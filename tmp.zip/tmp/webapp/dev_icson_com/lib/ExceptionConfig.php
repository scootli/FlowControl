<?php

class ExceptionConfig {
	
	private static $codes = array(
		'default' => array(
			'module_not_found' => 51,
			'action_not_found' => 52,
			'file_not_found' => 53,
			'class_not_found' => 54,
		),
		'TestGenerator' => array(
		),
		'TestExecutor' => array(
			'test_case_execute_error' => 151,
		)
	);
	
	public static function getExceptionCode($key) {
		$key = strtolower($key);
		$dbt = debug_backtrace();
		if(isset($dbt[1]['class'])) {
			$className = $dbt[1]['class'];
		} else {
			$className = 'default';
		}
		if(isset(self::$codes[$className]) && isset(self::$codes[$className][$key])) {
			return self::$codes[$className][$key];
		} else {
			if(isset(self::$codes['default'][$key])) {
				return self::$codes['default'][$key];
			} else {
				return 0;
			}
		}
	}
	
}