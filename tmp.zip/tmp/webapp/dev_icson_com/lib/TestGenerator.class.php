<?php

class TestGenerator {
	
	private $className = '';
	
	public function __construct($filename) {
		$ret = preg_match("/\/(\w+)\./", $filename, $matches);
		if($ret === 1) {
			$this->className = $matches[1];
			if(!class_exists($this->className)) {
				if(file_exists($filename)) {
					require_once($filename);
					if(!class_exists($this->className)) {
						throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "Class {$this->className} not found.");
					}
				} else {
					throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "File $filename not found.");
				}
			}
		} else {
			throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "Failed to get class name with file $filename.");
		}
	}
	
	public function generate() {
		$code_tpl = <<<CODE
<?php

class {$this->className}Test {

	private static \$test_obj;

	public static function setup() {
		{init_test_obj}
	}
	
	public static function tearDown() {
	
	}
{test_functions}
}
CODE;

		$methods = $this->getMethods(false);
		$test_functions = '';
		if(!empty($methods)) {
			$code_tpl = str_replace('{init_test_obj}', "self::\$test_obj = new {$this->className}();", $code_tpl);
			foreach ($methods as $m) {
				$name = ucfirst($m);
				$method_obj = new ReflectionMethod($this->className, $m);
				$params = array();
				foreach ($method_obj->getParameters() as $p) {
					if(!$p->isOptional()) {
						$params[] = '$' . $p->getName();
					}
				}
				$params_str = implode(', ', $params);
				$test_function = <<<CODE
	public static function test{$name}() {
		return self::\$test_obj->{$m}($params_str) !== false;		
	}
	
CODE;
				$test_functions .= $test_function;
			}
		} else {
			$code_tpl = str_replace('{init_test_obj}', '', $code_tpl);
		}
		
		$static_methods = $this->getMethods(true);
		foreach ($static_methods as $m) {
			$name = ucfirst($m);
			$method_obj = new ReflectionMethod($this->className, $m);
			$params = array();
			foreach ($method_obj->getParameters() as $p) {
				if(!$p->isOptional()) {
					$params[] = '$' . $p->getName();
				}
			}
			$params_str = implode(', ', $params);
			$test_function = <<<CODE

	public static function test{$name}() {
		return {$this->className}::{$m}($params_str) !== false;		
	}

CODE;
			$test_functions .= $test_function;
		}
		
		$code_tpl = str_replace('{test_functions}', $test_functions, $code_tpl);
		return $code_tpl;
	}
	
	private function getAllMethods() {
		$cls = new ReflectionClass($this->className);
		$methods = $cls->getMethods();
		$public_methods = array();
		foreach ($methods as $m) {
			if($m->isPublic() && !$m->isConstructor() && !$m->isDestructor() && !$m->isAbstract()) {
				$public_methods[] = $m;
			}
		}
		return $public_methods;
	}
	
	public function getMethods($isStatic) {
		$methods = $this->getAllMethods();
		$method_names = array();
		foreach ($methods as $m) {
			if($m->isStatic() == $isStatic) {
				$method_names[] = $m->name;
			}
		}
		return $method_names;
	}
}