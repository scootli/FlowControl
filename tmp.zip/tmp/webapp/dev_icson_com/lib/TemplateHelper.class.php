<?php
class TemplateHelper
{
	private static $allowedTypes = array(
		"right", "warn", /*"info", */"error"/*, "help"*/
	);
	
	public static function outMessage($message, $type = 'warn')
	{
		global $_WEBSITE_CFG;
		
		$TPL = new Template(PAGE_TPL_DIR, "keep");
		$TPL->set_file(array(
			'baseHandler' => 'base.tpl',
			'containerHandler' => 'message.tpl',
		));

		if(!in_array($type, self::$allowedTypes))
		{
			$type = 'warn';
		}

		$extMessage = '';
		if(is_array($message))
		{
			$tmp = array_shift($message);
			foreach ($message as $m)
			{
				$extMessage .= '<p>' . $m . '</p>';
			}
			if($extMessage)
			{
				$extMessage = '<div class="bd">' . $extMessage . '</div>';
			}
			$message = '<strong class="tit">' . $tmp . '</strong>';
		} 
		else 
		{
			$message = '<strong class="tit">' . $message . '</strong>';
		}
		$message = '<div class="para_blo para_big">
<div class="inner"> <b class="icon icon_msg4 icon_msg4_' . $type . '"></b>
<div class="hd">' . $message . '</div>
' . $extMessage . '
</div></div>';

		$vars = array(
			"message"	=> $message
		);
		$TPL->set_var($vars);
		$TPL->parse('container', 'containerHandler');
		$TPL->unset_var(array_keys($vars));
		
		$baseVars = array(
			"title"	=> '',
			"css_file"	=> '',
			'script_file' => ''
		);

		$TPL->set_var($baseVars);
		$TPL->pparse("output", "baseHandler");
	}

	public static function getBaseTPL($opt = array())
	{
		$tpl = new BaseTPL();
		$tpl->init($opt);
		return $tpl;
	}
}

class BaseTPL extends Template 
{
	private $opt = array();

	public function setOpt($options){
		foreach ($options as $k => $option)
		{
			$this->opt[$k] = $option;
		}
	}

	public function init($options = array())
	{
		parent::Template(PAGE_TPL_DIR, "keep");

		$this->opt = $options;

		$files = array('baseHandler' => 'base.tpl');
		
		if(!empty($this->opt['containerTPL'])){
			$files['containerHandler'] = $this->opt['containerTPL'];
		}

		$this->set_file($files);
	}

	public function out()
	{
		global $_WEBSITE_CFG;
		
		$this->parse('container', 'containerHandler');

		$baseVars = array();

		if(!empty($this->opt['title']))
		{
			$baseVars['title'] = $this->opt['title'];
		}

		if(!isset($this->opt['cssFile']))
			$baseVars['css_file'] = "";
		elseif(is_string($this->opt['cssFile']))
		{
			$baseVars['css_file'] = '<link href="' . $this->opt['cssFile'] . '" rel="stylesheet" type="text/css" />';
		}
		elseif(is_array($this->opt['cssFile'])) 
		{
			$baseVars['css_file'] = '';
			foreach ($this->opt['cssFile'] as $filename) 
			{
				if(!empty($baseVars['css_file']))
					$baseVars['css_file'] .= "\n";
				$baseVars['css_file'] .= '<link href="' . $filename . '" rel="stylesheet" type="text/css" />';
			}
		}
		
		if(!isset($this->opt['scriptFile']))
			$baseVars['script_file'] = "";
		else if(is_string($this->opt['scriptFile']))
		{
			$baseVars['script_file'] = '<script src="' . $this->opt['scriptFile'] . '" type="text/javascript"></script>';
		} 
		else if(is_array($this->opt['scriptFile'])) 
		{
			$baseVars['script_file'] = '';
			foreach ($this->opt['scriptFile'] as $filename) 
			{
				if(!empty($baseVars['script_file']))
					$baseVars['script_file'] .= "\n";
				$baseVars['script_file'] .= '<script src="' . $filename . '"  type="text/javascript"></script>';
			}
		}
		
		$this->set_var($baseVars);
		$this->pparse("output", "baseHandler");
	}
}
// End Of Script