<?php

class TestExecutor {
	
	private $className;
	
	public function __construct($filename) {
		$ret = preg_match("/\/(\w+)\./", $filename, $matches);
		if($ret === 1) {
			$this->className = $matches[1];
			if(!class_exists($this->className)) {
				if(file_exists($filename)) {
					require_once($filename);
					if(!class_exists($this->className)) {
						throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "Class {$this->className} not found.");
					}
				} else {
					throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "File $filename not found.");
				}
			}
		} else {
			throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "Failed to get class name with file $filename.");
		}
	}
	
	public function execute() {
		$testcases = $this->getTestCase();
		$hasSetup = method_exists($this->className, 'setup');
		$hasTearDown = method_exists($this->className, 'tearDown');
		$result = array();
		set_error_handler(array($this, 'onError'));
		foreach ($testcases as $tc) {
			try {
				if($hasSetup) {
					call_user_func(array($this->className, 'setup'));
				}
				$result[$tc] = array();
				$result[$tc]['result'] = call_user_func(array($this->className, $tc));
				if($hasTearDown) {
					call_user_func(array($this->className, 'tearDown'));
				}
			} catch (BaseException $e) {
				$result[$tc]['result'] = false;
				$result[$tc]['errCode'] = $e->errCode;
				$result[$tc]['errMsg'] = $e->errMsg;
			} catch (Exception $e) {
				$result[$tc]['result'] = false;
				$result[$tc]['errCode'] = ExceptionConfig::getExceptionCode('test_case_execute_error');
				$result[$tc]['errMsg'] = $e->getMessage();
			}
		}
		restore_error_handler();
		return $result;
	}
	
	public function getTestCase() {
		$cls = new ReflectionClass($this->className);
		$methods = $cls->getMethods();
		$testcases = array();
		foreach ($methods as $m) {
			if(strpos($m->name, 'test') === 0) {
				$testcases[] = $m->name;
			}
		}
		return $testcases;
	}
	
	public function onError($level, $messge) {
		throw new BaseException(ExceptionConfig::getExceptionCode('test_case_execute_error'), "[{$level}]$messge");
	}
}