<?php

error_reporting(E_ALL);
date_default_timezone_set('Asia/Shanghai');

require_once('/data/release/PHPLIB/lib/Config.php');
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("DEV_WEB_ROOT", WEB_ROOT . "dev_icson_com/");
define('PAGE_TPL_DIR', DEV_WEB_ROOT . 'tpl/');
define('CACHE_PATH', DEV_WEB_ROOT . 'cache/');
require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, DEV_WEB_ROOT . 'lib/', DEV_WEB_ROOT . 'api/'))
    ->setSavePath(CACHE_PATH)->execute();

try {
	// ��� module ��
	if (!empty($_REQUEST['mod'])){
		$mod_name = preg_replace("/[^a-zA-Z]/", '', trim($_REQUEST['mod']));
	} else {
		$mod_name = 'index';
	}
	
	$className = ucfirst($mod_name);
	$filename = DEV_WEB_ROOT . 'mod/' . $mod_name;
	if(file_exists($filename . '.php')) {
		require_once($filename . '.php');
	} else if(file_exists($filename . '.class.php')) {
		require_once($filename . '.class.php');
	} else {
		throw new BaseException(ExceptionConfig::getExceptionCode('module_not_found'), "Unexpected module {$mod_name}.");
	}
	
	if(!class_exists($className)) {
		throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "Failed to found class $className.");
	}
	
	// ��� act ��
	if (!empty($_REQUEST['act'])){
		$act_name = preg_replace("/[^a-zA-Z]/", '', trim($_REQUEST['act']));
	} else {
		$act_name = 'execute';
	}
	
	$methodName = $act_name . 'View';
	if(!method_exists($className, $methodName)) {
		throw new BaseException(ExceptionConfig::getExceptionCode('action_not_found'), "Failed to found action {$act_name}.");
	}
	
	call_user_func(array($className, $methodName));
	
} catch (BaseException $e) {
	TemplateHelper::outMessage($e->errCode . " : " . $e->errMsg, "error");
}


