<?php

error_reporting(E_ALL);
date_default_timezone_set('Asia/Shanghai');

require_once('/data/release/PHPLIB/lib/Config.php');
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("DEV_WEB_ROOT", WEB_ROOT . "dev_icson_com/");
define('PAGE_TPL_DIR', DEV_WEB_ROOT . 'tpl/');
define('CACHE_PATH', DEV_WEB_ROOT . 'cache/');
define("DEFAULT_CACHE_TIME", 300);
require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, DEV_WEB_ROOT . 'lib/', DEV_WEB_ROOT . 'api/'))
    ->setSavePath(CACHE_PATH)->execute();

try {
	// ��� module ��
	if (!empty($_REQUEST['mod'])){
		$mod_name = preg_replace("/[^a-zA-Z]/", '', trim($_REQUEST['mod']));
	} else {
		$mod_name = 'index';
	}
	
	$className = ucfirst($mod_name);
	$filename = DEV_WEB_ROOT . 'mod/' . $mod_name;
	if(file_exists($filename . '.php')) {
		require_once($filename . '.php');
	} else if(file_exists($filename . '.class.php')) {
		require_once($filename . '.class.php');
	} else {
		throw new BaseException(ExceptionConfig::getExceptionCode('module_not_found'), "Unexpected module {$mod_name}.");
	}
	
	if(!class_exists($className)) {
		throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "Failed to found class $className.");
	}
	
	// ��� act ��
	if (!empty($_REQUEST['act'])){
		$act_name = preg_replace("/[^a-zA-Z]/", '', trim($_REQUEST['act']));
	} else {
		$act_name = 'execute';
	}
	
	$methodName = $act_name;
	if(!method_exists($className, $methodName)) {
		throw new BaseException(ExceptionConfig::getExceptionCode('action_not_found'), "Failed to found action {$act_name}.");
	}
	
	// �������ͷ������(�Ա� modules ���ܹ��޸�)
	$wrap_header = array(
		"httpv1_0"	=> "HTTP/1.0 200 OK",
		//"httpv1_1"	=> "HTTP/1.1 200 OK",
		"cache"		=> "Cache-Control: max-age=" . DEFAULT_CACHE_TIME,
		"expires"	=> "Expires: " . gmdate( 'D, d M Y H:i:s', time() + -1) . ' GMT',
		"type"     => "Content-type:text/html; charset=" . (defined('CHARSET') ? CHARSET : 'GB2312'),
	);
	
	$ret = call_user_func(array($className, $methodName));
	
} catch (BaseException $e) {
	$ret = array( 'errno' => $e->errCode, 'errmsg' => $e->errMsg );
}

if (isset($_GET['jsontype']) && $_GET['jsontype'] === 'str'){
    $json_str = $ret;
} else {
    $json_str = ToolUtil::gbJsonEncode($ret);
}

// ��ȫ�������������� header
if (is_array($wrap_header))
{
    foreach ($wrap_header as $key => $header_line)
    {
        @header($header_line);
    }
}

// �������Ļص�������
$callback_function = (empty($_REQUEST['callback']) || !preg_match("/^[a-zA-Z0-9_$\.]+$/", trim($_REQUEST['callback'])))
    ? '' : trim($_REQUEST['callback']);

$is_json_format = (empty($_REQUEST['fmt']) || !preg_match("/^[0-9]+$/", trim($_REQUEST['fmt'])))
    ? 0 : intval($_REQUEST['fmt']);
    
// �������iframe��ʽ�����json��Ϣ
if ( $is_json_format == 0 )
{
    if ( empty( $callback_function ) )
    {
        echo $json_str;
    }
    else
    {
		if(isset($_REQUEST['exception'])){
			echo 'try{'."$callback_function($json_str)".';}catch(e){};';
		}
		else{
			echo "$callback_function($json_str);";
		}
    }
}
else
{
    echo <<<EOT
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn" lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<meta http-equiv="Content-Language" content="gb2312" />
<meta name="robots" content="all" />
<meta name="author" content="Tencent-ISRD" />
<meta name="Copyright" content="Tencent" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<title>POST - ICSON</title>
</head>
<body>
<script type="text/javascript">
var domain="icson.com";
document.domain = domain;
<!--
frameElement.callback($json_str);
//-->
</script>
</body>
</html>
EOT;
}