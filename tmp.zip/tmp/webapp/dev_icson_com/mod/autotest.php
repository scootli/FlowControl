<?php

class Autotest {
	
	public static function editView() {
		$TPL = TemplateHelper::getBaseTPL(array(
			'title' => '���������༭',
			'containerTPL' => 'test_edit.tpl'
		));
		
		$TPL->out();
	}
	
	public static function genTemplate() {
		$params = ToolUtil::array_fetch($_POST, array(
			'path' => array( 'allowEmpty' => false, 'secureType' => 'string' ),
		));
		
		if(!file_exists($params['path'])) {
			throw new BaseException(ExceptionConfig::getExceptionCode('file_not_found'), "File {$params['path']} not exist.");
		}
		
		$test_gen = new TestGenerator($params['path']);
		return array( 'errno' => 0, 'data' => $test_gen->generate() );
	}
	
	public static function saveTest() {
		$params = ToolUtil::array_fetch($_POST, array(
			'path' => array( 'allowEmpty' => false, 'secureType' => 'string' ),
			'content' => array( 'allowEmpty' => false )
		));
		
		$ret = preg_match("/\/(\w+)\./", $params['path'], $matches);
		if($ret === 1) {
			$className = $matches[1];
		} else {
			throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "Failed to get class name with file $filename.");
		}
		
		$filename = DEV_WEB_ROOT . "test/{$className}Test.php";
		file_put_contents($filename, $params['content']);
		return array( 'errno' => 0, 'data' => $filename );
	}
	
	public static function executeTest() {
		$params = ToolUtil::array_fetch($_POST, array(
			'path' => array( 'allowEmpty' => false, 'secureType' => 'string' ),
		));
		
		$ret = preg_match("/\/(\w+)\./", $params['path'], $matches);
		if($ret === 1) {
			$className = $matches[1];
		} else {
			throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "Failed to get class name with file $filename.");
		}
		
		$filename = DEV_WEB_ROOT . "test/{$className}Test.php";
		$test_executor = new TestExecutor($filename);
		$ret = $test_executor->execute();
		
		return array( 'errno' => 0, 'data' => $ret );
	}
	
	public static function loadTest() {
		$params = ToolUtil::array_fetch($_POST, array(
			'path' => array( 'allowEmpty' => false, 'secureType' => 'string' ),
		));
		
		$ret = preg_match("/\/(\w+)\./", $params['path'], $matches);
		if($ret === 1) {
			$className = $matches[1];
		} else {
			throw new BaseException(ExceptionConfig::getExceptionCode('class_not_found'), "Failed to get class name with file $filename.");
		}
		
		$filename = DEV_WEB_ROOT . "test/{$className}Test.php";
		if(file_exists($filename)) {
			$content = file_get_contents($filename);
		} else {
			$content = '';
		}
		
		return array( 'errno' => 0, 'data' => $content );
	}
}