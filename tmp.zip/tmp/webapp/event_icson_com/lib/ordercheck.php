<?php
require_once(WEB_PAGE_ROOT . 'inc/order.inc.php');

class OrderCheck {
	
	private $orderInfo = array();
	private $db = null;
	private $dbConfig = 'icson_event';
	private $table = 't_event_lottery_history_';
	private $eventSn = '';
	public $result = array();
	
	public function __construct($sn, $config) {
		$this->eventSn = $sn;
		//�������
		//$rst = $this->checkSn();
		global $orderInfo;
		
		$evtInfo = $config->event_info;
		$evtInfoObj = json_decode($evtInfo);
		$orderInfoCfg = $evtInfoObj->order_info;
		
		$newOrderInfo = array();
		foreach ($orderInfo as $key => $value) {
			$newOrderInfo[$key] = $value;
		}
		$newOrderInfo['order_min'] = $orderInfoCfg->order_min;
		$newOrderInfo['order_max'] = $orderInfoCfg->order_max;
		$newOrderInfo['order_start_time'] = $orderInfoCfg->order_start_time;
		$newOrderInfo['order_end_time'] = $orderInfoCfg->order_end_time;
		$newOrderInfo['order_time_limit_daily'] = $orderInfoCfg->order_time_limit_daily;
		$newOrderInfo['is_online'] = $orderInfoCfg->isonline;
		$newOrderInfo['allowpids'] = $orderInfoCfg->allowpids;
		
		$this->orderInfo = $newOrderInfo;
		$this->eventSn = $sn;
		$this->db = Config::getDB($this->dbConfig);
	}
	/**
	* �������
	* @param int $orderId
	*/
	public function orderGeCheck($orderId, $site) {
		//�������
// 		$rst = $this->checkSn();
// 		if (!$rst) {
// 			return false;
// 		}
		
		//�ж϶������Ƿ�Ϸ�
		$orderInputCheck = $this->checkOrderInput($orderId);
		if (!$orderInputCheck) {
			return false;
		}
	
		//��鶩���Ƿ�ʹ�ù�
		$orderUserdCheck = $this->checkOrderUsed($orderId);
		if (!$orderUserdCheck) {
			return false;
		}
	
		//��鶩���Ƿ����
		$userOrderInfo = array();
		$orderExistCheck = $this->checkOrderIsExist($orderId, $userOrderInfo);
		if (!$orderExistCheck) {
			return false;
		}
		
		//��鶩���Ƿ�ǰվ
		$orderSiteCheck = $this->checkOrderSite($userOrderInfo, $site);
		if (!$orderSiteCheck) {
			return false;
		}
	
		//��鶩���������
		$orderCostCheck = $this->checkOrderCostLimit($userOrderInfo);
		if (!$orderCostCheck) {
			return false;
		}
	
		//����µ�ʱ���Ƿ��ڻ����ʱ����
		$orderInDate = $this->checkOrderInDate($userOrderInfo);
		if (!$orderInDate) {
			return false;
		}
	
		//��鶩��״̬
		$orderStatusCheck = $this->checkOrderStatus($userOrderInfo);
		if (!$orderStatusCheck) {
			return false;
		}
		
		//��鶩��֧����ʽ
		$orderPayTypeCheck = $this->checkIsOnlinePay($userOrderInfo);
		if (!$orderPayTypeCheck) {
			return false;
		}
	
		return true;
	}
	
	/**
	 * ���sn����
	 */
	private function checkSn() {
		global $orderInfo;
		if (!isset($orderInfo[$this->eventSn]) || empty($orderInfo[$this->eventSn])) {
			$rs['errno'] = $orderInfo['error']['SN_ERROR']['errno'];
			$rs['message'] = $orderInfo['error']['SN_ERROR']['message'];
			$this->result = $rs;
			return false;
		}
		return true;
	}
	
	/**
	* �ж϶������Ƿ�Ϸ�
	* @param string $orderId
	*/
	private function checkOrderInput($orderId) {
		if (empty($orderId)) {
			$rs['errno'] = $this->orderInfo['error']['ORDERID_EMPTY']['errno'];
			$rs['message'] = str_replace('{money}', $this->orderInfo['order_min']/100, $this->orderInfo['error']['ORDERID_EMPTY']['message']);
			$this->result = $rs;
			return false;
		}
	
		if (!preg_match('/^(\d{10})$/', $orderId)) {
			$rs['errno'] = $this->orderInfo['error']['ORDERID_FMT_ERROR']['errno'];
			$rs['message'] = $this->orderInfo['error']['ORDERID_FMT_ERROR']['message'];
			$this->result = $rs;
			return false;
		}
		
		return true;
	}
	
	/**
	 *
	 * ��鶩���Ƿ�ʹ�ù�
	 * @param string $orderId
	 */
	private function checkOrderUsed($orderId) {
		$sql = "SELECT count(*) as count FROM " . $this->table . $this->eventSn . " WHERE from_id = '$orderId'";
		$rst = $this->db->getRows($sql);
		$count = $rst[0]['count'];
	
		if (!empty($count)) {
			$rs['errno'] = $this->orderInfo['error']['ORDERID_USED']['errno'];
			$rs['message'] = str_replace("{money}", $this->orderInfo['order_min']/100, $this->orderInfo['error']['ORDERID_USED']['message']);
			$this->result = $rs;
			return false;
		}
		return true;
	}
	
	/**
	 * ��鶩���Ƿ����
	 * @param string $orderId
	 * @param array $userOrderInfo
	 */
	private function checkOrderIsExist($orderId, &$userOrderInfo) {
		$uid = IUser::getLoginUid();
		$userOrderInfo = IOrder::getOneOrder($uid, $orderId);
	
		//@TODO
//  		$userOrderInfo['status'] = 4;
//  		$userOrderInfo['order_date'] = strtotime("2011-12-21 10:25:00");
//  		$userOrderInfo['order_cost'] = 8200;
//  		$userOrderInfo['hw_id'] = 1001;
	
		if (empty($userOrderInfo)) {
			$rs['errno'] = $this->orderInfo['error']['ORDER_EMPTY']['errno'];
			$rs['message'] = $this->orderInfo['error']['ORDER_EMPTY']['message'];
			$this->result = $rs;
			return false;
		}
		
		$allowPids = $this->orderInfo['allowpids'];
		$orderItem = IOrder::getOrderItems($uid, $orderId);
		
		if (isset($allowPids) && !empty($allowPids)) {
			$isAllow = false;
			$allowPidsArr = explode(",", $allowPids);
			foreach ($orderItem as $oi) {
				$pid = $oi['product_char_id'];
				
				if (in_array($pid, $allowPidsArr)) {
					$isAllow = true;
					break;
				}
			}
			if (!$isAllow) {
				$rs['errno'] = $this->orderInfo['error']['ORDER_ALLOW_ERROR']['errno'];
				$rs['message'] = $this->orderInfo['error']['ORDER_ALLOW_ERROR']['message'];
				$this->result = $rs;
				return false;
			}
		}
		return true;
	}
	
	/**
	 * ��鶩���Ľ������
	 * @param array $userOrderInfo
	 */
	private function checkOrderCostLimit($userOrderInfo) {
		$orderMin = $this->orderInfo['order_min'];
		$orderMax = $this->orderInfo['order_max'];
	
		if (!empty($orderMin) && $userOrderInfo['order_cost'] < $orderMin) {
			$rs['errno'] = $this->orderInfo['error']['ORDER_COST_MIN']['errno'];
			$rs['message'] = str_replace('{money}', $this->orderInfo['order_min']/100, $this->orderInfo['error']['ORDER_COST_MIN']['message']);
			$this->result = $rs;
			return false;
		}
	
		if (!empty($orderMax) && $userOrderInfo['order_cost'] > $orderMax) {
			$rs['errno'] = $this->orderInfo['error']['ORDER_COST_MAX']['errno'];
			$rs['message'] = $this->orderInfo['error']['ORDER_COST_MAX']['message'];
			$this->result = $rs;
			return false;
		}
		return true;
	}
	
	/**
	 * ����µ�ʱ���Ƿ��ڻ����ʱ����
	 * @param array $userOrderInfo
	 */
	private function checkOrderInDate($userOrderInfo) {
		if ($this->orderInfo['order_time_limit_daily']) {
			$orderStartTime = strtotime(date("Y-m-d 00:00:00"));
			$orderEndTime = strtotime(date("Y-m-d 00:10:00")) + 60 * 60 * 24;//������10���ӵ��ӳ�
			if ($userOrderInfo['order_date'] < $orderStartTime
			|| $userOrderInfo['order_date'] > $orderEndTime) {
				$rs['errno'] = $this->orderInfo['error']['ORDER_NOT_DAILY']['errno'];
				$rs['message'] = $this->orderInfo['error']['ORDER_NOT_DAILY']['message'];
				$this->result = $rs;
				return false;
			}
		} else {
			$orderStartTime = strtotime($this->orderInfo['order_start_time']);
			$orderEndTime = strtotime($this->orderInfo['order_end_time']);
		
			if (!empty($orderStartTime)
			&& ($userOrderInfo['order_date'] < $orderStartTime
			|| $userOrderInfo['order_date'] > $orderEndTime)) {
				$rs['errno'] = $this->orderInfo['error']['ORDER_NOT_INDATE']['errno'];
				$rs['message'] = $this->orderInfo['error']['ORDER_NOT_INDATE']['message'];
				$this->result = $rs;
				return false;
			}
		}
		return true;
	}
	
	/**
	 * ��鶩��״̬
	 * @param array $userOrderInfo
	 */
	private function checkOrderStatus($userOrderInfo) {
		$orderStatus = $userOrderInfo['status'];
		Global $_OrderState;
	
		//�������ڴ���˻��������״̬
		if ($orderStatus == $_OrderState['Origin']['value'] || $orderStatus == $_OrderState['WaitingManagerAudit']['value']) {
			$rs['errno']= $this->orderInfo['error']['ORDER_ORIGIN']['errno'];
			$rs['data'] = $this->orderInfo['error']['ORDER_ORIGIN']['message'];
			$this->result = $rs;
			return false;
		}
	
		//�������ڴ�����״̬
		if ($orderStatus == $_OrderState['WaitingOutStock']['value']) {
			$rs['errno']= $this->orderInfo['error']['ORDER_WAITING_OUT_STOCK']['errno'];
			$rs['data'] = $this->orderInfo['error']['ORDER_WAITING_OUT_STOCK']['message'];
			$this->result = $rs;
			return false;
		}
	
		//�������ڴ�֧��״̬
		if ($orderStatus == $_OrderState['WaitingPay']['value']) {
			$rs['errno']= $this->orderInfo['error']['ORDER_WAITING_PAY']['errno'];
			$rs['data'] = $this->orderInfo['error']['ORDER_WAITING_PAY']['message'];
			$this->result = $rs;
			return false;
		}
	
		//���������������ϻ�Ա�����ϻ��û�����״̬
		if ($orderStatus == $_OrderState['ManagerCancel']['value'] ||
		$orderStatus == $_OrderState['CustomerCancel']['value'] ||
		$orderStatus == $_OrderState['EmployeeCancel']['value']) {
			$rs['errno']= $this->orderInfo['error']['ORDER_CANCLE']['errno'];
			$rs['data'] = $this->orderInfo['error']['ORDER_CANCLE']['message'];
			$this->result = $rs;
			return false;
		}
	
		//�������ڲ����˻���ȫ���˻����û�����״̬
		if ($orderStatus == $_OrderState['PartlyReturn']['value'] ||
		$orderStatus == $_OrderState['Return']['value'] ) {
			$rs['errno']= $this->orderInfo['error']['ORDER_RETURN']['errno'];
			$rs['data'] = $this->orderInfo['error']['ORDER_RETURN']['message'];
			$this->result = $rs;
			return false;
		}
	
		return true;
	}
	
	/**
	 * �ж϶���վ������
	 * @param array $userOrderInfo
	 * @param int $site
	 */
	private function checkOrderSite($userOrderInfo, $site) {
		global $_Wh_id;
		if ($userOrderInfo['hw_id'] != $site && !empty($site)) {
			$rs['errno']= $this->orderInfo['error']['ORDER_SITE_ERROR']['errno'];
			$rs['data'] = str_replace('{site}', $_Wh_id[$site], $this->orderInfo['error']['ORDER_SITE_ERROR']['message']);
			$this->result = $rs;
			return false;
		}
		return true;
	}
	
	/**
	 * �Ƿ��ж�����֧��
	 * @param array $userOrderInfo
	 */
	private function checkIsOnlinePay($userOrderInfo) {
		if ($this->orderInfo['is_online']) {
			global $_PAY_MODE;
            $isNet = $_PAY_MODE[$userOrderInfo['hw_id']][$userOrderInfo['pay_type']]['IsNet'];
			if (!$isNet) {
				$rs['errno']= $this->orderInfo['error']['ORDER_PAYTYPE_ERROR']['errno'];
				$rs['data'] = $this->orderInfo['error']['ORDER_PAYTYPE_ERROR']['message'];
				$this->result = $rs;
				return false;
			} 
		}
		return true;
	}
}