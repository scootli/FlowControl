<?php

class ActionDispatcher {
	
	public static $errCode = 0;
	public static $errMsg = '';
	
	private static function clearErr() {
		self::$errCode = 0;
		self::$errMsg = '';
	}
	
	public static function dispatch($className, $methodName, $component) {
		self::clearErr();
		
		if(file_exists(WEB_PAGE_ROOT . "action/$className.php")) {
			require_once WEB_PAGE_ROOT . "action/$className.php";
		} else if(file_exists(WEB_PAGE_ROOT . "action/$className.class.php")) {
			require_once WEB_PAGE_ROOT . "action/$className.class.php";
		} else {
			Logger::err("Class $className not found, file not exist.");
			self::$errCode = ExtraErrorConfig::getErrorCode('server_error');
			self::$errMsg = "������Դ�����ڣ�";
			return false;
		}
		
		if(!class_exists($className)) {
			Logger::err("Class $className not found.");
			self::$errCode = ExtraErrorConfig::getErrorCode('server_error');
			self::$errMsg = "������Դ�����ڣ�";
			return false;
		}
		
		if(!method_exists($className, $methodName)) {
			Logger::err("Method $className::$methodName not found.");
			self::$errCode = ExtraErrorConfig::getErrorCode('server_error');
			self::$errMsg = "������Դ�����ڣ�";
			return false;
		}
		
		$ret = call_user_func(array($className, $methodName), $component);
		if($ret === false) {
			Logger::err("Failed to execute $className::$methodName.");
			self::$errCode = ExtraErrorConfig::getErrorCode('server_error');
			self::$errMsg = "����������";
			return false;
		}
		
		return $ret;
	}
}