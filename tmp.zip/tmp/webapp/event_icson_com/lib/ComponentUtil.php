<?php

class ComponentUtil {
	
	public static $errCode = 0;
	public static $errMsg = '';
	
	private static function clearErr() {
		self::$errCode = 0;
		self::$errMsg = '';
	}
	
	/**
	 * �������л�ȡ��֤����
	 * @param int $id ���id
	 * @param int $sub_id ��֤���
	 */
	public static function getVerifyParameters($id, $sub_id = 0) {
		self::clearErr();
		$param_config = IVerifyConfig::checkParameterNeeded(ACT_TYPE_COMPONENT, $id, $sub_id);
		if($param_config === false) {
			Logger::err(IVerifyConfig::$errCode . ' : ' . IVerifyConfig::$errMsg);
			self::$errCode = ExtraErrorConfig::getErrorCode('verify_config_not_found');
			self::$errMsg = '��֤���û�ȡʧ��';
			return false;
		}
		$params = array();
		foreach ($param_config as $name) {
			switch ($name) {
				case 'order_id':
					$tmp = ArrayUtil::array_fetch($_REQUEST, array(
						'order_id' => array( 'allowEmpty' => false, 'secureType' => 'int' )
					));
					if($tmp === false) {
						self::$errCode = ExtraErrorConfig::getErrorCode('invalid_parameter');
						self::$errMsg = '����������';
						return false;
					}
					$params['order_id'] = $tmp['order_id'];
					break;
				default:
					break;
			}
		}
		return $params;
	}
	
	/**
	 * ������֤����
	 * @param int $id ���id
	 * @param array $params ��֤����
	 */
	public static function checkVerifyParameters($id, $params) {
		self::clearErr();
		if(!is_array($params)) {
			self::$errCode = ExtraErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = '�����������';
		}
		foreach ($params as $k => $v) {
			switch ($k) {
				case 'order_id':
					$ret = IEventData::hasBound(IEventData::COMP_TYPE_UNIFY_COMP, $id, IEventData::DATA_TYPE_ORDER_ID, $v);
					if($ret === false) {
						if(IEventData::$errCode !== 0) {
							Logger::err(IEventData::$errCode . ' : ' . IEventData::$errMsg);
							self::$errCode = ExtraErrorConfig::getErrorCode('server_error');
							self::$errMsg = '��������æ��';
							return false;
						}
					} else {
						self::$errCode = ExtraErrorConfig::getErrorCode('duplicate_order_id');
						self::$errMsg = '�������ظ���';
						return false;
						return false;
					}
					break;
				default:
					break;
			}
		}
		return true;
	}
	
	/**
	 * ���沢����֤��ز���
	 * @param int $id ���id
	 * @param int $uid �û�id
	 * @param array $params ��֤����
	 */
	public static function saveVerifyParameters($id, $uid, $params) {
		self::clearErr();
		if(!is_array($params)) {
			self::$errCode = ExtraErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = '�����������';
		}
		foreach ($params as $k => $v) {
			switch ($k) {
				case 'order_id':
					$ret = IEventData::addAndBind($uid, IEventData::COMP_TYPE_UNIFY_COMP, $id, IEventData::DATA_TYPE_ORDER_ID, $v);
					if($ret === false) {
						Logger::err(IEventData::$errCode . ' : ' . IEventData::$errMsg);
						self::$errCode = ExtraErrorConfig::getErrorCode('server_error');
						self::$errMsg = '��������æ��';
						return false;
					}
					break;
				default:
					break;
			}
		}
		return true;
	}
	
	/**
	 * ����ʱ����
	 * @param string $key ����key
	 */
	public static function checkTimeLock($key) {
		$cas = -1;
		$expire_timestamp = 0;
		$ret = IDataCache::casGetData($key, $cas, $expire_timestamp);
		if($ret === false) {
			if(IDataCache::$errCode !== IDataCache::ERROR_KEY_EXPIRED && IDataCache::$errCode !== IDataCache::ERROR_NO_DATA) {
				Logger::err(IDataCache::$errCode . ' : ' . IDataCache::$errMsg);
				self::$errCode = IDataCache::$errCode;
				self::$errMsg = IDataCache::$errMsg;
				return false;
			} else {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * ����ʱ����
	 * @param string $key ����key
	 * @param int $expire ������Ч��
	 */
	public static function setTimeLock($key, $expire) {
		$cas = -1;
		$ret = IDataCache::casSetData($key, 1, $cas, $expire);
		if($ret === false) {
			if(IDataCache::$errCode !== ErrorConfig::getErrorCode('cas_not_match', 'IDataCache')) {
				Logger::err(IDataCache::$errCode . ' : ' . IDataCache::$errMsg);
				self::$errCode = IDataCache::$errCode;
				self::$errMsg = IDataCache::$errMsg;
			}
			return false;
		}
		return true;
	}
	
	/**
	 * ��ȡ��֤��
	 */
	public static function getVerifyCode() {
		$clientIp = ToolUtil::getClientIP();
		
		global $_IP_CFG;
		for($i = 0; $i < 5; $i++) {
			$ret = get_verify_code(VERIFY_CODE_APPID, $_IP_CFG['verify_code']['code_server'][0]['IP'], $_IP_CFG['verify_code']['code_server'][0]['PORT'], $_IP_CFG['verify_code']['code_server'][1]['IP'], $_IP_CFG['verify_code']['code_server'][1]['PORT'], $clientIp);
			if($ret !== false) {
				return $ret;
			}
		}
		Logger::err('��ȡ��֤��ʧ�ܣ�');
		return false;
	}
	
	/**
	 * ������֤��
	 * @param string $vcode ��֤��
	 */
	public static function checkVerifyCode($vcode) {
		$clientIp = ToolUtil::getClientIP();
		
		if(!isset($_COOKIE['verifysession'])) {
			self::$errCode = ExtraErrorConfig::getErrorCode('unexpected_request');
			self::$errMsg = '��֤��Ϣ����';
			return false;
		}
		
		global $_IP_CFG;
		for($i = 0; $i < 5; $i++) {
			$ret = check_verify_code(VERIFY_CODE_APPID, $_IP_CFG['verify_code']['check_server'][0]['IP'], $_IP_CFG['verify_code']['check_server'][0]['PORT'], $_IP_CFG['verify_code']['check_server'][1]['IP'], $_IP_CFG['verify_code']['check_server'][1]['PORT'], $clientIp, $vcode, $_COOKIE['verifysession']);
			if($ret === true) {
				break;
			} else if($ret === false) {
				return false;
			}
		}
		if($i == 5) {
			// ��֤�������ͨѶ���󣬺�����֤��
			self::$errCode = ExtraErrorConfig::getErrorCode('server_error');
			self::$errMsg = '��������æ��';
			Logger::err("������֤�������ʧ�ܣ�[ ret : $ret ]");
			return false;
		}
		
		return true;
	}

	/**
	 * �����Դ����
	 * @param array $domain ����������
	 */
	public static function checkReferer($domain) {
		$referer = $_SERVER["HTTP_REFERER"];

		if($referer) {
			$refererhost = parse_url($referer);
			$host = strtolower($refererhost['host']);
			$domain_list = array();
			if (is_array($domain)) {
				$domain_list = $domain;
			}else{
				array_push($domain_list, $domain);
			}

			if (!empty($domain_list)) {
				foreach ($domain_list as $v) {
					if(substr_count($host, $v)) {
						return true;
					}
				}
			}
		}
		return false;
	}
}
