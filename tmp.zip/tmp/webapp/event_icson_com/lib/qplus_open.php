<?php
/**
*PHP SDK for QPlus Open API
*
*@version 1.0.1
*@copyright 2011,Tencent Corporation.All rights reserved.
*/


/**
*如果您的PHP不支持JSON，请升级到PHP5.2.x以上版本
*/
if(!function_exists("json_decode"))
{
	throw new Exception('qplus API needs the JSON PHP extension.');
}
if(!function_exists("hash_hmac"))
{
	throw new Exception('qplus API needs the hash_hmac function.');
}

/**
*提供访问Q+开放平台OpenAPI的接口
*/
class QPlusOpen {
	/**
	**SDK版本号
	*/
	const VERSION = '1.0.1';
	
	/**
	*申请的应用ID
	*/
	private $app_id;
	
	/**
	*应用密钥，用于验证合法性
	*/
	private $app_secret;
	
	/**
	**语言版本
	*/
	private $app_lang;
	
	/**
	*qplus OpenAPI服务器域名
	*/
	private $serverName = 'http://openid.qplus.com/';

	
	function __construct($app_id,$app_secret,$app_lang = "2052")
	{
		$this->setAppId($app_id);
		$this->setAppSecret($app_secret);
		$this->setAppLang($app_lang);
	}
	
	/**
	*设置应用ID
	*/
	public function setAppId($app_id)
	{
		$this->app_id = $app_id;
	}
	
	/**
	*获取应用ID
	*/
	public function getAppId()
	{
		return $this->app_id;
	}
	
	/**
	*设置密钥
	*/
	public function setAppSecret($app_secret)
	{
		$this->app_secret = $app_secret;
	}
	
	/**
	*获取密钥
	*/
	public function getAppSecret()
	{
		return $this->app_secret;
	}
	
	/**
	*设置语言
	*/
	public function setAppLang($app_lang)
	{
		$this->app_lang = $app_lang;
	}
	
	/**
	*获取语言
	*/
	public function getAppLang()
	{
		return $this->app_lang;
	}
	
	/**
	*执行一个HTTP POST请求
	*/
	private function makeRequest($cgi,$params=array())
	{
		$result = $cgi;
		$data = "";
		//组装url
		$url = $this->serverName . "cgi-bin/" . $cgi;
		//组装参数
		$params = $params;
		if(empty($params))
			$params = array();
		$params["app_id"] = $this->app_id;
		$params["app_nonce"] = substr(uniqid(rand(),true), 0, 20);
		$params["app_ts"] = time();
		$params["app_userip"] = $_SERVER["REMOTE_ADDR"];
		//排序
		ksort($params);
		//编码
		foreach ( $params as $key => $value ) {
			$params[$key] = urlencode($value);
			$result .= "&" . $key . '=' . urlencode($value);
		}
		
		//进行签名，组装url
		$data = http_build_query($params) . '&sig=' . hash_hmac("sha1" ,  $result  , $this->app_secret . "&");
		
		$context['http'] = array ( 'method' => 'POST', 
									'header' => "Cache-Control: no-cache\r\n" . "Content-type: application/x-www-form-urlencoded\r\n" . "Content-length:" . strlen($data),
									'content' => $data 
								);
		
		return file_get_contents($url, false, stream_context_create($context));		
	}
	
	
	/**
	*拼装跳转地址，目前此方法没有用到
	*/
	public function getLoginUrl()
	{
		return "http://openid.qplus.com/cgi-bin/app_qqlogin?" . $this->getLoginParams();
	}
	
	/**
	*拼装参数，获取签名
	*/
	public function getLoginParams()
	{
		$params["app_id"] = $this->app_id;
		$params["app_nonce"] = substr(uniqid(rand(),true), 0, 20);
		$params["app_ts"] = time();
		$params["app_userip"] = $_SERVER["REMOTE_ADDR"];
		$params["app_lang"] = $this->app_lang;
		//排序
		ksort($params);
		//编码
		foreach ( $params as $key => $value ) {
			$params[$key] = urlencode($value);
			$result .= "&" . $key . '=' . urlencode($value);
		}
		
		//进行签名，组装参数
		$data = http_build_query($params) . '&sig=' . hash_hmac("sha1" , "app_qqlogin" . $result  , $this->app_secret . "&");
		
		
		return $data;
	}
	
	/**
	*到QPlus验证是否登录成功
	*@param string $app_openid
	*@param string $app_openkey
	*/
	public function checkLogin($app_openid,$app_openkey)
	{
		$params = array();
		$params["app_openid"] = $app_openid;
		$params["app_openkey"] = $app_openkey;
		$result = $this->makeRequest("app_verify",$params);
		return json_decode($result);
	}
	
	/**
	*到QPlus获取用户信息
	*@param string $app_openid
	*@param string $app_openkey
	*/
	public function getUserInfo($app_openid,$app_openkey)
	{
		$params = array();
		$params["app_openid"] = $app_openid;
		$params["app_openkey"] = $app_openkey;
		$result = $this->makeRequest("app_get_userinfo",$params);
		preg_match("/\"nick\":\"([^\"]*)\"/i",$result, $matches);
		$result = json_decode(preg_replace("/\"nick\":\"([^\"]*)\"/i" , "\"nick\":\"\"",$result));
		$result->info->nick = $matches[1];
		return $result;
	}
	
	/**
	*验证从qplus跳转过来的信息是否正确
	*@param array $app_openid
	*/
	public function checkSig($params)
	{
		$result = "";
		if(empty($params))
			$params = $_GET;
		$sig = $params["sig"];
		unset($params["sig"]);
		ksort($params);
		$result =  http_build_query($params);		
		return $sig == strtoupper(hash_hmac("sha1" ,  $result  , $this->app_secret . "&"));
	}
}
?>
