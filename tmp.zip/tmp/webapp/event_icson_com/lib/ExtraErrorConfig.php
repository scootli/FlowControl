<?php

class ExtraErrorConfig extends ErrorConfig {
	
	protected static $codes = array(
		'default' => array(
			'unexpected_request' => 1001,
			'user_not_found' => 1002,
			'invalid_time' => 1003,
			'over_freq_limit' => 1004,
			'verify_config_not_found' => 1005,
			'server_error' => 1006,
			'no_login_user' => 1007,
			'unknown_error' => 1008,
			'invalid_parameter' => 1009,
			'verify_code_error' => 1010,
			'unexpected_config' => 1011
		),
		'CouponAction' => array(
			'invalid_source' => 1100,
			'over_count_limit' => 1101,
			'coupon_conflict' => 1102,
			'coupon_out' => 1103,
			'fetch_failed' => 1104,
			'duplicate_order_id' => 1105,
			'version_not_match' => 1106,
			'over_term_limit' => 1107,
			'over_total_limit' => 1108,
			'over_vip_count' => 1109,
			'config_error' => 1110,
			'counter_error' => 1111,
			'too_many_request' => 1112,
			'over_day_limit' => 1113,
			'over_user_total_limit' => 1114,
			'over_user_day_limit' => 1115
		),
		'SMSAction' => array(
			'over_count_limit' => 1200,
			'send_msg_failed' => 1201,
			'record_sms_info_failed' => 1202
		),
		'VoteAction' => array(
			'over_total_num_limit' => 1300,
			'over_day_num_limit' => 1301,
			'vote_failed' => 1302,
			'vote_point_failed' => 1303
		),
		'SignAction' => array(
			'over_count_limit' => 1400,
		),
	);
	
	public static function getErrorCode($key, $className = '') {
		$key = strtolower($key);
		$className = $className ?: self::getClassName();
		if(isset(self::$codes[$className]) && isset(self::$codes[$className][$key])) {
			// ������ר�ô�����
			return self::$codes[$className][$key];
		} else {
			if(isset(self::$codes['default'][$key])) {
				// ���ô�����
				return self::$codes['default'][$key];
			} else {
				// δ����
				return parent::getErrorCode($key);
			}
		}
	}
}