<?php
/**
 * 
 * ˢ�����������
 * @author rongxu
 *
 */
class Mbpos {
	
	private $db = null;
	private $dbConfig = 'icson_event';
	private $table = 't_event_mbpost';
	
	public function __construct() {
		$this->db = Config::getDB($this->dbConfig);
	}
	
	public function isJoin($uid) {
		$sql = "SELECT count(*) as count FROM " . $this->table . " WHERE `uid` = '$uid'";
		$rst = $this->db->getRows($sql);
		$count = intval($rst[0]['count']);
		return $count;
	}
	
	public function isLimit($dateStart, $dateEnd) {
		$sql = "SELECT count(*) as count FROM " . $this->table . " WHERE `create_time` > '$dateStart' AND `create_time` < '$dateEnd'";
		$rst = $this->db->getRows($sql);
		$count = intval($rst[0]['count']);
		return $count;
	}
	
	public function getSuccess($data) {
		$rst = $this->db->insert($this->table, $data);
		return $rst;
	}
}