<?php
$ActCouponConf = array(
		'20037' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lenovo',
				'discount_class'=>'f4000_40',
				'desc' => '������ThinkPad',
				'link' => 'http://s.yixun.com/--------.html?q=%C1%AA%CF%EB'
				),
		'20039' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'acer',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_acer',
				'discount_class'=>'f3000_50',
				'link' => 'http://s.yixun.com/--------.html?q=acer'
				),
		'20038' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'΢��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microsoft',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/55--6-10-20-0-1--.html?q=%CE%A2%C8%ED'
				),
		'20041' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_viewsonic',
				'discount_class'=>'f500_10',
				'link' => 'http://s.yixun.com/--------.html?q=%D3%C5%C5%C9'
				),
		'20042' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sharp',
				'discount_class'=>'f2000_30',
				'link' => 'http://s.yixun.com/--------.html?q=%CF%C4%C6%D5'
				),
		'20043' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_shell',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%C7%C5%C6'
				),				
		'20044' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_samsung',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C8%FD%D0%C7'
				),
		'20045' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hitachi',
				'discount_class'=>'f3000_100',
				'link' => 'http://s.yixun.com/--------.html?q=%C8%D5%C1%A2'
				),
		'20046' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'MOTO',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_moto',
				'discount_class'=>'f2000_50',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%CD%D0%C2%DE%C0%AD'
				),
		'20047' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ľ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sunwood',
				'discount_class'=>'f100_20',
				'link' => 'http://list.yixun.com/866--8-1-16-0-1-5105e21920-.html'
				),
		'20048' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ţ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_gongniudianqi',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/135-0-6-10-20-0-1-3502e11513-.html'
				),
		'20049' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_kemi',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%C6%C3%DC'
				),
		'20050' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��֮��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_gezhige',
				'discount_class'=>'f150_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B8%F1%D6%AE%B8%F1'
				),
		'20051' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_midea',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C3%C0%B5%C4'
				),
		'20052' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_coolermaster',
				'discount_class'=>'f500_30',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%E1%C0%E4%D6%C1%D7%F0+'
				),
		'20053' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'3M',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_3m',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/--------.html?q=3M'
				)
				);