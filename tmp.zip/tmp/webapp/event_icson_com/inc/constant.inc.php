<?php
$mod_list = array(
   "lottery",
   "coupon",
   "zuan",
   "microsale", 
   "iphones",
   "lotteryge",
   "ipad",
   "first",
   "event",
   "mbpos",
   "qplus",
   "compcomment",
   "compinformation",
   "comprank",
   "compcountdown", //Added by Edison tsai on 11:25 2012/07/12 for allow countdown plugin
   "dispatch",
   "store",
	'verify',
	'appoint',
	'history',
	'product',
	'component',
   'rewardm'
);
