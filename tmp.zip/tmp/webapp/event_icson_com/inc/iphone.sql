CREATE TABLE IF NOT EXISTS `t_event_iphone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `icson_id` varchar(50) COLLATE latin1_bin  NOT NULL DEFAULT '' COMMENT '用户名',
  `number` int(11) NOT NULL DEFAULT '0' COMMENT '抽奖号',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '获取时间',
  `is_win` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否中奖',
  `win_time` int(11) NOT NULL DEFAULT '0' COMMENT '中奖时间',
  `from` int(11) NOT NULL DEFAULT '0' COMMENT '1来自活动，2来自会员，3来自绑定微博，4来自邀请',
  `from_uid` int(11) NOT NULL DEFAULT '0' COMMENT '邀请的朋友uid',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin COMMENT='抽奖号码表' AUTO_INCREMENT=1 