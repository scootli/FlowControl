<?php
$ActCouponConf = array(
		'703' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'�ָ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_loctek',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C0%D6%B8%E8'
				),
		'660' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�װ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_rapoo',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C0%D7%B0%D8'
				),
		'719' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hitachi',
				'discount_class'=>'f3000_100',
				'link' => 'http://s.yixun.com/--------.html?q=%C8%D5%C1%A2'
				),
		'746' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ʿ����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_victorinox',
				'discount_class'=>'f300_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C8%F0%CA%BF'
				),
		'692' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ʿ����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_victorinox',
				'discount_class'=>'f150_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C8%F0%CA%BF'
				),
		'676' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_mobil',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C3%C0%E6%DA'
				),				
		'701' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ħ��ʿ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_momax',
				'discount_class'=>'f50_5',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%C3%D7%CA%BF'
				),
		'766' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ħ��ʿ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_momax',
				'discount_class'=>'f100_10', 
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%C3%D7%CA%BF'
				),
		'707' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���ߵ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_mobi-garden',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%C1%B8%DF%B5%D1%A1%A1'
				),
		'668' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ŧ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_newsmy',
				'discount_class'=>'f300_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C5%A6%C2%FC'
				),
		'714' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sharp',
				'discount_class'=>'f2000_30',
				'link' => 'http://s.yixun.com/--------.html?q=%CF%C4%C6%D5'
				),
		'713' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_viewsonic',
				'discount_class'=>'f500_10',
				'link' => 'http://s.yixun.com/--------.html?q=%D3%C5%C5%C9'
				),
		'681' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'̨ʽ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_taishiji',
				'discount_class'=>'f5000_50',
				'link' => 'http://list.yixun.com/597--------.html'
				),
		'751' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_print-rite',
				'discount_class'=>'f150_10',
				'link' => 'http://s.yixun.com/--------.html?q=%CC%EC%CD%FE'
				),
		'721' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ľ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sunwood',
				'discount_class'=>'f100_20',
				'link' => 'http://list.yixun.com/866--8-1-16-0-1-5105e21920-.html'
				),
		'717' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_samsung',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C8%FD%D0%C7'
				),
		'732' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ʮ����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_shibazizuo',
				'discount_class'=>'f100_20',    
				'link' => 'http://s.yixun.com/--------.html?q=%CA%AE%B0%CB%D7%D3%A1%A1'
				),
		'718' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'˹����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swatch',
				'discount_class'=>'f1000_50',
				'link' => 'http://s.yixun.com/--------.html?q=%CB%B9%CE%D6%E7%F7'
				),
		'670' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'˹����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swatch',
				'discount_class'=>'f500_20', 
				'link' => 'http://s.yixun.com/--------.html?q=%CB%B9%CE%D6%E7%F7'
				),
		'759' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�°���',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_nb',
				'discount_class'=>'f500_50',
				'link' => 'http://s.yixun.com/--------.html?q=%D0%C2%B0%D9%C2%D7%A1%A1'
				),
		'715' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�°���',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_nb',
				'discount_class'=>'f300_20',
				'link' => 'http://s.yixun.com/--------.html?q=%D0%C2%B0%D9%C2%D7%A1%A1'
				),
		'673' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�ֵ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_brother',
				'discount_class'=>'f1000_20', 
				'link' => 'http://s.yixun.com/826--6-10-20-0-1--.html?q=%D0%D6%B5%DC'
				),
		'689' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'һ���',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_yitiji',
				'discount_class'=>'f20',
				'link' => 'http://s.yixun.com/--------.html?q=%D2%BB%CC%E5%BB%FA'
				),
		'675' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_yidun',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%D2%E6%B6%DC'
				),
		'699' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ϯ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_jilin',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%CF%AF%C1%D5'
				),
		'698' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ŵ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_carsino',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%A8%C5%B5'
				),
		'755' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_aurora',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=%D5%F0%B5%A9'
				),
		'662' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�о�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microtek',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/--------.html?q=%D6%D0%BE%A7'
				));