<?php
$ActCouponConf = array(
		'10055' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sharp',
				'discount_class'=>'f2000_30',
				'link' => 'http://s.yixun.com/--------.html?q=%CF%C4%C6%D5'
				),
		'10056' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_mk',
				'discount_class'=>'f150_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C2%F3%C0%A4'
				),
		'10057' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ʒʤ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_pisen',
				'discount_class'=>'f50_5',
				'link' => 'http://list.yixun.com/308-0-6-10-20-0-1-1550e15428-.html'
				),
		'10058' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ʒʤ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_pisen',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/308-0-6-10-20-0-1-1550e15428-.html'
				),
		'10059' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_print-rite',
				'discount_class'=>'f150_10',
				'link' => 'http://s.yixun.com/--------.html?q=%CC%EC%CD%FE'
				),
		'10060' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ʮ����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_shibazizuo',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=%CA%AE%B0%CB%D7%D3%A1%A1'
				),
		'10061' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_comix',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C6%EB%D0%C4'
				),
		'10062' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��Ҷԭ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_choserl',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/135-0-6-10-20-0-1-3502e11719-.html'
				),
		'10063' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ȫ��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_enjoysecurity',
				'discount_class'=>'f1000_150',
				'link' => 'http://s.yixun.com/1304--6-10-20-0-1--.html?q=%C8%AB%C4%DC'
				),
		'10064' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'̨ʽ��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_taishiji',
				'desc'=>'���ڵ���̨ʽ��',
				'discount_class'=>'f5000_50',
				'link' => 'http://list.yixun.com/597--------.html'
				),
		'10065' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��������',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_coolermaster',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%E1%C0%E4%D6%C1%D7%F0+'
				),
		'10066' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��������',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_coolermaster',
				'discount_class'=>'f500_30',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%E1%C0%E4%D6%C1%D7%F0+'
				),
		'10067' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ľ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sunwood',
				'discount_class'=>'f100_20',
				'link' => 'http://list.yixun.com/866--8-1-16-0-1-5105e21920-.html'
				),
		'10068' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_samsung',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C8%FD%D0%C7'
				),
		'10069' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ͯľ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_astroboy',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%A2%CD%AF%C4%BE'
				),
		'10070' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���Ƽ�',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_akg',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%AE%BF%C6%BC%BC'
				),
		'10071' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���Ƽ� ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_akg',
				'discount_class'=>'f1000_80',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%AE%BF%C6%BC%BC'
				),
		'10072' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'������',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_epson',
				'discount_class'=>'f1000_50',
				'link' => 'http://s.yixun.com/665--6-10-20-0-1--.html?q=%B0%AE%C6%D5%C9%FA'
				),
		'10073' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��Ħ��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_anmoyi',
				'discount_class'=>'f5000_300',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%B4%C4%A6%D2%CE'
				),
		'10074' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�ͷ���',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_buffalo',
				'desc'=>'������洢��·����������',
				'discount_class'=>'f300_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%CD%B7%A8%C2%E7'
				),
				);