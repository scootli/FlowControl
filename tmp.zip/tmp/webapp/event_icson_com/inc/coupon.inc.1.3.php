<?php
$ActCouponConf = array(
		'750' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'��ͯľ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_astroboy',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%A2%CD%AF%C4%BE'
				),
		'677' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���Ƽ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_akg',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%AE%BF%C6%BC%BC'
				),
		'700' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���Ƽ� ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_akg',
				'discount_class'=>'f1000_80',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%AE%BF%C6%BC%BC'
				),
		'674' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_epson',
				'discount_class'=>'f1000_50',
				'link' => 'http://s.yixun.com/665--6-10-20-0-1--.html?q=%B0%AE%C6%D5%C9%FA'
				),
		'725' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��Ħ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_anmoyi',
				'discount_class'=>'f5000_300',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%B4%C4%A6%D2%CE'
				),
		'666' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�ͷ���',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_buffalo',
				'desc'=>'������洢  ·���� ����',
				'discount_class'=>'f300_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%CD%B7%A8%C2%E7'
				),				
		'705' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_paiter',
				'discount_class'=>'f100_10',
				'link' => 'http://act.yixun.com/promo-2534.html'
				),
		'702' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_belkin',
				'desc'=>'��������·����',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B1%B4%B6%FB%BD%F0'
				),
		'694' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_bosch',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B2%A9%CA%C0'
				),
		'708' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����ҷ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_beyond',
				'discount_class'=>'f488_50',
				'link' => 'http://s.yixun.com/--------.html?q=%B2%A9%D1%F3%A1%A1'
				),
		'747' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����ҷ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_beyond',
				'discount_class'=>'f888_100',
				'link' => 'http://s.yixun.com/--------.html?q=%B2%A9%D1%F3%A1%A1'
				),
		'735' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sid',
				'discount_class'=>'f100_10',
				'link' => 'http://act.yixun.com/promo-2511.html '
				),
		'763' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_fram',
				'discount_class'=>'f150_30',
				'link' => 'http://s.yixun.com/--------.html?q=%B7%BD%C5%C6'
				),
		'744' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_founder',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B7%BD%D5%FD'
				),
		'724' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��֮��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_gezhige',
				'discount_class'=>'f150_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B8%F1%D6%AE%B8%F1'
				),
		'722' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ţ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_gongniudianqi',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/135-0-6-10-20-0-1-3502e11513-.html'
				),
		'753' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_turtle',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B9%EA%C5%C6'
				),
		'687' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hp',
				'discount_class'=>'f4000_20',
				'link' => 'http://s.yixun.com/--------.html?q=hp'
				),
		'695' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����Τ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_honeywell',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%BB%F4%C4%E1%CE%A4%B6%FB'
				),
		'658' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_canon',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BC%D1%C4%DC'
				),
		'693' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ʵ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_gastrol',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BC%CE%CA%B5%B6%E0'
				),
		'756' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_carsino',
				'discount_class'=>'f2000_50',
				'link' => 'http://s.yixun.com/--------.html?q=%BE%AB%B9%A4'
				),
		'723' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_kemi',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%C6%C3%DC'
				),
		'716' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_shell',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%C7%C5%C6'
				),
		'665' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_coolermaster',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%E1%C0%E4%D6%C1%D7%F0+'
				),
		'728' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_coolermaster',
				'discount_class'=>'f500_30',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%E1%C0%E4%D6%C1%D7%F0+'
				),
		'727' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ɯ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_langsha',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C0%CB%C9%AF%A1%A1'
				),
		'661' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ɯ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_langsha',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C0%CB%C9%AF%A1%A1'
				));