<?php
$ActCouponConf = array(
		'10075' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_paiter',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%D9%CC%D8'
				),
		'10076' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'������',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_belkin',
				'desc'=>'������������·����',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B1%B4%B6%FB%BD%F0'
				),
		'10077' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ħ��ʿ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_momax',
				'discount_class'=>'f50_5',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%C3%D7%CA%BF'
				),
		'10078' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ħ��ʿ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_momax',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%C3%D7%CA%BF'
				),
		'10079' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_mobil',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C3%C0%E6%DA'
				),
		'10080' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sid',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B3%AC%C8%CB'
				),
		'10081' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hitachi',
				'discount_class'=>'f3000_100',
				'link' => 'http://s.yixun.com/--------.html?q=%C8%D5%C1%A2'
				),
		'10082' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_founder',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B7%BD%D5%FD'
				),
		'10083' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��֮��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_gezhige',
				'discount_class'=>'f150_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B8%F1%D6%AE%B8%F1'
				),
		'10084' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ţ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_gongniudianqi',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/135-0-6-10-20-0-1-3502e11513-.html'
				),
		'10085' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_turtle',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B9%EA%C5%C6'
				),
		'10086' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hp',
				'discount_class'=>'f4000_20',
				'link' => 'http://s.yixun.com/--------.html?q=hp'
				),
		'10087' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����Τ��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_honeywell',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%BB%F4%C4%E1%CE%A4%B6%FB'
				),
		'10088' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_canon',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BC%D1%C4%DC'
				),
		'10089' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ʵ��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_gastrol',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BC%CE%CA%B5%B6%E0'
				),
		'10090' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ŧ�� ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_newsmy',
				'discount_class'=>'f300_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C5%A6%C2%FC'
				),
		'10091' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���� ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_carsino',
				'discount_class'=>'f2000_50',
				'link' => 'http://s.yixun.com/--------.html?q=%BE%AB%B9%A4'
				),
		'10092' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�װ�',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_rapoo',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C0%D7%B0%D8'
				),
		'10093' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_kemi',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%C6%C3%DC'
				)
				);