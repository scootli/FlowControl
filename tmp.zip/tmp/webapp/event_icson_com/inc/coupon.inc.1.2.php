<?php
$ActCouponConf = array(
		'685' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'ŵ����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_nokia',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C5%B5%BB%F9%D1%C7'
				),
		'672' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'SWISSWIN',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swisswin',
				'discount_class'=>'f100_10 ',
				'link' => 'http://list.yixun.com/398-0-6-10-20-0-1-3510e24404-.html'
				),
		'691' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'SWISSWIN',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swisswin',
				'discount_class'=>'f200_15',
				'link' => 'http://list.yixun.com/398-0-6-10-20-0-1-3510e24404-.html'
				),
		'757' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Targus',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_targus',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%CC%A9%B8%F1%CB%B9'
				),
		'656' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'TCL',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_tcl',
				'discount_class'=>'f1499_50',
				'link' => 'http://list.yixun.com/386-0-6-10-20-0-1-1977e9736-.html'
				),
		'696' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'TCL',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_tcl',
				'discount_class'=>'f4999_200',
				'link' => 'http://list.yixun.com/386-0-6-10-20-0-1-1977e9736-.html'
				),				
		'729' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'TCL',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_tcl',
				'discount_class'=>'f2999_100',
				'link' => 'http://list.yixun.com/386-0-6-10-20-0-1-1977e9736-.html'
				),
		'740' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'TCL',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_tcl',
				'discount_class'=>'f1999_80',
				'link' => 'http://list.yixun.com/386-0-6-10-20-0-1-1977e9736-.html'
				),
		'657' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_midea',
				'discount_class'=>'f100_8',
				'link' => 'http://s.yixun.com/--------.html?q=%C3%C0%B5%C4'
				),
		'726' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_midea',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C3%C0%B5%C4'
				),
		'669' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'¶��Ũ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_revlon',
				'discount_class'=>'f150_25',
				'link' => 'http://act.yixun.com/promo-2510.html'
				),
		'738' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_luolai',
				'discount_class'=>'f888_100',
				'link' => 'http://s.yixun.com/--------.html?q=%C2%DE%C0%B3%A1%A1'
				),
		'748' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_luolai',
				'discount_class'=>'f488_50',
				'link' => 'http://s.yixun.com/--------.html?q=%C2%DE%C0%B3%A1%A1'
				),
		'758' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_mk',
				'discount_class'=>'f150_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C2%F3%C0%A4'
				),
		'704' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ʒʤ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_pisen',
				'discount_class'=>'f50_5',
				'link' => 'http://list.yixun.com/308-0-6-10-20-0-1-1550e15428-.html'
				),
		'764' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ʒʤ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_pisen',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/308-0-6-10-20-0-1-1550e15428-.html'
				),
		'736' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lyceem',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C0%B6%B3%C8'
				),
		'767' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lyceem',
				'discount_class'=>'f200_40',
				'link' => 'http://s.yixun.com/--------.html?q=%C0%B6%B3%C8'
				),
		'768' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_grace',
				'discount_class'=>'f50_3',
				'link' => 'http://s.yixun.com/--------.html?q=%BD%E0%C0%F6%D1%C5'
				),
		'762' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_grace',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%BD%E0%C0%F6%D1%C5'
				),
		'752' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_comix',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C6%EB%D0%C4'
				),
		'679' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��Ҷԭ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_choserl',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/135-0-6-10-20-0-1-3502e11719-.html'
				),
		'678' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ȫ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_enjoysecurity',
				'discount_class'=>'f1000_150',
				'link' => 'http://s.yixun.com/1304--6-10-20-0-1--.html?q=%C8%AB%C4%DC'
				),
		'737' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'wenger����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swissgear',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%CD%FE%B8%EA'
				),
		'765' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'wenger����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swissgear',
				'discount_class'=>'f200_15',
				'link' => 'http://s.yixun.com/--------.html?q=%CD%FE%B8%EA'
				),
		'680' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Zippo',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_zippo',
				'discount_class'=>'f300_40',
				'link' => 'http://s.yixun.com/--------.html?q=Zippo%A1%A1'
				),
		'709' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Zippo',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_zippo',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=Zippo%A1%A1'
				),
		'749' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Zippo',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_zippo',
				'discount_class'=>'f120_10',
				'link' => 'http://s.yixun.com/--------.html?q=Zippo%A1%A1'
				));