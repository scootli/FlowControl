<?php
$BrandEntranceLink = "http://act.yixun.com/promo-2652.html";
$ActCouponConf = array(
		'20001' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'MOTO',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_moto',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%CD%D0%C2%DE%C0%AD'
				),
		'20002' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'hTC',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_htc',
				'discount_class'=>'f2000_50',
				'link' => 'http://s.yixun.com/--------.html?q=hTC'
				),
		'20003' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_midea',
				'discount_class'=>'f100_8',
				'link' => 'http://s.yixun.com/--------.html?q=%C3%C0%B5%C4'
				),
		'20004' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_canon',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BC%D1%C4%DC'
				),
		'20005' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ThinkPad',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_thinkpad',
				'discount_class'=>'f5000_50',
				'link' => 'http://list.yixun.com/234-0-6-10-20-0-1-1360e3694-.html'
				),
		'20006' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�װ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_rapoo',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C0%D7%B0%D8'
				),				
		'20007' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'LG',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lg',
				'desc'=>'��ϴ�»�',
				'discount_class'=>'f2000_30',
				'link' => 'http://s.yixun.com/--------.html?q=LG'
				),
		'20008' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��˶',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_asus',
				'discount_class'=>'f4000_50',
				'link' => 'http://list.yixun.com/234-0-6-10-20-0-1-1360e3686-.html'
				),
		'20009' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_coolermaster',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%E1%C0%E4%D6%C1%D7%F0+'
				),
		'20010' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�ͷ���',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_buffalo',
				'desc'=>'������洢 ·����  ����',
				'discount_class'=>'f300_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%CD%B7%A8%C2%E7'
				),
		'20011' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sony',
				'discount_class'=>'f100_5',
				'desc' => '����������',
				'link' => 'http://s.yixun.com/--------.html?q=%CB%F7%C4%E1'
				),
		'20012' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'¶��Ũ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_revlon',
				'discount_class'=>'f150_25',
				'link' => 'http://act.yixun.com/promo-2675.html'
				),
		'20013' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'SWISSWIN',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swisswin',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/398-0-6-10-20-0-1-3510e24404-.html'
				),
		'20014' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�ֵ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_brother',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/826--6-10-20-0-1--.html?q=%D0%D6%B5%DC'
				),
		'20015' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_epson',
				'discount_class'=>'f1000_50',
				'link' => 'http://s.yixun.com/824--6-10-20-0-1--.html?q=%B0%AE%C6%D5%C9%FA'
				),
		'20016' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_mobil',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C3%C0%E6%DA'
				),
		'20017' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���Ƽ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_akg',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%AE%BF%C6%BC%BC'
				),
		'20018' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ȫ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_enjoysecurity',
				'discount_class'=>'f1000_150',
				'link' => 'http://s.yixun.com/1304--6-10-20-0-1--.html?q=%C8%AB%C4%DC'
				),
		'20019' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��Ҷԭ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_choserl',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/135-0-6-10-20-0-1-3502e11719-.html'
				),
		'20020' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'̨ʽ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_taishiji',
				'discount_class'=>'f5000_50',
				'link' => 'http://list.yixun.com/597--------.html'
				));