<?php
$couponLimit = array(
				1 => array(
										'name' => 'pengyou', 
										'key' => '12@Dw$9dg', 
										'ip' => array('192.168.0.1', '192.168.0.2'), 
										'start_time' => '2012-03-21', 
										'ent_time' => '2013-04-21',
										'desc' => '������'
				),
				2 => array(
										'name' => 'pengyou', 
										'key' => '12@Dw$9dg', 
										'ip' => array('192.168.0.1', '192.168.0.2'), 
										'start_time' => '2012-03-21', 
										'ent_time' => '2013-04-21',
										'desc' => '������'
				),
				3 => array(
										'name' => 'pengyou', 
										'key' => '12@Dw$9dg', 
										'ip' => array('192.168.0.1', '192.168.0.2'), 
										'start_time' => '2012-03-21', 
										'ent_time' => '2013-04-21',
										'desc' => '������'
				),
				4 => array(
										'name' => 'qzone', 
										'key' => '12@Dw$9dg', 
										'ip' => array('192.168.0.1', '192.168.0.2'), 
										'start_time' => '2012-03-21', 
										'ent_time' => '2013-04-21',
										'desc' => 'qzone'
				),
				5 => array(
										'name' => 'qzone', 
										'key' => '12@Dw$9dg', 
										'ip' => array('192.168.0.1', '192.168.0.2'), 
										'start_time' => '2012-03-21', 
										'ent_time' => '2013-04-21',
										'desc' => 'qzone'
				),
			);