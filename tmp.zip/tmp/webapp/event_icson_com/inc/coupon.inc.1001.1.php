<?php
$BrandEntranceLink = "http://act.yixun.com/promo-2658.html";
$ActCouponConf = array(
		'10016' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'hTC',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_htc',
				'discount_class'=>'f2000_50',
				'link' => 'http://s.yixun.com/--------.html?q=hTC'
				),
		'10017' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'hTC',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_htc',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=hTC'
				),
		'10018' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'hTC',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_htc',
				'discount_class'=>'f3000_80',
				'link' => 'http://s.yixun.com/--------.html?q=hTC'
				),
		'10019' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_bosch',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B2%A9%CA%C0'
				),
		'10020' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'MOTO',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_moto',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%CD%D0%C2%DE%C0%AD'
				),
		'10021' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'MOTO',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_moto',
				'discount_class'=>'f2000_50',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%CD%D0%C2%DE%C0%AD'
				),
		'10022' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ThinkPad',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_thinkpad',
				'discount_class'=>'f5000_50',
				'link' => 'http://s.yixun.com/234--6-10-20-0-1--.html?q=ThinkPad'
				),
		'10023' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ThinkPad',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_thinkpad',
				'discount_class'=>'f10000_100',
				'link' => 'http://s.yixun.com/234--6-10-20-0-1--.html?q=ThinkPad'
				),
		'10024' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��˶',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_asus',
				'discount_class'=>'f4000_50',
				'link' => 'http://s.yixun.com/--------.html?q=%BB%AA%CB%B6'
				),
		'10025' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lenovo',
				'desc' => '������ThinkPad',
				'discount_class'=>'f3000_30',
				'link' => 'http://s.yixun.com/--------.html?q=%C1%AA%CF%EB'
				),
		'10026' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'desc' => '������ThinkPad',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lenovo',
				'discount_class'=>'f4000_40',
				'link' => 'http://s.yixun.com/--------.html?q=%C1%AA%CF%EB'
				),
		'10027' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'desc' => '������ThinkPad',
				'brand_class'=>'logo_lenovo',
				'discount_class'=>'f5000_50',
				'link' => 'http://s.yixun.com/--------.html?q=%C1%AA%CF%EB'
				),
		'10028' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'wenger����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swissgear',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%CD%FE%B8%EA'
				),
		'10029' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'wenger����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swissgear',
				'discount_class'=>'f200_15',
				'link' => 'http://s.yixun.com/--------.html?q=%CD%FE%B8%EA'
				),
		'10030' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'΢��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microsoft',
				'discount_class'=>'f100_5',
				'link' => 'http://s.yixun.com/55--6-10-20-0-1--.html?q=%CE%A2%C8%ED'
				),
		'10031' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'΢��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microsoft',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/55--6-10-20-0-1--.html?q=%CE%A2%C8%ED'
				),
		'10032' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'΢��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microsoft',
				'discount_class'=>'f800_50',
				'link' => 'http://s.yixun.com/55--6-10-20-0-1--.html?q=%CE%A2%C8%ED'
				),
		'10033' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Zippo',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_zippo',
				'discount_class'=>'f300_40',
				'link' => 'http://s.yixun.com/--------.html?q=Zippo%A1%A1'
				),
		'10034' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Zippo',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_zippo',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=Zippo%A1%A1'
				),
		'10035' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Zippo',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_zippo',
				'discount_class'=>'f120_10',
				'link' => 'http://s.yixun.com/--------.html?q=Zippo%A1%A1'
				)
				);