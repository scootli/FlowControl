<?php
$ActCouponConf = array(
		'20021' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'hTC',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_htc',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=hTC'
				),
		'20022' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'΢��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microsoft',
				'discount_class'=>'f100_5',
				'link' => 'http://s.yixun.com/55--6-10-20-0-1--.html?q=%CE%A2%C8%ED'
				),
		'20023' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ŵ����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_nokia',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C5%B5%BB%F9%D1%C7'
				),
		'20024' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lenovo',
				'desc'=>'������ThinkPad',
				'discount_class'=>'f3000_30',
				'link' => 'http://s.yixun.com/--------.html?q=%C1%AA%CF%EB'
				),
		'20025' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hp',
				'discount_class'=>'f4000_20',
				'link' => 'http://s.yixun.com/--------.html?q=hp'
				),
		'20026' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'deli',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_deli',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=deli'
				),				
		'20027' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'һ���',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_yitiji',
				'desc'=>'���ڵ���һ���',
				'discount_class'=>'f20',
				'link' => 'http://s.yixun.com/--------.html?q=%D2%BB%CC%E5%BB%FA'
				),
		'20028' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'SWISSWIN',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swisswin',
				'discount_class'=>'f200_15',
				'link' => 'http://list.yixun.com/398-0-6-10-20-0-1-3510e24404-.html'
				),
		'20029' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ʵ��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_gastrol',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BC%CE%CA%B5%B6%E0'
				),
		'20030' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_bosch',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B2%A9%CA%C0'
				),
		'20031' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'TYPE-R',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_type-r',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/-0-6-10-20-0-2--.html?q=TYPE-R#list'
				),
		'20032' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ThinkPad',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_thinkpad',
				'discount_class'=>'f10000_100',
				'link' => 'http://list.yixun.com/234-0-6-10-20-0-1-1360e3694-.html'
				),
		'20033' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���Ƽ�',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_akg',
				'discount_class'=>'f1000_80',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%AE%BF%C6%BC%BC'
				),
		'20034' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ħ��ʿ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_momax',
				'discount_class'=>'f50_5',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%C3%D7%CA%BF'
				),
		'20035' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ʒʤ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_pisen',
				'discount_class'=>'f50_5',
				'link' => 'http://list.yixun.com/308-0-6-10-20-0-1-1550e15428-.html'
				),
		'20036' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_paiter',
				'discount_class'=>'f100_10',
				'link' => 'http://act.yixun.com/promo-2663.html'
				)
				);