<?php
$ActCouponConf = array(
		'10036' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'�о�',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microtek',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/--------.html?q=%D6%D0%BE%A7'
				),
		'10037' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'3M',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_3m',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/--------.html?q=3M'
				),
		'10038' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'acer',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_acer',
				'discount_class'=>'f3000_50',
				'link' => 'http://s.yixun.com/--------.html?q=acer'
				),
		'10039' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'acer',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_acer',
				'discount_class'=>'f4000_100',
				'link' => 'http://s.yixun.com/--------.html?q=acer'
				),
		'10040' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'deli',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_deli',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=deli'
				),
		'10041' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Double A',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_doublea',
				'discount_class'=>'f100_5',
				'link' => 'http://s.yixun.com/--------.html?q=DOUBLE+A'
				),
		'10042' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'NEC',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_nec',
				'discount_class'=>'f1000_50',
				'link' => 'http://s.yixun.com/--------.html?q=NEC'
				),
		'10094' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_shell',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%BF%C7%C5%C6'
				),
		'10043' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ŵ����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_nokia',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C5%B5%BB%F9%D1%C7'
				),
		'10044' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'SWISSWIN',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swisswin',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/398-0-6-10-20-0-1-3510e24404-.html'
				),
		'10045' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'SWISSWIN',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_swisswin',
				'discount_class'=>'f200_15',
				'link' => 'http://list.yixun.com/398-0-6-10-20-0-1-3510e24404-.html'
				),
		'10046' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Targus',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_targus',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%CC%A9%B8%F1%CB%B9'
				),
		'10047' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'һ���',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_yitiji',
				'desc'=>'���ڵ���һ���',
				'discount_class'=>'f20',
				'link' => 'http://s.yixun.com/--------.html?q=%D2%BB%CC%E5%BB%FA'
				),
		'10048' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'���',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_yidun',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%D2%E6%B6%DC'
				),
		'10049' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_viewsonic',
				'discount_class'=>'f500_10',
				'link' => 'http://s.yixun.com/--------.html?q=%D3%C5%C5%C9'
				),
		'10050' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_aurora',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=%D5%F0%B5%A9'
				),
		'10051' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_midea',
				'discount_class'=>'f100_8',
				'link' => 'http://s.yixun.com/--------.html?q=%C3%C0%B5%C4'
				),
		'10052' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_midea',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C3%C0%B5%C4'
				),
		'10053' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'¶��Ũ',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_revlon',
				'discount_class'=>'f150_25',
				'link' => 'http://s.yixun.com/--------.html?q=%C2%B6%BB%AA%C5%A8'
				),
		'10054' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'�ֵ�',
				'valid_time_from'=>'2011-10-10',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_brother',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/826--6-10-20-0-1--.html?q=%D0%D6%B5%DC'
				),
				);