f<?php
$ActCouponConf = array(
		'20054' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'΢��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microsoft',
				'discount_class'=>'f800_50',
				'link' => 'http://s.yixun.com/55--6-10-20-0-1--.html?q=%CE%A2%C8%ED'
				),
		'20040' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'acer',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_acer',
				'discount_class'=>'f4000_100',
				'link' => 'http://s.yixun.com/--------.html?q=acer'
				),
		'20055' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sony',
				'discount_class'=>'f1000_20',
				'desc' => '����������',
				'link' => 'http://s.yixun.com/--------.html?q=%CB%F7%C4%E1'
				),
		'20056' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lenovo',
				'desc'=>'������ThinkPad',
				'discount_class'=>'f5000_50',
				'link' => 'http://s.yixun.com/--------.html?q=%C1%AA%CF%EB'
				),
		'20057' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��ͯľ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_astroboy',
				'discount_class'=>'f200_20',
				'link' => 'http://s.yixun.com/--------.html?q=%B0%A2%CD%AF%C4%BE'
				),
		'20058' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_print-rite',
				'discount_class'=>'f150_10',
				'link' => 'http://s.yixun.com/--------.html?q=%CC%EC%CD%FE'
				),				
		'20059' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_comix',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C6%EB%D0%C4'
				),
		'20061' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_turtle',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B9%EA%C5%C6'
				),
		'20062' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'hTC',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_htc',
				'discount_class'=>'f3000_80',
				'link' => 'http://s.yixun.com/--------.html?q=hTC'
				),
		'20063' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_aurora',
				'discount_class'=>'f100_20',
				'link' => 'http://s.yixun.com/--------.html?q=%D5%F0%B5%A9'
				),
		'20064' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Targus',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_targus',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%CC%A9%B8%F1%CB%B9'
				),
		'20065' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_mk',
				'discount_class'=>'f150_20',
				'link' => 'http://s.yixun.com/--------.html?q=%C2%F3%C0%A4'
				),
		'20066' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ʒʤ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_pisen',
				'discount_class'=>'f100_10',
				'link' => 'http://list.yixun.com/308-0-6-10-20-0-1-1550e15428-.html'
				),
		'20067' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Ħ��ʿ',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_momax',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C4%A6%C3%D7%CA%BF'
				),
		'20068' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'������',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_belkin',
				'desc'=>'��������·����',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%B1%B4%B6%FB%BD%F0'
				),
		'20069' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sid',
				'discount_class'=>'f100_10',
				'link' => 'http://act.yixun.com/promo-2673.html'
				)
				);