<?php
$BrandEntranceLink = "http://act.yixun.com/promo-2607.html";
$ActCouponConf = array(
		'655' => array(
				'needEmailVerify' => 0,  //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'needTelVerify' => 0,    //ȡֵ0��1��0������Ҫ��֤��1����Ҫ��֤��
				'userlevel' => array(),//�����û��ĵȼ�����,�������ʾ������
				'brand'=>'hTC',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_htc',
				'discount_class'=>'f2000_50',
				'link' => 'http://s.yixun.com/--------.html?q=hTC'
				),
		'682' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'hTC',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_htc',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=hTC'
				),
		'754' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'hTC',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_htc',
				'discount_class'=>'f3000_80',
				'link' => 'http://s.yixun.com/--------.html?q=hTC'
				),
		'663' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'LG',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lg',
				'desc'=>'��ϴ�»�',
				'discount_class'=>'f2000_30',
				'link' => 'http://s.yixun.com/--------.html?q=LG'
				),
		'654' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'MOTO',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_moto',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=MOTO'
				),
		'720' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'MOTO',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_moto',
				'discount_class'=>'f2000_50',
				'link' => 'http://s.yixun.com/--------.html?q=MOTO'
				),				
		'659' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ThinkPad',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_thinkpad',
				'discount_class'=>'f5000_50',
				'link' => 'http://act.yixun.com/promo-2359.html'
				),
		'697' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'ThinkPad',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_thinkpad',
				'discount_class'=>'f10000_100',
				'link' => 'http://act.yixun.com/promo-2359.html'
				),
		'664' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'��˶',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_asus',
				'discount_class'=>'f4000_50',
				'link' => 'http://act.yixun.com/promo-2200.html'
				),
		'710' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lenovo',
				'desc' => '������ThinkPad',
				'discount_class'=>'f4000_40',
				'link' => 'http://s.yixun.com/--------.html?q=%C1%AA%CF%EB'
				),
		'745' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lenovo',
				'desc' => '������ThinkPad',
				'discount_class'=>'f5000_50',
				'link' => 'http://s.yixun.com/--------.html?q=%C1%AA%CF%EB'
				),
		'686' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_lenovo',
				'desc' => '������ThinkPad',
				'discount_class'=>'f3000_30',
				'link' => 'http://s.yixun.com/--------.html?q=%C1%AA%CF%EB'
				),
		'667' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sony',
				'desc'=>'����������',
				'discount_class'=>'f100_5',
				'link' => 'http://s.yixun.com/--------.html?q=%CB%F7%C4%E1'
				),
		'742' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sony',
				'desc'=>'����������',
				'discount_class'=>'f1000_20',
				'link' => 'http://s.yixun.com/--------.html?q=%CB%F7%C4%E1'
				),
		'684' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'΢��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microsoft',
				'discount_class'=>'f100_5',
				'link' => 'http://s.yixun.com/55--6-10-20-0-1--.html?q=%CE%A2%C8%ED'
				),
		'712' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'΢��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microsoft',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/55--6-10-20-0-1--.html?q=%CE%A2%C8%ED'
				),
		'739' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'΢��',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_microsoft',
				'discount_class'=>'f800_50',
				'link' => 'http://s.yixun.com/55--6-10-20-0-1--.html?q=%CE%A2%C8%ED'
				),
		'671' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hisense',
				'discount_class'=>'f1000_50',
				'link' => '	http://s.yixun.com/--------.html?q=%BA%A3%D0%C5'
				),
		'706' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hisense',
				'discount_class'=>'f5000_200',
				'link' => '	http://s.yixun.com/--------.html?q=%BA%A3%D0%C5'
				),
		'733' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hisense',
				'discount_class'=>'f2000_80',
				'link' => '	http://s.yixun.com/--------.html?q=%BA%A3%D0%C5'
				),
		'760' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'����',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_hisense',
				'discount_class'=>'f3000_100',
				'link' => '	http://s.yixun.com/--------.html?q=%BA%A3%D0%C5'
				),
		'730' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'3M',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-20',
				'brand_class'=>'logo_3m',
				'discount_class'=>'f200_10',
				'link' => 'http://s.yixun.com/--------.html?q=3M'
				),
		'711' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'acer',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_acer',
				'discount_class'=>'f3000_50',
				'link' => '	http://s.yixun.com/--------.html?q=acer'
				),
		'741' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'acer',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_acer',
				'discount_class'=>'f4000_100',
				'link' => '	http://s.yixun.com/--------.html?q=acer'
				),
		'688' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'deli',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_deli',
				'discount_class'=>'f100_20',
				'link' => '	http://s.yixun.com/--------.html?q=deli'
				),
		'731' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'Double A',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_doublea',
				'discount_class'=>'f100_5',
				'link' => '	http://s.yixun.com/--------.html?q=DOUBLE+A'
				),
		'690' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'NEC',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_nec',
				'discount_class'=>'f1000_50',
				'link' => '	http://s.yixun.com/--------.html?q=NEC'
				),
		'761' => array(
				'needEmailVerify' => 0,  
				'needTelVerify' => 0, 
				'userlevel' => array(),
				'brand'=>'SUMDEX',
				'valid_time_from'=>'2011-10-11',
				'valid_time_to'=>'2011-10-31',
				'brand_class'=>'logo_sumdex',
				'discount_class'=>'f100_10',
				'link' => 'http://s.yixun.com/--------.html?q=%C9%AD%CC%A9%CB%B9'
				));