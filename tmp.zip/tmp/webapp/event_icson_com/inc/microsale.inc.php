<?php

require_once (PHPLIB_ROOT . 'api/IMicrosale.class.php');


$microsaleInfos = IMicrosale::getInfoByCache();

$infos = array();

foreach ($microsaleInfos as $microsaleInfo) {
	$pids = str_replace("，", ",", $microsaleInfo['pids']);
	$pids = str_replace(" ", "", $pids);
	$pids = explode(",", $pids);
	if (empty($microsaleInfo['pids'])) {
		$pids = array();
	}
	$infos[$microsaleInfo['date']] = $pids;
}


$eventMicroSale = array(
    'pids' => $infos,
);

