<?php
/**
 * ͶƱ������
 * @author hillperyang
 */
class VoteAction {
	/**
	 * ͶƱ
	 * @param array $component �������
	 */
	public static function vote($component) {
		// ��¼����
		try {
			$uid = IUser::getLoginUid();
			if (empty($uid)) {
				//throw new BaseException(ExtraErrorConfig::getErrorCode('no_login_user'), '�û�δ��¼��');
				$uip = str_replace('.', '', ToolUtil::getClientIP(true));
			}
			
			// Ƶ������
			$limitKey = !empty($uid) ? "uid_{$uid}_cid_{$component['id']}" : "uip_{$uip}_cid_{$component['id']}";
			$ret = IFreqLimit::checkFrequence($limitKey);
			if($ret === false) {
				if(IFreqLimit::$errCode !== ExtraErrorConfig::getErrorCode('cas_not_match', 'IDataCache')) {
					Logger::err(IFreqLimit::$errCode . ' : ' . IFreqLimit::$errMsg);
				}
				throw new BaseException(ExtraErrorConfig::getErrorCode('over_freq_limit'), '����Ƶ�ʹ��ߣ�');
			}
			
			$params = ArrayUtil::array_fetch($_POST, array(
				'vote_point' => array( 'allowEmpty' => false, 'secureType' => 'string' )
			));
			
			if ($params === false) {
				throw new BaseException(ExtraErrorConfig::getErrorCode('unexpected_request'), '�����������');
			}
			
			// ���ʱ������������ֻ��ͶƱһ��
			$ret = ComponentUtil::checkTimeLock($limitKey);
			if ($ret === false) {
				throw new BaseException(ExtraErrorConfig::getErrorCode('over_count_limit'), '������ֻ��ͶƱһ�Σ�');
			}
			
			// ʱ�����
			$now = time();
			if($component['start_time'] > $now || $component['end_time'] < $now) {
				throw new BaseException(ExtraErrorConfig::getErrorCode('invalid_time'), '������Ч�ڣ�');
			}
			
			$vote_params = $component['params'];
			
			// ������֤ BEGIN
			// ��ȡ��֤����
			$verify_params = ComponentUtil::getVerifyParameters($component['id']);
			if($verify_params === false) {
				throw new BaseException(ComponentUtil::$errCode, ComponentUtil::$errMsg);
			}
			
			// �ظ�����֤
			$ret = ComponentUtil::checkVerifyParameters($component['id'], $verify_params);
			if($ret === false) {
				throw new BaseException(ComponentUtil::$errCode, ComponentUtil::$errMsg);
			}
			
			// ���ݼ���
			$ret = IVerifyConfig::verify(ACT_TYPE_COMPONENT, $component['id'], 0, $verify_params);
			if($ret === false) {
				if(IVerifyConfig::$errCode === 0) {
					$failedInfo = IVerifyConfig::getFailedInfo();
					throw new BaseException(5000 + $failedInfo['verify_type'], $failedInfo['err_msg']);
				} else {
					Logger::err('Error ' . IVerifyConfig::$errCode . ' : ' . IVerifyConfig::$errMsg);
					throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
				}
			}
			// ������֤END
			
			// �û�ͶƱ��������
			if (!empty($uid)) {
				$day_num = $vote_params['day_num'];
				$total_num = $vote_params['total_num'];
				
				if (!empty($day_num) || !empty($total_num)) {
					$votes = IEventData::get($uid, IEventData::COMP_TYPE_UNIFY_COMP, $component['id'],  IEventData::DATA_TYPE_VOTE_ID);
					if ($votes === false) {
						Logger::err('Error ' . IEventData::$errCode . ' : ' . IEventData::$errMsg);
						throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
					}
					$user_total_num = count($votes);
					if ($total_num && $user_total_num >= $total_num) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('over_total_num_limit'), '��ͶƱ�����Ѿ����꣡');
					}
					
					if (count($votes)) {
						$user_day_num = 0;
						$todayDate = date('Y-m-d');
						foreach ($votes as $vote) {
							if (substr($vote['create_time'], 0, 10) == $todayDate) $user_day_num++;
						}
						if ($day_num && $user_day_num >= $day_num) {
							throw new BaseException(ExtraErrorConfig::getErrorCode('over_day_num_limit'), '����ͶƱ�����Ѿ����꣡');
						}
					}
				}
				
				//��¼�û�ͶƱ����
				$ret = IEventData::add($uid, IEventData::COMP_TYPE_UNIFY_COMP, $component['id'], IEventData::DATA_TYPE_VOTE_ID, $params['vote_point']);
				if ($ret === false) {
					Logger::err(IEventData::$errCode . ' : ' . IEventData::$errMsg);
					throw new BaseException(ExtraErrorConfig::getErrorCode('vote_failed'), 'ͶƱʧ�ܣ�');
				}
			}
			
			//��¼ͶƱ��ͶƱ����
			$key = 'vote_' . $component['id'] . '_' . $params['vote_point'];
			$ret = IDataCache::getData($key);
			$point_voted_num = empty($ret) ? 0 : $ret;
			$point_voted_num++;
			$ret = IDataCache::setData($key, $point_voted_num);
			if ($ret === false) {
				Logger::err(IDataCache::$errCode . ' : ' . IDataCache::$errMsg);
				throw new BaseException(ExtraErrorConfig::getErrorCode('vote_point_failed'), 'ͶƱʧ�ܣ�');
			}
				
			// ����ʱ����
			ComponentUtil::setTimeLock($limitKey, 2);
			
			return array( 
				'errno' => 0, 
				'data' => array( 
					'vote_num' => $point_voted_num,
					'msg' => 'ͶƱ�ɹ���'
				)
			);
		} catch(BaseException $e) {
			return array(
				'errno' => $e->errCode,
				'errmsg' => $e->errMsg
			);
		}
	}
	
	/**
	 * ��ȡͶƱ����
	 * @param array $component �������
	 */
	public static function get_voted_num($component) {
		try {
			$params = ArrayUtil::array_fetch($_POST, array(
				'point_ids' => array( 'allowEmpty' => false, 'secureType' => 'string' )
			));
			if ($params === false) {
				throw new BaseException(ExtraErrorConfig::getErrorCode('unexpected_request'), '�����������');
			}
			
			$point_id_arr = explode('|', $params['point_ids']);
			foreach ($point_id_arr as $key => $val) {
				$point_id_arr[$key] = 'vote_' . $component['id'] . '_' . $val;
			}
			$ret = IDataCache::getData($point_id_arr);
			if ($ret === false) {
				Logger::err(IDataCache::$errCode . ' : ' . IDataCache::$errMsg);
				throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
			}
			
			$voted_num = array();
			foreach ($ret as $key => $val) {
				$voted_num[str_replace('vote_' . $component['id'] . '_', '', $key)] = empty($val) ? 0 : $val;
			}
			return array( 
				'errno' => 0, 
				'voted_num' => $voted_num
			);
		} catch(BaseException $e) {
			return array(
				'errno' => $e->errCode,
				'errmsg' => $e->errMsg
			);
		}
	}
}