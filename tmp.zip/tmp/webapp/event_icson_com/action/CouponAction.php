<?php
/**
 * �Ż�ȯ������
 * @author smithhuang
 */
class CouponAction {
	
	const CURRENT_VERSION = 1;
	
	const PRIZE_TYPE_COUPON = 1;
	const PRIZE_TYPE_UNIFORM = 2;
	
	const FREQ_LIMIT_TYPE_NONE = 1;
	const FREQ_LIMIT_TYPE_DAY = 2;
	const FREQ_LIMIT_TYPE_HOUR = 3;
	
	const CRITICAL_COUNT = 10;
	
	const ALARM_CONFIG_ERR = 629482;
	
	/**
	 * ��ȡ�Ż�ȯ
	 * @param array $component �������
	 */
	public static function get($component) {
		// ��¼����
		try {
			$uid = IUser::getLoginUid();
			if(empty($uid)) {
				throw new BaseException(ExtraErrorConfig::getErrorCode('no_login_user'), '�û�δ��¼��');
			}
			
			// Ƶ������
			$ret = IFreqLimit::checkFrequence("uid_{$uid}_cid_{$component['id']}");
			if($ret === false) {
				if(IFreqLimit::$errCode !== ExtraErrorConfig::getErrorCode('cas_not_match', 'IDataCache')) {
					Logger::err(IFreqLimit::$errCode . ' : ' . IFreqLimit::$errMsg);
				}
				throw new BaseException(ExtraErrorConfig::getErrorCode('over_freq_limit'), '����Ƶ�ʹ��ߣ�');
			}
			
			// ʱ�����
			$now = time();
			if($component['start_time'] > $now || $component['end_time'] < $now) {
				throw new BaseException(ExtraErrorConfig::getErrorCode('invalid_time'), '������Ч�ڣ�');
			}
			
			$coupon_params = $component['params'];
			
			// ��Դ����
			/*$source_limit = $coupon_params['source_limit'];
			foreach ($source_limit as $s) {
				switch ($s) {
					case 'qq_tips':
						if (isset($_GET['openID']) && isset($_GET['vkey'])) {
							$openId = $_GET['openID'];
							$vkey = $_GET['vkey'];
							$mkey = 'icson@qq';
				
							$skey = substr(md5($openId . $mkey), 0, 6);
							if ($skey != $vkey) {
								throw new BaseException(ExtraErrorConfig::getErrorCode('invalid_source'), '��tips��Դ��');
							}
						} else {
							throw new BaseException(ExtraErrorConfig::getErrorCode('invalid_source'), '��tips��Դ��');
						}
						break;
					default:
						break;
				}
			}*/
			
			// ������֤ BEGIN
			// ��ȡ��֤����
			$verify_params = ComponentUtil::getVerifyParameters($component['id']);
			if($verify_params === false) {
				throw new BaseException(ComponentUtil::$errCode, ComponentUtil::$errMsg);
			}
			
			// �ظ�����֤
			$ret = ComponentUtil::checkVerifyParameters($component['id'], $verify_params);
			if($ret === false) {
				throw new BaseException(ComponentUtil::$errCode, ComponentUtil::$errMsg);
			}
			
			// ���ݼ���
			$ret = IVerifyConfig::verify(ACT_TYPE_COMPONENT, $component['id'], 0, $verify_params);
			if($ret === false) {
				if(IVerifyConfig::$errCode === 0) {
					$failedInfo = IVerifyConfig::getFailedInfo();
					throw new BaseException(5000 + $failedInfo['verify_type'], $failedInfo['err_msg']);
				} else {
					Logger::err('Error ' . IVerifyConfig::$errCode . ' : ' . IVerifyConfig::$errMsg);
					throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
				}
			}
			// ������֤END
			
			$version = empty($coupon_params['version']) ? 0 : $coupon_params['version'];
			if($version < self::CURRENT_VERSION) {
				throw new BaseException(ExtraErrorConfig::getErrorCode('version_not_match'), '��������ѹ��ڣ�');
			}
			
			if($coupon_params['prize_type'] == self::PRIZE_TYPE_COUPON) {
				// ��ȡ�Ż�ȯ
				
				if($coupon_params['freq_limit_type'] == self::FREQ_LIMIT_TYPE_NONE) {
					// �޷���Ƶ������
					$batch_no = $coupon_params['batch_no'];
				} else {
					// �з���Ƶ������
					$send_time = $coupon_params['send_time'];
					$now = time();
					
					if($now < $send_time) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('invalid_time'), '������δ��ʼ��');
					}
					
					if($coupon_params['freq_limit_type'] == 2) {
						// ����ÿ��Ƶ��
						$period = 86400;
					} else if($coupon_params['freq_limit_type'] == 3) {
						// ����ÿСʱƵ��
						$period = 3600;
					} else {
						throw new BaseException(ExtraErrorConfig::getErrorCode('unexpected_config'), '�����������');
					}
					
					$index = floor(($now - $send_time) / $period);
					if(isset($coupon_params['batch_no_list'])) {
						// �Զ��������κ�
						$batch_no_list = $coupon_params['batch_no_list'];
						if($index >= count($batch_no_list)) {
							// ���һ�����κ��Ժ�Ϊһ������
							$index = count($batch_no_list) - 1;
						}
						$batch_no = $batch_no_list[$index];
					} else {
						// �̶����κ�
						$batch_no = $coupon_params['batch_no'];
					}
					
					// ��鵱ǰ���������ƣ����ϸ��飬�߲���������
					if(!self::checkCurrentTermLimit($component['id'], $coupon_params['send_time'], $coupon_params['freq_limit_type'], $index, $coupon_params['period_count'])) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('over_term_limit'), '�Ż�ȯ�����꣡');
					}
					
					// ������������ƣ����ϸ��飬�߲���������
					if(!self::checkTotalLimit($component['id'], $coupon_params['send_time'], $coupon_params['total_count'])) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('over_total_limit'), '�Ż�ȯ�����꣡');
					}
				}
				
				// ��ȡ��������
				$count_limit = $coupon_params['count_limit'];
				if(!empty($count_limit)) {
					if($coupon_params['freq_limit_type'] == self::FREQ_LIMIT_TYPE_NONE || !isset($coupon_params['batch_no_list'])) {
						$count = ICoupon::getCouponNumofUser($uid, $batch_no);
						if($count === false) {
							Logger::err(ICoupon::$errCode . ' : ' . ICoupon::$errMsg);
							throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
						}
					} else {
						$count = 0;
						foreach ($coupon_params['batch_no_list'] as $bn) {
							$c = ICoupon::getCouponNumofUser($uid, $bn);
							if($c === false) {
								Logger::err(ICoupon::$errCode . ' : ' . ICoupon::$errMsg);
								throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
							}
							
							$count += $c;
						}
					}
					
					if($count >= $count_limit) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('over_count_limit'), '��ȡ�����Ѿ����꣡');
					}
				}
				
				// ��֤MP��Ա��ͨ����
				if(!empty($coupon_params['check_vip_count'])) {
					if(!isset($count)) {
						$count = ICoupon::getCouponNumofUser($uid, $batch_no);
						if($count === false) {
							Logger::err(ICoupon::$errCode . ' : ' . ICoupon::$errMsg);
							throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
						}
					}

					$qq = IQQVerifier::getQQByUid($uid);
					if($qq === false) {
						Logger::err(IQQVerifier::$errCode, IQQVerifier::$errMsg);
						throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
					}
					
					if($coupon_params['check_vip_count'] == 1) {
						// ����´���
						$chance = 0;
						
						$year_mp_no = $coupon_params['year_mp_no'];
						$ret = IQQVerifier::checkQQVipByMp($year_mp_no, $qq);
						if($ret === false) {
							Logger::err(IQQVerifier::$errCode . ' : ' . IQQVerifier::$errMsg);
							throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
						}
						$chance += $ret;
						
						$month_mp_no = $coupon_params['month_mp_no'];
						$ret = IQQVerifier::checkQQVipByMp($month_mp_no, $qq);
						if($ret === false) {
							Logger::err(IQQVerifier::$errCode . ' : ' . IQQVerifier::$errMsg);
							throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
						}
						$chance += $ret;
						
						if($chance <= $count) {
							throw new BaseException(ExtraErrorConfig::getErrorCode('over_vip_count'), '��ȡ�����Ѿ����꣡');
						}
					} else if($coupon_params['check_vip_count'] == 2) {
						// ��������
						$year_mp_no = $coupon_params['year_mp_no'];
						$ret = IQQVerifier::checkQQVipByMp($year_mp_no, $qq);
						if($ret === false) {
							Logger::err(IQQVerifier::$errCode . ' : ' . IQQVerifier::$errMsg);
							throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
						}
						$chance = $ret;
						
						if($chance <= $count) {
							throw new BaseException(ExtraErrorConfig::getErrorCode('over_vip_count'), '��ȡ�����Ѿ����꣡');
						}
					}
				}
				
				// ����Ż�ȯ
				$rel_batch_no = $coupon_params['rel_batch_no'];
				foreach ($rel_batch_no as $bn) {
					$count = ICoupon::getCouponNumofUser($uid, $bn);
					if($count === false) {
						Logger::err(ICoupon::$errCode . ' : ' . ICoupon::$errMsg);
						throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
					}
					if($count > 0) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('coupon_conflict'), '��ȡ�������Ż�ȯ��');
					}
				}
				
				// ��ȡ�Ż�ȯ
				$couponConf = array();
				$couponConf[$batch_no] = array();
				$couponConf[$batch_no]['needEmailVerify'] = 0;
				$couponConf[$batch_no]['needTelVerify'] = 0;
				$couponConf[$batch_no]['onlyNewUser'] = 0;
				$couponConf[$batch_no]['userlevel'] = array();
				// �������5��
				for($i = 0; $i < 5; $i++) {
					$coupon_ret = ICouponFetcher::fetchCoupon($uid,  array($batch_no => 1) , $couponConf);
					if($coupon_ret !== false) {
						break;
					}
				}
				if($coupon_ret === false) {
					if(ICouponFetcher::$errCode == -106) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('coupon_out'), '�Ż�ȯ�����꣡');
					} else {
						Logger::err(ICouponFetcher::$errCode . ' : ' . ICouponFetcher::$errMsg);
						throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
					}
				}
				
				// ��ȡ�ɹ�
				if(!isset($coupon_ret['errCode']) || $coupon_ret['errCode'] == 0) {
					// ��¼��֤�������
					ComponentUtil::saveVerifyParameters($component['id'], $uid, $verify_params);
					
					if(isset($index)) {
						// ���ӵ�ǰ����ȯ���������ϸ�������߲����������
						self::incrementCurrentTermCount($component['id'], $coupon_params['send_time'], $coupon_params['freq_limit_type'], $index);
						
						// ��������ȯ���������ϸ�������߲����������
						self::incrementTotalCount($component['id'], $coupon_params['send_time']);
					}
					
					// ��¼��ȯ��¼
					if($coupon_params['record_user']) {
						$ret = IEventData::add($uid, IEventData::COMP_TYPE_UNIFY_COMP, $component['id'], IEventData::DATA_TYPE_ORDER_ID, $coupon_ret[$batch_no][0]);
						if($ret === false) {
							Logger::err(IEventData::$errCode . ' : ' . IEventData::$errMsg);
						}
					}
				} else {
					throw new BaseException(ExtraErrorConfig::getErrorCode('fetch_failed'), '�Ż�ȯ��ȡʧ�ܣ�' . $ret['errMsg'] . '����');
				}
				
				return array( 
					'errno' => 0, 
					'data' => array( 
						'coupon' => $coupon_ret[$batch_no][0], 
						'title' => $component['title'] 
					)
				);
			} else if($coupon_params['prize_type'] == self::PRIZE_TYPE_UNIFORM) {
				// ͳһ����ƽ̨
				
				if(empty($coupon_params['prize_id'])) {
					// ���ܽ��û����
					qp_itil_write(self::ALARM_CONFIG_ERR, "���[{$component['id']}]������δ���ã�");
					throw new BaseException(ExtraErrorConfig::getErrorCode('config_error'), '��ȡʧ�ܣ����Ժ����ԣ�');
				}
				
				$prize_id = $coupon_params['prize_id'];
				$prize_day_limit = $coupon_params['prize_day_limit'];
				$prize_total_limit = $coupon_params['prize_total_limit'];
				$user_day_limit = $coupon_params['user_day_limit'];
				$user_total_limit = $coupon_params['user_total_limit'];
				
				$now = time();
				
				if(!empty($prize_total_limit)) {
					// ���������
					$prize_total_limit_key = IDataCache::getPrefix(BIZ_TYPE_PRIZE_TOTAL_COUNTER) . $component['id'] . '_' . $prize_id;
					$count = self::checkCountLimit($prize_total_limit_key, $prize_total_limit);
					if($count === false) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('over_total_limit'), '�ý�Ʒ�Ѿ����꣬лл���룡');
					}
					
					$rest = $prize_total_limit - $count;
					if($rest < self::CRITICAL_COUNT) {
						// С���ٽ�ֵʱ�Խ������
						$ret = IFreqLimit::checkFrequence("last_prize_{$component['id']}_{$prize_id}_{$rest}");
						if($ret === false) {
							throw new BaseException(ExtraErrorConfig::getErrorCode('too_many_request'), '��ȡʧ�ܣ����Ժ����ԣ�');
						}
					}
				}
				
				if(!empty($prize_day_limit)) {
					// ÿ�շ�������
					$day = date('Ymd', $now);
					$prize_day_limit_key = IDataCache::getPrefix(BIZ_TYPE_PRIZE_DAY_COUNTER) . $component['id'] . '_' . $prize_id . '_' . $day;
					$count = self::checkCountLimit($prize_day_limit_key, $prize_day_limit);
					if($count === false) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('over_day_limit'), '���ս�Ʒ�Ѿ����꣬лл���룡');
					}
					
					$rest = $prize_day_limit - $count;
					if($rest < self::CRITICAL_COUNT) {
						// С���ٽ�ֵʱ�Խ������
						$ret = IFreqLimit::checkFrequence("last_prize_{$component['id']}_{$prize_id}_{$day}_{$rest}");
						if($ret === false) {
							throw new BaseException(ExtraErrorConfig::getErrorCode('too_many_request'), '��ȡʧ�ܣ����Ժ����ԣ�');
						}
					}
				}
				
				if(!empty($user_total_limit)) {
					// �û���ڼ���������
					$user_total_limit_key = IDataCache::getPrefix(BIZ_TYPE_USER_TOTAL_COUNTER) . $component['id'] . '_' . $prize_id . '_' . $uid;
					$count = self::checkCountLimit($user_total_limit_key, $user_total_limit);
					if($count === false) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('over_user_total_limit'), '������ȡ�����Ѿ����꣡');
					}
				}
				
				if(!empty($user_day_limit)) {
					// �û�������������
					$day = date('Ymd', $now);
					$user_day_limit_key = IDataCache::getPrefix(BIZ_TYPE_USER_DAY_COUNTER) . $component['id'] . '_' . $prize_id . '_' . $uid . '_' . $day;
					$count = self::checkCountLimit($user_day_limit_key, $user_day_limit);
					if($count === false) {
						throw new BaseException(ExtraErrorConfig::getErrorCode('over_user_day_limit'), '���������ȡ�����Ѿ����꣡');
					}
				}
				
				$ip = ToolUtil::getClientIP();
				$ret = IPrize::sendPrize($uid, $prize_id, $component['id'], $ip);
				if($ret === false) {
					throw new BaseException('server_error', '��ȡʧ�ܣ����Ժ����ԣ�');
				}
				
				if(!empty($prize_total_limit)) {
					IDataCache::incrValue($prize_total_limit_key, 1);
				}
				
				if(!empty($prize_day_limit)) {
					IDataCache::incrValue($prize_day_limit_key, 1);
				}
				
				if(!empty($user_total_limit)) {
					IDataCache::incrValue($user_total_limit_key, 1);
				}
				
				if(!empty($user_day_limit)) {
					IDataCache::incrValue($user_day_limit_key, 1);
				}
				
				return array( 'errno' => 0, 'data' => array() );
			}
		} catch(BaseException $e) {
			return array(
				'errno' => $e->errCode,
				'errmsg' => $e->errMsg
			);
		}
	}
	
	public static function getCDKey($component) {
		try {
			$uid = IUser::getLoginUid();
			if(empty($uid)) {
				throw new BaseException(ExtraErrorConfig::getErrorCode('no_login_user'), '�û�δ��¼��');
			}
			
			$res = IEventData::get($uid, IEventData::COMP_TYPE_UNIFY_COMP, $component['id'], IEventData::DATA_TYPE_CDKEY);
			if($res === false) {
				throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '��������æ��');
			}
			
			$cdkeys = array();
			foreach($res as $r) {
				$cdkeys[] = $r['value'];
			}
			
			return array(
				'errno' => 0,
				'data' => $cdkeys
			);
		} catch(BaseException $e) {
			return array(
				'errno' => $e->errCode,
				'errmsg' => $e->errMsg
			);
		}
	}
	
	private static function checkCurrentTermLimit($id, $send_time, $period_type, $index, $limit) {
		$key = "prize_term_limit_{$id}_{$send_time}_{$period_type}_{$index}";
		Logger::info($key);
		$ret = IDataCache::getData($key);
		if($ret === false) {
			if(IDataCache::$errCode === IDataCache::ERROR_NO_DATA || IDataCache::$errCode === IDataCache::ERROR_KEY_EXPIRED) {
				$count = 0;
			} else {
				Logger::err("Failed to check current term limit.[{$id}, {$send_time}, {$period_type}, {$index}]");
				return false;
			}
		} else {
			$count = $ret;
		}
		return $count < $limit;
	}
	
	private static function checkTotalLimit($id, $send_time, $limit) {
		$key = "prize_term_limit_{$id}_{$send_time}";
		$ret = IDataCache::getData($key);
		if($ret === false) {
			if(IDataCache::$errCode === IDataCache::ERROR_NO_DATA || IDataCache::$errCode === IDataCache::ERROR_KEY_EXPIRED) {
				$count = 0;
			} else {
				Logger::err("Failed to check total limit.[{$id}, {$send_time}]");
				return false;
			}
		} else {
			$count = $ret;
		}
		return $count < $limit;
	}
	
	private static function incrementCurrentTermCount($id, $send_time, $period_type, $index) {
		$key = "prize_term_limit_{$id}_{$send_time}_{$period_type}_{$index}";
		$cas = -1;
		$expire_timestamp = 0;
		$ret = IDataCache::casGetData($key, $cas, $expire_timestamp);
		if($ret === false) {
			if(IDataCache::$errCode === IDataCache::ERROR_NO_DATA || IDataCache::$errCode === IDataCache::ERROR_KEY_EXPIRED) {
				$count = 0;
			} else {
				Logger::err("Failed to get current term count.[{$id}, {$send_time}, {$period_type}, {$index}]");
				return false;
			}
		} else {
			$count = $ret;
		}
		
		$ret = IDataCache::casSetData($key, $count + 1, $cas, 0);
		if($ret === false) {
			Logger::err("Failed to increment current term count.[{$id}, {$send_time}, {$period_type}, {$index}]");
			return false;
		}
		
		return true;
	}
	
	private static function incrementTotalCount($id, $send_time) {
		$key = "prize_term_limit_{$id}_{$send_time}";
		$cas = -1;
		$expire_timestamp = 0;
		$ret = IDataCache::casGetData($key, $cas, $expire_timestamp);
		if($ret === false) {
			if(IDataCache::$errCode === IDataCache::ERROR_NO_DATA || IDataCache::$errCode === IDataCache::ERROR_KEY_EXPIRED) {
				$count = 0;
			} else {
				Logger::err("Failed to get total count.[{$id}, {$send_time}]");
				return false;
			}
		} else {
			$count = $ret;
		}
		
		$ret = IDataCache::casSetData($key, $count + 1, $cas, 0);
		if($ret === false) {
			Logger::err("Failed to increment total count.[{$id}, {$send_time}]");
			return false;
		}
		
		return true;
	}
	
	private static function checkCountLimit($key, $limit) {
		$ret = IDataCache::incrGet($key);
		if($ret === false) {
			if(IDataCache::$errCode == IDataCache::ERROR_NO_DATA) {
				// ��ʼ��������
				$ret = IFreqLimit::checkFrequence($key . '_lock');
				if($ret === false) {
					throw new BaseException(ExtraErrorConfig::getErrorCode('too_many_request'), '��ȡʧ�ܣ����Ժ����ԣ�');
				}
				
				$ret = IDataCache::incrInit($key, 0);
				if($ret === false) {
					Logger::err("Failed to init counter with key {$key}.[ " . IDataCache::$errCode . ' : ' . IDataCache::$errMsg . ' ]');
					throw new BaseException(ExtraErrorConfig::getErrorCode('counter_error'), '��ȡʧ�ܣ����Ժ����ԣ�');
				}
				$count = 0;
			} else {
				Logger::err("Failed to get count with key {$key}.[ " . IDataCache::$errCode . ' : ' . IDataCache::$errMsg . ' ]');
				throw new BaseException(ExtraErrorConfig::getErrorCode('counter_error'), '��ȡʧ�ܣ����Ժ����ԣ�');
			}
		} else {
			$count = $ret;
		}
		
		if($count >= $limit) {
			// �Ѵ���������
			return false;
		}
		
		return $count;
	}
}