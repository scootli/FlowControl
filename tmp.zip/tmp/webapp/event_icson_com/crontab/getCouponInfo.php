<?php
/**
 * 得到用户历史奖项信息
 * @author scootli
 * @version 1.0
 * @created 14-六月-2013 
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

Logger::init();

function getOrderInfo(){

	try{
	//设置数据库
	$_DB_CFG["act_event_coupon"] = array(
		'IP' => '10.180.92.36',
		'PORT' => '3306',
		'DB' => "icson_event",
		'USER' => 'user_icson',
		'PASSWD' => 'icson'
	);

	$dao = new IMySQLDAO("icson_event","t_event_coupon_record");
	$sql = "select id,create_date from t_event_coupon_record where evtno = 605 and create_date >= '2013-07-01' and create_date <= '2013-07-16'";


	//连接数据库并执行查询操作
	$result = $dao->query($sql);
	if (false === $result || !is_array($result)) {

		echo "query failed!";
	}
	//循环取出数据
	foreach ($result as $value) {
		$content .= ($value['id'] . "\t" . $value['create_date'] . "\n");
	}
}catch(BaseException $e){
	echo $e->errCode . " : " . $e->errMsg;
}

	//写入数据到文件
	file_put_contents("coupon.txt",$content);
}

getOrderInfo();
?>