<?php
/**
 * 得到用户历史奖项信息
 * @author scootli
 * @version 1.0
 * @created 14-六月-2013 
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

Logger::init();

	global $_DB_CFG;

	if (count($argv) < 4) {
		exit("	Use: /usr/local/php/bin/php -f getVoteInfo.php <component-type	component-id	type>\n");
	}

	$componentType = $argv[1];
	$componentId = $argv[2];
	$type = $argv[3];

	$content = "";
	for($i = 0; $i < 100;$i++){
		//设置数据库
			$_DB_CFG["act_vote_$i"] = array(
				'IP' => '10.180.92.36',
				'PORT' => '3306',
				'DB' => "act_data_$i",
				'USER' => 'user_icson',
				'PASSWD' => 'icson'
			);
		for($j = 0;$j < 100;$j++){
			//初始化数据对象
			$dao = new IMySQLDAO("act_vote_$i","t_act_data_$j");
			$sql = "select uid,create_time from t_act_data_$j where component_type = $componentType and component_id = $componentId and type = $type";
			//连接数据库并执行查询操作
			$result = $dao->query($sql);
			if (false === $result || !is_array($result)) {
				Logger::err("execute query failed $i  $j");
				continue;
			}
			//循环取出数据
			foreach ($result as $value) {
				$content .= ($value['uid'] . "," . $value['create_time'] . "\n");
			}
		}
	}

	//写入数据到文件
	file_put_contents("vote/vote_record_" . $componentId. ".txt",$content);
?>