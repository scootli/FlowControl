<?php
/**
 * 得到用户历史奖项信息
 * @author scootli
 * @version 1.0
 * @created 14-六月-2013 
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

require_once (PHPLIB_ROOT . 'api/IEvtAward.php');
Logger::init();

function getOrderInfo(){
	$orders = array();
	$fp = fopen('orderData.txt', 'r');
	if ($fp === false){
		Logger::err('\n' . "open file failed!" . $filename . '\t');
	}

	$orders = array();
	while(!feof($fp)){
		$buffer = fgets($fp);
		list($uid,$orderid) = preg_split('/,/',$buffer);
		$oneorder = array(
			'uid' => intval($uid),
			'orderid' => intval($orderid)
		);
		array_push($orders, $oneorder);
	}
	Logger::info('\n' . "orders" . var_export($orders,true) . '\t');
	fclose($fp);

	$fp = fopen('order_fee.txt', 'w+');
	if ($fp === false){
		Logger::err('\n' . "open file failed!" . $filename . '\t');
	}
	foreach ($orders as $order) {
		$orderInfo = IOrder::getOneOrder($order['uid'],$order['orderid']);
		$str = $order['uid'] . ',' . $order['orderid'] . ',' . ($orderInfo['order_cost'] / 100) .  ',' .$orderInfo['status'] . ',' . $orderInfo['isPayed'] . '\n';
		Logger::info('\n' . $str . '\t');
		fwrite($fp, $str);
	}
	fclose($fp);
}

getOrderInfo();
?>