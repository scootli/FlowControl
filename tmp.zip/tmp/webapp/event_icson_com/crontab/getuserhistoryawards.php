<?php

/**
 * �õ��û���ʷ������Ϣ
 * @author scootli
 * @version 1.0
 * @created 14-����-2013 
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");
define('ONE_SUM',30);
define('FILE_NAME', WEB_PAGE_ROOT . 'web/event/');

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH,DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

require_once (PHPLIB_ROOT . 'api/IEvtAward.php');
require_once (PHPLIB_ROOT . 'api/ILotteryEvent.class.php');

Logger::init();

function writeAwards($act_id) {
	$error = 0;
	$reward_info = array();
	if (!$act_id) {
		Logger::err("\n" . "act_id is not right!" . "\t");
		$error = 1;
	}else{
		//��ȡ���ONE_SUM�������û��н���Ϣ
		//��ʼ���齱��
		$evtAward = new IEvtAward($act_id);
		//��ȡ���ONE_SUM�������û��н���Ϣ
		$rs = $evtAward->getNAllUsersAwardInfo(ONE_SUM);
		if ($rs === false || !is_array($rs)) {
			$error = 1;
			Logger::err("\n" . "tables does not exist!");
			return;
		}else{
			foreach ($rs as $award) {
				/*$event_info = ToolUtil::gbJsonDecode($award['event_info']);*/
				$userinfo	= IUser::getUserInfo($award['uid']);
				if ($userinfo['nick']) {
					$nick = $userinfo['nick'];
				}else{
					$nick = $userinfo['icsonid'];
				}
				$one_award = array(
					'uid' => $award['uid'],
					'nick' => $nick,
					'lottery_code' => $award['lottery_code'],
					'success_code' => $award['success_code'],
					'time' => strtotime($award['create_time'])
				);
				array_push($reward_info,$one_award);
			}
			Logger::info("\n" . "all award record: " . var_export($reward_info,true) . "\t");
		}
	}
	if ($error) {
		$data = array('errno' => $error);
		$result = ToolUtil::gbJsonEncode($data);
	}else{
		$data = array(
			'errno' => 0,
			'reward_info' => $reward_info
		);

		Logger::info("\n" . "result value: " . var_export($data,true) . "\t");
		$result = ToolUtil::gbJsonEncode($data);
	}

	$result = "window.award" . $act_id . "=" . $result;

	Logger::info("\n" . "JSON data: " . $result . "\t");
	//��ת�����JSON��ʽ����д���ļ�
	$filename = FILE_NAME . "awards_" . $act_id . ".js";
	//var_dump($filename . "\n");
	file_put_contents($filename, $result);
}

//�õ�ÿ�����ǰONE_SUM�������¼
function getnallAward(){
	//�����õ����еĻ��
	$eventObj = new ILotteryEvent();
	$rs = $eventObj->getAllLotteryActivitys();
	if(false === $rs || !is_array($rs)){
		var_dump('���Ϊ��');
		return array('errno' => 1,'message' => '���Ϊ��');
	}else{
		//�����еĻ�Ų��������¼
		foreach ($rs as $actsn) {
			writeAwards($actsn['sn']);
		}
	}
}

getnallAward();