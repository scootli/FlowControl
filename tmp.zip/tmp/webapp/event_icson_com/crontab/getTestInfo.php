<?php
/**
 * 得到用户历史奖项信息
 * @author scootli
 * @version 1.0
 * @created 14-六月-2013 
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");


require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
require_once(API_PATH . "appplatform/user_api.php");
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

Logger::init();

 function GetUserInfoByIcsonUid($uid){
		//检查参数
		if (!isset($uid) || $uid <= 0) {
			var_dump("uid is invalid");
			return false;
		}

		$reqSps->source = __FILE__;
		$reqSps->machineKey = ToolUtil::getClientIP();
		$reqSps->sceneId = 0;
		$reqSps->icsonUid = $uid;
		$reqSps->option = 1;

		$ret = WebStubCntl2::request(
			'b2b2c\user\ao\GetUserInfoByIcsonUid',
			array(
				'opt' => array(
					'uin' => $uid,
					'operator' => $uid,
					'caller' => 'User',
					'itil' => '633986|633987|633988'
				),
				'req' => (array)$reqSps
			)
		);

		if($ret && $ret['code'] == 0){
			if($ret['data']['result'] == 0){
				var_dump("[IUser::GetUserInfoByIcsonUid trace], success ! uid=".$uid);
				var_dump($ret['data']['buyerInfoPo']['bitProperty'][2]);
				return $ret['data']['buyerInfoPo']['bitProperty'][2];
			}
			var_dump("[IUser::GetUserInfoByIcsonUid trace], Error in result:" . " uid=".$uid);
			return 0;
		}
		
		var_dump("[IUser::GetUserInfoByIcsonUid trace], Error in net:" . " uid=".$uid);

		return 0;
	}

function getTestInfo(){
	$uid = 106046295; //400000129
	
	$ret = GetUserInfoByIcsonUid($uid);
	var_dump($ret);
	if($ret == 1){
		var_dump("123");
	}else{
		var_dump("456");
	}
}

getTestInfo();
?>