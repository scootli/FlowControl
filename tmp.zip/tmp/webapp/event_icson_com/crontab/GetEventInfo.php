<?php
/**
 * @author summer
 * @version 1.0
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");
define("PUBLISH_WEB_ROOT", WEB_ROOT . "admin_icson_com/biz/publish/");
define("PUBLISH_WEB_ROOTs", WEB_ROOT . "admin_icson_com/lib/");
require_once (PUBLISH_WEB_ROOT . 'dao/IActStatistic.class.php');
require_once (PUBLISH_WEB_ROOT . 'dao/IActBasic.class.php');
require_once (PUBLISH_WEB_ROOT . 'dao/IActBlock.class.php');
require_once (PUBLISH_WEB_ROOT . 'dao/IActProduct.class.php');
require_once (PUBLISH_WEB_ROOT . 'inc/const_activity_statistic.inc.php');
require_once (PUBLISH_WEB_ROOT . 'lib/Tools.class.php');
require_once (PUBLISH_WEB_ROOTs . 'Common.php');
require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');

TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

Logger::init();

function getEventInfo(){

   //����������߻�Ļid
     $sql= 'SELECT activity_id FROM  t_basic WHERE state=1';
     $actIds = IActBasic::getRows($sql);
     $oldProductID = array();
     $newProductID = array();
     $newPoolID = array();
     $cateryProduct = array(); 

     $activiCatery = array();
    //�����������ߵĻ�����ȸ���cotent_type���ͣ��õ�Ҫ��ֵ
    foreach($actIds as $valueG){
       $sql2 = "SELECT * from t_block WHERE activity_id=". $valueG["activity_id"]." and (content_type=0 or content_type=2)";
       $blockCotent = IActBlock::getRows($sql2);
       //���ÿ���id������Ʒ�����ȡ����ԸûId��������Ʒ�飬������Ʒ�����������������Ҫ�Ķ�����
       //foreach($blockCotent )
       if(empty($blockCotent)){
         continue;
       }
       foreach ($blockCotent as $key => $value) {
       	  if(intval($value['pool_id']) == 0){
               $sql = "SELECT * from t_product WHERE block_id=". $value['block_id'];
               $proIds = IActProduct::getRows($sql);
               if(!empty($proIds)){
                   foreach($proIds as $kk => $vv){
                       array_push($oldProductID,$vv['product_id']);
                   }
               }
       	  }else{
              array_push($newPoolID,$value['pool_id']);

       	  }
       }
        $productInfo=array();
       foreach ($newPoolID as $key => $value) {
      	  array_push($productInfo, IContentPool::getProductByPool(intval($value)));
        }
       foreach ($productInfo as $key => $values) {
     	    foreach ($values as $value) {
     	        array_push($newProductID, $value['product_id']);
          }
        }
        foreach ($oldProductID as $key => $value) {
     	 array_push($newProductID, $value);
        }
        $result = IProduct::getProductsInfo($newProductID);
       
        $temp = array();
        //$result�д��и�����Ʒid�õ�����Ʒ��Ϣ��ע����Ʒ��Ϣ��ȱʧ����Щ��Ʒidû�л����Ʒ��Ϣ
        foreach ($result as $key => $value) {
    	   $ret = ICategoryTTC::get(($value['c3_ids']),array('level'=>3));
		   $ret = ICategoryTTC::get(($ret[0]['parent_id']),array('level'=>2));
		   $ret = ICategoryTTC::get(($ret[0]['parent_id']),array('level'=>1));
		   array_push($temp, $ret[0]['name']);
        }
        $arrayCatery = array_count_values($temp);
        $totally = 0;

        foreach ($arrayCatery as $key => $value) {
             $totally+=$value;
        }  
        foreach ($arrayCatery as $key => $value) {
             $arrayCatery[$key] = $value/$totally;
             
        } 
         $activity_type = 'ȫվ�';
         $max = 0;
        foreach($arrayCatery as $key => $val){
        	  if($val > $max){

        	  	$max = $val;
        	  }
          
        }
        foreach($arrayCatery as $key => $val){
        	  if(($val == $max ) && $max > 0.4){

        	  	$activity_type = $key;
        	  }
          
        }
      
        foreach ($arrayCatery as $key => $value) {
             $arrayCatery[$key] = Common::formatFloat($value*100).'%';
             
        } 
     
       // var_dump($activity_type);
        //$activity_type = 
       //var_dump($arrayCatery);
        $asql = "SELECT name FROM t_basic WHERE activity_id=". $valueG["activity_id"];
        $act_nametype= IActBlock::getRows($asql);

        $namea = $valueG["activity_id"] . substr(md5($valueG["activity_id"]), 0, 4) . '.html';
		$act_url = 'http://event.yixun.com/event/' . $namea;
        $tempresult=array();
        $tempresult['act_id'] = $valueG["activity_id"];
        $tempresult['act_name'] = $act_nametype[0]['name'];
        $tempresult['act_url'] = $act_url;

        $tempresult['act_catery'] = $activity_type;
        $tempresult['act_percent'] = $arrayCatery;
        //var_dump($arrayCatery);

        array_push($cateryProduct,$tempresult);
        
       foreach ($cateryProduct as $key => $value) {
       	  $cotent .= ($value['act_id'] . "\t" . $value['act_name'] . "\t" . $value['act_url'] . "\t" . $value['act_catery'] . "\n");
       }
 
       file_put_contents("activityInfo2.txt",$cotent,FILE_APPEND | LOCK_EX);

} 
   getEventInfo();
?>