#!/bin/bash

while true
do
sleep 1 
`/usr/local/php/bin/php /data/release/webapp/event_icson_com/crontab/microsale.php`
done
