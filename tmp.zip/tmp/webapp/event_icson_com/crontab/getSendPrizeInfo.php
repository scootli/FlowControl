<?php
/**
 * 得到用户历史奖项信息
 * @author scootli
 * @version 1.0
 * @created 14-六月-2013 
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

Logger::init();

if (count($argv) < 2) {
	exit("	Use: /usr/local/php/bin/php -f getVoteInfo.php <prize-id>\n");
}

$prizeId = $argv[1];

function getSendPrizeInfo(){
	global $prizeId;
	global $_DB_CFG;

	$content = '';

	try{
				for($i = 0; $i < 100;$i++){
				//设置数据库
					$_DB_CFG["prize_record_$i"] = array(
						'IP' => '10.206.30.125',
						'PORT' => '9003',
						'DB' => "prize_record_$i",
						'USER' => 'user_icson',
						'PASSWD' => 'icson'
					);
					
				for($j = 0;$j < 100;$j++){
					//初始化数据对象
					$dao = new IMySQLDAO("prize_record_$i","t_prize_record_$j");

					$sql = "select uid from t_prize_record_$j where status = 5 and prize_id = $prizeId and create_time >= '2013-07-01' and create_time <'2013-08-01' group by uid";

					//连接数据库并执行查询操作
					$result = $dao->query($sql);

					if (false === $result || !is_array($result)) {
						echo ("execute query failed $i  $j");
						continue;
					}

					foreach ($result as $value) {
						$content .= ($value['uid'] . "\n");
					}
				}
			}

			file_put_contents("sendPrize/prize" . $prizeId . ".txt", $content);

		}catch(BaseException $e){
			var_dump($e->errCode . ":" . $e->errMsg);
		}
}	

getSendPrizeInfo();
?>