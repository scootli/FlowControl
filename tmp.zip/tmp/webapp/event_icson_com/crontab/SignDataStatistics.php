<?php
/**
 * 得到用户历史奖项信息
 * @author scootli
 * @version 1.0
 * @created 14-六月-2013 
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

Logger::init();


if (count($argv) < 5) {
	exit("	Use: /usr/local/php/bin/php -f getVoteInfo.php <component-id,start_time,end_time,days>\n");
}

$componentId = $argv[1];
$startTime = $argv[2];
$endTime = $argv[3];
$days = $argv[4];

function SignDataStastics(){
	global $componentId,$startTime,$endTime,$days;
	global $_DB_CFG;

	//先取某段时间内累计签到n天的用户数据（用户信息、签到时间、签到用户数、签到人次数）
	$totalTimes = 0;
	$totalPeople = 0;

	//再统计某段时间内连续签到n天的用户数据（用户信息、签到时间、签到用户数、签到人次数）
	$continuousTotalTimes = 0;
	$continuousTotalPeople = 0;

	//存放uid的数组
	/*$totalArray = array();
	$continuousArray = array();*/

	try{
			for($i = 0; $i < 100;$i++){
			//设置数据库
				$_DB_CFG["act_sign_$i"] = array(
					'IP' => '10.180.92.36',
					'PORT' => '3306',
					'DB' => "act_data_$i",
					'USER' => 'user_icson',
					'PASSWD' => 'icson'
				);
				
			for($j = 0;$j < 100;$j++){
				//初始化数据对象
				$dao = new IMySQLDAO("act_sign_$i","t_act_data_$j");

				$sql = "select uid,count(*) from t_act_data_$j where component_id = $componentId and create_time >= '" . $startTime . "' and create_time <= '"
						. $endTime . "' group by uid";

				//连接数据库并执行查询操作
				$result = $dao->query($sql);

				if (false === $result || !is_array($result)) {
					echo ("execute query failed $i  $j");
					continue;
				}	

				foreach ($result as $value) {
					if ($value['count(*)'] >= $days) {
						//统计累计总签到次数
						$totalTimes += ($value['count(*)']);
						//统计累计总签到人数
						$totalPeople++;

						//取得满足条件的用户信息和签到时间
						$uid = $value['uid'];
						$subsql = "select uid,create_time from t_act_data_$j where component_id = $componentId and uid = $uid and create_time >= '" . $startTime . "' and create_time <= '"
						. $endTime . "' order by create_time";

						//连接数据库并执行查询操作
						$rs = $dao->query($subsql);
						if (false === $rs || !is_array($rs)) {
							echo ("execute sub query failed $i  $j");
							continue;
						}

						//得到满足条件结果的内容
						$content = "";
						foreach ($rs as $item) {
							$content .= ($item['uid'] . /*"\t" . date("Y-m-d H:m:s",$item['create_time']) .*/ "\n");
						}


						//将满足累计条件的结果写入文件
						file_put_contents("sign/accumulative.txt", $content,FILE_APPEND | LOCK_EX);


						//处理连续签到(某段时间内累计签到不满n天的用户，连续签到一定不满n天)
						//提取出该用户所有签到时间
						/*$sign_time_array = array();
						foreach ($rs as $item) {
							array_push($sign_time_array, strtotime(date("Y-m-d",strtotime($item['create_time']))));
						}
						//得到该用户的连续签到次数(并且如果此用户的连续签到次数大于n天则统计)
						if(_getContinueSignCount($sign_time_array) >= $days){
							//统计累计连续签到次数
							$continuousTotalTimes += ($value['count(*)']);
							//统计连续总签到人数
							$continuousTotalPeople++;

							//将满足连续条件的结果写入文件
							file_put_contents("sign/continuous.txt", $content,FILE_APPEND | LOCK_EX);
						}*/
					}
				}
			}
		}

		//将满足累计条件的结果写入文件
		/*file_put_contents("sign/accumulative.txt",join("\n",$totalArray),FILE_APPEND | LOCK_EX);*/

		//写入满足累计条件的总签到次数和总签到人数
		$additional = "\n" . $totalTimes . "\t" . $totalPeople . "\n";
		file_put_contents("sign/accumulative.txt", $additional,FILE_APPEND | LOCK_EX);

		//将满足连续条件的结果写入文件
		/*file_put_contents("sign/continuous.txt", join("\n",$continuousArray),FILE_APPEND | LOCK_EX);*/

		//写入满足连续条件的总签到次数和总签到人数
		/*$conAdditional = "\n" . $continuousTotalTimes . "\t" . $continuousTotalPeople . "\n";
		file_put_contents("sign/continuous.txt", $conAdditional,FILE_APPEND | LOCK_EX);*/

	}catch(BaseException $e){
		var_dump($e->errCode . ":" . $e->errMsg);
	}
}	
	
//根据签到时间得到连续签到次数（取最大的连续签到次数）
function _getContinueSignCount($sign_time_array){
	$max_continue_count = 1;
	//数组大小
	$size = count($sign_time_array);

	$continue_count = 1;
	$prev_value = $sign_time_array[0];

	for ($index= 1; $index < $size; $index++) {

		$value =  $sign_time_array[$index];
		if ($value == ($prev_value + 86400)) {
				$continue_count++;
		}else{
			if ($continue_count > $max_continue_count) {
				$max_continue_count = $continue_count;
			}
			$continue_count = 1;
		}

		$prev_value = $value;
	}

	//var_dump("\n max_continue_count: " . $max_continue_count . "\n");

	return $max_continue_count;
}

SignDataStastics();
?>