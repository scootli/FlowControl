<?php

require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

require_once(WEB_PAGE_ROOT . 'inc/microsale.inc.php');
Logger::init();

function run() {
	global $eventMicroSale;
	$date = date('Y-m-d',time());

	if( !isset($eventMicroSale['pids'][$date]) )
		return false;
	foreach( $eventMicroSale['pids'][$date] as $pid )	
	{
		$result = array();
		$url = "http://tshop.qq.com/tshop/getActivityProgress.xhtml?format=json&itemCode=".$pid."&sellerUin=855002000";
		//$url = "http://10.16.78.65:8080/tshop/getActivityProgress.xhtml?format=json&itemCode=BFE7CB0C00000000003F3B0D0001C7D8";
		$ret = NetUtil::cURLHTTPGet($url, 30, '');
		if( $ret == false )
		{
			logger::err('fail to get paipai price');
			continue;
		}
		$info = ToolUtil::gbJsonDecode($ret);
		if( $info['errorCode'] !=0 )
		{
			logger::err('fail to get paipai price:'.$info['errorMessage']);
			continue;
		}

		$EDMcodeInfo =  getEDMCodeInfo($pid);
		if( $EDMcodeInfo==false || empty($EDMcodeInfo) )
		{
			logger::err('fail to get edmprice');
			continue;
		}
		if( $info['itemPrice'] == ($EDMcodeInfo['EDMPrice']*100) )
		{
		//		logger::info('the price is same.'.$pid);
				continue;
		}
                if (empty($info['itemPrice'])) {
                       logger::err('item price 0');
                       continue;
		}


		global  $_IP_CFG;;
		
		foreach ($_IP_CFG as $siteId => $urlPre)
 		{
 			$params = "siteid=".$siteId."&EDMCode=".$EDMcodeInfo['EDMCode']."&ProductSysNo=".$pid."&EDMPrice=".$info['itemPrice']/100;
			$setUrl = 'http://' . $urlPre . '/InternalService/EDMPrivilegesUpdate.ashx?'.$params;
	                logger::info('seturl:' . $setUrl);
			$retCode = NetUtil::cURLHTTPGet($setUrl, 15, '');
			if( intval($retCode) > 0  )
				logger::info('sucess to set price '.$pid.'_'. $info['itemPrice'] . ', siteid' . $siteId);
			else
				logger::info('fail to set price '.$pid . ', siteid' . $siteId);
 		}
	}
	return;
}

run();


function getEDMCodeInfo($pid)
{
    $now = date('Y-m-d H:i:s');
    $sql = "select EDMCode, ProductSysNo, EDMPrice, IsMobileVerification, IsEmailVerification, MemberLevelRange
            from EDM_Privileges where EDMStatus=1 and StartDate <='" . $now . "' and EndDate >='" . $now . "'
            and ProductSysNo = $pid";
    $oldDB = Config::getMSDB('ERP_1');
    $ret = $oldDB->getRows($sql);
    if( $ret==false || empty($ret) )
        return false;
    return $ret[0];
}
