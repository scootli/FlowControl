<?php
/**
 * 得到用户历史奖项信息
 * @author scootli
 * @version 1.0
 * @created 14-六月-2013 
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

Logger::init();

if (count($argv) < 4) {
	exit("	Use: /usr/local/php/bin/php -f getVoteInfo.php <component-id,start_time,end_time>\n");
}

$componentId = $argv[1];
$startTime = $argv[2];
$endTime = $argv[3];

function SignNumbersDaily(){
	global $componentId,$startTime,$endTime;
	global $_DB_CFG;

	$start_time = strtotime($startTime);
	$end_time = strtotime($endTime);

	for($index = $start_time; $index <$end_time; $index += 86400){
		$first_time = date("Y-m-d",$index);
		$second_time = date("Y-m-d",($index + 86400));

		//每天签到总人数
		$total = 0;
		try{
				for($i = 0; $i < 100;$i++){
				//设置数据库
					$_DB_CFG["act_sign_$i"] = array(
						'IP' => '10.180.92.36',
						'PORT' => '3306',
						'DB' => "act_data_$i",
						'USER' => 'user_icson',
						'PASSWD' => 'icson'
					);
					
				for($j = 0;$j < 100;$j++){
					//初始化数据对象
					$dao = new IMySQLDAO("act_sign_$i","t_act_data_$j");

					$sql = "select uid,count(*) from t_act_data_$j where component_id = $componentId and create_time >= '" . $first_time . "' and create_time <= '"
							. $second_time . "' group by uid";

					//连接数据库并执行查询操作
					$result = $dao->query($sql);

					if (false === $result || !is_array($result)) {
						echo ("execute query failed $i  $j");
						continue;
					}

					//累加签到人数
					$total += count($result);
				}
			}

			$content = '';
			$content .= ($first_time . "\t" . $total . "\n");
			file_put_contents("sign/daily.txt", $content,FILE_APPEND | LOCK_EX);

		}catch(BaseException $e){
			var_dump($e->errCode . ":" . $e->errMsg);
		}
	}
}	

SignNumbersDaily();
?>