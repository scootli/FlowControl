<?php
/**
 * 得到用户历史奖项信息
 * @author scootli
 * @version 1.0
 * @created 14-六月-2013 
 */
require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

Logger::init();

	global $_DB_CFG;

	if (count($argv) < 2) {
		exit("	Use: /usr/local/php/bin/php -f getVoteInfo.php < component-id >\n");
	}


	$componentId = $argv[1];

	$totalTimes = 0;
	$totalPeople = 0;

	try{
			for($i = 0; $i < 100;$i++){
			//设置数据库
				$_DB_CFG["act_sign_$i"] = array(
					'IP' => '10.180.92.36',
					'PORT' => '3306',
					'DB' => "act_data_$i",
					'USER' => 'user_icson',
					'PASSWD' => 'icson'
				);
			for($j = 0;$j < 100;$j++){
				//初始化数据对象
				$dao = new IMySQLDAO("act_sign_$i","t_act_data_$j");
				$sql = "select count(*) from t_act_data_$j where component_id = $componentId";
				//连接数据库并执行查询操作
				$result = $dao->query($sql);

				if (false === $result || !is_array($result)) {
					Logger::err("execute query failed $i  $j");
					continue;
				}	

				//统计总签到次数
				$totalTimes += ($result[0]['count(*)']);
				
				//统计总签到人数
				$sql = "select count(*) from t_act_data_$j where component_id = $componentId group by uid";
				//连接数据库并执行查询操作
				$result = $dao->query($sql);
				if (false === $result || !is_array($result)) {
					Logger::err("execute query failed $i  $j");
					continue;
				}
				//统计总签到人数
				$totalPeople += count($result);
			}
		}

		echo $totalTimes . " : " . $totalPeople . "\n";

	}catch(BaseException $e){
		var_dump($e->errCode . ":" . $e->errMsg);
	}
	
?>