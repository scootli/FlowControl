<?php
require_once(WEB_PAGE_ROOT . 'inc/lottery.inc.php');

Logger::init();

function page_lottery_start()
{
    $wid = IUser::getSiteId();
    $pid = $error = $code = 0;
    $msg = '';

    $uid = IUser::getLoginUid();
    $userInfo = IUser::getUserInfo($uid);

    //ֻ���ֻ���֤���ܲμӳ齱
    if ( !$uid )
    {
        $error = 81;
        $msg = '����û�е�¼��';
    }
    else if(!$userInfo['bindMobile'])
    {
        $error = 1001;
        $msg = 'ֻ���ֻ���֤�û��ŲμӴ˻�����Ƚ����ֻ���֤��';
    } else
    {
        $obj = new IActAward();
        $ret = $obj->getAward($uid);
        $error = $ret['error'];
        $msg = $ret['message'];
        $code = $ret['item']['code'];
        $pid = $ret['item']['pid'];
    }

    echo "<?xml version='1.0' encoding='gb2312'?><root><ret>$error</ret><level>$code</level><message>$msg</message><uid>$uid</uid><pid>$pid</pid></root>";
    return;
}

function page_lottery_index()
{
    ToolUtil::noCacheHeader(); //�����޻���
    $whid = IUser::getSiteId(1); //ǿ���Ϻ�վ
    $cacheContent = IPageCahce::getCachePage(__FILE__, __FUNCTION__, $whid);
    $TPL = TemplateHelper::getBaseTPL(array(
        'titleDesc' => '5�۷籩 ��Ҫ��',
    ));

    $uid = IUser::getLoginUid();
    $userInfo = IUser::getUserInfo($uid);
    if ($uid && (!$userInfo['bindMobile'])) { //ֻ���ֻ���֤���ܲμӳ齱
        $cacheContent .= '<script type="text/javascript">$(function(){_showPhoneWarningDialog();});</script>';
    }
    $TPL->set_var('container', $cacheContent);
    $TPL->out();
}

function lottery_cancel()
{
    $uid = IUser::getLoginUid();
    if (!$uid)
    {
        return array('error'=>81,'message'=>'����û�е�¼��');
    }

    $_uid = empty($_GET['uid']) ? 0 : intval($_GET['uid']);
    $_pid = empty($_GET['pid']) ? 0 : intval($_GET['pid']);
    if ( !$_uid  || !$_pid || ($uid!=$_uid) )
    {
        return array('error'=>1001,'message'=>'�Ƿ�����');
    }

    $obj = new IActAward();
    $awards = $obj->getUserAward("user_id=$uid and product_id=$_pid and status=0");
    if( empty($awards) )
    {
        return array('error'=>1001,'message'=>'�Ƿ�����');
    }
    $id = $awards[0]['id'];
    $ret = $obj->setUserAwardStatus(array('status'=>-1),"id=$id");

    if($ret)
        return array('error'=>0,'message'=>'�����ɹ���');
    else
        return array('error'=>1001,'message'=>'�������ݿ�ʧ�ܣ�');
}

function page_lottery_order()
{
    $uid = IUser::getLoginUid();
    $wid = IUser::getSiteId();
    if(!$uid)
    {
        echo '����û�е�¼��';
        _errorReloadPage();
        return;
    }

    $_uid = empty($_GET['uid'])?0:intval($_GET['uid']);
    $_pid = empty($_GET['pid'])?0:intval($_GET['pid']);
    if( !$_uid  || !$_pid || ($uid!=$_uid) )
    {
        echo '�Ƿ����󣡲�������';
        _errorReloadPage();
        return;
    }

    $obj = new IActAward();
    $awards = $obj->getUserAward("user_id=$uid and product_id=$_pid and status=0");
    if( empty($awards) )
    {
        echo '�Ƿ����󣡷��û���Ʒ';
        _errorReloadPage();
        return;
    }

    $EDMcode =  getEDMCode($_pid);
    if( empty($EDMcode) )
    {
        echo '�Ƿ����󣡻�ȡEDM��ʧ�ܣ�';
        _errorReloadPage();
        return;
    }

    IShoppingCart::clear($uid, $wid);
    IShoppingCart::add($uid,
        array(
            'product_id' => $_pid,
            'buy_count' => 1,
            'wh_id' => $wid
        )
    );
    setcookie('edm', $EDMcode.'_'.$_pid, null, '/', '.yixun.com');
    setcookie('event_lottery', 1, null, '/', '.yixun.com');

    echo "<script type='text/javascript'> window.location.href='http://buy.yixun.com/order.html'; </script>";
    return ;
}

function page_lottery_admin()
{
    $uid = IUser::getLoginUid();
    $admin_uid = array(
        1684099,
        872611,
        93729,
	6808530,
    );

    if (!in_array($uid, $admin_uid)) {
        return;
    }

    $pass = empty($_GET['pass']) ? 0 : ($_GET['pass']);

    if (!strcmp($pass, 'oscarzhu'))
    {
        $TPL = TemplateHelper::getBaseTPL(array(
            'containerTPL' => 'admin.tpl'
        ));
        $TPL->set_block('containerHandler', 'result_list', 't_result_list');

        $obj = new IActAward();
        $awardsCount = $obj->getAwardsCount();
        foreach($awardsCount as $val)
        {
            $TPL->set_var('id', $val['id']);
            $TPL->set_var('name', $val['name']);
            $TPL->set_var('count', $val['count']);
            $TPL->set_var('total', $val['total']);
            $TPL->parse('t_result_list','result_list',true);
        }
        $TPL->out();
    }
    return;
}

function _errorReloadPage()
{
    echo "<script type='text/javascript'> window.location.href='http://event.yixun.com/lottery/index.html'; </script>";
    return;
}

function getEDMCode($pid)
{
/*
    $now = date('Y-m-d H:i:s');
    $sql = "select EDMCode, ProductSysNo, EDMPrice, IsMobileVerification, IsEmailVerification, MemberLevelRange
            from EDM_Privileges where EDMStatus=1 and StartDate <='" . $now . "' and EndDate >='" . $now . "'
            and ProductSysNo = $pid";
    $oldDB = Config::getMSDB('ERP_1');
    $ret = $oldDB->getRows($sql);
    if(empty($ret))
        return false;
    return $ret[0]['EDMCode'];*/
	return 'lyedm110930tips';
}


