<?php

Logger::init();

function product_get() {
	$ret 		= array(
		'errno'		=> 0,
		'message'	=> '',
		'data'		=> null,
	);
	
	$id			= isset($_GET['id']) ? intval($_GET['id']) : 0;
	$site_id	= isset($_GET['site_id']) ? intval($_GET['site_id']) : SITE_ALL;
	
	if (empty($id)) {
		$ret['errno']		= 1;
		$ret['message']		= 'Ƶ��id����Ϊ��';
	} else {
		$rs = IEventProductInfo::getAllByChannelId($id, $site_id);
		if (IEventProductInfo::$errCode) {
			$ret['errno']	= IEventProductInfo::$errCode;
			$ret['message']	= IEventProductInfo::$errMsg;
		} else {
			$ret['data']	= ToolUtil::gbJsonDecode($rs);
		}
	}
	
	return $ret;
}