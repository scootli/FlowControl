<?php
require_once(PHPLIB_ROOT . 'api/IPageCahce.class.php');
require_once(PHPLIB_ROOT . 'api/IReviewReply.php');
require_once(PHPLIB_ROOT . 'api/IReviews.php');
require_once(PHPLIB_ROOT . 'lib/Dirty.php');
require_once(PHPLIB_ROOT . 'lib/VerifyCode.php');
require_once(PHPLIB_ROOT . 'inc/constant.inc.php');

Logger::init();

/**
 * JSON �ӿڣ������վ��
 * @return string
 */
function event_checksite() {
	global $_Wh_id;
	$eventId = intval($_GET['eventid']);
	$whId = IUser::getSiteIdWrapper();
	$DB = Config::getDB('icson_admin_event');
	if (!$DB) {
		/*
		 * �����falg��ָflag��������һЩ��flag����������falg��Ӧ���Ǳ���
		 * Added by EdisonTsai on 14:19 2012/07/05
		 */
		return '{falg:0, message:"�޷���ȡ�û��������Ϣ"}';
	} else {
		$sql = 'select * from t_basic where activity_id=' . $eventId;
		$rs = $DB->getRows($sql);
		if ($rs === false || !isset($rs[0]['where_id'])) {
			return '{falg:0, message:"�û�����ڣ���л���Ĺ�ע"}';
		} else {
			$eventWhId = $rs[0]['where_id'];
			if($eventWhId && $eventWhId != $whId) {
				$eventUrl = isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'http://event.yixun.com/event/' . $eventId . substr(md5($eventId), 0, 4) . '.html';
				$eventUrl = '\"' . $eventUrl . '\"';
				$message  = '�����ʵĻ����Ѹ��-' . $_Wh_id[$eventWhId] . 'վ�Ļ<br /><br />';
				$message .= '<span style=\"margin-right:5px\"><a href=\"#\" style=\"background: #06c; color:#ffffff; text-decoration:none; padding:5px 10px; font-size:12px; font-weight:normal;\" onclick=\'G.app.switchSite.tryToSwitchTo(' . $eventWhId . ', ' . $eventUrl . ');\'>������Ѹ��-' . $_Wh_id[$eventWhId] . 'վ����</a></span>';
				$message .= '<span><a style=\"background: #ccc; color:#ffffff; text-decoration:none; padding:5px 10px; font-size:12px; font-weight:normal;\" href=\"http://www.yixun.com\">��վ��������</a></span>';
				return '{flag:0, message:"' . $message . '"}';
			} else {
				IEvent::checkEventSn($eventId, true);
				IEvent::setEventVisited($eventId);
				return '{flag:1}';
			}
		}
	}
}

//ǿ��վ��
function page_event_forcesite() {
	header("P3P: CP='CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR'");
	$siteId = intval($_GET['siteid']);
	IUser::getSiteIdWrapper($siteId);
	if (preg_match("/^http:\/\/([^\.]+\.|)(51buy|icson|yixun)\.com/i", $_GET['url'])) {
		$ext = '';
		foreach ($_GET as $key => $gt) {
			if (in_array($key, array('mod', 'act', 'url', 'siteid'))) {
				continue;
			}
			$ext .= '&' . $key . '=' . $gt;
		}
		header("Location:" . $_GET['url'] . $ext);
	} else {
		ToolUtil::redirect('http://www.yixun.com');
	}
}

//ǿ��ʡ��
function page_event_forceprov() {
	header("P3P: CP='CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR'");
	$provid = intval($_GET['provid']);
	IUser::getProvId($provid);
	if (preg_match("/^http:\/\/([^\.]+\.|)(51buy|icson|yixun)\.com/i", $_GET['url'])) {
		$ext = '';
		foreach ($_GET as $key => $gt) {
			if (in_array($key, array('mod', 'act', 'url', 'siteid'))) {
				continue;
			}
			$ext .= '&' . $key . '=' . $gt;
		}
		header("Location:" . $_GET['url'] . $ext);
	} else {
		ToolUtil::redirect('http://www.yixun.com');
	}
}


function page_event_getjson(){
	header('Content-Type: text/html; charset=gb2312');
	$eventId = isset($_GET['eventId']) ? intval($_GET['eventId']) : 0;
	$callback = isset($_GET['callback']) ? ToolUtil::transXSSContent($_GET['callback']) : '';

    if(preg_match('/^[\$a-z0-9_\.]+$/i', $callback) == 0) {
	     exit;
    }
	if (empty($callback)) {
		exit;
	}
	if (!$eventId) {
		exit($callback . "({'error':'event id is empty'})");
	}
	$jsPath = '/data/release/webapp/event_icson_com/web/event/' . $eventId . '.js';
	if (!file_exists($jsPath)) {
		exit($callback . "({'error':'js file does not exist'})");
	}
	$eventInfo = file_get_contents($jsPath);
	if (empty($eventInfo)) {
		exit($callback . "({'error':'can not get information of event'})");
	}
	exit($callback . "($eventInfo)");
	
	/*
	 * ǰ�˵��÷���
	 * 
	 * 
	 * 	$.getJSON("http://event.51buy.com/index.php?mod=event&act=getjson&eventId=171&callback=?", function(result){
		if (result.error == null || result.error == '') {
			alert(result.name);
		} else {
			alert(result.error);
		}
	});*/
}

//����Ƿ���qq vip�û�
function event_qqvip() {
	$uid = IUser::getLoginUid();
	if ($uid) {
		$isVip = IUser::checkQQVip($uid);
		if ($isVip) {
			return true;
		}
	}
	return false;
}

//�鿴����ϲ��
function event_instresting() {
	$count = isset($_GET['count']) ? intval($_GET['count']) : 0;
	if (empty($count)) {
		$count = 5;
	}
	$siteId = isset($_GET['sid']) ? intval($_GET['sid']) : IUser::getSiteId();
	$products = ISearch::getPersonalProducts($siteId, 20, true);
	$clicks = ISearch::$clicks;
	$policyId = ISearch::$policyId;

	$i = 0;
	$rstProducts = array();
	if (is_array($products)) {
		foreach ($products as $product) {
			if ($i >= $count) break;
			$rstProduct['product_id'] = $product['product_id'];
			$rstProduct['product_char_id'] = $product['product_char_id'];
			$rstProduct['name'] = $product['name'];
			$rstProduct['show_price'] = sprintf("%0.2f", $product['show_price']/100);
			if ($product['status'] != 1) continue;
			$rstProducts[] = $rstProduct;
			$i++;
		}
	}

	return array('products' => $rstProducts, 'clicks' => $clicks);
}


