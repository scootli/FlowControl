<?php
require_once(WEB_PAGE_ROOT . 'inc/lottery.inc.php');
require_once (PHPLIB_ROOT . 'api/ILotteryEvent.class.php');
require_once (PHPLIB_ROOT . 'api/IEvtAward.php');
require_once (PHPLIB_ROOT . 'api/IInviteEvent.class.php');
require_once (PHPLIB_ROOT . 'api/IAllEvent.class.php');
require_once(PHPLIB_ROOT . 'api/IFreqLimit.php');
require_once(PHPLIB_ROOT . 'api/IVerifyConfig.inc.php');
require_once(PHPLIB_ROOT . 'api/ICoupon.php');
require_once('lotteryge.php');

define('SEND_COUPON_ALARM_KEY',635249);
define('QUEUE_KEY','mobile_send_coupon_key');


Logger::init();  

/**
 * ÓÃÓÚ»ñÈ¡ÓÃ»§Ò¡½±×´Ì¬ÐÅÏ¢
 * @param $uid    :   ÓÃ»§id
 * @param $act_id :   »î¶¯id
 * 
 * @return JSONÊä³ö
 *      error     :   ´íÎóÂë : 0 ÕýÈ· 1 Ê§°Ü
 *      remain_cnt£º  ½ñÌìÊ£ÓàÒ¡½±´ÎÊý
 *      goldcount :   ½ð±ÒÄ£ºóµÄ¸öÊý
 */
function rewardm_list(){
	$uid = $_POST['uid'];
	$wg_skey = $_POST['award_kk'];
	//Logger::info("uid - {$uid}, skey - {$wg_skey}");
	$_COOKIE['uid'] = $uid;
	//$_COOKIE['wg_skey'] = $wg_skey;
	$_COOKIE['skey'] = $wg_skey;
	$_COOKIE['token'] = md5($uid . APP_LOGIN_RENEWAL_KEY);
	unset($_COOKIE['wg_skey']);
	$uid = IUser::getLoginUid();
	//$uid = $_GET['uid'];
	$error = 0;
	if (!$uid) {
		Logger::err("\n" . "Äã»¹Î´µÇÂ½" . "\t");
		$error = 1;
		$data = array(
			'errno' => $error,
			'message' => "ÇëÄúÏÈµÇÂ¼£¬Ð»Ð»ÅäºÏ"
		);
		return $data;
		//return array('errno'=> 1, 'message'=>'ÇëÄúÏÈµÇÂ¼£¬Ð»Ð»ÅäºÏ');
	}

	$act_id = $_POST['act_id'];
	$error = 0;
	if (!$act_id) {
		Logger::err("\n" . "act_id are 0" . "\t");
		$error = 4;
		$data = array(
			'errno' => $error,
			'message' => "»î¶¯ºÅÉèÖÃ²»ÕýÈ·!"
		);
		return $data;
		//return array('errno'=> 3, 'message'=>'»î¶¯ºÅÎª0');
	}
	//»ñµÃ½ñÌìÊ£ÓàµÄÒ¡½±´ÎÊý
	$evtAward = new IEvtAward($act_id);
	$remain_cnt = $evtAward->getJoinCounts($uid);

	//Logger::info("\n" . "remain lottery times: " . $remain_cnt . "\t");
	//È¡µÃ½ð±ÒÄ£ºóµÄÊýÁ¿
	//½ð±Ò½±Ïî±àºÅ
	$code = 2;
	//µÃµ½ÓÃ»§½ð±ÒµÄÊýÁ¿
	$rs = lotteryge_getAwardNum($uid);
	if($rs['errno']){
		Logger::err("\n" . "³öÏÖ´íÎó" . "\t");
		if($rs['errno'] == 2){
			$error = 3;
			$data = array(
				'errno' => $error,
				'message' => "ÏàÍ¬Ê±¼äÄÚµã»÷´ÎÊý¹ý¶à£¬ÇëÄú5ÃëºóÔÙ³¢ÊÔ£¡"
			);
			return $data;
		}else{
			$error = 2;
			$data = array(
				'errno' => $error,
				'message' => "µÃµ½ÓÃ»§½±ÏîºÍÏàÓ¦µÄÊýÁ¿Ê§°Ü£¡"
			);
			return $data;
		}
		//return array('errno'=> $rs['errno'], 'message'=>'³öÏÖ´íÎó!');
	}

	//Logger::info("\n" . "rs: " . var_export($rs,true) . "\t");

	$result = $rs['data'];
	foreach ($result as $oneAward) {
		if ($oneAward['lottery_code'] == $code) {
			$gold_num = $oneAward['count(*)'];
			break;
		}
	}

	//Logger::info("\n" . "gold num: " . $gold_num . "\t");
	//È¡µÃÄ£¼¸µÄÅäÖÃ£¨Ä¬ÈÏÉèÖÃÎª1£¬·ÀÖ¹´ËÖµÎª0ÒÔ×öÓàÊý£©
	$modNum = 1;

	$eventInfo = ToolUtil::gbJsonDecode($evtAward->getConfigInfo());
	$awardInfo = $eventInfo['coupon_datas'];
	//²ÎÊýÓÐÎó
	if (!is_array($awardInfo)) {
		$error = 5;
		Logger::err("\n" . "È¡ÅäÖÃÐÅÏ¢Ê§°Ü!" . "\t");
		$data = array(
			'errno' => $error,
			'message' => "µÃµ½½±ÏîÅäÖÃÐÅÏ¢Ê§°Ü"
		);
		return $data;
	}

	foreach ($awardInfo as $daward) {
		if ($daward['id'] == $code) {
			$modNum = $daward['count'];
			break;
		}
	}
	if ($modNum == 0) {
		$modNum = 1;
	}

	//Logger::info("\n" . "default value: " . $modNum . "\t");
	//È¡µÃ½ð±ÒÄ£ºóµÄÊýÁ¿
	$gold_mod_num = $gold_num % $modNum;

	//·â×°³ÉjsonÊä³ö
	$data = array(
		'errno' => $error,
		'remain_cnt' => $remain_cnt['dailay'],
		'gold_mod_num' => $gold_mod_num
	);

	//Logger::info("\n" . "result value: " . var_export($data,true) . "\t");

	return $data;
}

/**
 * ·ÖÏí³É¹¦Ôö¼ÓÒ¡½±»ú»á½Ó¿Ú
 * ·ÖÏí½±ÀøÊÇÓÃ»§Ã¿ÌìµÚÒ»´Î·ÖÏí¿É»ñµÃ£¬µ±ÌìÆäËû´Î·ÖÏí²»ÔÙ½±Àø
 * Èç¹ûÊÇÓÃ»§µ±ÌìµÚÒ»´Î·ÖÏíÔò½«´Ë¼ÇÂ¼²åÈëÊý¾Ý¿â£¬·ñÔò²»ÔÙ²åÈëÊý¾Ý¿â
 * @param $uid    :   ÓÃ»§id
 * @param $act_id :   »î¶¯id
 * 
 * @return JSONÊä³ö
 *      error     :   ´íÎóÂë  0 ÕýÈ· 1 ´íÎó 2 ½ñÌìÒÑ·ÖÏí¹ý
 *      
 *      
 */
function rewardm_share(){
	$uid = $_POST['uid'];
	$wg_skey = $_POST['award_kk'];
	//Logger::info("uid - {$uid}, skey - {$wg_skey}");
	$_COOKIE['uid'] = $uid;
	//$_COOKIE['wg_skey'] = $wg_skey;
	$_COOKIE['skey'] = $wg_skey;
	$_COOKIE['token'] = md5($uid . APP_LOGIN_RENEWAL_KEY);
	unset($_COOKIE['wg_skey']);
	$uid = IUser::getLoginUid();
	//$uid = $_GET['uid'];
	if (!$uid) {
		$error = 1;
		$data = array(
			'errno' => $error,
			'message' => "ÇëÄúÏÈµÇÂ¼,Ð»Ð»ÅäºÏ"
		);
		Logger::err("\n" . "please login first!" . "\t");
		return $data;
	}
	$act_id = $_POST['act_id'];
	$error = 0;
	if (!$act_id) {
		Logger::err("\n" . "act_id is not right!" . "\t");
		$error = 2;
		$data = array(
			'errno' => $error,
			'message' => "»î¶¯ºÅÉèÖÃ²»ÕýÈ·!"
		);
		return $data;
	}
	//·ÀË¢
	if (IFreqLimit::checkAndAdd($uid, 2)) {
		$error = 3;
		$data = array(
			'errno' => $error,
			'message' => "ÏàÍ¬Ê±¼äÄÚµã»÷´ÎÊý¹ý¶à£¬ÇëÄú5ÃëºóÔÙ³¢ÊÔ"
		);
		Logger::err("\n" . "You click in short time" . "\t");

		return $data;
	}

	$invite = new IInviteEvent();

	//¼ÆËãµ±Ç°Ê±¼ä
	$current = strtotime(date("Y-m-d", time()));
	//²é¿´ÓÃ»§ÊÇ·ñ·ÖÏí¹ý
	$is = $invite->getIsInviteCache($act_id, 0, $uid, $current);
	//Logger::info("\n" . "does user share? " . $is . "\t");
	//Èç¹ûÓÃ»§½ñÌìÒÑ¾­·ÖÏí
	if ($is) {
		$error = 2;
		$data = array(
			'errno' => $error,
			'message' => "Äã½ñÌìÒÑ·ÖÏí¹ý"
		);
		return $data;
	}

	//½ñÌìÉÐÎ´·ÖÏí¹ý
	$invite->insert($act_id, array('uid' => 0, 'from_uid' => $uid, 'create_time' => $current));

	$data = array('errno' => $error);
	//Logger::info("\n" . "result value: " . var_export($data,true) . "\t");

	return $data;
}

/**
 * ÓÃÓÚ»ñÈ¡ÓÃ»§Ò»´ÎÒ¡½±µÄ½á¹û
 * @param $uid    :   ÓÃ»§id
 * @param $act_id :   »î¶¯id
 * 
 * @return JSONÊä³ö
 *   error        :   ´íÎóÂë  0 ÕýÈ· 
 *   success_code :   ÊÇ·ñÖÐ½±£¬ÓÐÔòÎª½±Ïî·µ»ØÂë£¨ÀàÐÍ¹Ì¶¨²»¿ÉËæ±ã±ä¸ü£©£¬0ÎªÃ»ÓÐÖÐ½±
 *   reward_detail:   ½±ÀøÏêÇé£¬ÓÅ»ÝÈ¯ÏêÇé
 *   reward_info  :   ¶Ò»»µÄÓÅ»Ý„»Åú´ÎºÅ
 *  
 *  ËµÃ÷:	Èç¹ûÒ¡ÖÐ½±Àø£¬Ôòsuccess_code=ÏàÓ¦µÄ·µ»ØÂë,reward_detailÊÇ½±ÀøÏêÇé
 *          Èç¹ûÒ¡ÖÐµÄÊÇ½ð±Ò½±Àø£¬Ôòsuccess_code=½ð±ÒµÄ·µ»ØÂë£¬reward_info Îª¿Õ¡£·ñÔò£¬µ±½ð±ÒÊýÁ¿´óÓÚÔ¤ÉèÖµÊ±£¬reward_info´æ·Å¶Ò»»µÄÓÅ»Ý„»Åú´ÎºÅ   
 *
 */
function rewardm_shake(){
	$uid = $_POST['uid'];
	$wg_skey = $_POST['award_kk'];
	//Logger::info("uid - {$uid}, skey - {$wg_skey}");
	$_COOKIE['uid'] = $uid;
	//$_COOKIE['wg_skey'] = $wg_skey;
	$_COOKIE['skey'] = $wg_skey;
	$_COOKIE['token'] = md5($uid . APP_LOGIN_RENEWAL_KEY);
	unset($_COOKIE['wg_skey']);
	$uid = IUser::getLoginUid();
	//$uid = $_GET['uid'];
	if (!$uid) {
		$error = 1;
		$data = array(
			'errno' => $error,
			'message' => "ÇëÄúÏÈµÇÂ¼,Ð»Ð»ÅäºÏ"
		);
		Logger::err("\n" . "please login first!" . "\t");
		return $data;
	}

	$act_id = $_POST['act_id'];
	$error = 0;
	if (!$act_id) {
		Logger::err("\n" . "act_id or uid are not positive integer" . "\t");
		$error = 2;
		$data = array(
			'errno' => $error,
			'message' => "ÇëÉèÖÃÕýÈ·µÄ»î¶¯ºÅ"
		);
		return $data;
	}
	//ÓòÃû¼ì²é
	/*if (!ComponentUtil::checkReferer(array('51buy.com', 'qq.com', 'icson.com',yixun.com))) {
		$error = 9;
		$data = array('errno' => $error);
		Logger::err("\n" . "domain name check failed" . "\t");
		return ToolUtil::gbJsonEncode($data);
	}*/
	//³õÊ¼»¯³é½±Àà
	$evtAward = new IEvtAward($act_id);
	if(!$evtAward->generalCheck()) {
		$error = 4;
		$data = array(
			'errno' => $error,
			'message' => "ÄãÒÑ¾­ÓÃ¹âÁË³é½±»ú»á"
		);
		Logger::err("\n" . "You have not lottery times" . "\t");
		return $data;
	}
	//½øÐÐ³é½±
	$rst = $evtAward->getAward();
	//³é½±Ê§°Ü
	if (!$rst) {
		$error = 5;
		$data = array(
			'errno' => $error,
			'message' => "³é½±Ê§°Ü"
		);
		Logger::err("\n" . "lottery failed" . "\t");

		return $data;
	}
	//³é½±½á¹û
	$awardResult = $evtAward->result;
	//È¡µÃÖÐ½±id
	$awardforId = $awardResult['id'];
	//È¡µÃ½ð±ÒÄ£ºóµÄÊýÁ¿
	//½ð±Ò½±Ïî±àºÅ
	$code = 2;
	//µ±ÓÃ»§ÖÐ½ð±ÒÊ±£¬¿´ÊÇ·ñ´ïµ½ÁËÔ¤ÉèÖµ
	if ($awardforId == $code) {
		//Logger::info("\n" . "ÓÃ»§³éÖÐÁË½ð±Ò!" . "\t");
		//µÃµ½ÓÃ»§½ð±ÒµÄÊýÁ¿
		$rs = lotteryge_getAwardNum($uid);
		if($rs['errno']){
				Logger::err("\n" . "³öÏÖ´íÎó" . "\t");
				if($rs['errno'] == 2){
				$error = 3;
				$data = array(
					'errno' => $error,
					'message' => "ÏàÍ¬Ê±¼äÄÚµã»÷´ÎÊý¹ý¶à£¬ÇëÄú5ÃëºóÔÙ³¢ÊÔ£¡"
				);
				return $data;
			}else{
				$error = 6;
				$data = array(
					'errno' => $error,
					'message' => "µÃµ½ÓÃ»§½±ÏîºÍÏàÓ¦µÄÊýÁ¿Ê§°Ü"
				);
				return $data;
			}
			//return array('errno'=> $rs['errno'], 'message'=>'³öÏÖ´íÎó!');
		}
		//Logger::info("\n" . "rs: " . var_export($rs,true) . "\t");

		$result = $rs['data'];
		foreach ($result as $oneAward) {
			if ($oneAward['lottery_code'] == $code) {
				$gold_num = $oneAward['count(*)'];
				break;
			}
		}

		//È¡µÃÄ£¼¸µÄÅäÖÃ£¨Ä¬ÈÏÉèÖÃÎª1£¬·ÀÖ¹´ËÖµÎª0ÒÔ×öÓàÊý£©
		$modNum = 1;
		$eventInfo = ToolUtil::gbJsonDecode($evtAward->getConfigInfo());
		$awardInfo = $eventInfo['coupon_datas'];
		foreach ($awardInfo as $daward) {
			if ($daward['id'] == $code) {
				$modNum = $daward['count'];
				if ($gold_num % $modNum == 0) {
					$batch_no = $daward['batch_no'];
				}
				break;
			}
		}

		Logger::err("\n" . "gold num: " . $gold_num . "\t"  . " default value: " . $modNum . "\t");
		//Logger::info("\n" . "batch no. :" . $batch_no . "\t");
		//·¢½±£¨·¢·Å³ýÁË½ð±ÒÒÔÍâµÄ½±Ïî ºÍ ½ð±Ò¶Ò»»µÄÓÅ»Ý„»Åú´ÎºÅ£©
		//Èç¹û½ð±ÒÊýÊÇÔ¤ÉèÖµµÄ±¶Êý,Ôò·¢·ÅÓÅ»Ý„»
		if($gold_num % $modNum == 0){
			//Logger::info("\n" . "½ð±Ò´ïµ½¶Ò½±Êý,·¢·ÅÓÅ»Ý„»" . "\t");
			//·¢·Å½±Æ·
			$ret = ICoupon::fetchCoupon($uid, $batch_no);
			if (!$ret) {
				$i = 0;
				while (!$ret) {
					$ret = ICoupon::fetchCoupon($uid, $batch_no);
					if ($ret) {
						break;
					}
					if ($i > 5) {
						break;
					}
					$i++;
				}
			}
			//Èç¹û·¢·ÅÓÅ»Ý„»Î´³É¹¦
			if(!$ret){
				//Logger::info("\n" . "ÓÅ»Ý„»·¢·ÅÊ§°Ü,ÐèÒª²¹·¢!" . "\t");
				Logger::err("\n" . $act_id . " sends coupon " . $batch_no . " to " . $uid ." failed");
				Logger::err("\n" . ICouponFetcher::$errCode . ' : ' . ICouponFetcher::$errMsg . "\t");
				qp_itil_write(SEND_COUPON_ALARM_KEY,"»î¶¯[$act_id]·¢ÓÅ»Ý„»[$batch_no]Ê§°Ü!");
				$mem_cache_q = Config::getMCQ('send_prize');
				if($mem_cache_q === false) {
					Logger::err('Failed to init mem cache queue.[' . Config::$errCode . ' : ' . Config::$errMsg . ']');
					qp_itil_write(SEND_COUPON_ALARM_KEY, "Á¬½Ó·¢½±ÏûÏ¢¶ÓÁÐÊ§°Ü£¡[$act_id : $batch_no]");
					
					$error = 7;
					$data = array(
						'errno' => $error,
						'message' => "·¢·ÅÓÅ»Ý„»Ê§°Ü!"
					);

					return $data;
					//throw new BaseException(Config::$errCode, Config::$errMsg);
				}
				
				$ret = $mem_cache_q->set(QUEUE_KEY, serialize(array(
					'act_id' => $act_id,
					'uid' => $uid,
					'batch_no' => $batch_no,
					'create_time' => date('Y-m-d H:i:s')
				)));
				if($ret === false || $ret === null) {
					Logger::err("Failed to add record to queue.[$act_id : $batch_no]");
					qp_itil_write(SEND_COUPON_ALARM_KEY, "ÉèÖÃ·¢½±ÐÅÏ¢Ê§°Ü£¡[$act_id : $batch_no]");
					
					$error = 8;
					$data = array(
						'errno' => $error,
						'message' => "·¢·ÅÓÅ»Ý„»Ê§°Ü!"
					);
					return $data;
					//throw new BaseException(ErrorConfig::getErrorCode('send_failed'), 'Failed to set prize information.');
				}
			}else{  //Èç¹û·¢·ÅÓÅ»Ý„»³É¹¦
				//×°ÅäkeyÖµ
				$cmemkey = $uid . '_swap_awart'; 
				//È¡µÃÓÃ»§µÄ¶Ò»»Ê±¼ä
				$rt=IDataCache::getData($cmemkey);
				if($rt !== FALSE){
					$swap_time = unserialize($rt);
					//½«µ±Ç°¶Ò»»Ê±¼ä¼ÓÈë
					array_push($swap_time,time());
				}else{
					//ÓÃ»§ÒÔÇ°Ã»ÓÐ¶Ò¹ý½±£¬µ±Ç°ÊÇµÚÒ»´Î¶Ò½±
					$swap_time = array();
					array_push($swap_time,time());
				}
				//½«ÐÂµÄ¶Ò»»ÊýÁ¿Ð´Èë
				IDataCache::setData($cmemkey,serialize($swap_time));
				//½«¶Ò½±µÄÓÅ»Ý„»Åú´ÎºÅÐ´Èëcmem
				$tmemkey = 'swap_awart_batch_no';
				IDataCache::setData($tmemkey,$batch_no);
			}
		}
	}
	
	if($batch_no){
		$batch_code = getAwardSuccessCode($act_id,$batch_no);
	}

	$data = array(
		'errno' => $error,
		'success_code' => $awardResult['success_code'],
		'reward_detail' => $awardResult['message'],
		'award_type' => $awardResult['select_award'],
		'reward_info' => $batch_code,
		'cdkey' => $awardResult['cdkey']
	);

	//Logger::info("\n" . "result value: " . var_export($data,true) . "\t");
	return $data;
}

/**
 * À­È¡ÓÃ»§ÀúÊ·Áì½±ÐÅÏ¢£¨ÍøÕ¾¶Ë£©
 * @param $uid         :   ÓÃ»§id
 * @param $act_id      :   »î¶¯id
 * @param $page        :   µ±Ç°Ò³Âë£¬Ä¬ÈÏ0
 * @param $page_size   :   Ã¿Ò³ÐÅÏ¢ÊýÁ¿£¬Ä¬ÈÏ10
 * 
 * @return JSONÊä³ö
 *        error        :   ´íÎóÂë  0 ÕýÈ· 
 *        history      :   Áì½±ÀúÊ·ÁÐ±í  °üÀ¨: success_code(int ÁìÈ¡³É¹¦·µ»Ø´úÂë),time(int Áì½±Ê±¼ä),extra(string ¶îÍâÐÅÏ¢)
 *    
 *
 */
/*function reward_history(){
	$uid = $_POST['uid'];
	$act_id = $_POST['act_id'];
	$error = 0;
	$reward_info = array();
	$act_id = intval($act_id);
	$uid = intval($uid);
	if (!$uid || !$act_id) {
		Logger::err("\n" . "act_id or uid are not positive integer" . "\t");
		$error = 1;
		$data = array('errno' => $error);
		return ToolUtil::gbJsonEncode($data);
	}
	//·ÀË¢
	if (IFreqLimit::checkAndAdd($uid, 2)) {
		$error = 1;
		$data = array('errno' => $error);
		Logger::err("\n" . "You click in short time" . "\t");

		return ToolUtil::gbJsonEncode($data);
	}
	//À­È¡ÓÃ»§ÀúÊ·Áì½±ÐÅÏ¢
	//³õÊ¼»¯³é½±Àà
	$evtAward = new IEvtAward($act_id);
	$rs = $evtAward->getUserAwardInfo($uid);
	if ($rs === false || !is_array($rs)) {
		$error = 1;
		Logger::err("\n" . "fetch award record failed" . "\t");
	}else{
		foreach ($rs as $award) {
			$event_info = ToolUtil::gbJsonDecode($award['event_info']);
			$one_award = array(
				'success_code' => $event_info['success_code'],
				'time' => $award['create_date'],
				'extra' => $event_info['message']
			);
			array_push($reward_info,$one_award);
		}
		Logger::info("\n" . "user all award record: " . var_export($reward_info,true) . "\t");
	}

	$data = array(
		'errno' => $error,
		'history' => $reward_info
	);

	return ToolUtil::gbJsonEncode($data);
}*/

/**
 * À­È¡ÓÃ»§ÀúÊ·Áì½±ÐÅÏ¢£¨ÎÞÏß£©
 * @param $uid         :   ÓÃ»§id
 * @param $act_id      :   »î¶¯id
 * @param $page        :   µ±Ç°Ò³Âë£¬Ä¬ÈÏ0
 * @param $page_size   :   Ã¿Ò³ÐÅÏ¢ÊýÁ¿£¬Ä¬ÈÏ10
 * 
 * @return JSONÊä³ö
 *        error        :   ´íÎóÂë  0 ÕýÈ· 
 *        history      :   Áì½±ÀúÊ·ÁÐ±í  °üÀ¨: success_code(int ÁìÈ¡³É¹¦·µ»Ø´úÂë),time(int Áì½±Ê±¼ä),extra(string ¶îÍâÐÅÏ¢)
 *   	  total        :   ×Ü¹²¶àÉÙÌõ¼ÇÂ¼
 *    
 *
 */
function rewardm_history(){
	$error = 0;
	$uid = $_POST['uid'];
	$wg_skey = $_POST['award_kk'];
	//Logger::info("uid - {$uid}, skey - {$wg_skey}");
	$_COOKIE['uid'] = $uid;
	//$_COOKIE['wg_skey'] = $wg_skey;
	$_COOKIE['skey'] = $wg_skey;
	$_COOKIE['token'] = md5($uid . APP_LOGIN_RENEWAL_KEY);
	unset($_COOKIE['wg_skey']);
	$uid = IUser::getLoginUid();
	//$uid = $_GET['uid'];
	if (!$uid) {
		$error = 1;
		$data = array(
			'errno' => $error,
			'message' => "ÇëÄúÏÈµÇÂ¼,Ð»Ð»ÅäºÏ"
		);
		Logger::err("\n" . "please login first!" . "\t");
		return $data;
	}
	$act_id = $_POST['act_id'];
	if (!$act_id) {
		Logger::err("\n" . "act_id is not right!" . "\t");
		$error = 2;
		$data = array(
			'errno' => $error,
			'message' => "»î¶¯ºÅÉèÖÃ²»ÕýÈ·"
		);
		return $data;
	}
	$page = $_POST['page'];
	$page_size = $_POST['page_size'];
	if (!isset($page)){
		$page = 0;
	}
	if (!isset($page_size)) {
		$page_size = 10;
	}
	$history = array();
	//·ÀË¢
	if (IFreqLimit::checkAndAdd($uid, 2)) {
		$error = 3;
		$data = array(
			'errno' => $error,
			'message' => "ÏàÍ¬Ê±¼äÄÚµã»÷´ÎÊý¹ý¶à£¬ÇëÄú5ÃëºóÔÙ³¢ÊÔ"
		);
		Logger::err("\n" . "You click in short time" . "\t");

		return $data;
	}
	
	//Òª¹ýÂËµÄ½±ÏîidÁÐ±í
	$filter = array(
		1,
		2            //½âÎö³É°Ë½øÖÆÁË£¬Òª×ª±ä³É10½øÖÆ
	);
	//À­È¡ÓÃ»§ÀúÊ·Áì½±ÐÅÏ¢
	//³õÊ¼»¯³é½±Àà
	$evtAward = new IEvtAward($act_id);
	//µÃµ½¼ÇÂ¼×ÜÊý
	$total = $evtAward->getUserWinAwardNum($uid,$filter);
	//Logger::info("\n" . "total is:" . $total . "\t");

	//¼ÆËã³öÒªµÃµÄ¼ÇÂ¼µÄ¿ªÊ¼ºÍ½áÊøÎ»ÖÃ
	$start = $page * $page_size;
	//µÃµ½Ö¸¶¨Ë÷Òý·¶Î§µÄ¼ÇÂ¼¼¯
	$rs = $evtAward->getUserSpecificAwardInfo($uid,$start,$page_size,$filter);
	if ($rs === false || !is_array($rs)) {
		$error = 4;
		Logger::err("\n" . "fetch user specific award record failed" . "\t");
	}else{
		foreach ($rs as $award) {
			/*$event_info = ToolUtil::gbJsonDecode($award['event_info']);*/
			//µÃµ½½±ÏîÃèÊöÐÅÏ¢
			$message = getAwardDescrip($act_id,$award['success_code']);
			$one_award = array(
				'success_code' => $award['success_code'],
				'time' => strtotime($award['create_time']),
				'cdkey' => $award['cdkey'],
				'extra' => $message
			);
			array_push($history,$one_award);
		}
		//Logger::info("\n" . "user specific award record: " . var_export($history,true) . "\t");
	}

	$data = array(
		'errno' => $error,
		'history' => $history,
		'total' => $total
	);

	//Logger::info("\n" . "result value: " . var_export($data,true) . "\t");

	return $data;
}

/**
 * À­È¡ÓÃ»§ÀúÊ·¶Ò½±ÐÅÏ¢£¨ÎÞÏß£©
 * @param $uid         :   ÓÃ»§id
 * @param $act_id      :   »î¶¯id
 * 
 * @return JSONÊä³ö
 *        error        :   ´íÎóÂë  0 ÕýÈ· 
 *        history      :   ¶Ò½±ÀúÊ·ÁÐ±í  °üÀ¨: success_code(int ÁìÈ¡³É¹¦·µ»Ø´úÂë),time(int Áì½±Ê±¼ä),extra(string ¶îÍâÐÅÏ¢)
 *    
 */
function rewardm_swaphistory(){
	$error = 0;
	$uid = $_POST['uid'];
	$wg_skey = $_POST['award_kk'];
	//Logger::info("uid - {$uid}, skey - {$wg_skey}");
	$_COOKIE['uid'] = $uid;
	//$_COOKIE['wg_skey'] = $wg_skey;
	$_COOKIE['skey'] = $wg_skey;
	$_COOKIE['token'] = md5($uid . APP_LOGIN_RENEWAL_KEY);
	unset($_COOKIE['wg_skey']);
	$uid = IUser::getLoginUid();
	//$uid = $_GET['uid'];
	if (!$uid) {
		$error = 1;
		$data = array(
			'errno' => $error,
			'message' => "ÇëÄúÏÈµÇÂ¼,Ð»Ð»ÅäºÏ"
		);
		Logger::err("\n" . "please login first!" . "\t");
		return $data;
	}
	$act_id = $_POST['act_id'];
	if (!$act_id) {
		Logger::err("\n" . "act_id is not right!" . "\t");
		$error = 2;
		$data = array(
			'errno' => $error,
			'message' => "»î¶¯ºÅÉèÖÃ²»ÕýÈ·"
		);
		return $data;
	}

	$history = array();

	//²é¿´ÓÃ»§µ±Ç°ÊÇ·ñ¶Ò¹ý½±
	//×°ÅäkeyÖµ
	$cmemkey = $uid . '_swap_awart'; 
	//È¡µÃÓÃ»§µÄ¶Ò»»ÊýÁ¿
	$rt=IDataCache::getData($cmemkey);
	if($rt !== FALSE){
		$swap_time = unserialize($rt);
		//ÓÃ»§¶Ò¹ý½±
		if (count($swap_time)) {
			//È¡µÃ¶Ò½±±àºÅ
			$tmemkey = 'swap_awart_batch_no';
			$swap_batch_no = IDataCache::getData($tmemkey);
			//È¡µÃ¶Ò½±success_code
			$swap_success_code = getAwardSuccessCode($act_id,$swap_batch_no);
			//È¡µÃ½±ÏîÃèÊö
			$swap_message = getAwardDescrip($act_id,$swap_success_code);
			foreach ($swap_time as $key => $value) {
				$one_award = array(
					'success_code' => $swap_success_code,
					'time' => $value,
					'cdkey' => 0,
					'extra' => $swap_message
				);

			array_push($history,$one_award);
			}
		}
	}

	$data = array(
		'errno' => $error,
		'history' => $history
	);

	//Logger::info("\n" . "result value: " . var_export($data,true) . "\t");

	return $data;
}

/**
 * À­È¡×î½üONE_SUMÌõËùÓÐÓÃ»§ÖÐ½±ÐÅÏ¢½Ó¿Ú£¨ONE_SUMÄ¬ÈÏÎª30£©£¬²¢±£´æµ½ÎÄ¼þÖÐ
 * @param $act_id      :   »î¶¯id
 * 
 * @return Í¨¹ýJSON¸ñÊ½Êä³öµ½ÎÄ¼þ
 *        error        :   ´íÎóÂë  0 ÕýÈ· 
 *    reward_info      :   ×î½üNÌõËùÓÐÓÃ»§ÖÐ½±ÐÅÏ¢  °üº¬: uid(int ÓÃ»§uid),success_code(int ÁìÈ¡³É¹¦·µ»Ø´úÂë),Time(ÖÐ½±Ê±¼ä int)
 *    
 *
 */
/*function rewardm_nallAward(){
	$act_id = $_GET['act_id'];
	$error = 0;
	$reward_info = array();
	if (!$act_id) {
		Logger::err("\n" . "act_id is not positive integer" . "\t");
		$error = 1;
	}else{
		//À­È¡×î½üONE_SUMÌõËùÓÐÓÃ»§ÖÐ½±ÐÅÏ¢
		//³õÊ¼»¯³é½±Àà
		$evtAward = new IEvtAward($act_id);
		//À­È¡×î½üONE_SUMÌõËùÓÐÓÃ»§ÖÐ½±ÐÅÏ¢
		$rs = $evtAward->getNAllUsersAwardInfo(ONE_SUM);
		if ($rs === false || !is_array($rs)) {
			$error = 1;
			Logger::err("\n" . "fetch award record failed" . "\t");
		}else{
			foreach ($rs as $award) {
				$event_info = ToolUtil::gbJsonDecode($award['event_info']);
				$one_award = array(
					'uid' => $award['uid'],
					'lottery_code' => $award['lottery_code'],
					'success_code' => $event_info['success_code'],
					'time' => $award['create_date']
				);
				array_push($reward_info,$one_award);
			}
			Logger::info("\n" . "all award record: " . var_export($reward_info,true) . "\t");
		}
	}
	if ($error) {
		$data = array('errno' => $error);
		$result = ToolUtil::gbJsonEncode($data);
	}else{
		$data = array(
			'errno' => 0,
			'reward_info' => $reward_info
		);

		Logger::info("\n" . "result value: " . var_export($data,true) . "\t");
		$result = ToolUtil::gbJsonEncode($data);
	}

	Logger::info("\n" . "JSON data: " . $result . "\t");
	//½«×ª»»ºóµÄJSON¸ñÊ½Êý¾ÝÐ´ÈëÎÄ¼þ
	$filename = FILE_NAME . "awards_" . $act_id . ".js";
	var_dump($filename);
	$fp = fopen($filename, 'w+');
	if ($fp === false){
		Logger::err("\n" . "open w file failed!" . $filename . "\t");
	}
	if (fwrite($fp, $result) === false) {
		Logger::err("\n" . "write file failed" . $filename . "\t");
		fclose($fp);
	}
	fclose($fp);
}*/

/**
 * µÃµ½»î¶¯½±ÏîÅäÖÃÐÅÏ¢½Ó¿Ú
 * @param $act_id      :   »î¶¯id
 * 
 * @return JSONÊä³ö
 *        error        :   ´íÎóÂë  0 ÕýÈ· 
 *    event_info       :   ½±ÏîÅäÖÃÐÅÏ¢  °üÀ¨: success_code£¨int£¬·µ»ØÂë£¬±êÊ¾²»Í¬µÄ½±ÏîÐÅÏ¢£©ºÍ reg_message£¨string£¬¶ÔÓ¦ÓÚÉÏÃæ·µ»ØÂëµÄ½±ÏîÏêÏ¸ÃèÊöÐÅÏ¢£©
 *    
 *
 */
function rewardm_getconfig(){
	$act_id = $_POST['act_id'];
	$error = 0;
	$config_info = array();
	if (!$act_id) {
		Logger::err("\n" . "act_id is not right!" . "\t");
		$error = 2;
	}else{
		//»ñÈ¡ÅäÖÃÐÅÏ¢
		/*$ipEvent = new ILotteryEvent();
		$rs = $ipEvent->getAwardConfigInfo($act_id);*/
		$evtAward = new IEvtAward($act_id);
		$rs = $evtAward->getConfigInfo();
		$event_info = ToolUtil::gbJsonDecode($rs);
		$extra_info = $event_info['coupon_datas'];
		if ($extra_info === false || !is_array($extra_info)) {
			$error = 2;
			Logger::err("\n" . "get sub config info failed" . "\t");
		}else{
			foreach ($extra_info as $result_info) {
			$one_award = array(
				'image_url'    =>  $result_info['coupon_detail'],
 				'success_code' => $result_info['return_code'],
				'reg_message' => $result_info['return_msg'],
				'type_id'    =>  $result_info['select_award']
			);
			array_push($config_info,$one_award);		
			}
		}
			
		//Logger::info("\n" . "all config info: " . var_export($config_info,true) . "\t");
		
	}

	$data = array(
		'errno' => $error,
		'config_info' => $config_info
	);

	//Logger::info("\n" . "result value: " . var_export($data,true) . "\t");

	return $data;
}

/**
 * ¸ù¾Ý·µ»ØcodeµÃµ½ÏàÓ¦µÄ½±ÏîÃèÊö
 * @param $success_code      :   ÁìÈ¡³É¹¦·µ»Øcode
 * @param $act_id   		 :   »î¶¯id
 * 
 * @return 
 *        false        :   ³öÏÖ´íÎó 
 *    			       :   ¶ÔÓ¦ÓÚ·µ»Ø´úÂëµÄ½±ÏîÃèÊöÐÅÏ¢
 *    
 *
 */
function getAwardDescrip($act_id,$success_code){
	//»ñÈ¡ÅäÖÃÐÅÏ¢
	$evtAward = new IEvtAward($act_id);
	$rs = $evtAward->getConfigInfo();
	$event_info = ToolUtil::gbJsonDecode($rs);
	$extra_info = $event_info['coupon_datas'];
	if ($extra_info === false || !is_array($extra_info)) {
		Logger::err("\n" . "get sub config info failed" . "\t");
		return false;
	}else{
		foreach ($extra_info as $result_info) {
			if ($result_info['return_code'] == $success_code) {
				return $result_info['return_msg'];
			}
		}
		return false;
	}
}


/**
 * ¸ù¾Ý·µ½±ÏîidµÃµ½succes_code
 * @param $id                :   ½±Ïîid
 * @param $act_id   		 :   »î¶¯id
 * 
 * @return 
 *        false        :   ³öÏÖ´íÎó 
 *    			       :   ¶ÔÓ¦ÓÚ·µ»Ø´úÂëµÄ½±ÏîÃèÊöÐÅÏ¢
 *    
 *
 */
function getAwardSuccessCode($act_id,$id){
	//»ñÈ¡ÅäÖÃÐÅÏ¢
	$evtAward = new IEvtAward($act_id);
	$rs = $evtAward->getConfigInfo();
	$event_info = ToolUtil::gbJsonDecode($rs);
	$extra_info = $event_info['coupon_datas'];
	if ($extra_info === false || !is_array($extra_info)) {
		Logger::err("\n" . "get sub config info failed" . "\t");
		return false;
	}else{
		foreach ($extra_info as $result_info) {
			if ($result_info['id'] == $id) {
				return $result_info['return_code'];
			}
		}
		return false;
	}
}

?>