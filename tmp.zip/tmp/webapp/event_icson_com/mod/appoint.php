<?php

function appoint_getConfig() {
	try {
		$params = ToolUtil::array_fetch($_GET, array(
			'act_id' => array( 'allowEmpty' => false, 'secureType' => 'int' )
		));
		
		$appoint_config = IActAppoint::getAppointConfig($params['act_id']);
		if($appoint_config === false) {
			Logger::err('Error ' . IActAppoint::$errCode . ' : ' . IActAppoint::$errMsg);
			throw new BaseException(2, "ԤԼ�δ�ҵ�");
		}
		
		$verify_params = IVerifyConfig::checkParameterNeeded(ACT_TYPE_APPOINT, $params['act_id'], 0);
		if($verify_params === false) {
			Logger::err('Error ' . IVerifyConfig::$errCode . ' : ' . IVerifyConfig::$errMsg);
			throw new BaseException(500, '����������');
		}
		
		$count = IActAppoint::getAppointCount($params['act_id']);
		if($count === false) {
			throw new BaseException(13, '��ȡԤԼ����ʧ��');
		}
		
		$default_values = array();
		$hasAppointed = false;
		$uid = IUser::getLoginUid();
		if(!empty($uid)) {
			$userInfo = IUser::getUserInfo($uid);
			if($userInfo !== false) {
				if(!empty($userInfo['mobile'])) {
					$default_values['phone'] = $userInfo['mobile'];
				}
			} else {
				Logger::err('Error ' . IUser::$errCode . ' : ' . IUser::$errMsg);
			}
			
			$hasAppointed = IActAppoint::hasAppointed($params['act_id'], $uid);
		}
		
		return array( 'errno' => 0, 'data' => array( 
			'config' => $appoint_config['params'], 
			'params' => $verify_params, 
			'default' => $default_values,
			'hasAppointed' => $hasAppointed,
			'count' => $count
		));
	} catch (BaseException $e) {
		return array( 'errno' => $e->errCode, 'errmsg' => $e->errMsg );
	}
}

function appoint_page() {
	try {
		$params = ToolUtil::array_fetch($_POST, array(
			'act_id' => array( 'allowEmpty' => false, 'secureType' => 'int' )
		));
		
		$uid = IUser::getLoginUid();
		if(empty($uid)) {
			throw new BaseException(1, '�û�δ��¼');
		}
		
		// ԤԼ���
		_precheck($params['act_id'], $uid);
		
		$config = IActAppoint::getAppointConfig($params['act_id']);
		if($config === false) {
			Logger::err('Error ' . IActAppoint::$errCode . ' : ' . IActAppoint::$errMsg);
			throw new BaseException(2, "ԤԼ�δ�ҵ�");
		}
		
		// ԤԼ
		$ip = ToolUtil::getClientIP();
		$appoint_params = _get_appoint_parameter($config['params']);
		if(isset($appoint_params['vcode'])) {
			// ��Ҫ��֤
			if(empty($appoint_params['vcode'])) {
				// δ������֤��
				throw new BaseException(4, "��Ҫ��֤��");
			} else {
				$ret = IVerify::checkMobileVerifyCode($uid, $appoint_params['vcode'], $appoint_params[IActAppoint::VALUE_TYPE_PHONE]);
				if($ret === false) {
					Logger::err('Error ' . IVerify::$errCode . ' : ' . IVerify::$errMsg);
					throw new BaseException(6, '��֤ʧ��');
				}
				unset($appoint_params['vcode']);
			}
		}
		$ret = IActAppoint::appoint($params['act_id'], $uid, $ip, $appoint_params);
		if($ret === false) {
			Logger::err('Error ' . IActAppoint::$errCode . ' : ' . IActAppoint::$errMsg);
			throw new BaseException(5, "ԤԼʧ��");
		}
		if(isset($verify_params['order_id'])) {
			$ret = IVerifyConfig::addVerifyObjectMap(ACT_TYPE_APPOINT, $params['act_id'], OBJECT_TYPE_ORDER, $verify_params['order_id'], $uid);
			if($ret === false) {
				Logger::err('Error ' . IVerifyConfig::$errCode . ' : ' . IVerifyConfig::$errMsg);
			}
		}
		
		return array( 'errno' => 0 );
	} catch (BaseException $e) {
		return array( 'errno' => $e->errCode, 'errmsg' => $e->errMsg );
	}
}

function appoint_getVerifyCode() {
	try {
		$params = ToolUtil::array_fetch($_POST, array(
			'act_id' => array( 'allowEmpty' => false, 'secureType' => 'int' ),
			'phone' => array( 'allowEmpty' => false, 'secureType' => 'string' )
		));
		
		$uid = IUser::getLoginUid();
		if(empty($uid)) {
			throw new BaseException(1, '�û�δ��¼');
		}
		
		// �û���ϢԤ��
		_precheck($params['act_id'], $uid);
		
		$ret = IFreqLimit::checkAndAdd($uid, 7);
		if ($ret > 0) {
			throw new BaseException(10, '����̫Ƶ�������Ժ�����');
		}
		
		$ret = ComponentUtil::checkTimeLock("phone_{$params['phone']}_aid_{$params['act_id']}");
		if($ret === false) {
			throw new BaseException(ExtraErrorConfig::getErrorCode('over_freq_limit'), 'һ������ֻ�ܷ���һ�Σ�');
		}
		
		$code = IVerify::getMobileVerifyCode($uid, $params['phone']);
		if($code === false) {
			Logger::err('Error ' . IVerify::$errCode . ' : ' . IVerify::$errMsg);
			throw new BaseException(12, '��ȡ��֤��ʧ��');
		}
		
		$config = IActAppoint::getAppointConfig($params['act_id']);
		$ret = IMessage::sendSMSMessage($params['phone'], "����{$config['title']}�����ֻ���֤����֤���ǣ�{$code}��������������֤��лл��[��Ѹ��]");
		if($ret === false) {
			Logger::err('Error ' . IMessage::$errCode . ' : ' . IMessage::$errMsg);
			throw new BaseException(11, '������֤��ʧ��');
		}
		
		// ����ʱ����
		ComponentUtil::setTimeLock("phone_{$params['phone']}_aid_{$params['act_id']}", 60);
		
		return array( 'errno' => 0/*, 'vcode' => "{$params['phone']}, ����{$config['title']}�����ֻ���֤����֤���ǣ�{$code}��������������֤��лл��[��Ѹ��]"*/ );
	} catch (BaseException $e) {
		return array( 'errno' => $e->errCode, 'errmsg' => $e->errMsg );
	}
}

function appoint_hasAppointed() {
	try {
		$params = ToolUtil::array_fetch($_GET, array(
			'act_id' => array( 'allowEmpty' => false, 'secureType' => 'int' )
		));
		
		$uid = IUser::getLoginUid();
		if(empty($uid)) {
			throw new BaseException(1, '�û�δ��¼');
		}
		
		$ret = IActAppoint::hasAppointed($params['act_id'], $uid);
		
		return array( 'errno' => 0, 'data' => $ret );
	} catch (BaseException $e) {
		return array( 'errno' => $e->errCode, 'errmsg' => $e->errMsg );
	}
}

function appoint_getCount() {
	try {
		$params = ToolUtil::array_fetch($_GET, array(
			'act_id' => array( 'allowEmpty' => false, 'secureType' => 'int' )
		));
		
		$ret = IActAppoint::getAppointCount($params['act_id']);
		if($ret === false) {
			throw new BaseException(IActAppoint::$errCode, IActAppoint::$errMsg);
		}
		
		return array( 'errno' => 0, 'data' => $ret );
	} catch (BaseException $e) {
		return array( 'errno' => $e->errCode, 'errmsg' => $e->errMsg );
	}
}

function _get_verify_parameter($act_id) {
	$param_config = IVerifyConfig::checkParameterNeeded(ACT_TYPE_APPOINT, $act_id, 0);
	$params = array();
	foreach ($param_config as $name) {
		switch ($name) {
			case 'order_id':
				$tmp = ToolUtil::array_fetch($_POST, array(
					'order_id' => array( 'allowEmpty' => false, 'secureType' => 'int' )
				));
				$params['order_id'] = $tmp['order_id'];
				break;
			default:
				break;
		}
	}
	return $params;
}

function _get_appoint_parameter($config) {
	$params = array();
	foreach ($config as $k => $c) {
		switch ($k) {
			case IActAppoint::VALUE_TYPE_PHONE:
				if($c['check']) {
					$tmp = ToolUtil::array_fetch($_POST, array(
						'phone' => array( 'allowEmpty' => false, 'secureType' => 'string' ),
						'vcode' => array( 'default' => '', 'secureType' => 'string' )
					));
					$params['vcode'] = $tmp['vcode'];
					$params[IActAppoint::VALUE_TYPE_PHONE] = $tmp['phone'];
				} else {
					$tmp = ToolUtil::array_fetch($_POST, array(
						'phone' => array( 'allowEmpty' => false, 'secureType' => 'string' )
					));
					$params[IActAppoint::VALUE_TYPE_PHONE] = $tmp['phone'];
				}
				break;
			default:
				break;
		}
	}
	if(isset($_COOKIE['y_source'])) {
		$params[IActAppoint::VALUE_TYPE_YTAG] = $_COOKIE['y_source'];
	}
	return $params;
}

function _precheck($act_id, $uid) {
		
	$config = IActAppoint::getAppointConfig($act_id);
	if($config === false) {
		Logger::err('Error ' . IActAppoint::$errCode . ' : ' . IActAppoint::$errMsg);
		throw new BaseException(2, "ԤԼ�δ�ҵ�");
	}
	
	// �ж�ԤԼʱ��
	$now = time();
	if($now < $config['start_time'] || $now > $config['end_time']) {
		throw new BaseException(3, "�������Ч��");
	}
	
	$cur_count = IActAppoint::getAppointCount($act_id);
	if(!empty($config['count_limit']) && $cur_count >= $config['count_limit']) {
		throw new BaseException(9, 'ԤԼ��������');
	}
	
	// �ж�ԤԼ�ʸ�
	$verify_params = _get_verify_parameter($act_id);
	$ret = IVerifyConfig::verify(ACT_TYPE_APPOINT, $act_id, 0, $verify_params);
	if($ret === false) {
		if(IVerifyConfig::$errCode === 0) {
			$failedInfo = IVerifyConfig::getFailedInfo();
			throw new BaseException(20 + $failedInfo['verify_type'], $failedInfo['err_msg'] );
		} else {
			Logger::err('Error ' . IVerifyConfig::$errCode . ' : ' . IVerifyConfig::$errMsg);
			throw new BaseException(IVerifyConfig::$errCode, '����������' );
		}
	}
	
	// �ж��Ƿ��Ѿ�ԤԼ
	if(IActAppoint::hasAppointed($act_id, $uid)) {
		throw new BaseException(7, '�����ظ�ԤԼ');
	}
	
	$appoint_params = _get_appoint_parameter($config['params']);
	if(isset($appoint_params[IActAppoint::VALUE_TYPE_PHONE])) {
		if($config['params'][IActAppoint::VALUE_TYPE_PHONE]['check']) {
			// �ж��ֻ����Ƿ�ʹ��
			if(IActAppoint::isExistValue($act_id, IActAppoint::VALUE_TYPE_PHONE, $appoint_params[IActAppoint::VALUE_TYPE_PHONE])) {
				throw new BaseException(8, '�ֻ����ѱ�ʹ��');
			}
		}
	}
}