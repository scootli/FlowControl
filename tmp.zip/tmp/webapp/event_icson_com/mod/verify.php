<?php

function verify_user() {
	try {
		$p = ToolUtil::array_fetch($_GET, array(
			'type' => array( 'allowEmpty' => false, 'secureType' => 'int' )
		));
		$type = $p['type'];
		$params = _get_parameter($type);
		if(IVerifyConfig::verifyUser($type, $params)) {
			return array( 'errno' => 0 );
		} else {
			if(IVerifyConfig::$errCode === 0) {
				$errInfo = IVerifyConfig::getFailedInfo();
				return array( 'errno' => $errInfo['err_code'], 'errmsg' => $errInfo['err_msg'] );
			} else {
				return array( 'errno' => IVerifyConfig::$errCode, 'errmsg' => IVerifyConfig::$errMsg );
			}
		}
	} catch(BaseException $e) {
		Logger::err($e->errCode . ' : ' . $e->errMsg);
		return array( 'errno' => $e->errCode );
	}
}

function _get_parameter($type) {
	switch ($type) {
		default:
			return array();
	}
}

function verify_checkQQVipInActivity() {
	try {
		$params = ToolUtil::array_fetch($_GET, array(
			'mp' => array( 'allowEmpty' => false, 'secureType' => 'string' )
		));
		
		$mps = explode('_', $params['mp']);
		
		$uid = IUser::getLoginUid();
		if(empty($uid)) {
			throw new BaseException(ExtraErrorConfig::getErrorCode('user_not_found'), '�û�δ��¼��');
		}
		
		$qq = IQQVerifier::getQQByUid($uid);
		if($qq === false) {
			throw new BaseException(ExtraErrorConfig::getErrorCode('get_qq_failed'), "��ȡQQ����ʧ�ܣ�");
		}
		
		foreach ($mps as $mp) {
			if(empty($mp)) {
				continue;
			}
			$ret = IQQVerifier::checkQQVipByMp($mp, $qq);
			if($ret > 0) {
				return array( 'errno' => 0, 'data' => 1 );
			}
		}
		return array( 'errno' => 0, 'data' => 0 );
			
	} catch(BaseException $e) {
		return array( 'errno' => $e->errCode, 'errmsg' => $e->errMsg );
	}
}