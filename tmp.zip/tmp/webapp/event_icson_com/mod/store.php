<?php
require_once(PHPLIB_ROOT . 'api/IPageCahce.class.php');
require_once(PHPLIB_ROOT . 'api/IReviewReply.php');
require_once(PHPLIB_ROOT . 'api/IReviews.php');
require_once(PHPLIB_ROOT . 'lib/Dirty.php');
require_once(PHPLIB_ROOT . 'lib/VerifyCode.php');
require_once(PHPLIB_ROOT . 'inc/constant.inc.php');

Logger::init();

/**
 * JSON �ӿڣ�����콢���վ��
 * @return string
 */
function store_checksite() {
	global $_Wh_id;
	$storeId = isset($_GET['storeId']) ? intval($_GET['storeId']) : 0;
	$whId = IUser::getSiteIdWrapper();
	$DB = Config::getDB('icson_admin_store');
	if (!$DB) {
		return '{falg:0, message:"��Ҫ�����콢����δ����!"}';
	} else {
		$sql = 'SELECT * FROM t_store WHERE id=' . $storeId;
		$rs = $DB->getRows($sql);
		if ($rs === false || !isset($rs[0]['where_id'])) {
			return '{falg:0, message:"��Ҫ�����콢����δ����!"}';
		} else {
			$storeWhId = $rs[0]['where_id'];
			if($storeWhId && $storeWhId != $whId) {
				$storeUrl = isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'http://event.yixun.com/store/' . $storeId . substr(md5($storeId), 0, 4) . '.html';
				$storeUrl = '\"' . $storeUrl . '\"';
				$message  = '��Ҫ���ʵ��콢������Ѹ��-' . $_Wh_id[$storeWhId] . 'վ���콢��!<br /><br />';
				$message .= '<span style=\"margin-right:5px\"><a href=\"#\" style=\"background: #06c; color:#ffffff; text-decoration:none; padding:5px 10px; font-size:12px; font-weight:normal;\" onclick=\'G.app.switchSite.tryToSwitchTo(' . $storeWhId . ', ' . $storeUrl . ');\'>������Ѹ��-' . $_Wh_id[$storeWhId] . 'վ����</a></span>';
				$message .= '<span><a style=\"background: #ccc; color:#ffffff; text-decoration:none; padding:5px 10px; font-size:12px; font-weight:normal;\" href=\"http://www.yixun.com\">��վ��������</a></span>';
				return '{flag:0, message:"' . $message . '"}';
			} else {
				return '{flag:1}';
			}
		}
	}
}








