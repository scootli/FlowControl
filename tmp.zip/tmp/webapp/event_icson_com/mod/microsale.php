<?php
require_once(WEB_PAGE_ROOT . 'inc/microsale.inc.php');
require_once(PHPLIB_ROOT . 'api/IProductInventory.php');

Logger::init();

function microsale_getinfo()
{
	global $_WEBSITE_CFG;
	
	$pid = isset($_POST['itemCode'])?intval($_POST['itemCode']):intval($_GET['itemCode']);
		
	$wid = IUser::getSiteId(1); //ǿ���Ϻ�վ
	$result = array();
	
	if(!checkPid($pid))
	{
		$result['errorCode'] = 101;
		$result['errorMessage'] = "��Ʒ��Ŵ���";
		return $result;
	}
			
	$key = "event_microsale_20111114_".$pid;
	$ret = IPageCahce::getCacheData($key);
//	$ret = false;//��ʱ��������
	if( $ret==false )
	{
		$EDMcodeInfo =  getEDMCodeInfo($pid);
		if( $EDMcodeInfo==false || empty($EDMcodeInfo) )
		{
			$result['errorCode'] = 101;
			$result['errorMessage'] = "��ȡedm�۸�ʧ�ܣ�";
			return $result;
		}
		
		$stock = getProductStock($pid);
		if( $stock===false )
		{
			$result['errorCode'] = 101;
			$result['errorMessage'] = "��ȡ��Ʒ���ʧ�ܣ�";
			return $result;
		}
		$commInfo = IProductCommonInfoTTC::get($pid);
		if( $commInfo==false || empty($commInfo) )
		{
			$result['errorCode'] = 101;
			$result['errorMessage'] = "��ȡ��Ʒ����Ϣʧ�ܣ�";
			return $result;
		}
		
		$result['errorCode'] = 0;
		$result['errorMessage'] = "";	
		$result['itemCode'] = $pid;
		$result['itemName'] = $commInfo[0]['name'];
		$result['stockCount'] = $stock;
		$result['itemPrice'] = $EDMcodeInfo['EDMPrice']*100;
		$result['picLink'] = IProduct::getPic($commInfo[0]['product_char_id'], 'mm');
		$result['jumpUrl'] = "http://item.yixun.com/item-".$pid.".html";
		IPageCahce::setCacheData($key, serialize($result), 2);
	} else {
		$result = unserialize($ret);
	}
	return $result;
}

function microsale_setinfo()
{
	$result = array();
	$pid = 'BFE7CB0C00000000003F3B0D0001C7D8';
	$url = "http://10.16.78.65:8080/tshop/getActivityProgress.xhtml?format=json&itemCode=".$pid;
	$pid = 84248;
	$ret = NetUtil::cURLHTTPGet($url, 15, '');
	if( $ret == false )
		return array('errorCode'=>-101, 'errorMessage'=>'��ȡ��Ʒ�¼۸�ʧ�ܣ�');
	$info = ToolUtil::gbJsonDecode($ret);
	
	$EDMcodeInfo =  getEDMCodeInfo($pid);
	if( $EDMcodeInfo==false || empty($EDMcodeInfo) )
	{
		$result['errorCode'] = 101;
		$result['errorMessage'] = "��ȡedm�۸�ʧ�ܣ�";
		return $result;
	}
		
	$params = "EDMCode=".$EDMcodeInfo['EDMCode']."&ProductSysNo=".$pid."&EDMPrice=".$info['itemPrice'];
	$setUrl = 'http://192.168.17.65/Test.IAS/InternalService/EDMPrivilegesUpdate.ashx?'.$params;
	$retCode = NetUtil::cURLHTTPGet($setUrl, 15, '');
	if( intval($retCode) > 0  )
		return array('errorCode'=>0, 'errorMessage'=>'������Ʒ�۸�ɹ���');
	else
		return array('errorCode'=>-1, 'errorMessage'=>'������Ʒ�۸�ʧ�ܣ�');
}

function page_microsale_order()
{
	//$url = "http://a1.shop.qq.com/act.php?mod=checkuser&func=redirect&id=icson&url=http%3A%2F%2Fbase.51buy.com%2Findex.php%3Fmod%3Duser%26act%3Dloginqq%26url%3Dhttp%253A%252F%252Fevent.51buy.com%252Fmicrosale%252Forder.html%253Fpid%253D";
    $uid = IUser::getLoginUid();
    //$wid = IUser::getSiteId();
    $wid = IUser::getSiteId(1); //ǿ���Ϻ�վ
    if(!$uid)
    {
        echo '����û�е�¼��';
        _errorReloadPage();
        return;
    }

    $pid = empty($_GET['itemCode'])?0:intval($_GET['itemCode']);
    if( !$pid  || !$uid )
    {
        echo '�Ƿ����󣡲�������';
        _errorReloadPage();
        return;
    }

	if(!checkPid($pid))
	{
		echo "��Ʒ��Ŵ���";
		_errorReloadPage();
		return;
	}
	    
    $EDMcodeInfo =  getEDMCodeInfo($pid);
    if( $EDMcodeInfo==false || empty($EDMcodeInfo) )
    {
        echo '�Ƿ����󣡻�ȡEDM��ʧ�ܣ�';
        _errorReloadPage();
        return;
    }

    IShoppingCart::clear($uid, $wid);
    IShoppingCart::add($uid,
        array(
            'product_id' => $pid,
            'buy_count' => 1,
            'wh_id' => $wid
        )
    );
    setcookie('edm', $EDMcodeInfo['EDMCode'].'_'.$pid, null, '/', '.yixun.com');

    echo "<script type='text/javascript'> window.location.href='http://buy.yixun.com/order.html'; </script>";
    return ;
}

function _errorReloadPage()
{
    echo "<script type='text/javascript'> window.location.href='http://www.yixun.com'; </script>";
    return;
}

function getEDMCodeInfo($pid)
{
    $now = date('Y-m-d H:i:s');
    $sql = "select EDMCode, ProductSysNo, EDMPrice, IsMobileVerification, IsEmailVerification, MemberLevelRange
            from EDM_Privileges where EDMStatus=1 and StartDate <='" . $now . "' and EndDate >='" . $now . "'
            and ProductSysNo = $pid";
    $oldDB = Config::getMSDB('ERP_1');
    $ret = $oldDB->getRows($sql);
    if( $ret==false || empty($ret) )
        return false;
    return $ret[0];
}

function getProductStock($pid)
{
    //$sql = "select ProductSysNo as product_id, AvailableQty, VirtualQty from Inventory where ProductSysNo=".$pid;
    //$oldDB = Config::getMSDB('ERP_1');
    //$ret = $oldDB->getRows($sql);
    //if( $ret==false || empty($ret) )
    //    return false;
		
	//ixiuzeng���ӣ���ֲ���Ŀ�У���ȡ�����߼�
	$productsInventoryInfo = IProductInventory::getProductInventeory($pid, 1);
	if (false === $productsInventoryInfo)
	{
		self::$errCode = IProductInventory::$errCode;
		self::$errMsg = IProductInventory::$errMsg;
	
		return false;
	}
	else
	{
		return intval($productsInventoryInfo['num_available'] + $productsInventoryInfo['virtual_num']);
	}		
}

function checkPid($pid)
{
	global $eventMicroSale;
	$date = date('Y-m-d',time());
	if( isset($eventMicroSale['pids'][$date]) && in_array($pid, $eventMicroSale['pids'][$date]))
	{
		return true;
	} else 
	{
		return false;
	}
}
