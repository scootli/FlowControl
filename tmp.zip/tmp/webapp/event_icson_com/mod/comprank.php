<?php
Logger::init();


function comprank_getproduct()
{
	$id = intval($_GET['id']);
	$products = CompRank::getProducts($id);
	$lists = $products['list'];
	$data = CompRank::getData($id);
	$content = $data[0]['html'];
	
	$i = 0;
	foreach ($lists as $list) {
		$content = str_replace('{@productLink_' . $i . '}', 'http://item.yixun.com/item-' . $list['sysNo'] . '.html', $content);
		$content = __comprank_getpicurl($content, $i, $list['productID']);
		foreach ($list as $key => $value) {
			$content = str_replace('{@' . $key . '_' . $i . '}', $value, $content);
		}
		$i++;
	}
	return $content;
}

function __comprank_getpicurl($content, $i, $productId) {
	$pictypes = array('pd_pic800' => 'bpic',
					'pd_pic800m' => 'mpic',
					'pd_pic300' => 'mm',
					'pd_pic120' => 'middle',
					'pd_pic80' => 'small',
					'pd_pic50' => 'ss',
					'pd_pic200' => 'pic200,200',
					'pd_pic160' => 'pic160',
					'pd_pic60' => 'pic60',
					);
	foreach ($pictypes as $key => $picType) {
		$content = str_replace('{@' . $key . '_' . $i . '}' , IProduct::getPic($productId, $picType), $content);
	}
	return $content;
}