<?php
/*
 * ����ǰ��ҳ��Ե���ʱ����������¼�������JSON��ʽ����
 *
 * @Version	0.1
 * @Created	19:18 2012/07/11
 * @Author	EdisonTsai
 */

/*
 * ����ʣ��ʱ��
 *
 * @Return	array
 * @Modified by EdisonTsai on 16:02 2012/08/09 for split countdown type
 * @Modified by Edison tsai on 11:16 2012/07/18 for split the multi-times
 * @Created	19:20 2012/07/11
 * @Author EdisonTsai
 */
function compcountdown_getremaining(){

	$id	= isset($_GET['id']) ? (int)$_GET['id'] : 0;

	if(empty($id)){
		return array('res'=>0);
	}

	$rs = CompCountdown::getData($id);

	 if(!isset($rs['id']) || !isset($rs['future_time'])){
		return array('res'=>0);
	 }

	 //Split the future_time
	 $rs['future_time']	= explode(',', $rs['future_time']);

	  if(count($rs['future_time'])<1){
			return array('res'=>0);
	  }
	  
		#Added by EdisonTsai on 16:03 2012/08/09
		 if(empty($rs['type'])){
		 	
		 	$tmpArr = array();
		 	
		 	foreach($rs['future_time'] AS $k=>$v){
		 			if(!is_numeric($v)){ //Convert to current time
		 				array_push($tmpArr,strtotime($v));
		 			} #end if
		 	} #end foreach
		 	
		 	$rs['future_time']	=	$tmpArr;
		 	
		 	unset($tmpArr);
		 }

	 //Sorting by ASC
	 asort($rs['future_time']);
	
	  $tt = array(); //Target time
		
	  foreach($rs['future_time'] AS $k=>$v){
			
			if($v>time()){
				$tt[$k] = $v; break;
			}

	  } #end foreach

	  if($tt[$k] <= time()){
		return array('res'=>0);
	  }

	  $rs['callback'] = explode(',', $rs['callback']);

	 return array(
			'res'	=>	1,
			'tt'	=>	(int)$tt[$k],
			'ts'	=>	time(),
			'cb'	=>	isset($rs['callback'][$k]) && !empty($rs['callback'][$k]) ? $rs['callback'][$k] : ''
	 );

}
?>