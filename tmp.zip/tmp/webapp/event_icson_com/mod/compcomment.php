<?php
require_once(PHPLIB_ROOT . 'api/IPageCahce.class.php');
require_once(PHPLIB_ROOT . 'api/IReviewReply.php');
require_once(PHPLIB_ROOT . 'api/IReviews.php');
require_once(PHPLIB_ROOT . 'lib/Dirty.php');
require_once(PHPLIB_ROOT . 'lib/VerifyCode.php');
require_once(PHPLIB_ROOT . 'inc/constant.inc.php');

Logger::init();

//������Ӧ ajax ����

//������֤��
function compcomment_vcode(){
	VerifyCode::generateCodeNum();
	exit;
}

/**
 * ��Դ����������һ�����ۡ�
 * @param string $content
 */
function compcomment_addreview() {
	$uid = IUser::getLoginUid();
	if (empty($uid))	return  array( 'errno' => 500);
	if (empty($_GET['uid']) || $_GET['uid'] != $uid) return array( 'errno' => 501 );

	if (empty($_POST['codeNum'])) { //��֤��
		return array( 'errno' => 23);
	}
	else {
		$codeNum = strtolower(trim($_POST['codeNum']));
		$codeYes = VerifyCode::verifycodeNum($codeNum);
		if ($codeYes === false) {
			return array('errno' => 24, 'data' => json_encode(array($codeNum, VerifyCode::$errCode, VerifyCode::$errMsg)));
		}
	}

	if (empty($_POST['pid'])) return  array( 'errno' => 13);
	if (empty($_POST['content']) || strlen($_POST['content']) > 4000) return array( 'errno' => 12 );

	$promoId = $_POST['pid'];
	$content = isset($_POST['content']) ? trim($_POST['content']) : '';
	$content = Dirty::replaceDirty($content);
	$content = addslashes(htmlspecialchars($content));

	//����ֵ����
	$noLimit = isset($_POST['noLimit']) ? intval($_POST['noLimit']) : 0;
	if (!$noLimit) {
		$check = IReviewPromotion::checkUserExp_point($uid);
		if ($check !== true) {
			return $check;//����ֵС��20,���ܷ�������
		}
	}
	
	//������������
	$check = IReviewPromotion::checkUserReviewLimit($uid);
	if ($check === false) {
		return array('errno' => 600);//��֤ʧ��,�������ӻظ�
	}
	
	$add = IReviewPromotion::addPromotionReview($promoId, $uid, $content);
	//add by allenzhou 2011-11-22 ����������·ϵͳ ,����-1,����,�ظ�,��ѯ��Ϊ���ϸ�
	if($add == -1){
		return array('errno' => 777);
	}

	if ($add === false || !empty($add['errCode'])){
		Logger::err("IReviewPromotion::addPromotionReview failed, code: " . IReviewPromotion::$errCode . ', msg: ' . IReviewPromotion::$errMsg);
		return array( 'errno' => empty($add['errCode']) ? 6001 : $add['errCode'] );
	}

	return array( 'errno' => 0, 'data' => $add);
}

/**
 * ��Դ������һ�����ۣ�����һ���ظ���
 * @return Boolean �ɹ���ʧ��
 */
function compcomment_addreply() {
	if (empty($_POST['review_id'])) return array( 'errno' => 11 );

	$reviewId = $_POST['review_id'];
	$uid = IUser::getLoginUid();
	if (empty($uid)) return array( 'errno' => 500 );

	if (empty($_POST['codeNum'])) { //��֤��
		return array( 'errno' => 23);
	}
	else {
		$codeNum = strtolower(trim($_POST['codeNum']));
		$codeYes = VerifyCode::verifycodeNum($codeNum);
		if($codeYes === false){
			return array('errno' => 24);
		}
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) return array( 'errno' => 501 );
	if (empty($_POST['ruid'])) return array( 'errno' => 13 );
	if (empty($_POST['content']) || strlen($_POST['content']) > 4000) return array( 'errno' => 12 );

	$content = Dirty::replaceDirty($_POST['content']);
	$content = addslashes(htmlspecialchars($content));

	//����ֵ����
	$check = IReviewPromotion::checkUserExp_point($uid);
	if ($check !== true) {
		return $check;//����ֵС��20,���ܷ�������
	}
	
	//�ظ���������
	$check = IReply::checkUserReviewLimit($uid);
	if($check === false){
		return array('errno' => 600); //��֤ʧ��,�������ӻظ�
	}

	$add = IReply::addReply($reviewId, $uid, $_POST['ruid'] - 0, $_POST['type'] - 0, $content);
	//add by allenzhou 2011-11-22 ����������·ϵͳ ,����-1,����,�ظ�,��ѯ��Ϊ���ϸ�
	if($add == -1){
		return array('errno' => 777);
	}

	if ($add === false || !empty($add['errCode'])){
		Logger::err("IReply::addReply failed, code: " . IReply::$errCode . ', msg: ' . IReply::$errMsg);
		return array( 'errno' => empty($add['errCode']) ? 6001 : $add['errCode'] );
	}

	return array( 'errno' => 0, 'data' => $add['reply_id']);
}

/**
 * JSON �ӿڣ���ȡ��������
 * @return string
 */
function compcomment_getreviewscount() {
	if (empty($_GET['eventid'])){
		return '{errno:404}';
	}
	$eventId = $_GET['eventid'];
	$whId = IUser::getSiteId();

	$check = _validate_event_id($eventId, $whId);
	if ($check === true) {
		$reviewsCount = IReviewPromotion::getPromotionReviewCount($eventId);
		if ($reviewsCount === false){
			Logger::err('IReviewPromotion::getPromotionReview failed, code:' . IReviewPromotion::$errCode . ', msg:' . IReviewPromotion::$errMsg);
			return '{errno:500, errmsg:"' . IReviewPromotion::$errMsg . '"}';
		}
		return $reviewsCount;
	}
	else {
		return $check;
	}
}

/**
 * ��á����������Ӧ������
 * @return string
 */
function compcomment_getreviews() {
	if (empty($_GET['eventid'])){
		return '{errno:404}';
	}
	$eventId = $_GET['eventid'];
	$page = empty($_GET['page']) ? 1 : ($_GET['page'] - 0); // ��1��ʼ��
	$pageSize = isset($_GET['pagesize']) && !empty($_GET['pagesize']) ? intval($_GET['pagesize']) : IPromotionManager::$ReviewsPerPage;
	$whId = IUser::getSiteId();
	$check = _validate_event_id($eventId, $whId);
	if ($check === true) {
		$reviews = IReviewPromotion::getPromotionReview(
			$eventId,
			($page - 1) * $pageSize,
			$pageSize
		);

		if ($reviews === false){
			Logger::err('IReviewPromotion::getPromotionReview failed, code:' . IReviewPromotion::$errCode . ', msg:' . IReviewPromotion::$errMsg);
			return '{errno:500, errmsg:"' . IReviewPromotion::$errMsg . '"}';
		}
		_filter_review_list($reviews);
		return $reviews;
	}
	else {
		return $check;
	}
}

//�鿴��������
function compcomment_getreplylist(){
	if(empty($_GET['review_id'])){
		return array( 'errno' => 12 );
	}
	$reviewId = $_GET['review_id'];

	$begin = empty($_GET['begin']) ? 0 : intval($_GET['begin']);
	$quatity = empty($_GET['quatity']) || $_GET['quatity'] < 0 ? 0 : intval($_GET['quatity']);

	$replies = IReply::getReplies($reviewId, $_GET['type'] - 0, $begin, $quatity);
	if($replies === false){
		Logger::err('IReply::getReplies failed, code:' . IReply::$errCode . ', msg:' . IReply::$errMsg);
		return array( 'errno' => 6001 );
	}

	_filter_review_list($replies);
	return $replies;
}

/**
 * ��֤�����ID�Ƿ�Ϸ���
 * @param int $eventId �����ID
 * @param int $whId ��վID
 * @return Boolean �Ϸ���string ���Ϸ���������Ϣ
 */
function _validate_event_id($eventId, $whId) {
	if (empty($eventId) || !ToolUtil::checkInt($eventId)) {
		Logger::err('IPromotionManager::fetchPromotionMasterInfo error: ' . IPromotionManager::$errCode . '; ' . IPromotionManager::$errMsg);
		return '{errno:400, errmsg:"�û�����ڣ���л���Ĺ�ע"}';
	}
	/*
	$promoMaster = IPromotionManager::fetchPromotionMasterInfo($eventId, $whId);
	if (!$promoMaster) {
		Logger::err('IPromotionManager::fetchPromotionMasterInfo error: ' . IPromotionManager::$errCode . '; ' . IPromotionManager::$errMsg);
		return '{errno:400, errmsg:"�û�����ڣ���л���Ĺ�ע"}';
	}
	if (intval($promoMaster['Status']) != 0) { //�����״̬��0 valid / -1 invalid
		Logger::info('event.php::compcomment_getreviews: anonymous user check invalid promotion.');
		return '{errno:403, errmsg:"�û�Ѿ���������л���Ĺ�ע"}';
	}
	*/
	return true;
}

/**
 * ȥ�������в�Ӧ��ʾ����Ϣ
 * @param array $match
 * @return string
 */
function _replace_review_param($match){
	if ($match[1] == 'ip') return '"ip":""';

	if ($match[1] == 'user_name' || $match[1] == 'name') {
		$str = $match[2];
		$c = strlen($str);
		$str =  ($c > 4 ? substr_replace($str, "***", 2, $c-4) : $str);

		return '"' . $match[1] . '":"' . $str .  '"';
	}
}

/**
 * ��������
 * @param array $reviews
 */
function _filter_review_list(&$reviews){
	$reviews = preg_replace_callback(array(
		"/\"(ip|user_name|name)\":\"([^\"]*?)\"/",
	), '_replace_review_param', $reviews);
}









