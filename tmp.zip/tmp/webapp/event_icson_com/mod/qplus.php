<?php
Logger::init();

/**
 * ��¼51buy
 */
function page_qplus_icson() {
	error_reporting(E_ALL ^ E_NOTICE);
	header('P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR"');
	header('Content-Type:   text/html;   charset=gbk');
	require_once(WEB_PAGE_ROOT . 'lib/qplus_open.php');
	$app_openid = @$_GET["app_openid"];
	$app_openkey = @$_GET["app_openkey"];
	$qplus = new QPlusOpen("200201280","8FWqbDgnUAXLojSV");//xxxxxΪappid��yyyyyΪapp_secret
	//$url = $qplus->getLoginUrl();
	if($app_openid)
	{
		$userInfo = $qplus->getUserInfo($app_openid, $app_openkey);
		$nickName = $userInfo->info->nick;
		$nickName1 = urlencode(iconv("UTF-8", "GBK", $nickName));
		$nickName2 = iconv("UTF-8", "GBK", $nickName);
		setrawcookie("qplus_nick", $nickName1, 0, '/', '.yixun.com');
		setrawcookie("qplus_openid", $app_openid, 0, '/', '.yixun.com');
		setrawcookie("qplus_openkey", $app_openkey, 0, '/', '.yixun.com');
		if(_loginqq_autouser($app_openid, substr($app_openkey, 0, 10), $nickName2) === false) return;
		if (isset($_GET['url']) && preg_match("/^http:\/\/([^\.]+\.|)(51buy|icson|yixun)\.com/i", $_GET['url'])) {
			header("location: " . $_GET['url']);
		} else {
			header("location: http://act.yixun.com/index.php?mod=morningmarket&act=qplus");
		}
	}
}

function _loginqq_autouser($openID, $password, $nickname = ''){
	$message = '��¼ʧ��';
	$account = QQ_ACCOUNT_PRE . '_' . $openID; // ��ID�м�����һ���»���
	$exists = IUser::checkIcsonAccountExist($account);
	if ($exists === false) {
		Logger::err("user_loginqq IUser::checkIcsonAccountExist failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}

	$clientIp = ToolUtil::getClientIP();
	if ($exists['exist'] == 0) {
		$email = '';

		$regSrc = empty($_COOKIE['us']) ? '' : $_COOKIE['us'];			
		$userData = array(
				'email' => $email,
				'regIP' => $clientIp,
				'warehouseId' => IUser::getSiteId(),
				'source' => $regSrc
			);	
		$register = IUser::register($account, $password, $userData);
		if ($register === false) {
			if(IUser::$errCode != 10303){
				// �ظ�key���ɳɹ�
				Logger::err("user_loginqq IUser::register failed-" . IUser::$errCode . '-' . IUser::$errMsg);
				TemplateHelper::outMessage( $message );
				return false;
			}
		}
		// ��Ϣһ�� ��������login�ᱨ��
		// ��Ҫ��һ���Ż������������������
		sleep(1);
	}

	$session = IUser::login($account, $password, $clientIp, 1,  3);
	if ($session === false) {
		Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}


	setrawcookie("QQACCT", $openID, 0, '/', '.yixun.com');
	setrawcookie("new_u", false, 1, '/', '.yixun.com');
	$user = IUser::getUserInfo($session['uid']);
	if ($user === false) {
		Logger::err("IUser::getUserInfo failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}else if (isset($user['exp_point'])  && $user['exp_point'] <= 0)
	{
		//�������û�cookie
		setrawcookie("new_u", '1', 0, '/', '.yixun.com');
	}

	setrawcookie("uid", $session['uid'], 0, '/', '.yixun.com');
	setrawcookie("skey", $session['skey'], 0, '/', '.yixun.com', false, true);

	setrawcookie("qq_nick", $session['uid'] . '|' . ToolUtil::escape($nickname), 0, '/', 'yixun.com');
	//���QQ tips��������������֤��Ϣ
	if (isset($_GET['key'])) {
		if ((substr(md5($openID . "icson@qq"), 0 , 6) != $_GET['key'])) {
			TemplateHelper::outMessage( array("�Բ����������ϲμӴ˻������", '<a href="http://www.yixun.com">�ص���Ѹ��ҳ</a>') );
			return false;
		}else
		{
			setrawcookie("edm_key", $_GET['key'], 0, '/', '.yixun.com');
		}
	}
}
