<?php
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IEventIphone.php');
require_once(WEB_PAGE_ROOT . 'inc/iphone.inc.php');
Logger::init();

/**
 * ���ҳ
 */
function page_iphones_index() {
	$uid = IUser::getLoginUid();
	if (isset($_GET['uid'])) {
		$inviteUid = $_GET['uid'];
		$userInfo = IUser::getUserInfo($inviteUid);
		if (!empty($inviteUid) && $uid != $inviteUid && !empty($userInfo)) {
			setcookie('invite_uid', $inviteUid, time()+3600, '/', '.yixun.com');
		}
	}
	
	$op = array(
			'titleDesc' => '0Ԫ�齱Ӯiphone4s',
			"containerTPL" => 'iphones.tpl',
			'before_body' => implode("", array(
				TemplateHelper::getCSS("http://st.icson.com/static_v1/event/51buy_1031_iphone4s/css/style.css?v=1.3", false),
				TemplateHelper::getJS("http://st.icson.com/static_v1/event/51buy_1031_iphone4s/js/iphone.js?v=1.6", false),
			))
			
	);
	if (time() > strtotime("2011-12-4 00:00:00")) {
		$op = array(
					'titleDesc' => '0Ԫ�齱Ӯiphone4s',
					"containerTPL" => 'iphones.tpl',
					'before_body' => implode("", array(
		TemplateHelper::getCSS("http://st.icson.com/static_v1/event/51buy_1031_iphone4s/css/style_1.css?v=1.3", false),
		TemplateHelper::getJS("http://st.icson.com/static_v1/event/51buy_1031_iphone4s/js/iphone.js?v=1.6", false),
		))
			
		);
	}
	
	$TPL = TemplateHelper::getBaseTPL($op);
	global $win_user;
	global $weibo,$qqSpace,$email;
	$html = "";
	if (is_array($win_user) && isset($win_user[0])) {
		foreach ($win_user as $user) {
			$html .= "<tr><td>" . $user['name'] . "</td><td>" . $user['item'] . "</td></tr>";
		}
		$TPL->set_var("win_head", "<tr>
							<td>�н�����</td>
							<td><strong>ʱ��</strong></td>
						</tr>");
		$TPL->set_var("win_col", '<col class="td0"/>
						<col class="td1"/>');
	} else {
		$TPL->set_var("win_col", '<col class="td0"/>');
		$TPL->set_var("win_head", "");
		$html .= '<tr style="font-size:12px;color:black;"><td>ÿ���н�����Ϊ�����յ���������Ʊ��������н�����</td></tr><tr style="font-size:12px;color:black;"><td>��һ����н����뽫��11��25��22:00�㹫��</td></tr>';
	}
	$TPL->set_var("win_users", $html);
	$TPL->set_var("weibo_title", urlencode(iconv("GBK", "UTF-8", $weibo['title'])));
	$TPL->set_var("qzone_title", urlencode(iconv("GBK", "UTF-8", $qqSpace['title'])));
	$TPL->set_var("qzone_sum", urlencode(iconv("GBK", "UTF-8", $qqSpace['sum'])));
	$TPL->set_var("e_title", rawurlencode($email['title']));
	$TPL->set_var("e_body", rawurlencode($email['body']));
	$TPL->set_var("d_body", urlencode(iconv("GBK", "UTF-8", $email['body'])));
	$TPL->set_var("q_body", $email['body']);
	$TPL->set_var("uid", $uid);
	$TPL->out();
}

/**
 * �ж��Ƿ��¼
 */
function page_iphones_islogin() {
	$uid = IUser::getLoginUid();
	
	if ($uid > 0) {
		$userInfo = IUser::getUserInfo($uid);
		$username = $userInfo['icsonid'];
// 		if (strlen($username) > 16) {
// 			$qqNick = $_COOKIE['qq_nick'];
// 			$qqNickArr = explode('|', $qqNick);
// 			$username = $qqNickArr[1];
// 		}
		
		//$ieventIphone = new IEventIphone();
		//$isJoin = $ieventIphone->isJoin($uid);
		$out = 0;
		if (time() > strtotime("2011-12-4 00:00:00")) {
			$out = 1;
		}
		echo json_encode(array('rt' => 1, 
								'uid' => $uid, 
								'username' => $username,
								'email' => $userInfo['email'],
								'mobile' => $userInfo['mobile'],
		// @TODO
								'bindMobile' => $userInfo['bindMobile'],
								//'bindMobile' => '1',
								//'isJoin' => $isJoin,
								'out' => $out,
								)
						);
	} else {
		if (time() > strtotime("2011-12-4 00:00:00")) {
			echo json_encode(array('rt' => 2));
		} else {
			echo json_encode(array('rt' => 0));
		}
	}
}

/**
 * ��ȡ�Ѿ��ĵ��ĳ齱��
 */
function page_iphones_hasnumbers() {
	$uid = IUser::getLoginUid();
	$ieventIphone = new IEventIphone();
// 	$isJoin = $ieventIphone->isJoin($uid);
// 	if (!$isJoin) {
// 		echo json_encode(array('rt' => 0));
// 		return ;
// 	}
	if (time() > strtotime("2011-12-4 00:00:00")) {
		$out = 1;
	} else {
		$out = 0;
	}
	
	$data = $ieventIphone->getHasNumbers($uid);
	if (empty($data['has_number'])) {
		echo json_encode(array('rt' => 0, 'out' => $out));
		return ;
	}
	echo json_encode(array('rt' => 1, 'data' => $data, 'out' => $out));
}

/**
 * ��ȡ�齱��
 */
function page_iphones_activities() {
	$uid = IUser::getLoginUid();
	//δ��¼����
	if (empty($uid)) {
		echo json_encode(array('rt' => 0));
		return;
	}
	
	//δ��������,�����ֻ�δ�󶨷���
	$userInfo = IUser::getUserInfo($uid);
	// @TODO
	//$userInfo['bindMobile'] = 1;
	if (empty($userInfo['email']) || empty($userInfo['mobile']) || empty($userInfo['bindMobile'])) {
		echo json_encode(array('rt' => -1));
		return;
	}
	
	//��ȡ�齱��
	$ieventIphone = new IEventIphone();
	global $email_send,$sms_send;
	$ieventIphone->emailSend = $email_send;
	$ieventIphone->smsSend = $sms_send;
	if (time() > strtotime("2011-12-4 00:00:00")) {
		$data = $ieventIphone->getHasNumbers($uid);
		$out = 1;
	} else {
		$data = $ieventIphone->getNumbers($uid, $userInfo['icsonid']);
		$out = 0;
	}
	echo json_encode(array('rt' => 1, 'data' => $data, 'out' => $out));
}

/**
 * �μӻ������
 */
function page_iphones_usercount() {
	$ieventIphone = new IEventIphone();
	global $baseCount;
	$userCount = $ieventIphone->getUserCount($baseCount);
	$len = strlen($userCount);
	$data = array();
	if ($len < 7) {
		for ($i = 0;$i < (7-$len);$i++) {
			$data[] = '0';
		}
	}
	for ($j = 0;$j < $len;$j++) {
			$data[] = $userCount[$j];
	}
	echo json_encode($data);
}

/**
 * ת����Ѷ΢��
 */
function page_iphones_sharetqq() {
	//�����
	if (time() > strtotime("2011-12-4 00:00:00")) {
		echo json_encode(array('rt' => 0));
		return;
	}
	$uid = IUser::getLoginUid();
	//δ��¼����
	if (empty($uid)) {
		echo json_encode(array('rt' => 0));
		return;
	}
	
	//δ��������,�����ֻ�δ�󶨷���
	$userInfo = IUser::getUserInfo($uid);
	// @TODO
	//$userInfo['bindMobile'] = 1;
	if (empty($userInfo['email']) || empty($userInfo['mobile']) || empty($userInfo['bindMobile'])) {
		echo json_encode(array('rt' => -1));
		return;
	}
	$t = 3;
	if (isset($_GET['t'])) {
		$t = intval($_GET['t']);
	}
	//��ȡ�齱��
	$ieventIphone = new IEventIphone();
	global $email_send,$sms_send;
	$ieventIphone->emailSend = $email_send;
	$ieventIphone->smsSend = $sms_send;
	$data = $ieventIphone->getShareTqqNumbers($uid, $userInfo['icsonid'], $t);
	echo json_encode(array('rt' => 1, 'data' => $data));
}

function page_iphones_getvipqqinfo() {
	
	$uid = $_GET['uid'];
	$time = $_GET['time'];
	$nickname = $_GET['nickname'];
	$vipqqinfo = $_GET['vipqqinfo'];
	$vkey = $_GET['vkey'];
	
	$verify = md5 ( $uid . $time .$nickname. $vipqqinfo . "c26TyH_s8s" );
	
	if ($vkey == $verify) {
		setcookie("is_vip", $vipqqinfo, time() + 3600, '/', '.yixun.com');
	}
}
