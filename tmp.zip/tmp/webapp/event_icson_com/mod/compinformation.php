<?php
Logger::init();

//������Ӧ ajax ����

/**
 * �����ѯ�б�
 * @return string
 */
function compinformation_getlist() {
	$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
	$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
	if (!$id){
		return '{errno:404}';
	}
	$infoList = CompInformation::pageInformation($id, $page);
	return ToolUtil::gbJsonEncode($infoList);
}

function compinformation_getdetail() {
	$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
	if (!$id){
		return '{errno:404}';
	}
	$infoDetail = CompInformation::selectInformation('id=' . $id);
	if (!$infoDetail || !isset($infoDetail[0])) {
		return '{errno:404}'; 
	}
	return ToolUtil::gbJsonEncode($infoDetail[0]);
}










