<?php

/**
 * ��������������ڴ˷ַ����ɸ����Ͷ�Ӧ��action��cmd��Ӧ�ķ�������
 */
function component_dispatch() {
	try {
		$params = ArrayUtil::array_fetch($_REQUEST, array(
			'id' => array( 'allowEmpty' => false, 'secureType' => 'int' ),
			'cmd' => array( 'allowEmpty' => false, 'secureType' => 'string' )
		));
		
		if($params === false) {
			throw new BaseException(ExtraErrorConfig::getErrorCode('unexpected_request'), '�����������');
		}
		
		$component = IComponent::getCachedComponent($params['id']);
		if($component === false) {
			throw new BaseException(ExtraErrorConfig::getErrorCode('unexpected_request'), '�����Ϣ��ȡʧ�ܣ�');
		}
		if(!isset(ComponentConfig::$components[$component['type']])) {
			Logger::err("Unknown component type {$component['type']}.");
			throw new BaseException(ExtraErrorConfig::getErrorCode('server_error'), '����Ŀ�겻���ڣ�');
		}
		$className = ucfirst(ComponentConfig::$components[$component['type']]['name']) . 'Action';
		$methodName = $params['cmd'];
		
		$ret = ActionDispatcher::dispatch($className, $methodName, $component);
		if($ret === false) {
			throw new BaseException(ActionDispatcher::$errCode, ActionDispatcher::$errMsg);
		}
		Logger::info("COMPONENT_DISPATCHER : {$params['id']}\t{$component['type']}\t{$params['cmd']}\t{$_SERVER['QUERY_STRING']}\t" . ToolUtil::gbJsonEncode($ret) . "\t" . (isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : ''));
		
		return $ret;
	} catch(BaseException $e) {
		if($e->errCode < 1000) {
			Logger::warn($e->errCode . ' : ' . $e->errMsg);
			return array(
				'errno' => ExtraErrorConfig::getErrorCode('unknown_error'),
				'errmsg' => 'δ֪����'
			);
		}
		return array(
			'errno' => $e->errCode,
			'errmsg' => $e->errMsg
		);
	}
}

function page_component_vcode() {
	header('Content-type:image/jpeg');
	$ret = ComponentUtil::getVerifyCode();
	if($ret !== false) {
		setcookie("verifysession", $ret['sig']);
		echo $ret['img'];
	}
	exit;
}
