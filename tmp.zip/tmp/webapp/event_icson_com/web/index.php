<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/PHPLIB/lib/Config.php");

define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define('DAO_PATH', PHPLIB_ROOT."dao/");
define("WEB_PAGE_ROOT", WEB_ROOT . "event_icson_com/");
define('CACHE_PATH', '/tmp/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, DAO_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

require_once(WEB_PAGE_ROOT. 'inc/constant.inc.php');

// ��� module ��
if (!empty($_REQUEST['mod'])) {
	$mod_name = preg_replace("/[^a-zA-Z]/", '',trim($_REQUEST['mod']));
} else {
	$mod_name = 'main';
}

$siteInfo = IUser::getSiteInfo( empty($_GET['site_id']) || $_GET['site_id'] == 1 ? null : $_GET['site_id'] );

if ( false === $siteInfo) {
	IUser::redirectOldSite();
}

$mod_file = WEB_PAGE_ROOT . 'mod/'.$mod_name.'.php';

if ( !file_exists($mod_file)) {
	$mod_file = WEB_PAGE_ROOT . 'areas/'.$siteInfo['name'].'/mod/'.$mod_name.'.php';
	$tpl_directory = WEB_PAGE_ROOT . 'areas/'.$siteInfo['name'].'/tpl';

	if ( !file_exists($mod_file)) {
		$mod_file = WEB_PAGE_ROOT . 'areas/default/mod/'.$mod_name.'.php';
		$tpl_directory = WEB_PAGE_ROOT . 'areas/default/tpl';
	}
	define("DEFAULT_TPL_DIR", WEB_PAGE_ROOT . 'areas/default/tpl');
	define("CURRENT_TPL_DIR", $tpl_directory);
}

if ( !in_array($mod_name, $mod_list, true) || !file_exists($mod_file) ) {
	// ��¼���ʵ� url
	$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
	$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
	Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
	ToolUtil::redirect("http://www.yixun.com/");
}

// ��� act ��
if (!empty($_REQUEST['act'])) {
	$act_name = preg_replace("/[^a-zA-Z]/", '', trim($_REQUEST['act']));
} else {
	$act_name = 'page';
}

// ���html�ĺ���ǰ׺��page_����������json��
$func_name = 'page_' . $mod_name . '_' . $act_name;

require_once $mod_file;

if (!function_exists($func_name)) {
	$func_name = $mod_name . '_page';
	if (!function_exists($func_name)) {
		$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
		$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
		Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
		ToolUtil::redirect("http://www.yixun.com/");
	}
}

$func_name($siteInfo);
// End Of Script