<?php

define("IMG3_WEB_PAGE_ROOT", WEB_ROOT . "img3_icson_com/");

Logger::init();

require_once(WEB_PAGE_ROOT . 'lib/ImageGD.php');

/**
 * ͼƬ�ϳ�
 */
function img_compose() {
	$ret 		= array(
		'errno'		=> 0,
		'message'	=> '',
		'data'		=> null,
	);
	
	$event_id	= isset($_REQUEST['event_id']) ? intval($_REQUEST['event_id']) : 0;
	// $uid		= 111;
	$uid 		= IUser::getLoginUid();
	$ip			= ToolUtil::getClientIP();
	
	if (!$event_id) {
		$ret['errno']	= 101;
		$ret['message']	= 'event_id required';
		return $ret;
	}
	if (!$uid) {
		$ret['errno']	= 102;
		$ret['message']	= 'login required';
		return $ret;
	}
	
	// �����û� uid ��ˢ
	if (IFreqLimit::checkAndAdd($uid, 12) || IFreqLimit::checkAndAdd($uid, 13)) {
		$ret['errno']	= 103;
		$ret['message']	= 'times limit, please try it again later';
		Logger::err('uid times limit, uid: ' . $uid);
		return $ret;
	}
	// ���� ip ��ˢ
	if (IFreqLimit::checkAndAdd($ip, 14) || IFreqLimit::checkAndAdd($ip, 15)) {
		$ret['errno']	= 104;
		$ret['message']	= 'times limit, please try it again later';
		Logger::err('ip times limit, ip: ' . $ip);
		return $ret;
	}
	// return $ret;
	
	// д����ı�ע���ڵ��� writeText ʱ�ı�������
	$param_srcfile	= isset($_REQUEST['srcfile'])	? $_REQUEST['srcfile']			: '';
	$param_text		= isset($_REQUEST['text'])		? $_REQUEST['text']				: '';
	$param_text_x	= isset($_REQUEST['text_x'])	? intval($_REQUEST['text_x']) 	: 0;
	$param_text_y	= isset($_REQUEST['text_y'])	? intval($_REQUEST['text_y']) 	: 0;
	$param_width	= isset($_REQUEST['width'])		? intval($_REQUEST['width'])	: 0;
	$param_height	= isset($_REQUEST['height']) 	? intval($_REQUEST['height'])	: 0;
	$param_fontsize	= isset($_REQUEST['fontsize'])	? intval($_REQUEST['fontsize'])	: 12;
	$param_color	= isset($_REQUEST['color'])		? trim($_REQUEST['color'])		: '000000';
	$param_fontfile	= isset($_REQUEST['fontfile'])	? trim($_REQUEST['fontfile'])	: 'msyh.ttf';
	$param_angle	= isset($_REQUEST['angle'])		? intval($_REQUEST['angle'])	: 0;
	$param_quality	= isset($_REQUEST['quality'])	? intval($_REQUEST['quality'])	: 75;
	
	$date			= date('Y-m-d/H/i');
	if (($pos = strpos($param_srcfile, '.com')) !== false) {
		$src_pos_path = ltrim(substr($param_srcfile, $pos + 4), "/\\");
	} else {
		$src_pos_path = ltrim($param_srcfile, "/\\");
	}
	$src_filepath	= WEB_PAGE_ROOT . 'web/data/' . $src_pos_path;
	$dst_dir		= WEB_PAGE_ROOT . 'web/data/event/' . $date;
	$dst_filename	= $uid . '_' . $event_id . '_' . time() . '.' .strtolower(pathinfo($src_filepath, PATHINFO_EXTENSION));
	$dst_filepath	= $dst_dir . '/' . $dst_filename;
	
	if (!is_dir($dst_dir) && !@mkdir($dst_dir, 0777, true)) {
		$ret['errno']	= 105;
		$ret['message']	= 'make dir failed';
		return $ret;
	}
	
	$image		= new ImageGD($src_filepath);
	$result		= $image->writeText($param_text, array(
		'text_x'	=> $param_text_x,
		'text_y'	=> $param_text_y,
		'width'		=> $param_width,
		'height'	=> $param_height,
		'fontsize'	=> $param_fontsize,
		'color'		=> $param_color,
		'fontfile'	=> $param_fontfile,
		'angle'		=> $param_angle,
	), 'utf-8')->save($dst_filepath, $param_quality);
	
	if ($result) {
		$db_file_path	= $date . '/' . $dst_filename;
		$param = array(
			'event_id'		=> $event_id,
			'uid'			=> $uid,
			'createtime'	=> date('Y-m-d H:i:s'),
			'file_path'		=> $db_file_path,
			'content'		=> $param_text,
			'ip'			=> $ip
		);
		$v = IEventApiImgTTC::insert($param);
		if ($v) {
			$ret['data'] 	= array(
				'file_path'	=> $db_file_path
			);
		} else {
			$ret['errno']	= 301;
			$ret['message']	= 'compose file success, save data failed: errCode:' . IEventApiImgTTC::$errMsg;
			$ret['data'] 	= array(
				'file_path'	=> $db_file_path
			);
			Logger::err($ret['message'] . '; uid: ' . $uid . ', event_id: ' . $event_id);
		}
	} else {
		$ret['errno']	= 201;
		$ret['message']	= $image->errMsg;
	}
	
	return $ret;
}
