<?php

/**
 * ͼƬ������
 * 
 * @author yakehuang
 */
class ImageGD
{
	/**
	 * �������
	 */
	public $errCode = 0;

	/**
	 * ������Ϣ
	 */
	public $errMsg  = '';
	
	/**
	 * GD ��Դ���
	 */
	private $_handle = null;
	
	/**
	 * ���캯��
	 */
	public function __construct($filename)
	{
		if (!file_exists($filename)) {
			$this->errCode	= 100;
			$this->errMsg	= 'file not exist';
		} else {
			$fileext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
			$ext2functions = array(
				'jpg'	=> 'imagecreatefromjpeg',
				'jpeg'	=> 'imagecreatefromjpeg',
				'png'	=> 'imagecreatefrompng',
				'gif'	=> 'imagecreatefromgif'
			);
	
			if (!isset($ext2functions[$fileext])) {
				$this->errCode	= 101;
				$this->errMsg	= 'file type not support';
			} else {
				$this->_handle = call_user_func($ext2functions[$fileext], $filename);
			}
		}
	}
	
	/**
	 * ��ͼƬ��д������
	 */
	public function writeText($text, $options = array(), $charset = 'gb2312')
	{
		if (is_null($this->_handle) || trim($text) == '') return $this;
		
		$_options = array(
			'fontsize'		=> 12,
			'angle'			=> 0,
			'text_x'		=> 0,
			'text_y'		=> 0,
			'color'			=> '000000',
			'fontfile'		=> 'msyh.ttf',
			'width'			=> 0,
			'height'		=> 0
		);
		
		$options = array_merge($_options, $options);
		list($r, $g, $b) = self::hex2rgb($options['color']);
		$options['color'] = imagecolorallocate($this->_handle, $r, $g, $b);
		
		if (strtolower($charset) !== 'utf-8') {
			$text = iconv($charset, 'utf-8//IGNORE', $text);
		}
		$text = self::autowrap($text, $options['fontsize'], $options['angle'], $options['fontfile'],
								$options['width'], $options['height']);
		
		imagettftext($this->_handle, $options['fontsize'], $options['angle'], $options['text_x'],
						$options['text_y'], $options['color'], $options['fontfile'], $text);
		
		return $this;
	}
	
	/**
	 * ����
	 * 
	 * @param $filename		Ŀ���ļ�·��
	 * @param $quality		Ŀ��ͼƬ�������Ĳ���ֻ�� jpg ��ʽͼƬ��Ч
	 */
	public function save($filename, $quality = 80)
	{
		// header("Content-type: image/jpeg");
		// imagejpeg($this->_handle);		// exit;
		
		if (is_null($this->_handle)) return false;
		
		$return = false;
		$fileext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
		switch ($fileext) {
            case 'gif':
                $return = imagegif($this->_handle, $filename);
                break;
            case 'png':
                $return = imagepng($this->_handle, $filename);
                break;
            case 'jpg':
            case 'jpeg':
            default:
                $return = imagejpeg($this->_handle, $filename, $quality);
        }

		return (bool)$return;
	}
	
	/**
	 * �� 16 ������ɫֵת��Ϊ rgb ֵ
	 */
	public static function hex2rgb($color, $default = 'ffffff')
	{
		$hex = trim($color, '#&Hh');
		$len = strlen($hex);
		if ($len == 3) {
			$hex = "{$hex[0]}{$hex[0]}{$hex[1]}{$hex[1]}{$hex[2]}{$hex[2]}";
		} elseif ($len < 6) {
			$hex = $default;
		}
		$dec = hexdec($hex);
		return array(($dec >> 16) & 0xff, ($dec >> 8) & 0xff, $dec & 0xff);
	}
	
	/**
	 * �������ƵĿ��ȼ��뻻�з������Ƶĸ߶Ⱥ��Զ����ַ�����
	 * 
	 * @param $text		д���ı�
	 * @param $fontsize	�����С
	 * @param $angle	�Ƕ�
	 * @param $fontfile	�����ļ�
	 * @param $width	���ƿ��ȣ�Ϊ 0  ʱ��ʾ������
	 * @param $height	���Ƹ߶ȣ�Ϊ 0 ʱ��ʾ������
	 */
	public static function autowrap($text, $fontsize, $angle, $fontfile, $width, $height, $charset = 'utf8')
	{
		if (trim($text) == '' || ($width == 0 && $height == 0)) return $text;
		
		$content = "";
		
		// ���ַ�����ֳ�һ�������� ���浽���� letter ��
		for ($i = 0; $i < mb_strlen($text, $charset); $i++) {
			$letter[] = mb_substr($text, $i, 1, $charset);
		}
	
		foreach ($letter as $l) {
			$teststr = $content . ' ' . $l;
			
			// �ж�ƴ�Ӻ��Ƿ񳬹�Ԥ��Ŀ���
			if ($width != 0) {
				$testbox = imagettfbbox($fontsize, $angle, $fontfile, $teststr);
				if ($testbox[2] > $width && $content !== '') {
					$content .= "\n";
				}
			}
			
			// �ж�ƴ�Ӻ��Ƿ񳬹�Ԥ��ĸ߶�
			if ($height != 0) {
				// $content ���ϻس���ò�Ʋ���Ӱ��߶ȣ�����׷�Ӹ��ո�
				$testbox = imagettfbbox($fontsize, $angle, $fontfile, $content . ' ' . $l);
				if (intval(($testbox[3] + $fontsize * 0.9)) > $height) {
					break;
				}
			}
			
			$content .= $l;
		}
		
		return $content;
	}
	
	/**
	 * ��������
	 */
	public function __destruct()
	{
		if ($this->_handle) {
			@imagedestroy($this->_handle);
		}
		$this->_handle = null;
	}
}