<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/PHPLIB/lib/Config.php");

define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define("WEB_PAGE_ROOT", WEB_ROOT . "tuan_icson_com/");
define('CACHE_PATH', WEB_PAGE_ROOT.'cache/');
define("WEB_PAGE_TPL_DIR", WEB_PAGE_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, WEB_PAGE_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

require_once(WEB_PAGE_ROOT. 'inc/constant.inc.php');

// �������ͷ������(�Ա� modules ���ܹ��޸�)
$wrap_header = array(
	"httpv1_0"	=> "HTTP/1.0 200 OK",
	//"httpv1_1"	=> "HTTP/1.1 200 OK",
	"cache"		=> "Cache-Control: max-age=" . DEFAULT_CACHE_TIME,
	"expires"	=> "Expires: " . gmdate( 'D, d M Y H:i:s', time() + DEFAULT_CACHE_TIME) . ' GMT',
	"type"     => "Content-type:text/html; charset=" . (defined('CHARSET') ? CHARSET : 'GB2312'),
);

// ��� module ��
if (!empty($_REQUEST['mod'])){
	$mod_name = preg_replace("/[^a-zA-Z]/", '',trim($_REQUEST['mod']));
} else {
	$mod_name = 'main';
}


$mod_file = WEB_PAGE_ROOT . 'mod/'.$mod_name.'.php';

if( !file_exists($mod_file)){
	$mod_file = WEB_PAGE_ROOT . 'areas/'.$siteInfo['name'].'/mod/'.$mod_name.'.php';
	$tpl_directory = WEB_PAGE_ROOT . 'areas/'.$siteInfo['name'].'/tpl';
	
	if( !file_exists($mod_file)){
		$mod_file = WEB_PAGE_ROOT . 'areas/default/mod/'.$mod_name.'.php';
		$tpl_directory = WEB_PAGE_ROOT . 'areas/default/tpl';
	}
	define("DEFAULT_TPL_DIR", WEB_PAGE_ROOT . 'areas/default/tpl');
	define("CURRENT_TPL_DIR", $tpl_directory);
}
if ( !in_array($mod_name, $mod_list, true) || !file_exists($mod_file) ){
	// ��¼���ʵ� url
	$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
	$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
	Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
	ToolUtil::redirect("http://www.51buy.com/");
}

// ��� act ��
if (!empty($_REQUEST['act'])){
	$act_name = preg_replace("/[^a-zA-Z0-9]/", '', trim($_REQUEST['act']));
} else {
	$act_name = 'page';
}

$func_name = $mod_name . '_' . $act_name;

require_once $mod_file;
if (!function_exists($func_name)){
	$func_name = $mod_name . '_page';
	if(!function_exists($func_name)){
		$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
		$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
		Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
		ToolUtil::redirect("http://www.51buy.com/");
	}
}

$str = $func_name();

// ��ȫ�������������� header
if (is_array($wrap_header))
{
    foreach ($wrap_header as $key => $header_line)
    {
        @header($header_line);
    }
}

$xml = '<?xml version="1.0" encoding="gbk"?>';
$xml .= '<result>';
if (is_array($str)) {
	
	foreach ($str as $key => $value) {
		$xml .= '<' . $key . '>' . htmlspecialchars($value) . '</' . $key . '>';
		
	}
}
$xml .= '</result>';
echo $xml;
?>