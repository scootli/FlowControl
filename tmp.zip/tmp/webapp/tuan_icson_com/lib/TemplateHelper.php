<?php
define('SALEFIELD', 1);
define('PRICEFIELD', 2);
define('EVALUATEFIELD', 4);
define('DEFAULTFIELD', 6);

class TemplateHelper{
	private static $allowedTypes = array(
		"right", "warn", /*"info", */"error"/*, "help"*/
	);
	/**
	* ������ʾ��Ϣ��ȫҳ����ʾ
	*
	* @param string $message ��ʾ��Ϣ����
	* @param string $type ��ʾ��Ϣ����
	*/
	public static function outMessage($message, $type = 'notice'){
		global $_WEBSITE_CFG;


		$TPL = new Template(WEB_PAGE_ROOT."tpl/", 'keep');
		$TPL->set_file(array(
			'baseHandler' => 'base.tpl',
			'headerHandler' => 'header.tpl',  //����
			'containerHandler' => 'message.tpl',
			'footerHandler' => 'footer.tpl' //�ײ�
		));

		if(!in_array($type, self::$allowedTypes)){
			$type = 'warn';
		}

		$extMessage = '';
		if(is_array($message)){
			$tmp = array_shift($message);
			foreach ($message as $m){
				$extMessage .= '<p>' . $m . '</p>';
			}
			if($extMessage){
				$extMessage = '<div class="bd">' . $extMessage . '</div>';
			}
			$message = '<strong class="tit">' . $tmp . '</strong>';
		} else {
			$message = '<strong class="tit">' . $message . '</strong>';
		}

		if(empty($extMessage)) $message .= '<br />';
		$message = '<div class="para_blo para_' . $type . '">
<div class="inner"> <b class="icon icon_msg4 icon_msg4_' . $type . '"></b>
<div class="hd">' . $message . '</div>
' . $extMessage . '
</div></div>';

		$vars = array(
			"message"	=> $message
		);
		$TPL->set_var($vars);
		$TPL->parse('container', 'containerHandler');
		$TPL->unset_var(array_keys($vars));
		$_siteId = IUser::getSiteIdWrapper(); //�人վ
		$defaultSearch = IIndex::getTopSearch($_siteId); //Ĭ���������ù��λ����
		$vars = array(
//			"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteId()]) ? $_WEBSITE_CFG[IUser::getSiteId()]['contact_number'] : '',
			"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteIdWrapper()]) ? $_WEBSITE_CFG[IUser::getSiteIdWrapper()]['contact_number'] : '', //�人վ
			"nav_list_str"  => IUser::getNavList(),
			'global_default_search' => empty($defaultSearch) ? json_encode(array()) : json_encode($defaultSearch), //ҳͷ������
			"wap_icson_enter" => (isset($_WEBSITE_CFG[IUser::getSiteIdWrapper()]) && ($_WEBSITE_CFG[IUser::getSiteIdWrapper()]['site_id'] == 1))?  '<li class="item"><a ytag="00007" href="http://act.51buy.com/promo-3105.html">�ֻ���Ѹ</a></li>': ''
		);
		$TPL->set_var($vars);
		$TPL->parse('header', 'headerHandler');
		$TPL->parse('footer', 'footerHandler');
		$TPL->unset_var(array_keys($vars));
		$TPL->set_var("cate_site", IUser::getCateClass());
		$shandiansongInfo = IUser::getShanDianSongInfo();
		$TPL->set_var('shandiansong_info_text', $shandiansongInfo['text']);
		$TPL->set_var('shandiansong_info_hover', $shandiansongInfo['hover']);
		$TPL->set_var('cod_desc', IUser::isCashOnDelivery() ? '' : 'stand_seven');
		
		$baseVars = array(
			"header_css"	=> '<link href="http://st.icson.com/static_v1/css/header/header_full.css?v=[[V_CSS_HEADER_FULL]]" rel="stylesheet" type="text/css" />', // default
			"title_desc"	=> '',
			"css_file"	=> '',
			"before_body"	=> '',
		);

		$TPL->set_var($baseVars);
		$TPL->pparse("output", "baseHandler");
	}

	public static function getBaseTPL($opt = array()){
		$tpl = new BaseTPL();
		$tpl->init($opt);
		$tpl->set_var("cate_site", IUser::getCateClass());
		$shandiansongInfo = IUser::getShanDianSongInfo();
		$tpl->set_var('shandiansong_info_text', $shandiansongInfo['text']);
		$tpl->set_var('shandiansong_info_hover', $shandiansongInfo['hover']);
		$tpl->set_var('cod_desc', IUser::isCashOnDelivery() ? '' : 'stand_seven');
		return $tpl;
	}

	public static function getJS($url, $needPrefix = true,  $charset = 'gb2312'){
		return '<script type="text/javascript" src="' . ( $needPrefix ? 'http://st.icson.com/static_v1/js/' : '') . $url . '" charset="' . $charset . '"></script>' . "\n";
	}

	public static function getCSS($url, $needPrefix = true){
		return '<link href="' . ( $needPrefix ? 'http://st.icson.com/static_v1/css/' : '') . $url . '" rel="stylesheet" type="text/css" />' . "\n";
	}

}


class BaseTPL extends Template {
	private $opt = array();

	public function setOpt($options){
		foreach ($options as $k => $option){
			$this->opt[$k] = $option;
		}
	}

	public function init($options = array()){
		parent::Template(WEB_PAGE_TPL_DIR, 'keep');

		$this->opt = $options;

		$headerTPLFile = 'header.tpl';
		if(!empty($this->opt['headerStyle'])){
			if($this->opt['headerStyle'] == 'none'){
				$headerTPLFile = 'header_none.tpl';
			} else if($this->opt['headerStyle'] == 'login'){
				$headerTPLFile = 'header_login.tpl';
			} else if($this->opt['headerStyle'] == 'min'){
				$headerTPLFile = 'header_min.tpl';
			}
		}

		$containerTPLFile = 'container.tpl';
		if(!empty($this->opt['containerTPL'])){
			$containerTPLFile = $this->opt['containerTPL'];
		}
		$this->set_var("cate_site", IUser::getCateClass());
		$this->set_file(array(
			'baseHandler' => 'base.tpl',
			'headerHandler'	=> $headerTPLFile,
			'containerHandler' => $containerTPLFile,
			'footerHandler' => 'footer.tpl' //�ײ�
		));
	}

	/**
	 * ���or����ҳ������
	 * @param boolean $return �Ƿ񷵻ش���������HTML
	 * @return mixed false ��pparse���أ�html��parse������
	 */
	public function out($return = false){
		global $_WEBSITE_CFG;

		$this->parse('header', 'headerHandler');
		$this->parse('container', 'containerHandler');
		$this->parse('footer', 'footerHandler');

		if (empty($this->opt['headerConfig'])) {
			$this->opt['headerConfig']['currentPage'] = 'nav_groupbuy';
		}
		$_siteId = IUser::getSiteIdWrapper(); //�人վ
		$defaultSearch = IIndex::getTopSearch($_siteId); //Ĭ���������ù��λ����
		$baseVars = array(
			"header_css"	=> '<link href="http://st.icson.com/static_v1/css/header/header_full.css?v=[[V_CSS_HEADER_FULL]]" rel="stylesheet" type="text/css" />', // default
//			"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteId()]) ? $_WEBSITE_CFG[IUser::getSiteId()]['contact_number'] : '',
			"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteIdWrapper()]) ? $_WEBSITE_CFG[IUser::getSiteIdWrapper()]['contact_number'] : '', //�人վ
			"nav_list_str"  => IUser::getNavList( !empty($this->opt['headerConfig'])? $this->opt['headerConfig'] : array() ),
			'global_default_search' => empty($defaultSearch) ? json_encode(array()) : json_encode($defaultSearch), //ҳͷ������
			"wap_icson_enter" => (isset($_WEBSITE_CFG[IUser::getSiteIdWrapper()]) && ($_WEBSITE_CFG[IUser::getSiteIdWrapper()]['site_id'] == 1))?  '<li class="item"><a ytag="00007" href="http://act.51buy.com/promo-3105.html">�ֻ���Ѹ</a></li>': ''
		);

		if(!empty($this->opt['headerStyle'])){
			if($this->opt['headerStyle'] == 'none' || $this->opt['headerStyle'] == 'min'){
				$baseVars['header_css'] = '<link href="http://st.icson.com/static_v1/css/header/header_min.css?v=[[V_CSS_HEADER_MIN]]" rel="stylesheet" type="text/css" />';
			}
		}

		if(!empty($this->opt['titleDesc'])){
			$baseVars['title_desc'] = $this->opt['titleDesc'] . ' - ';
		} else {
			$baseVars['title_desc'] = '';
		}

		if(!empty($this->opt['cssFile'])){
			$baseVars['css_file'] = '<link href="' . $this->opt['cssFile'] . '" rel="stylesheet" type="text/css" />';
		} else {
			$baseVars['css_file'] = '';
		}

		if(!empty($this->opt['before_body'])){
			$baseVars['before_body'] = $this->opt['before_body'];
		} else {
			$baseVars['before_body'] = '';
		}

		$pageIdInfo = ToolUtil::getCurrentPageId();
		$baseVars['yPageId'] = $pageIdInfo['yPageId'];
		$baseVars['yPageLevel'] = $pageIdInfo['yPageLevel'];
		$this->set_var($baseVars);

		return ($return) ? $this->parse("output", "baseHandler") : $this->pparse("output", "baseHandler");
	}


}
// End Of Script