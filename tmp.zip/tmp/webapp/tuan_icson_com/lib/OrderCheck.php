<?php

class OrderCheck {
	
	public static function checkOrderInput($order) {
		if (empty($order)) {
			return false;
		}
	
		if (!preg_match('/^(\d{10})$/', $order['order_char_id'])) {
			return false;
		}
		
		return true;
	}
	
	public static function checkOrderInDate($order, $start_time = -1, $end_time = -1) {
		if(empty($order))
			return false;
	
		if($start_time >= 0 && $order['order_date'] < $start_time)
			return false;
			
		if($end_time >=0 && $order['order_date'] > $end_time)
			return false;
		
		return true;
	}
	
	public static function checkOrderStatus($order) {
		if (self::checkIsOnlinePay($order)) {
			if ($order['isPayed']) {
				return true;
			}  else 
				return false;
		} else {
			$orderStatus = $order['status'];
			Global $_OrderState;
			if($orderStatus == $_OrderState['OutStock']['value'])
				return true;
			else 
				return false;
		}
	}	
	
	public static function checkIsOnlinePay($order) {
		global $_PAY_MODE;
        return $_PAY_MODE[$order['hw_id']][$order['pay_type']]['IsNet'];
	}
}