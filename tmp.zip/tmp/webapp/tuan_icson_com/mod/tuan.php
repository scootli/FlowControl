<?php
/**
 * ��ǰ�Ź�
 */

Logger::init();

function page_tuan_index() {
	ToolUtil::setCurrentPageId(2, 170);
	$wid = IUser::getSiteIdWrapper();
	$cacheContent = IPageCahce::getCachePage(__FILE__, __FUNCTION__, $wid);
	if (empty($cacheContent)) {
		Logger::ERR("empty cache:" . IPageCahce::$errCode . ',' . IPageCahce::$errMsg);
	}
	
	$js = '';
	if (isset($_GET['pos'])) {
			$keys = explode('_', $_GET['pos']);
			$first_content = '';
			$rs = preg_match_all('/<\!--start(' . implode('|', $keys) . ')-->([\s\S]*?)<\!--end\1-->/', $cacheContent, $matches);
			$cnt = array();
			foreach ($matches[0] as $k => $v) {
				$cnt[$matches[1][$k]] = $v;
			}
			foreach ($keys as $key) {
				$first_content .= $cnt[$key];
				$cacheContent = str_replace($cnt[$key], "", $cacheContent);
			}
			$cacheContent = str_replace('<!--first-->', $first_content , $cacheContent);
			/*foreach ($keys as $k) {
				$key = intval($k);
				//�����������
				$rs = preg_match('/<\!--start' . $key . '-->([\s\S]*?)<\!--end' . $key . '-->/', $cacheContent, $array);
				if ($rs) {
					//$div = $array[1];
					$div = $array[0];
					$cacheContent = str_replace($div, "", $cacheContent);
//					$cacheContent = str_replace('<!--first-->', $div , $cacheContent);
					$first_content .= $div;
				}
			}
			$cacheContent = str_replace('<!--first-->', $first_content , $cacheContent);*/
	}
	
	if (isset($_GET['ls']) && strpos($_GET['ls'], 'tuan') !== false) {
		$cacheContent = str_replace("ls=tuan", "ls=" . addslashes(ToolUtil::transXSSContent($_GET['ls'])), $cacheContent);
	}
	$op = array(
			"titleDesc" => '��Ѹ�Ź�',
			'before_body' => implode("", array(
		TemplateHelper::getCSS("http://st.icson.com/static_v1/act/51buy_20120314_tuan/css/style.css?v=2013031201", false),
		TemplateHelper::getJS("http://st.icson.com/static_v1/act/51buy_20120314_tuan/js/tuan.js?v=2013031201",false),
		$js,
		)),
	);

	$TPL = TemplateHelper::getBaseTPL($op);
	$TPL->set_var('cate_site', IUser::getCateClass());
	$shandiansongInfo = IUser::getShanDianSongInfo();
	$TPL->set_var('shandiansong_info_text', $shandiansongInfo['text']);
	$TPL->set_var('shandiansong_info_hover', $shandiansongInfo['hover']);
	$TPL->set_var('cod_desc', IUser::isCashOnDelivery() ? '' : 'stand_seven');
	
	if (!empty($cacheContent)) {
		$TPL->set_var('container', $cacheContent);
		$TPL->set_var('qqvip_block', _get_qqvip_block($wid));
		$TPL->set_var('lottery_status', _get_lottery_status($wid));
	} else {
		$TPL->set_var('container', _get_qqvip_block($wid));
		$TPL->set_var('lottery_status', _get_lottery_status($wid));
	}
	
	$TPL->out();
}

/**
 * ��һ���Ź�
 */
function page_tuan_next() {
	// �Ѿ�ȡ����������
	ToolUtil::redirect("http://tuan.51buy.com");
	
	ToolUtil::setCurrentPageId(2, 180);
	$wid = IUser::getSiteIdWrapper();

	$cacheContent = IPageCahce::getCachePage(__FILE__, __FUNCTION__, $wid);
	if (empty($cacheContent)) {
		Logger::ERR("empty cache:" . IPageCahce::$errCode . ',' . IPageCahce::$errMsg);
		ToolUtil::redirect("http://tuan.51buy.com");
	}
	
	$op = array(
			"titleDesc" => '��Ѹ�Ź�-Ԥ��',
			'before_body' => implode("", array(
	TemplateHelper::getCSS("http://st.icson.com/static_v1/act/51buy_20120314_tuan/css/style.css?v=2013031201", false),
	TemplateHelper::getJS("http://st.icson.com/static_v1/act/51buy_20120314_tuan/js/tuan.js?v=2013031201",false),
	)),
	);

	$TPL = TemplateHelper::getBaseTPL($op);
	$TPL->set_var('container', $cacheContent);
	$TPL->set_var('qqvip_block', _get_qqvip_block($wid, false));
	$TPL->set_var('lottery_status', _get_lottery_status($wid, false));
	$TPL->out();
}

/**
 * ������
 */
function tuan_like() {
	$id = intval($_GET['id']);
	$ts = intval($_GET['ts']);
	
	session_start();
	if (isset($_SESSION['item_' . $id])) {
		return array('errno' => 3, 'message' => '���Ѿ�����');
	} else {
		$_SESSION['item_' . $id] = 1;
		$ilike = new ITuanLikeHistory();
		$ilike->addLikeCount($id, $ts);
		$ilike->setLikeCount($id, $ts);
		return array('errno' => 0, 'message' => '�ɹ�');
	}
}

/**
 * �û����ŵ���Ϣ
 */
function tuan_userlikes() {
	session_start();
	if (isset($_GET['id'])) {
		$ilike = new ITuanLikeHistory();
		$count = $ilike->getLikeCount(intval($_GET['id']), intval($_GET['ts']));
		if ($count < 0 || $count == false) {
			$count = 0;
		}
		if (isset($_SESSION['item_' . $_GET['id']])) {
			return array('errno' => 0, 'message' => $count);
		} else {
			return array('errno' => 1, 'message' => $count);
		}
	}
	return array('errno' => 3, 'message' => '');
}

function page_tuan_tosite() {
	$site = $_GET['site'];
	$ext = '';
	if (isset($_GET['ls']) && !empty($_GET['ls'])) {
		$ext = '/?ls=' . $_GET['ls'];
	}
	if (isset($_GET['pos']) && !empty($_GET['pos'])) {
		if (empty($ext)) {
			$ext = '/?pos=' . $_GET['pos'];
		} else {
			$ext .= '&pos=' . $_GET['pos'];
		}
	}
	if ($site == 'sh') {
		$wid = IUser::getSiteId(1);
	} else if ($site == 'vipqq' || $site == 'qqvip') {
		page_tuan_qqvip();
		return;
	} else if ($site == 'bj') {
		$wid = IUser::getSiteId(2001);
	} else if ($site == 'gd' || $site == 'sz') {
		$wid = IUser::getSiteId(1001);
	} else {
		$wid = IUser::getSiteIdWrapper();
	}
	header("location: http://tuan.51buy.com" . $ext);
}

function _get_qqvip_block($wid, $is_current = true) {
	$cacheContent = IPageCahce::getCachePage(__FILE__, 'page_tuan_qqvip_block', $wid);
	
	if (empty($cacheContent)) {
		return '';
	} else {
		if (!$is_current) {
			$cacheContent = str_replace('href="#top" class="btn_mashangqujiang"', 'href="http://tuan.51buy.com/#top" class="btn_mashangqujiang"', $cacheContent);
		}
		return $cacheContent;
	}
}

function _get_lottery_status($wid, $is_current = true) {
	$lottery_status_html = '';
	$uid = IUser::getLoginUid();
	$key = IPageCahce::getCacheKey('tuan', 'tuan_qqvip_lottery', $wid);
	$value = IPageCahce::getCacheData($key);
	if(!empty($value)) {
		$times = unserialize($value);
		$now = time();
		if($now >= $times['lottery_start_time'] && $now <= $times['lottery_end_time']) {
			$tuanAward = new ITuanAward($times['lottery_start_time'], $times['lottery_end_time'], $times['lottery_publish_time'], $times['lottery_order_time']);
			if (!empty($uid)) {
				$codes = $tuanAward->getCodeCache($uid);
			} else {
				$codes = array();
			}
			$pc_codes = array();
			if(isset($codes[ITuanAward::LOTTERY_TYPE_QQ])) {
				$pc_codes = array_merge($pc_codes, $codes[ITuanAward::LOTTERY_TYPE_QQ]);
			}
			if(isset($codes[ITuanAward::LOTTERY_TYPE_QQVIP])) {
				$pc_codes = array_merge($pc_codes, $codes[ITuanAward::LOTTERY_TYPE_QQVIP]);
			}
			$pc_codes_count = count($pc_codes);
			if($pc_codes_count >= 1) {
				$tuan_link = $is_current ? '#top' : 'http://tuan.51buy.com#top';
				$lottery_status_html = <<<HTML
<div class="chou_on">
	<div>
		<h3 class="title_gongxi">��ϲ�����{$pc_codes_count}�ų齱ȯ<i></i><span class="num">{$pc_codes_count}</span></h3>
		<p class="item_list">{codes}</p>
		<p class="choujiang_tip">�齱����������ǽ�ͨ���ֻ��绰��ʽ�����н��û����뱣���ֻ���ͨ��</p>
		<h3 class="choujiang_rp">�н�����Ʒ���Ż���ʵ��!<i></i></h3>
		<div class="time"><span class="h" id="lottery_hour">00</span><span class="m" id="lottery_minute">00</span><span class="s" id="lottery_second">00</span></div>
		<a href="{$tuan_link}" class="btn_mashangqujiang">����ȥ��<i></i></a>
	</div>
</div>
HTML;
				$codes_html = '';
				foreach ($pc_codes as $c) {
					$codes_html .= '<span class="item">' . $c . '</span>';
				}
				$lottery_status_html = str_replace('{codes}', $codes_html, $lottery_status_html);
			} else {
				$lottery_count_html = '';
				if (!empty($times['lottery_count'])) {
					$lottery_count_html = '<p class="join_num">����<span>' . $times['lottery_count'] . '</span>�˲μӱ��ڳ齱</p>';
				}
				$lottery_status_html = <<<HTML
	<div class="chou_start">
		<a ytag="36000" href="https://itunes.apple.com/cn/app/id557825088?YTAG=0.170100004300000" class="download_apple hidetxt" title="��Ѹ���ֻ�IOS�ͻ���AppStore����">AppStore����</a>
		<a ytag="36001" href="http://app.51buy.com/download/android?YTAG=0.170100005300000" class="download_android hidetxt" title="��Ѹ���ֻ���׿�ͻ���android�г�����">android�г�����</a>
		{$lottery_count_html}
		<a ytag="37000" href="javascript:void(0);" class="btn_choujiang" onclick="G.app.tuan.lottery(0);return false;">�����齱<i></i></a>
	</div>
HTML;
			}
		}
	}
	
	return $lottery_status_html;
}

function page_tuan_qqvip() {
	// �Ѿ��ϲ�������ת
	ToolUtil::redirect("http://tuan.51buy.com");
	
	ToolUtil::setCurrentPageId(2);
	$wid = IUser::getSiteIdWrapper(/*1*/);
	if($wid != 1 && $wid != 1001 && $wid != 2001) {
		ToolUtil::redirect("http://tuan.51buy.com");
	}
//	$wid = 1;
	$cacheContent = IPageCahce::getCachePage(__FILE__, __FUNCTION__, $wid);
	if (empty($cacheContent)) {
		Logger::ERR("empty cache:" . IPageCahce::$errCode . ',' . IPageCahce::$errMsg);
	}
	$op = array(
				"titleDesc" => '��Ѹ�Ź�--QQ��Աר��',
				'before_body' => implode("", array(
	TemplateHelper::getCSS("http://st.icson.com/static_v1/act/51buy_20120314_tuan/css/style.css?v=2013031201", false),
	TemplateHelper::getJS("http://st.icson.com/static_v1/act/51buy_20120314_tuan/js/tuan.js?v=2013031201",false),
	)),
	);
	
	if (isset($_GET['ls']) && strpos($_GET['ls'], 'tuanqqvip') !== false) {
		setrawcookie('qqvip_ls', $_GET['ls'], 0, '/', '.51buy.com');
		$cacheContent = str_replace("ls=tuanqqvip", "ls=" . addslashes(htmlspecialchars($_GET['ls'])), $cacheContent);
	}
	ITuan::checkTuanSn(true);
	
	$TPL = TemplateHelper::getBaseTPL($op);
	
	$uid = IUser::getLoginUid();
	if ($uid) {
		$isVip = IUser::checkQQVip($uid);
		if ($isVip) {
			setrawcookie('is_qqvip', '1', 0, '/', '.51buy.com');
		} else {
			setrawcookie('is_qqvip', '0', 0, '/', '.51buy.com');
		}
		
		if (isset($_COOKIE['qqvip_new_login']) && $_COOKIE['qqvip_new_login'] > 0) {
			$id = $_COOKIE['qqvip_new_login'];
			if ($isVip) {
				setrawcookie('qqvip_new_login', 0, 0, '/', '.51buy.com');
				if (isset($_COOKIE['qqvip_join']) && !empty($_COOKIE['qqvip_join'])) {
					setrawcookie('qqvip_join', '0', 0, '/', '.51buy.com');
					header("Location: http://buy.51buy.com/cart.html?pid=" . $id . "&price_id=22&pnum=1&mid=" . $id . $_COOKIE['qqvip_new_login_ytag']);
				} else {
					if (isset($_GET['ls']) && !empty($_GET['ls'])) {
						header("Location: http://item.51buy.com/item-" . $wid . "-" . $id . ".html?ls=" . addslashes(htmlspecialchars($_GET['ls'])) . $_COOKIE['qqvip_new_login_ytag']);
					} else {
						header("Location: http://item.51buy.com/item-" . $wid . "-" . $id . ".html?ls=tuanqqvip" . $_COOKIE['qqvip_new_login_ytag']);
					}
				}
				exit;
			} else {
				setrawcookie('qqvip_new_login', 0, 0, '/', '.51buy.com');
				//if (isset($_COOKIE['qqvip_join']) && !empty($_COOKIE['qqvip_join'])) {
				//	setrawcookie('qqvip_join', '0', 0, '/', '.51buy.com');
				//	if (isset($_GET['ls']) && !empty($_GET['ls'])) {
				//		header("Location: http://item.51buy.com/item-" . $id . ".html?ls=" . $_GET['ls']);
				//	} else {
				//		header("Location: http://item.51buy.com/item-" . $id . ".html");
				//	}
				//} else {
					$cacheContent .= "<script>
					var id= $id;
					var dialog = G.ui.popup.showMsg(
							'QQ��Ա����' + $('#pricecha' + id).val() + 'Ԫ���������������Żݣ�',
							1,
							function() { //okFunc
								window.open('http://pay.qq.com/qqvip/index.shtml?aid=vip.dianshang.bd.tequan.51buy');
								dialog.close();
							},
							function() { //closeFunc
							},
							function() { //cancelFunc
								if (G.util.cookie.get('qqvip_ls') != '') {
									window.open('http://item.51buy.com/item-" . $wid . "-' + id + '.html?ls=' + G.util.cookie.get('qqvip_ls'));
								} else {
									window.open('http://item.51buy.com/item-" . $wid . "-' + id + '.html?ls=tuanqqvip');
								}
								dialog.close();
							},
							'��ͨ��Ա',
							'��������'
					);
					G.app.tuan.dialog = dialog;
					var url = '';
					if (G.util.cookie.get('qqvip_ls') != '') {
						url = 'http://item.51buy.com/item-" . $wid . "-' + id + '.html?ls=' + G.util.cookie.get('qqvip_ls') + '" . $_COOKIE['qqvip_new_login_ytag'] ."';
					} else {
						url = 'http://item.51buy.com/item-" . $wid . "-' + id + '.html?ls=tuanqqvip" . $_COOKIE['qqvip_new_login_ytag'] ."';
					}
					$(\".wrap_btn\").html('<a onclick=\"G.app.tuan.dialog.close();\" href=\"http://pay.qq.com/qqvip/index.shtml?aid=vip.dianshang.bd.tequan.51buy\" target=\"_blank\" class=\"btn_qq_open\">��ͨQQ��Ա<b></b></a> <a target=\"_blank\"  class=\"btn_buy\" href=\"' + url + '\" onclick=\"G.app.tuan.dialog.close();\"><i class=\"bod_left\"></i>��������<i class=\"bod_right\"></i></a>');
					</script>";
				//}
			}
		}
		
		$TPL->set_var('container', $cacheContent);
		
		$key = IPageCahce::getCacheKey('tuan', 'tuan_qqvip_lottery', $wid);
		$value = IPageCahce::getCacheData($key);
		if(!empty($value)) {
			$times = unserialize($value);
			$now = time();
			if($now >= $times['lottery_start_time'] && $now <= $times['lottery_end_time']) {
				$tuanAward = new ITuanAward($times['lottery_start_time'], $times['lottery_end_time'], $times['lottery_publish_time'], $times['lottery_order_time']);
				$codes = $tuanAward->getCodeCache($uid);
				$pc_codes = array();
				if(isset($codes[ITuanAward::LOTTERY_TYPE_QQ])) {
					$pc_codes = array_merge($pc_codes, $codes[ITuanAward::LOTTERY_TYPE_QQ]);
				}
				if(isset($codes[ITuanAward::LOTTERY_TYPE_QQVIP])) {
					$pc_codes = array_merge($pc_codes, $codes[ITuanAward::LOTTERY_TYPE_QQVIP]);
				}
				if(empty($pc_codes)) {
					$TPL->set_var('step_style', 'start');
					$lottery_status_html = '<div class="jiang"><a ytag="37000" class="jiang_in" onclick="G.app.tuan.lottery(0);return false;"></a></div>';
					$TPL->set_var('lottery_status', $lottery_status_html);
				} else if(count($pc_codes) == 1) {
					$TPL->set_var('step_style', 'start');
					$lottery_status_html = <<<HTML
					<div class="quan">
	                    <p class="tit_quan">���Ķҽ�ȯ��</p>
	                    <p class="quan1">{codes}</p>
                    </div>
                    <div class="jiang"><a ytag="37000" class="jiang_in" onclick="G.app.tuan.lottery(0);return false;"></a></div>
HTML;
					$codes_html = '';
					foreach ($pc_codes as $c) {
						$codes_html .= '<span class="quan_item">' . $c . '</span>';
					}
					$lottery_status_html = str_replace('{codes}', $codes_html, $lottery_status_html);
					$TPL->set_var('lottery_status', $lottery_status_html);
				} else {
					$TPL->set_var('step_style', 'wait');
					$lottery_status_html = <<<HTML
					<div class="quan">
	                    <p class="tit_quan">���Ķҽ�ȯ��</p>
	                    <p class="quan1">{codes}</p>
                    </div>
                    <div class="wait_txt">����ʱ�䣺{publish_time}�������ڴ�</div>
HTML;
					$codes_html = '';
					foreach ($pc_codes as $c) {
						$codes_html .= '<span class="quan_item">' . $c . '</span>';
					}
					$lottery_status_html = str_replace('{publish_time}', date('Y��n��j��', $times['lottery_publish_time']), $lottery_status_html);
					$lottery_status_html = str_replace('{codes}', $codes_html, $lottery_status_html);
					$TPL->set_var('lottery_status', $lottery_status_html);
				}
			} else
				clean_mark($TPL);
		} else {
			clean_mark($TPL);
		}
		
		
	} else {
		setrawcookie('is_qqvip', '1', 0, '/', '.51buy.com');
		setrawcookie('qqvip_join', '0', 0, '/', '.51buy.com');
		setrawcookie('qqvip_new_login', 0, 0, '/', '.51buy.com');
		
		$TPL->set_var('container', $cacheContent);
		
		clean_mark($TPL);
	}
	
	if(isset($_GET['ls']) && !empty($_GET['ls']))
		$TPL->set_var('ls', ToolUtil::transXSSContent($_GET['ls']));
	else 
		$TPL->set_var('ls', 'tuanqqvip');
	
	echo '';
	$TPL->out();
}

function clean_mark($TPL) {
	$TPL->set_var('step_style', 'start');
	$TPL->set_var('lottery_status', '<div class="jiang"><a ytag="37000" class="jiang_in" onclick="G.app.tuan.lottery(0);return false;"></a></div>');
}

function page_tuan_yixuntuan() {
	$key = 'sdf@E@90D_*&__POI';
	$ts = time();
	$type = 1;
	$skey = md5($type . $ts . md5($key));
	$url = "http://a1.shop.qq.com/act.php?mod=checkuser&type=" . $type . "&func=weibo&ts=" . $ts . "&sn=" . $skey;
	header("Location: " . $url);
}

function page_tuan_toyixuntuan() {
	header("Location: http://t.qq.com/yixuntuan");
}

function page_tuan_top() {
	$wid = IUser::getSiteId();
	$cacheContent = ITuan::getTuanIndex($wid);
	$op = array(
				"titleDesc" => '��Ѹ�Ź�--��ҳ',
				'before_body' => implode("", array(
	TemplateHelper::getCSS("http://st.icson.com/static_v1/act/51buy_20120314_tuan/css/style.css?v=2013031201", false),
	TemplateHelper::getJS("http://st.icson.com/static_v1/act/51buy_20120314_tuan/js/tuan.js?v=2013031201",false),
	)),
	);
	
	$TPL = TemplateHelper::getBaseTPL($op);
	$TPL->set_var('container', $cacheContent);
	$TPL->out();
}

function page_tuan_qqvipurl() {
	$uid = IUser::getLoginUid();
	if ($uid > 0) {
		
		$isQQRst = IUser::validateUserFromQQ($uid);
		$isQQ = $isQQRst['validate'];
		if ($isQQ && preg_match("/^http:\/\/([^\.]+\.|)(51buy|icson)\.com/i", $_GET['url'])) {
			header('Location: ' . $_GET['url']);
			exit;
		}
	} 
	
	echo "<script>location.href='https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=215585&redirect_uri=' + encodeURIComponent('http://base.51buy.com/index.php?mod=user&act=loginqqauthcode&url=' + encodeURIComponent('" . $_GET['url'] . "'))</script>";
	exit;
}

//��Ա�齱
function tuan_lottery() {
	
	$uid = IUser::getLoginUid();
	if (!$uid) {
		return array('errno'=> 1, 'message'=>'�����ȵ�¼�ٲμӳ齱��лл���');
	}
	
	//��ˢ
	if (IFreqLimit::checkAndAdd($uid, 2) && isset($_GET['check'])) {
		return array('errno'=> 2, 'message'=>'��ͬʱ���ڵ���������࣬����5����ٳ���');
	}
	
	$wid = IUser::getSiteId();
	$key = IPageCahce::getCacheKey('tuan', 'tuan_qqvip_lottery', $wid);
	$value = IPageCahce::getCacheData($key);
	if(!empty($value)) {
		$times = unserialize($value);
	} else
		return array('errno' => -5, 'message' => '����������������');
	
	if(!isset($_POST['lottery_type']) || $_POST['lottery_type'] === '')
		return array('errno' => 6, 'message' => 'δ֪�ĳ齱����');
	$lottery_type = $_POST['lottery_type'];
	
	$userInfo = IUser::getUserInfo($uid);
	
	switch($lottery_type) {
		case ITuanAward::LOTTERY_TYPE_QQ:
			//�ж��Ƿ�QQ�û�
			$rs = IUser::validateUserFromQQ($uid);
			if (!$rs['validate']) {
				return array('errno' => 5, 'message' => $userInfo['icsonid']);
			}
			
			//�ж��Ƿ������ֻ��ͻ���
			if(!AppAccountAction::getUserLastLoginTime($uid)) {
				return array('errno' => 10, 'message' => 'δ���ػ��¼�ֻ��ͻ���');
			}
			
			//�жϻ�Ա
			$rs = IUser::checkQQVip($uid);
			if ($rs) {
				$lottery_type = ITuanAward::LOTTERY_TYPE_QQVIP;
			}
			break;
		/*case ITuanAward::LOTTERY_TYPE_SHOPPING:
			//�ж��Ƿ���
			if(!isset($_POST['order_id']) || empty($_POST['order_id']))
				return array('errno' => 7, 'message' => '��ȡ������ʧ��');
			$order_id = ToolUtil::transXSSContent($_POST['order_id']);
			$order = IOrder::getOneOrder($uid, $order_id);
			if(!OrderCheck::checkOrderInput($order) || !OrderCheck::checkOrderInDate($order, $times['lottery_order_time'], -1)
				|| !OrderCheck::checkOrderStatus($order))
				return array('errno' => 8, 'message' => '��֤����ʧ��');
			break;*/
		default:
			return array('errno' => 6, 'message' => 'δ֪�ĳ齱����');
	}
	
	//�ж��ֻ���
	$mobile = $userInfo['mobile'];
	if (empty($mobile)) {
		return array('errno' => 4, 'message' => '�����ֻ���Ϊ��');
	}
	
	$tuanAward = new ITuanAward($times['lottery_start_time'], $times['lottery_end_time'], $times['lottery_publish_time'], $times['lottery_order_time']);
	if($lottery_type != ITuanAward::LOTTERY_TYPE_QQVIP) {
		$rs = $tuanAward->lottery($uid, $lottery_type);
		if ($rs < 0) {
			switch ($rs) {
				case -1: $message = '���첻�ܳ齱';break;
				case -2: $message = '�齱ʱ�仹δ��ʼ';break;
				case -3: $message = '�齱ʱ���Ѿ�����';break;
				case -4: $message = '���Ѿ��μӹ���';break;
				case -5: $message = '����������������';break;
			}
			return array('errno' => $rs, 'message' => $message);
		}
	} else {
		$rs1 = $tuanAward->lottery($uid, ITuanAward::LOTTERY_TYPE_QQ);
		if($rs1 < 0 && $rs1 != -4) {
			switch ($rs1) {
				case -1: $message = '���첻�ܳ齱';break;
				case -2: $message = '�齱ʱ�仹δ��ʼ';break;
				case -3: $message = '�齱ʱ���Ѿ�����';break;
				case -5: $message = '����������������';break;
			}
			return array('errno' => $rs1, 'message' => $message);
		}
		$rs2 = $tuanAward->lottery($uid, ITuanAward::LOTTERY_TYPE_QQVIP);
		if ($rs2 < 0) {
			switch ($rs2) {
				case -1: $message = '���첻�ܳ齱';break;
				case -2: $message = '�齱ʱ�仹δ��ʼ';break;
				case -3: $message = '�齱ʱ���Ѿ�����';break;
				case -4: $message = '���Ѿ��μӹ���';break;
				case -5: $message = '����������������';break;
			}
			return array('errno' => $rs2, 'message' => $message);
		}
		if(is_array($rs1)) {
			$rs = array_merge($rs1, $rs2);
		} else {
			$rs = $rs2;
		}
	}
	
	return array('errno' => 0, 'message' => implode(' ', $rs));
}

//�õ��齱��
function tuan_getUserCode() {
	$uid = IUser::getLoginUid();
	if (!$uid) {
		return array('errno'=> 1, 'message'=>'�����ȵ�¼��лл���');
	}
	
	//�ж��Ƿ�QQ�û�
/*	$rs = IUser::validateUserFromQQ($uid);
	$userInfo = IUser::getUserInfo($uid);
	if (!$rs['validate']) {
		return array('errno' => 5, 'message' => $userInfo['icsonid']);
	}*/
	$wid = IUser::getSiteId();
	$key = IPageCahce::getCacheKey('tuan', 'tuan_qqvip_lottery', $wid);
	$value = IPageCahce::getCacheData($key);
	if(!empty($value)) {
		$times = unserialize($value);
		$tuanAward = new ITuanAward($times['lottery_start_time'], $times['lottery_end_time'], $times['lottery_publish_time'], $times['lottery_order_time']);
		$codes = $tuanAward->getCodeCache($uid);
		$pc_codes = array();
		if(isset($codes[ITuanAward::LOTTERY_TYPE_QQ])) {
			$pc_codes = array_merge($pc_codes, $codes[ITuanAward::LOTTERY_TYPE_QQ]);
		}
		if(isset($codes[ITuanAward::LOTTERY_TYPE_QQVIP])) {
			$pc_codes = array_merge($pc_codes, $codes[ITuanAward::LOTTERY_TYPE_QQVIP]);
		}
		$m_codes = array();
		if(isset($codes[ITuanAward::LOTTERY_TYPE_MOBILE])) {
			$m_codes = array_merge($m_codes, $codes[ITuanAward::LOTTERY_TYPE_MOBILE]);
		}
		return array('errno' => 0, 'data' => array( 'pc' => $pc_codes, 'm' => $m_codes ));
	} else {
		return array('errno'=> 2, 'message'=>'����������������');
	}
}
