<?php

    function page_test_index() {
    class classname
    {
        function __construct()
        {
            echo __METHOD__,"\n";
        }
    }
    function funcname()
    {
        echo __FUNCTION__,"\n";
    }
        //const $li = 12;

        $a = 'classname';
        $obj = new $a; // prints classname::__construct
        $b = 'funcname';
        $b(); // prints funcname
        //echo constant('li'), "\n"; // prints global

    }
?> 