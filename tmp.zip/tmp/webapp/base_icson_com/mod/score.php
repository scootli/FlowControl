<?php
	
	require_once(PHPLIB_ROOT . 'api/IUser.php');
	require_once(PHPLIB_ROOT . 'api/appplatform/platform/web_stub_cntl.php');
	require_once(PHPLIB_ROOT . 'api/appplatform/platform/lang_util.php');
	require_once(PHPLIB_ROOT . 'api/appplatform/pointsaccountao_stub4php.php');
	
	Logger::init();
	
	/**
	* 易讯积分接口查询
	* 500 没登录
	* 501 页面传说uid为空或者不正确
	* 101 查询积分接口错误
	*/
	function score_getUserScore(){
		//校验登录态
		
		
		$uid = IUser::getLoginUid(); 		
		if (empty($uid)) {
			return array('errno' => 500);
		}
		if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
			return array('errno' => 501);
		}	
		
		$totalAvailPoint = 0;//积分+账户余额
		$cashs = 0;//账户余额
		$points = 0;//积分

		//查询积分账户系统
		$cntl = new WebStubCntl();
        $sPassport = "0123456789";
        $cntl->setDwOperatorId($uid);
        $cntl->setSPassport($sPassport);
        $cntl->setDwSerialNo(10002);
        $cntl->setDwUin($uid);
        $cntl->setWVersion(2);		
		$cntl->setCallerName("basescore");


		$getPointsAccouReq = new GetPointsAccountReq();
        $getPointsAccouResp = new GetPointsAccountResp();
		$getPointsAccouReq->machineKey = ToolUtil::getClientIP();
        $getPointsAccouReq->source = __FILE__;
        $getPointsAccouReq->sceneId = 0;
		$getPointsAccouReq->inReserve = "";
		$getPointsAccouReq->icsonUid = $uid;		
		$ret = $cntl->invoke($getPointsAccouReq, $getPointsAccouResp, 3);

		if($ret != 0  ){ 
			$errMsg = "ret code:".$ret.",errMsg:".$getPointsAccouResp->errmsg;
			return array('errno' => 101,
						 "errmsg" =>$errMsg );
		}
		$totalAvailPoint = $getPointsAccouResp->pointsAccountPo->dwTotalAvailablePoints;
		$points = $getPointsAccouResp->pointsAccountPo->dwPromotionPoints;
		$cashs = $getPointsAccouResp->pointsAccountPo->dwCashPoints;
		$expiringPromotionPoints = $getPointsAccouResp->pointsAccountPo->dwExpiringPromotionPoints;
		$expiringPromotionPointsTime = $getPointsAccouResp->pointsAccountPo->dwExpiringPromotionPointsTime;

		return array('errno' => 0,
					 'totalAvailPoint' => $totalAvailPoint,
					 'points' => $points,
					 'cashs' => $cashs,
					'expiringPromotionPoints'=>$expiringPromotionPoints,
					 'expiringPromotionPointsTime' => $expiringPromotionPointsTime 
		);
	}
	
	/**
	* 积分明细接口List，考虑到明细很长，需要分页进行查询
	* 500 没登录
	* 501 页面传说uid为空或者不正确
	* 101 查询积分接口错误
	*/
	function score_getScoreList(){
		$page = empty($_GET['page'])?0:intval($_GET['page']);
		$pagesize =  empty($_GET['pagesize'])?20:intval($_GET['pagesize']);
		$pointype = empty($_GET['pointype'])?0:intval($_GET['pointype']);
		//校验登录态
		$uid = IUser::getLoginUid();		
		if (empty($uid)) {
			return array('errno' => 500);
		}

		if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
			return array('errno' => 501);
		}		
		//查询积分账户系统
		$cntl = new WebStubCntl();
        $sPassport = "0123456789";
        $cntl->setDwOperatorId($uid);
        $cntl->setSPassport($sPassport);
        $cntl->setDwSerialNo(10002);
        $cntl->setDwUin($uid);
        $cntl->setWVersion(2);		
		$cntl->setCallerName("basescorelist");

		$pointsAccountDetailReq = new GetPointsAccountDetailReq();
		$pointsAccountDetailResp = new GetPointsAccountDetailResp();
		$pointsAccountDetailFilter = new PointsAccountDetailFilterPo();

		$pointsAccountDetailFilter->dwVersion = 0;
		$pointsAccountDetailFilter->ddwIcsonUid = $uid;
		$pointsAccountDetailFilter->dwPointsType = $pointype ;//积分类型, 1：现金积分、2：促销积分  默认0，查找所有积分明细
		$pointsAccountDetailFilter->dwPageid = $page;
		$pointsAccountDetailFilter->dwPagesize = $pagesize;

		$pointsAccountDetailFilter->cIcsonUid_u = 1;
		$pointsAccountDetailFilter->cPointsType_u = 1;
		$pointsAccountDetailFilter->cPageid_u = 1;
		$pointsAccountDetailFilter->cPagesize_u = 1;

		$pointsAccountDetailReq->machineKey = ToolUtil::getClientIP();
        $pointsAccountDetailReq->source = __FILE__;
        $pointsAccountDetailReq->sceneId = 0;
		$pointsAccountDetailReq->inReserve = "";
		$pointsAccountDetailReq->PointsDetailFilterPo = $pointsAccountDetailFilter;	

		$ret = $cntl->invoke($pointsAccountDetailReq, $pointsAccountDetailResp, 3);

		if($ret != 0 || $pointsAccountDetailResp->result != 0 ){
			$errMsg = "ret code:".$ret.",errMsg:".$pointsAccountDetailResp->errmsg;
			return array('errno' => 101,
						 "errmsg" =>$errMsg );
		}
		$pointsDetailList =  $pointsAccountDetailResp->pointsAccountDetailPoList;
		$data = array();
		$data['num'] = $pointsDetailList->dwDetailTotalNum;
		$data['uid'] = $pointsDetailList->ddwIcsonUid;
		$detaillist = array();		
		foreach($pointsDetailList->vecPointsAccountDetailPoList as $pointsitem){
			$item = array();
			$item['detailId'] = $pointsitem->ddwDetailId;
			$item['totalAvailablePoints'] = $pointsitem->dwTotalAvailablePoints;
			$item['detailPoints'] = $pointsitem->nDetailPoints;
			$item['pointsType'] = $pointsitem->dwPointsType;
			$item['detailType'] = $pointsitem->dwDetailType;			
			$item['detailState'] = $pointsitem->dwDetailState;
			$item['detailAddtime'] = $pointsitem->dwDetailAddtime;
			$item['detailExpiredTime'] = $pointsitem->dwExpiredTime;
			$item['detailLastmodifytime'] = $pointsitem->dwDetailLastmodifytime;
			$item['remarks'] = $pointsitem->strRemarks;
			array_push($detaillist,$item);
		}
		$data['list'] = 	$detaillist ;
		return array('errno'=>0,'data'=>$data);
	}

?>