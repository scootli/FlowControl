<?php
Logger::init ();

/**
 * �ҵļ۸񱣻�(ҳ��ģ��)
 */
function page_mypriceprotect_page()
{
	$uid = ToolUtil::checkLoginOrRedirect();

	//��� 20130409
	ToolUtil::setCurrentPageId(3, 11708460);

	$TPL = TemplateHelper::getBaseTPL(0, "mypriceprotect", array ('titleDesc' => '�۸񱣻�'));
	$TPL->set_var('pageName', '�۸񱣻�');

	//��ȡ�û��ļ۸񱣻���Ϣ
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0);
	if($currentPage < 1)
	{
		$currentPage = 1;
	}

	$pageSize = 10;
	$datalist = EA_AutoPayBack::getPayBackInfo($uid, $currentPage, $pageSize);
	if($datalist === false)
	{
		Logger::err( "EA_AutoPayBack::getPayBackInfo failed, code:" . EA_AutoPayBack::$errCode . ', msg:' . EA_AutoPayBack::$errMsg . ', uid:' . $uid);
		return _output_error( "ϵͳ��æ�����Ժ����ԣ�", $TPL );
	}

	$total = isset($datalist['total']) ? $datalist['total'] : 0 ;
	$TPL->set_file(array('contentHandler' => 'mypriceprotect_content.tpl'));
	$TPL->set_block('contentHandler', 'mypriceprotection_list', 't_mypriceprotection_list');
	if(is_array($datalist['data']) && count($datalist['data']) >0)
	{
		foreach ($datalist['data'] as $v)
		{
			$result = $v['result'];
			$tips =
			'<div class="wrap_layout_track">
				<a class="question"></a>
				<div class="layout_popup" style="">
					<div class="layout_inner">'.EA_AutoPayBack::getForbiddenReason($result).'</div>
					<div class="layout_arrow_top">
						<span class="">��</span><i>��</i>
					</div>
				</div>
			</div>';

			$php_result = ($result == EA_AutoPayBack::$status['APB_STATUS_VALID']) ? '�Ѳ���' : '����ʧ��';
			$php_result_desc = ($result == EA_AutoPayBack::$status['APB_STATUS_VALID']) ? '<a href="http://base.51buy.com/myintegral.html" class="success_a1" target="_blank">�鿴����</a>' : $tips;

			$price_sign = '<span class="i_yuan">&yen;</span>';
			$params = array(
				'order_char_id' => $v['order_char_id'],
				'create_time' => date("Y-m-d H:i:s", $v['create_time']),
				'product_id' => $v['product_id'],
				'product_char_id' => $v['product_char_id'],
				'name' => ToolUtil::transXSSContent($v['name']),
				'price' => $v['price'],
				'buy_num' => $v['buy_num'],
				'paid_back_price' => $v['paid_back_price'],
				'php_img' => '<img src="' . IProduct::getPic($v['product_char_id'], 'small') . '" alt="'.ToolUtil::transXSSContent($v['name']).'" title="'.ToolUtil::transXSSContent($v['name']).'">',
				'php_url' => 'http://item.51buy.com/item-' . $v['product_id'] . '.html',
				'php_result' => $php_result,
				'php_result_desc' => $php_result_desc,
				'icson_price' => $v['real_price']/100,
				'lowest_price' => ($result == EA_AutoPayBack::$status['APB_STATUS_VALID']) ? $price_sign . $v['lowest_price']/100 : '-',
				'paid_back_price' => $v['paid_back_price'],
				'paid_back_price_money' => $v['paid_back_price']/10,
			);
			$TPL->set_var($params);
			$TPL->parse('t_mypriceprotection_list', 'mypriceprotection_list', true);
			$TPL->unset_var(array_keys($params));

		}
		$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/mypriceprotect-{page}.html', $currentPage, ceil($total/$pageSize) )  . '</div></div>');
	}
	else
	{
		$TPL->set_var('page','');
		$TPL->set_var(array('t_mypriceprotection_list' => '<td colspan="7"><p class="kong">���Ķ����л�û�з���"�۸񱣻�"����Ʒ</p></td>'));
	}

	$rst = ISMS::updateSMS($uid, ISmsBizs::Price_Record, 0);
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

/**
 * �����ַ����
 * @param unknown_type $str ����ַ���
 * @param unknown_type $TPL ģ��
 */
function _output_error($str, &$TPL) {
	$TPL->set_var ( 'content', '<div class="i_content" style="text-align:center">' . $str . '</div>' );
	$TPL->out ();
}
