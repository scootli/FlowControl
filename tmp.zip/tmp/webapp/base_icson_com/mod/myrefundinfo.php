<?php
require_once (PHPLIB_ROOT . 'api/IRMANew.php');
require_once (PHPLIB_ROOT . 'api/IUser.php');
require_once (PHPLIB_ROOT . 'api/IOrder.php');
require_once (PHPLIB_ROOT . 'inc/district.inc.php');
require_once (PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once (PHPLIB_ROOT . 'api/IShipping.php');
require_once (PHPLIB_ROOT . 'api/IShippingTime.php');
require_once (PHPLIB_ROOT . 'inc/ship.inc.php');
require_once (PHPLIB_ROOT . 'lib/Template.php');

Logger::init ();

function page_myrefundinfo_page(){
	global $rma_refundType, $rma_refundStatus;
	$uid = ToolUtil::checkLoginOrRedirect();
	$whId = IUser::getSiteId ();
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'cssFile'	=> 'http://st.icson.com/static_v1/css/mycenter/myorder.css',
		'titleDesc' => '�˿�����'
	));
	$TPL->set_var('pageName', '<a href="http://base.51buy.com/myrefund.html"> �˿�����</a> > ����');

	$TPL->set_file(array(
		'contentHandler' => 'myrefund_info.tpl'
	));

	//����ID
	if(!isset($_GET['customer_request_id'])){
		return false;
	}
	$rma_CustomerRequestID = $_GET['customer_request_id'];

	//����ID
	if(!isset($_GET['register_sysno'])){
		return false;
	}
	$register_sysno = $_GET['register_sysno'] + 0;
	$rma_CustomerRefundtInfo = IRMANew::getCustomerRefund_detail($uid, $rma_CustomerRequestID, $register_sysno);
	if(false === $rma_CustomerRefundtInfo || !is_array($rma_CustomerRefundtInfo)){
		Logger::err('IRMANew::getCustomerRefund_detail failed-' . IRMANew::$errCode . '-' . IRMANew::$errMsg . ',uid:' . $uid . ',rma_request_id:' . $rma_CustomerRequestID . ', register_sysno:' . $register_sysno);
		$rma_CustomerRefundtInfo = "";
	}
	if(isset($rma_CustomerRefundtInfo)  && count($rma_CustomerRefundtInfo) > 0){
		foreach($rma_CustomerRefundtInfo as &$rmainfo){
			//������Ϣ
			if(2 == $rmainfo['RefundTypeSysNo']){
				$refund_info = "<dt class=\"tit hd\">������Ϣ</dt>
									<dd class=\"con\">�˿ʽ��{$rma_refundType[$rmainfo['RefundTypeSysNo']]}</dd>
									<dd class=\"con\">������������{$rmainfo['RefundAccountName']}</dd>
									<dd class=\"con\">�����˻���{$rmainfo['RefundAccountNo']}</dd>
									<dd class=\"con\">�����˳��У�{$rmainfo['ProvinceName']}</dd>
									<dd class=\"con\">֧�����ƣ�{$rmainfo['CityName']}</dd>
								</dt>";

				//$rmainfo['RefundBankCity'];$rmainfo['RefundBankSubBranchSysNo']
			}else{
				$refund_info = "<dt class=\"tit hd\">������Ϣ</dt>
									<dd class=\"con\">�˿ʽ��{$rma_refundType[$rmainfo['RefundTypeSysNo']]}</dd>
								</dt>";
			}

			//������Ʒ
			if(isset($rmainfo['Iproducts']) && !empty($rmainfo['Iproducts'])){
				$pids = array();
				foreach($rmainfo['Iproducts'] as &$val){
					$pids[] = $val['I_ProductSysNo'];
				}
				$product_info = get_products_info($uid, $rmainfo['SOID'],$pids);
			}else{
				$product_info = "";
			}
			$param = array(
				'php_order_id' => $rmainfo['SOID'],//������
				'php_refund_status' =>$rma_refundStatus[$rmainfo['Status']],//�˿�״̬
				'php_refund_date' => (empty($rmainfo['rowModifyDate']) ||(strtotime($rmainfo['rowModifyDate']) < 0)) ? $rmainfo['RequestDate'] : $rmainfo['rowModifyDate'],//����ʱ��
				'php_refund_info' => $refund_info,//������Ϣ
				'php_product_info' => $product_info,//������Ʒ
				'php_refund_amt' => sprintf("%.2f", $rmainfo['RequestAmt']/100),//���ַ���
				'php_refund_point' => sprintf("%.2f", $rmainfo['RequestPoint']/100),//�ֽ𷵻�
				'php_count' => sprintf("%.2f", ($rmainfo['RequestPoint']/100) + ($rmainfo['RequestAmt']/100)),//�ϼ�
				'php_description' => $rmainfo['ProductDesc'],//����/�˻���ԭ������
			);
			$TPL->set_var($param);
			$TPL->unset_var($param);
		}
	}
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//��ȡ�������Ʒ��Ϣ
function get_products_info($uid, $order_id, $pids){
	$html = "";
	$order_detail = Iorder::getOneOrderDetail($uid, $order_id);
	if($order_detail === false){
		Logger::err('Iorder::getOneOrderDetail failed-' . Iorder::$errCode . '-' . Iorder::$errMsg . ',uid:' . $uid . ',order_id:' . $order_id);
		continue;
	}

	if(!isset($order_detail['order_char_id'])){
		ToolUtil::redirect("http://base.51buy.com");
	}

	if(isset($order_detail['items']) && count($order_detail['items']) > 0 ){
		$products = array();
		foreach($order_detail['items'] as $item){//������Ʒ��ɸѡ
			if(in_array($item['product_id'], $pids)){
				$products[$item['product_id']] = $item;
			}

			if(isset($item['gift'])){
				foreach($item['gift'] as $giftItem){//����Ʒ�������ɸѡ
					if(in_array($giftItem['product_id'], $pids)){
						$products[$giftItem['product_id']] = $giftItem;
					}
				}
			}
		}

		foreach($products as &$p){
			$p_id = $p['product_id'];
			$p_name = $p['name'];
			$p_price = sprintf("%.2f", $p['price']/100);
			$p_cash_back = sprintf("%.2f",$p['cash_back']/100);
			$p_buy_num = $p['buy_num'];
			$p_price_total = sprintf("%.2f",$p['price'] * $p['buy_num']/100);
			$html .="<tr>
						<td class=\"left\"><a target=\"_blank\" href=\"http://item.51buy.com/item-{$p_id}.html\">{$p_name}</a><div></div></td>
						<td><span class=\"yuan\">&yen;</span>{$p_price}</td>
						<td><span class=\"yuan\">&yen;</span>{$p_cash_back}</td>
						<td>$p_buy_num</td>
						<td><span class=\"yuan\">&yen;</span>{$p_price_total}</td>
					</tr>";
		}
	}
	return $html;
}