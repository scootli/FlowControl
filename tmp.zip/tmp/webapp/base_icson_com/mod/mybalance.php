<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');

require_once(PHPLIB_ROOT . 'api/appplatform/platform/web_stub_cntl.php');
require_once(PHPLIB_ROOT . 'api/appplatform/platform/lang_util.php');
require_once(PHPLIB_ROOT . 'api/appplatform/pointsaccountao_stub4php.php');

Logger::init();

function mybalance_page(){
	
	global $_SCORE_TYPE;
	$uid = ToolUtil::checkLoginOrRedirect();

	$TPL = TemplateHelper::getBaseTPL(0, "mybalance", array(
		'titleDesc' => '�ҵ��˻����'
	));
	$TPL->set_var('pageName', '�ҵ��˻����');

	$TPL->set_file(array(
		'contentHandler' => 'mybalance_content.tpl'
	));

	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	$pageSize = 10;

	$TPL->set_block("contentHandler", 'list', 't_list');
	
	//��ȡ�û�����
	$user = getBalanceAndList($uid,$currentPage,$pageSize);
	if($user === false){
		$TPL->set_var('t_list', '');
		$TPL->set_var('page', '');
		$TPL->set_var('content', '');
		$TPL->out();
		return;
	}
	$TPL->set_var('balance',  round($user['balance']/10,1) );

	if(empty($user['list'])){		
		$TPL->set_var('t_list', '<tr><td colspan="6"><p class="kong">����û�л�ù��˻�����֧��¼��</p></td></tr>');
		$TPL->set_var('page', '');
	}else{
		$scoreType = array();
		foreach ($_SCORE_TYPE as $type){
				$scoreType[$type['id']] = $type['description'];
		}
		foreach($user['list'] as $item){
				$params = array(
						'time' => date('Y-m-d', $item['time'] ),
						'score_type' => isset($scoreType[$item['score_type']]) ? $scoreType[$item['score_type']] : '',
						'score_from' => str_replace('����','�˻����',$item['score_from']),
						'score' => round($item['score']/10,1)
				);
				$TPL->set_var($params);
				$TPL->parse('t_list', 'list', true);
				$TPL->unset_var($params);
		}

		$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/mybalance-{page}.html', $currentPage, ceil($user['total'] / $pageSize))  . '</div></div>');
	}	
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

function getBalanceAndList($uid,$currentPage,$pageSize){
	//��ѯ�����˻�ϵͳ
	$cntl = new WebStubCntl();
	$sPassport = "0123456789";
	$cntl->setDwOperatorId($uid);
	$cntl->setSPassport($sPassport);
	$cntl->setDwSerialNo(10002);
	$cntl->setDwUin($uid);
	$cntl->setWVersion(2);		
	$cntl->setCallerName("basemybalance");

	$getPointsAccouReq = new GetPointsAccountReq();
	$getPointsAccouResp = new GetPointsAccountResp();
	$getPointsAccouReq->machineKey = ToolUtil::getClientIP();
	$getPointsAccouReq->source = __FILE__;
	$getPointsAccouReq->sceneId = 0;
	$getPointsAccouReq->inReserve = "";
	$getPointsAccouReq->icsonUid = $uid;	

	$ret = $cntl->invoke($getPointsAccouReq, $getPointsAccouResp, 2);

	if($ret != 0  ){ 
		Logger::err('Get Points::GetPointsAccount failed-' .$ret . '-' . $getPointsAccouResp->errmsg);
		return false;
	}

	$user['balance'] = $getPointsAccouResp->pointsAccountPo->dwCashPoints;
	
	//����ϸ
	$pointsAccountDetailReq = new GetPointsAccountDetailReq();
	$pointsAccountDetailResp = new GetPointsAccountDetailResp();
	$pointsAccountDetailFilter = new PointsAccountDetailFilterPo();

	$pointsAccountDetailFilter->dwVersion = 0;
	$pointsAccountDetailFilter->ddwIcsonUid = $uid;
	$pointsAccountDetailFilter->dwPointsType = 1 ;//ֻ���Ҵ�������
	
	$pointsAccountDetailFilter->dwPageid = $currentPage-1;
	$pointsAccountDetailFilter->dwPagesize = $pageSize;

	$pointsAccountDetailFilter->cIcsonUid_u = 1;
	$pointsAccountDetailFilter->cPointsType_u = 1;
	$pointsAccountDetailFilter->cPageid_u = 1;
	$pointsAccountDetailFilter->cPagesize_u = 1;

	$pointsAccountDetailReq->machineKey = ToolUtil::getClientIP();
	$pointsAccountDetailReq->source = __FILE__;
	$pointsAccountDetailReq->sceneId = 0;
	$pointsAccountDetailReq->inReserve = "";
	$pointsAccountDetailReq->PointsDetailFilterPo = $pointsAccountDetailFilter;	

	$ret = $cntl->invoke($pointsAccountDetailReq, $pointsAccountDetailResp, 2);

	if($ret != 0 || $pointsAccountDetailResp->result != 0 ){
		Logger::err('Get Points::PointsAccountDetail failed-' .$ret . '-' . $pointsAccountDetailResp->errmsg);		
		$user['total']= 0 ;
		$user['list']  = array();
		return $user;
	}
	
	$pointsDetailList =  $pointsAccountDetailResp->pointsAccountDetailPoList;
	$user['total'] = $pointsDetailList->dwDetailTotalNum;
	$data = array();	
	$detaillist = array();	
	foreach($pointsDetailList->vecPointsAccountDetailPoList as $pointsitem){
		$item = array();
		$item['score'] = $pointsitem->nDetailPoints;
		$item['score_type'] = $pointsitem->dwDetailType;		
		$item['time'] = $pointsitem->dwDetailAddtime;		
		$item['score_from'] = $pointsitem->strRemarks;
		array_push($detaillist,$item);
	}
	$user['list'] = $detaillist ;
	return $user;
}