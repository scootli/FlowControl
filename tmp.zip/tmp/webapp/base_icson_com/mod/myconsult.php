<?php
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IReviewAsking.php');
require_once(PHPLIB_ROOT . 'api/IOrder.php');
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'api/IProduct.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');

Logger::init();

function page_myconsult_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$wid = IUser::getSiteId();
	$TPL = TemplateHelper::getBaseTPL(0, 'myconsult', array(
		'titleDesc' => '��Ʒ��ѯ'
	));

	$TPL->set_var('pageName', '��Ʒ��ѯ');
	$TPL->set_file(array(
		'contentHandler' => 'myconsult.tpl'
	));

	$pageSize = 10;
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	$myConsultList = IAsking::getAllUserAsking($uid, ($currentPage-1) * $pageSize, $pageSize);
	if($myConsultList === false){
		Logger::err('IAsking::getAllUserAsking failed-' . IAsking::$errCode . '-' . IAsking::$errMsg);
		return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
	}

	$myConsultCount = IAsking::getAllUserAsking($uid);
	if($myConsultCount === false){
		Logger::err('IAsking::getAllUserAsking failed-' . IAsking::$errCode . '-' . IAsking::$errMsg);
		return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
	}

	$myConsultList = ToolUtil::gbJsonDecode($myConsultList);
	$myConsultCount = ToolUtil::gbJsonDecode($myConsultCount);
	if ( (!is_array($myConsultList) && !empty($myConsultList)) || (!is_array($myConsultCount) && !empty($myConsultCount)) ){
		Logger::err('myConsultList or myConsultCount is not array' . IAsking::$errCode . '-' . IAsking::$errMsg);;
		return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
	}

	$TPL->set_block('contentHandler', 'myconsult_list', 't_myconsult_list');

	$count = count($myConsultCount);
	$total = empty($count) ? 0 : ceil($count / $pageSize);
	if( empty($myConsultCount) || empty($myConsultList) ){
		$TPL->set_var('t_myconsult_list', '<tr><td colspan="4"><p class="kong">����û�н��й���ѯ��</p></td></tr>');
		$TPL->set_var('page', '');
	}
	else {
		$productIds = array(); //��Ʒ��Ϣ
		foreach($myConsultList as &$product){
			$productIds[] = $product['product_id'];
		}
		$productInfo = IProduct::getProductsInfo($productIds, $wid);
		if($productInfo === false){
			Logger::err('IProduct::getProductsInfo failed-' . IProduct::$errCode . '-' . IProduct::$errMsg);
			return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
		}

		foreach($myConsultList as $k => &$product){
			if (! isset($productInfo[$product['product_id']])) {
				unset($myConsultList[$k]);
				continue;
			}

			$params = array(
				'id' => $myConsultList[$k]['id'],
				'content' =>ToolUtil::transXSSContent($myConsultList[$k]['content']),
				'create_time' => date('Y-m-d H:i:s',$myConsultList[$k]['create_time']),
				'product_id' => $myConsultList[$k]['product_id'],
				'name' => $productInfo[$product['product_id']]['name'],
				'product_char_id' => $productInfo[$product['product_id']]['product_char_id'],
				'product_replies' => _get_product_replies($product),
			);

			$TPL->set_var($params);
			$TPL->parse('t_myconsult_list', 'myconsult_list', true);
			$TPL->unset_var(array_keys($params));
		}

		$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myconsult-{page}.html', $currentPage, $total)  . '</div></div>');
	}

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//��ȡ�ҵ���ѯ�б�
function myconsult_page(){
	$uid=IUser::getLoginUid();
	$wid = IUser::getSiteId();
	if(empty($uid)){
		return array('errno' => 500);
	}

	$myConsultList = IAsking::getAllUserAsking($uid);

	if($myConsultList === false){
		Logger::err('IAsking::getAllUserAsking failed-' . IAsking::$errCode . '-' . IAsking::$errMsg);
		return  false;
	}

	$myConsultList = ToolUtil::gbJsonDecode($myConsultList);
	if(!is_array($myConsultList) && !empty($myConsultList)){
		return  false;
	}
	if(empty($myConsultList)){
		return array('errno' => 1);
	}

	//��Ʒ��Ϣ
	$productIds = array();
	foreach($myConsultList as $product ){
		$productIds[] = $product['product_id'];
	}
	$productInfo = IProduct::getProductsInfo($productIds, $wid);
	if($productInfo === false){
		Logger::err('IProduct::getProductsInfo failed-' . IProduct::$errCode . '-' . IProduct::$errMsg);
		return  false;
	}

	foreach($myConsultList as $k => $product ){
		if(!isset($productInfo[$product['product_id']])) {
			unset($myConsultList[$k]);
			continue;
		}

		$myConsultList[$k] = array_merge($myConsultList[$k], array(
			'id' => $myConsultList[$k]['id'],
			'content' =>ToolUtil::transXSSContent($myConsultList[$k]['content']),
			'create_time' => $myConsultList[$k]['create_time'],
			'product_id' => $myConsultList[$k]['product_id'],
			'name' => $productInfo[$product['product_id']]['name'],
			'product_char_id' => $productInfo[$product['product_id']]['product_char_id'],
		));
	}
	return $myConsultList;
}

//������ʾ text-align
function _output_error($str, &$TPL){
	$TPL->set_var('content', '<div class="i_content" style="text-align:center">' . $str . '</div>');
	$TPL->out();
}

/**
 * ��ȡ������Ʒ�ظ�
 * @param array $product ��Ʒ��ϸ��Ϣ
 * @return string
 */
function _get_product_replies(&$product) {
	$html = '';

	if (!empty($product['replies'])) {
		foreach($product['replies'] as &$replies){
			$html .= "<p>{$replies['content']}</p>";
		}
	}

	return $html;
}