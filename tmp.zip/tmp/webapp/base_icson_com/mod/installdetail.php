<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');
require_once(PHPLIB_ROOT . 'api/IInstall.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'api/IProduct.php');

Logger::init();

function page_installdetail_page(){
	global $install_PureLandMaterialType,//̨�����
		   $install_AirConditionLineType,//���߳���
		   $install_AirConditionBracketType,//֧��
		   $install_AirConditionWallType,//��ǽ��
		   $install_status;//״ֵ̬
	global $_District, $_Province, $_City;
	$wh_id = IUser::getSiteId();
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'cssFile'	=> 'http://st.icson.com/static_v1/css/mycenter/myorder.css',
		'titleDesc' => '���Ű�װ����'
	));
	$TPL->set_var('pageName', '<a href="http://base.51buy.com/myinstall.html">���Ű�װ</a> > �鿴����');

	$TPL->set_file(array(
		'contentHandler' => 'installdetail.tpl'
	));

	$sosysno = $_GET['sosys_no'] + 0;
	$detail = IInstall::installdetail($sosysno, $uid);
	if($detail === false){
		Logger::err('IInstall::installdetail failed-' . IInstall::$errCode . '-' . IInstall::$errMsg);
	}

	if(!empty($detail)){
		foreach($detail as $install){
			$order_id = 0;
			if(strlen($install['SoSysNo']) == 7){
				$order_id = "100" .$install['SoSysNo'];
			}else if(strlen($install['SoSysNo']) == 8){
				$order_id = "10" .$install['SoSysNo'];
			}else{
				$order_id = "1" .$install['SoSysNo'];
			}

			$materialInfo = '';
			if($install['C3SysNo'] == 736){//�յ�
				$materialInfo = '<dd class="con">���߳��ȣ�' . $install_AirConditionLineType[$install['AirConditionLineType']] . '</dd>
								<dd class="con">֧�ܣ�' . $install_AirConditionBracketType[$install['AirConditionBracketType']] . '</dd>
								<dd class="con">��ǽ����' . $install_AirConditionWallType[$install['AirConditionWallType']] . '</dd>';
			}else{//��ˮ�豸
				$materialInfo = '<dd class="con">̨����ʣ�' . $install_PureLandMaterialType[$install['PureLandMaterialType']] . '</dd>';
			}
			$param = array(
				'php_install_sysno' => $install['SysNo'],
				'php_install_status' => @$install_status[$install['Status']],
				'php_install_cancel' => ($install['Status'] == 0) ? '&nbsp;&nbsp;<a href="#" class="second" onclick="G.app.mycenter.myinstall.cancel(this, \''.$install['SysNo'].'\');return false;">ȡ��ԤԼ</a>' : '',
				'php_install_date' => $install['CreateTime'],//date("Y-m-d H:i:s",strtotime($install['CreateTime'])),
				'php_install_order_id' => $order_id,
				'php_install_product_name' => ToolUtil::transXSSContent(getProductName($install['ProductSysNo'], 1)),//ToolUtil::transXSSContent($install['ProductName']),
				'php_install_product_sysno' => $install['ProductSysNo'],
				'php_install_materialInfo' => $materialInfo,
				'php_install_install_time' => $install['InstallTime'],
				'php_install_contact_name' => ToolUtil::transXSSContent($install['ContactName']),
				'php_install_Contact_phone' => empty($install['ContactPhone']) ? $install['ContactMobile'] : $install['ContactPhone'],
				'php_install_install_address' => (@$_Province[$_District[$install['InstallAreaSysNo']]['province_id']] . @$_City[$_District[$install['InstallAreaSysNo']]['city_id']]['name'] . @$_District[$install['InstallAreaSysNo']]['name'] . $install['InstallAddress']),//$install['InstallAddress'],
				'php_install_memo' => ToolUtil::transXSSContent($install['Memo']),
			);
		}
	}else{
		$param = array(
				'php_install_sysno' => '',
				'php_install_status' => '',
				'php_install_cancel' => '',
				'php_install_date' => '',
				'php_install_order_id' => '',
				'php_install_product_name' => '',
				'php_install_product_sysno' => '',
				'php_install_materialInfo' => '',
				'php_install_install_time' => '',
				'php_install_contact_name' => '',
				'php_install_Contact_phone' => '',
				'php_install_install_address' => '',
				'php_install_memo' => '',
			);
		Logger::err('IInstall::installdetail is empty' . IInstall::$errCode . '-' . IInstall::$errMsg . ',uid:' . $uid . ',order_id:' . '10'.$sosysno);
	}
	$TPL->set_var($param);
	$TPL->unset_var($param);
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//��ȡ��Ʒ��Ϣ
function getProductName($pid, $whId){
	$ProductName = '';
	$pinfo = IProduct::getBaseInfo($pid, $whId, true);
	if($pinfo === false){
		Logger::err("IProduct::getBaseInfo failed, code:" . IProduct::$errCode . ', msg:' . IProduct::$errMsg . ',pid:' . $pid . ',whid:' . $whId);
	}else if(empty($pinfo) || count($pinfo) <0){
		Logger::err("IProduct::getBaseInfo empty, code:" . IProduct::$errCode . ', msg:' . IProduct::$errMsg . ',pid:' . $pid . ',whid:' . $whId);
	}else{
		$product_title = strip_tags($pinfo['name']);
		$product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);
		$ProductName = $product_title;
	}
	return $ProductName;
}

//ȡ������ԤԼ
function installdetail_cancel(){
	$sysno = $_GET['sysno'] + 0;
	$uid = IUser::getLoginUid();
	if(!empty($uid) && !empty($sysno)){
		$res = IInstall::setInstallCanceled($uid, $sysno);
		if(false === $res){
			Logger::err('IInstall::setInstallCanceled failed-' . IInstall::$errCode . '-' . IInstall::$errMsg . ' uid:' . $uid . ' sysno:' . $sysno);
			return array("errno" => 1);
		}
		if(is_array($res) && isset($res['errno']) && $res['errno'] ==2){
			return array("errno" => 2);
		}
		return array("errno" => 0 );
	}else{
		Logger::err('IInstall::setInstallCanceled empty-' . IInstall::$errCode . '-' . IInstall::$errMsg . ' uid:' . $uid . ' sysno:' . $sysno);
		return array("errno" => -1 );
	}
}
