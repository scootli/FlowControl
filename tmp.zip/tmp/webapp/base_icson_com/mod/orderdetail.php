<?php
require_once PHPLIB_ROOT . "lib/Config.php";
require_once PHPLIB_ROOT . 'api/IUniOrder.php';

Logger::init();

function page_orderdetail_page() {
	$uid = ToolUtil::checkLoginOrRedirect();

	$order_id = intval($_GET['order_char_id']);
	$detail = IOrder::getOneOrderDetail($uid, $order_id);
	if ($detail === false) {
		Logger::err('Iorder::getOneOrderDetail failed-' . Iorder::$errCode . '-' . Iorder::$errMsg);
	}

	if ( !isset($detail['order_char_id']) || $detail['subOrderNum'] > 0) { // �𵥶�������ʾ����ҳ
		ToolUtil::redirect("http://base.51buy.com/myorder.html");
		exit();
	}

	$wh_id = IUser::getSiteId();
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'cssFile'	=> 'http://st.icson.com/static_v1/css/mycenter/myorder_detail.css?v=2012120501',
		'titleDesc' => '��������'
	));
	$TPL->set_file(array(
		'contentHandler' => 'orderdetail.tpl'
	));
	$TPL->set_block('contentHandler', 'item_list', 't_item_list');
	$TPL->set_block('contentHandler', 'pay_btn_block', 't_pay_btn_block');

	$TPL->set_var('pageName', '<a href="http://base.51buy.com/myorder.html">�ҵĶ���</a> > ��������');

	$TPL->set_var('t_item_list');

	$siteId = $detail['hw_id'];
	$order_flow = '';
	$_status = '';
	global $_OrderState;
	foreach ($_OrderState as $item) {
		if ($item['value'] == $detail['status']) {
			$_status = $item['desc'];
		}
	}

	//֧����ʽ
	$payInfo = ToolUtil::getPayTypeInfo($detail['pay_type'], $siteId);
	$PayTypeName = false === $payInfo ? '' : $payInfo['PayTypeName'];

	//���ͷ�ʽ
	$shippingInfo = ToolUtil::getShipTypeInfo($detail['shipping_type'], $siteId );
	$shipping_type = false === $shippingInfo ? '' : $shippingInfo["ShipTypeName"];
    //������
    if(isset($detail['shipping_flag']) && $detail['shipping_flag'] == 2)
    {
        $shipping_type .= '-�����ͣ�48Сʱ���ʹ29Ԫ�������˷�';
    }
	$receiver_mobile = trim( ToolUtil::transXSSContent( $detail['receiver_mobile'] ) );
	$receiver_tel = trim( ToolUtil::transXSSContent( $detail['receiver_tel'] ) );
	$receiver_mobile = $receiver_mobile . ( !empty($receiver_mobile) && !empty($receiver_tel)? '��' : '') . $receiver_tel;

	$remain_payment_time = empty($detail['need_pay']) ? '' : '<span class="txt_strong">ʣ�ึ��ʱ�䣺' . _getRemainPaymentTimeStr($payInfo, $detail['order_date'], $detail['flag']) . '�����ڶ������Զ�ȡ����</span>';

	$param = array (
		'order_char_id' => $detail['order_char_id'],
		'order_id' => $detail['order_id'],
		'receiver' => ToolUtil::transXSSContent( $detail['receiver'] ),
		'receiver_addr' => ToolUtil::transXSSContent( $detail['receiver_addr'] ),
		'receiver_mobile' => $receiver_mobile,
		'pay_type' => $PayTypeName, //֧����ʽ
		'shipping_type' => $shipping_type, //���ͷ�ʽ
		'expect_dly_date' => ( $detail['shipping_type'] == 1 ) ? '����������ʱ�䣺'. ( empty($detail['expect_dly_date'] ) ? '' : $detail['expect_dly_date'] ). ' '. ( empty($detail['expect_dly_time_span']) ? '' : $detail['expect_dly_time_span'] ) . '��' : '', //��������ʱ��
		'order_cost' => sprintf("%.2f", $detail['order_cost'] / 100), //�����ܼ�
		'shipping_cost' => sprintf("%.2f", $detail['shipping_cost'] / 100), //�˷�
		'products_cost' => sprintf("%.2f", ( $detail['order_cost'] - $detail['shipping_cost'] ) / 100), //��Ʒ�ܼ�
		'point_pay' => sprintf("%.2f", $detail['point_pay'] / 100), //���ֵֿ�
		'price_cut' => sprintf("%.2f", $detail['price_cut'] / 100), //�����Ż�
		'promotion_coupon' => _convertPromotionOrCoupon($detail),
		'cash' => sprintf("%.2f", $detail['cash'] / 100), //�ϼ�
		'prcdfee_str' => empty($detail['prcd_cost']) ? '' : ('<li><span class="l">֧�������ѣ�</span><span class="r">&yen;' . sprintf("%.2f", $detail['prcd_cost'] / 100) . '</span></li>'), //�ϼ�
		'order_desc' => ToolUtil::transXSSContent( $detail['comment'] ),	 //��ע
		'remain_payment_time' => $remain_payment_time, //ʣ�ึ���ʱ��
	);

	$TPL->set_var($param);

	//��Ʊ��Ϣ
	if (!empty($detail['invoices'])) {
		$item = $detail['invoices'][0];
		//�Ƿ�����ֵ��Ʊ
		$isVat = $item['type_id'] == INVOICE_TYPE_VAT;
		//�Ƿ��ǻ�Ʊ����
		$isSap = 0;
		if (($detail['bits']&ORDER_SEPARATE_GOODS_INVOICE) == ORDER_SEPARATE_GOODS_INVOICE) {
			$invoice_address = IOrder::getOneInvoiceAddress($uid, $order_id);
			if (false === $invoice_address) {
				Logger::err("IOrder::getOneInvoiceAddress get error;" . IOrder::$errMsg);
			}
			else {
				$isSap = $invoice_address['separateInvoice'] == 1;
			}
		}

		$invoice_explanation_phone = ($siteId == 1001) ? '0514-82930139' : '021-61831107';
		$param = array(
			'invoice_title' => ToolUtil::transXSSContent( $item['title'] ),
			'invoice_type' => $item['type'],
			'invoice_content' => ToolUtil::transXSSContent( $item['content'] ),
			'invoice_name' => $isVat ? '<dd class="con">��˾���ƣ�' . ToolUtil::transXSSContent( $item['name'] ) . '</dd>' : '',
			'invoice_addr' => $isVat ? '<dd class="con">��˾��ַ��' .ToolUtil::transXSSContent( $item['addr'] ) . '</dd>' : '',
			'invoice_phone' => $isVat ? '<dd class="con">��˾�绰��' .ToolUtil::transXSSContent( $item['phone'] ) . '</dd>' : '',
			'invoice_taxno' => $isVat ? '<dd class="con">˰�ţ�' .ToolUtil::transXSSContent( $item['taxno'] ) . '</dd>' : '',
			'invoice_bankno' => $isVat ? '<dd class="con">�����˺ţ�' .ToolUtil::transXSSContent( $item['bankno'] ) . '</dd>' : '',
			'invoice_explanation' => $isVat ? '<dd class="con strong">��ʾ�����״ο�����ֵ˰ר�÷�Ʊ�Ŀͻ���Ӫҵִ�ա�˰��Ǽ�֤������һ����˰���ʸ�֤�顢��������֤������ '.$invoice_explanation_phone.'</dd>' : '',
			'invoice_send_status' => $isSap ? ToolUtil::transXSSContent( $invoice_address['invoice_send_status'] ) : 'invoice_hide',
			'invoiceReceiver' => $isSap ? ToolUtil::transXSSContent( $invoice_address['invoiceReceiver'] ) : '',
			'invoiceReceiverTel' => $isSap ? ToolUtil::transXSSContent( $invoice_address['invoiceReceiverTel'] ) : '',
			'invoiceReceiverMobile' => $isSap ? ToolUtil::transXSSContent( $invoice_address['invoiceReceiverMobile'] ) : '',
			'invoiceReceiveAddrDetail' => $isSap ? ToolUtil::transXSSContent( $invoice_address['invoiceReceiveAddrDetail'] ) : '',
			'invoiceReceiveAddrId' => $isSap ? ToolUtil::transXSSContent( $invoice_address['invoiceReceiveAddrId'] ) : '',
			'invoiceZipCode' => $isSap ? ToolUtil::transXSSContent( $invoice_address['invoiceZipCode'] ) : '',
		);
	}
	else {
		$param = array(
			'invoice_title' => '',
			'invoice_type' => '',
			'invoice_content' => '',
			'invoice_name' => '',
			'invoice_addr' => '',
			'invoice_phone' => '',
			'invoice_taxno' => '',
			'invoice_bankno' => '',
			'invoice_explanation' => '',
			'invoice_send_status' => 'invoice_hide',
			'invoiceReceiver' => '',
			'invoiceReceiverTel' => '',
			'invoiceReceiverMobile' => '',
			'invoiceReceiveAddrDetail' => '',
			'invoiceReceiveAddrId' => '',
			'invoiceZipCode' => '',
		);
	}
	$TPL->set_var($param);

	global $_OrderState;
	$now = time();
	$price_protect_desc = '';
	$protect_link = '';
	$price_protect_pid = array();
	//�۸񱣻�,������Ϣ
	if(($detail['status'] != $_OrderState['Return']['value'])//��ȫ���˻�
		&& ($detail['status'] != $_OrderState['ManagerCancel']['value'])//��ϵͳ����
		&& ($detail['status'] != $_OrderState['CustomerCancel']['value'])//�ǿͻ�����
		&& ($detail['status'] != $_OrderState['EmployeeCancel']['value']))//��Ա������
	{
		if(($now - $detail['order_date']) <= 86400)//�µ�ʱ���24Сʱ��
		{
			$price_protect_desc = '��������"�۸񱣻�"��Ϊ������µ�24Сʱ�ڵļ۸�䶯';
		}
		else//24Сʱ�����ɲ�������׶�
		{
			$payBack = EA_AutoPayBack::getOnePayBackInfo($order_id);
			if($payBack === false)
			{
				Logger::err( "EA_AutoPayBack::getOnePayBackInfo failed, code:" . EA_AutoPayBack::$errCode . ', msg:' . EA_AutoPayBack::$errMsg . ', uid:' . $uid . ' order_id:' . $order_id);
				$price_protect_desc = 'ϵͳ��æ';
			}
			if(empty($payBack))//�޲������
			{
				$price_protect_desc = '�µ�24Сʱ�ڣ��޷���"�۸񱣻�"��������Ʒ';
			}
			else//���ɲ������
			{
				//-2,-1,0,1
				if(is_array($payBack) && count($payBack) > 0)
				{
					$pay_count = count($payBack);
					$paid_back_price = 0;//��������
					$i = 0;//resulet = 0 || -2
					$j = 0;//resulet = -1
					foreach ($payBack as $pay)
					{
						if($pay['result'] == 1)//ֻ���㲹���ɹ��Ļ���
						{
							$paid_back_price += $pay['paid_back_price'];
							$price_protect_pid[$pay['product_id']] = $pay['paid_back_price'];
						}
						if($pay['result'] == 0 || $pay['result'] == -2)
						{
							$i++;
						}
						if($pay['result'] == -1)
						{
							$j++;
						}
					}

					if($paid_back_price > 0)//�в�������,�����ɹ�
					{
						$price_protect_desc = '�Ѳ���<span class="price_strong">' . $paid_back_price .'</span>����';
						$protect_link = '<a class="todo_link" target="_blank" href="http://base.51buy.com/mypriceprotect.html">�鿴����</a>';
					}
					else//�޻��ֲ���
					{
						if($i == $pay_count)
						{
							$price_protect_desc = '"�۸񱣻�"����������';
						}
						if($j == $pay_count)
						{
							$price_protect_desc = '�����е���Ʒ�����⸶��Χ��';
						}
					}
				}
				else//�������ݸ�ʽ�쳣
				{
					$price_protect_desc = '�����е���Ʒ�����⸶��Χ��';
				}
			}
		}

		$price_protect_block = '<div class="order_pp" >
		        <p class="pp_bd"><i class="dot" onmouseout="javascript:$(this).parent().parent(\'div\').find(\'.layout_popup\').css(\'display\', \'none\');" onmouseover="javascript:$(this).parent().parent(\'div\').find(\'.layout_popup\').css(\'display\', \'block\');"></i>' . $price_protect_desc . $protect_link . '</p>
		          <div class="layout_popup" style="display:none">
		            <div class="layout_inner">
		            <dl>
		            <dt>�۸񱣻�</dt>
		            <dd>�û��µ���24Сʱ�ڣ�����Ʒ�ļ۸�����������ǰ�۸�����û�ʵ�ʹ���۸�ģ�ͬʱ���㽵�۷��ȴ���5%�����Է��ϼ۸񱣻���������Ʒ���û��������Ѹ�Զ������Ĳ�ۡ� </dd>
		            </dl>
		            </div>
		            <div class="layout_arrow_top"> <span class="">��</span><i>��</i> </div>
		          </div>
		        </div>';

		$TPL->set_var('price_protect_block', $price_protect_block);
	}
	else
	{
		$TPL->set_var('price_protect_block', '');
	}

	global $_CP_Sp_Data;
	$hasCard = false;

	//������Ʒ
	$linkIds = array();
	$product_other = '';
	if ( isset($detail['items']) && count($detail['items']) > 0 )
	{
		foreach( $detail['items'] as $item)
		{
			// ����Ƕ��ƻ�sim�����������ۣ���û������ҳ
			if ( $item['product_id'] == $_CP_Sp_Data[SP_LT]['CardID']
				or $item['product_id'] == $_CP_Sp_Data[SP_DX]['CardID']
				or $item['product_id'] == $_CP_Sp_Data[SP_YD]['CardID'])
			{
				$product_other = '<font color="#ccc"></font>';
				$url = ICustomPhone::getUrl(0,'stepone');

				$cardBaseInfo = IProduct::getBaseInfo($item['product_id'], $wh_id, true);

				$orderDb = ToolUtil::getMSDBObj('ICSON_CORE');
				if ( false === $orderDb)
				{
					Logger::err( $orderDb->errMsg);
					return $TPL->out();
				}

				$sql = "select * from t_cp_contract_info where order_char_id=".$order_id;

				$contract_info = $orderDb->getRows($sql);
				if ( false === $contract_info || count($contract_info) == 0)
				{
					Logger::err( $orderDb->errMsg);
					return $TPL->out();
				}

				$contract_info=$contract_info[0];

				$packageInfo = ICustomPhone::getPackageOneFee($contract_info['product_id'], $contract_info['package_id'], $wh_id);
				if ( false === $packageInfo )
				{
					Logger::err( 'getPackageFeeInfo Error! - ' . ICustomPhone::$errCode . ' - ' . ICustomPhone::$errMsg . ' fee_id :' . $contract_info['package_id']);
					//�˴����ݴ����������ж�ҳ�����
					//return $TPL->out();
				}

				//��ȡ�ֻ��ײ���
				$phonePackageInfo = array();
				$ret = ICustomPhone::getPackage($phonePackageInfo, $packageInfo['package_id']);
				if (!$phonePackageInfo) {
					Logger::err( 'ICustomPhone getPackage Error! - ' . ICustomPhone::$errCode . ' - ' . ICustomPhone::$errMsg . ' package_id :' . $packageInfo['package_id']);
					//�˴����ݴ����������ж�ҳ�����
					//return $TPL->out();
				}

				$phonePackageInfo = current($phonePackageInfo);
				if ( count($detail['items']) > 1 ) { // ����һ�ſ�����������Ʒ��˵���ǹ�������Ԥ��
					$packBrief = $phonePackageInfo['package_name'];
				}
				else { // ֻ��һ�ſ���˵����ѡ������
					$packBrief = $phonePackageInfo['package_name'];
				}

				$param = array(
					'product_id' => $cardBaseInfo['product_id'],
					'package_info' => $packBrief,
					'php_url' => $cardBaseInfo['name']."(".$contract_info['num'].")",
					'product_price' => sprintf("%.2f", ($contract_info['card_price'] + $contract_info['package_price'])),
					'cash_back' => '0.00',
					'product_weight' => 0,
					'buy_num' => 1,
					'weight_total' => 0,
					'price_total' => sprintf("%.2f", ($contract_info['card_price'] + $contract_info['package_price'])),
					'warranty' => '', //����
					'product_other' => '',
				);
			}
			else
			{
				//�Ƿ�����۽ӿ��޸� modify by allenzhou 2011-12-22
				if ($item['can_evaluate'] === true) {
					$product_other = '<a class="todo_link" href="http://item.51buy.com/review-toaddexperience-'.$item['product_id'].'.html" target="_blank">����</a>';
				}
				else {
					if ($item['is_evaluated'] === true) {
						$product_other = '<font color="#ccc">������</font>';
					}
				}
				$url = "<a href='http://item.51buy.com/item-".$item['product_id'].".html' target='_blank'>".$item['name']."</a>";
				$param = array(
					'product_id' => $item['product_id'],
					'product_name' => $item['name'],
					'package_info' => '',
					'product_price' => sprintf("%.2f", $item['price']/100),
					'cash_back' => sprintf("%.2f", $item['cash_back']/100),
					'product_weight' => $item['weight'],
					'buy_num' => $item['buy_num'],
					'weight_total' => $item['weight'] * $item['buy_num'],
					'price_total' => sprintf("%.2f", $item['price'] * $item['buy_num'] / 100),
					'warranty' => $item['warranty'], //����
					'product_other' => $product_other,
					'php_url'	=> $url
				);
			}

			//����
			$param['product_gift'] = '';
			if ( isset($item['gift']) && count( $item['gift'] ) > 0 ) {
				$param['product_gift'] = '<p class="gift_wrap">';
				$wrap = '';
				foreach($item['gift'] as $gift) {
					$param['weight_total'] += $gift['weight'] * $gift['buy_num'];
//					$param['product_gift'] .= ( $wrap . '<span class="gift">['. $gift['product_type'] .']</span><a href="javascript:;" onclick="return false">' . $gift['name'] . '</a>' );
					$param['product_gift'] .= ( $wrap . '<span class="gift">['. $gift['product_type'] .']</span>' . $gift['name'] );
					$wrap = '<br/>';
				}
				$param['product_gift'] .= '</p>';
			}

			//������Ʒ�������
			$price_protect_pid_block = '';
			if(array_key_exists($item['product_id'], $price_protect_pid) && $price_protect_pid[$item['product_id']] > 0)
			{
				$price_protect_pid_block = '<div class="order_pp">
			        <p class="pp_bd"><i class="dot" onmouseout="javascript:$(this).parent().parent(\'div\').find(\'.layout_popup\').css(\'display\', \'none\');" onmouseover="javascript:$(this).parent().parent(\'div\').find(\'.layout_popup\').css(\'display\', \'block\');"></i>�Ѳ���<span class="price_strong">' . $price_protect_pid[$item['product_id']] . '</span>����<a class="todo_link" target="_blank" href="http://base.51buy.com/mypriceprotect.html">�鿴����</a></p>
			          <div class="layout_popup" style="display:none">
			            <div class="layout_inner">
			            <dl>
			            	<dt>�۸񱣻�</dt>
			            	<dd>�û��µ���24Сʱ�ڣ�����Ʒ�ļ۸�����������ǰ�۸�����û�ʵ�ʹ���۸�ģ�ͬʱ���㽵�۷��ȴ���5%�����Է��ϼ۸񱣻���������Ʒ���û��������Ѹ�Զ������Ĳ�ۡ� </dd>
			            </dl>
			            </div>
			            <div class="layout_arrow_top"> <span class="">��</span><i>��</i> </div>
			          </div>
			        </div>';
			}
			$param['price_protect_pid_block'] = $price_protect_pid_block;

			array_push($linkIds, $item['product_id']);
			$TPL->set_var($param);
			$TPL->parse('t_item_list', 'item_list', true);
			$TPL->unset_var($param);
//			$weight_total += $param['weight_total'];
		}

	}
	else
	{
		$TPL->set_var('t_item_list', '');
	}

	//��Ҫ��������Ҫ����
	_getBtn($detail, $TPL, $uid, join(',' , array_reverse($linkIds )));

//	��Ʒ����
//	$TPL->set_var('weight_total', sprintf("%.3f", $weight_total / 1000));

	// �Ƿ���ʾ��ȥ֧������ť
	if (empty($detail['need_pay'])) {
		$TPL->set_var('t_pay_btn_block', '');
	}

	//���ڸ���
	$TPL->set_var("installment_str", isset($detail['installment']) && $detail['installment'] == '1' ? '<li><span class="l">���ڸ��������ѣ�</span><span class="r">&yen;' . (sprintf("%.2f", ( $detail['cash_per_month'] * $detail['installment_num'] - $detail['order_cost'] ) / 100 )) . '</span></li>' : '');
	$TPL->parse('t_pay_btn_block', 'pay_btn_block', true);

	$TPL->parse('content', 'contentHandler');
	$TPL->out();

}

function _convertPromotionOrCoupon(&$detail) {
	if (isset($detail['promotion_cut'])) {
		$cut_type = '�����Ż�';
		$cut = empty($detail['promotion_cut']) ? '0.00' : sprintf("%.2f", $detail['promotion_cut'] / 100);
	}
	else {
		$cut_type = '�Ż�ȯ';
		$cut = empty($detail['coupon_amt']) ? '0.00' : sprintf("%.2f", $detail['coupon_amt'] / 100);
	}

	return "<span class='l'>{$cut_type}��</span><span class='r'><span class='yen'>&yen;</span>{$cut}</span>";
}

function _getBtn($detail, $TPL, $uid, $linkIds) {
	$order_id = $detail['order_char_id'];
	$status_str = '';
	$status_main = '';
	$status_secondary = '';

	$payInfoBtn = '';
	$order_delay_desc = '';

	if ($detail['pay_type'] == 3 || $detail['pay_type'] == 4) {// ���е��or�ʾֻ��
		$payInfoBtn = '<span class="wrap_paydetail">
	<a href="javascript:void(0);" class="btn_normal110 js_wrap_paydetail" order_id="' . $order_id . '">�鿴������Ϣ</a>
	<div style="" class="layout_popup">
		<div class="layout_inner"> </div>
		<div class="layout_arrow_top">
			<span class="">��</span><i>��</i>
		</div>
	</div>
</span>';
	}

	global $_OrderState, $_PAY_MODE;
	switch($detail['status']) {
		//�����
		case $_OrderState['Origin']['value']:
		case $_OrderState['WaitingManagerAudit']['value']:
			$status_str = $_OrderState['Origin']['siteName'];
			if ($_PAY_MODE[$detail['hw_id']][$detail['pay_type']]['IsNet'] == 1 && $detail['isPayed'] == 1) { //����֧�� && �Ѹ�����
				$status_str = '��֧����������';
			}
			$status_main = '';
			if (! empty($detail['need_pay'])) {
				$hide = (isset($detail['pOrderId']) && $detail['pOrderId'] != $detail['order_char_id']);
				if (! $hide) {
					$status_main = '<a href="http://pay.51buy.com/redirect_' . $order_id . '" class="btn_strong70">ȥ����</a>';
					$withpoint = (empty($detail['point_pay']) ? 0 : ($detail['point_pay']/10));
					$status_secondary = empty($detail['can_cancel']) ? '' : '<a withpoint="' . $withpoint . '" withcoupon="' . (!empty($detail['coupon_amt']) ? sprintf("%.2f",$detail['coupon_amt']/100) : 0) . '" class="btn_common70 second cancelBtn" href="#" onclick="G.app.mycenter.order.cancel(this, \''.$order_id.'\');return false;">ȡ������</a>';
				}
			}
			$status_main .= $payInfoBtn;

			//���ҽ�������Ϊ��ֵ˰��Ʊʱ�������޸���Ʊ����
			/*if ( !empty($detail['invoices']) && count($detail['invoices']) > 0 && $detail['invoices'][0]['type_id'] == INVOICE_TYPE_VAT) {
				$status_secondary .= ' <a class="second" target="_blank" href="http://base.51buy.com/modifyinvoice-' . $order_id . '.html">�޸���Ʊ����</a>';
			}*/

			break;

		//Ա������
		case $_OrderState['EmployeeCancel']['value']:
		case $_OrderState['ManagerCancel']['value']:
			if ($detail['status'] == $_OrderState['EmployeeCancel']['value'])
			{
				$status_str = $_OrderState['EmployeeCancel']['siteName'];
			}
			else
			{
				$status_str = $_OrderState['ManagerCancel']['siteName'];
			}

			if ( ($detail['flag'] & ORDER_CP) == ORDER_CP )
			{
				// ����Ƕ��ƻ��������޸ļ��빺���urlΪ���ƻ���������
				if ( count($detail['items']) > 1)
				{
					foreach($detail['items'] as $it)
					{
						// ����������Ʒ���ҵ����ƻ�
						if ( ICustomPhone::isCustomPhoneProduct($it) )
						{
							$status_secondary = '<a class="btn_normal70 second" href="http://buy.51buy.com/cart.html?pid='.$it['product_id'].'">���¹���</a>';
							break;
						}
					}
				}
				else {
					$status_secondary = '<a class="btn_normal70 second" href="http://buy.51buy.com/stepone.html">���¹���</a>';
				}
			}
			else
			{
				$status_secondary = '<a class="btn_normal70 second" href="http://buy.51buy.com/cart.html?ids='. $linkIds .'">���¹���</a>';
			}
			break;

		// ��֧��
		case $_OrderState['WaitingPay']['value']:
			$status_str = $_OrderState['WaitingPay']['siteName'];
			if ($_PAY_MODE[$detail['hw_id']][$detail['pay_type']]['IsNet'] == 1 && $detail['isPayed'] == 1) { //����֧�� && �Ѹ�����
				$status_str = '��֧����������';
			}

			$status_main = '';
			if (! empty($detail['need_pay'])) {
				$hide = (isset($detail['pOrderId']) && $detail['pOrderId'] != $detail['order_char_id']);
				if (! $hide) {
					$status_main = '<a href="http://pay.51buy.com/redirect_' . $order_id . '" class="btn_strong70">ȥ����</a>';
					$withpoint = (empty($detail['point_pay']) ? 0 : ($detail['point_pay']/10));
					$status_secondary = empty($detail['can_cancel']) ? '' : '<a withpoint="' . $withpoint . '" withcoupon="' . (!empty($detail['coupon_amt']) ? sprintf("%.2f",$detail['coupon_amt']/100) : 0) . '" class="btn_common70 second cancelBtn" href="#" onclick="G.app.mycenter.order.cancel(this, \''.$order_id.'\');return false;">ȡ������</a>';
				}
			}
			$status_main .= $payInfoBtn;

			break;

		// ������
		case $_OrderState['WaitingOutStock']['value']:
			$status_str = $_OrderState['WaitingOutStock']['siteName'];

			$process_ids = array();
			$order_process_flows = IOrderProcessFlowTTC::get($detail['order_id'], array(), array('process_id'));//��ȡ������������
			if (count($order_process_flows) > 0 && is_array($order_process_flows)) {
				foreach($order_process_flows as $process) {
					$process_ids[] = $process['process_id'];
				}
			}

			$orderdelay_check = IOrder::orderDelayCheck($detail['order_date'], $detail['stockNo'], $detail['status'], $process_ids);
			if ($orderdelay_check === true) {
				$is_delay = IOrder::orderDelay($order_id, $detail['shipping_type']);
				if (isset($is_delay['data']) && $is_delay['data']['order_delay_status'] == 1) {
					$delay_data = $is_delay['data'];
					$minDate = ($delay_data['order_delay_mintime'] /24);
					$maxDate = ($delay_data['order_delay_maxtime'] /24);
					$order_delay_desc = ($detail['shipping_type'] != ICSON_DELIVERY) ? '<span class="hot">���ӻ���</span>' : '<span class="hot">���ӻ���Ԥ���ӻ�'.$minDate.'-'.$maxDate.'�죩</span>';
				}
			}
			break;

		// �ѳ���
		case $_OrderState['OutStock']['value']:
			$status_str = $_OrderState['OutStock']['siteName'];

			$process_ids = array();
			$order_process_flows = IOrderProcessFlowTTC::get($detail['order_id'], array(), array('process_id'));//��ȡ������������
			if (count($order_process_flows) > 0 && is_array($order_process_flows)) {
				foreach($order_process_flows as $process) {
					$process_ids[] = $process['process_id'];
				}
			}
			$orderdelay_check = IOrder::orderDelayCheck($detail['order_date'], $detail['stockNo'], $detail['status'], $process_ids);
			if ($orderdelay_check === true) {
				$is_delay = IOrder::orderDelay($order_id, $detail['shipping_type']);
				if (isset($is_delay['data']) && $is_delay['data']['order_delay_status'] == 1) {
					$delay_data = $is_delay['data'];
					$minDate = ($delay_data['order_delay_mintime'] /24);
					$maxDate = ($delay_data['order_delay_maxtime'] /24);
					$order_delay_desc = ($detail['shipping_type'] != ICSON_DELIVERY) ? '<span class="hot">���ӻ���</span>' : '<span class="hot">���ӻ���Ԥ���ӻ�'.$minDate.'-'.$maxDate.'�죩</span>';
				}
			}

			$can_evaluate = false;//�����Ƿ�������
			if (isset($detail['items']) && count($detail['items']) > 0) {
				foreach ($detail['items'] as $k => &$it) {
					$can_evaluate = $it['can_evaluate'];
					if ($can_evaluate === true) break;
				}
			}

			if ($can_evaluate === true) { //���������������
				if (isset($detail['items']) && count($detail['items']) == 1) {
					foreach($detail['items'] as $k => &$it) {
						if ($it['is_evaluated'] === false) {//�����Ʒû������
							$status_secondary .= '<a class="btn_normal110 second" href="http://item.51buy.com/review-toaddexperience-'.$it['product_id'].'.html" target="_blank">ȥ����</a>';
						}
						break;
					}
				}
				else {
					$status_secondary .= '<a class="btn_normal110 second" href="#review">ȥ����</a>';
				}
			}

			$status_secondary .= '<a class="todo_link" href="http://base.51buy.com/myrepair_report.html?orderid='.$order_id.'">����/�˻���</a>';

			if (EA_GuiJiuPei::validateGJPOrder($uid, $detail)) { //�����
				$status_secondary .= '<span class="wrap_guijiupei">
	<a class="btn_normal110" href="http://base.51buy.com/payforexpensiveness_report_'. $detail['order_char_id'] .'.html" target="_blank"><i class="clock"></i>��������</a>'.'
	<div class="layout_popup id_guijiupei_btn" style="display:block">
		<div id="time_countdown" class="layout_inner wrap_clock" timestamp="' . $detail['out_time'] . '">
			ʣ������ʱ��:
			<span class="strong hours_dash"><em class="digit">0</em><em class="digit">0</em></span>ʱ
			<span class="strong minutes_dash"><em class="digit">0</em><em class="digit">0</em></span>��
			<span class="strong seconds_dash"><em class="digit">0</em><em class="digit">0</em></span>��
		</div>
		<div class="layout_arrow_left">
			<span class="">��</span><i>��</i>
		</div>
	</div>
</span>';
			}

			break;

		// �ͻ�����
		case $_OrderState['CustomerCancel']['value']:
			$status_str = $_OrderState['CustomerCancel']['siteName'];
			if ( ($detail['flag'] & ORDER_CP) == ORDER_CP )
			{
				// ����Ƕ��ƻ��������޸ļ��빺���urlΪ���ƻ���������
				if ( count($detail['items']) > 1)
				{
					foreach($detail['items'] as $it)
					{
						// ����������Ʒ���ҵ����ƻ�
						if ( ICustomPhone::isCustomPhoneProduct($it) )
						{
							$status_secondary = '<a class="btn_normal70 second" href="http://buy.51buy.com/cart.html?pid='.$it['product_id'].'">���¹���</a>';
							break;
						}
					}
				}
				else {
					$status_secondary = '<a class="btn_normal70 second" href="http://buy.51buy.com/stepone.html">���¹���</a>';
				}
			}
			else
			{
				$status_secondary = '<a class="btn_normal70 second" href="http://buy.51buy.com/cart.html?ids='. $linkIds .'">���¹���</a>';
			}

			break;

		// �����˻�
		case $_OrderState['PartlyReturn']['value']:
			$status_str = $_OrderState['PartlyReturn']['siteName'];

			if (EA_GuiJiuPei::validateGJPOrder($uid, $detail)) { //�����
				$status_secondary = '<span class="wrap_guijiupei">
	<a class="btn_normal110" href="http://base.51buy.com/payforexpensiveness_report_' . $detail['order_char_id'] .'.html" target="_blank"><i class="clock"></i>��������</a>
	<div class="layout_popup id_guijiupei_btn" style="display:block">
		<div id="time_countdown" class="layout_inner wrap_clock" timestamp="' . $detail['out_time'] . '">
			ʣ������ʱ��:
			<span class="strong hours_dash"><em class="digit">0</em><em class="digit">0</em></span>ʱ
			<span class="strong minutes_dash"><em class="digit">0</em><em class="digit">0</em></span>��
			<span class="strong seconds_dash"><em class="digit">0</em><em class="digit">0</em></span>��
		</div>
		<div class="layout_arrow_left">
			<span class="">��</span><i>��</i>
		</div>
	</div>
</span>';
			}

			break;

		//ȫ���˻�
		case $_OrderState['Return']['value']:
			$status_str = $_OrderState['Return']['siteName'];

			break;

		default:
			Logger::err('order status is exception - ' . $detail['status']);
	}

	$TPL->set_var('orderdetail_order_status', $status_str);
	$TPL->set_var('status_main', $status_main);
	$TPL->set_var('status_secondary', $status_secondary);
	$TPL->set_var('order_delay_desc', $order_delay_desc);
}

/**
 * ȡ������
 */
function orderdetail_cancel() {
	$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
	if ($order_id <= 0) {
		return array("errno" => -1 );
	}
	$uid = IUser::getLoginUid();
	if ($uid <= 0) {
		return array("errno" => -1 );
	}


	$subOrderIds = $_GET['sub_order_ids'];

	if (is_array($subOrderIds) && count($subOrderIds) > 0) { //�ϲ�ȡ��
		$res = EA_OrderCancel::setPOrderCanceled($uid, array('p_order_id' => $order_id, 's_order_id' => $subOrderIds,));
		if (false == $res) {
			Logger::err('EA_OrderCancel::setPOrderCanceled failed-' . EA_OrderCancel::$errCode . '-' . EA_OrderCancel::$errMsg);
			return array("errno" => 1);
		}
	}
	else {
		$res = IOrder::setOrderCanceled($uid, $order_id);
		if (false === $res) {
			Logger::err('IOrder::setOrderCanceled failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);
			return array("errno" => 1);
		}
	}

    /***************�Ҷ�ͳһ����***************/
    //ͳһ�����Ҷ�
    $_UIN_ORDER_WHITE_LIST = array(
        'flag' => true, //�Ƿ�Ҷ�     true:�Ҷ� false:���Ҷ�
        'type' => 1, //�Ҷȷ�ʽ     1:������ 2:ȡģ 3: ȫ��
        'mod' => 10, //ȡģ��      type=2ʱ��Ч uid%mod
        'list' => array(//�ҶȰ�����   type=1ʱ��Ч��uid������

        ),
    );
    $_pay_enable = false;
    if ($_UIN_ORDER_WHITE_LIST['flag']) {
        //�Ҷ�
        if ($_UIN_ORDER_WHITE_LIST['type'] == 1) {
            //�������Ҷ�
            if (in_array($uid, $_UIN_ORDER_WHITE_LIST['list'])) {
                $_pay_enable = true;
            }
        }
        else if ($_UIN_ORDER_WHITE_LIST['type'] == 2) {
            //uidȡģ�Ҷ�
            $mod = $_UIN_ORDER_WHITE_LIST['mod'];
            if ($uid % $mod == 0) {
                //дͳһ����
                $_pay_enable = true;
            }
        }
        else if ($_UIN_ORDER_WHITE_LIST['type'] == 3) {
            //ȫ��
            $_pay_enable = true;
        }
    }
    if ($_pay_enable) {
        $orderDetails = IOrder::getSomeOrders($uid, array($order_id));
        if(!empty($orderDetails[$order_id])){
            if($orderDetails[$order_id]["subOrderNum"] > 0){//�кϵ��ĸ�����
                $parentOrderId = $order_id;
            }
            else{//�кϵ����ӵ� �� �Ǻϵ�
                if($order_id != $orderDetails[$order_id]["pOrderId"]){//�кϵ����ӵ�
                    $parentOrderId = $orderDetails[$order_id]["pOrderId"];
                    $subOrderIds = $order_id;
                }  
                else{//�Ǻϵ�
                    $parentOrderId = $order_id;
                }
            }
            if(strlen($parentOrderId) == 10){
                $parentOrderId = (int)substr($parentOrderId, 1);
            }
            if(isset($subOrderIds) && !is_array($subOrderIds)){//ȡ�������ӵ����кϵ���
                if(strlen($subOrderIds) == 10){
                    $subOrderId = (int)substr($subOrderIds, 1);
                }
                \ECC\Order\IcsonOrder::cancel($uid, $parentOrderId, $subOrderId);
            }
            else{//ȡ���������кϵ�/�޺ϵ���
                \ECC\Order\IcsonOrder::cancel($uid, $parentOrderId);
            }
            //var_dump($parentOrderId);
        }
    }
	return array("errno" => 0);
}

function orderdetail_cancelcp() {
	$order_id = $_GET['order_id'] + 0;
	$uid = IUser::getLoginUid();
	if (!empty($uid) && !empty($order_id)) {
		$res = ICustomPhone::setOrderCanceled($uid, $order_id);

		if ( false === $res ) {
			Logger::err('ICustomPhone::setOrderCanceled failed-' . ICustomPhone::$errCode . '-' . ICustomPhone::$errMsg);
			return array("errno" => 1);
		}

		return array("errno" => 0 );
	}
	else {
		return array("errno" => -1 );
	}
}

function orderdetail_bankOrPostofficePayInfo() {
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}
	if (!isset($_GET['order_id'])) {
		return array(
			"errno" => 1,
			"data" => "��������"
		);
	}

	$order_id = intval( $_GET['order_id'] );
	$order = IOrder::getOneOrder($uid, $order_id);
	if (false === $order) {
		Logger::err('IOrder::getOneOrder failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);

		return array(
			"errno" => 3,
			"data" => "��ѯʧ�ܣ� ���Ժ����ԣ�"
		);
	}

	global $_StockToStation;
	$stock_hw_id = SITE_SH;
	if ( isset($_StocktoStation[$order['stockNo']]) ) {
		$stock_hw_id = $_StockToStation[$order['stockNo']];
	}

	$message = '';
	if ($order['pay_type'] == 3) { // ���е��
		$message = '<a href="javascript:void(0);" class="close">�ر�</a>
<p>���е�㵽��ʱ��ԼΪ2��4��</p>
<table class="table_paydetail">
	<tr><td>��	  �� </td><td>�Ϻ���Ѹ��������չ���޹�˾</td></tr>
	<tr><td>��������</td><td>�й����������Ϻ�������֧��</td></tr>
	<tr><td>�ʺ�</td><td>31001528700050010815</td></tr>
	<tr><td colspan="2"><strong>ע�����ڵ�㵥�����;����ע�����Ķ�����</strong>' . $order['order_char_id'] . '</td></tr>
</table>
<a href="http://st.51buy.com/help/2-5-banktransfer.htm" target="_blank">�鿴���ึ����Ϣ</a>';
	}
	else if ($order['pay_type'] == 4) { // �ʾֻ��
		$message = '<a href="javascript:void(0);" class="close">�ر�</a>
<p>�ʾָ����ʱ��ԼΪ1��3��</p>
<table class="table_paydetail">
	<tr><td>�������</td><td>������</td></tr>
	<tr><td>�̻��ͻ���</td><td><strong>312220031</strong>&nbsp;�������׼ȷ��д��</td></tr>
	<tr><td>�տλ</td><td>�Ϻ���Ѹ��������չ���޹�˾</td></tr>
	<tr><td colspan="2"><strong>ע�����ڵ�㵥�����;����ע�����Ķ�����</strong>' . $order['order_char_id'] . '</td></tr>
</table>
<a href="http://st.51buy.com/help/2-4-postal_remittance.htm" target="_blank">�鿴���ึ����Ϣ</a>';
	}

	return array(
		"errno" => 0,
		"data" => $message
	);
}

function orderdetail_progressBar() {
	if (!isset($_GET['order_id'])) {
		return array(
			"errno" => 1,
			"data" => "��������"
		);
	}

	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	$order_id = intval( $_GET['order_id'] );
	$detail = IOrder::getOneOrder($uid, $order_id);
	if (false === $detail) {
		Logger::err('IOrder::getOneOrder failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);

		return array(
			"errno" => 3,
			"data" => "��ѯʧ�ܣ� ���Ժ����ԣ�"
		);
	}

	$siteId = $detail['hw_id'];
	$payInfo = ToolUtil::getPayTypeInfo($detail['pay_type'], $siteId); //֧����ʽ

	//��Ҫ֧���ֶ�
	global $_OrderState, $_PAY_MODE;
	$status = $detail['status'];
	if ( ($status == $_OrderState['Origin']['value'] || ($status == $_OrderState['WaitingManagerAudit']['value']) ||
		($status == $_OrderState['WaitingPay']['value'])) && $_PAY_MODE[$detail['hw_id']][$detail['pay_type']]['IsNet'] == 1 &&
		$detail['isPayed'] == 0) {
		$detail['need_pay'] = 1;
	}
	else {
		$detail['need_pay'] = 0;
	}

	//����������
	$orderProgressBarClassName =  _getOrderProgressBarClassName($detail, $uid) ; //������������ʽ
	$progressBarContent = '';
	if ($orderProgressBarClassName == 'c_load_false') { // �ݴ�����
		$progressBarContent = '<div class="c_load c_load_false"><p>��ȡ��Ϣʧ�ܣ����Ժ�����</p></div>';
	}
	else {
		$progressBarContent = '<ul class="' . $orderProgressBarClassName . '">';
		$onlinePay = false; //����֧��
		$cashOnDelivery = false; //��������
		if ($payInfo['SysNo'] === 1) {
			$cashOnDelivery = true;
		}
		if ($payInfo['IsNet'] == true || $payInfo['SysNo'] === 3 || $payInfo['SysNo'] === 4) {
			$onlinePay = true;
		}
		$orderFlowTime = _getOrderFlowTime($detail, $uid);
		if (!empty($orderFlowTime['submit'])) {
			$orderflow_submit = explode(" ", $orderFlowTime['submit']);
			$orderflow_submit_date = $orderflow_submit[0];
			$orderflow_submit_time = $orderflow_submit[1];
		}
		if (!empty($orderFlowTime['pay'])) {
			$orderflow_pay = explode(" ", $orderFlowTime['pay']);
			$orderflow_pay_date = $orderflow_pay[0];
			$orderflow_pay_time = $orderflow_pay[1];
		}
		if (!empty($orderFlowTime['signfo'])) {
			$orderflow_signfo = explode(" ", $orderFlowTime['signfo']);
			$orderflow_signfo_date = $orderflow_signfo[0];
			$orderflow_signfo_time = $orderflow_signfo[1];
		}
		if (!empty($orderFlowTime['distri'])) {
			$orderflow_distri = explode(" ", $orderFlowTime['distri']);
			$orderflow_distri_date = $orderflow_distri[0];
			$orderflow_distri_time = $orderflow_distri[1];
		}
		if (!empty($orderFlowTime['waiting_out'])) {
			$orderflow_waiting_out = explode(" ", $orderFlowTime['waiting_out']);
			$orderflow_waiting_out_date = $orderflow_waiting_out[0];
		}
		if (!empty($orderFlowTime['invalid'])) {
			$orderflow_invalid = explode(" ", $orderFlowTime['invalid']);
			$orderflow_invalid_date = $orderflow_invalid[0];
			$orderflow_invalid_time = $orderflow_invalid[1];
		}

		if ($onlinePay || $cashOnDelivery) { // ����֧��or��������
			$progressBarContent .= generateProgressBarHtml('o_submit', '�ύ����', (empty($orderFlowTime['submit']) ? '' : $orderflow_submit_date), (empty($orderFlowTime['submit']) ? '' : $orderflow_submit_time));
			$status = $detail['status'];
			if ($status === $_OrderState['EmployeeCancel']['value'] || $status === $_OrderState['CustomerCancel']['value'] || $status === $_OrderState['ManagerCancel']['value']) { // ��������
				$progressBarContent .= generateProgressBarHtml('o_invalid', '������', (empty($orderFlowTime['invalid']) ? '' : $orderflow_invalid_date), (empty($orderFlowTime['invalid']) ? '' : $orderflow_invalid_time));
			}
			else {
				if ($status === $_OrderState['Origin']['value'] || $status === $_OrderState['WaitingManagerAudit']['value'] || $status === $_OrderState['WaitingPay']['value']) { // ����״̬=�����/��֧��
					$progressBarContent .= generateProgressBarHtml('o_pay', '������', '', (empty($orderFlowTime['waiting_pay']) ? '' : $orderFlowTime['waiting_pay']));
				}
				else if ($onlinePay) {
					$progressBarContent .= generateProgressBarHtml('o_pay', '�Ѹ���', (empty($orderFlowTime['pay']) ? '' : $orderflow_pay_date), (empty($orderFlowTime['pay']) ? '' : $orderflow_pay_time));
				}

				if ($orderProgressBarClassName === 'online3') {
					$progressBarContent .= generateProgressBarHtml('o_out', '������', '', (empty($orderFlowTime['waiting_out']) ? '' : $orderFlowTime['waiting_out']));
				}
				else {
					$progressBarContent .= generateProgressBarHtml('o_out', '��Ʒ����', (empty($orderFlowTime['distri']) ? '' : $orderflow_distri_date), (empty($orderFlowTime['distri']) ? '' : $orderflow_distri_time));
				}
				if ($orderProgressBarClassName === 'online4') {
					$progressBarContent .= generateProgressBarHtml('o_distri', '������', (empty($orderFlowTime['waiting_out']) ? '' : $orderFlowTime['waiting_out']), '', $detail);
				}
				else if ($orderProgressBarClassName === 'online5') {
					$progressBarContent .= generateProgressBarHtml('o_distri', '����', (empty($orderFlowTime['waiting_out']) ? '' : $orderFlowTime['waiting_out']), '', $detail);
				}
				else {
					$progressBarContent .= generateProgressBarHtml('o_distri', '����', '', '', $detail);
				}

				if ($orderProgressBarClassName === 'online5') { // �ѳ���and���1��������ˮ=�������|ǩ��ɨ��
					$progressBarContent .= generateProgressBarHtml('o_signfo', '��ǩ��', (empty($orderFlowTime['signfo']) ? '' : $orderflow_signfo_date), (empty($orderFlowTime['signfo']) ? '' : $orderflow_signfo_time));
				}
				else {
					$progressBarContent .= generateProgressBarHtml('o_signfo', 'ǩ��', '', '');
				}
			}
		}
		else {
			Logger::err("page_orderdetail_page : paytype is not right ");
		}

		$progressBarContent .= '</ul>';
	}
	return array(
		"errno" => 0,
		"data" => $progressBarContent
	);
}

function _orderdetail_orderflow( $siteId, $order_id, $order_date ) {
	global $_IP_CFG;

	$url = $_IP_CFG['ORDERFLOW'][$siteId] . "/InternalService/AjaxGetOrderInfo.aspx?sysno=" . $order_id . "&siteid=" . $siteId . "&type=json";
	$res = NetUtil::cURLHTTPGet($url, 10);
	if ( false === $res ) {
		Logger::err("_orderdetail_orderflow: �������-" . $url);
		return false;
	}
	$res = ToolUtil::gbJsonDecode($res);
	if ( empty($res) || !isset($res['Steps']) || !isset( $res['Steps']['Step'] )) {
		Logger::err("ToolUtil::gbJsonDecode error: " . $res);
		return false;
	}

	if (isset($res['Steps']['Step']['Item'])) {
		$data = $res['Steps']['Step'];

		if ( $data["ItemContent"] == "Order is not exist" ) {
			//hack
			$res['Steps']['Step'] = array(
				array(
					"Item" => date("Y-m-d H:i:s", $order_date),
					"ItemContent" => "���ύ�˶������ȴ��ͷ���ˡ�"
				)
			);
//			Logger::err("_orderdetail_orderflow: Order is not exist-" . $url);
//			return false;
		}
		else {
			$res['Steps']['Step'] = array(
				array(
					"Item" => $data["Item"],
					"ItemContent" => $data['ItemContent']
				)
			);
		}
	}

	$items = array();
	$total = '';

	foreach( $res['Steps']['Step']  as $index => $item) {
		if ( empty( $item['Item'] ) ) {
			$total = $item['ItemContent'];
		}
		else {
			$time =  $item['Item'];

			if ($time === '��' && $index > 0) {
				$time = $res['Steps']['Step'][$index - 1]['Item'];
			}
			$items[] = array(
				"ptime" => $time,
				"content" => $item['ItemContent']
			);
		}
	}

	return $items;
}

/*
 *  ��ȡʣ�ึ��ʱ��
 */
function _getRemainPaymentTimeStr($payInfo, $order_date, $flag) {
	$left = 0;
	if ( ($flag & ORDER_RUSHING_BUY_ONLINE_PAY) == ORDER_RUSHING_BUY_ONLINE_PAY ) { //��ʱ����֧������
		$left = floor(($order_date + 3600 - $_SERVER['REQUEST_TIME']) / 60);
	}
	else if ($payInfo['IsNet'] === 1) { //��ͨ����֧������
		$left = floor(($order_date + 172800 - $_SERVER['REQUEST_TIME']) / 60); //48 * 3600
	}
	else if ($payInfo['SysNo'] == 3) { //���е��
		$left = floor(($order_date + 345600 - $_SERVER['REQUEST_TIME']) / 60); //24 * 4 * 3600
	}
	else if ($payInfo['SysNo'] == 4) { //�������
		$left = floor(($order_date + 604800 - $_SERVER['REQUEST_TIME']) / 60); //24 * 7 * 3600
	}

	$str = '';
	if ($left <= 0) {
		return $str;
	}
	$day = floor($left / 1440);
	if ($day > 0) {
		$str .= $day . '��';
	}
	$hour = floor(($left - $day * 1440) / 60);
	if ($hour > 0) {
		$str .= $hour . 'Сʱ';
	}
	$minute = ($left - $day * 1400 - $hour * 60);
	if ($day==0 && $minute > 0 && $minute < 60) {
		$str .= $minute . '��';
	}

	return $str;
}

/*
 * ��ȡ������������ǩ��class����ֵ
 * return : String
 */
function _getOrderProgressBarClassName($detail, $uid) {

	global $_OrderState, $_PAY_MODE;
	$status = $detail['status'];
		//�����
		if ( $status == $_OrderState['Origin']['value'] || ($status == $_OrderState['WaitingManagerAudit']['value']) ||
			($status == $_OrderState['WaitingPay']['value']) ) {
			if ( ($_PAY_MODE[$detail['hw_id' ]][$detail[ 'pay_type']][ 'IsNet' ] == 1 && $detail['isPayed' ] == 0) || $detail['pay_type' ] == 3 || $detail['pay_type' ] == 4) { //����֧����Ҫ���� or ���е�� or �ʾֻ��
				return 'online2';
			}
			else { // ����������ʾ������״̬
				return 'online3';
			}
		}
		else if ( $status == $_OrderState['WaitingOutStock']['value']) {// ������
			return 'online3';
		}
		else if ($status == $_OrderState['OutStock']['value']) {// �ѳ���
			$order_id = $detail['order_char_id'];

			$order_flow = IOrder::geOrderFlow($uid, $order_id);
			if ($order_flow === false) {
				Logger::err("IOrder::geOrderFlow failed, code: " . IOrder::$errCode . '; msg: ' . IOrder::$errMsg);
				return "c_load_false";
			}
			$third_order_flow_item = array();
			$item = $order_flow['items'];
			if (!empty($order_flow['third_type']) && !empty($order_flow['third_sysno'])) {
				$third_order_flow = IOrder::getThirdOrderFlow($order_flow['third_type'], $order_flow['third_sysno']);
				if (false === $third_order_flow) {
					Logger::err("IOrder::getThirdOrderFlow failed, code: " . IOrder::$errCode . '; msg: ' . IOrder::$errMsg);
					return "c_load_false";
				}

				if (isset($third_order_flow['items'])) {
					$third_order_flow_item = $third_order_flow['items'];
				}
				else {
					$third_order_flow_item = $third_order_flow;
				}

				$item = array_merge($item, $third_order_flow_item);
			}

//��������
//$item = array(
//	array(
//		'time' => '2012-07-01 10:10:10',
//		'content' => ' ���ύ�˶������ȴ��ͷ���ˡ�'
//	),
//	array(
//		'time' => '2012-08-01 11:11:11',
//		'content' => '���Ķ�������ɹ�'
//	),
//	array(
//		'time' => '2012-08-01 23:23:23',
//		'content' => '���Ķ����ѿ�ʼ���'
//	),
//	array(
//		'time' => '2012-08-02 22:22:22',
//		'content' => '������'
//	),
//	array(
//		'time' => '2012-08-01 99��99��99',
//		'content' => 'ǩ��ɨ��'
//	)
//);

			$count = count($item);

			if ($count == 0) { // ��ȡ������ˮ����ʾ�ݴ�����
				return 'c_load_false';
			}

			$content = $item[$count-1]['content'];// ���һ��������ˮ
			if (preg_match("/�ѿ�ʼ���/", $content)) {//����1����ˮ�������ѿ�ʼ�����
				return 'online3';
			}
			if (preg_match("/�������|ǩ��ɨ��/", $content)) {//����1��������ˮ�������������/ǩ��ɨ�衱
				return 'online5';
			}
			return 'online4';
		}
		// Ա������  �ͻ�����  ϵͳ����
		else if ($status == $_OrderState['EmployeeCancel']['value'] || ($status == $_OrderState['CustomerCancel']['value']) || ($status == $_OrderState['ManagerCancel']['value']) ) {
			return 'online2';
		}
}

/*
 * ��ȡ����״̬��Ӧ��ʱ��ڵ�
 */
function _getOrderFlowTime($detail, $uid) {
	$order_id = $detail['order_char_id'];
	$order_flow = IOrder::geOrderFlow($uid, $order_id);
	if ($order_flow === false) {
		Logger::err("IOrder::geOrderFlow failed, code: " . IOrder::$errCode . '; msg: ' . IOrder::$errMsg);
		return '';
	}
	$third_order_flow_item = array();
	$item = $order_flow['items'];

	if (!empty($order_flow['third_type']) && !empty($order_flow['third_sysno'])) {
		$third_order_flow = IOrder::getThirdOrderFlow($order_flow['third_type'], $order_flow['third_sysno']);
		if ($third_order_flow === false) {
			Logger::err("IOrder::geOrderFlow failed, code: " . IOrder::$errCode . '; msg: ' . IOrder::$errMsg);
			return '';
		}
		if (isset($third_order_flow['items'])) {
			$third_order_flow_item = $third_order_flow['items'];
		}
		else {
			$third_order_flow_item = $third_order_flow;
		}
		$item = array_merge($item, $third_order_flow_item);
	}
	$ret = array();

	$count = count($item);

	$submit_pattern = "/�ύ�˶���/";
	$pay_pattern = "/����ɹ�/";
	$invalid_pattern = "/����/";
	$distri_pattern = "/������/";
	$signfo_pattern = "/�������|ǩ��ɨ��/";

	$submit_flag = false;
	$pay_flag = false;
	$invalid_flag = false;
	$distri_flag = false;
	$signfo_flag = false;

	for($i=0; $i<$count; $i++) {
		$content = $item[$i]['content'];

		if (!$submit_flag) {
			if (preg_match($submit_pattern, $content)) {
				$ret['submit'] = $item[$i]['time'];
				$submit_flag = true;
				continue;
			}
		}
		if (!$pay_flag) {
			if (preg_match($pay_pattern, $content)) {
				$ret['pay'] = $item[$i]['time'];
				$pay_flag = true;
				continue;
			}
		}
		if (!$invalid_flag) {
			if (preg_match($invalid_pattern, $content)) {
				$ret['invalid'] = $item[$i]['time'];
				$invalid_flag = true;
				continue;
			}
		}
		if (!$distri_flag) {
			if (preg_match($distri_pattern, $content)) {
				$ret['distri'] = $item[$i]['time'];
				$distri_flag = true;
				continue;
			}
		}
		if (!$signfo_flag) {
			if (preg_match($signfo_pattern, $content)) {
				$ret['signfo'] = $item[$i]['time'];
				$signfo_flag = true;
				continue;
			}
		}

	}

	//��Ѹ����û�ѡ�����������ʱ��
	$siteId = $detail['hw_id'];
	$isIcsonDelivery =  $detail['shipping_type'] == 1 && $siteId == 1 ||  $detail['shipping_type'] == 22 && $siteId = 1001;
	$expect_dly_date = ( empty($detail['expect_dly_date']) || (0 == $detail['expect_dly_date']) ) ? '' : preg_replace('/(\d{4})��(\d{1,2})��(\d{1,2})��/', '$1-$2-$3', $detail['expect_dly_date']);
	$ret['waiting_out'] = $isIcsonDelivery ? '<span class="date">Ԥ���ʹ�ʱ��</span><span class="time txt_strong">' . $expect_dly_date . '</span>' : '';

	//ʣ�ึ��ʱ��
	global $_OrderState;
	$payInfo = ToolUtil::getPayTypeInfo($detail['pay_type'], $siteId); //֧����ʽ
	$ret['waiting_pay'] = ''; //ʣ�ึ���ʱ��
	if (!empty($detail['need_pay'])) { //�����������״̬ && ����֧�� && δ����
		$ret['waiting_pay'] = '<span class="date">ʣ�ึ��ʱ��</span><span class="time txt_strong">' . _getRemainPaymentTimeStr($payInfo, $detail['order_date'], $detail['flag']) . '</span>';
	}

	return $ret;
}


function getOrderProductIds($order_char_id) {
	$ids = array();

	$uid = IUser::getLoginUid();

	$order = IOrder::getOneOrderDetail($uid, $order_char_id);
	if ($order === false) {
		Logger::err('Iorder::getOneOrderDetail failed-' . Iorder::$errCode . '-' . Iorder::$errMsg);
		return '';
	}

	if ( isset($order['items'])  && count($order['items']) > 0 ) {
		foreach($order['items'] as $item ) {
			$ids[] =  $item['product_id'];
		}
	}

	$ids = array_reverse($ids);

	$ids = implode(",", $ids);

	return $ids;
}

/*
 * ���ɶ�����������html
 */
function generateProgressBarHtml($className, $title, $date, $time, &$detail = array()) {
	$ret = '';
	switch ($className) {
		case 'o_submit' :
		case 'o_out' :
			$ret = '<li class="' . $className . '"><p class="o_statu">' . $title . '</p><p class="o_img"><span class="wrap_img"><img src="http://st.icson.com/static_v1/img/mycenter/o_status_out.gif" class="img" alt="" /></span></p><p class="done"><span></span></p>';
			break;
		case 'o_pay' :
			$ret = '<li class="o_pay"><p class="o_statu">' . $title . '</p><p class="o_img"><span class="wrap_img"><img src="http://st.icson.com/static_v1/img/mycenter/o_status_pay.gif" class="img" alt="" /></span></p><p class="done"><span></span></p>';
			break;
		case 'o_distri' :
			$ret = '<li class="o_distri"><p class="o_statu">' . $title . '</p><p class="o_img"><span class="wrap_img"><img src="http://st.icson.com/static_v1/img/mycenter/o_status_distri.gif" class="img" alt="" /></span></p><p class="done"><span></span></p>';
			break;
		case 'o_invalid' :
			$ret = '<li class="o_invalid"><p class="o_statu">' . $title . '</p><p class="o_img"><span class="wrap_img"></span></p><p class="done"><span></span></p>';
			break;
		case 'o_signfo' :
			$ret = '<li class="o_signfo"><p class="o_statu">' . $title . '</p><p class="o_img"><span class="wrap_img"></span></p><p class="done"><span></span></p>';
			break;
//		default:
//			$ret = '<li class="o_distri"><p class="o_statu">' . $title . '</p><p class="o_img"><span class="wrap_img"><img src="http://st.icson.com/static_v1/img/mycenter/o_status_distri.gif" class="img" alt="" /></span></p><p class="done"><span></span></p>';
	}

	if ($className == 'o_distri' && (count($detail) > 0)) {
		$process_ids = array();
		$order_process_flows = IOrderProcessFlowTTC::get($detail['order_id'], array(), array('process_id'));//��ȡ������������
		if (count($order_process_flows) > 0 && is_array($order_process_flows)) {
			foreach($order_process_flows as $process) {
				$process_ids[] = $process['process_id'];
			}
		}

		$orderdelay_check = IOrder::orderDelayCheck($detail['order_date'], $detail['stockNo'], $detail['status'], $process_ids);
		if ($orderdelay_check === true) {
			$is_delay = IOrder::orderDelay($detail['order_char_id'], $detail['shipping_type']);
			if (isset($is_delay['data']) && $is_delay['data']['order_delay_status'] == 1) {
				$delay_data =  $is_delay['data'];
				$minDate = ($delay_data['order_delay_mintime'] /24);
				$maxDate = ($delay_data['order_delay_maxtime'] /24);
				$delay_desc = ($detail['shipping_type'] != ICSON_DELIVERY) ? '<span class="txt_strong">�ӻ� </span><br>��������ʱ�������֪ͨ' : '<span class="txt_strong">�ӻ� Ԥ���ӻ�'.$minDate.'-'.$maxDate.'��</span><br>��������ʱ�������֪ͨ';
				$ret .= '<p class="ext_txt">' . $delay_desc . '</p><b class="next_to"></b></li>';
			}
		}
	}

	if ($date == '' || $orderdelay_check) {
		$ret .= '<p class="ext_txt">' . $time . '</p><b class="next_to"></b></li>';
	}
	else {
		$ret .= '<p class="ext_txt"><span class="date">' . $date . ' </span><span class="time">' . $time . ' </span></p><b class="next_to"></b></li>';
	}

	return $ret;
}

