<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');
require_once(PHPLIB_ROOT . 'api/distribution/IBUser.php');
require_once(PHPLIB_ROOT . 'api/distribution/IBPreOrder.php');

define("ONEMONTHNOW",1);
define("ONEMONTHAGO",2);
Logger::init();

function page_bmanageorder_page()
{
	page_bmanageorder_search();
}


function page_bmanageorder_search()
{
	global $_OrderState;

	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, 'b_manage_order', array(
		'titleDesc' => '�����б�'
	));

	$TPL->set_file(array(
		'contentHandler' => 'b_manage_order.tpl'
	));
	$TPL->set_var('pageName','�����б�');
	
	$TPL->set_var('shop_info',ToolUtil::gbJsonEncode(getShop($uid)));
	
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
    $TPL->set_block("contentHandler", 'list', 't_list');
	$pageSize = 24;
	$input = array(
		'date' => empty($_GET['date']) ? 1 : intval($_GET['date']), //��1-���£�2-һ��֮ǰ
		'shopId' => empty($_GET['shopid']) ? '' : intval($_GET['shopid']),
		'accout' => empty($_GET['accout']) ? '' : iconv('utf-8','gb2312',urldecode($_GET['accout'])),
	    'name' => empty($_GET['name']) ? '' : iconv('utf-8','gb2312',urldecode($_GET['name'])),
	    'orderid' => $_GET['orderid'],
	);
	
	$retailer = IRetailer::getRetailers(array('uid'=>$uid));
    if (false === $retailer || 0 === count($retailer))
    {
         Logger::err(basename(__FILE__, '.php') . " |" . __LINE__  . IRetailer::$errMsg);
         return '';
    }
    $retailer = current($retailer);
    //�����ѯ����
	$dis_info = array();
	if ($input['shopId'] != '')
	{
		$dis_info['shopId'] = $input['shopId'];
	}
	$guidConditionAccout = '';
    if ($input['accout'] != '')
    {//�����ʺ�
    	if ($retailer['icsonid'] == $input['accout'])
    	{
    	     $guidConditionAccout = 0; //�����̺�̨�µ�
    	}
    	else
    	{
	        $shop_guide_id = getAccountInfo($uid,array('account'=>$input['accout']));
	        if (false != $shop_guide_id)
	        {
	            $guidConditionAccout = $shop_guide_id;
	        }
	    	else //�û������ʺŲ��Ƿ����̵��ʺţ�Ҳ���ǵ������ʺţ����������Ϊ��
	        {
	            recoverSearchItem($TPL,$input);
	            $TPL->set_var('t_list', '<tbody><tr class="no_order"><td colspan="7"><b class="icon icon_msg3 icon_msg3_warn"></b>û�з��������Ķ������볢����������������</td></tr></tbody>');
	            $TPL->set_var('page', '');
	            $TPL->parse('content', 'contentHandler');
	            $TPL->out();
	            
	            return;
	        }
    	}
    }
    $guidConditionName = '';
    if ($input['name'] != '')
    {//��������
        if ($retailer['name'] == $input['name'])
        {
            $guidConditionName = 0; //�����̺�̨�µ�
        }
        else 
        {
	        $shop_guide_id = getAccountInfo($uid,array('name'=>$input['name']));
	        if (false != $shop_guide_id)
	        {
	            $guidConditionName = $shop_guide_id;
	        }
	        else
	        {
	            recoverSearchItem($TPL,$input);
	            $TPL->set_var('t_list', '<tbody><tr class="no_order"><td colspan="7"><b class="icon icon_msg3 icon_msg3_warn"></b>û�з��������Ķ������볢����������������</td></tr></tbody>');
	            $TPL->set_var('page', '');
	            $TPL->parse('content', 'contentHandler');
	            $TPL->out();
	            
	            return;
	        }
        }
    }

    if($guidConditionName == $guidConditionAccout && '' != $guidConditionName)
    {
        $dis_info['shopGuideId'] = $guidConditionAccout;
    }
    else if ($guidConditionName != $guidConditionAccout && 0 != $guidConditionName && 0 != $guidConditionAccout)
    {
        recoverSearchItem($TPL,$input);
        $TPL->set_var('t_list', '<tbody><tr class="no_order"><td colspan="7"><b class="icon icon_msg3 icon_msg3_warn"></b>û�з��������Ķ������볢����������������</td></tr></tbody>');
        $TPL->set_var('page', '');
        $TPL->parse('content', 'contentHandler');
        $TPL->out();
                
        return;
    }
    else if($guidConditionName !== $guidConditionAccout)
    {
         $dis_info['shopGuideId'] = $guidConditionName + $guidConditionAccout;
    }
    
    //�������

    $orderList = array();
    if (!empty($_GET['orderid'])) //�����˶�����
    {
        $detail = IOrder::getOneOrderDetail($uid, $_GET['orderid']);
	    if($detail['subOrderNum'] > 0)
	    {
	        // �𵥶�������ʾ����ҳ����ת������ҳ�档
	        ToolUtil::redirect("http://base.51buy.com/bmanageorder.html");
	        exit();
	    }
	    if($detail === false){
	        Logger::err('IOrder::getOneOrderDetail failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);
	    }
	    else if (0 != count($detail))
	    {
	       $orderList = array('orders'=>array($detail));
	    }
    }
    else 
    {
		if (ONEMONTHNOW === $input['date'])
		{
			$orderList = IOrder::getUserOrdersInOneMonth($uid, $currentPage - 1, $pageSize,$dis_info);
		}
		else 
		{
			$orderList = IOrder::getUserOrdersOneMonthAgo($uid, $currentPage - 1, $pageSize,$dis_info);
		}
	
		if($orderList === false)
		{
			Logger::err('IOrder::getUserOrders failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);
			$TPL->set_var('t_list', '<tr><td colspan="7"><p class="kong">�����쳣</p></td></tr>');
			recoverSearchItem($TPL,$input);
			$TPL->parse('content', 'contentHandler');
			$TPL->out();
			
			return;
		}
    }
	if(!empty($orderList['orders']))
	{
		
		foreach( $orderList['orders'] as $item)
		{ 
			$btn_str = '';
			switch($item['status'])
			{
		        //�����
		        case $_OrderState['Origin']['value']:
		        case $_OrderState['WaitingManagerAudit']['value']:
		        	$btn_str .=  empty($item['can_cancel']) ? '':
			        	 ('<p><a withcoupon="' 
			        	 . '" href="#" class="todo_link" onclick="G.app.mycenter.order.cancel(this, \''
			        	 . $item['order_char_id'] .'\');return false;">ȡ������</a></p>');
		        	break;
			}
			$btn_str .= '<a target="_blank" href="http://base.51buy.com/orderdetail-'.$item['order_char_id'].'.html" class="todo_link">�鿴����</a>';
			//����״̬
			$_orderState = "";
			foreach($_OrderState as $key => $arr)
			{
				if($item['status'] == $arr['value'])
				{
					$_orderState = $arr['siteName'];
					break;
				}
			}
			//��Ʒ�б�
			$product_list_str = '';
			
			if(!empty($item['items']))
			{
				$index = 0;
				foreach ($item['items'] as $product)
				{
					if($index > 7)
					{
						break;
					}
					$product_title = strip_tags($product['name']);
					$product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);
					$product_list_str.= '<a target="_blank" href="http://item.51buy.com/productdetail-' . $product['product_id'] .'.html" class="img"><i></i><img src="' . IProduct::getPic($product['product_char_id'], 'small') . '" alt="'.$product_title.'" title="'.$product_title.'"></a>';
				    $index ++;
				}
			}
			$account_info = getAccountDetail($uid,$item['shop_guide_id']);
			if (false === $account_info)
			{
				Logger::err('IBUser::getSalesmanInfo failed');
			    $account_info = array('account' => '','name' => '');
			}

			$params = array(
			    'pre_order_char_id' => '--',
				'order_char_id' => $item['order_char_id'],  //�������
				'order_id' => $item['order_id'],
				'order_date' => date("Y-m-d", $item['order_date']), //�µ�ʱ��
				'order_cost' => sprintf("%.2f", $item['shop_guide_cost']/100), // �����ܼ�
				'order_cost_in' => sprintf("%.2f", $item['order_cost']/100), //�����ܼ�
				'status' => $_orderState,  //����״̬
				'product_list_str' => $product_list_str,
				'shop_name' => getShopName($uid,$item['shop_id']),
				'sub_accout' => $account_info['account'],
				'sub_accout_name' => $account_info['name'],
			    'btn_str' => $btn_str,
			);
		    $preOrder = IBOrdersTTC::get($uid,array('real_order_id'=>$item['order_char_id']));
            if (is_array($preOrder) && count($preOrder) > 0)
            {
            	$oid = $preOrder[0]['order_char_id'];
                $params['pre_order_char_id'] = '<a target="_blank" href="http://base.51buy.com/borderdetail-' . $oid . '.html" class="todo_link">' . $oid . '</a>';
            }
			$TPL->set_var($params);
			$TPL->parse('t_list', 'list', true);
			$TPL->unset_var($params);

			$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/'. $input['date'] .'-'. $input['shopId'] . '-{page}.html?q=' . $input['accout'] , $currentPage, ceil( $orderList['total'] / $pageSize ))  . '</div></div>');
		}
	}
	else
	{                    
		$TPL->set_var('t_list', '<tbody><tr class="no_order"><td colspan="7"><b class="icon icon_msg3 icon_msg3_warn"></b>û�з��������Ķ������볢����������������</td></tr></tbody>');
		$TPL->set_var('page', '');
	}
	recoverSearchItem($TPL,$input);
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}


function recoverSearchItem($TPL ,$input)
{
	$TPL->set_var('select_shop' , $input['shopId'] );
	$TPL->set_var('input_accout' , $input['accout']);
	$TPL->set_var('input_name' , $input['name']);
	$TPL->set_var('input_order_id' , $input['orderid']);
	if (ONEMONTHNOW === $input['date'])
	{
		$TPL->set_var('select_new','selected="selected"');
		$TPL->set_var('select_old','');
	}
	else if (ONEMONTHAGO === $input['date'])
	{
		$TPL->set_var('select_new','');
		$TPL->set_var('select_old','selected="selected"');
	}
}

/**
 * ��ȡ�ŵ���Ϣ 
 */
 function getShop($retailerId)
{
	if (!isset($retailerId))
	{
		self::logger(basename ( __FILE__, '.php' ) . " |" . __LINE__ . "retailer ID null" );
		
		return false;
	}
	$res = IBUser::getAllShop($retailerId);
	if (false === $res)
	{	
		return false;
	}
	$ret = array();
	$index = 0;
	foreach ($res AS $shop)
	{
		$ret[$index] = array(
			'shopName' 	=> $shop['shopName'],
			'shopId'	=> $shop['shopId']
			);
		$index ++;
	}
	
	return $ret;
}

/**
 * ��ȡ�ŵ����� 
 */
function getShopName($retailerId,$shopId)
{
	if (!isset($shopId))
	{
		return false;
	}
	
	$res = IBUser::getShopInfo($retailerId, $shopId);
	if (false === $res)
	{
		return false;
	}
	
	if (count($res) <= 0)
	{	
		return false;
	}

	return $res['shopName'];
}

//��ȡ�˺���Ϣ
function getAccountInfo($retailerId,$condition)
{
	if (!is_array($condition) || !isset($retailerId))
	{	
		return false;
	}

	$res = IBUser::getAllSalesman($retailerId,$condition);
	
	if ((false === $res) || (0 === count($res)))
	{
		return false;
	}

	$ret = current($res);
	
	return $ret['uid'];
}

// ��ȡ���˺���������
function getAccountDetail($retailerId,$uid)
{ 
	if (null === $uid || '' === $uid || 0 === $uid)
	{  //@Logger::debug($retailerId);
	    $ret = IRetailer::getRetailers(array('uid'=>$retailerId));
	   // @Logger::debug($ret);
	    if (false === $ret || 0 === count($ret))
	    {
	        return false;
	    }
        
	    $ret = current($ret);
	   // @Logger::debug("IRetailer::getRetailers(array('uid'=>$retailerId));");
	   // @Logger::debug($ret);
	    return array('name' => $ret['name'] , 'account' => $ret['icsonid']);
	}
	else 
	{
		$res = IBUser::getSalesmanInfo($retailerId ,$uid);
		
		if (false === $res) 
		{
			return false;
		}
		//@Logger::debug('IBUser::getSalesmanInfo($retailerId ,$uid);');
		//@Logger::debug($res);
		return array('account'=>$res['account'],'name'=>$res['name']);
	}
}

/**
 * �������ҳ��
 */
function page_bmanageorder_approval()
{
    $uid = ToolUtil::checkLoginOrRedirect();
    $TPL = TemplateHelper::getBaseTPL(0, 'b_approval_order', array(
        'titleDesc' => '�������'
    ));

    $TPL->set_file(array(
        'contentHandler' => 'b_approval_order.tpl'
    ));
    $TPL->set_var('pageName','�������');
    
    $TPL->set_var('shop_info',ToolUtil::gbJsonEncode(getShop($uid)));
    $TPL->parse('content', 'contentHandler');
    $TPL->out();
}

/**
 * ��ȡ�����б����� 
 */
function bmanageorder_list()
{
	 $uid = IUser::getLoginUid();
	 if (false === $uid || $uid <= 0)
	 {
	    return array('errno'=>3 ,'errMsg'=>'login out');
	 }
	 
     
     $currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
     
     $pageSize = 12;

     $input = array(
        'shop_id' => empty($_POST['shopid']) ? '' : intval($_POST['shopid']),
        'name' => empty($_POST['name']) ? '' : $_POST['name'],//iconv('utf-8','gb2312',urldecode($_POST['shopguidename'])),
        'account' => empty($_POST['account']) ? '' : $_POST['account'],//iconv('utf-8','gb2312',urldecode($_POST['receiver'])),
        'status' => empty($_POST['status']) ? '0' : $_POST['status'],
     ); 
     if (isset($_POST['date']) && 2 == intval($_POST['date']))
     {
        $input['onMonthAgo'] = intval($_POST['date']);
     }
     else 
     {
        $input['onMonth'] = intval($_POST['date']);
     }

     if (!empty($_POST['orderid']))
     {
        $input = array('order_char_id'=>$_POST['orderid']);
     }
     $orders = IBPreOrder::getPreOrders($uid,$input,$currentPage,$pageSize);  

     if (false === $orders)
     {
     	Logger::ERR('IBPreOrder::getPreOrders failed (uid= '. $uid . ' ' . IBPreOrder::$errMsg);
        return array('errno'=>2 ,'errMsg'=>'');
     }
     if (0 == $orders['total'])
     {
        return array('errno'=>1 ,'errMsg'=>'no orders');
     }
    
     $ret = array();
     foreach ($orders['data'] AS $item)
     {
            //��Ʒ�б�
            $product_list_str = '';
            if(!empty($item['items']))
            {
                foreach ($item['items'] as $index => $product)
                {
                    if($index > 5)
                    {
                        break;
                    }
                    $product_title = strip_tags($product['name']);
                    $product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);
                    $product_list_str .= '<a target="_blank" href="http://item.51buy.com/productdetail-' . $product['product_id'] .'.html" class="img"><i></i><img src="' . IProduct::getPic($product['product_char_id'], 'small') . '" alt="'.$product_title.'" title="'.$product_title.'"></a>';
                    
                }
            }
            $account_info = getAccountDetail($uid,intval($item['shop_guide_id']));
            if (false === $account_info)
            {
                Logger::err('IBUser::getSalesmanInfo failed');
                $account_info = array('account' => '','name' => '');
            }
           
            $params = array(
                'pre_order_char_id' => $item['order_char_id'],  //�������
                'real_order_id' => (intval($item['real_order_id'])>0) ? $item['real_order_id']:'--',
                'link_real_order' => '--',
                'order_id' => $item['order_id'],
                'order_date' => date("Y-m-d", $item['order_date']), //�µ�ʱ��
                'order_cost' => sprintf("%.2f", $item['shop_guide_cost']/100), // �����ܼ�
                'order_cost_in' => sprintf("%.2f", $item['order_cost']/100), //�����ܼ�
                'status' => $item['status'],  //����״̬
                'product_list_str' => $product_list_str,
                'shop_name' => getShopName($uid,$item['shop_id']),
                'sub_accout' => $account_info['account'],
                'sub_accout_name' => $account_info['name'],
                'products' => $products
            );
            if (intval($item['real_order_id'])>0)
            {
                $params['link_real_order'] = "<a target='_blank' href='http://base.51buy.com/orderdetail-" 
                                    . $item['real_order_id'] . ".html' class='todo_link'>"  
                                    . $item['real_order_id'] ."</a>" ;
            }
            $ret[] = $params;
     }

     return array('errno'=>0,'data'=>$ret,'pages'=>ceil($orders['total']/$pageSize));
}

/**
 * ��ȡ������Ʒ 
 */
function bmanageorder_product()
{
     $uid = IUser::getLoginUid();
     if (false === $uid || $uid <= 0)
     {
         return array('errno'=>3 ,'errMsg'=>'login out');
     }
     if ($uid != $_POST['uid'])
     {
        return array('errno'=>4 ,'errMsg'=>'login error'); //anti csrf
     }
     if (!isset($_POST['orderid']))
     {
         return array('errno'=>2 ,'errMsg'=>'params lost');
     }
     $order_char_id = $_POST['orderid'];
     $order = IBPreOrder::getOneOrderDetail($uid,$order_char_id);
   
     if (false === $order)
     {
     	Logger::ERR('������ȡʧ��' . basename(__FILE__, '.php') . " |" . __LINE__ );
        return array('errno'=>4 ,'errMsg'=>'system error');
     }
     if (0 === count($order))
     {
        return array('errno'=>1 ,'errMsg'=>'order not exits');
     }


     return array('errno'=>0 ,'data'=>$order['items'],'order_cost'=>$order['order_cost']);
}

/**
 * json������� 
 */
function bmanageorder_approval()
{
     $uid = IUser::getLoginUid();
     if (false === $uid || $uid <= 0)
     {
         return array('errno'=>3 ,'errMsg'=>'��¼��ʱ');
     }
     if ($uid != $_POST['uid'])
     {
        return array('errno'=>4 ,'errMsg'=>'ϵͳæ'); //anti csrf
     }
     if (!isset($_POST['orderid']) || !isset($_POST['status']))
     {
         return array('errno'=>2 ,'errMsg'=>'������ʧ');
     }
      global $_OrderState;
     $order_id = intval($_POST['orderid']);
     $status = intval($_POST['status']);

     if ($status !== $_OrderState['WaitingOutStock']['value'])  //1  ��˲�ͨ��
     {
	     if (!isset($_POST['reason']) || '' == $_POST['reason'])
	     {
	         return array('errno'=>5 ,'errMsg'=>'��ͨ��ԭ�򲻿�Ϊ��');
	     }
     }
    
     $reason = $_POST['reason'];
     $ret = IBPreOrder::approvalPreOrder($uid,$order_id,$status,$reason);

     if (false === $ret)
     { 
         return array('errno'=>IBPreOrder::$errCode ,'errMsg'=>IBPreOrder::$errMsg);
     }
     else {
         return array('errno'=>0);
     }
}

/**
 * json ��ȡ������˲�ͨ��ԭ�� 
 */
function bmanageorder_nopasslog()
{
     $uid = IUser::getLoginUid();
     if (false === $uid || $uid <= 0)
     {
         return array('errno'=>3 ,'errMsg'=>'��¼��ʱ');
     }
     if ($uid != $_POST['uid'])
     {
        return array('errno'=>4 ,'errMsg'=>'ϵͳæ'); //anti csrf
     }
     if (!isset($_POST['orderid']))
     {
         return array('errno'=>2 ,'errMsg'=>'������ʧ');
     }
     $order_id = intval($_POST['orderid']);
     $ret = IBPreOrder::getOneOrder($uid, $order_id);
     if (false === $ret)
     {
     	Logger::ERR('������ȡʧ��' . basename(__FILE__, '.php') . " |" . __LINE__ );
        return array('errno'=>5 ,'errMsg'=>'ϵͳæ�����Ժ�����');
     }
    
     return array('errno' => 0,'data'=>ToolUtil::transXSSContent($ret['single_promotion_info']));
}

function bmanageorder_shop()
{
     $uid = IUser::getLoginUid();
     if (false === $uid || $uid <= 0)
     {
         return array('errno'=>3 ,'errMsg'=>'��¼��ʱ');
     }
     
     $res = IBUser::getAllShop($uid, array('status'=>1));
     if (false === $res)
     {   
        return false;
     }

    return array('errno'=>0 ,'data'=>$res);
}