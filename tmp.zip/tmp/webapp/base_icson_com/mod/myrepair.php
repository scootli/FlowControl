<?php

require_once (PHPLIB_ROOT . 'api/IProduct.php');
require_once (PHPLIB_ROOT . 'api/IRMANew.php');
require_once (PHPLIB_ROOT . 'api/IUser.php');
require_once (PHPLIB_ROOT . 'api/IOrder.php');
require_once (PHPLIB_ROOT . 'inc/district.inc.php');
require_once (PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once (PHPLIB_ROOT . 'api/IShipping.php');
require_once (PHPLIB_ROOT . 'api/IShippingTime.php');
require_once (PHPLIB_ROOT . 'inc/ship.inc.php');
require_once (PHPLIB_ROOT . 'api/IPreOrder.php');
require_once (PHPLIB_ROOT . 'api/ISatisfactionSurvey.php');
require_once (PHPLIB_ROOT . 'api/IVirtualPay.php');
require_once ('../api/IRmaApi.php');

$uid = ToolUtil::checkLoginOrRedirect();

Logger::init ();

//����ɹ�ҳ��
function page_myrepair_success(){
	$TPL = TemplateHelper::getBaseTPL( 0, "myrepair", array ('titleDesc' => '����/�˻�������ɹ�'));
	$TPL->set_var('pageName', '����/�˻���');
	$TPL->set_var('rma_id', $_GET['rma_id']);

	$TPL->set_file(array('contentHandler' => 'myrepair_success.tpl'));
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//���������ѯ(ҳ��ģ��)
function page_myrepair_page(){
	
	global $uid, $rma_requestStatus;
	$TPL = TemplateHelper::getBaseTPL( 0, "myrepair", array ('titleDesc' => '����/�˻���'));
	$TPL->set_var('pageName', '����/�˻���');
	$TPL->set_var('myrepair_class', 'sc_nav_cur_item');

	$whId = IUser::getSiteId();
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0);
	if($currentPage < 1) $currentPage = 1;
	$pageSize = 10;

	$TPL->set_file(array('contentHandler' => 'myrepair_cover.tpl'));
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

function _getFirstTdCell($params) {
	extract($params);
	$ret = "<td class='left {$bor_r}' {$php_rowspan}>
	<p>{$php_soid}</p>
	<p class='date nor'>{$php_request_time}</p>
	<p>{$php_source}</p>
</td>";

	return $ret;
}

$zindex = 20;

function _getLastTdCell($params, $notes, $request_date) {
	global $zindex;
	extract($params);
	$link = "<div><a target='_blank' href='http://base.51buy.com/myrepairinfo-{$php_request_sysno}-{$regist_sysno}-{$product_id}.html' class='todo_link'>�鿴����</a></div>";

	$survey_link = "<div class='wrap_manyi'>
						<a class='survey_link' survey_link='{$php_request_sysno}' soid='{$php_soid}' href='javascript:;'>���������</a>
					</div>";
	$has_link = false;
	if($status == 999){
		$has_survey = ISatisfactionSurveyTTC::get($php_request_sysno, array(), array('SysNo', 'RequestSysNo'));
		if(false === $has_survey){
			Logger::err('ISatisfactionSurveyTTC get failed. ' . ' errMsg: ' .ISatisfactionSurveyTTC::$errMsg .' errCode: ' .ISatisfactionSurveyTTC::$errCode . ' request_sysno:'.$request_sysno .' request_date: ' .$request_date . ' register_sysno:' . $register_sysno);
			$has_link = false;
		}else if(count($has_survey) >= 1){//����ύ���˼�¼
			$has_link = false;
		}else{
			$has_link = true;
		}
	}
	$survey_link_html = ($has_link == true) ? $survey_link : '';

	$ret = "<td class='{$bor_l}' {$php_rowspan}>
	{$link}
	<div style='z-index: {$zindex};' class='wrap_zixun' id='repair_rma_{$php_request_sysno}'>
		<a href='javascript:;' class='act php_rma_id' id='a_repair_rma_{$php_request_sysno}' repair_comment='{$php_request_sysno}'>������ѯ��¼</a>(<span class='J_noteTotle'>{$notes}</span>)
	</div>
	{$survey_link_html}
</td>";

	$zindex --;
	return $ret;
}

/**
 * ��ȡRMA�������һ����־��ˮ��Ϣ
 * @param $requestsysno ���뵥ϵͳ���
 * @param $registsysno ����������
 * @param $wid ��վid
 * @param $requestdate ���뵥����ʱ��
 * @return ����:��ˮ��־��Ϣ
 */
function myrepair_statusdesclast($requestsysno, $registsysno, $wid, $requestdate,  $status){
	//״ֵ̬
	$val['php_status_desc'] = '�����';
	$request_date = strtotime($requestdate);
	$wid = intval($wid);
	if($request_date <= 1353495600){//2012-11-21 19:00:00 ֮ǰ��Ϊ ��ʷ״̬
		if($status == 0){//�����뵥δ��ˣ���ʾ״̬���Ǵ���ˣ�����ˮ
			$val['php_status_desc'] = '�����';
		}else if(in_array($status, array(-1, 4))){//�����뵥��˲�ͨ������ʾ���뵥��˲�ͨ���Ŀͷ���ע���ݣ�����ˮ��
			$val['php_status_desc'] =  IRMANew::getRmaStatusNotPass_Last($requestsysno, $wid);
		}else{//�����뵥���ͨ������ʾ��ˮ��������״̬
			$val['php_status_desc'] = IRMANew::getOldRmaStatus_Last($registsysno);
		}
	}else{//��״̬:���������ȡ�´�����ˮ��������
		$val['php_status_desc'] = IRMANew::getRmaStatus_Last($requestsysno, $registsysno, $wid);
	}

	return $val['php_status_desc'];
}


//��д��������(ҳ��ģ��)
function page_myrepair_report(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, "myrepair", array ('titleDesc' => '��д����/�˻�������'));

	$TPL->set_var('pageName', '��д����/�˻�������');
	$TPL->set_var('myrepair_class', 'sc_nav_cur_item');

	$TPL->set_file(array('contentHandler' => 'myrepair_report_content.tpl'));
	$TPL->parse('content', 'contentHandler');

	$TPL->set_file(array('refundBankInfo' => 'refund_bankinfo.tpl'));
	$TPL->parse('contentBank', 'refundBankInfo');
	$TPL->out();
}

function page_myrepair_record(){	
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, "myrepair", array ('titleDesc' => '����/�˻�����¼'));

	$TPL->set_var('pageName', '��д����/�˻�������');
	$TPL->set_var('myrepair_class', 'sc_nav_cur_item');
	
	$whId = IUser::getSiteId();
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0);
	if($currentPage < 1){
		$currentPage = 1;
	}
	$pageSize = 10;
	
	$postsaleData = IRmaApi::getPostsaleByUid($uid, $whId);
	//var_dump($postsaleData);
	//return;
	$total = ceil($postsaleData['data']['totalcount'] / $pageSize);
	
	/*
	$rmaList = IRMANew::getRmaApplies($uid, $whId, $pageSize, ($currentPage-1));
	if($rmaList === false){
		Logger::err("IRMANew::getRmaApplies failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ', uid:' . $uid . ', whid:' . $whId);
		return _output_error( "ϵͳ��æ�����Ժ����ԣ�", $TPL );
	}*/

	$TPL->set_file(array('contentHandler' => 'myrepair_record.tpl'));
	$TPL->set_block('contentHandler', 'repair_list', 't_repair_list');
	
	$postsaleData['data']['entry'] = array_slice($postsaleData['data']['entry'], ($currentPage - 1), $pageSize);

	if(count($postsaleData['data']['entry']) > 0){
		$total = ceil($postsaleData['data']['totalcount'] / $pageSize);
		foreach($postsaleData['data']['entry'] AS $rma){
			$count = 0;
			$cacl_total = count($rma['Items']);
			
			//��Ʒ��Ϣ
			foreach($rma['Items'] AS $rmaProduct) {
				$params = array();
				$params['php_soid'] = $rma['SOID'];//������
				$params['status'] = $rma['Status'];//״̬
				$strtotime_RequestDate = substr($rma['RowCreateDate'], 0, 10);
				//var_dump(($rma['RowCreateDate']));
				
				//������Ϣ
				$params['php_request_id'] = $rma['ReqSysNo'];
				$params['php_request_sysno'] = $rma['ReqSysNo'];
				$params['php_request_time'] = $rma['RowCreateDate'];
				$params['php_source'] = $rma['SourceTypeDesc'];
				
				if ($cacl_total == 1) {
					$params['php_rowspan'] = '';
					$params['bor_r'] = '';
					$params['bor_l'] = '';
				}
				else {
					$params['php_rowspan'] = " rowspan='{$cacl_total}'";
					$params['bor_r'] = 'bor_r';
					$params['bor_l'] = 'bor_l';
				}

				$vars['first_td_cell'] = (0 == $count) ? _getFirstTdCell($params) : ''; //first
				
				$vars['rma_type'] = $rma['HandleTypeDesc'];
				
				//��Ʒ��Ϣ
				$pid =  $rmaProduct['ProductSysNo'];
				$product_title = strip_tags($rmaProduct['ProductName']);
				$product_title = htmlspecialchars($product_title, ENT_QUOTES);
				$php_pic = '<img src="' . IProduct::getPic($rmaProduct['ProductID'], 'small') . '" alt="'.$product_title.'" title="'.$product_title.'">';
				$vars['product_id'] = $pid;
				$vars['product_title'] = $product_title;
				$vars['php_pic'] = $php_pic;

				//����ģ��
				$params['product_id'] = $pid;//��Ʒid
				$params['regist_sysno'] = $rmaProduct['ReqItemSysNo'];//����������
				$params['status'] = $rma['Status'];//���뵥״̬
				$vars['last_td_cell'] = (0 == $count) ? _getLastTdCell($params, $rma['TotalMsg'], $strtotime_RequestDate) : ''; //last

				$vars['php_request_sysno'] = $rma['SysNo'];
				//var_dump($rma['SysNo']);
				$vars['php_regist_id'] = '9999';

				//״ֵ̬
				$vars['php_status_desc'] = $rma['StatusDesc'];

				//���뵥����ʱ��
				$vars['php_request_createdate'] = $strtotime_RequestDate;
				$php_regist_id = $vars['php_regist_id'];
				$php_request_sysno = $rma['SysNo'];

				//��������
				$vars['link_track'] = (0== $count) ? '<a class="link_track" href="javascript:;" req_sysno="'. $params['php_request_id'] . '" regist_id="'. $php_regist_id . '" rdate="'. $request_date . '">����<b class="arrow_piont"></b></a>' : '';
				$TPL->set_var($vars);
				$TPL->parse('t_repair_list', 'repair_list', true);
				$TPL->unset_var(array_keys($vars));
				
				$count ++;
			}
		}
		$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/index.php?mod=myrepair&act=record&page={page}', $currentPage, $total)  . '</div></div>');
	}else{
		$TPL->set_var(array('t_repair_list' => '<tr><td colspan="7" align="center"><p class="kong">�����û�����뱨��/�˻�����</p></td></tr>'));
		$TPL->set_var('page','');
	}

	/*
	if(!empty($rmaList['data']) && count($rmaList['data']) >0){
		$total = ceil($rmaList['total'] / $pageSize);
		$noProductFind = true;
		foreach($rmaList['data'] as &$rma){
			//��Ʒ��Ϣ
			$vars = array();
			if(empty($rma['Iproducts'])){ //exception
				continue;
			}else {
				$noProductFind = false;
				$count = 0;
				$cacl_total = count($rma['Iproducts']);

				//��Ʒ��Ϣ
				foreach($rma['Iproducts'] as $rmaProduct) {
					$params = array();
					$params['php_soid'] = $rma['SOID'];//������
					$strtotime_RequestDate = strtotime($rma['RequestDate']);
					//������Ϣ
					$params['php_request_id'] = $rma['RequestSysNo'];
					$params['php_request_sysno'] = $rma['SysNo'];
					$params['php_request_time'] = (empty($rma['RequestDate']) || ($strtotime_RequestDate <0)) ? '' : $rma['RequestDate'];
					$params['php_source'] = ($rma['Source'] == 1) ? '�û��Խ�' : '�ͷ�����';

					if ($cacl_total == 1) {
						$params['php_rowspan'] = '';
						$params['bor_r'] = '';
						$params['bor_l'] = '';
					}
					else {
						$params['php_rowspan'] = " rowspan='{$cacl_total}'";
						$params['bor_r'] = 'bor_r';
						$params['bor_l'] = 'bor_l';
					}

					$vars['first_td_cell'] = (0 == $count) ? _getFirstTdCell($params) : ''; //first

					//��Ʒ��Ϣ
					$pid =  $rmaProduct['I_ProductSysNo'];
					$pinfo = IProduct::getBaseInfo($pid, $whId, true);
					if($pinfo === false){
						$vars['product_id'] = '';
						$vars['product_title'] = '';
						$vars['php_pic'] = '';
					}else if(empty($pinfo) || count($pinfo) <0){
						$vars['product_id'] = '';
						$vars['product_title'] = '';
						$vars['php_pic'] = '';
					}else{
						$product_title = strip_tags($pinfo['name']);
						$product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);
						$php_pic = '<img src="' . IProduct::getPic($pinfo['product_char_id'], 'small') . '" alt="'.$product_title.'" title="'.$product_title.'">';
						$vars['product_id'] = $pid;
						$vars['product_title'] = $product_title;
						$vars['php_pic'] = $php_pic;
					}

					//����ģ��
					$params['product_id'] = $pid;//��Ʒid
					$params['regist_sysno'] = $rmaProduct['I_RegistSysNo'];//����������
					$params['status'] = $rma['Status'];//���뵥״̬
					$vars['last_td_cell'] = (0 == $count) ? _getLastTdCell($params, $rma['Nnotes'], $strtotime_RequestDate) : ''; //last
					$count++;

					$vars['php_request_sysno'] = $rma['SysNo'];
					//var_dump($rma['SysNo']);
					$vars['php_regist_id'] = $rmaProduct['I_RegistSysNo'];

					//״ֵ̬
					$vars['php_status_desc'] = myrepair_statusdesclast($rma['SysNo'], $rmaProduct['I_RegistSysNo'], $whId, $rma['RequestDate'],  $rma['Status']);

					//���뵥����ʱ��  ��2012-11-21 19:00:00 (1353495600) Ϊ���ն���
					$strtotime_RequestDate = $strtotime_RequestDate;
					$request_date = ( $strtotime_RequestDate <= 1353495600 ) ? '1' : '2';
					$vars['php_request_createdate'] = $request_date;
					$php_regist_id = $rmaProduct['I_RegistSysNo'];
					$php_request_sysno = $rma['SysNo'];

					//��������
					$link_track = ( ($strtotime_RequestDate <= 1353495600) && (in_array($rma['Status'], array(-1, 4))) ) ? "" : '<a class="link_track" href="javascript:;" req_sysno="'. $php_request_sysno . '" regist_id="'. $php_regist_id . '" rdate="'. $request_date . '">����<b class="arrow_piont"></b></a>';
					$vars['link_track'] = $link_track;
					$TPL->set_var($vars);
					$TPL->parse('t_repair_list', 'repair_list', true);
					$TPL->unset_var(array_keys($vars));
				}
			}
		}
		if($noProductFind){
			$TPL->set_var(array('t_repair_list' => '<tr><td colspan="7"><p class="kong">��ǰ���������쳣�������Ժ�����!</p></td></tr>'));
		}
		$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/index.php?mod=myrepair&act=record&page={page}', $currentPage, $total)  . '</div></div>');
	}
	else {
		$TPL->set_var(array('t_repair_list' => '<tr><td colspan="7"><p class="kong">�����û�����뱨��/�˻�����</p></td></tr>'));
		$TPL->set_var('page','');
	}*/
	
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//���ӱ���/�˻���/�˿�����
function myrepair_add(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		Logger::err("is not uid" . IUser::$errCode . ', msg:' . IUser::$errMsg);
		return array('errno' => 500);
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		Logger::err("uid is empty");
		return array('errno' => 501);
	}
	$rmaInfo = array('user_id' => $uid );

	if(empty($_POST['order_id'])){
		Logger::err("order_id is empty, uid:" . $uid);
		return array('errno' => 10);
	}
	$rmaInfo['order_id'] = $_POST['order_id'];

	if(empty($_POST['order_items'])){
		Logger::err("order_items is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 11);
	}

	$rmaInfo['product_ids'] = false;
	$pids = explode(',', $_POST['order_items']);
	if($pids){
		foreach($pids AS $pidval){
			list($pid, $count) = explode('.', $pidval);
			if($pid && is_numeric($count) && $count > 0){
				$rmaInfo['product_ids'][$pid] = $count;
			}
		}
	}
	if(!$rmaInfo['product_ids']){
		Logger::err("product_ids is empty, uid:" . $uid . "order_id:" . $_POST ['order_id'] . "order_items:" . $_POST ['order_items'] );
		return array('errno' => 12);
	}

	if(empty($_POST['description'])){
		Logger::err ("description is empty, uid:" . $uid . "order_id:" . $_POST ['order_id'] . "order_items:" . $_POST ['order_items'] . "product_ids:" . $rmaInfo ['product_ids'] );
		return array('errno' => 13 );
	}
	$rmaInfo ['description'] = $_POST ['description'];

	//ȡ����Ϣ
	$rmaInfo ['contact_info'] = array();
	if(empty( $_POST ['contact_contact'])){
		Logger::err( "contact_contact is empty, uid:" . $uid . "order_id:" . $_POST ['order_id'] . "order_items:" . $_POST ['order_items'] . "product_ids:" . $rmaInfo ['product_ids'] . "description:" . $_POST ['description'] );
		return array('errno' => 14);
	}

	$rmaInfo ['contact_info'] ['contact'] = $_POST ['contact_contact'];

	//��ϵ��ʽ(�ֻ�/�̻�)
	if(empty($_POST['contact_mobile'])){
		Logger::err( "contact_phone is empty, uid:" . $uid . "order_id:" . $_POST ['order_id'] . "order_items:" . $_POST ['order_items'] . "product_ids:" . $rmaInfo ['product_ids'] . "description:" . $_POST ['description'] . "contact_contact:" . $_POST ['contact_contact'] );
		return array('errno' => 15);
	}

	$rmaInfo['contact_info']['mobile'] = ! empty($_POST['contact_mobile']) ? $_POST['contact_mobile'] : '';
	$rmaInfo['contact_info']['phone'] = ! empty($_POST['contact_phone']) ? $_POST['contact_phone'] : '';

	if(!empty($_POST['is_revert_result']) && $_POST['is_revert_result'] == 1){
		$rmaInfo ['reason'] = 1;
	}else{
		$rmaInfo ['reason'] = 0;
	}

	//����������ʽ
	if(empty($_POST['request_type'])){
		Logger::err ( "request_type is empty, uid:" . $uid . "order_id:" . $_POST ['order_id']);
		return array ('errno' => 16 );
	}
	$rmaInfo['request_type'] = $_POST['request_type'];

	//����֧����ʽ
	if(isset($_POST['pay_type']) && !empty($_POST['pay_type'])){
		$rmaInfo['pay_type'] = $_POST['pay_type'];
	}
	$pay_type = $_POST['pay_type'];

	//ѡ���˻�,�˿�
	if(3 == $rmaInfo['request_type']){
		$rmaInfo['refund_type'] = $_POST['refund_type'];//�˿ʽ
		if(2 == $rmaInfo['refund_type']){//�˿������п�
			if(empty($_POST['sel_online_pay'])){
				Logger::err ( "sel_online_pay is empty");
				return array ('errno' => 17 );
			}
			$rmaInfo['sel_online_pay'] = $_POST['sel_online_pay'];

			if(empty($_POST['area_id_bank'])){
				Logger::err ( "area_id_bank is empty");
				return array ('errno' => 18 );
			}
			$rmaInfo['area_id_bank'] = $_POST['area_id_bank'];

			if(empty($_POST['sel_refund_bank'])){
				Logger::err ( "refund_bank is empty");
				return array ('errno' => 19 );
			}
			$rmaInfo['refund_bank'] = $_POST['sel_refund_bank'];

			if(empty($_POST['account_name'])){
				Logger::err ( "account_name is empty");
				return array ('errno' => 20 );
			}
			$rmaInfo['account_name'] = $_POST['account_name'];

			if(empty($_POST['account_no'])){
				Logger::err ( "account_no is empty");
				return array ('errno' => 21 );
			}
			$rmaInfo['account_no'] = $_POST['account_no'];

			if(empty($_POST['mobile_phone_bank'])){
				Logger::err ( "mobile_phone is empty");
				return array ('errno' => 22 );
			}
			$rmaInfo['mobile_phone_bank'] = $_POST['mobile_phone_bank'];
			$rmaInfo['bank_cityName'] = empty($_POST['bank_cityName']) ? $_POST['area_id_bank'] : $_POST['bank_cityName'];//��������
			$rmaInfo['refund_bankName'] = empty($_POST['refund_bankName']) ? $_POST['sel_refund_bank'] : $_POST['refund_bankName'];//֧������
		}else{
			if($pay_type == 15){//�˿�������OK��
				if(empty($_POST['lianhua_ok_id'])){
					Logger::err ( "lianhua_ok_id is empty");
					return array ('errno' => 23 );
				}
				$rmaInfo['lianhua_ok_id'] = $_POST['lianhua_ok_id'];
			}

			if($pay_type == 32){//�˿���һ�ǿ�
				if(empty($_POST['yicheng_id'])){
					Logger::err ( "yicheng_id is empty");
					return array ('errno' => 24 );
				}
				$rmaInfo['yicheng_id'] = $_POST['yicheng_id'];
			}
		}
	}

	//ѡ��ȡ����ʽ
	$rmaInfo['contact_info']['fetchgoods_way'] = $_POST['fetchgoods_way'];//ȡ����ʽ
	if($rmaInfo['contact_info']['fetchgoods_way'] != 1 && $rmaInfo['contact_info']['fetchgoods_way'] != 4){
		$rmaInfo['contact_info']['can_door_get'] = 0;
		$rmaInfo['contact_info']['etake_date'] = '';
		$rmaInfo['contact_info']['etake_time_span'] = 0;
	}else{//��Ѹ�������ȡ��
		//����ȡ��$rmaInfo ['contact_info'] ['can_door_get'] = 1;
		//ȡ������
		if(empty($_POST['etake_date'])){
			Logger::err("etake_date is empty, uid:" . $uid . "order_id:" . $_POST['order_id'] . "order_items:" . $_POST['order_items'] . "product_ids:" . $rmaInfo['product_ids'] . "description:" . $_POST['description'] . "contact_contact:" . $_POST['contact_contact'] . "contact_phone:" . $_POST['contact_phone'] . "is_revert_result:" . $_POST['is_revert_result'] . "can_door_get:" . $rmaInfo['contact_info']['can_door_get'] );
			return array('errno' => 2 );
		}
		$rmaInfo['contact_info']['etake_date'] = $_POST['etake_date'];

		//ȡ��ʱ��
		if(!isset($_POST ['etake_time_span'])){
			Logger::err("etake_time_span not set, uid:" . $uid . "order_id:" . $_POST['order_id'] . "order_items:" . $_POST['order_items'] . "product_ids:" . $rmaInfo['product_ids'] . "description:" . $_POST['description'] . "contact_contact:" . $_POST['contact_contact'] . "contact_phone:" . $_POST['contact_phone'] . "is_revert_result:" . $_POST['is_revert_result'] . "can_door_get:" . $rmaInfo['contact_info'] ['can_door_get'] . "etake_date:" . $_POST['etake_date'] );
			return array('errno' => 26);
		}
		$rmaInfo ['contact_info'] ['etake_time_span'] = $_POST ['etake_time_span'] - 0;
	}

	if(empty($_POST['contact_area_id']) || ! _checkDistrictValid ( $_POST['contact_area_id'] )){
		Logger::err("contact_area_id is empty, uid:" . $uid . "order_id:" . $_POST['order_id'] . "order_items:" . $_POST['order_items'] . "product_ids:" . $rmaInfo['product_ids'] . "description:" . $_POST['description'] . "contact_contact:" . $_POST['contact_contact'] . "contact_phone:" . $_POST['contact_phone'] . "is_revert_result:" . $_POST['is_revert_result'] . "can_door_get:" . $rmaInfo['contact_info']['can_door_get'] . "etake_date:" . $_POST['etake_date'] . "etake_time_span:" . $_POST['etake_time_span'] );
		return array('errno' => 27 );
	}

	$rmaInfo ['contact_info'] ['area_id'] = $_POST['contact_area_id'];

	if(empty($_POST['contact_address'])){
		Logger::err ("contact_address is empty, uid:" . $uid . "order_id:" . $_POST['order_id'] . "order_items:" . $_POST['order_items'] . "product_ids:" . $rmaInfo['product_ids'] . "description:" . $_POST['description'] . "contact_contact:" . $_POST['contact_contact'] . "contact_phone:" . $_POST['contact_phone'] . "is_revert_result:" . $_POST['is_revert_result'] . "can_door_get:" . $rmaInfo['contact_info']['can_door_get'] . "etake_date:" . $_POST['etake_date'] . "etake_time_span:" . $_POST['etake_time_span'] . "contact_area_id:" . $_POST ['contact_area_id'] );
		return array ('errno' => 28 );
	}

	$rmaInfo['contact_info']['address'] = $_POST['contact_address'];

	if(empty($_POST['contact_zip'])){
		$_POST['contact_zip'] = '';
	}
	$rmaInfo['contact_info']['zip'] = $_POST['contact_zip'];

	if(!empty($_POST['is_revert_address']) && $_POST['is_revert_address'] == 1){
		$rmaInfo['is_revert_address'] = 1;
		$rmaInfo['revert_contact_info'] = array();
		
		$rmaInfo['revert_contact_info']['area_id'] = $rmaInfo['contact_info']['area_id'];
		$rmaInfo['revert_contact_info']['address'] = $rmaInfo['contact_info']['address'];
		$rmaInfo['revert_contact_info']['mobile'] = $rmaInfo['contact_info']['mobile'];
		$rmaInfo ['revert_contact_info']['contact'] = $rmaInfo['contact_info']['contact'];
		$rmaInfo['revert_contact_info']['zip'] = $rmaInfo['contact_info']['zip'];
		
	}else{
		//�Զ����ջ���Ϣ
		$rmaInfo['is_revert_address'] = 0;
		$rmaInfo['revert_contact_info'] = array();

		if(empty($_POST['revert_contact_contact'])){
			Logger::err("revert_contact_contact is empty, uid:" . $uid . "order_id:" . $_POST['order_id'] . "order_items:" . $_POST['order_items'] . "product_ids:" . $rmaInfo['product_ids'] . "description:" . $_POST['description'] . "contact_contact:" . $_POST['contact_contact'] . "contact_phone:" . $_POST['contact_phone'] . "is_revert_result:" . $_POST['is_revert_result'] . "can_door_get:" . $rmaInfo['contact_info']['can_door_get'] . "etake_date:" . $_POST['etake_date'] . "etake_time_span:" . $_POST['etake_time_span'] . "contact_area_id:" . $_POST['contact_area_id'] . "contact_zip:" . $_POST['contact_zip'] . "is_revert_address:" . $_POST['is_revert_address'] );
			return array('errno' => 29);
		}
		$rmaInfo['revert_contact_info']['contact'] = $_POST['revert_contact_contact'];

		if(empty($_POST['revert_contact_mobile'])){
			Logger::err("revert_contact_phone and revert_contact_mobile is empty, uid:" . $uid . "order_id:" . $_POST['order_id'] . "order_items:" . $_POST['order_items'] . "product_ids:" . $rmaInfo['product_ids'] . "description:" . $_POST['description'] . "contact_contact:" . $_POST['contact_contact'] . "contact_phone:" . $_POST['contact_phone'] . "is_revert_result:" . $_POST['is_revert_result'] . "can_door_get:" . $rmaInfo['contact_info'] ['can_door_get'] . "etake_date:" . $_POST['etake_date'] . "etake_time_span:" . $_POST['etake_time_span'] . "contact_area_id:" . $_POST['contact_area_id'] . "contact_zip:" . $_POST['contact_zip'] . "is_revert_address:" . $_POST['is_revert_address'] . "revert_contact_contact:" . $_POST['revert_contact_contact']);
			return array('errno' => 30);
		}
		$rmaInfo['revert_contact_info']['phone'] = ! empty($_POST['revert_contact_phone']) ? $_POST['revert_contact_phone'] : '';
		$rmaInfo['revert_contact_info']['mobile'] = ! empty($_POST['revert_contact_mobile']) ? $_POST['revert_contact_mobile'] : '';

		if(empty($_POST['revert_contact_area_id']) || ! _checkDistrictValid($_POST['revert_contact_area_id'])){
			Logger::err("revert_contact_area_id is empty, uid:" . $uid . "order_id:" . $_POST['order_id'] . "order_items:" . $_POST['order_items'] . "product_ids:" . $rmaInfo['product_ids'] . "description:" . $_POST['description'] . "contact_contact:" . $_POST['contact_contact'] . "contact_phone:" . $_POST['contact_phone'] . "is_revert_result:" . $_POST['is_revert_result'] . "can_door_get:" . $rmaInfo['contact_info']['can_door_get'] . "etake_date:" . $_POST['etake_date'] . "etake_time_span:" . $_POST['etake_time_span'] . "contact_area_id:" . $_POST['contact_area_id'] . "contact_zip:" . $_POST['contact_zip'] . "is_revert_address:" . $_POST['is_revert_address'] . "revert_contact_contact:" . $_POST['revert_contact_contact'] . "revert_contact_phone:" . $_POST['revert_contact_phone'] );
			return array('errno' => 31 );
		}
		$rmaInfo['revert_contact_info']['area_id'] = $_POST['revert_contact_area_id'];

		if(empty($_POST['revert_contact_address'])){
			Logger::err("revert_contact_area_id is empty, uid:" . $uid . "order_id:" . $_POST['order_id'] . "order_items:" . $_POST['order_items'] . "product_ids:" . $rmaInfo['product_ids'] . "description:" . $_POST['description'] . "contact_contact:" . $_POST['contact_contact'] . "contact_phone:" . $_POST['contact_phone'] . "is_revert_result:" . $_POST['is_revert_result'] . "can_door_get:" . $rmaInfo['contact_info']['can_door_get'] . "etake_date:" . $_POST['etake_date'] . "etake_time_span:" . $_POST['etake_time_span'] . "contact_area_id:" . $_POST['contact_area_id'] . "contact_zip:" . $_POST['contact_zip'] . "is_revert_address:" . $_POST['is_revert_address'] . "revert_contact_contact:" . $_POST['revert_contact_contact'] . "revert_contact_phone:" . $_POST['revert_contact_phone'] . "revert_contact_area_id:" . $_POST['revert_contact_area_id'] );
			return array('errno' => 32);
		}
		$rmaInfo['revert_contact_info']['address'] = $_POST['revert_contact_address'];

		$rmaInfo['revert_contact_info']['zip'] = $_POST['revert_contact_zip'];
	}

	$order = IOrder::getOneOrderDetail($uid, $rmaInfo['order_id']);
	if($order === false){
		Logger::err("IOrder::getOneOrder failed, code:" . IOrder::$errCode . ', msg:' . IOrder::$errMsg . ', uid:' . $uid . ',order_id:' . $rmaInfo['order_id']);
		return array('errno' => 6001 );
	}

	if($order ['status'] != 4){
		Logger::err( "status <> 4");
		return array('errno' => 6002);
	}
	
	/*
	$order_item_counts = array();
	foreach($order['items'] AS $item){
		$order_item_counts[$item['product_id']] = $item['buy_num'];
	}

	$available = IRMANew::getAvaliableOrderProducts($uid, $rmaInfo['order_id'], $rmaInfo['product_ids'], $order['hw_id'], 2, $order_item_counts);
	if($available === false){
		Logger::err("IRMANew::getAvaliableOrderProducts failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ', uid:' . $uid . ',order_id:' . $rmaInfo['order_id']);
		return array('errno' => 6003);
	}

	foreach($rmaInfo['product_ids'] as $k => $idItem ) {
		if(isset($available[$idItem]) && $available[$idItem] === false){
			Logger::err("IRMANew::getAvaliableOrderProducts this product_is can't repair, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg );
			return array('errno' => 6004, 'data' => $idItem);
		}
	}*/
	
	$order = _getorderavaliableitembyapi($order);
	if($order === false){
		return array('errno' => 6003);
	}
	foreach($order['items'] AS $item){
		if($item['canapplycount'] < $rmaInfo['product_ids'][$item['product_id']]){
			return array('errno' => 6004, 'data' => $item['product_id']);
		}
	}

	// ����ȡ������$_POST['fetchgoods_way']
	$now = time();
	if ($rmaInfo['contact_info']['fetchgoods_way'] == 1) {
		$productInfo = IOrder::getOrderItems($uid, $rmaInfo['order_id']);
		if ($productInfo === false) {
			Logger::err("IOrder::getOrderItems failed, code:" . IOrder::$errCode . ', msg:' . IOrder::$errMsg . ',uid:' . $uid . ',order_id:' . $rmaInfo['order_id']);
			return array('errno' => 6005 );
		}

		$weight = 0;
		foreach( $productInfo as $k => $pro ){
			if(isset($available[$pro['product_id']])){
				$weight += $pro['weight'];
			}
		}

		if($now - ($order['out_time'] + 24 * 3600) < 15 * 24 * 3600){ //15������
			if($rmaInfo['reason'] == 0){ //��������
				$pickup_price = 0;
			}else{ //����������
				if($weight > 0 && $weight <= 5000){
					$pickup_price = 600;
				}else if($weight > 5000){
					$pickup_price = 1500;
				}else{
					$pickup_price = 0;
				}
			}
		}else{ //15������
			if($weight > 0 && $weight <= 5000){
				$pickup_price = 600;
			}else if($weight > 5000){
				$pickup_price = 1500;
			}else{
				$pickup_price = 0;
			}
		}
		$rmaInfo['contact_info']['door_get_fee'] = $pickup_price / 100;
	} else {
		$rmaInfo['contact_info']['door_get_fee'] = 0;
	}

	global $_StockToStation;// ����������վ��
	$stockNo = empty($order['stockNo']) ? $order['hw_id'] : $order['stockNo'];
	@$stock_wh_id = $_StockToStation[$stockNo];

	$rmaInfo['useDays'] = abs(ceil(($now - $order['out_time'])/86400));//�û�ʹ������
	
	//�ϴ���ͼƬ
	$rmaInfo['pictures'] = $_POST['pictures'];
	
	/*
	$result = IRMANew::addRequest($rmaInfo, @$stock_wh_id);
	if($result === false){
		Logger::err("IRMANew::addRequest failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg);
		return array('errno' => 6006 );
	}
	var_dump($result);
	*/
	
	//д�ӿ�
	$whId = IUser::getSiteId();
	$nums = array();
	$pids = array();
	foreach($rmaInfo['product_ids'] AS $pid => $count){
		$nums[] = $count;
		$pids[] = $pid;
	}

	$data = array(
			'CustomerSysNo'		=> $uid,
			'HandleType'		=> intval($rmaInfo['request_type']) - 1,
			'ProductDesc'		=> ToolUtil::transXSSContent($rmaInfo['description']),
			'ReasonType'		=> $rmaInfo['reason'],
			'SiteSysNo'			=> $whId,
			'SoSysNo'			=> intval(substr($rmaInfo['order_id'], -8)),
			'CreateTime'		=> date('Y-m-d H:i:s'),
			'ImagesUrl'			=> $rmaInfo['pictures'],
			'Num'				=> implode(',', $nums),
			'ProductSysNo'		=> implode(',', $pids),
			
			'RecAddress'		=> $rmaInfo['contact_info']['address'],
			'RecAreaSysNo'		=> $rmaInfo['contact_info']['area_id'],
			'RecPhone'			=> '',
			'RecCellPhone'		=> $rmaInfo['contact_info']['mobile'],
			'RecContact'		=> ToolUtil::transXSSContent($rmaInfo['contact_info']['contact']),
			'RecETakeDate'		=> $rmaInfo['contact_info']['etake_date'],
			'RecETakeTimeSpan'	=> $rmaInfo['contact_info']['etake_time_span'],
			'RecIsLarge'		=> 1,
			'RecFee'			=> $rmaInfo['contact_info']['door_get_fee'],
			'RecReqRecType'		=> $rmaInfo['contact_info']['fetchgoods_way'],
			'RecZip'			=> $rmaInfo['contact_info']['zip'],
			
			'RevAreaSysNo'		=> $rmaInfo['revert_contact_info']['area_id'],
			'RevAddress'		=> $rmaInfo['revert_contact_info']['address'],
			'RevCellPhone'		=> $rmaInfo['revert_contact_info']['mobile'],
			'RevContact'		=> $rmaInfo ['revert_contact_info']['contact'],
			'RevZip'			=> $rmaInfo['revert_contact_info']['zip']
	);
	
	//�˿�
	if($rmaInfo['request_type'] == 3){
		$data['RefundTypeSysNo']	= $rmaInfo['refund_type'];
		if($rmaInfo['refund_type'] == 2){	//�˿�������
			$data['AccountName']		= ToolUtil::transXSSContent($rmaInfo['account_name']);
			$data['AccountNo']			= $rmaInfo['account_no'];
			$data['AccountPhone']		= $rmaInfo['mobile_phone_bank'];
			$data['Bank']				= $rmaInfo['sel_online_pay'];
			$data['BankCity']			= $rmaInfo['area_id_bank'];
			$data['BankSubBranchSysNo']	= $rmaInfo['refund_bank'];
		}else{
			if(isset($rmaInfo['pay_type']) && !empty($rmaInfo['pay_type'])){
				$refund_payType = $rmaInfo['pay_type'];//֧����ʽ
				if($refund_payType == 15){//�˿�������OK��
					$data['RefundAccountNo']	= ToolUtil::transXSSContent($rmaInfo['lianhua_ok_id']);
				}
				if($refund_payType == 32){//�˿���һ�ǿ�
					$data['RefundAccountNo']	= ToolUtil::transXSSContent($rmaInfo['yicheng_id']);
				}
			}
		}
	}
	
	$ret = IRmaApi::addPostsale($data);
	if($ret['return_code'] != 0){
		//IRMANew::removeRequest($uid);
		return array(
				'errno'	=> $ret['return_code'],
				'msg'	=> $ret['return_message']
		);
	}

	return array ('errno' => 0, 'data' => $ret['data']['ReqSysNo']);
}

//�������Ժ�,ͨ���첽����������ȡ������Ϣ
function myrepair_getnotes(){
	$uid = IUser::getLoginUid();
	$whId = IUser::getSiteId();
	if(!$uid){
		return array('errno' => 500 );
	}

	if(empty($_GET ['reqid'])) {
		return array('errno' => 11 );
	}
	$rma_id = $_GET['reqid'];

	$notes = IRmaApi::getPostsaleMessage($rma_id, 1);
	if($notes['return_code'] != 0){
		Logger::err("IRMANew::getPostsaleMessage failed, code:" . $notes['return_code'] . ', msg:' . $notes['return_message'] . ',uid:' . $uid . ',rma_id:' . $rma_id);
		return array('errno' => 6001 );
	}

	return array ('errno' => 0, 'data' => $notes['data']['entry'], 'notestotal' => $notes['data']['totalcount']);
}

//��ȡ�ɱ��޵���Ʒ��Ϣ
function myrepair_getavailableproducts(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		return array('errno' => 500);
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 501);
	}

	if(empty($_GET['order_id'])){
		return array('errno' => 11);
	}
	$order_id = intval($_GET['order_id']);

	$whId = IUser::getSiteId();
	$order = IOrder::getOneOrderDetail($uid, $order_id);
	if($order === false){
		Logger::err("IOrder::getOneOrderDetail failed, code:" . IOrder::$errCode . ', msg:' . IOrder::$errMsg . ',uid:' . $uid . ',order_id' . $order_id);
		return array('errno' => 6001);
	}
	$addr_id = $order['receiver_addr_id'];
	$province = ToolUtil::getLocInfo($addr_id);
	$province_id = $province['province_id'];

	global $_StockToStation;
	$stockNo = empty($order['stockNo']) ? $order['hw_id'] : $order['stockNo'];
	@$stock_wh_id = $_StockToStation[$stockNo];
	if($whId != @$stock_wh_id){
		$prid = returnPrid($order['receiver_addr_id'], @$stock_wh_id);//��ȡprid
		return array('errno' => 21 ,'siteID'=>@$stock_wh_id, 'prid'=> $prid);
	}

	if($order['status'] != 4){
		return array('errno' => 22);
	}

	if(empty($order['items'] )){
		$order['items'] = array();
	}

	if(empty($order['receiver_addr_id'])){
		return array('errno' => 23);
	}

	if(empty($order['shipping_type'])){
		return array('errno' => 24);
	}

	/*
	$ids = array();
	foreach($order['items'] as $item){
		$ids[] = $item['product_id'];
		if(empty($item['gift'])) continue;
		foreach ($item['gift'] as $gift){
			$ids[] = $gift['product_id'];
		}
	}
	
	$order_item_counts = array();
	foreach($order['items'] AS $item){
		$order_item_counts[$item['product_id']] = $item['buy_num'];
	}

	$available = IRMANew::getAvaliableOrderProducts($uid, $order_id, $ids, $order['hw_id'], 2);
	if($available === false){
		Logger::err("IRMANew::getAvaliableOrderProducts failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ',uid:' . $uid . ',order_id:' . $order_id);
		return array('errno' => 6002 );
	}

	foreach($order['items'] as $k => $item){
		if(isset($available[$item['product_id']]) && $available[$item['product_id']] > 0){
			$order['items'][$k]['canrepair'] = true;
		}else{
			$order['items'][$k]['canrepair'] = false;
		}
		
		if(empty($item['gift'])) continue;
		foreach($item['gift'] as $v => $gift){
			if (isset( $available[$gift['product_id']] ) && $available[$gift['product_id']] === false) {
				$order['items'][$k]['gift'][$v]['canrepair'] = false;
			} else {
				$order['items'][$k]['gift'][$v]['canrepair'] = true;
			}
		}
	}*/
	
	$order = _getorderavaliableitembyapi($order);
	if($order === false){
		return array('errno' => 6003);
	}
	foreach($order['items'] AS $item){
		if($item['canapplycount'] < $rmaInfo['product_ids'][$item['product_id']]){
			return array('errno' => 6004, 'data' => $item['product_id']);
		}
	}

	//�Ƿ��ܹ�����ȡ��???  �ж϶�������ʱ���Ƿ���15������.
	$order['canRevertReason'] = time() - ($order['out_time'] + 24 * 3600) < 15 * 24 * 3600;

	//����ǩ��̬�����¸�ֵ
	$order['is_sign'] = true;//�Ƿ���ǩ����ˮ (Ĭ��true����ǩ����ˮ��)
	if($order['order_date'] < 1324512000){//2012��12��22��֮ǰ�Ķ�������û��ǩ����ˮ�� 1324512000
		$order['is_sign'] = false;
		$order['request_num'] = 2; //��,��
	}

	//�Ƿ�����Ѹ���(����ȫ����):ICSON_DELIVERY,ICSON_DELIVERY_QF.��������ݸ��ݶ����Ƿ�����������ж����ѳ������ۺ��˿�����
	$shipping_type = array(1,22,44,45);
	if(!in_array($order['shipping_type'],$shipping_type)){//����Ѹ���
		if($order['status'] != 4){//����δ����������ϵ�
			$order['refund_type'] = false;//true:��ǩ��(�ѳ���),false:δǩ��(����δ����������ϵ�)
		}else{
			$order['refund_type'] = true;
		}
	}

	//������ʽ
	$sign_time  = ($order['out_time'] + (24*3600));
	$diff_time =time() - $sign_time;
	if($diff_time <=(7 * 24 * 3600)){//7����:��,��,��
		$order['request_num'] = 3;
	}else if(((8 * 24 * 3600) < $diff_time) && ($diff_time <= (15 * 24 * 3600))){//8��15��: ��,��
		$order['request_num'] = 2;
	}else{//����15��:��
		$order['request_num'] = 1;
	}

	return array ('errno' => 0, 'data' => $order, 'siteID'=>@$stock_wh_id);
}

//����prid��ǰ̨,�����л���վ
function returnPrid($district, $wid){
	$prid = '2626_2621';//Ĭ���Ϻ�
	global $_ProvinceToWhid, $_District;
	@$pid = $_District[$district]['province_id'];//���ݵ���ID�ҵ���Ӧ��ʡID
	@$_wid = $_ProvinceToWhid[@$pid];//����ʡID�ҵ���Ӧ�ķ�վID
	if($wid != @$_wid ){
		$wid = intval($wid);
		switch ($wid){
			case 1:
				$prid = '2626_2621'; break;//�Ϻ��������
			case 1001:
				$prid = '3764_403'; break;//�����������
			case 2001:
				$prid = '3804_131'; break;//������ȫ��
			case 3001:
				$prid = '1325_1323'; break;//�人�н�����
			case 4001:
				$prid = '10160_158'; break;//�����г�����
			case 5001:
				$prid = '2214_2212'; break;//�����г�����
		}
	}else{
		$prid = $district . '_' . @$pid;
	}

	return $prid;
}

//��ȡ����ȡ��ʱ�估����ȡ������
function myrepair_getfetchtime(){
	$uid = IUser::getLoginUid();
	if(! $uid){
		return array('errno' => 500);
	}

	if(empty($_GET['uid'] ) || $_GET['uid'] != $uid){
		return array ('errno' => 501 );
	}

	if(empty($_GET['order_id'])){
		return array('errno' => 11);
	}
	$order_id = intval($_GET['order_id']);

	if(empty($_GET['district'])){
		return array('errno' => 12);
	}
	$distict = $_GET['district'] - 0;

	if(empty($_GET['weight'])){
		return array('errno' => 13 );
	}
	$weight = $_GET['weight'] - 0;

	$distictInfo = _checkDistrictValid($_GET['district']);
	if($distictInfo === false){
		return array('errno' => 14 );
	}

	if(empty($_GET['cityid'])){
		return array('errno' => 15 );
	}
	$cityid = $_GET['cityid'] - 0;

	$reason = empty($_GET['revert_reason']) ? 0 : 1; // 1 �Ƿ���Ʒ��������;0��Ʒ��������

	$order = IOrder::getOneOrderDetail($uid, $order_id);

	if($order === false){
		Logger::err("IOrder::getOneOrderDetail failed, code:" . IOrder::$errCode . ', msg:' . IOrder::$errMsg . ',uid:' . $uid . ',order_id:' . $order_id);
		return array('errno' => 6003 );
	}

	$now = time ();

	$shipMode = 0;
	$pickup_type = 0;//0Ĭ�� 1:�Ϻ�������Ѹ���  2:�Ϻ���������Ѹ��� 3:���Ϻ�������Ѹ��� 4:���Ϻ���������Ѹ���
	$isSH = ($cityid == 2622) ? true : false;//�Ƿ����Ϻ�����
	$is_icson_delivery =false;
	$whId = IUser::getSiteId ();
	$delivery_time = 0;//Ĭ��0: ��Ѹ��ݼ��ռ���
	global $_District,$_WhidToRegion;
	$source_region = $_WhidToRegion[$whId];
	/*
	$shippingTypeAva = IShippingRegionTTC::gets(
		array($distict,
			$_District[$distict]['city_id'],
			$_District[$distict]['province_id'] ),
		array(
			'wh_id' => $source_region,
			'status' => 0 )
		);

	
	if (false === $shippingTypeAva) {

		self::$errCode = IShippingRegionTTC::$errCode;
		self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . '[get IShippingRegionTTC failed]' . IShippingRegionTTC::$errMsg;

		return array('errno' => 6004 );
	}

	$is_icson_delivery	= false;
	$is_yto_delivery	= false;
	$delivery_time		= 0;
	$delivery_time_yto	= 0;
	foreach ($shippingTypeAva AS $sp){
		if($sp['shipping_id'] == ICSON_DELIVERY){
			$is_icson_delivery = true;
			$delivery_time = $sp['delivery_time'];//��Ѹ��ݼ��ռ���
		}elseif($sp['shipping_id'] == 7){
			$is_yto_delivery = true;
			$delivery_time_yto = $sp['delivery_time'];//Բͨ��ݼ��ռ���
		}
	}
	*/

	$ytoicson				= _checkYTOAnd51Buy($distict);
	$is_icson_delivery		= $ytoicson['icson'];
	$is_yto_delivery		= $ytoicson['yto'];
	$delivery_time			= $ytoicson['icson_times'];
	$delivery_time_yto		= $ytoicson['yto_times'];

	if(time() - $order['out_time'] > 15 * 86400){
		$is_yto_delivery = false;
		$ytoicson['yto'] = false;
	}

	if($is_icson_delivery){//���֧����Ѹ���
		if(true == $isSH){//�Ϻ�����
			if($delivery_time == 3){
				$shipMode = 3; //��Ѹ���:1��3�͵���
				$pickup_type = 1;
			}else if($delivery_time == 2){
				$shipMode = 2; //��Ѹ���:1��2�͵���
				$pickup_type = 1;
			}else if($delivery_time == 1){
				$shipMode = 1; //��Ѹ���:1��1�͵���
				$pickup_type = 1;
			}else{
				$shipMode = 0;//����Ѹ���
				$pickup_type = 2;
			}
		}else{//���Ϻ�����
			if($delivery_time == 3){
				$shipMode = 3; //��Ѹ���:1��3�͵���
				$pickup_type = 3;
			}else if($delivery_time == 2){
				$shipMode = 2; //��Ѹ���:1��2�͵���
				$pickup_type = 3;
			} else if($delivery_time == 1){
				$shipMode = 1; //��Ѹ���:1��1�͵���
				$pickup_type = 3;
			}else{
				$shipMode = 0;//����Ѹ���
				$pickup_type = 4;
			}
		}
	}elseif($is_yto_delivery){
		$shipMode = 2;
		$pickup_type = 1;
	}else{//��֧����Ѹ���
		if(true == $isSH){//�Ϻ�����
			$pickup_type = 2;
		}else{//���Ϻ�����
			$pickup_type = 4;
		}
	}

	$fetchprice = 0;
	if($shipMode != 0){
		//����Ʒ��������
		if ($reason == 1){
			if($weight > 10000){
				$fetchprice = ceil(($weight/1000 - 5) * 2 + 6) * 100;
			}elseif($weight > 5000){
				$fetchprice = 1500;
			}else{
				$fetchprice = 600;
			}
		}else{
			if($weight > 10000){
				$fetchprice = ceil(($weight/1000 - 10) * 2 + 15) * 100;
			}elseif($weight > 5000){
				$fetchprice = 1500;
			}else{
				$fetchprice = 0;
			}
		}
	}
	$cTime = date('Hi'); // 1208 1800
	$sDate = 0;

	$sTime = 0; // 1,����;2,����;3,����
	$mTime = 0; // ���ʱ���ֵ
	if ($shipMode == 3){
		$mTime = 3;
		if($cTime < 2200){
			//����ǵ���22��ǰ���ޣ���Ĭ�Ͽ�ѡʱ��Ӵ������翪ʼ
			$sDate = 1;
			$sTime = 1;
		}else{
			//����ǵ���22���Ժ��ޣ�Ĭ�Ͽ�ѡʱ��ӵ��������翪ʼ
			$sDate = 2;
			$sTime = 1;
		}
	}else if($shipMode == 2){
		$mTime = 2;
		if($cTime < 2200){
			//����ǵ���22��ǰ���ޣ���Ĭ�Ͽ�ѡʱ��Ӵ������翪ʼ
			$sDate = 1;
			$sTime = 1;
		}else{
			//����ǵ���22���Ժ��ޣ�Ĭ�Ͽ�ѡʱ��ӵ��������翪ʼ
			$sDate = 2;
			$sTime = 1;
		}
	}else if($shipMode == 1){
		$mTime = 0;
		//$sDate = 1;// ֻ�ܴӵڶ��쿪ʼ
		if($cTime < 2200){
			//����ǵ���22��ǰ���ޣ���Ĭ�Ͽ�ѡʱ��Ӵ������翪ʼ
			$sDate = 1;
			$sTime = 1;
		}else{
			//����ǵ���22���Ժ��ޣ�Ĭ�Ͽ�ѡʱ��ӵ��������翪ʼ
			$sDate = 2;
			$sTime = 1;
		}

	}

	$weekName = array('������', '����һ', '���ڶ�', '������', '������', '������', '������');
	$timeSpanName = array ('1' => '����9: 00-14��00', '2' => '����14��00-18��00', '3' => '����18��00-22��00');
	$shipTime = array ();
	$timeSpan = array ();

	if($shipMode == 0){
	}else if($shipMode != 1){
		for($i = 0; $i < 3; $i ++){
			for($j =($i == 0 ? $sTime : 1); $j <= $mTime; $j ++){
				$timeSpan[$j] = $timeSpanName[$j];
			}

			$time = $now + ($sDate + $i) * 24 * 3600;
			$ymd = date('Y-m-d', $time);
			$shipTime [$ymd] = array('date' => $ymd . ' ' . $weekName[date( 'w', $time )], 'timeSpan' => $timeSpan );
		}
	} else {
		for($i = 0; $i < 3; $i ++) {
			$time = $now + ($sDate + $i) * 24 * 3600;
			$ymd = date('Y-m-d', $time );
			$shipTime[$ymd] = array('date' => $ymd . ' ' . $weekName[date('w', $time)]);
		}
	}
	
	//���Բͨ��ݿɴ�
	$ytoShipTime	= array();
	if($is_yto_delivery){
		$timeSpanName1 = array ('4' => '8��00-17��30');
		$timeSpanName2 = array ('5' => '10��00-18��00');
		$start_time = time();
		
		for($i = 1; $i <= 3; $i ++){
			$time = $start_time + $i * 86400;
			$ymd = date('Y-m-d', $time);
			$w = date('w', $time);
			$ytoShipTime[$ymd] = array(
						'date'		=> $ymd . ' ' . $weekName[$w],
						'timeSpan'	=> ($w==0 || $w==6) ? $timeSpanName1 : $timeSpanName2
			);
		}
	}
	
	//�ӿڲ�ѯ�Ļص�ַ
	$addr_back = IRmaApi::getPickUpAddress(515 /*$cityid*/, 7);

	return array (
			'errno' => 0,
			'data' => array(
					'canfetch'		=> $shipMode == 0 ? 0 : 1,
					'shipTime'		=> $shipTime,
					'fetchprice'	=> $fetchprice,
					'shipMode'		=> $shipMode,
					'pickup_type'	=> $pickup_type,
					'logistics'		=> $ytoicson,
					'ytoShipTime'	=> $ytoShipTime,
					'backMailAddr'	=> $addr_back['data']['MailAddress'] ? $addr_back['data'] : array()
			)
	);
}

//��ȡ���뵥��Ʒ�б���Ϣ
function get_products_info(&$product, $TPL, $whId) {
	$html = '';
	if (!empty($product)){
		foreach($product as &$p){
			$pid =  $p['I_ProductSysNo'];
			$pinfo = IProduct::getBaseInfo($pid, $whId, true);
			if($pinfo === false){
				Logger::err("IProduct::getBaseInfo failed, code:" . IProduct::$errCode . ', msg:' . IProduct::$errMsg . ',pid:' . $pid . ',whid:' . $whId);
				return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL );
			}else if(empty($pinfo) || count($pinfo) <0){
				$html .= "<div class=\"wrap_good\"></div>";
			}else{
				$product_title = strip_tags($pinfo['name']);
				$product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);
				$php_pic = '<img src="' . IProduct::getPic($pinfo['product_char_id'], 'small') . '" alt="'.$product_title.'" title="'.$product_title.'">';
				$html .= "<div class=\"wrap_good\">
							<a href=\"http://item.51buy.com/item-{$pinfo['product_id']}.html\" target=\"_blank\" class=\"img\" title=\"{$product_title}\">{$php_pic}</a>
							<div class=\"goods_name\"><a target=\"_blank\" href=\"http://item.51buy.com/item-{$pinfo['product_id']}.html\">{$product_title}</a></div>
						</div>";
			}
		}
	}

	return $html;
}

//��ȡ��������(����)
function get_notes_info(&$notes) {
	$html = '';
	if(!empty($notes)){
		foreach($notes as &$n){
			$php_nick = ($n['N_Type'] == 1) ? '��' : '��Ѹ��';
			$php_date_chn = $n['N_CreateDate'];
			$php_content = htmlspecialchars($n['N_Content']);
			$html .="<dl>
						<dt>{$php_nick} {$php_date_chn}</dt>
						<dd>{$php_content}</dd>
					</dl>";
		}
	}
	return $html;
}

//��������
function myrepair_addrmacomments(){
	$uid = IUser::getLoginUid();
	$whId = IUser::getSiteId();
	if(!$uid){
		return array('errno' => 500);
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' =>501);
	}
	$commentInfo['user_id'] = $uid;

	$commentInfo = array();
	if(empty($_POST['rma_id'])){
		return array('errno' => 11 );
	}
	$commentInfo['rma_id'] = $_POST['rma_id'];

	if(empty($_POST['content'])){
		return array ('errno' => 12 );
	}
	$commentInfo['comments'] = $_POST['content'];

	$notes = IRMANew::addRmaComments($uid, $whId, $commentInfo);
	if($notes === false){
		Logger::err("IRMANew::addRmaComments failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ',uid:' . $uid . ',whid:' . $whId);
		return array('errno' => 6001 );
	}

	return array ('errno' => 0 );
}


/**
 * ���������½ӿ� add by allenzhou 2012-11-28
 * @param int uid �û�ID
 * @param int rma_id ���뵥����
 * @param string content ��������
 * @return �ɹ�����0 ,���󷵻ض�Ӧ������
 */
function myrepair_addnote(){
	$uid = IUser::getLoginUid();
	$whId = IUser::getSiteId();
	if(!$uid){
		return array('errno' => 500);
	}

	$noteInfo = array();
	$noteInfo['uid'] = $uid;

	if(empty($_GET['rma_id'])){
		return array('errno' => 1 );
	}
	$noteInfo['rma_id'] = ToolUtil::transXSSContent($_GET['rma_id']);

	if(empty($_POST['content'])){
		return array ('errno' => 2 );
	}
	
	$noteInfo['comments'] = ToolUtil::transXSSContent($_POST['content']);
	$noteInfo['comments'] = iconv('utf-8', 'gbk', $noteInfo['comments']);

	$notes = IRmaApi::addPostsaleMessage($noteInfo['rma_id'], $noteInfo['comments'], $whId);
	if($notes['return_code'] != 0){
		Logger::err("IRmaApi::addPostsaleMessage failed, code:" . $notes['return_code'] . ', msg:' . $notes['return_message'] . ',uid:' . $uid . ',whid:' . $whId);
		return array('errno' => 3, 'return_code' => $notes['return_code'], 'return_message' =>  $notes['return_message']);
	}

	return array ('errno' => 0 );
}

/**
 * ��ȡ�û������½ӿ� add by allenzhou 2012-11-28
 * @param int uid �û�ID
 * @param int rma_id ���뵥����
 * @return �ɹ�����0���������� ,���󷵻ض�Ӧ������
 */
function myrepair_getusernotes(){
	$uid = IUser::getLoginUid();
	$whId = IUser::getSiteId();
	if(!$uid){
		return array('errno' => 500 );
	}
	
	if(empty($_REQUEST ['reqid']) && empty($_REQUEST ['rma_id'])) {
		return array('errno' => 11 );
	}
	$rma_id = $_REQUEST['reqid'] ? $_REQUEST['reqid'] : $_REQUEST['rma_id'];

	$notes = IRmaApi::getPostsaleMessage($rma_id, 1);

	if($notes['return_code'] != 0){
		Logger::err("IRMANew::getPostsaleMessage failed, code:" . $notes['return_code'] . ', msg:' . $notes['return_message'] . ',uid:' . $uid . ',rma_id:' . $rma_id);
		return array('errno' => 6001, 'err1' => $notes['return_code'], 'err2' => $notes['return_message']);
	}

	return array ('errno' => 0, 'data' => $notes['data']['entry'], 'notestotal' => $notes['data']['totalcount']);

	if(empty($_GET ['rma_id'])) {
		return array('errno' => 1 );
	}
	$rma_id = ToolUtil::transXSSContent($_GET['rma_id']);

	$notes = IRMANew::getRmaNotes($rma_id, $whId);
	if($notes === false){
		Logger::err("IRMANew::getRmaNotes failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ',uid:' . $uid . ',rma_id:' . $rma_id);
		return array('errno' => 2 );
	}

	$notes['total'] = count($notes);
	return array ('errno' => 0, 'data' => $notes);
}


/**
 * ��ȡ������ˮ��Ϣ�½ӿ� add by allenzhou 2012-11-28
 * @param int req_sysno ���뵥ϵͳ���
 * @param string rdate ���뵥����ʱ��  �Ƿ���2012-11-21 19:00:00 (1353495600) ֮ǰ. ��:1, ��:2
 * @return �ɹ�����0���������� ,���󷵻ض�Ӧ������,��������Ϣ
 */
function myrepair_repairflowlog(){
	$uid = IUser::getLoginUid();
	$whId = IUser::getSiteId ();
	if(empty($uid)){
		return array('errno' => 500);
	}

	if(!isset($_GET['regist_id'])){
		return array(
			"errno" => 1001,
			"data" => "��������"
		);
	}
	$regist_id= intval($_GET['regist_id']);

	if(!isset($_GET['rdate'])){
		return array(
			"errno" => 1002,
			"data" => "��������"
		);
	}
	$rdate= intval($_GET['rdate']);

	//��
	$flow = array();
	if($rdate == 1){//2012-12-21��ǰ��ȡ�ɵ���ˮ������Ϣ
		$result = IRMANew::getRmaRegisterLog($uid, $whId, $regist_id);
		if(false === $result || !is_array($result)){
			Logger::err ( "IRMANew::getRmaRegisterLog failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ',uid:' . $uid . ',whid:' . $whId . ',regist_id:' . $regist_id);
			return array(
				"errno" => 1003,
				"data" => "��ѯʧ��,���Ժ�����"
			);
		}

		if(empty($result) || count($result) <=0 ){
			Logger::err ( "IRMANew::getRmaRegisterLog empty, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ',uid:' . $uid . ',whid:' . $whId . ',regist_id:' . $regist_id);
			return array(
				"errno" => 1004,
				"data" => "��ˮ��¼Ϊ��"
			);
		}

		foreach ($result as &$res){
			$flow[] = array(
				'time' => $res['time'],
				'content' => $res['content']
			);
		}
	}else{//2012-12-21�պ���ȡ�µ���ˮ������Ϣ
		if(!isset($_GET['req_sysno'])){
				return array(
					"errno" => 1005,
					"data" => "��������"
				);
			}
			$req_sysno = intval($_GET['req_sysno'] );

		/*
		$result = IRMANew::getRmaFlowLog($uid, $whId, $req_sysno, $regist_id);

		if(false === $result || !is_array($result)){
			Logger::err ( "IRMANew::getRmaFlowLog failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ',uid:' . $uid . ',whid:' . $whId . ',regist_id:' . $regist_id);
			return array(
				"errno" => 1006,
				"data" => "��ѯʧ��,���Ժ�����"
			);
		}

		if(empty($result) || count($result) <=0 ){
			Logger::err ( "IRMANew::getRmaFlowLog empty, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ',uid:' . $uid . ',whid:' . $whId . ',regist_id:' . $regist_id);
			return array(
				"errno" => 1007,
				"data" => "��ˮ��¼Ϊ��"
			);
		}

		foreach ($result as &$res){
			$flow[] = array(
				'time' => $res['time'],
				'content' => $res['content']
			);
		}
		*/
		
		$flow = array();
	
		$data = IRmaApi::getPostsaleLogs($req_sysno);
		if(count($data['data']['entry']) > 0){
			//var_dump($data['data']['entry']);
			foreach($data['data']['entry'] AS $row){
				$flow[] = array(
					'time'		=> substr($row['RowCreateDate'], 0, 16),
					'type'		=> $row['LogType'],
					'content'	=> $row['OpContent']
				);
			}
		}else{
			return array(
				"errno" => 1004,
				"data" => "��ˮ��¼Ϊ��"
			);
		}
	}

	return array(
		"errno" => 0,
		"data" => $flow
	);
}

//������Ϣ���
function _output_error($str, &$TPL) {
	$TPL->set_var ( 'content', '<div class="i_content" style="text-align:center">' . $str . '</div>' );
	$TPL->out ();
}

//�������Ƿ���Ч
function _checkDistrictValid($districtId){
	$whId = IUser::getSiteId();

	global $_District, $_City, $_Province;

	if(!isset($_District [$districtId])){ // ������Ч
		return false;
	}

	$addr = $_District [$districtId];
	if(!isset($_City[$addr['city_id']])){ // �м���Ч
		return false;
	}

	$addr['city_name'] = $_City[$addr ['city_id']]['name'];

	if(!isset($_Province[$addr['province_id']])){ // ʡ����Ч
		return false;
	}

	$addr['prov_name'] = $_Province[$addr['province_id']];
	$addr['full_name'] = $addr['prov_name'] . $addr['city_name'] . $addr['name'];
	return $addr;
}

//���ٵ���ˮ ͨ��api��ѯ
function myrepair_repairflownew(){
	$uid = IUser::getLoginUid();
	$whId = IUser::getSiteId ();
	
	if(empty($uid)){
		return array('errno' => 500);
	}

	if(!isset($_GET['reqid'])){
		return array(
			"errno" => 1001,
			"data" => "��������"
		);
	}
	$reqid = intval($_GET['reqid']);
	$flow = array();
	
	$data = IRmaApi::getPostsaleLogs($reqid);
	if(count($data['data']['entry']) > 0){
		//var_dump($data['data']['entry']);
		foreach($data['data']['entry'] AS $row){
			$flow[] = array(
				'time'		=> substr($row['RowCreateDate'], 0, 16),
				'type'		=> $row['LogType'],
				'content'	=> $row['OpContent']
			);
		}
	}else{
		return array(
			"errno" => 1004,
			"data" => "��ˮ��¼Ϊ��"
		);
	}
	
	return array(
		"errno" => 0,
		"data" => $flow
	);
}

//���ٵ���ˮ
function myrepair_repairflow(){
	$uid = IUser::getLoginUid();
	$whId = IUser::getSiteId ();
	if(empty($uid)){
		return array('errno' => 500);
	}

	if(!isset($_GET['log_id'])){
		return array(
			"errno" => 1001,
			"data" => "��������"
		);
	}
	$log_id = intval($_GET['log_id'] );
	$flow = array();
	$result = IRMANew::getRmaRegisterLog($uid, $whId, $log_id);
	if(false === $result || !is_array($result)){
		Logger::err ( "IRMANew::getRmaRegisterLog failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ',uid:' . $uid . ',whid:' . $whId . ',;og_id:' . $log_id);
		return array(
			"errno" => 1002,
			"data" => "��ѯʧ��,���Ժ�����"
		);
	}

	if(empty($result) || count($result) <=0 ){
		Logger::err ( "IRMANew::getRmaRegisterLog empty, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ',uid:' . $uid . ',whid:' . $whId . ',;og_id:' . $log_id);
		return array(
			"errno" => 1003,
			"data" => "��ˮ��¼Ϊ��"
		);
	}

	foreach ($result as &$res){
		$flow[] = array(
			'time' => $res['time'],
			'content' => $res['content']
		);
	}

	return array(
		"errno" => 0,
		"data" => $flow
	);
}

//�ۺ�����ȵ�������
function myrepair_addSatisfactionSurvey(){
	$uid = IUser::getLoginUid();
	$whId = IUser::getSiteId();
	if(empty($uid)){
		Logger::err("is not uid" . IUser::$errCode . ', msg:' . IUser::$errMsg);
		return array('errno' => 500);
	}

	$data_info = array();

	if(empty($_POST['request_sysno'])){
		return array('errno' => 1);
	}
	$RequestSysNo = intval($_POST['request_sysno']);

	if(empty($_POST['order_id'])){
		return array('errno' => 2);
	}
	$OrderId = intval($_POST['order_id']);

	if(empty($_POST['answer1'])){
		return array('errno' => 3);
	}
	$answer1 = intval($_POST['answer1']);

	if(empty($_POST['answer2'])){
		return array('errno' => 4);
	}
	$answer2 = intval($_POST['answer2']);

	if(empty($_POST['answer3'])){
		return array('errno' => 5);
	}
	$answer3 = intval($_POST['answer3']);

	if(empty($_POST['make_better'])){
		return array('errno' => 6);
	}
	$MakeBetter = ToolUtil::transXSSContent($_POST['make_better']);

	$Suggestions = ToolUtil::transXSSContent($_POST['suggestions']);

	$has_survey = ISatisfactionSurveyTTC::get($RequestSysNo, array(), array('SysNo', 'RequestSysNo'));
	if(is_array($has_survey) && count($has_survey) >= 1){//����ύ���˼�¼
		return array('errno' => 7);
	}

	$answers = array(
		$answer1,
		$answer2,
		$answer3,
		$MakeBetter,
		$Suggestions,
	);

	$questions = array(
		'���Ա��εĴ������������',
		'���Ա����ۺ����̬��������',
		'���Ա����ۺ����Ĵ���Ч��������',
		'�����ñ����ۺ������Ҫ��һ�������ĵط��ǣ�',
		'����뽨��',
	);

	for($i = 0; $i < count($answers); $i++){
		$post_data = array(
			'RequestSysNo' => $RequestSysNo,
			'ModelSysNo' => 1,//Ŀǰ��д��. 1:�����˻���ģ��
			'OrderId' => $OrderId,
			'OrderWhid' => 1,//������Դ��վ
			'Question' => $questions[$i],
			'Answer' => ($i<3) ? $answers[$i] : 0,
			'MakeBetter' => ($i==3) ? $MakeBetter : '',
			'Suggestions' => ($i==4) ? $Suggestions : '',
			'Remark' => '',
			'Status' => 0,
			'Whid' => $whId,
		);

		$result = ISatisfactionSurvey::addSatisfactionSurvey($uid, $post_data);
		if(false === $result){
			Logger::err("ISatisfactionSurvey::addSatisfactionSurvey failed, errCode:" . ISatisfactionSurvey::$errCode . ', errMsg:' . ISatisfactionSurvey::$errMsg . ', uid:' . $uid . ', whid:' . $whId . ', data_info:' . var_export($post_data, true));
			if($i <= 0){
				return array('errno' => 1001);
			}else{
				return array('errno' => 0);
				//return array('errno' => 100 . $i);
			}
		}
	}

	return array('errno' => 0);
}











//�ۺ��б�
function myrepair_getrmalist(){
	global $uid;
	$whId = IUser::getSiteId();
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0);
	if($currentPage < 1) $currentPage = 1;
	$pageSize = 10;
	$rmaList = IRMANew::getRmaApplies($uid, $whId, $pageSize, ($currentPage-1));
	if($rmaList === false){
		Logger::err( "IRMANew::getRmaApplies failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ', uid:' . $uid . ', whid:' . $whId);
		return array('errno' => 1, 'msg' => 'ϵͳ��æ�����Ժ����ԣ�');
	}
	
	$ret_total	= 0;
	$ret_page	= $currentPage;
	$ret_pages	= 0;
	$ret_list	= array();

	if(!empty($rmaList['data']) && count($rmaList['data']) >0){
		$total = ceil($rmaList['total'] / $pageSize);
		$ret_total = $total;
		foreach($rmaList['data'] as &$rma){
			//��Ʒ��Ϣ
			$vars = array();
			if(empty($rma['Iproducts'])){ //exception
				continue;
			}else {
				$count = 0;
				$cacl_total = count($rma['Iproducts']);

				//��Ʒ��Ϣ
				foreach($rma['Iproducts'] as $rmaProduct) {
					$params = array();
					$params['php_soid'] = $rma['SOID'];//������
					$strtotime_RequestDate = strtotime($rma['RequestDate']);
					//������Ϣ
					$params['php_request_id'] = $rma['RequestSysNo'];
					$params['php_request_sysno'] = $rma['SysNo'];
					$params['php_request_time'] = (empty($rma['RequestDate']) || ($strtotime_RequestDate <0)) ? '' : $rma['RequestDate'];
					$params['php_source'] = ($rma['Source'] == 1) ? '�û��Խ�' : '�ͷ�����';

					if ($cacl_total == 1) {
						$params['php_rowspan'] = '';
						$params['bor_r'] = '';
						$params['bor_l'] = '';
					}
					else {
						$params['php_rowspan'] = " rowspan='{$cacl_total}'";
						$params['bor_r'] = 'bor_r';
						$params['bor_l'] = 'bor_l';
					}

					$vars['first_td_cell'] = (0 == $count) ? _getFirstTdCell($params) : ''; //first

					//��Ʒ��Ϣ
					$pid =  $rmaProduct['I_ProductSysNo'];
					$pinfo = IProduct::getBaseInfo($pid, $whId, true);
					if($pinfo === false){
						$vars['product_id'] = '';
						$vars['product_title'] = '';
						$vars['php_pic'] = '';
					}else if(empty($pinfo) || count($pinfo) <0){
						$vars['product_id'] = '';
						$vars['product_title'] = '';
						$vars['php_pic'] = '';
					}else{
						$product_title = strip_tags($pinfo['name']);
						$product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);
						$php_pic = '<img src="' . IProduct::getPic($pinfo['product_char_id'], 'small') . '" alt="'.$product_title.'" title="'.$product_title.'">';
						$vars['product_id'] = $pid;
						$vars['product_title'] = $product_title;
						$vars['php_pic'] = $php_pic;
					}

					//����ģ��
					$params['product_id'] = $pid;//��Ʒid
					$params['regist_sysno'] = $rmaProduct['I_RegistSysNo'];//����������
					$params['status'] = $rma['Status'];//���뵥״̬
					$vars['status'] = $rma['Status'];//���뵥״̬
					$vars['last_td_cell'] = (0 == $count) ? _getLastTdCell($params, $rma['Nnotes'], $strtotime_RequestDate) : ''; //last
					$count++;

					$vars['php_request_sysno'] = $rma['SysNo'];
					$vars['php_regist_id'] = $rmaProduct['I_RegistSysNo'];

					//״ֵ̬
					$vars['php_status_desc'] = myrepair_statusdesclast($rma['SysNo'], $rmaProduct['I_RegistSysNo'], $whId, $rma['RequestDate'],  $rma['Status']);

					//���뵥����ʱ��  ��2012-11-21 19:00:00 (1353495600) Ϊ���ն���
					$strtotime_RequestDate = $strtotime_RequestDate;
					$request_date = ( $strtotime_RequestDate <= 1353495600 ) ? '1' : '2';
					$vars['php_request_createdate'] = $request_date;
					$php_regist_id = $rmaProduct['I_RegistSysNo'];
					$php_request_sysno = $rma['SysNo'];

					//��������
					$vars['link_track'] = ( ($strtotime_RequestDate <= 1353495600) && (in_array($rma['Status'], array(-1, 4))) ) ? "" : '<a class="link_track" href="javascript:;" req_sysno="'. $php_request_sysno . '" regist_id="'. $php_regist_id . '" rdate="'. $request_date . '">����<b class="arrow_piont"></b></a>';
					
					$ret_list[] = $vars;
				}
			}
		}
	}
	
	return array(
			'errno' => 0,
			'data'	=> array(
				'total'		=> $ret_total,
				'page'		=> $ret_page,
				'pages'		=> $ret_pages,
				'list'		=> $ret_list
			)
	);
}

function myrepair_getorderlist(){
	global $uid;
	$monthago	= intval($_REQUEST['monthago']);
	$page		= intval($_REQUEST['page']);
	$list		= getOrderDetailList($uid, $monthago, $page, 10);

	if(count($list['orders']) > 0){
		foreach($list['orders'] AS $n => &$order){
			$list['orders'][$n] = _getorderavaliableitembyapi($order);
		}
	}
	return $list;
}

function _getorderavaliableitembyapi($order){
	global $uid;
	$order_item_repairing = array();
	$data = IRmaApi::getPostsaleNumByOrderId(substr($order['order_char_id'], -8));
	if($data['return_code'] == 0){
		if($data['data']['entry']){
			foreach($data['data']['entry'] AS $record){
				foreach($order['items'] AS &$item){
					if($item['product_id'] == $record['ProductSysNo']){
						$order_item_repairing[$item['product_id']] = $record['RMANum'];
					}
				}
			}
		}
	}

	$canapplycountall = 0;
	foreach($order['items'] AS &$item){
		//���������ѳ��� ��Ӫ��ݳ���12Сʱ ����48Сʱout_time
		$item['exceptionmsg'] = '';
		if($order['status'] == 4 || $order['status'] == "�ѳ���"){
			$item['canapplycount'] = $item['buy_num'];
		}else{
			$item['canapplycount'] = 0;
			$item['exceptionmsg'] = '��Ʒ��δ����';
		}
		if($order['shipping_type'] == 1){
			if($order['out_time'] + 12 * 3600 > time()){
				$item['canapplycount'] = 0;
				$item['exceptionmsg'] = '��Ѹ��ݳ���12Сʱ���ܷ����ۺ�';
			}
		}else{
			if($order['out_time'] + 48 * 3600 > time()){
				$item['canapplycount'] = 0;
				$item['exceptionmsg'] = '����Ѹ��ݳ���48Сʱ���ܷ����ۺ�';
			}
		}
		if(isset($order_item_repairing[$item['product_id']]) && $order_item_repairing[$item['product_id']] > 0){
			$item['canapplycount'] -= $order_item_repairing[$item['product_id']];
			if($item['canapplycount'] <= 0){
				$item['exceptionmsg'] = '����Ʒ�����ۺ�';
			}
		}
		if($item['canapplycount'] < 0){
			$item['canapplycount'] = 0;
		}
		$canapplycountall += $item['canapplycount'];
	}
	
	$order['canapply'] = $canapplycountall > 0 ? true : false;
	
	return $order;
}

function _getorderavaliableitem($order){
	global $uid;
	$order_item_repairing = array();
	//�ۺ�����¼ �����ж���
	$data = IRMARequestTTC::get($uid, array('SOSysNo' => $order['order_id']), array('CustomerSysNo', 'RequestSysNo', 'SOSysNo', 'SOID','RequestFormType','SysNo','Status'));

	if(false === $data){
		Logger::err("IRMARequestTTC get failed" . " errMsg: " .IRMARequestTTC::$errMsg ." errCode: " .IRMARequestTTC::$errCode);
		return false;
	}
	if(!empty($data)){
		foreach($data AS $val){
			$data_item = IRMARequestItemTTC::get($val['SysNo'], array('RequestFormType' => 2), array('SysNo', 'RegistSysNo', 'ProductSysNo', 'RequestNum', 'Status'));
			if(false === $data_item){
				Logger::err("IRMARequestItemTTC get failed" . " errMsg: " .IRMARequestItemTTC::$errMsg ." errCode: " .IRMARequestItemTTC::$errCode);
				return false;
			}else{
				foreach($data_item AS $item_val){
					$status = getFlowLogLastStatus($item_val['RequestSysNo'], $item_val['RegistSysNo']);
					if(!isset($order_item_repairing[$item_val['ProductSysNo']])){
						$order_item_repairing[$item_val['ProductSysNo']] = 0;
					}
					
					if($status == 10 ||
						$status == 0 ||
						$status == 30 ||
						$status == 50 ||
						$status == 60 ||
						$status == 70 ||
						$status == 80 ||
						$status == 90 ||
						$status == 100 ||
						$status == 140 ||
						$status == 160 ||
						$status == 170 ||
						$status == 180 ||
						$status == 190 ||
						$status == 200 ||
						$status == 210 ||
						$status == 230 ||
						$status == 250){	//���ۺ��е���Ʒ
						$order_item_repairing[$item_val['ProductSysNo']] += $item_val['RequestNum'];
					}
				}
			}
		}
	}
	$canapplycountall = 0;
	foreach($order['items'] AS &$item){
		//���������ѳ��� ��Ӫ��ݳ���12Сʱ ����48Сʱout_time
		$item['exceptionmsg'] = '';
		if($order['status'] == 4 || $order['status'] == "�ѳ���"){
			$item['canapplycount'] = $item['buy_num'];
		}else{
			$item['canapplycount'] = 0;
			$item['exceptionmsg'] = '��Ʒδ����';
		}
		if($order['shipping_type'] == 1){
			if($order['out_time'] + 12 * 3600 > time()){
				$item['canapplycount'] = 0;
				$item['exceptionmsg'] = '��Ѹ��ݳ���12Сʱ���ܷ����ۺ�';
			}
		}else{
			if($order['out_time'] + 48 * 3600 > time()){
				$item['canapplycount'] = 0;
				$item['exceptionmsg'] = '����Ѹ��ݳ���48Сʱ���ܷ����ۺ�';
			}
		}
		if(isset($order_item_repairing[$item['product_id']]) && $order_item_repairing[$item['product_id']] > 0){
			$item['canapplycount'] -= $order_item_repairing[$item['product_id']];
			if($item['canapplycount'] <= 0){
				$item['exceptionmsg'] = '����Ʒ�ۺ���';
			}
		}
		if($item['canapplycount'] < 0){
			$item['canapplycount'] = 0;
		}
		$canapplycountall += $item['canapplycount'];
	}
	
	$order['canapply'] = $canapplycountall > 0 ? true : false;
	
	return $order;
}


function getFlowLogLastStatus($requestsysno, $registsysno){
	$data = IRMACusLogTTC::get($requestsysno);
	if(false === $data){
		return 0;
	}
	if(empty($data)){
		return 0;
	}
	//�޳�������Ҫ���
	foreach($data as $key => &$value){
		if(($value['RegisterSysNo'] != -999999) && ($value['RegisterSysNo'] != $registsysno) ){
			//unset($data[$key]);
		}
	}

	if(empty($data)){
		return 0;
	}else{
		foreach($data as $key => $value){
			$status = $value['LogType'];
		}
		return $status;
	}
	return 0;
}

function getOrderDetailList($uid, $monthAgo = 1, $page = 0, $pageSize = 10){
	global $_OrderState, $_PAY_MODE, $_OrderDelayStock, $_OrderProcessId, $_VP_MobileOrderState;
	$page -= 1;
	if($page < 0){
		$page = 0;
	}
	if($monthAgo === 2){	//һ������ǰ
		$list = IOrder::getUserOrdersOneMonthAgo($uid, $page, $pageSize);
	}else{
		$list = IOrder::getUserOrdersInOneMonth($uid, $page, $pageSize);
	}
		
	if(count($list['orders']) > 0){
		foreach($list['orders'] AS $n => $row){
			//����״̬
			$order_detail = IOrder::getOneOrderDetail($uid, $row['order_char_id']);
			//var_dump($order_detail);
			if ($order_detail === false){
				continue; //TODO ��ȡ������¼ʧ��
			}
			$_order_state_str = "";
			if ( in_array($order_detail['status'], array($_OrderState['Origin']['value'], $_OrderState['WaitingPay']['value'], $_OrderState['WaitingManagerAudit']['value'], ))
				&& $_PAY_MODE[$order_detail['hw_id']][$order_detail['pay_type']]['IsNet'] == 1
				&& $order_detail['isPayed'] == 1) { //����֧�� && ״̬Ϊ����˻��֧�� && �Ѹ�����

				$_order_state_str = '��֧����������';
			}
			else {
				foreach ($_OrderState as $key => $arr) {
					if ($order_detail['status'] == $arr['value']) {
						$_order_state_str = $arr['siteName'];
						break;
					}
				}
			}
			$list['orders'][$n]['detail'] = $order_detail;
			$list['orders'][$n]['status_int'] = $list['orders'][$n]['status'];
			$list['orders'][$n]['status'] = $_order_state_str;
		}
	}
	return $list;
}

//�����Ѹ��ݺ�Բͨ����Ƿ�������ռ�
function _checkYTOAnd51Buy($areaId){
	$msDB = ToolUtil::getMSDBObj('DMSDB');
	if(!$msDB){
		Logger::err('DMS query fail, TargetAreaSysNo='.$areaId);
		return false;
	}
	
	$sql = 'SELECT * FROM dbo.Base_Area_ShipType a WHERE a.TargetAreaSysNo='.$areaId;
	$ret = $msDB->getRows($sql);
	
	if($ret === false){
		Logger::err('DMS query fail, TargetAreaSysNo='.$areaId);
		return false;
	}
	$data = array(
			'icson'			=> false,
			'yto'			=> false,
			'icson_times'	=> 0,
			'yto_times'		=> 0
	);
	if(count($ret) > 0){
		//��Ѹ���1 Բͨ7
		foreach($ret AS $row){
			if($row['ShipTypeSysNo'] === 1){
				$data['icson'] = true;
				$data['icson_times'] = $row['DeliveryTimes'];
			}elseif($row['ShipTypeSysNo'] === 7){
				$data['yto'] = true;
				$data['yto_times'] = $row['DeliveryTimes'];
			}
		}
	}
	
	return $data;
}

function myrepair_test(){
	global $uid;
	$order = array();
	$order = IOrder::getOneOrderDetail($uid, $_GET['oid']);
	$data = IRMARequestTTC::get($uid, array('SOSysNo' => $order['order_id']), array('CustomerSysNo', 'RequestSysNo', 'SOSysNo', 'SOID','RequestFormType','SysNo','Status'));
	if(false === $data){
		var_dump("IRMARequestTTC get failed" . " errMsg: " .IRMARequestTTC::$errMsg ." errCode: " .IRMARequestTTC::$errCode);
		return false;
	}
	echo "\r\n\r\n\r\n";
	if(!empty($data)){
		foreach($data AS $val){
			$data_item = IRMARequestItemTTC::get($val['SysNo'], array('RequestFormType'=>2), array('SysNo', 'RequestSysNo', 'RegistSysNo', 'ProductSysNo', 'RequestNum', 'Status'));
			var_dump($data_item);
			foreach($data_item AS $item_val){
				$status = getFlowLogLastStatus($item_val['RequestSysNo'], $item_val['RegistSysNo']);
				var_dump($status);
			}
		}
	}
	
	return 0;
}

function myrepair_test2(){
	//return _checkYTOAnd51Buy($_GET['aid']);
	
	
	//return;
	global $uid;
	/*
	$ret = IOrdersTTC::get($uid, array('order_char_id' => 1030131961));
	var_dump($ret);
	echo '<hr>';
	echo IOrdersTTC::$errCode;
	echo '<hr>';
	echo IOrdersTTC::$errMsg;
	$ret = IOrdersTTC::update(array('uid' => $uid, 'status' => 4), array('order_char_id' => 1030131961));
	echo '<hr>';
	echo IOrdersTTC::$errCode;
	echo '<hr>';
	echo IOrdersTTC::$errMsg;
	echo '<hr>';
	return $ret;
	*/
	
	$db_tab_index = ToolUtil::getMSDBTableIndex($uid, 'ICSON_ORDER_CORE');
	$orderDb = ToolUtil::getMSDBObj('ICSON_ORDER_CORE', $db_tab_index['db']);
	
	var_dump($orderDb);
	
	$sql = "update t_orders_{$db_tab_index['table']} set status = 1 where uid=$uid and order_char_id=1030131962;";
	//$sql = "update t_orders_{$db_tab_index['table']} set status = 4, out_time = ". (time() - 4*86400) ." where uid=$uid and order_char_id=1030132417;";
	
	//$sql = "delete from t_orders_{$db_tab_index['table']} where uid=$uid AND order_char_id !=1030132417";
	return $orderDb->execSql($sql);
}

function myrepair_test3(){
	
	$msDB = ToolUtil::getMSDBObj('DMSDB');
	$sql = 'SELECT b.ShipTypeName,b.SysNo FROM dbo.Base_Area_ShipType a INNER JOIN dbo.Base_ShipType b ON a.ShipTypeSysNo=b.SysNo WHERE b.IsOnlineShow=1 and a.SourceAreaSysNo=131';
	$sql = 'select * from dbo.Base_Area_ShipType a where a.TargetAreaSysNo=131';
	//$sql = 'select * from dbo.Base_ShipType a where a.SourceAreaSysNo=131';
	//$sql = 'select * from dbo.Base_ShipType';
	$ret = $msDB->getRows($sql);
	
	return $ret;
}

function myrepair_test4(){
	
	$ret = IQQSudi::getLogisUrl(7294449315, LOGIS_COMPANY_ID_YTO);
	
	return $ret;
}