<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'lib/Dirty.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IAlipayAuthorize.php');
require_once(PHPLIB_ROOT . 'api/IQQCBAddress.php');
require_once(PHPLIB_ROOT . 'api/ISHCarAuthorize.class.php');

require_once(PHPLIB_ROOT . 'api/ICPS.php');
require_once(PHPLIB_ROOT . 'inc/CPSConfig.inc.php');
require_once(PHPLIB_ROOT . 'api/appplatform/user_api.php');

Logger::init();

//��ȡվ��id
function user_getwhid() {
	$whId = IUser::getSiteId();
	$prid = IUser::getProvId();
	return array('errno' => 0, 'data' => $whId, 'prid' => $prid);
}

//��ȡ�û�ʵ��ʡ��
function user_getrealprid() {
	global $_ProvinceToWhid,$PROVINCEID_MAP_DEFAULT_PRID;
	$provId = 2621;
	$ip = ToolUtil::getClientIP();
	$ipInfo = NetUtil::getCityByIp($ip);
	$prov = $ipInfo['prov'];
	if (!empty($prov)) {
		global $_Province2city;
		foreach ($_Province2city as $key => $kc) {
			if ($prov == $kc) {
				$provId = $key;
				break;
			}
		}
	}

	return array('errno' => 0, 'prid' => $provId);
}

function user_getwhidforip() {
	if (empty($_GET['ip'])) {
		echo('1,1');
		exit;
	}

	$siteId = IUser::getSiteIdByIp($_GET['ip']);
	echo(''.$siteId);
	exit;
}

function user_profile() {
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	$user = IUser::getUserInfo($uid);
	if ($user === false) {
		Logger::err("IUser::getUserInfo failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return array('errno' => 1);
	}

	return array(
		'errno'	=> 0,
		'data'	=> $user
	);
}

function user_loginstatusfromapp() {
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	return array(
		'errno'	=> 0,
	);
}

function user_accountexists() {
	$account = $_POST['account'];
	if (empty($account)) {
		return array('errno' => 1);
	}

	$hasDirty = Dirty::hasDirty($account);
	if ($hasDirty !== false) {
		return array(
			'errno' => 3,
			'data' => $hasDirty
		);
	}

	// fix bug �����˽ӿڣ�����ȡϵͳ�û���
	return array(
		'errno'	=> 0,
		'data'	=> 0,
	);

	$exists = IUser::checkIcsonAccountExist($account);
	if ($exists === false) {
		Logger::err("IUser::checkIcsonAccountExist failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return array('errno' => 2);
	}

	if (true === empty($exists['exist']) &&  (0 === stripos($account, QQ_ACCOUNT_PRE) || 0 === stripos($account, ALIPAY_ACCOUNT_PRE))) {
		$exists['exist'] = true;
	}

	return array(
		'errno'	=> 0,
		'data'	=> empty($exists['exist']) ? 0 : 1,
	);
}

function user_emailexists() {
	$email = $_POST['email'];
	if (empty($email)) {
		return array('errno' => 1);
	}

	$exists = IUser::checkEmailExist($email);
	if ($exists === false) {
		Logger::err("IUser::checkEmailExist failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return array('errno' => 2);
	}

	return array(
		'errno'	=> 0,
		'data'	=> empty($exists['exist']) ? 0 : 1,
	);
}

function user_register() {
	return;//�����Ѹע��ӿ�
	$clientIp = ToolUtil::getClientIP();

	if(!ToolUtil::is_mobile()) {

		if(!isset($_POST['vcode'])){
			return array('errno' => 10001);
		}

		if(!isset($_COOKIE['verifysession'])) {
			return array('errno' => 10002);
		}

		global $_IP_CFG;
		for($i = 0; $i < 5; $i++) {
			$ret = check_verify_code(
				VERIFY_CODE_APPID,
				$_IP_CFG['verify_code']['check_server'][0]['IP'],
				$_IP_CFG['verify_code']['check_server'][0]['PORT'],
				$_IP_CFG['verify_code']['check_server'][1]['IP'],
				$_IP_CFG['verify_code']['check_server'][1]['PORT'],
				$clientIp,
				$_POST['vcode'],
				$_COOKIE['verifysession']
			);
			if($ret === true) {
				break;
			} else if($ret === false) {
				return array('errno' => 10003);
			}
		}
		if($i == 5) {
			// ��֤�������ͨѶ���󣬺�����֤��
			Logger::err("������֤�������ʧ�ܣ�[ error : $ret ]");
			return array('errno' => 10004);
		}
	}

	if (empty($_POST['account'])) {
		return array('errno' => 1);
	}

	$account = $_POST['account'];
	$hasDirty = Dirty::hasDirty($account);
	if ($hasDirty !== false) {
		return array('errno' => 444);
	}

	if (empty($_POST['password'])) {
		return array('errno' => 3);
	}

	if (0 === stripos($account, QQ_ACCOUNT_PRE ) || 0 === stripos($account, ALIPAY_ACCOUNT_PRE)) {
		return array('errno' => 444);
	}

	$password = $_POST['password'];

	//modify by allenzhou 2012-02-13 �û�ע���������
	if (empty($_POST['email'])) {
		return array('errno' => 4);
	}

	$email = $_POST['email'];

	$regSrc = empty($_COOKIE['us']) ? '' : $_COOKIE['us'];
	$userData = array(
				'email' => $email,
				'regIP' => $clientIp,
				'warehouseId' => IUser::getSiteId(),
				'source' => $regSrc
			);
	$register = IUser::register($account, $password, $userData);
	if ($register === false) {
		Logger::err("IUser::register failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return array('errno' => IUser::$errCode);
	}
	//�ϱ�ע��
	_registerReport(2, $register, $account);
	_registerReport(6, $register, $account);
	//������ͨע�ᣬ��Ҫ���õ����ݽӿ�
	//UserWg::ImportCopartnerUserInfo($register, $account, 1);

	// �Զ���¼
	if(!ToolUtil::is_mobile()) {
		/*for($i = 0; $i < 3; $i++) {
			$session = IUser::login($account, $password, $clientIp, 1);
			if($session !== false) {
				break;
			} else {
				sleep(1);
			}
		}*/
		$session = IUser::login($account, $password, $clientIp, 1);
		if($session === false){
			Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
			return array('errno' => empty(IUser::$errCode) ? 6001 : IUser::$errCode);
		}

		$user = IUser::getUserInfo($session['uid']);
		if($user === false){
			Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
			return array('errno' => empty(IUser::$errCode) ? 6001 : IUser::$errCode);
		}

		setrawcookie("uid", $session['uid'], 0, '/', '.51buy.com');
		setrawcookie("skey", $session['skey'], 0, '/', '.51buy.com');
		setrawcookie("BOUND_QQACCT", isset($user['cqq']) ? $user['cqq'] : '0', 0, '/', '.51buy.com');

		return array('errno' => 0);
	} else {
		return array( 'errno' => 0 );
	}

}
function page_user_loginqq() {
	$redirectUrl = 'http://www.51buy.com';
	if (!empty($_GET['url']) && preg_match("/^http:\/\/([^\.]+\.|)(51buy|icson)\.com($|\/)/i", $_GET['url'])) {
		$redirectUrl = $_GET['url'];
	}
	$vKey = isset( $_GET['vkey'] ) ?  $_GET['vkey'] : '';
	$time = isset($_GET['time']) ? $_GET['time'] : '';
	//$nickName = isset($_GET['nickname']) ? $_GET['nickname'] : '';
	$uid = isset($_GET['uid']) ? $_GET['uid'] : '';
	$message = '��¼ʧ��';

	if (empty( $vKey ) || empty( $time ) || !isset($_GET['nickname']) || empty( $uid ) || md5($uid . $time . $_GET['nickname'] . QQ_VALIDATE_KEY) != $vKey) {
		TemplateHelper::outMessage( $message );
		return false;
	}
	else{
		$openID = isset( $_GET['openID'] ) ?  $_GET['openID'] : '';
		if (empty($openID)) {
			TemplateHelper::outMessage( $message );
			return false;
		}

		if(_loginqq_autouser($openID, $uid, iconv('UTF-8', 'GBK//IGNORE', $_GET['nickname'])) === false) return;

		ToolUtil::redirect($redirectUrl);
	}
}

function page_user_ptloginqq() {
	$redirectUrl = 'http://www.51buy.com';
	if (!empty($_GET['url']) && preg_match("/^http:\/\/([^\.]+\.|)(51buy|icson)\.com($|\/)/i", $_GET['url'])) {
		$redirectUrl = $_GET['url'];
	}
	$vKey = isset( $_GET['vkey'] ) ?  $_GET['vkey'] : '';
	$time = isset($_GET['time']) ? $_GET['time'] : '';

	$message = '��¼ʧ��';

	$qq = isset( $_GET['uin'] ) ?  $_GET['uin'] : '';

	if (empty($qq) || empty( $vKey ) || empty( $time ) || !isset($_GET['nickname']) || md5($qq . $time . QQ_VALIDATE_KEY) != $vKey) {
		TemplateHelper::outMessage( $message );
		return false;
	}
	else{

		if (empty($qq) || empty($_GET['ptskey'])) {
			TemplateHelper::outMessage( $message );
			return false;
		}

		//��ֲcookie
		setrawcookie("pt2gguin", $_GET['pt2gguin'], 0, '/', '.51buy.com');
		setrawcookie("uin", $_GET['uin'], time() + 3600*24*300, '/', '.51buy.com');
		setrawcookie("ptskey", $_GET['ptskey'], 0, '/', '.51buy.com');

		if(_ptloginqq_autouser($qq, $qq, $_GET['nickname'])) return;

		ToolUtil::redirect($redirectUrl);
	}
}

function _ptloginqq_autouser($qq, $password, $nickname = ''){
	$message = '��¼ʧ��';
	global $_IP_CFG,$_AccountType;
	if (is_array($_IP_CFG['QQ_OPENIDS'])) {
		$ip_key = array_rand($_IP_CFG['QQ_OPENIDS'], 1);
		$ip = $_IP_CFG['QQ_OPENIDS'][$ip_key];
	} else {
		$ip = $_IP_CFG['QQ_OPENIDS'];
	}

	$url = "http://".$ip.":8080/openid/decopenid.php?func=getopenidbyuin&uin=" . $qq;
    $qqinfo = NetUtil::cURLHTTPGet($url);
    $ret = json_decode($qqinfo);
    $openID = strtoupper($ret->openid);

    if (empty($openID) || $openID == 'failed' || strlen($openID) != 32) {
    	Logger::err("ptlogin get openid error," . $qq . "," . $openID);
		TemplateHelper::outMessage( $message );
		return false;
    }
    $clientIp = ToolUtil::getClientIP();
	$account = QQ_ACCOUNT_PRE . '_' . $openID; // ��ID�м�����һ���»���
// 	$exists = IUser::checkIcsonAccountExist($account);
// 	if ($exists === false) {
// 		Logger::err("user_loginqq IUser::checkIcsonAccountExist failed-" . IUser::$errCode . '-' . IUser::$errMsg);
// 		TemplateHelper::outMessage( $message );
// 		return false;
// 	}
	
	$userInfo = UserWg::GetUserInfoByQQorAccount($_AccountType['qq'], $account, $qq);
	if ($userInfo === false) {
		Logger::err("user_loginqq UserWg::GetUserInfoByQQorAccount failed-" . UserWg::$errCode . '-' . UserWg::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}
	
// 	if ($exists['exist'] == 0) {
	if(!empty($userInfo)){

        // ͨ��QQ���뷴����Ѹ�˺Ų���½��Ѷ�˺�
        /*
        if ($item = IUsersQqMapTTC::get($qq)) {
            if ($icsonAccount = IUsersTTC::get($item[0]['uid'])) {
                // do nothing
                $icsonId = $icsonAccount[0]['icsonid'];
                setrawcookie("__BINDQQACCOUNT", 'true', 0, '/', '.51buy.com');
            }
        }
        */
		$isNew = false;
		if( stripos($userInfo[0]['icsonid'], QQ_ACCOUNT_PRE) !== 0){
			$icsonId = $userInfo[0]['icsonid'];
			setrawcookie("__BINDQQACCOUNT", 'true', 0, '/', '.51buy.com');
		}
		
// 		$isNew = true;
// 		$item = IUsersQqMapTTC::get($qq);
// 		if(false===$item){
// 			Logger::err("Check IUsersQqMapTTC  fail. qq: $qq, " . IUsersQqMapTTC::$errCode . ": " . IUsersQqMapTTC::$errMsg);
// 			TemplateHelper::outMessage($message);
// 			return false;
// 		}
// 		if(count($item)==1){
// 			$icsonAccount = IUsersTTC::get($item[0]['uid']);
// 			if(false===$icsonAccount){
// 				Logger::err("Check IUsersTTC fail. uid: $item[0]['uid']");
// 				TemplateHelper::outMessage($message);
// 				return false;
// 			}
// 			if(count($icsonAccount)==1){
// 				$isNew = false;
// 				$icsonId = $icsonAccount[0]['icsonid'];
// 				setrawcookie("__BINDQQACCOUNT", 'true', 0, '/', '.51buy.com');
// 			}
// 		}
	}else{
		$isNew = true;
	}
	
        // ���û�а󶨵���Ѹ�˺���ִ��ע���߼�
        if($isNew){
        //if (!isset($icsonId)) {
        	//�ռ��º���Դ
        	$uin = $_GET['uin'];
        	$url = $_GET['url'];
//         	$clientIp = ToolUtil::getClientIP();
        	$time = time();
        	$referer = $_SERVER['HTTP_REFERER'];
        	$msg = "$uin\t$account\t$clientIp\t$time\t$url\t$referer";
        	@$addr = explode(':', configcenter4_get_serv('report_register', 0, 0));
        	@$ip = $addr[0];
        	@$port = $addr[1];
        	$ret = NetUtil::udpCmd($ip, $port, $msg, false);
        	if($ret === false){
        		Logger::err('udpCmd failed, code=' . NetUtil::$errCode . 'msg: ' . NetUtil::$errMsg);
        	}
			
        	$redirectUrl = $_SERVER["QUERY_STRING"];
        	$redirectUrl = str_replace('mod=user', 'mod=registerAndLogin', $redirectUrl);
        	ToolUtil::redirect('http://base.51buy.com/index.php?'.$redirectUrl.'&account='.$account);
//         	header('Location:http://base.51buy.com/index.php?'.$redirectUrl);
        	exit();
			$email = '';

			$regSrc = empty($_COOKIE['us']) ? '' : $_COOKIE['us'];
					$userData = array(
					'email' => $email,
					'regIP' => $clientIp,
					'warehouseId' => IUser::getSiteId(),
					'source' => $regSrc
				);
			$register = IUser::register($account, "123456".$password, $userData, $qq);
			if ($register === false) {
				if(IUser::$errCode != 10303){ // �ظ�key���ɳɹ�
					Logger::err("user_loginqq IUser::register failed-" . IUser::$errCode . '-' . IUser::$errMsg);
					TemplateHelper::outMessage( $message );
					return false;
				}
			}
			// ��Ϣһ�� ��������login�ᱨ��
			// ��Ҫ��һ���Ż������������������
// 			sleep(1);
			//���õ����ݽӿ�,��Ѹid����Ѹ����
			//UserWg::ImportCopartnerUserInfo($register, $qq, 3);				
        }

	$ptskey = $_GET['ptskey'];
	//$session = isset($icsonId) ? IUser::login($icsonId, $password, $clientIp, 1, 0, false, $qq, $ptskey) : IUser::login($account, $password, $clientIp, 1, 3, true, $qq, $ptskey);
	$session = IUser::login($account, $password, $clientIp, 1, 3, true, $qq, $ptskey);
	if ($session === false) {
		Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}
	//�ϱ���¼
	_registerReport(4, $session['uid'], $account);

	setrawcookie("QQACCT", $openID, 0, '/', '.51buy.com');
	setrawcookie("new_u", false, 1, '/', '.51buy.com');
	$user = IUser::getUserInfo($session['uid']);
	if ($user === false) {
		Logger::err("IUser::getUserInfo failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}
	else if (isset($user['exp_point'])  && $user['exp_point'] <= 0) { //�������û�cookie
		setrawcookie("new_u", '1', 0, '/', '.51buy.com');
	}

	setrawcookie("uid", $session['uid'], 0, '/', '.51buy.com');
	setrawcookie("skey", $session['skey'], 0, '/', '.51buy.com');
	setrawcookie("yx_uid", $session['uid'], time() + 3600*24*600, '/', '.51buy.com');
	setrawcookie("yx_uin", $qq, time() + 3600*24*600, '/', '.51buy.com');
	//������˫д��ʱ�����wg_skey
	if(!empty($session['wg_skey'])){
		setrawcookie("wg_skey", $session['wg_skey'], 0, '/', '.51buy.com');
	}
	

	setrawcookie("qq_nick", $session['uid'] . '|' . ToolUtil::escape($nickname), 0, '/', '51buy.com');

	//���QQ tips��������������֤��Ϣ
	if (isset($_GET['key'])) {
		if ((substr(md5($openID . "icson@qq"), 0 , 6) != $_GET['key'])) {
			TemplateHelper::outMessage( array("�Բ����������ϲμӴ˻������", '<a href="http://www.51buy.com">�ص���Ѹ��ҳ</a>') );
			return false;
		}
		else {
			setrawcookie("edm_key", $_GET['key'], 0, '/', '.51buy.com');
		}
	}
}

function page_user_loginqqauthcode() {
	// IE6�������cgi�Ტ���������� ������js��ת
	$_GET['act'] = 'loginqqauthcodeact';
	$redirectUrl = 'http://base.51buy.com/index.php?' . http_build_query($_GET);
	ToolUtil::noCacheHeader();
	echo('<script type="text/javascript">location.replace("' . $redirectUrl . '");</script><noscript>��������������֧�ֽű�������<a href="' . $redirectUrl . '">����</a></noscript>');
	exit;
}

//�����ѯ���� ��ȡQQ_TOKEN�ӿ�
function getTokenIP(){
	global $_IP_CFG;
	if(is_array($_IP_CFG)){
		$ip_key = array_rand($_IP_CFG['QQ_TOKEN'], 1);
		$ip = $_IP_CFG['QQ_TOKEN'][$ip_key];
		return $ip;
	}else{
		return $_IP_CFG['QQ_TOKEN'];
	}
}

/*֮ǰ�ĵ�¼�ӿڣ�����ǰ����ȷ��û����ʹ���ˣ������������ Start*/
function page_user_loginqqauthcodeact() {
	$t = microtime(true);
	$redirectUrl = 'http://www.51buy.com';
	if (!empty($_GET['url']) && preg_match("/^http:\/\/([^\.]+\.|)(51buy|icson)\.com($|\/)/i", $_GET['url'])) {
		$redirectUrl = $_GET['url'];
	}

	$fullURL = 'http://base.51buy.com/index.php?mod=user&act=loginqqauthcode' . (isset($_GET['url']) ? ('&url=' . $_GET['url']) : '');
	$message = '��¼ʧ��';
	if(empty($_GET['code'])){
		TemplateHelper::outMessage( $message );
		return false;
	}
	else{
		$ip_cfg = getTokenIP();
		$accessTokenInfo = NetUtil::cURLHTTPGet("https://".$ip_cfg."/oauth2.0/token"
				. "?grant_type=authorization_code"
				. "&redirect_uri=" . urlencode($fullURL)
				. "&client_id=" . OPENQQ_APPID
				. "&client_secret=cbedab258c4b3e9d93e034796b741d56"
				. "&code=" . $_GET['code'], 3, 'graph.qq.com');
		if($accessTokenInfo === false){
			Logger::err("authorization_code failed-" . NetUtil::$errCode . '-' . NetUtil::$errMsg);
			TemplateHelper::outMessage( $message );
			return false;
		}

		parse_str($accessTokenInfo, $accessToken);
		if(empty($accessToken) || empty($accessToken['access_token'])){
			Logger::err("access_token is empty");
			TemplateHelper::outMessage( $message );
			return false;
		}

		$openIDInfo = NetUtil::cURLHTTPGet("https://".$ip_cfg."/oauth2.0/me"
				. "?access_token=" . $accessToken['access_token'], 3, 'graph.qq.com');
		if($openIDInfo === false){
			Logger::err("me failed-" . NetUtil::$errCode . '-' . NetUtil::$errMsg);
			TemplateHelper::outMessage( $message );
			return false;
		}

		if (strpos($openIDInfo, "callback") !== false){
			$lpos = strpos($openIDInfo, "(");
			$rpos = strrpos($openIDInfo, ")");
			$openIDInfo  = substr($openIDInfo, $lpos + 1, $rpos - $lpos -1);
		}
		$openIDInfo = json_decode($openIDInfo);
		if (isset($openIDInfo->error)){
			Logger::err("get openid failed-" . $openIDInfo->error);
			TemplateHelper::outMessage( $message );
			return;
		}

		$qqUserInfo = NetUtil::cURLHTTPGet("https://".$ip_cfg."/user/get_user_info"
				. "?access_token=" . $accessToken['access_token']
				. "&oauth_consumer_key=" . OPENQQ_APPID
				. "&openid=" . $openIDInfo->openid, 3, 'graph.qq.com');
		if($qqUserInfo === false){
			Logger::err("get_user_info failed-" . NetUtil::$errCode . '-' . NetUtil::$errMsg);
			TemplateHelper::outMessage( $message );
			return false;
		}

		$qqUserInfo = json_decode($qqUserInfo, true);
		if(empty($qqUserInfo)){
			TemplateHelper::outMessage( $message );
			return false;
		}

		// access_token �Ƿ����߹��ڵ�
		if($qqUserInfo['ret'] >= 100013 || $qqUserInfo['ret'] <= 100016){
			//
		}

		foreach ($qqUserInfo as $i => $v){
			$qqUserInfo[$i] = is_string($v) ? iconv("UTF-8", "GBK//IGNORE", $v) : $v;
		}

		if(_loginqq_autouser($openIDInfo->openid, substr($accessToken['access_token'], 0, 10), $qqUserInfo['nickname']) === false) return;

		// access_token����ttc
		$ttc_key = "access_token_{$openIDInfo->openid}";
		IPageCahce::setCacheData($ttc_key, $accessToken['access_token'], 86400);

		ToolUtil::redirect($redirectUrl);
	}
}

function page_user_loginqqauth() {
	$redirectUrl = 'http://www.51buy.com';
	if (!empty($_GET['url']) && preg_match("/^http:\/\/([^\.]+\.|)(51buy|icson)\.com($|\/)/i", $_GET['url'])) {
		$redirectUrl = $_GET['url'];
	}

	$message = '��¼ʧ��';
	if(empty($_GET['access_token']) || empty($_GET['openid'])){
		TemplateHelper::outMessage( $message );
		return false;
	}
	else{
		$ip_cfg = getTokenIP();
		$qqUserInfo = NetUtil::cURLHTTPGet("https://".$ip_cfg."/user/get_user_info"
				. "?access_token=" . $_GET['access_token']
				. "&oauth_consumer_key=" . OPENQQ_APPID
				. "&openid=" . $_GET['openid'], 'graph.qq.com');
		if($qqUserInfo === false){
			TemplateHelper::outMessage( $message );
			return false;
		}

		$qqUserInfo = json_decode($qqUserInfo, true);
		if(empty($qqUserInfo)){
			TemplateHelper::outMessage( $message );
			return false;
		}

		// access_token �Ƿ����߹��ڵ�
		if($qqUserInfo['ret'] >= 100013 || $qqUserInfo['ret'] <= 100016){
			//
		}

		foreach ($qqUserInfo as $i => $v){
			$qqUserInfo[$i] = is_string($v) ? iconv("UTF-8", "GBK//IGNORE", $v) : $v;
		}

		if(_loginqq_autouser($_GET['openid'], substr($_GET['access_token'], 0, 10), $qqUserInfo['nickname']) === false) return;
		ToolUtil::redirect($redirectUrl);
	}
}

function _loginqq_autouser($openID, $password, $nickname = ''){
	$message = '��¼ʧ��';
	$account = QQ_ACCOUNT_PRE . '_' . $openID; // ��ID�м�����һ���»���
	$exists = IUser::checkIcsonAccountExist($account);
	if ($exists === false) {
		Logger::err("user_loginqq IUser::checkIcsonAccountExist failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}

	$clientIp = ToolUtil::getClientIP();
	if ($exists['exist'] == 0) {
	    $getQQUrl = 'http://101.226.52.124:8080/openid/decopenid.php?func=getuinbyopenid&openid=' . $account;
	    // ͨ��openid����QQ���룬�û������ʱ��ִ��
        $qqinfo = NetUtil::cURLHTTPGet($getQQUrl);
//         sleep(1);

        // ͨ��QQ���뷴����Ѹ�˺Ų���½��Ѷ�˺�
        if ($qqinfo && ($info = json_decode($qqinfo)) && preg_match('/\d\d+/', $info->uin)) {
            if ($item = IUsersQqMapTTC::get($info->uin)) {
                if ($icsonAccount = IUsersTTC::get($item[0]['uid'])) {
                    // do nothing
                    $icsonId = $icsonAccount[0]['icsonid'];
                    setrawcookie("__BINDQQACCOUNT", 'true', 0, '/', '.51buy.com');
                }
            }
        }

        // ���û�а󶨵���Ѹ�˺���ִ��ע���߼�
        if (!isset($icsonId)) {
			$email = '';

			$regSrc = empty($_COOKIE['us']) ? '' : $_COOKIE['us'];
					$userData = array(
					'email' => $email,
					'regIP' => $clientIp,
					'warehouseId' => IUser::getSiteId(),
					'source' => $regSrc
				);
			$register = IUser::register($account, $password, $userData);
			if ($register === false) {
				if(IUser::$errCode != 10303){ // �ظ�key���ɳɹ�
					Logger::err("user_loginqq IUser::register failed-" . IUser::$errCode . '-' . IUser::$errMsg);
					TemplateHelper::outMessage( $message );
					return false;
				}
			}
			// ��Ϣһ�� ��������login�ᱨ��
			// ��Ҫ��һ���Ż������������������
// 			sleep(1);
        }
	}

	$session = isset($icsonId) ? IUser::login($icsonId, $password, $clientIp, 1, 0, false) : IUser::login($account, $password, $clientIp, 1,  3);
	if ($session === false) {
		Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}

	setrawcookie("QQACCT", $openID, 0, '/', '.51buy.com');
	setrawcookie("new_u", false, 1, '/', '.51buy.com');
	$user = IUser::getUserInfo($session['uid']);
	if ($user === false) {
		Logger::err("IUser::getUserInfo failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}
	else if (isset($user['exp_point'])  && $user['exp_point'] <= 0) { //�������û�cookie
		setrawcookie("new_u", '1', 0, '/', '.51buy.com');
	}

	setrawcookie("uid", $session['uid'], 0, '/', '.51buy.com');
	setrawcookie("skey", $session['skey'], 0, '/', '.51buy.com');
	if(!empty($session['wg_skey'])){
		setrawcookie("wg_skey", $session['wg_skey'], 0, '/', '.51buy.com');
	}
	
	setrawcookie("qq_nick", $session['uid'] . '|' . ToolUtil::escape($nickname), 0, '/', '51buy.com');

	//���QQ tips��������������֤��Ϣ
	if (isset($_GET['key'])) {
		if ((substr(md5($openID . "icson@qq"), 0 , 6) != $_GET['key'])) {
			TemplateHelper::outMessage( array("�Բ����������ϲμӴ˻������", '<a href="http://www.51buy.com">�ص���Ѹ��ҳ</a>') );
			return false;
		}
		else {
			setrawcookie("edm_key", $_GET['key'], 0, '/', '.51buy.com');
		}
	}
}
/*֮ǰ�ĵ�¼�ӿڣ�����ǰ����ȷ��û����ʹ���ˣ������������ End*/
function page_user_toalipaylogin() {
	$redirectUrl = '';
	if (!empty($_GET['url']) && preg_match("/^http:\/\/([^\.]+\.|)51buy\.com($|\/)/i", $_GET['url'])) {
		$redirectUrl = $_GET['url'];
	}
	IAlipayAuthorize::redirect($redirectUrl);
}

function page_user_alipaylogin() {
	$redirectUrl = 'http://www.51buy.com/';

	$whiteList = array_keys(CPSConfig::$providerList);
	//array_push($whiteList, '51buy', 'icson');
	array_push($whiteList, '51buy', 'icson','cps\.51buy');
	$whiteListSite = implode('|', $whiteList);
	if (!empty($_GET['url']) && preg_match("/^http:\/\/([^\.]+\.|)({$whiteListSite})\.(com|cn)($|\/)/i", $_GET['url'])) {
		$redirectUrl = $_GET['url'];
		$redirectUrl = str_replace("[_]", "&", $redirectUrl);
	}
	if (!empty($_GET['target_url']) && preg_match("/^http:\/\/([^\.]+\.|)($whiteListSite)\.(com|cn)($|\/)/i", $_GET['target_url'])) {
		$redirectUrl = $_GET['target_url'];
	}

	$alipayInfo = IAlipayAuthorize::authorize($_GET);
	if ($alipayInfo === false || empty($alipayInfo['user_id'])) {
		Logger::err("IAlipayAuthorize::authorize failed, code: " . IAlipayAuthorize::$errCode . '; msg: ' . IAlipayAuthorize::$errMsg);
		return TemplateHelper::outMessage( "�Բ��𣬵�¼ʧ�ܣ�" );
	}

	$account = ALIPAY_ACCOUNT_PRE . $alipayInfo['user_id'];
	$exists = IUser::checkIcsonAccountExist($account);
	if ($exists === false) {
		Logger::err("IUser::checkIcsonAccountExist failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return TemplateHelper::outMessage( "�Բ��𣬵�¼ʧ�ܣ�" );
	}

	$password = "";
	$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	$charsLen = strlen($chars);
	for ( $i = 0; $i < 10; $i++) {
		$password .= $chars[ mt_rand(0, $charsLen - 1) ];
	}

	$clientIp = ToolUtil::getClientIP();
	if ($exists['exist'] == 0) {
		$regSrc = empty($_COOKIE['us']) ? '' : $_COOKIE['us'];
		$userData = array(
			'regIP' => $clientIp,
			'warehouseId' => IUser::getSiteId(),
			'source' => $regSrc
		);
		$register = IUser::register($account, $password, $userData);

		if ($register === false) {
			Logger::err("IUser::register failed-" . IUser::$errCode . '-' . IUser::$errMsg);
			return TemplateHelper::outMessage("�Բ��𣬵�¼ʧ�ܣ�");
		}

		if (!empty($alipayInfo['real_name'])) {
			$update = IUser::updateUser($register, array(
				'name'	=> $alipayInfo['real_name']
			));
			if ($update === false) {
				Logger::warn("IUser::updateUser failed-" . IUser::$errCode . '-' . IUser::$errMsg);
			}
		}
		//�������������û������ݽӿ�,��Ϊ�����ݣ�����������λ������ǰ��Ҳ����һ��
		if (isset($alipayInfo['user_grade_type']) && $alipayInfo['user_grade_type'] !== false) {
			$updateAliUserGradeType = IUser::setStatusBits($session['uid'], array(
				ALI_GOLDEN_USER	=> $alipayInfo['user_grade_type'],
			));
			if ($updateAliUserGradeType === false) {
				Logger::warn("IUser::setStatusBits failed, code: " . IUser::$errCode . '; msg: ' . IUser::$errMsg);
			}
		}
		//UserWg::ImportCopartnerUserInfo($register, $account, 4);
	}

	$session = IUser::login($account, $password, $clientIp, 1, 4);
	if ($session === false) {
		Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return TemplateHelper::outMessage("�Բ��𣬵�¼ʧ�ܣ�");
	}
	//�ϱ���¼
	_registerReport(4, $session['uid'], $account);

	setrawcookie("uid", $session['uid'], 0, '/', '.51buy.com');
	setrawcookie("skey", $session['skey'], 0, '/', '.51buy.com');
	if(!empty($session['wg_skey'])){
		setrawcookie("wg_skey", $session['wg_skey'], 0, '/', '.51buy.com');
	}
	

	if (isset($alipayInfo['user_grade_type']) && $alipayInfo['user_grade_type'] !== false) {
		//� 2012.5.31 ���������˻���¼��ת�ҳ������ɾ��
//		if (empty($_GET['target_url']) || $redirectUrl != $_GET['target_url']) {
//			$redirectUrl = (false !== strpos($redirectUrl, 'www.51buy.com'))
//								? 'http://act.51buy.com/promo-2978.html?ls=alipayjzh'
//								: $redirectUrl; //���������� www.51buy.com ����վ����ʱ, ��ת���˻ҳ
//		} //etao ʹ���� target_url ��Ϊ��������

		$updateAliUserGradeType = IUser::setStatusBits($session['uid'], array(
			ALI_GOLDEN_USER	=> $alipayInfo['user_grade_type'],
		));
		if ($updateAliUserGradeType === false) {
			Logger::warn("IUser::setStatusBits failed, code: " . IUser::$errCode . '; msg: ' . IUser::$errMsg);
		}
	}

	if (!empty($alipayInfo['token'])) {
		setrawcookie("ali_token", $alipayInfo['token'], 0, '/', '.51buy.com');
	}

	ToolUtil::redirect($redirectUrl);
}

function user_getqqcbaddress() {
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	$user = IUser::getUserInfo($uid);
	if ($user === false) {
		return array('errno' => 6001);
	}

	if (strpos($user['icsonid'], QQ_ACCOUNT_PRE) !== 0) {
		return array('errno' => 1);
	}

	$params = array(
		'version' => '1.0',
		'merchant_id' => 'icson',
		'openid' => trim(substr($user['icsonid'], strlen(QQ_ACCOUNT_PRE)), '_'),
		'openkey' => $_COOKIE[CPSConfig::$cookieNameOpenKey],
		'charset' => 'UTF-8', //�ҳ��Թ�gbk, û��
		'return_fmt' => 'json',
		'timestamp' => time(),
	);

	$address = IQQCBAddress::request($params);
	if (false === $address) {
		return array('errno' => 6003);
	}
	else {
		return array(
			'errno'	=> 0,
			'data'	=> $address
		);
	}
}

//��֤����
function page_user_validateemail() {
	if (empty($_GET['code'])) {
		return TemplateHelper::outMessage("��������", 'warn');
	}

	$realBindEmail = IUser::realBindEmail($_GET['code']);
	if ($realBindEmail === false) {
		Logger::err('IUser::realBindEmail failed, code: ' . IUser::$errCode . '; msg: ' . IUser::$errMsg);
		return TemplateHelper::outMessage('�Բ��𣬰�����ʧ�ܣ�', 'warn');
	}

	TemplateHelper::outMessage(array(
		"�󶨳ɹ���",
		IUser::getLoginUid() ? '<a href="http://base.51buy.com/myprofile.html">�ҵ���Ѹ</a>' : ('<a href="http://base.51buy.com/login.html?url=' . urlencode('http://base.51buy.com/myprofile.html') .'">���ڵ�¼</a>'),
		"<script type=\"text/javascript\">G.logic.login.forceFlushUser();</script>"
	), 'right');
}

//ȡ����֤����
function page_user_unvalidateemail() {
	$uid = IUser::getLoginUid();
	if(!$uid){
		return TemplateHelper::outMessage("���ĵ�¼״̬�Ѿ���ʧ,�����µ�¼", 'warn');
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		return TemplateHelper::outMessage("���ĵ�¼״̬�Ѿ���ʧ,�����µ�¼", 'warn');
	}

	if (empty($_GET['code'])) {
		return TemplateHelper::outMessage("��������", 'warn');
	}

	if(empty($_GET['email']) || !ToolUtil::checkEmail($_GET['email'])){
		return TemplateHelper::outMessage('����Ϊ�ջ��������ʽ���Ϸ�', 'warn');
	}
	//��֤��
	$code = $_GET['code'];
	$code = substr($code, 8);
	$email = $_GET['email'];
	$ret = IVerify::checkEmailVerifyCode($uid, $code, $email);
	if (false === $ret) {
		return TemplateHelper::outMessage("ȡ����ʧ�ܣ������»�ȡȡ����֤�ʼ�", 'warn');
	}
	$unbind = IUser::unbindEmail($uid,$_GET['email']);
	if($unbind === false){
		if(IUser::$errCode == 29){
			return TemplateHelper::outMessage('ϵͳ��æ,ȡ����ʧ��', 'warn');
		}

		Logger::err("IUser::unbindEmail failed, code:" . IUser::$errCode . ', msg:' . IUser::$errMsg);
		return TemplateHelper::outMessage('ϵͳ��æ,ȡ����ʧ��', 'warn');
	}

	//ȡ����֤�ɹ���,��ҳ�淵����ʾ
	TemplateHelper::outMessage(array(
		"ȡ���ɹ���",
		IUser::getLoginUid() ? '<a href="http://base.51buy.com/myprofile.html">�ҵ���Ѹ</a>' : ('<a href="http://base.51buy.com/login.html?url=' . urlencode('http://base.51buy.com/myprofile.html') .'">���ڵ�¼</a>'),
		"<script type=\"text/javascript\">G.logic.login.forceFlushUser();</script>"
	), 'right');
}
//�°��¼ҳ���Ҷ���
function page_user_login() {
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		//'cssFile'	=> 'https://st.51buy.com/static_v1/css/loginV2/login.css',
		'cssFile'	=> 'https://st.51buy.com/static_v1/css/login/login.css?v=2013031901',
		'headerStyle'	=> 'login',
		'titleDesc'	=> '��¼',
		'SSL' => true
	));

	$TPL->set_file(array(
		"containerHandler"	=> "login.tpl"
	));
	//�ϱ���¼
	_registerReport(3);
	$TPL->out();
}
//�ϰ��¼ҳ����ͨ�����������µ�¼ҳ
/*function page_user_login() {
	$loginflag = isset($_GET['loginflag'])		? $_GET['loginflag']		: 0;
	if($loginflag == 1)
	{//������loginflag���°�
		$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
			'cssFile'	=> 'https://st.51buy.com/static_v1/css/loginV2/login.css',
			//'cssFile'	=> 'https://st.51buy.com/static_v1/css/login/login.css?v=2013031901',
			'headerStyle'	=> 'login',
			'titleDesc'	=> '��¼',
			'SSL' => true
		));

		$TPL->set_file(array(
			"containerHandler"	=> "login.tpl"
		));
	}
	else
	{//�ɰ�
		$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
			//'cssFile'	=> 'https://st.51buy.com/static_v1/css/loginV2/login.css',
			'cssFile'	=> 'https://st.51buy.com/static_v1/css/login/login.css?v=2013031901',
			'headerStyle'	=> 'loginold',
			'titleDesc'	=> '��¼',
			'SSL' => true
		));

		$TPL->set_file(array(
			"containerHandler"	=> "loginold.tpl"
		));
	}
	//�ϱ���¼
	_registerReport(3);
	$TPL->out();
}*/

/*��¼������
function page_user_logintest() {
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'cssFile'	=> 'https://st.51buy.com/static_v1/css/login/login.css?v=2013031901',
		'headerStyle'	=> 'login',
		'titleDesc'	=> '��¼',
		'SSL' => true
	));

	$TPL->set_file(array(
		"containerHandler"	=> "logintest.tpl"
	));
	//�ϱ���¼
	_registerReport(3);
	$TPL->out();
}*/

function page_user_register() {
	$reg_re = $_COOKIE['reg_re'];
	if(empty($reg_re))
	{
		setrawcookie("reg_re", 1, 0, '/', '.51buy.com');
		ToolUtil::redirect('http://base.51buy.com'.$_SERVER['REQUEST_URI']);
		return ;
	}
	setrawcookie("reg_re", '', 0, '/', '.51buy.com');
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'cssFile'	=> 'http://st.51buy.com/static_v1/css/login/register.css?v=2013031901',
		'headerStyle'	=> 'register',
		'titleDesc'	=> 'ע��'
	));

	$TPL->set_file(array(
		"containerHandler"	=> "register.tpl"
	));
	//�ϱ�ҳ�����Ϣ
	//_registerReport(1);
	$TPL->out();
}

/**
 * ������ҵ���ϵ�¼
 * @author oscarzhu
 * @modified by EdisonTsai on 11:02 2012/09/05 for add target URL
 */

function page_user_shcarlogin() {

	$uid = isset($_GET['uid']) ? $_GET['uid']:'';
	$name = isset($_GET['uname']) ? $_GET['uname']:'';
	$name = iconv('utf8','gbk',$name);

	if( empty($uid) || empty($name) )
	{
		return TemplateHelper::outMessage( "�Բ��𣬲������󣬵�¼ʧ�ܣ�" );
	}

	//��֤�ش�uname����Ϊutf8
	$shCarInfo = ISHCarAuthorize::authorize($uid, urlencode($_GET['uname']));
	if ( $shCarInfo === false ) {
		Logger::err("ISHCarAuthorize::authorize failed, code: " . IAlipayAuthorize::$errCode . '; msg: ' . IAlipayAuthorize::$errMsg);
		return TemplateHelper::outMessage( "�Բ�����֤ʧ�ܣ���¼ʧ�ܣ�" );
	}

	$account = SHAUTO_ACCOUNT_PRE . $name;
	$exists = IUser::checkIcsonAccountExist($account);
	if ($exists === false) {
		Logger::err("IUser::checkIcsonAccountExist failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return TemplateHelper::outMessage( "�Բ��𣬲�ѯʧ�ܣ���¼ʧ�ܣ�" );
	}

		#Added by EdisonTsai for redirect to target URL
		$redirectUrl	=	!isset($_GET['turl']) || !ToolUtil::checkURL($_GET['turl']) || !preg_match("/^https?:\/\/([^\.]+\.|)51buy\.com($|\/)/i", $_GET['turl']) ? 'http://www.51buy.com' : trim(urldecode($_GET['turl']));

	$clientIp = ToolUtil::getClientIP();
	if ($exists['exist'] == 0) {
		global $_USER_TYPE;
		$regSrc = empty($_COOKIE['us']) ? '' : $_COOKIE['us'];
		$userData = array (
			'regIP' => $clientIp,
			'warehouseId' => IUser::getSiteId(),
			'source' => $regSrc
		);
		$register = IUser::register($account, $shCarInfo['password'], $userData);

		if ($register === false) {
			Logger::err("IUser::register failed-" . IUser::$errCode . '-' . IUser::$errMsg);
			return TemplateHelper::outMessage("�Բ���ע��ʧ�ܣ���¼ʧ�ܣ�");
		}

		$update = IUser::updateUser($register, array(
			'name'	=> $shCarInfo['realName'],
			'type'	=> $_USER_TYPE['SHAutoUser']
		));
		if ($update === false) {
			Logger::warn("IUser::updateUser failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		}
		$ret = IUser::setStatusBits($register, array('1'=>1));//���ô��û����ֱ�־λ
		if ($ret === false) {
			Logger::warn("IUser::setStatusBits failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		}
		//�������������û������ݽӿ�
		//UserWg::ImportCopartnerUserInfo($register, $account, 6);
	}

	$session = IUser::login($account, $shCarInfo['password'], $clientIp, 1, 6);
	if ($session === false) {
		Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return TemplateHelper::outMessage("�Բ�������ʧ�ܣ���¼ʧ�ܣ�");
	}
	//�ϱ���¼
	_registerReport(4, $session['uid'], $account);

	setrawcookie("uid", $session['uid'], 0, '/', '.51buy.com');
	setrawcookie("skey", $session['skey'], 0, '/', '.51buy.com');
	if(!empty($session['wg_skey'])){
		setrawcookie("wg_skey", $session['wg_skey'], 0, '/', '.51buy.com');
	}
	
	setrawcookie("shcar_token", 1, 0, '/', '.51buy.com'); //����cookie,��ǰ�û�Ϊ�����û�

	if (isset($_COOKIE[CPSConfig::$cookieName])) { //����У�ɾ��CPS���
		unset($_COOKIE[CPSConfig::$cookieName]);
		setrawcookie(CPSConfig::$cookieName, '', -1, '/', '.51buy.com');
	}

	ToolUtil::redirect($redirectUrl);
}

function user_vcode() {
	$clientIp = ToolUtil::getClientIP();
	header('Content-type:image/jpeg');
	global $_IP_CFG;
	for($i = 0; $i < 2; $i++) {
		$ret = get_verify_code(VERIFY_CODE_APPID, $_IP_CFG['verify_code']['code_server'][0]['IP'], $_IP_CFG['verify_code']['code_server'][0]['PORT'], $_IP_CFG['verify_code']['code_server'][1]['IP'], $_IP_CFG['verify_code']['code_server'][1]['PORT'], $clientIp);
		if($ret !== false) {
			if(!empty($_COOKIE['verifysession']))
			{
				setcookie("verifysession", '', 1);
				setcookie("verifysession", '', 1 , "/", ".51buy.com");
			}
			setcookie("verifysession", $ret['sig'], 0 , "/", "base.51buy.com");
			//setcookie("verifysession", $ret['sig'], 0 , "/", ".51buy.com");
			//setcookie("verifysession", $ret['sig']);
			//�ϱ�
			_registerReport(5,0,0,$ret['sig']);
			echo $ret['img'];
			break;
		}
	}
	exit;
}

//ͳһ��̨�˳���¼
function user_logout(){
	$uid = !empty($_COOKIE['uid']) ? $_COOKIE['uid'] : "";
	$skey = !empty($_COOKIE['wg_skey']) ? $_COOKIE['wg_skey'] : "";
	if(!$uid || !$skey){
		return array('errno'=> 1);
	}
	$result = UserWg::IcsonUserLogout($uid, $skey);
	if($result === false){
		return array('errno'=> 2);
	}
	return array('errno'=> 0);
}

/**
 * 1. ����ע�����
 * 2. �ύע��
 * 3. �����¼����
 * 4. �ύ��¼
 * 5. ��ȡ��֤��
 * 6. �ύ��֤��
 * $_IP_CFG['USER_REGISTER_REPORT'] =  array(
		array('IP' => '10.191.8.44', 'PORT' => 59891),
		array('IP' => '10.191.8.44', 'PORT' => 59891)
	);
 */
function _registerReport($type, $uid=0, $account=0,$session="")
{
    $userIP = ToolUtil::getClientIP();
    $visitKey = isset($_COOKIE["visitkey"]) ? $_COOKIE["visitkey"] : "";
//     $verifysession = isset($_COOKIE["verifysession"]) ? $_COOKIE["verifysession"] : $session;
    $verifysession = !empty($session) ? $session :(isset($_COOKIE["verifysession"])?$_COOKIE["verifysession"]:"");
    $report = array(
                "user_id"=> $uid,
                "account"=> $account,
                "log_type"=>$type,
                "time" => time(),
                "verifysession" => $verifysession,
                "visitkey"=> $visitKey,
                "ip"=>$userIP
            );
    $req = json_encode($report);
    $address = Config::getIP('USER_REGISTER_REPORT');
    if(!$address)
    {
        Logger::err("_registerReport Get Ip Error:".print_r($address,true));
    }
    //�������ʵ��������ȷ��
    $ip = $address[0]["IP"];
    $port = $address[0]["PORT"];
    $resp = NetUtil::udpCmd($ip, $port, $req, false);
    if($resp === false)
    {
        Logger::err("_registerReport Send Msg Error");
    }
    return;
}
/**
 * 1. ����ע�����
 * 2. �ύע��
 * 3. �����¼����
 * 4. �ύ��¼
 * 5. ��ȡ��֤��
 * 6. �ύ��֤��
 * 7. 
 * $_IP_CFG['USER_REGISTER_REPORT'] =  array(
		array('IP' => '10.191.8.44', 'PORT' => 59891),
		array('IP' => '10.191.8.44', 'PORT' => 59891)
	);
 */
function user_registerReportSubmit( )
{
	$type	 = isset($_GET['type'])		? $_GET['type']		: 0;
	$uid	 = isset($_GET['uid'])		? $_GET['uid']		: 0;
	$account = isset($_GET['account'])	? $_GET['account']	: 0;
	$session = isset($_GET['session'])	? $_GET['session']	: '';
	$uin	 = isset($_GET['uin'])		? $_GET['uin']		: 0;
	$phone	 = isset($_GET['phone'])	? $_GET['phone']	: 0;
	$mail	 = isset($_GET['mail'])		? $_GET['mail']		: '';
	//$registerFlag = isset($_GET['registerFlag']) ? $_GET['registerFlag']:$userIP.time();
	$registerFlag = isset($_GET['registerFlag']) ? $_GET['registerFlag']:"";

    $userIP = ToolUtil::getClientIP();
    $visitKey = isset($_COOKIE["visitkey"]) ? $_COOKIE["visitkey"] : "";
    $verifysession = !empty($session) ? $session :(isset($_COOKIE["verifysession"])?$_COOKIE["verifysession"]:"");
    $report = array(
                "user_id"=> $uid,
                "account"=> $account,
                "log_type"=> intval($type),
                "time" => time(),
                "verifysession" => $verifysession,
                "visitkey"=> $visitKey,
                "ip"=>$userIP,
				"uin"=>$uin.'',
				"phone"=>$phone.'',
				"mail"=>$mail,
				"registerFlag"=>md5($registerFlag."&".$userIP)
            );
    $req = json_encode($report);
	Logger::info("Register Report : ".$req);
    $address = Config::getIP('USER_REGISTER_REPORT');
	Logger::info("USER_REGISTER_REPORT : ".print_r($address,true));

    if(!$address)
    {
        Logger::err("_registerReport Get Ip Error:".print_r($address,true));
    }
    //�������ʵ��������ȷ��
    $ip = $address[0]["IP"];
    $port = $address[0]["PORT"];
    $resp = NetUtil::udpCmd($ip, $port, $req, false);
    if($resp === false)
    {
        Logger::err("_registerReport Send Msg Error");
    }
    return;
}
// End Of Script