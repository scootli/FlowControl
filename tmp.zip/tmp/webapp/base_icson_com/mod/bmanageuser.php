<?php
require_once (PHPLIB_ROOT . 'api/distribution/IBUser.php');
require_once (PHPLIB_ROOT . 'lib/Image.php');
require_once (PHPLIB_ROOT . 'lib/UploadPic.php');
header('Content-Type:text/html;charset=GB2312');

Logger::init();

function page_bmanageuser_shop() {
	$fmt = empty($_GET['fmt'])? 0 : intval($_GET['fmt']); //�����Դ
    $source = array(
       0 => array('titleDesc' => '�ŵ����','navName' =>'b_manage_shop'),
       1 => array('titleDesc' => '�ջ���ַ','navName' =>'b_manage_address'),
    );
    if ($fmt > 1 || $fmt < 0)
    {
       $fmt = 0;
    }
    $TPL = TemplateHelper::getBaseTPL(0,$source[$fmt]['navName'], array(
        'titleDesc' => $source[$fmt]['titleDesc']
    ));
    $TPL->set_var(array(
        'pageName'  => $source[$fmt]['titleDesc'],
    ));
    $TPL->set_file(array(
        'contentHandler' => 'b_manage_shop.tpl'
    ));
	
	$TPL->parse('content', 'contentHandler');
	$TPL->set_var('store_class', 'my_store');
	$TPL->out();
}

function bmanageuser_shop() {
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $conditions = array();
    if (isset($_POST['name']) && '' != $_POST['name']) {
        $conditions ['shopName'] = $_POST ['name'];
    }
    if (isset($_POST['contact']) && '' != $_POST['contact']) {
        $conditions ['contact'] = $_POST ['contact'];
    }
    if (isset($_POST['status']) && '' != $_POST['status']) {
        $conditions['status'] = $_POST['status'];
    }
    $page = 0;
    $pageSize = 24;
    if (isset($_POST['page']) && '' != $_POST['page']) {
        $page = intval($_POST['page']);
    }
    $shops = IBUser::getPageShop($uid, $conditions, $page, $pageSize, !$page);
    if (FALSE === $shops) {
        Logger::err("IBUser::getPageShop faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno'	=> IBUser::$errCode);
    }
    if (!$shops['data']) {
        //û������
        return array('errno' => 1);
    }
    if (0 == $page) {//init page
        $shops['pages'] = ceil($shops['count'] / $pageSize);
        unset($shops['count']);
    }
    $shops['errno'] = 0;
    return $shops;
}

function bmanageuser_addShop() {
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $_POST['retailerId'] = $uid;
    $user = IUser::getUserInfo($uid);
    $ret = IBUser::addShop($_POST, $user['icsonid']);
    if (FALSE === $ret) {
        Logger::err("IBUser::addShop faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
	return array('errno' => 0);
}

function bmanageuser_updateShop() {
    if (!isset($_POST['shopId'])) {
        return array('errno' => 1);
    }
    
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $shopId = intval($_POST['shopId']);
    $_POST['retailerId'] = $uid;
    
    $shopInfo = IBUser::getShopInfo($uid, $shopId);
    if (FALSE === $shopInfo) {
        Logger::err("IBUser::getShopInfo faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
    //�ŵ������ķ�����ID���½��ID������
    if (!$shopInfo || $uid != $shopInfo['retailerId']) {
        return array('errno' => 5);
    }
    
    $user = IUser::getUserInfo($uid);
    $ret = IBUser::modifyShop($uid, $_POST, $user['icsonid']);
    if (FALSE === $ret) {
        Logger::err("IBUser::modifyShop faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
	return array('errno' => 0);
}

function bmanageuser_getlog() {
    if (!isset($_POST['shopId'])) {
        return array('errno' => 1);
    }
    $shopId = intval($_POST['shopId']);
    $reason = IBUser::getNoPassReason($shopId);
    if ($reason) {
        return array(
            'errno'	=> 0,
            'data'	=> $reason['remark']
    	);
    }
    return array('errno' => 404);
}

function bmanageuser_removeShop() {
    if (!isset($_POST['shopId'])) {
        return array('errno' => 1);
    }
    $shopId = intval($_POST['shopId']);
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $shopInfo = IBUser::getShopInfo($uid, $shopId);
    if (FALSE === $shopInfo) {
        Logger::err("IBUser::getShioInfo faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
    //�ŵ������ķ�����ID���½��ID������
    if (!$shopInfo || $uid != $shopInfo['retailerId']) {
        return array('errno' => 5);
    }
    
    
    $salesmans = IBUser::getAllSalesman($uid, array('shopId' => $shopId, 'status' => IBUser::STATUS_CHECK_PASSED));
    if (FALSE === $salesmans) {
        Logger::err("IBUser::getAllSalesman faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
    //�Ѿ������˺Ű󶨵����ŵ��¡�
    if ($salesmans) {
        return array('errno' => -4044);
    }
    $user = IUser::getUserInfo($uid);
    $reason = IBUser::deleteShop($uid, $shopId, $user['icsonid']);
    if (!$reason) {
        Logger::err("IBUser::deleteShop faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
    return array('errno' => 0);
}

function page_bmanageuser_salesman() {
	$TPL = TemplateHelper::getBaseTPL(0, "b_manage_salesman", array(
		'titleDesc' => '�ʺŹ���'
	));
	$TPL->set_var(array(
		'pageName'	=> '�ʺŹ���',
	));
	$TPL->set_file(array(
		'contentHandler' => 'b_manage_salesman.tpl'
	));
	$TPL->parse('content', 'contentHandler');
	$TPL->set_var('store_class', 'my_store');
	$TPL->out();
}

function bmanageuser_salesman() {
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $conditions = array();
    $page = 0;
    $pageSize = 24;
    if (isset($_POST['page']) && '' != $_POST['page']) {
        $page = intval($_POST['page']);
    }
    if (isset($_POST['account']) && '' != $_POST['account']) {
        $conditions['account'] = $_POST['account'];
    }
    if (isset($_POST['status']) && '' != $_POST['status']) {
        $conditions['status'] = $_POST['status'];
    }
    //�ȴ��ŵ����ȡ�ŵ���Ϣ
    if (isset($_POST['shopName']) && '' != $_POST['shopName']) {
        $rows = IBUser::getAllShop($uid, array('shopName' => $_POST['shopName']));
        if (FALSE === $rows) {
            Logger::err("IBUser::getAllShop faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
            return array('errno' => IBUser::$errCode);
        }
        if (!$rows) {
            //û������
            return array('errno' => 1);
        }
        $shop = current($rows);
        $conditions['shopId'] = $shop['shopId'];
        $salesmans = IBUser::getPageSalesman($uid, $conditions, $page, $pageSize, !$page);
        if (FALSE === $salesmans) {
            Logger::err("IBUser::getPageSalesman faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
            return array('errno'	=> IBUser::$errCode);
        }
        if (0 == $page) {//init page
            $salesmans['pages'] = ceil($salesmans['count'] / $pageSize);
            unset($salesmans['count']);
        }
        $salesmans['errno'] = 0;
        foreach ($salesmans['data'] as $k => $v) {
            $salesmans['data'][$k]['shopName'] = $shop['shopName'];
        }
        return $salesmans;
    }
    else {
        $salesmans = IBUser::getPageSalesman($uid, $conditions, $page, $pageSize, !$page);
        if (FALSE === $salesmans) {
            Logger::err("IBUser::getList faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
            return array('errno'	=> IBUser::$errCode);
        }
        if (!$salesmans['data']) {
            //û������
            return array('errno' => 1);
        }
        $sameShopIds = array();
        $tmpData = array();
        foreach ($salesmans['data'] as $v) {
            if (isset($sameShopIds[$v['shopId']])) {
                $sameShopIds[$v['shopId']][] = $v['uid'];
            }
            else {
                $sameShopIds[$v['shopId']] = array($v['uid']);
            }
            $tmpData[$v['uid']] = $v;
        }
        $rows = IBUser::getAllShop($uid);
        if (FALSE === $rows) {
            Logger::err("IBUser::getAllShop faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
            return array('errno' => IBUser::$errCode);
        }
        
        foreach ($rows as $v) {
            if (isset($sameShopIds[$v['shopId']])) {
                foreach ($sameShopIds[$v['shopId']] as $vv) {
                    $tmpData[$vv]['shopName'] = $v['shopName'];
                };
            }
        }
        $salesmans['data'] = $tmpData;
        if (0 == $page) {//init page
                $salesmans['pages'] = ceil($salesmans['count'] / $pageSize);
                unset($salesmans['count']);
            }
        $salesmans['errno'] = 0;
        return $salesmans;
    }
}

function bmanageuser_addAccount() {
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $_POST['retailerId'] = $uid;
    //���ò���Ա�����ڼ�¼��־��ǧ��������
    $ret = IBUser::register($_POST);
    if (FALSE === $ret) {
        Logger::err("IBUser::register faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
	return array('errno' => 0);
}

function bmanageuser_updateAccount() {
    if (!isset($_POST['uid'])) {
        return array('errno' => 1);
    }
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $_POST['retailerId'] = $uid;
    $salesman = IBUser::getSalesmanInfo($uid, intval($_POST['uid']));
    if (FALSE === $salesman) {
        Logger::err("IBUser::getSalesmanInfo faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
    //���˺������ķ�����ID���½��ID������
    if (!$salesman || $uid != $salesman['retailerId']) {
        return array('errno' => 5);
    }
    $ret = IBUser::modify($uid, $_POST);
    if (FALSE === $ret) {
        Logger::err("IBUser::modify faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
	return array('errno' => 0);
}

function bmanageuser_setStatus() {
    if (!isset($_POST['uid']) || !isset($_POST['status'])) {
        return array('errno' => 1);
    }
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $_POST['retailerId'] = $uid;
    $salesman = IBUser::getSalesmanInfo($uid, intval($_POST['uid']));
    if (FALSE === $salesman) {
        Logger::err("IBUser::getSalesmanInfo faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
    //���˺������ķ�����ID���½��ID������
    if (!$salesman || $uid != $salesman['retailerId']) {
        return array('errno' => 5);
    }
    $ret = '1' == $_POST['status'] ? IBUser::enable($uid, intval($_POST['uid'])) : IBUser::disable($uid, intval($_POST['uid']));
    if (FALSE === $ret) {
        Logger::err("IBUser::enable|disable faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
	return array('errno' => 0);
}

function bmanageuser_resetPasswd() {
    if (!isset($_POST['uid']) || !isset($_POST['passwd'])) {
        return array('errno' => 1);
    }
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $_POST['retailerId'] = $uid;
    $salesman = IBUser::getSalesmanInfo($uid, intval($_POST['uid']));
    if (FALSE === $salesman) {
        Logger::err("IBUser::getSalesmanInfo faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
    //���˺������ķ�����ID���½��ID������
    if (!$salesman || $uid != $salesman['retailerId']) {
        return array('errno' => 5);
    }
    $ret = IBUser::changePassword($uid, intval($_POST['uid']), $_POST['passwd']);
    if (FALSE === $ret) {
        Logger::err("IBUser::changePassword faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno' => IBUser::$errCode);
    }
	return array('errno' => 0);
}

function bmanageuser_getShops() {
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $conditions = array('status' => '1');
    $rows = IBUser::getAllShop($uid, $conditions);
    if (FALSE === $rows) {
        Logger::err("IBUser::getAllShop faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno'	=> IBUser::$errCode);
    }
    if (!$rows) {
        return array('errno' => 1);
    }
    $shops = array();
    foreach ($rows as $v) {
        $shops['data'][] = array('shopId' => $v['shopId'], 'shopName' => $v['shopName']);
    }
    $shops['errno'] = 0;
    return $shops;
}

function bmanageuser_getAllShops() {
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
        return array('errno' => 5);
    }
    $conditions = array('status' => '1');
    $rows = IBUser::getAllShop($uid, $conditions);
    if (FALSE === $rows) {
        Logger::err("IBUser::getAllShop faild-" . IBUser::$errCode . "-" . IBUser::$errMsg);
        return array('errno'    => IBUser::$errCode);
    }
    if (!$rows) {
        return array('errno' => 1);
    }
    $shops = array();
//    foreach ($rows as $v) {
//        $shops['data'][] = array('shopId' => $v['shopId'], 'shopName' => $v['shopName']);
//    }
    $shops['data'] = $rows;
    $shops['errno'] = 0;
    return $shops;
}

function page_bmanageuser_setting() {
	$uid = ToolUtil::checkLoginOrRedirect();

	$TPL = TemplateHelper::getBaseTPL(0, "b_manage_setting", array(
		'titleDesc' => '��������'
	));
	$TPL->set_var(array(
		'pageName'	=> '��������',
	));
	$TPL->set_file(array(
		'contentHandler' => 'b_manage_setting.tpl'
	));
	$TPL->parse('content', 'contentHandler');
	$logo = IBUser::getRetailerLogo($uid);
	if (!$logo) {
	    $logo = '';
	}
	if (isset($_GET['err'])) {
	    $errMsg = array(
	        1 => '��ѡ��Ҫ�ϴ���ͼƬ',
	        2 => 'logoͼƬ���Ϸ�',
	        3 => '�������',
	        4 => '����logoͼƬʧ��',
	        5 => '����logoͼƬʧ��',
	        6 => '�ļ���С��������',
	        7 => '�ϴ�����'
	    );
	    $err = intval($_GET['err']);
	    if (isset($errMsg[$err])) {
	        $srciptStr = "
<script type='text/javascript'>
    $(document).ready(function(){
        G.ui.popup.showMsg('" . $errMsg[$err] . "');
    });
</script>
";
	        $TPL->set_var('logoSrcipt', $srciptStr);
	    }
	    else {
	        if ($logo) {
	            $logo .= '?t=' . time();
	        }
	        $TPL->set_var('logoSrcipt', '');
	    }
	}
	else {
	    $TPL->set_var('logoSrcipt', '');
	}
	$TPL->set_var('logo', $logo);
	$TPL->set_var('uid', IUser::getLoginUid());
	$TPL->set_var('store_class', 'my_guide');
	$TPL->out();
}

function page_bmanageuser_savesetting() {
    if ($_FILES && $_FILES['logopic']['name']) {
        $uid = IUser::getLoginUid();
        if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
    		ToolUtil::redirect("/bmanagesetting.html?err=3");
    	}
        $tmpFile = $_FILES['logopic']['tmp_name'];
        if (0 != $_FILES['logopic']['error']) {
            ToolUtil::redirect("/bmanagesetting.html?err=7");
        }
        if (1024 * 1024 < $_FILES['logopic']['size']) {
            @unlink($tmpFile);
            ToolUtil::redirect("/bmanagesetting.html?err=6");
        }
        if ('png' != strtolower(substr($_FILES['logopic']['name'], -3))) {
            @unlink($tmpFile);
            ToolUtil::redirect("/bmanagesetting.html?err=2");
        }
        //����ļ��Ϸ���
        else if (is_uploaded_file($tmpFile) && @getimagesize($tmpFile)) {
            $fileName = $tmpFile . $_FILES['logopic']['name'];
            move_uploaded_file($tmpFile, $fileName);                        
            $url = 'http://image.icson.com/publish/index.php?mod=uplogo';
            $post_data = array(
                'image' => '@' . $fileName,
                'uid'   => $uid
            );
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            // ���ӳ�ʱ
    		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
    		// ִ�г�ʱ
    		curl_setopt($ch, CURLOPT_TIMEOUT, 3);
            $ret = curl_exec($ch);
            curl_close($ch);
            if (!$ret) {
                Logger::err("curl_exec faild-" . curl_errno($ch) . "-" . curl_error($ch));
                ToolUtil::redirect("/bmanagesetting.html?err=3");
            }
            $logoInfo = json_decode($ret, TRUE);
            if (0 != $logoInfo['err']) {
                ToolUtil::redirect("/bmanagesetting.html?err=4");
            }
            $updateData = array(
                'uid'  => $uid,
                'logo' => $logoInfo['msg']
            );
            $ret = IRetailer::updateRetailer($updateData);
            if (!$ret) {
                Logger::err("IRetailer::updateRetailer faild-" . IRetailer::$errCode . "-" . IRetailer::$errMsg);
                ToolUtil::redirect("/bmanagesetting.html?err=5");
            }
            ToolUtil::redirect("/bmanagesetting.html?err=0");
        }
        else {
            @unlink($tmpFile);
            ToolUtil::redirect("/bmanagesetting.html?err=2");
        }
    }
    else {
        ToolUtil::redirect("/bmanagesetting.html?err=1");
    }
}