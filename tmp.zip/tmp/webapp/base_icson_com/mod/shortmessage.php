<?php
require_once(PHPLIB_ROOT . 'api/IReviewShortMessage.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');

Logger::init();

function page_shortmessage_page() {
	$uid = ToolUtil::checkLoginOrRedirect();

	$TPL = TemplateHelper::getBaseTPL(0, 'shortmessage', array(
		'titleDesc' => 'վ����'
	));
	$TPL->set_var('pageName', 'վ����');
	$TPL->set_file(array(
		'contentHandler' => 'shortmessage.tpl'
	));

//IShortMessage::addSystemShortMessge($uid, array($uid), "������\r����\n����", "Hi,�װ����û�\r\n,���¼http://base.51buy.com");

	//�ҵ�վ����
	$pageSize = 10;
	$currentPage = (intval($_GET['page']) <= 0) ? 1 : intval($_GET['page']);
	$shortmessageJsonStr = IShortMessage::getReceivedSystemMessage($uid, ($currentPage-1) * $pageSize, $pageSize);
	if ($shortmessageJsonStr === false) {
		Logger::err('IShortMessage::getReceivedSystemMessage failed-' . IShortMessage::$errCode . '-' . IShortMessage::$errMsg);
		return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
	}

	//Logger::info("{$uid} - " . "shortmessageJsonStr:" .count($shortmessageJsonStr));

	$search_str = array("\\'");
	$replace_str = array("'");
	$shortmessageJsonStr = str_replace($search_str, $replace_str, $shortmessageJsonStr);
	$shortmessageList = ToolUtil::gbJsonDecode($shortmessageJsonStr);

	//Logger::info("{$uid} - " . "shortmessageList:" .count($shortmessageList));

	$TPL->set_block('contentHandler', 'shortmessage_list', 't_shortmessage_list');

	$total = 0;
	$count = IShortMessage::getReceivedMessageCount($uid);
	if (false === $count) {
		Logger::err('IShortMessage::getReceivedSystemMessage failed-' . IShortMessage::$errCode . '-' . IShortMessage::$errMsg);
	}
	else {
		$count = ToolUtil::gbJsonDecode($count);
		$total = empty($count['total']) ? 0 : $count['total'];
		$total = ceil($total / $pageSize);
	}

	if (empty($shortmessageList)) {
		$TPL->set_var('t_shortmessage_list', '<tr><td colspan="5"><p class="kong">��û��վ����Ϣ</p></td></tr>');
		$TPL->set_var('page', '');
	}
	else {
		foreach ($shortmessageList as &$message) {
			$params = array (
				'id' => $message['id'],
				'status' => $message['status'],
				'title' => ToolUtil::transXSSContent($message['title']),
				'content' =>  nl2br(ToolUtil::transXSSContent($message['content'])),
				'create_time' => date('Y-m-d H:i:s', $message['create_time']),
				'shortmessage_id' => $message['id'],
				'ifbold'	=> $message['status'] == 1 ? ' bold' : '',
				'currentPage' => $currentPage,
			);
			$TPL->set_var($params);
			$TPL->parse('t_shortmessage_list', 'shortmessage_list', true);
			$TPL->unset_var($params);
		}

		$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/shortmessage-{page}.html', $currentPage, $total)  . '</div></div>');
	}

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//���˵�վ����statusΪ4[��ɾ��]����Ϣ
function _filter($list) {
	$ret = array();
	if (!empty($list)) {
		foreach($list as $item) {
			if ($item['status'] != 4 ) {
				$ret[] = $item;
			}
		}
	}
	return $ret;
}

//ɾ���ҵ�վ����
function shortmessage_remove() {
	$uid=IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	$message_ids = empty($_GET['ids']) ? '' :$_GET['ids'];
	if (empty($message_ids)) {
		return  array('errno' => 1);
	}

	$res = IShortMessage::deleteReceivedMessage($message_ids, $uid);
	if (false == $res) {
		Logger::err('IShortMessage::deleteReceivedMessage failed-' . IShortMessage::$errCode . '-' . IShortMessage::$errMsg);
		return  array('errno' => 2);
	}
	return  array('errno' => 0);
}

//�Ѷ�ȡվ����Ϣ
function shortmessage_read() {
	$uid=IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	$message_ids=empty($_GET['ids']) ? '' :$_GET['ids'];
	if (empty($message_ids)) {
		return  array('errno' => 1);
	}
	$res = IShortMessage::updateReceivedMessageStatus($message_ids, $uid);
	$message_ids = $message_ids + 0;
	if (false == $res) {
		Logger::err('IShortMessage::updateReceivedMessageStatus failed-' . IShortMessage::$errCode . '-' . IShortMessage::$errMsg);
		return  array('errno' => 2);
	}
	return  array('errno' => 0);

}

//������ʾ
function _output_error($str, &$TPL) {
	$TPL->set_var('content', '<div class="i_content" style="text-align:center">' . $str . '</div>');
	$TPL->out();
}

function _utf8ToGbk($data) {
	if(is_object($data)){
		$data = get_object_vars($data);
	}
	if(is_array($data)){
		$ret = array();
		foreach($data as $key => &$val){
	 		$key = iconv('UTF-8', 'GBK', $key);
			$ret[$key] = _utf8ToGbk($val);
		}
		return $ret;
	} else if(is_string($data)){
		return iconv('UTF-8', 'GBK', $data);
	} else {
		return $data;
	}
}

function _gbkToUtf8($data){
	if(is_object($data)){
		$data = get_object_vars($data);
	}
	if(is_array($data)){
		$ret = array();
		foreach($data as $key => &$val){
	 		$key = iconv('GBK', 'UTF-8', $key);
			$ret[$key] = _gbkToUtf8($val);
		}
		return $ret;
	} else if(is_string($data)){
		return iconv('GBK', 'UTF-8', $data);
	} else {
		return $data;
	}
}