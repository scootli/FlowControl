<?php
require_once(PHPLIB_ROOT . 'api/distribution/IBUser.php');  
require_once(PHPLIB_ROOT . 'api/distribution/IBSailReport.php');  
Logger::init();

/**
 * 
 */
function page_bsailreport_page()
{
	$uid = ToolUtil::checkLoginOrRedirect();

	$TPL = TemplateHelper::getBaseTPL(0, 'b_sail_report', array(
        'titleDesc' => '���۱���'
        ));

    $TPL->set_file(array(
        'contentHandler' => 'b_sail_report.tpl'
        ));
    $TPL->set_var('pageName','���۱���');
    $TPL->set_var('shop_info',ToolUtil::gbJsonEncode(_getShop($uid)));
	$TPL->parse('content', 'contentHandler');
	
	$TPL->out();
}

/**
 * json ��ȡ��ѯ��Ϣ 
 */
function  bsailreport_search()
{
    $uid = ToolUtil::checkLoginOrRedirect();
    if (!isset($_POST['uid']) || $_POST['uid'] != $uid)
    {
        return array('errno' => 1);
    }
    $page = isset($_POST['page']) ? intval($_POST['page']) : 1 ;
    $pageSize =  isset($_POST['pagesize']) ? intval($_POST['pagesize']) : 12 ;
    $_POST['retailerId'] = $uid;
    $ret = IBSailReport::getSailReport($_POST, $page, $pageSize);
    
    if (false === $ret)
    {
    	//Logger::debug(IBSailReport::$errMsg);
    	Logger::err("IBSailReport::getSailReport faild-" . IBSailReport::$errCode . "-" . IBSailReport::$errMsg . basename(__FILE__, '.php') . " |" . __LINE__ );
        return array('errno' => 2);
    }
    
    foreach ($ret['data'] as $key => &$cell)
    {
    	$sname = '';
    	$shopname = IBUser::getShopDetail($uid,$cell['shop_id']);
    	if (false != $shopname && count($shopname)!=0)
    	{
    	   $sname = $shopname['shopName'];
    	}
        $ret['data'][$key]['shop_name'] = $sname;
        if (null == $cell['ShopGuideCost'] || 'null' == $cell['ShopGuideCost'])
        {
           $ret['data'][$key]['ShopGuideCost'] = '--';
        }
        $ret['data'][$key]['TotalFee'] = sprintf("%.2f",$cell['TotalFee']) ;
        $ret['data'][$key]['profit'] = sprintf("%.2f",$cell['profit']) ;
    }
    return array(
        'errno' => 0,
        'data' => $ret['data'], 
        'total' => $ret['total'] ,
        'total_quantity'=> $ret['total_quantity'],
        'total_fee' => $ret['total_fee'],
        'total_shopguidcost' =>$ret['total_shopguidcost'] ,
        'pages' => ceil($ret['total']/$pageSize)
    );
}

//������
function  page_bsailreport_output()
{
    $uid = ToolUtil::checkLoginOrRedirect();
    if (!isset($_REQUEST['uid']) || $_REQUEST['uid'] != $uid)
    {
        return array('errno' => 1);
    }
 
    $conditions ['retailerId'] = $_REQUEST ['uid'];

	if (isset($_REQUEST['shopId']) && '' != $_REQUEST['shopId']) {
        $conditions ['shopId'] = $_REQUEST ['shopId'];
    }
	if (isset($_REQUEST['account']) && '' != $_REQUEST['account']) {
        $conditions ['account'] = $_REQUEST ['account'];
    }
	
	if (isset($_REQUEST['brandName']) && '' != $_REQUEST['brandName']) {
        $conditions ['brandName'] = $_REQUEST ['brandName'];
    }
	if (isset($_REQUEST['productName']) && '' != $_REQUEST['productName']) {
        $conditions ['productName'] = $_REQUEST ['productName'];
    }
	if (isset($_REQUEST['timeFrom']) && '' != $_REQUEST['timeFrom']) {
        $conditions ['timeFrom'] = $_REQUEST ['timeFrom'];
    }
	if (isset($_REQUEST['timeTo']) && '' != $_REQUEST['timeTo']) {
        $conditions ['timeTo'] = $_REQUEST ['timeTo'];
    }
	$searchfield = $_REQUEST ['searchfield'];
    $rs= IBSailReport::getExcel($conditions);
	if($rs == false)
	{
		exit;
	}
	
	if($searchfield ==0)
	{
		$total_quantity=0;
		$total_cost=0;
		$total_fee=0;
		$tmp = time();
		$sheettime = date('YmdHis',$tmp);
		$outputFileName =  'mendian-'.$sheettime.'.xlsx';

		$objPHPExcel = new PHPExcel();
	
		$objPHPExcel ->setActiveSheetIndex(0)
					 ->setCellValue('A1',iconv('GBK','UTF-8','�ŵ�����'))
					 ->setCellValue('B1',iconv('GBK','UTF-8','��������'))
					 ->setCellValue('C1',iconv('GBK','UTF-8','�����ܶ�'))
					 ->setCellValue('D1',iconv('GBK','UTF-8','�����ܶ�'))
					 ->setCellValue('E1',iconv('GBK','UTF-8','ë��'))
					 ->setCellValue('F1',iconv('GBK','UTF-8','ë����'));
					 
	//iconv('GBK','UTF-8',"�ŵ�����")							
		foreach($rs as $k => $v){
					$mendian=IBUser::getShopDetail($uid,$v['shop_id']);
				   $num=$k+2;
				   $objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, iconv('GBK','UTF-8',$mendian['shopName']))   
									  ->setCellValue('B'.$num, $v['Quantity'])
									  ->setCellValue('C'.$num, $v['TotalFee'])
									  ->setCellValue('D'.$num, $v['ShopGuideCost'])
									  ->setCellValue('E'.$num, $v['profit'])
									  ->setCellValue('F'.$num, $v['ProfitRate']);
									  $total_quantity=$total_quantity+$v['Quantity'];
									  $total_cost=$total_cost+$v['TotalFee'];
									  $total_fee=$total_fee+$v['ShopGuideCost'];
		}
	$objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, iconv('GBK','UTF-8',"�ϼ�"))    
									  ->setCellValue('B'.$num, $total_quantity)
									  ->setCellValue('C'.$num, $total_cost)
									  ->setCellValue('D'.$num, $total_fee)
									  ->setCellValue('E'.$num, '--')
									  ->setCellValue('F'.$num, '--');
									  
	$objPHPExcel->getActiveSheet()->setTitle($sheettime);
	$objPHPExcel->setActiveSheetIndex(0);
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header('Content-Disposition: attachment;filename='.$outputFileName);
	header('Cache-Control: max-age=0');
	
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save('php://output');
	exit;
	
	}
	else if($searchfield ==1)
	{
		$total_quantity=0;
		$total_cost=0;
		$total_fee=0;
		$tmp = time();
		$sheettime = date('YmdHis',$tmp);
		$outputFileName =  'dingdan-'.$sheettime.'.xlsx';

		$objPHPExcel = new PHPExcel();
	
		$objPHPExcel ->setActiveSheetIndex(0)
					 ->setCellValue('A1',iconv('GBK','UTF-8','�������'))
					 ->setCellValue('B1',iconv('GBK','UTF-8','�ŵ�����'))
					 ->setCellValue('C1',iconv('GBK','UTF-8','�µ�ʱ��'))
					 ->setCellValue('D1',iconv('GBK','UTF-8','�����ܼ�'))
					 ->setCellValue('E1',iconv('GBK','UTF-8','�����ܼ�'))
					 ->setCellValue('F1',iconv('GBK','UTF-8','ë��'))
					 ->setCellValue('G1',iconv('GBK','UTF-8','ë����'));
	//iconv('GBK','UTF-8',"�ŵ�����")							
		foreach($rs as $k => $v){
					$mendian=IBUser::getShopDetail($uid,$v['shop_id']);
				   $num=$k+2;
				   $objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, $v['SOID'])    
									  ->setCellValue('B'.$num, iconv('GBK','UTF-8',$mendian['shopName']))
									  ->setCellValue('C'.$num, $v['OrderDate'])
									  ->setCellValue('D'.$num, $v['TotalFee'])
									  ->setCellValue('E'.$num, $v['ShopGuideCost'])
									  ->setCellValue('F'.$num, $v['profit'])
									  ->setCellValue('G'.$num, $v['ProfitRate']);
									 $total_cost=$total_cost+$v['TotalFee'];
									  $total_fee=$total_fee+$v['ShopGuideCost'];
		}
		
		$objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, iconv('GBK','UTF-8',"�ϼ�"))    
									  ->setCellValue('B'.$num, '--')
									  ->setCellValue('C'.$num, '--')
									  ->setCellValue('D'.$num, $total_cost)
									  ->setCellValue('E'.$num, $total_fee)
									  ->setCellValue('F'.$num, '--')
									  ->setCellValue('G'.$num, '--');
									  
		$objPHPExcel->getActiveSheet()->setTitle($sheettime);
		$objPHPExcel->setActiveSheetIndex(0);
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename='.$outputFileName);
		header('Cache-Control: max-age=0');
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
	}
	else if($searchfield ==2)
	{
		$total_quantity=0;
		$total_cost=0;
		$total_fee=0;
		$tmp = time();
		$sheettime = date('YmdHis',$tmp);
		$outputFileName =  'pinpai-'.$sheettime.'.xlsx';

		$objPHPExcel = new PHPExcel();
	
		$objPHPExcel ->setActiveSheetIndex(0)
					 ->setCellValue('A1',iconv('GBK','UTF-8','Ʒ��'))
					 ->setCellValue('B1',iconv('GBK','UTF-8','��������'))
					 ->setCellValue('C1',iconv('GBK','UTF-8','�����ܶ�'))
					 ->setCellValue('D1',iconv('GBK','UTF-8','�����ܶ�'))
					 ->setCellValue('E1',iconv('GBK','UTF-8','ë��'))
					 ->setCellValue('F1',iconv('GBK','UTF-8','ë����'));
					 
	//iconv('GBK','UTF-8',"�ŵ�����")							
		foreach($rs as $k => $v){
					$mendian=IBUser::getShopDetail($uid,$v['shop_id']);
				   $num=$k+2;
				   $objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, iconv('GBK','UTF-8',$v['ManufacturerName']))
									  ->setCellValue('B'.$num, $v['Quantity'])
									  ->setCellValue('C'.$num, $v['TotalFee'])
									  ->setCellValue('D'.$num, $v['ShopGuideCost'])
									  ->setCellValue('E'.$num, $v['profit'])
									  ->setCellValue('F'.$num, $v['ProfitRate']);
									   $total_quantity=$total_quantity+$v['Quantity'];
									  $total_cost=$total_cost+$v['TotalFee'];
									  $total_fee=$total_fee+$v['ShopGuideCost'];
		}
		$objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, iconv('GBK','UTF-8',"�ϼ�"))    
									  ->setCellValue('B'.$num, $total_quantity)
									  ->setCellValue('C'.$num, $total_cost)
									  ->setCellValue('D'.$num, $total_fee)
									  ->setCellValue('E'.$num, '--')
									  ->setCellValue('F'.$num, '--');

		$objPHPExcel->getActiveSheet()->setTitle($sheettime);
		$objPHPExcel->setActiveSheetIndex(0);
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename='.$outputFileName);
		header('Cache-Control: max-age=0');
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
	}
	else if($searchfield ==3)
	{
		$total_quantity=0;
		$total_cost=0;
		$total_fee=0;
		$tmp = time();
		$sheettime = date('YmdHis',$tmp);
		$outputFileName =  'shangpin-'.$sheettime.'.xlsx';

		$objPHPExcel = new PHPExcel();
	
		$objPHPExcel ->setActiveSheetIndex(0)
					 ->setCellValue('A1',iconv('GBK','UTF-8','��Ʒ'))
					 ->setCellValue('B1',iconv('GBK','UTF-8','�����۸�'))
					 ->setCellValue('C1',iconv('GBK','UTF-8','��������'))
					 ->setCellValue('D1',iconv('GBK','UTF-8','�����ܶ�'))
					 ->setCellValue('E1',iconv('GBK','UTF-8','�����ܶ�'))
					 ->setCellValue('F1',iconv('GBK','UTF-8','ë��'))
					 ->setCellValue('G1',iconv('GBK','UTF-8','ë����'));
					 
	//iconv('GBK','UTF-8',"�ŵ�����")							
		foreach($rs as $k => $v){
					$mendian=IBUser::getShopDetail($uid,$v['shop_id']);
				   $num=$k+2;
				   $objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, iconv('GBK','UTF-8',$v['ProductName']))
									  ->setCellValue('B'.$num, $v['cost'])
									  ->setCellValue('C'.$num, $v['Quantity'])
									  ->setCellValue('D'.$num, $v['TotalFee'])
									  ->setCellValue('E'.$num, $v['ShopGuideCost'])
									  ->setCellValue('F'.$num, $v['profit'])
									  ->setCellValue('G'.$num, $v['ProfitRate']);
									   $total_quantity=$total_quantity+$v['Quantity'];
									  $total_cost=$total_cost+$v['TotalFee'];
									  $total_fee=$total_fee+$v['ShopGuideCost'];
		}
		$objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, iconv('GBK','UTF-8',"�ϼ�"))    
									  ->setCellValue('B'.$num, '--')
									  ->setCellValue('C'.$num, $total_quantity)
									  ->setCellValue('D'.$num, $total_cost)
									  ->setCellValue('E'.$num, $total_fee)
									  ->setCellValue('F'.$num, '--')
									  ->setCellValue('G'.$num, '--');

		$objPHPExcel->getActiveSheet()->setTitle($sheettime);
		$objPHPExcel->setActiveSheetIndex(0);
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename='.$outputFileName);
		header('Cache-Control: max-age=0');
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
	}
	else if($searchfield ==4)
	{
		$total_quantity=0;
		$total_cost=0;
		$total_fee=0;
		$tmp = time();
		$sheettime = date('YmdHis',$tmp);
		$outputFileName =  'zhanghao-'.$sheettime.'.xlsx';

		$objPHPExcel = new PHPExcel();
	
		$objPHPExcel ->setActiveSheetIndex(0)
					 ->setCellValue('A1',iconv('GBK','UTF-8','�˺�'))
					 ->setCellValue('B1',iconv('GBK','UTF-8','�ŵ�����'))
					 ->setCellValue('C1',iconv('GBK','UTF-8','��������'))
					 ->setCellValue('D1',iconv('GBK','UTF-8','�����ܶ�'))
					 ->setCellValue('E1',iconv('GBK','UTF-8','�����ܶ�'))
					 ->setCellValue('F1',iconv('GBK','UTF-8','ë��'))
					 ->setCellValue('G1',iconv('GBK','UTF-8','ë����'));
					 
	//iconv('GBK','UTF-8',"�ŵ�����")							
		foreach($rs as $k => $v){
					$mendian=IBUser::getShopDetail($uid,$v['shop_id']);
				   $num=$k+2;
				   $objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, $v['ShopGuideName'])    
									  ->setCellValue('B'.$num, iconv('GBK','UTF-8',$mendian['shopName']))
									  ->setCellValue('C'.$num, $v['Quantity'])
									  ->setCellValue('D'.$num, $v['cost']* $v['Quantity'])
									  ->setCellValue('E'.$num, $v['TotalFee']* $v['Quantity'])
									  ->setCellValue('F'.$num, $v['profit'])
									  ->setCellValue('G'.$num, $v['ProfitRate']);
									   $total_quantity=$total_quantity+$v['Quantity'];
									  $total_cost=$total_cost+$v['cost']* $v['Quantity'];
									  $total_fee=$total_fee+$v['TotalFee']* $v['Quantity'];
		}
		$objPHPExcel       ->setActiveSheetIndex(0)
									  ->setCellValue('A'.$num, iconv('GBK','UTF-8',"�ϼ�"))    
									  ->setCellValue('B'.$num, '--')
									  ->setCellValue('C'.$num, $total_quantity)
									  ->setCellValue('D'.$num, $total_cost)
									  ->setCellValue('E'.$num, $total_fee)
									  ->setCellValue('F'.$num, '--')
									  ->setCellValue('G'.$num, '--');

		$objPHPExcel->getActiveSheet()->setTitle($sheettime);
		$objPHPExcel->setActiveSheetIndex(0);
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename='.$outputFileName);
		header('Cache-Control: max-age=0');
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
	}
	
    
}



/**
 * ��ȡ�ŵ���Ϣ 
 */
function _getShop($retailerId)
{
    if (!isset($retailerId))
    {
        Logger::ERR(basename ( __FILE__, '.php' ) . " |" . __LINE__ . "retailer ID null" );
        
        return false;
    }
    $res = IBUser::getAllShop($retailerId);
    if (false === $res)
    {   
        return false;
    }
    $ret = array();
    $index = 0;
    foreach ($res AS $shop)
    {
        $ret[$index] = array(
            'shopName'  => $shop['shopName'],
            'shopId'    => $shop['shopId']
            );
        $index ++;
    }
    
    return $ret;
}