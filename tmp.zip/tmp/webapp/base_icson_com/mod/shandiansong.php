<?php

require_once(PHPLIB_ROOT . 'api/IUser.php');

function page_shandiansong_index(){
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'titleDesc'	=> '������',
		'cssFile' => 'http://st.icson.com/51buy_v3/css/act_help.css?v=[[v_CSS_ACT_HELP]]'
	));
	$TPL->set_file(array(
		'containerHandler'	=> 'shandiansong.tpl'
	));
	$TPL->out();
}
