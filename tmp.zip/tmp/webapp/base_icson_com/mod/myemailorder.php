<?php
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IMailOrder.php');
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');

Logger::init();

function page_myemailorder_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, 'myemailorder', array(
		'titleDesc' => '�ʼ����Ĺ���'
	));

	$TPL->set_var('pageName', '�ʼ����Ĺ���');

	$userInfo = IUser::getUserInfo($uid);
	if($userInfo === false){
		Logger::err("IUser::getUserInfo failed, code:" . IUser::$errCode . ', msg:' . IUser::$errMsg);
		return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL);
	}

	//�������� @modify by allenzhou 2012-08-10
	ToolUtil::setCurrentPageId(3, 11611520);

	$account = $userInfo['icsonid'];
	$TPL->set_file(array(
		'contentHandler' => 'myemailorder_content.tpl'
	));

	$TPL->set_var(array(
		'php_account'	=> $account,
		'php_email'	=> empty($userInfo['email']) ? '' : addslashes($userInfo['email']),// �ŵ�json�ַ����У����Խ���addslashes
		'php_bindEmail'	=> empty($userInfo['bindEmail']) ? 0 : $userInfo['bindEmail'],
	));

	$result = IMailOrder::getSettings($uid);
	if($result === false){
		Logger::err('IMailOrder::getSettings failed-' . IMailOrder::$errCode . '-' . IMailOrder::$errMsg);
		return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
	}
	//�����ʼ�����
	$order_noticeTpl = "";
	$sale_noticeTpl = "";
	if($result['OrderNotice'] != 1){
		$order_noticeTpl = '';
	}else{
		$order_noticeTpl = ' on';
	}
	$TPL->set_var('emailorder_on0',$order_noticeTpl);

	//����/��ʼ�
	for($i = 1; $i <= 6; $i ++){
		if($result['saleNotice' . $i] != 1){
			$sale_noticeTpl = '';
		}else{
			$sale_noticeTpl =' on';
		}
		$TPL->set_var('emailorder_on' . $i, $sale_noticeTpl);
	}
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}


function myemailorder_modify(){
	$uid = IUser::getLoginUid();
	if(empty($uid)){
		return array('errno' => 500);
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 11);
	}

	if(!isset($_GET['col'])){
		return array('errno' => 12);
	}
	$col = empty($_GET['col']) ? 0 : $_GET['col'];

	$value = empty($_GET['value']) ? 0 : 1;

	if($col == 0){
		$col = 'OrderNotice';
	}else if($col > 0 && $col < 7){
		$col = 'saleNotice' . $col;
	}

	$result = IMailOrder::setSettings($uid, array(
		$col	=> $value
	));

	if($result === false){
		Logger::err("IMailOrder::setSettings faild-" . IMailOrder::$errCode . "-" . IMailOrder::$errMsg);
		return array('errno' => 1);
	}
	return array('errno' => 0);
}


//������ʾ
function _output_error($str, &$TPL){
	$TPL->set_var('content', '<div class="i_content" style="text-align:center">' . $str . '</div>');
	$TPL->out();
}