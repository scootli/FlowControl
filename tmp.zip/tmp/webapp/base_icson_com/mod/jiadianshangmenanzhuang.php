<?php

require_once(PHPLIB_ROOT . 'api/IUser.php');

function page_jiadianshangmenanzhuang_index(){
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'titleDesc'	=> '�ҵ����Ű�װ',
		'cssFile' => 'http://st.icson.com/51buy_v3/css/channel_installation.css?v=[[v_CSS_ACT_HELP]]'
	));
	$TPL->set_file(array(
		'containerHandler'	=> 'jiadianshangmenanzhuang.tpl'
	));
	$TPL->out();
}
