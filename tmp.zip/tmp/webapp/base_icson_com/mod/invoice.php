<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'inc/district.inc.php');

Logger::init();

function invoice_get()
{
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}
	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}
	if (strtolower($_SERVER['REQUEST_METHOD']) != 'post') {
		return array('errno' => 1);
	}

	$wh_id = IUser::getSiteId();
	if (empty($wh_id)) {
		return array('errno' => 503);
	}

	$invoice = EA_Invoice::get($uid, array('wh_id' => $wh_id));
	if ($invoice === false) {
		Logger::err("EA_Invoice::get faild-" . EA_Invoice::$errCode . "-" . EA_Invoice::$errMsg);
		return array('errno' => 2);
	}

	$i = ($wh_id == SITE_SZ) ? SITE_SZ : SITE_ALL;
	return array(
		'errno'    => 0,
		'data'     => $invoice,
		'types'    => EA_Invoice::$whidInvoice[$i],
	);
}

function invoice_getcp()
{
	// ��ö��ƻ��Ķ��Ʊ
	if (empty($uid)) {
		return array('errno' => 500);
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	if (strtolower($_SERVER['REQUEST_METHOD']) != 'post') {
		return array('errno' => 1);
	}

	$newId = IIdGenerator::getNewId('Invoice_Sequence');
	if (false === $newId || $newId <= 0) {
		Logger::err("IIdGenerator getNewId failed,errCode:" . IIdGenerator::$errCode . ",errMsg:" . IIdGenerator::$errMsg);
		return false;
	}

	$now = time();
	$invoice[INVOICE_TYPE_CP_UNICOM] = array(
		'addr'       => "1",
		'bankname'   => "2",
		'bankno'     => "3",
		'createtime' => $now,
		'iid'        => INVOICE_TYPE_CP_UNICOM,
		'name'       => "4",
		'phone'      => "5",
		'sortfactor' => 0,
		'status'     => 0,
		'taxno'      => "6",
		'title'      => "��ͨͳһ���Ʊ",
		'type'       => INVOICE_TYPE_CP_UNICOM,
		'uid'        => $uid,
		'updatetime' => $now,
	);


	return array(
		'errno'    => 0,
		'data'     => $invoice,
	);
}

function invoice_add()
{
	$uid = IUser::getLoginUid();

	$start = time();
	Logger::info("--------invoice_add starts at $start ---------");
	Logger::info(var_export($uid, true));
	Logger::info(var_export($_GET, true));
	Logger::info(var_export($_POST, true));


	if (empty($uid)) {
		return array('errno' => 500);
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	if (!empty($_POST['type']) && $_POST['type'] == 2 && empty($_POST['name'])) {
		$_POST['title'] = $_POST['name'];
	}
	// ����POST���жϽ���api��
	$newInvoiceId = EA_Invoice::insert($uid, $_POST);
	if ($newInvoiceId === false) {
		Logger::err("EA_Invoice::insert faild-" . EA_Invoice::$errCode . "-" . EA_Invoice::$errMsg);
		return array('errno' => EA_Invoice::$errCode);
	}

	$end = time();
	$diff = $end - $start;
	Logger::info("--------invoice_add ends at $end, cost $diff---------\n");
	return array(
		'errno'    => 0,
		'data'     => $newInvoiceId,
	);
}

function invoice_modify()
{
	$uid = IUser::getLoginUid();

	$start = time();
	Logger::info("--------invoice_modify starts at $start ---------");
	Logger::info(var_export($uid, true));
	Logger::info(var_export($_GET, true));
	Logger::info(var_export($_POST, true));


	if (empty($uid)) {
		return array('errno' => 500);
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	$iid = empty($_POST['iid']) ? 0 : $_POST['iid'];
	if (empty($iid)) {
		return array('errno' => 1);
	}

	if (!empty($_POST['type']) && $_POST['type'] == 2 && empty($_POST['name'])) {
		$_POST['title'] = $_POST['name'];
	}

	$newInvoice = $_POST;
	$newInvoice['uid'] = $uid;

	// ����POST���жϽ���api��
	$newInvoiceId = EA_Invoice::update($newInvoice, array('iid'=> $iid));
	if ($newInvoiceId === false) {
		Logger::err("EA_Invoice::update faild-" . EA_Invoice::$errCode . "-" . EA_Invoice::$errMsg);
		return array('errno' => EA_Invoice::$errCode);
	}

	$end = time();
	$diff = $end - $start;
	Logger::info("--------invoice_modify ends at $end, cost $diff---------\n");
	return array(
		'errno'    => 0,
		'data'     => $newInvoiceId,
	);
}

function invoice_del()
{
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}
	$start = time();
	Logger::info("--------invoice_del starts at $start ---------");
	Logger::info(var_export($uid, true));
	Logger::info(var_export($_GET, true));
	Logger::info(var_export($_POST, true));

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	$iid = empty($_POST['iid']) ? 0 : $_POST['iid'];
	if (empty($iid)) {
		return array('errno' => 1);
	}

	$del = EA_Invoice::del($uid, $iid);
	if ($del === false) {
		Logger::err("EA_Invoice::delInvoice faild-" . EA_Invoice::$errCode . "-" . EA_Invoice::$errMsg);
		return array('errno' => 1);
	}
	$end = time();
	$diff = $end - $start;
	Logger::info("--------invoice_del ends at $end, cost $diff---------\n");

	return array('errno' => 0);
}
// End Of Script