<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'lib/Dirty.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IAlipayAuthorize.php');
require_once(PHPLIB_ROOT . 'api/IQQCBAddress.php');
require_once(PHPLIB_ROOT . 'api/ISHCarAuthorize.class.php');

require_once(PHPLIB_ROOT . 'api/ICPS.php');
require_once(PHPLIB_ROOT . 'inc/CPSConfig.inc.php');
require_once(PHPLIB_ROOT . 'api/appplatform/user_api.php');

Logger::init();



function page_registerAndLogin_ptloginqq() {
	$redirectUrl = 'http://www.51buy.com';
	if (!empty($_GET['url']) && preg_match("/^http:\/\/([^\.]+\.|)(51buy|icson)\.com($|\/)/i", $_GET['url'])) {
		$redirectUrl = $_GET['url'];
	}
	$vKey = isset( $_GET['vkey'] ) ?  $_GET['vkey'] : '';
	$time = isset($_GET['time']) ? $_GET['time'] : '';

	$message = '��¼ʧ��';

	$qq = isset( $_GET['uin'] ) ?  $_GET['uin'] : '';

	if (empty($qq) || empty( $vKey ) || empty( $time ) || !isset($_GET['nickname']) || md5($qq . $time . QQ_VALIDATE_KEY) != $vKey) {
		TemplateHelper::outMessage( $message );
		return false;
	}
	else{

		if (empty($qq) || empty($_GET['ptskey'])) {
			TemplateHelper::outMessage( $message );
			return false;
		}

		//��ֲcookie
// 		setrawcookie("pt2gguin", $_GET['pt2gguin'], 0, '/', '.51buy.com');
// 		setrawcookie("uin", $_GET['uin'], time() + 3600*24*300, '/', '.51buy.com');
// 		setrawcookie("ptskey", $_GET['ptskey'], 0, '/', '.51buy.com');

		if(_ptloginqq_autouser($qq, $qq, $_GET['nickname'])) return;

		ToolUtil::redirect($redirectUrl);
	}
}

function _ptloginqq_autouser($qq, $password, $nickname = ''){
	$message = '��¼ʧ��';
	global $_AccountType;
	global $_IP_CFG;
	if (is_array($_IP_CFG['QQ_OPENIDS'])) {
		$ip_key = array_rand($_IP_CFG['QQ_OPENIDS'], 1);
		$ip = $_IP_CFG['QQ_OPENIDS'][$ip_key];
	} else {
		$ip = $_IP_CFG['QQ_OPENIDS'];
	}

	$url = "http://".$ip.":8080/openid/decopenid.php?func=getopenidbyuin&uin=" . $qq;
    $qqinfo = NetUtil::cURLHTTPGet($url);
    $ret = json_decode($qqinfo);
    $openID = strtoupper($ret->openid);

    if (empty($openID) || $openID == 'failed' || strlen($openID) != 32) {
    	Logger::err("ptlogin get openid error," . $qq . "," . $openID);
		TemplateHelper::outMessage( $message );
		return false;
    }

	$account = QQ_ACCOUNT_PRE . '_' . $openID; // ��ID�м�����һ���»���
	$clientIp = ToolUtil::getClientIP();
	/*$exists = IUser::checkIcsonAccountExist($account);
	if ($exists === false) {
		Logger::err("user_loginqq IUser::checkIcsonAccountExist failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}

	$clientIp = ToolUtil::getClientIP();
	if ($exists['exist'] == 0) {
		$isNew = true;
		$item = IUsersQqMapTTC::get($qq);
		if(false===$item){
			Logger::err("Check IUsersQqMapTTC  fail. qq: $qq, " . IUsersQqMapTTC::$errCode . ": " . IUsersQqMapTTC::$errMsg);
			TemplateHelper::outMessage($message);
			return false;
		}
		if(count($item)==1){
			$icsonAccount = IUsersTTC::get($item[0]['uid']);
			if(false===$icsonAccount){
				Logger::err("Check IUsersTTC fail. uid: $item[0]['uid']");
				TemplateHelper::outMessage($message);
				return false;
			}
			if(count($icsonAccount)==1){
				$isNew = false;
				$icsonId = $icsonAccount[0]['icsonid'];
				setrawcookie("__BINDQQACCOUNT", 'true', 0, '/', '.51buy.com');
			}
		}
	}

        // ���û�а󶨵���Ѹ�˺���ִ��ע���߼�
        if($isNew){
        //if (!isset($icsonId)) {
			$email = '';

			$regSrc = empty($_COOKIE['us']) ? '' : $_COOKIE['us'];
					$userData = array(
					'email' => $email,
					'regIP' => $clientIp,
					'warehouseId' => IUser::getSiteId(),
					'source' => $regSrc
				);
			$register = IUser::register($account, "123456".$password, $userData);
			if ($register === false) {
				if(IUser::$errCode != 10303){ // �ظ�key���ɳɹ�
					Logger::err("user_loginqq IUser::register failed-" . IUser::$errCode . '-' . IUser::$errMsg);
					TemplateHelper::outMessage( $message );
					return false;
				}
			}
			// ��Ϣһ�� ��������login�ᱨ��
			// ��Ҫ��һ���Ż������������������
// 			sleep(1);
			//���õ����ݽӿ�,��Ѹid����Ѹ����
			//UserWg::ImportCopartnerUserInfo($register, $qq, 3);				
        }
*/
	$ptskey = $_GET['ptskey'];
	$account = $_GET['account'];
	$registerResult = UserWg::IcsonUniformLogin($_AccountType['qq'], $qq, $ptskey);

// 	$session = IUser::login($account, $password, $clientIp, 1, 3, true, $qq, $ptskey);
	if ($registerResult === false) {
		Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}
	$session = array('uid' => $registerResult->icsonUid, 'skey' => $registerResult->skey, 'wg_skey' => $registerResult->skey);
	
	//�ϱ���¼
	_registerReport(4, $session['uid'], $account);

	setrawcookie("QQACCT", $openID, 0, '/', '.51buy.com');
	setrawcookie("new_u", false, 1, '/', '.51buy.com');
	$user = IUser::getUserInfo($session['uid']);
	if ($user === false) {
		Logger::err("IUser::getUserInfo failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		TemplateHelper::outMessage( $message );
		return false;
	}
	else if (isset($user['exp_point'])  && $user['exp_point'] <= 0) { //�������û�cookie
		setrawcookie("new_u", '1', 0, '/', '.51buy.com');
	}

	setrawcookie("uid", $session['uid'], 0, '/', '.51buy.com');
	setrawcookie("skey", $session['skey'], 0, '/', '.51buy.com');
	setrawcookie("yx_uid", $session['uid'], time() + 3600*24*600, '/', '.51buy.com');
	setrawcookie("yx_uin", $qq, time() + 3600*24*600, '/', '.51buy.com');
	//������˫д��ʱ�����wg_skey
	if(!empty($session['wg_skey'])){
		setrawcookie("wg_skey", $session['wg_skey'], 0, '/', '.51buy.com');
	}
	

	setrawcookie("qq_nick", $session['uid'] . '|' . ToolUtil::escape($nickname), 0, '/', '51buy.com');

	//���QQ tips��������������֤��Ϣ
	if (isset($_GET['key'])) {
		if ((substr(md5($openID . "icson@qq"), 0 , 6) != $_GET['key'])) {
			TemplateHelper::outMessage( array("�Բ����������ϲμӴ˻������", '<a href="http://www.51buy.com">�ص���Ѹ��ҳ</a>') );
			return false;
		}
		else {
			setrawcookie("edm_key", $_GET['key'], 0, '/', '.51buy.com');
		}
	}
}

/**
 * 1. ����ע�����
 * 2. �ύע��
 * 3. �����¼����
 * 4. �ύ��¼
 * 5. ��ȡ��֤��
 * 6. �ύ��֤��
 * $_IP_CFG['USER_REGISTER_REPORT'] =  array(
		array('IP' => '10.191.8.44', 'PORT' => 59891),
		array('IP' => '10.191.8.44', 'PORT' => 59891)
	);
 */
function _registerReport($type, $uid=0, $account=0,$session="")
{
    $userIP = ToolUtil::getClientIP();
    $visitKey = isset($_COOKIE["visitkey"]) ? $_COOKIE["visitkey"] : "";
//     $verifysession = isset($_COOKIE["verifysession"]) ? $_COOKIE["verifysession"] : $session;
    $verifysession = !empty($session) ? $session :(isset($_COOKIE["verifysession"])?$_COOKIE["verifysession"]:"");
    $report = array(
                "user_id"=> $uid,
                "account"=> $account,
                "log_type"=>$type,
                "time" => time(),
                "verifysession" => $verifysession,
                "visitkey"=> $visitKey,
                "ip"=>$userIP
            );
    $req = json_encode($report);
    $address = Config::getIP('USER_REGISTER_REPORT');
    if(!$address)
    {
        Logger::err("_registerReport Get Ip Error:".print_r($address,true));
    }
    //�������ʵ��������ȷ��
    $ip = $address[0]["IP"];
    $port = $address[0]["PORT"];
    $resp = NetUtil::udpCmd($ip, $port, $req, false);
    if($resp === false)
    {
        Logger::err("_registerReport Send Msg Error");
    }
    return;
}
// End Of Script