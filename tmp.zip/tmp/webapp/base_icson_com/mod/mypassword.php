<?php
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/NetUtil.php');
require_once(PHPLIB_ROOT . 'lib/Dirty.php');
require_once(PHPLIB_ROOT .'lib/Config.php');
require_once(PHPLIB_ROOT . 'inc/constant.inc.php');
require_once('../api/IVerifyUserIdentity.php');

$_TTC_CFG['IVerifyUserIdentityTTC']['TTCKEY']	= 'IVerifyUserIdentityTTC';
$_TTC_CFG['IVerifyUserIdentityTTC']['TABLE']	= 't_user_verify_';
$_TTC_CFG['IVerifyUserIdentityTTC']['TimeOut']	= 1;
$_TTC_CFG['IVerifyUserIdentityTTC']['KEY']		= 'uid';
$_TTC_CFG['IVerifyUserIdentityTTC']['FIELDS']	= array();//�������ͣ�int=1,string=2,binary=3
$_TTC_CFG['IVerifyUserIdentityTTC']['FIELDS']['uid'] = array('type' => 1, 'min'=> 0, 'max' => 4294967295);
$_TTC_CFG['IVerifyUserIdentityTTC']['FIELDS']['mobile'] = array('type' => 2, 'min' => 0, 'max' => 32);
$_TTC_CFG['IVerifyUserIdentityTTC']['FIELDS']['code'] = array('type' => 2, 'min' => 0, 'max' => 10);
$_TTC_CFG['IVerifyUserIdentityTTC']['FIELDS']['time'] = array('type' => 1, 'min' => 0, 'max' => 4294967295);

define('VERIFY_CODE_TYPE_MOBILE_NEW', 2);
define('MOBILE_VERIFY_CODE_VALID_TIME_NEW', 600);
define( 'POINTLINE', 0);

Logger::init();
function _insertUserStatus($uid, $arrayRConfig){
	$ttc = Config::getTTC('IVerifyUserIdentityTTC');
	if(!$ttc)
	{
		return false;
	}
	$need = array(
		"uid"=>0,
		"mobile"=>"",
		"code"=>"",
		"time"=>""
	);
	$ret = $ttc->get($uid);
        
	if($ret === false)
	{
             
		$ret = $ttc->insert($arrayRConfig);
	}
	else
	{
              
                $ret =$ttc->delete($uid);
                Logger::info('$ret'.print_r($ret, true));
                if($ret!==false)
                    $ret = $ttc->insert($arrayRConfig);
                else
                    return false;
	}
	
	if(false === $ret)
	{
		return false;
	}
	Logger::info('_insertUserStatusTTC'.print_r($ret, true));
	return true;
}
function _deleteUserStatus($uid){
        $ttc = Config::getTTC('IVerifyUserIdentityTTC');
	if(!$ttc)
	{
		return false;
	}
       
	$ret=$ttc->delete($uid);
        if($ret===false)
        {
            Logger::info('_checkUserStatus TTC 3'.print_r($ret, true));
            return false;
        }
	return true;
		
}

function _checkUserStatus($uid){
	$ttc = Config::getTTC('IVerifyUserIdentityTTC');
	if(!$ttc)
	{
		return false;
	}
	$need = array(
			"uid"=>0,
			"mobile"=>"",
			"code"=>"",
			"time"=>""
		);
	$ret = $ttc->get($uid);
	Logger::info('_checkUserStatus TTC'.print_r($ret, true));
	if($ret === false)
	{
		Logger::info('_checkUserStatus TTC 1'.print_r($ret, true));
		return false;
	}
	else if(count($ret) > 0)
	{
		$ret = $ret[0];
		if($ret['uid'] != $uid|| (time() - $ret['time'] > MOBILE_VERIFY_CODE_VALID_TIME_NEW)
			)
		{
			Logger::info('_checkUserStatus TTC 2'.print_r($ret, true)." UID:".$uid." time:".time());
			return false;
		}
		return true;
	}
	else
	{
		return false;
	}
}


/*************add cmem *************




//tmem�����û�״̬
function getTMem() {
	
	$tm = Config::getTMem("user_verify");
	return $tm;
}
function insertTmem($Bid, $tmemHandle, $uid, $arrayRConfig)
{
	$strKey = $uid;
	$strValue = json_encode($arrayRConfig);
	
	$ret = $tmemHandle->set($Bid, $strKey, $strValue);
	Logger::info("insertTmem [".$strKey."][".$strValue."]" . $ret);
	return $ret;
}
//_insertUserStatus($uid, array('uid'=>$uid, 'mobile'=>$mobile, 'code'=>$code, 'time'=>time()));
function _insertUserStatus($uid, $arrayRConfig){
       
	$tmemHandle = getTMem();
	if($tmemHandle === false)
	{
		Logger::info("commodityRemove tmem ��ʼ��ʧ����ֱ�ӷ��أ�");
		return false;
	}
        
	$result = insertTmem(VERIFY_IDENTITY_BID, $tmemHandle, $uid, $arrayRConfig);
        if($result)
            return true;
        else
            return false;
}
function _checkUserStatus($uid){
       
	$tmemHandle = getTMem();
	if($tmemHandle === false)
	{
		Logger::info("commodityRemove tmem ��ʼ��ʧ����ֱ�ӷ��أ�");
		return false;
	}
	$strKey = $uid;
        
	$ret = $tmemHandle->get(VERIFY_IDENTITY_BID, $strKey);
	if(!$ret)
	{
		return false;
	}
	else
	{
		$userStatus = json_decode($ret);
		if((time() - $userStatus['time'] > MOBILE_VERIFY_CODE_VALID_TIME_NEW))
		{
			return false;
		}
		return true;
	}


}


function delTmem($Bid, $tmemHandle, $arrKey)
{
	$result = array(
	    "data" => "",
	    "errorCode" => 0
	    );
	$strKey = implode("", $arrKey);
	$ret = $tmemHandle->del($Bid, $strKey);
	Logger::info("delTmem [".$strKey."][".print_r($tmemHandle, true)."]" . $ret);
	if(!$ret)
	{
		$result["errorCode"] = $tmemHandle->errno();
	}
	return $result;
}


************add cmem **************/




function _verfyUser($userOldInfo)
{
                $userIP = ToolUtil::getClientIP();
                $request=array(
                   "scene_id"=>100,
                   "time"=>time(),
                    "user_id"=> $userOldInfo["uid"],
                    "ip"=>$userIP,
                    "vk"=>$_COOKIE["visitkey"],
                    "wireless"=>0,
                    "total_point"=>$userOldInfo["point"],     // ������������λ���� ABC
                    "deal_id"=>0,           // Ĭ�� A
                    "name"=>"",         // �ռ������� A
                    "address"=>array(),            // �ռ��˵�ַ A
                    "mobile"=>"",
                    "total_fee"=>0,     // ������ ��λ�� A
                    "point_pay"=>0      // ʹ�û��ָ���      
                );
                
                $req=json_encode($request);
                $address = Config::getIP('VERIFY_IDENTITY');
               Logger::info("ip get err".print_r($address,true));
                if(!$address)
                {
                    Logger::info("ip get err".print_r($address,true));
                    return false;
                }
                if($userOldInfo["uid"]%2==0)
                {
                    $ip = $address[0]["IP"];
                    $port = $address[0]["PORT"];
                }
                else
                {
                    $ip = $address[1]["IP"];
                    $port = $address[1]["PORT"];
                }
                  
                Logger::info("ip :".$ip."  port:".$port);
                $response=NetUtil::udpCmd( $ip,$port,$req);
                //$reaponse="{ \"need_verify\" : 1,\"trusted_mobile_list\":[\"15806123251\", \"15806123252\", \"15806123255\"] }";
                 Logger::info("response:".print_r($response,true));
                $response=json_decode($response,true);
                //$response["need_verify"]=1;
                //$response["trusted_mobile_list"]=array();
                $response2=json_encode($response);
                return $response2;
}

//�Ӱ��ֻ����߿����ֻ���ȡ���������ֻ�
function  _getRightMobile($mobile,$bindmobile,$verfyMobile)
{
    $pattern = "/(1\d{2})\d{4}(\d{4})/";
    $replacement = "\$1****\$2";
    $realMobile=0;
    
    if(empty($bindmobile)||$bindmobile==0 )//û�а��ֻ�
        $realMobile=0;
    else
    {   
        
        if($mobile == preg_replace($pattern, $replacement, $bindmobile))
        { 
            
            $realMobile=$bindmobile;
        }       
    }
    foreach($verfyMobile as $value)
    {
        if(ToolUtil::checkMobilePhone($value))
	{
            //Logger::info("---------mobile:".$mobile." value:".$value);
            if($mobile == preg_replace($pattern, $replacement, $value))
            {
               // Logger::info("realMobile:".$realMobile." value:".$value);
                $realMobile=$value;                
                break;
            }
	}
    }
    
    return $realMobile;
}


function page_mypassword_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, "mypassword", array(
		'titleDesc' => '��¼�������',
		'SSL' => false
	));

	$TPL->set_var(array(
		'pageName'	=> '��¼�������',
	));


	$validateRes = IUser::validateUserFromQQ($uid);

	if( false === $validateRes){
		return _output_error("��ȡ����ʧ�ܣ����Ժ�ˢ�����ԣ�", $TPL);
	}

	if($validateRes['validate'] == false){
		$validateRes = IUser::validateUserFromALI($uid);
	}

	if( false === $validateRes){
		return _output_error("��ȡ����ʧ�ܣ����Ժ�ˢ�����ԣ�", $TPL);
	}
	if( true === $validateRes['validate'] ){
		ToolUtil::redirect("http://base.51buy.com/index.html");
		return;
	}

	$TPL->set_file(array(
		'contentHandler' => 'mypassword_content.tpl'
	));

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}


function page_mypassword_modify(){
	$uid = IUser::getLoginUid();
	if( $uid == 0 )
	{
		ToolUtil::redirect("https://base.51buy.com/login.html");
		return;
	}         
         
	$html = <<<EOT
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
</head>

<style type="text/css">
    /* layer optimize */
    .layer_global {box-shadow:2px 2px 4px rgba(0,0,0,0.4);}
    .layer_global_cont {zoom:1;_position:relative;}
    .layer_global .layer_global_mod .icon_msg3 { position:absolute;left:52px;}
    .layer_global .layer_desp {margin-top:5px;}
    .layer_global .layer_btn_wrap {margin-top:10px;}

    .co_gray {color:#888;}

    /* mini layer */
    .layer_mini {width:220px;height:80px;border:2px solid #DAE7F3;background-color:#fff;box-shadow:2px 2px 3px rgba(0,0,0,0.3);}
    .layer_mini_cont {zoom:1;overflow:hidden;padding:25px 0px 0px 50px;}
    .layer_mini_cont .icon {float:left;width:32px;margin-right:15px;}
    .layer_mini_cont .cont {float:left;font:700 14px/32px "\5FAE\8F6F\96C5\9ED1",Arial;}

    /* hint msg optimize */
    .para_inb {vertical-align:middle;padding-top:3px;padding-bottom:0px;_padding-top:5px;_padding-bottom:2px;}
    .para_inb .icon {vertical-align:-2px;display:inline-block;}

    /* �ֻ���֤���� */
    .phone_validate {margin-top:10px;padding-left:120px;}
    .phone_validate_direct {padding-left:5px;margin-top:0px;}
    .ph_va_line {clear:both;display:block;overflow:hidden;font-size:0px;width:100%;height:1px;background-color:#ddd;}
    .ph_va_guide {font:700 14px/25px Arial;padding-top:10px;}
    .ph_va_row {padding-top:10px;}
    .pvr_hd {height:25px;color:#000;}
    .pvr_bd {line-height:25px;}
    .phone_validate .input_short {border:1px solid #aaa;box-shadow:inset 2px 2px 2px #ddd;}
    .phone_validate .input_phone_number {width:150px;}
    .phone_validate .layer_btn_wrap a {margin-right:8px;}
    .link_request_yzm:link,
    .link_request_yzm:visited {color:#317EE7;}
    .link_request_yzm:hover {color:#317EE7;}

</style>
<link href="https://st.51buy.com/static_v1/css/package/package_v1.css" rel="stylesheet" type="text/css" />
<link href="https://st.51buy.com/static_v1/css/mycenter/mycenter.css" rel="stylesheet" type="text/css" />
<link href="https://st.51buy.com/51buy_v3/css/gb.css?v=2012053101" rel="stylesheet" type="text/css" />
<script type="text/javascript">document.domain="51buy.com";</script>
<script type="text/javascript" src="https://st.51buy.com/static_v1/js/jquery-1.5.1.min.js" charset="gb2312"></script>
<script type="text/javascript" src="https://st.51buy.com/static_v1/js/global.js?v=2012053101" charset="gb2312"></script>
<script type="text/javascript" src="https://st.51buy.com/static_v1/js/app/mycenter.mypassword.js?v=2013011803" charset="gb2312"></script>
<div class="i_content wrap_mycenter">
	<div class="mod_kong id_mod_password" id="password_box">
		<div class="mod_hd">
			<h3 style='margin-left:20px;'>��¼�������</h3>
		</div>
		<div class="mod_bd">
			<ul class="list_info">
				<li><span class="tit"><span class="strong">*</span>������</span><input type="password" class="input_short" name="oldpassword" />
				<span class="nor">������ʹ�õ�����</span><span t="oldpassword"></span></li>
				<li><span class="tit"><span class="strong">*</span>������</span><input type="password" class="input_short" name="newpassword" />
				<span class="nor">�����룬6-16λ���֡���ĸ���߷��ţ�������ʹ��</span> <span t="newpassword"></span></li>
				<li><span class="tit"><span class="strong">*</span>ȷ������</span><input type="password" class="input_short" name="newpassword2" />
				<span class="nor">���ٴ�����������</span><span t="newpassword2"></span></li>
				<li><a class="btn_common" t="submit">�޸�����</a></li>
			</ul>
		</div>
	</div>
</div>
EOT;
        
           
 
        $userOldInfo = IUser::getUserInfo($uid);
       // logger::info("".print_r($userOldInfo,true));
        if($userOldInfo === false||$userOldInfo["point"]==POINTLINE)//�ӿڵ��ò���ȷ
        {
             $scripthtml= <<<EOT
           
                    <script type="text/javascript">

                    $(document).ready(function(){
                            G.app.mycenter.mypassword.init();
                    });

                    </script>
EOT;


            echo $html."".$scripthtml;
        }
        else    
        {
		 $pattern = "/(1\d{2})\d{4}(\d{4})/";
                 $replacement = "\$1****\$2";
                $response=  _verfyUser($userOldInfo);
               // logger::info("".print_r($response,true));
                if($response!==false)
                {    
                    
                    $response=  json_decode($response,true);
                    $bindmobile="0";
                    if(!empty($userOldInfo["bindMobile"])&&$userOldInfo["bindMobile"]!=0 )//�а��ֻ�
                        $bindmobile=preg_replace($pattern, $replacement, $userOldInfo["mobile"]);
                   
                     //������ǰѰ��ֻ����߼��ŵ�ǰ����
                    
                     for ($i=0;$i<count($response["trusted_mobile_list"]);$i++) {//��ɸ����Ǻ�
                         $response["trusted_mobile_list"][$i]=preg_replace($pattern, $replacement, $response["trusted_mobile_list"][$i]);
                     }
                     $hasStatus=0;
                     if(_checkUserStatus($uid))
                     {
                         $hasStatus=1;
                     }
                     
                    $scripthtml=" <script type=\"text/javascript\"> 
                         var response=".json_encode($response).";
                          var isbindmobind='$bindmobile'; 
                          var hasStatus=".$hasStatus.";
                        $(document).ready(function(){
                           G.app.mycenter.mypassword.init();
                    });

                    </script>";
                     echo $html."".$scripthtml;
                }
                else
                {    
                    
                    $scripthtml= <<<EOT
           
                    <script type="text/javascript">

                    $(document).ready(function(){
                            G.app.mycenter.mypassword.init();
                    });

                    </script>
EOT;
                    echo $html."".$scripthtml;
                }
	}
    
        
}

function mypassword_modify(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		return array('errno' => 500);
	}
        $userOldInfo = IUser::getUserInfo($uid);
        Logger::info("".print_r($userOldInfo, true));
        if($userOldInfo === false||$userOldInfo["point"]==POINTLINE)//�ӿڵ��ò���ȷ���߻���Ϊ0
        {
            //����ʲô������
        }
        else
        {
            $response=  _verfyUser($userOldInfo);
            Logger::info("&&&&".$response);
            if($response!==false)//�ӿڹ��˻�Ź�
            {    
                $response=  json_decode($response,true);
                Logger::info("".print_r($response,true));
               
                if($response["need_verify"]===0)//����Ҫ��֤��ʲô���붼����д
                {          
                   //����Ҫ��֤��ʲô���붼����д
                }
                else//Ҫ��֤��
                {
                   
                    $bindMobile=0;
                    if(!empty($userOldInfo["bindMobile"])&&$userOldInfo["bindMobile"]!=0 )//�а��ֻ�
                    { 
                        $bindMobile=$userOldInfo["mobile"];
                    } 
                                           
                    $result=_checkUserStatus($uid);//�����û������ʹ��״̬����
                    if($result===false)
                    {
                        Logger::err("_checkUserStatus failed,userid:".$uid );
                        return array('errno' => 6001);
                    }
                }    
            }       
        }    
	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 501);
	}

	if(empty($_POST['oldpassword'])){
		return array('errno' => 11);
	}

	$oldPass = $_POST['oldpassword'];

	if(empty($_POST['newpassword'])){
		return array('errno' => 12);
	}

	if(empty($_POST['newpassword2'])){
		return array('errno' => 13);
	}

	if($_POST['newpassword'] != $_POST['newpassword2']){
		return array('errno' => 14);
	}

	$newPass = $_POST['newpassword'];
	$modify = IUser::modifyPassword($uid, $newPass, $oldPass);
	if($modify === false){
		Logger::err("IUser::modifyPassword failed, code: " . IUser::$errCode . ', msg: ' . IUser::$errMsg);
		IVerifyUserIdentity::changePasswordReport(intval($uid), 0);
        return array('errno' => 6001);
	}
    _deleteUserStatus($uid);
    IVerifyUserIdentity::changePasswordReport(intval($uid), 1);
	return array('errno' => 0);
}


function mypassword_getcode(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		return array('errno' => 500);
	}

	$user = IUser::getUserInfo($uid);
	if ($user===false) {
		return array('errno' => 6001);
	}
        $mobile=0;
        $response =  _verfyUser($user);
        if($response!==false)//��ȫ��֤�з���
        {
            $response=  json_decode($response,true);
            Logger::info("".print_r($response,true));
            if($response["need_verify"]==0)
            {//����
                if(empty($user["bindMobile"])||$user["bindMobile"]==0 )//û�а��ֻ���ֱ���ô������ķ�����
                {
                    $mobile=$_REQUEST["mobile"];
                }
                else//�а��ֻ���Ҫȡ���������ֻ�
                {
                    
                    $mobile=_getRightMobile($_REQUEST["mobile"],$user["mobile"],$response["trusted_mobile_list"]);
                }
            }
            else//������,ֱ��ȡ���������ֻ�
            {
                $bindMobile=0;
                if(!empty($user["bindMobile"])&&$user["bindMobile"]!=0 )//�а��ֻ�
                {
                    $bindMobile=$user["mobile"];
                }
               
                $mobile=_getRightMobile($_REQUEST["mobile"],$bindMobile,$response["trusted_mobile_list"]);
            }
               
                
        }    
        else{//û���յ�����ʧ��
            return array('errno' => 6004);
        }
        if($mobile===0)
        {
            Logger::err("no right mobile:".$mobile);
            return array('errno' => 6004);
        }
        
        
	$getCodeMsg='������Ѹ���޸��������֤��Ϊ';

	if (!ToolUtil::checkMobilePhone($mobile)) {
            return array('errno' => 502);
	}

    $limited = IFreqLimit::checkAndAdd(substr($mobile , 2), 1);
	if ($limited > 0) {
            return array('errno' => 503);
	}

	
	// ���Ͷ���
	$code = IVerify::getMobileVerifyCode($uid, $mobile);
	if (false === $code) {
		return array('errno' => 6004);
	}
	Logger::info("Get Code :mobile[".$mobile."]code[".$code."]");
	$ret = IMessage::sendSMSMessage($mobile, $getCodeMsg.$code);
	if (false === $ret) {
		return array('errno' => 6005);
	}

	return array('errno' => 0);
}


function mypassword_codecheck(){
    $uid = IUser::getLoginUid();
    if(!$uid){
        return array('errno' => 500);
    }

    $user = IUser::getUserInfo($uid);
    Logger::info("".print_r($user, true));
    if ($user===false) {//��ȡuser,ʧ�ܵĻ����˳�
        return array('errno' => 6001);
    }  
    $mobile=0;
    $code=$_REQUEST["code"];
    $response=  _verfyUser($user);
    Logger::info("&&&&".$response);
    if($response!==false)//��֤�ɹ�
    {    
        $response=  json_decode($response,true);
        //��ʼȡ��ȷ���ֻ�
        if($response["need_verify"]==0)
        {//����
            if(empty($user["bindMobile"])||$user["bindMobile"]==0 )//û�а��ֻ���ֱ���ô������ķ�����
            {
                $mobile=$_REQUEST["mobile"];
            }
            else//�а��ֻ���Ҫȡ���������ֻ�
            {
                $mobile=_getRightMobile($_REQUEST["mobile"],$user["mobile"],$response["trusted_mobile_list"]);
            }
        }
        else//������,ֱ��ȡ���������ֻ�
        {
            $bindMobile=0;
            if(!empty($user["bindMobile"])&&$user["bindMobile"]!=0 )//�а��ֻ�
            {
                $bindMobile=$user["mobile"];
            }
            $mobile=_getRightMobile($_REQUEST["mobile"],$bindMobile,$response["trusted_mobile_list"]);
        }
        Logger::info("right mobile:".$mobile);
        if($mobile===0)
        {
            Logger::err("no right mobile:".$mobile);
            return array('errno' => 6004);
        }
        
        $ret = IVerify::checkMobileVerifyCode($uid, $code,$mobile);  
        if (false === $ret) {
            Logger::err("IUser::checkMobileVerifyCode failed, code: " . IVerify::$errCode . ', msg: ' . IVerify::$errMsg);
            return array('errno' => 7004);
	}
        
        $ret1 =_insertUserStatus($uid, array('uid'=>$uid, 'mobile'=>$mobile, 'code'=>$code, 'time'=>time()));//���ȥ���´κ���֤
        if ($ret1===false) {
            Logger::err("_insertMobileVerifyCode failed, uin: " . $uid . ', mobile: '.$mobile." code:".$code);
            return array('errno' => 7004);
	}
       
    }
    else
    {
        return array('errno' => 501, 'errmsg' => 'ϵͳ��æ');
    }    
    return array('errno' => 0);
}