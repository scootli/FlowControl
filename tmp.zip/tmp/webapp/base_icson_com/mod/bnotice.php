<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/Logger.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');
require_once(PHPLIB_ROOT . 'api/distribution/INotice.php');
header('Content-Type:text/html;charset=GB2312');
Logger::init();

/**
 * page - ��ʼ������Ϣ����
 */
function page_bnotice_page()
{
	/**
	 * ��ʼ��ѯ���������ʾΪ��
	 * ֱ�����tpl
	 */
	page_bnotice_search();
}

/**
 * page - 
 */
function page_bnotice_search()
{
	$uid = ToolUtil::checkLoginOrRedirect(); 
	$TPL = TemplateHelper::getBaseTPL(0,'b_notice', array(
		'titleDesc' => '�����б�',
		'cssFile' => array(
               'http://st.icson.com/static_v1/css/update8.css'         
           )
	));

	$TPL->set_file(array(
		'contentHandler' => 'b_notice.tpl'
	));
	
	$TPL->set_block("contentHandler", 'list', 't_list');
	
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	$pageSize = 5;
	$TPL->set_var('pageName','�����б�');
	$Total=INotice::getbaseTotal();
	$ret=INotice::getBaseNoticePage($currentPage,$pageSize);
	if (count($ret) == 0)
	{
	   $TPL->set_var('t_list','');
	}
	$TPL->set_var('pagehtml', '');
	$TPL->set_var('pagehtml', 
		'<div class="paginator">' .
		 ToolUtil::getpageHTML("http://base.51buy.com/bnotice.html?page={page}", $currentPage, ceil( intval($Total) / $pageSize ))  . '</div>');
	
	foreach ($ret as $item)
	{
		$data['theme']=$item['notice_theme'];
		$data['content']=text2links(nl2br(str_replace(" ","&nbsp;",$item['notice_content'])));
	//	str_replace("\r\n","<br>;",$str);
		$data['publish_time']=date("Y-m-d H:i:s",$item['notice_publish_time']);
		$data['page']=$currentPage;
		$TPL->set_var($data);
		$TPL->parse('t_list', 'list', true);
	}
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}
function text2links($str='') 
{
    if($str=='' or !preg_match('/(http|www\.|@)/i',$str))
	{ 
		return $str;
	}
    $lines = explode("\n", $str); $new_text = '';
    while (list($k,$l) = each($lines)) 
	{ 
        // replace links:
        $l = preg_replace("/([ \t]|^)www\./i", "\\1http://www.", $l);
        $l = preg_replace("/([ \t]|^)ftp\./i", "\\1ftp://ftp.", $l);
        $l = preg_replace("/(http:\/\/[^)!]+)/i", "<a href=\"\\1\">\\1</a>", $l);
        $l = preg_replace("/(https:\/\/[^)!]+)/i","<a href=\"\\1\">\\1</a>", $l);
        $l = preg_replace("/(ftp:\/\/[^ )!]+)/i", "<a href=\"\\1\">\\1</a>", $l);
        $l = preg_replace("/([-a-z0-9_]+(\.[_a-z0-9-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)+))/i", "<a href=\"mailto:\\1\">\\1</a>", $l);
        $new_text .= $l."\n";
    }
    return $new_text;
}
