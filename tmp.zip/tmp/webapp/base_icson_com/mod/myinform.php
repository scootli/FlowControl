<?php
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IMyinform.php');
require_once(PHPLIB_ROOT . 'api/IProduct.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
//require_once(BASE_WEB_ROOT . 'inc/TemplateHelper.php');

Logger::init();

function page_myinform_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, 'myinform', array(
		'titleDesc' => '�۸�ٱ�'
	));

	$TPL->set_var('pageName', '�۸�ٱ�');

	$TPL->set_file(array(
			'contentHandler' => 'myinform.tpl'
	));
	//���ӷ�ҳ
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	if($currentPage < 1) $currentPage = 1;
	$pageSize = 10;

	$informList = IMyinform::getinformList($uid, ($currentPage-1), $pageSize);
	if($informList === false){
		Logger::err('IMyinform::getinformList failed-' . IMyinform::$errCode . '-' . IMyinform::$errMsg);
		return  _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
	}

	//��ȡ�ҵļ۸�ٱ�������
	$count = IMyinform::getReplyCount($uid);
	if($count === false){
		Logger::err('IMyinform::getReplyCount failed-' . IMyinform::$errCode . '-' . IMyinform::$errMsg);
		$total = 0;
	} else {
		$total = empty($count[0]['report_count']) ? 0 : $count[0]['report_count'];
		$total = ceil($total / $pageSize);
	}

	$TPL->set_block("contentHandler", 'myinform_list', 't_myinform_list');

	$statusArray = array(
		'-1'=>  '����',
		'0' =>  '��ʼ',
		'1' =>  '���δ�����۸�',
		'2' =>  '����ѵ����۸�',
		'3' =>  '��˴������۸�',
	);
	if (!empty($informList)){
		foreach ( $informList as $val){
			$params = array(
				'productSysNo' => $val['ProductSysNo'],
				'oldSysNo' => $val['OldSysNo'],
				'competitorUrl' => ToolUtil::transXSSContent($val['CompetitorUrl']),
				'reportTime' => $val['ReportTimeStr'],
				'customerSysNo' => $val['CustomerSysNo'],
				'productID' => $val['ProductSysNo'],
				'productName' => getProductName($val['ProductSysNo']),//ToolUtil::transXSSContent($val['productName']),
				'currentPrice' => sprintf("%.2f", $val['CurrentPrice']/100),
				'competitorPrice' => sprintf("%.2f", $val['CompetitorPrice']),
				'status' => isset($statusArray[$val['Status']]) ? $statusArray[$val['Status']] : '',
				'point' => empty($val['Point']) ? 0 : $val['Point'],
				'auditMemo' => empty($val['AuditMemo']) ? '' : $val['AuditMemo'],
				'url' => "http://item.51buy.com/item-".$val['ProductSysNo'].".html"
			);
			$TPL->set_var($params);
			$TPL->parse('t_myinform_list', 'myinform_list', true);
			$TPL->unset_var(array_keys($params));
			$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myinform-{page}.html', $currentPage, $total)  . '</div></div>');
		}
	}else {
		$TPL->set_var('t_myinform_list', '<tr><td colspan="8"><p class="kong">�����û�оٱ��۸�</p></td></tr>');
		$TPL->set_var('page','');
	}

	$TPL->parse('content', 'contentHandler');
	$TPL->out();

}

//��д�۸�ٱ�ҳ��ģ����ʾ
function page_myinform_myinformapply(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$wid = IUser::getSiteId();
	$TPL = TemplateHelper::getBaseTPL(0, 'myinformapply', array(
		'titleDesc' => '��д�۸�ٱ�'
	));

	if (isset($_GET['qplus'])) {
		$TPL = TemplateHelper::getBaseTPL(0, 'myinformapply', array(
				'titleDesc' => '��д�۸�ٱ�',
				'cssFile' => "http://st.icson.com/static_v1/css/mycenter/qplus_mycenter.css",
		));
	}

	$TPL->set_var(array(
		'pageName'	=> '��д�۸�ٱ�',
		'left_nav'	=> ''
	));
	$tpl = 'myinform_apply.tpl';
	if (isset($_GET['qplus'])) {
		$tpl = 'qplus_myinform_apply.tpl';
		$TPL->set_file(array(
					'containerHandler' => 'qplus_container.tpl',
					'contentHandler' => $tpl
		));
	}
	$TPL->set_file(array(
			'contentHandler' => $tpl
	));

	//�û���Ϣ
	$userInfo = IUser::getUserInfo($uid);
	if($userInfo === false){
		Logger::err("IUser::getUserInfo failed, code:" . IUser::$errCode . ', msg:' . IUser::$errMsg);
		TemplateHelper::outMessage('ϵͳ��æ�����Ժ����ԣ�','info');
		return false;
	}
	$email = $userInfo['email'] ? $userInfo['email'] : '';
	$icsonid = $userInfo['icsonid'] ? $userInfo['icsonid'] : '';
	$TPL->set_var('uEmail', $email);
	$TPL->set_var('uIcsonid', $icsonid);

	//��Ʒ��Ϣ
	if(empty($_GET['pid'])){
		TemplateHelper::outMessage('��Ǹ,����Ʒ������,���߸���Ʒ�ݲ�����,���߸���Ʒ�����Ͼٱ�����!','info');
		return false;
	}

	$productInfo = IProduct::getBaseInfo($_GET['pid'], $wid);
	if($productInfo === false){
		Logger::err("IProduct::getBaseInfo failed, code:" . IProduct::$errCode . ', msg:' . IProduct::$errMsg);
		TemplateHelper::outMessage('��Ǹ,����Ʒ������,���߸���Ʒ�ݲ�����,���߸���Ʒ�����Ͼٱ�����!','info');
		return false;
	}

	$TPL->set_var('productName', $productInfo['name']);
	$TPL->set_var('productid', $productInfo['product_id']);
	$TPL->set_var('productcharid', $productInfo['product_char_id']);
	$TPL->set_var('currentPrice', $productInfo['price'] / 100);

	$TPL->parse('content', 'contentHandler');

	$TPL->out();
}

//�ύ�ҵļ۸�ٱ�
function myinform_replyInform(){
	$uid = IUser::getLoginUid();
	$wid = IUser::getSiteId();
	if(!$uid){
		return array('errno' => 500);
	}

	if(empty($_POST['competitorPrice'])){
		return array('errno' => 3);
	}
	$competitorPrice = $_POST['competitorPrice'];

	$competitorUrl = !empty($_POST['competitorUrl']) ? trim($_POST['competitorUrl']) : '';
	$customerMemo = !empty($_POST['customerMemo']) ? trim($_POST['customerMemo']) : '';

	//�û���Ϣ
	$userInfo = IUser::getUserInfo($uid);
	if($userInfo === false){
		Logger::err("IUser::getUserInfo failed, code:" . IUser::$errCode . ', msg:' . IUser::$errMsg);
		return array('errno' => 6001);
	}

	$nickName = $userInfo['name'] ? $userInfo['name'] : '';
	$email = $userInfo['email'] ? $userInfo['email'] : '';

	$productSysNo = $_POST['productSysNo'];
	if(empty($_POST['productSysNo'])){
		return array('errno' => 5);
	}

	$productSysNo -= 0;
	//��Ʒ��Ϣ
	$productInfo = IProduct::getBaseInfo($productSysNo, $wid, false);
	if($productInfo === false){
		Logger::err("IProduct::getBaseInfo failed, code:" . IProduct::$errCode . ', msg:' . IProduct::$errMsg);
		return array('errno' => 6002);
	}
	$currentPrice = $productInfo['price'];

	//�Ƿ��й�����Ʒ�ļ۸�ٱ�
	$count = IMyinform::HasReplyInform($productSysNo, $uid);
	if($count === false){
		Logger::err("IMyinform::HasReplyInform failed, code:" . IMyinform::$errCode . ', msg:' . IMyinform::$errMsg);
		return array('errno' => 6003);
	}

	if($count >= 1){
		return array('errno' => 6004);
	}

	$rs = IMyinform::replyInform($productSysNo, $currentPrice, $competitorPrice, $competitorUrl, $uid, $nickName, $email, $customerMemo);
	if($rs === false){
		echo("IMyinform::replyInform failed, code:" . IMyinform::$errCode . ', msg:' . IMyinform::$errMsg);
		return array('errno' => 6005);
	}
	return  array('errno' => 0);
}

/**
 *
 * ������ƷID��ȡ��Ʒ����
 * @param $pid
 */
function getProductName($pid){
	$productName = '';
	$product = IProductCommonInfoTTC::get($pid, array(), array('name'));
	if (false === ($product)) {
		self::$errCode = IProductCommonInfoTTC::$errCode;
		self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . '[get IProductCommonInfoTTC failed]' . IProductCommonInfoTTC::$errMsg;
	}

	if (count($product) == 0) {
		self::$errCode = 409;
		self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "product_id($pid) is not exist";
	}
	$productName = $product[0]['name'];

	return $productName;
}

//������ʾ
function _output_error($str, &$TPL){
	$TPL->set_var('content', '<div class="i_content" style="text-align:center">' . $str . '</div>');
	$TPL->out();
}
