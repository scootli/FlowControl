<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');
require_once(PHPLIB_ROOT . 'api/IProduct.php');
require_once(PHPLIB_ROOT . 'api/IProductRelativity.php');
require_once(PHPLIB_ROOT . 'api/IMyFavorite.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');

Logger::init();

function favor_getlist(){
	$uid = IUser::getLoginUid();
	if(empty($uid)){
		return array('errno' => 500);
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 501);
	}

	$page = empty($_GET['page']) ? 1 : ($_GET['page'] - 0);
	if($page < 1) $page = 1;

	$perpage = empty($_GET['perpage']) ? 1 : ($_GET['perpage'] - 0);
	if($perpage < 1) $perpage = 1;

	$whId = IUser::getSiteId();
	$list = IMyFavorite::gets($uid, $whId, $page, $perpage);
	if($list === false){
		Logger::err('IMyFavorite::gets failed-' . IMyFavorite::$errCode . '-' . IMyFavorite::$errMsg);
		return array('errno' => 2);
	}

	return array(
		'errno'	=> 0,
		'data'	=> $list
	);
}

function favor_add(){
	$uid = IUser::getLoginUid();
	if(empty($uid)){
		return array('errno' => 500);
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 501);
	}

	if(empty($_POST['pid'])){
		return array('errno' => 1);
	}

	$pid = $_POST['pid'] + 0;

	$add = IMyFavorite::add($uid, $pid);
	if($add === false){
		if(IMyFavorite::$errCode == 404) {
			return array('errno' => 404);
		}
		Logger::err('IMyFavorite::add failed-' . IMyFavorite::$errCode . '-' . IMyFavorite::$errMsg);
		return array('errno' => 2);
	}

	return array(
		'errno'	=> 0
	);
}
// End Of Script