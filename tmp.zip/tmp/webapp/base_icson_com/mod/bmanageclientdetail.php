<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/Logger.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');
require_once(PHPLIB_ROOT . 'api/distribution/INotice.php');
require_once(PHPLIB_ROOT . 'api/IOrder.php');
require_once(PHPLIB_ROOT . 'api/distribution/IBCustom.php');
require_once(PHPLIB_ROOT . 'api/inc/IRetailerCustomerTTC.php');
require_once(PHPLIB_ROOT . 'api/inc/IRetailerCustomerMapTTC.php');
header('Content-Type:text/html;charset=GB2312');
Logger::init();

/**
 * page - 
 */
function page_bmanageclientdetail_page()
{
	/**
	 * ��ʼ��ѯ���������ʾΪ��
	 * ֱ�����tpl
	 */
	//page_bmanageclient_search();
	$uid = ToolUtil::checkLoginOrRedirect(); 
	$TPL = TemplateHelper::getBaseTPL(0,'b_manage_client', array(
		'titleDesc' => '�ͻ������б�',
		'cssFile' => array(
               'http://st.icson.com/static_v1/css/update8.css'         
           )
	));

	$TPL->set_file(array(
		'contentHandler' => 'b_manage_client_detail.tpl'
	));
	$TPL->set_var('pageName','�ͻ�����');
	$TPL->parse('content', 'contentHandler');
	$TPL->set_var('store_class', 'my_store');
	$TPL->out();
}

/**
 * page - 
 */
function page_bmanageclientdetail_search()
{

	$uid = ToolUtil::checkLoginOrRedirect(); 
	$TPL = TemplateHelper::getBaseTPL(0,'b_notice', array(
		'titleDesc' => '�ͻ��б�',
		'cssFile' => array(
               'http://st.icson.com/static_v1/css/update8.css'         
           )
	));

	$TPL->set_file(array(
		'contentHandler' => 'b_manage_client.tpl'
	));
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	$pageSize = 12;
//	$TPL->set_block("contentHandler", 'list', 't_list');
	$Total=IBCustom::getTotal($uid);

	$ret=IBCustom::getCustomPage($uid,$currentPage,$pageSize);
	$TPL->set_var('pagehtml', '');
	$TPL->set_var('pagehtml', 
		'<div class="paginator">' .
		 ToolUtil::getpageHTML("http://base.51buy.com/bmanageclientdetail.html?page={page}", $currentPage, ceil( intval($Total) / $pageSize ))  . '</div>');
	foreach ($ret as $item)
	{
		$data['uid']=$item['retailerId'];
		$data['name']=$item['name'];
		$data['qq']=$item['qq'];
		$data['mobile']=$item['mobile'];
		$data['address']=$item['address'];
		$data['page']=$currentPage;
		$TPL->set_var($data);
		$TPL->parse('t_list', 'list', true);
	}
	
	
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	$pageSize = 5;
	$TPL->set_var('pageName','�ͻ��б�');
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
	
}


//���ط����̿ͻ���Ϣ
function bmanageclientdetail_client() {
	$clientdata=array();
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $page = 1;
    $pageSize = 5;
    if (isset($_POST['page']) && '' != $_POST['page']) {
        $page = intval($_POST['page']);
    }
	
	$conditions = array();
	
    if (isset($_POST['clientname']) && '' != $_POST['clientname']) {
        $conditions ['name'] = $_POST ['clientname'];
    }
    if (isset($_POST['clientphone']) && '' != $_POST['clientphone']) {
        $conditions ['mobile'] = $_POST ['clientphone'];
    }
    if (isset($_POST['clientqq']) && '' != $_POST['clientqq'
	]) {
        $conditions['qq'] = $_POST['clientqq'];
    }
	if (isset($_POST['clientorderid']) && '' != $_POST['clientorderid']) {
        $conditions['orderCharId'] = $_POST['clientorderid'];
    }
	$clients=IBCustom::getCustomPage($uid,$conditions,$page,$pageSize);
	$Total=$clients['count'];
	$clientdata['total']=$Total;
	$clientdata['data']=$clients['data'];
	 
    if (FALSE === $shops) {
        Logger::err("IBCustom::getCustomPage faild-" . IBCustom::$errCode . "-" . IBCustom::$errMsg);
        return array('errno'	=> IBCustom::$errCode);
    }
    if (!$clients) {
        //û������
        return array('errno' => 1);
    }
    if (1 == $page) {//init page
        $clientdata['pages'] = ceil($Total / $pageSize);
    }
	$clientdata['errno'] = 0;
    return $clientdata;
}

//���ض����б�
function bmanageclientdetail_orderlist() 
{
	$clientdata=array();
    $uid = ToolUtil::checkLoginOrRedirect();
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
    $page = 1;
    $pageSize = 5;
    if (isset($_POST['page']) && '' != $_POST['page']) {
        $page = intval($_POST['page']);
    }
	
	$conditions = array();
	
    $conditions['uid']=$uid;
	if (isset($_POST['mobile']) && '' != $_POST['mobile']) {
        $conditions['mobile'] = $_POST['mobile'];
    }
	$clients=IBCustom::getorderlistPage($uid,$conditions,$page,$pageSize);
	
	$Total=$clients['count'];
	$clientdata['total']=$Total;
	$clientdata['data']=$clients['data'];
	 
    if ($Total==0) {
        //û������
         $clientdata['errno'] = 1;
		 return $clientdata;
    }
    if (1 == $page) {//init page
        $clientdata['pages'] = ceil($Total / $pageSize);
    }
	$clientdata['errno'] = 0;
    return $clientdata;
}


//�����¿ͻ�ʱ�����ù��������ŵó���ַ
function bmanageclientdetail_addr()
{
	$uid = ToolUtil::checkLoginOrRedirect();
	$orderID ="";
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
	if (isset($_POST['orderID']) && '' != $_POST['orderID']) {
        $orderID = $_POST ['orderID'];
    }
	$ret=IOrder::getOneOrderDetail($uid,$orderID);
	$addr=$ret['receiver_addr'];
	return $addr;
	
}

//����������
function bmanageclientdetail_addreation()
{
	$uid = ToolUtil::checkLoginOrRedirect();
	$orderID ="";
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
	if (isset($_POST['orderID']) && '' != $_POST['orderID']) {
        $orderID = $_POST ['orderID'];
    }
	if (isset($_POST['qq']) && '' != $_POST['qq']) {
        $qq = $_POST ['qq'];
    }
	//��鶩���ɣ��Ƿ����
	if(!empty($orderID))
	{
		$ret=IOrder::getOneOrderDetail($uid,$orderID);
		if($ret){}
		else
		{
			return array('errno' => 10,'errMsg'=>'���������Ų����ڣ�����ȷ����');
		}
	}
	
	$ret=IBCustom::addreation($uid,$orderID,$qq);
	return array('errno' => $ret['error'],'errMsg'=>$ret['data']);
	
}

//ȡ������������
function bmanageclientdetail_delreation()
{
	$uid = ToolUtil::checkLoginOrRedirect();
	$orderID ="";
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
	if (isset($_POST['orderID']) && '' != $_POST['orderID']) {
        $orderID = $_POST ['orderID'];
    }
	if (isset($_POST['qq']) && '' != $_POST['qq']) {
        $qq = $_POST ['qq'];
    }
	//��鶩���ɣ��Ƿ����
	if(!empty($orderID))
	{
		$ret=IOrder::getOneOrderDetail($uid,$orderID);
		if($ret){}
		else
		{
			return array('errno' => 10,'errMsg'=>'���������Ų����ڣ�����ȷ����');
		}
	}
	
	$ret=IBCustom::delreation($uid,$orderID,$qq);
	return array('errno' => $ret['error'],'errMsg'=>$ret['data']);
	
}

function bmanageclientdetail_checkorder()
{
	$uid = ToolUtil::checkLoginOrRedirect();
	$orderId ="";
    if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
	if (isset($_POST['orderId']) && '' != $_POST['orderId']) {
        $orderId = $_POST ['orderId'];
    }
	$ret=IOrder::getOneOrderDetail($uid,$orderId);
	if($ret)
	{
		return array('errno' => 0);
	}
	else
	{
		return array('errno' => 1);
	}
}


//���ӷ����̿ͻ�
function bmanageclientdetail_saveclient()
{

	$uid = ToolUtil::checkLoginOrRedirect();
	if(!isset($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 5);
	}
	
	$conditions = array();
	
    if (isset($_POST['_clientname']) && '' != $_POST['_clientname']) {
        $conditions ['_clientname'] = $_POST ['_clientname'];
    }
	
	if (isset($_POST['_clientqq']) && '' != $_POST['_clientqq']) {
        $conditions ['_clientqq'] = $_POST ['_clientqq'];
    }
	
	if (isset($_POST['_clientmobile']) && '' != $_POST['_clientmobile']) {
        $conditions ['_clientmobile'] = $_POST ['_clientmobile'];
    }
	
	$conditions ['_clientooderId'] = $_POST ['_clientooderId'];
	$conditions ['_clientaddr'] = $_POST ['_clientaddr'];
	
	//��鶩���ɣ��Ƿ����
	if(!empty($conditions ['_clientooderId']))
	{
		$ret=IOrder::getOneOrderDetail($uid,$conditions ['_clientooderId']);
		if($ret){}
		else
		{
			return array('errno' => 10,'errMsg'=>'���������Ų����ڣ�����ȷ����');
		}
	}
	
	
	
	//�洢��ϵ��
		$retailer_customer_order=array(
							'retailerId' =>  $uid,
							'qq' =>  $conditions ['_clientqq'],
							'orderCharId' => $conditions ['_clientooderId'],
							);
	//�洢�ͻ���Ϣ��
	$retailer_customer=	array(
								'retailerId' =>  $uid,
								'name' => $conditions ['_clientname'],
								'qq' =>  $conditions ['_clientqq'],
								'mobile' => $conditions ['_clientmobile'],
								'phone' => '',
								'district' =>  0,
								'address' => $conditions ['_clientaddr'],
								'zipcode' => '1234',
								'status' =>  1,
								'isDelete' =>  0,
								'createTime' =>  time(),
								'updateTime' =>  time(),
								'orders' => $conditions ['_clientooderId'],
								);
								
	if(!empty($conditions ['_clientooderId']))
	{
		$ret=IBCustom::addAll($retailer_customer_order,$retailer_customer);
		return array('errno' => $ret['error'],'errMsg'=>$ret['data']);
	}
	else
	{
		$ret=IBCustom::addAllNotOrder($retailer_customer);
		return array('errno' => $ret['error'],'errMsg'=>$ret['data']);
	}
}
