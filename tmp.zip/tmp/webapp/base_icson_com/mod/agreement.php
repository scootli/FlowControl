<?php

require_once(PHPLIB_ROOT . 'api/IUser.php');

function page_agreement_index(){
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
	'cssFile'	=> 'http://st.51buy.com/static_v1/css/login/agreement.css?v=20130319',
	'headerStyle'	=> 'agreement',
	'titleDesc'	=> '��Ѹ���û�����Э��'
	));

	$TPL->set_file(array(
		"containerHandler"	=> "agreement.tpl"
	));
	$TPL->out();
}
?>