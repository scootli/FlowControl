<?php
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IMynotify.php');
require_once(PHPLIB_ROOT . 'api/IProduct.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');

Logger::init();

function page_mynotify_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$wid = IUser::getSiteId();
	$TPL = TemplateHelper::getBaseTPL(0, 'mynotify', array(
		'titleDesc' => '����֪ͨ'
	));

	$TPL->set_var('pageName', '����֪ͨ');

	$TPL->set_file(array(
			'contentHandler' => 'mynotify_content.tpl'
	));

	$userInfo = IUser::getUserInfo($uid);
	if($userInfo === false){
		Logger::err("IUser::getUserInfo failed, code:" . IUser::$errCode . ', msg:' . IUser::$errMsg);
		return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL);
	}

	global  $_StockTips;

	$result = IMynotify::getnotifyList($uid);
	if($result === false){
		Logger::err('IMynotify::getnotifyList failed-' . IMynotify::$errCode . '-' . IMynotify::$errMsg);
		return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
	}

	$TPL->set_block("contentHandler", 'mynotify_list', 't_mynotify_list');

	$notifystatus = array(
		'-1'=>  '����',
		'0' =>  'δ֪ͨ',
		'1' =>  '��֪ͨ',
	);
	if (!empty($result)){
		foreach ( $result as $val){
			$pinfo = IProduct::getBaseInfo($val['ProductSysNo'], $wid, true);
			if($pinfo === false){
				Logger::err('IProduct::getBaseInfo failed-' . IProduct::$errCode . '-' . IProduct::$errMsg);
			}
			$params = array(
				'productname' => ToolUtil::transXSSContent($pinfo['name']),
				'productmode' => ToolUtil::transXSSContent($pinfo['mode']),
				'productSysNo' => $pinfo['product_id'],
				'currentPrice' => sprintf("%.2f", $pinfo['price']/100),
				'createTime' => $val['CreateTime'],
				'productchar_id' => $pinfo['product_char_id'],
				'notifysysno' => $val['notifysysno'],
				'notifystatus' => ($pinfo['stock'] != $_StockTips['not_available']) ? '��֪ͨ' : 'δ֪ͨ',
				//'notifystatus' => isset($notifystatus[$val['notifystatus']]) ? $notifystatus[$val['notifystatus']] : '',
				'stock' => (!empty($pinfo))? $pinfo['stock'] : '',
				'addTocart' => ($pinfo['stock'] != $_StockTips['not_available']) ? '<p><a href="#" class="btn_strong" onclick="G.app.mycenter.mynotify.goToCart('.$pinfo["product_id"].',this); return false;"><span>���빺�ﳵ</span></a></p>' : '',
				'continueNotify' => (($pinfo['stock'] !== $_StockTips['not_available']) && (isset($notifystatus[$val['notifystatus']]) && $notifystatus[$val['notifystatus']]) == '��֪ͨ') ? '' : '<a href="#" class="btn_pay" onclick="G.app.mycenter.mynotify.continueNotify('.$val["notifysysno"].'); return false;"><span>����֪ͨ</span></a></p>',
				'url' => "http://item.51buy.com/item-".$val['ProductSysNo'].".html",
				'pic' => IProduct::getPic($pinfo['product_char_id'], 'small'),
				'has_stock' => ($pinfo['stock'] != $_StockTips['not_available']) ? 'yes' : 'no',
				//'check_addTocar' => (!empty($pinfo['stock']) && strpos($pinfo['stock'], '�޻�') === false) ? true : false,
			);
			$TPL->set_var($params);
			$TPL->parse('t_mynotify_list', 'mynotify_list', true);
			$TPL->unset_var(array_keys($params));
		}
		$TPL->set_var('user_email', $userInfo['email']);
	}else {
		$TPL->set_var('t_mynotify_list', '<tr><td colspan="7"><p class="kong">�����û�����õ���֪ͨ��</p></td></tr>');
	}

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}


//���ӵ���֪ͨ
function mynotify_addMynotify(){
	$uid = IUser::getLoginUid();
	$wid = IUser::getSiteId();
	if(!$uid){
		return array('errno' => 500);
	}

	if(isset($_POST['pid'])){
		if(empty($_POST['pid'])){
			return array('errno' => 4);
		}
		$productSysNo = ToolUtil::transXSSContent($_POST['pid']);
		$productInfo = IProduct::getBaseInfo($productSysNo, $wid, true);
		if($productInfo === false){
			Logger::err('IProduct::getBaseInfo failed-' . IProduct::$errCode . '-' . IProduct::$errMsg);
			return _output_error('��Ǹ,����Ʒ�����ڣ�', $TPL);
		}
	}

	if(isset($_POST['email'])){
		if(empty($_POST['email'])){
			return array('errno' => 5);
		}
		$email = ToolUtil::transXSSContent($_POST['email']);
	}

	$count = IMynotify::HasReplyNotify($productSysNo, $uid);
	if($count === false){
		Logger::err("IMynotify::HasReplyNotify failed, code:" . IMynotify::$errCode . ', msg:' . IMynotify::$errMsg);
		return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
	}

	if($count < 1){
		//$email = $userInfo['email'];
		$rs = IMynotify::addNotify($uid, $productSysNo, $email);
		if($rs === false){
			Logger::err("IMynotify::addNotify failed, code:" . IMynotify::$errCode . ', msg:' . IMynotify::$errMsg);
			return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
		}
		return array('errno'=> 0);
	}else{
		return array('errno'=> 33);
	}

/*	ToolUtil::redirect('http://base.51buy.com/mynotify.html');
	return;*/

}
//ɾ������֪ͨ
function mynotify_delMynotify(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		return array('errno' => 500);
	}

	if(isset($_GET['sysno'])){
		if(empty($_GET['sysno'])){
			return array('errno' => 1);
		}
		$sysno = $_GET['sysno'];
	}

	$sysno = explode(',', $sysno);
	foreach ($sysno as $key => $value){
		if(!is_numeric($value)){
			unset($sysno[$key]);
		}
	}
	if(empty($sysno)){
		return array('errno' => 3);
	}
	$rs = IMynotify::delnotify($sysno);
	if($rs === false){
		Logger::err('IMynotify::delnotify failed-' . IMynotify::$errCode . '-' . IMynotify::$errMsg);
		return array('errno' => 6003);
	}
	return  array('errno' => 0);
}

//����֪ͨ
function mynotify_continueNotify(){
	if(isset($_GET['sysno'])){
		if(empty($_GET['sysno'])){
			return array('errno' => 2);
		}
		$sysno = $_GET['sysno'];
	}

	$rs = IMynotify::continueNotify($sysno);
	if($rs === false){
		Logger::err('IMynotify::continueNotify failed-' . IMynotify::$errCode . '-' . IMynotify::$errMsg);
		return array('errno' => 6004);
	}
	return  array('errno' => 0);
}

//δ��д������û��ɹ����ӵ���֪ͨ,�����û�д���������������
function mynotify_enterEmail(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		return array('errno' => 500);
	}

	$updateInfo = array();
	if(isset($_POST['email'])){
		if(!empty($_POST['email']) && !ToolUtil::checkEmail($_POST['email'])){
			return array('errno' => 4);
		}
		$updateInfo['email'] = $_POST['email'];
	}

	$rs = IUser::updateUser($uid, $updateInfo);
	if($rs === false){
		Logger::err('IUser::updateUser failed-' . IUser::$errCode . '-' . IUser::$errMsg);
		return array('errno' => 6005);
	}
	return  array('errno' => 0);
}

//�޸ĵ���֪ͨ[֪ͨ����]
function mynotify_updateEmail(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		return array('errno' => 500);
	}

	if(isset($_POST['email'])){
		if(!empty($_POST['email']) && !ToolUtil::checkEmail($_POST['email'])){
			return array('errno' => 6);
		}
		$email = $_POST['email'];
	}

	$rs = IMynotify::updateNotifyEmail($uid, $email);
	if($rs === false){
		Logger::err('IMynotify::updateNotifyEmail failed-' . IMynotify::$errCode . '-' . IMynotify::$errMsg);
		return array('errno' => 6006);
	}
	return  array('errno' => 0);
}
//������ʾstyle="text-align:center"
function _output_error($str, &$TPL){
	$TPL->set_var('content', '<div class="i_content" style="text-align:center">' . $str . '</div>');
	$TPL->out();
}