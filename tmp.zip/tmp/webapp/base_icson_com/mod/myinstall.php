<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');
require_once(PHPLIB_ROOT . 'api/IProduct.php');
require_once(PHPLIB_ROOT . 'api/IProductRelativity.php');
require_once(PHPLIB_ROOT . 'api/IOrder.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IInstall.php');
require_once(PHPLIB_ROOT . 'api/inc/IOrderItemsTTC.php');
require_once(PHPLIB_ROOT . 'api/inc/IManufacturerTTC.php');

Logger::init();
//δԤԼ
function page_myinstall_page(){
	global $_OrderState;
	$beforeOneMonth = false;

	if(!empty($_GET['type']) || $_GET['type'] == "1"){
		if($_GET['type'] == "2"){
			return alreadyinstall_page();
		}else{
			$beforeOneMonth = true;
		}
	}

	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, "myinstall", array(
		'titleDesc' => '���Ű�װ'
	));

	$TPL->set_file(array(
		'contentHandler' => 'myinstall_content.tpl'
	));

	$TPL->set_var('already_install', 'status_on');
	$TPL->set_var('not_install', '');
	$TPL->set_var('myinstall_class', 'sc_nav_cur_item');

	//����������ѡ��״̬
	if($beforeOneMonth){
		$TPL->set_var('recentlyOrderSelect', '');
		$TPL->set_var('oneMonthAgoOrderSelect', 'selected');
	}else{
		$TPL->set_var('recentlyOrderSelect', 'selected');
		$TPL->set_var('oneMonthAgoOrderSelect', '');
	}


	$ret = explode("-", date("Y-m") );
	$currentYear = $ret[0];
	$currentMonth = $ret[1];

	$begin = "";
	$end = "";

	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );

	$pageSize = 10;
	//һ����֮ǰ
	if($beforeOneMonth){
		$orderList = IInstall::getUserOrdersNeedInstallOneMonthAgo($uid, $currentPage - 1, $pageSize);
	}
	//����
	else{
		$orderList = IInstall::getUserOrdersNeedInstallOneMonth($uid, $currentPage - 1, $pageSize);
	}

	$TPL->set_var('pageName', '���Ű�װ');
	$TPL->set_block("contentHandler", 'list', 't_list');

	if($orderList === false){
		Logger::err('IOrder::getUserOrders failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);
		return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL);
	}

	if(!empty($orderList['orders'])){
		foreach( $orderList['orders'] as $key_o => $item){
			$product_list_str = '';
			if(!empty($item['items'])){//��Ʒ�б�
				foreach($item['items'] as $index => $product){
					if($index > 7){
						break;
					}else{
						if($product['buy_num'] != $product['installed_num']){
							$product_title = strip_tags($product['name']);
							$product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);
							$product_list_str.= '<a target="_blank" href="http://item.51buy.com/item-' . $product['product_id'] .'.html" class="img"><i></i><img src="' . IProduct::getPic($product['product_char_id'], 'small') . '" alt="'.$product_title.'" title="'.$product_title.'"></a>';
						}
					}
				}

				$siteId = $item['hw_id'];
				$params = array(
					'order_char_id' => $item['order_char_id'],  //�������
					'order_id' => $item['order_id'],
					'order_date' => date("Y-m-d", $item['order_date']), //�µ�ʱ��
					'order_create_time' => $item['order_date'],
					'order_button_list'=> '',
					'receiver' => ToolUtil::transXSSContent( $item['receiver'] ), //�ջ���
					'product_list_str' => $product_list_str,
					//'product_list_display' => empty($product_list_str) ? 'none' : 'table-row',
				);
				$TPL->set_var($params);
				$TPL->parse('t_list', 'list', true);
				$TPL->unset_var($params);
				$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myinstall-'.($beforeOneMonth ? '1' : '0').'-{page}.html', $currentPage, ceil( $orderList['total'] / $pageSize ))  . '</div></div>');
			}else{
				$TPL->set_var('t_list', '<tr><td colspan="4"><p class="kong">'.($beforeOneMonth? '����һ����֮ǰû�п�ԤԼ�Ķ���' : '����һ������û�п�ԤԼ�Ķ���').'</p></td></tr>');
				$TPL->set_var('page', '');
			}
		}
	}
	else{
		$TPL->set_var('t_list', '<tr><td colspan="4"><p class="kong">'.($beforeOneMonth? '����һ����֮ǰû�п�ԤԼ�Ķ���' : '����һ������û�п�ԤԼ�Ķ���').'</p></td></tr>');
		$TPL->set_var('page', '');
	}
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//��ԤԼ
function alreadyinstall_page()
{
	global $install_status;
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, "myinstall", array(
		'titleDesc' => '���Ű�װ'
	));

	$TPL->set_file(array(
		'contentHandler' => 'already_myinstall_content.tpl'
	));

	$TPL->set_var('already_install', '');
	$TPL->set_var('no_install', 'status_on');
	$TPL->set_var('myinstall_class', 'sc_nav_cur_item');

	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	if($currentPage < 1) $currentPage = 1;
	$pageSize = 10;

	$TPL->set_var('pageName', '���Ű�װ');
	$TPL->set_block("contentHandler", 'myinstall_list', 't_myinstall_list');
	$installList = IInstall::getalready_install($uid, ($currentPage-1), $pageSize);
	if($installList === false){
		Logger::err('IInstall::getalready_install failed-' . IInstall::$errCode . '-' . IInstall::$errMsg);
		return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL);
	}

	$total = empty($installList['total']) ? 0 : $installList['total'];
	$total = ceil($total / $pageSize);

	if(isset($installList['data']) && $installList['total'] > 0 ){
		foreach($installList['data'] as $list){
			$order_id = 0;
			if(strlen($list['SoSysNo']) == 7){
				$order_id = "100" .$list['SoSysNo'];
			}else if(strlen($list['SoSysNo']) == 8){
				$order_id = "10" .$list['SoSysNo'];
			}else{
				$order_id = "1" .$list['SoSysNo'];
			}

			$params = array(
				'php_order_id' => $order_id,
				'php_product_sysno' => $list['ProductSysNo'],
				//'php_product_name' => $product_title,
				'php_product_list_str' => getProductInfo($list['ProductSysNo'], 1, $TPL),//$product_list_str,
				'php_sysno' => $list['SysNo'],
				'php_install_time' => substr($list['InstallTime'], 0, 10),
				'php_install_status' => @$install_status[$list['Status']],
				'php_install_cancel' => ($list['Status'] == 0) ? '<p><a href="#" onclick="G.app.mycenter.myinstall.cancel(this, \''.$list['SysNo'].'\');return false;">ȡ��ԤԼ</a></p>' : '',
				'php_create_time' => ToolUtil::transXSSContent($list['CreateTime']),
			);
			$TPL->set_var($params);
			$TPL->parse('t_myinstall_list', 'myinstall_list', true);
			$TPL->unset_var(array_keys($params));
			$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myinstall-2-{page}.html', $currentPage, $total)  . '</div></div>');
		}
	}else{
		$TPL->set_var('t_myinstall_list', '<tr><td colspan="6"><p class="kong">��ʱ����ԤԼ���Ű�װ����Ʒ</p></td></tr>');
		$TPL->set_var('page','');
	}
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//��д���Ű�װԤԼ(ҳ��ģ��)
function page_myinstall_report(){
	global $install_status;//״ֵ̬
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, "myinstall_report", array ('titleDesc' => '��д���Ű�װԤԼ����'));
	$TPL->set_var(array('pageName' => '��д���Ű�װԤԼ����', 'left_nav' => ''));
	$TPL->set_var('myinstall_class', 'sc_nav_cur_item');

	$order_id = $_GET['order_id'];
	if(empty($order_id)){
		Logger::err("get order_id empty");
		return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL);
	}
	$no_install_list = IInstall::reportInstall_list($uid, $order_id);
	if($no_install_list === false){
		Logger::err("exec IInstall::reportInstall_list false" . IInstall::$errCode . "-" . IInstall::$errMsg . " -uid:" . $uid . ' -order_id:' . $order_id);
		return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL);
	}

	if(isset($no_install_list['data']) && !empty($no_install_list['data']) && isset($no_install_list['data']['items'])){
		$TPL->set_var('php_order_char_id', $no_install_list['data']['order_char_id']);
		$TPL->set_var('php_order_date', date('Y-m-d',$no_install_list['data']['order_date']));
		$TPL->set_file(array('contentHandler' => 'myinstall_report.tpl'));
		$TPL->set_block('contentHandler', 'myinstall_report_list', 't_myinstall_report_list');
		$TPL->set_block('contentHandler', 'areadyinstall_list', 't_areadyinstall_list');
	}else{
		Logger::err("get IInstall::reportInstall_list empty" . IInstall::$errCode . "-" . IInstall::$errMsg. " -uid:" . $uid . ' -order_id:' . $order_id);
		return _output_error("��������ȷ�����Ժ����ԣ�", $TPL);
	}
	//$count_num = count($no_install_list['data']['items']);
	$count_num = 0;
	$installed_total_num = 0;//������ԤԼ��Ʒ����
	$install_array = array();//��ԤԼ
	$no_install_array = array();//δԤԼ
	if(isset($no_install_list['data']) && !empty($no_install_list['data']) && isset($no_install_list['data']['items'])){
		foreach($no_install_list['data']['items'] as $items){//��Ʒ�������
			//1.������ԤԼ��Ʒ��Ϣ
			$installed_num = count($items['install_info']);
			$install_array[] = array($items,$installed_num);
			$count_num = $count_num + $items['buy_num'];

			//2.����δԤԼ��Ʒ��Ϣ
			$no_installed_num = $items['buy_num'] - $installed_num;
			$no_install_array[] = array($items,$no_installed_num);

			$installed_total_num = $installed_total_num + $installed_num;
		}
	}
	$no_installed_total_num = $count_num - $installed_total_num;//δ��ԤԼ��Ʒ����
	//1.��ʾ��ԤԼ��Ʒ��Ϣ
	if($installed_total_num <= 0){
		$vars_item['aready_install_info'] = "<div class=\"oredered clearfix\" id=\"aready_install_div\">û����ԤԼ��װ����Ʒ</div>";
		$TPL->set_var($vars_item);
		$TPL->parse('t_areadyinstall_list', 'areadyinstall_list', true);
		$TPL->unset_var(array_keys($vars_item));
	}else{
		foreach($install_array as $it){
			$items = $it[0];
			$vars_item = array();
			$TPL->set_var('aready_install_append', '<div class="mod_install_tit ordered_tit" id="aready_install_append">��ԤԼ��Ʒ</div>');
			for($i=0 ; $i<$it[1]; $i++){
				$install_info = $items['install_info'];
				$InstallTime = substr($install_info[$i]['InstallTime'], 0, 10);
				$img_show = '<img src="' . IProduct::getPic($items['product_char_id'], 'small') . '" alt="'.$items['name'].'" title="'.$items['name'].'">';
				$vars_item['aready_install_info'] = "<div class=\"oredered clearfix\" id=\"aready_install_div\">
														<span class=\"wrap_img\"><a target=\"_blank\" href=\"http://item.51buy.com/item-{$items['product_id']}.html\" title=\"{$items['name']}\">{$img_show}</a></span>
														<div class=\"info\">
															<p>{$items['name']} </p>
														    <p><span>ԤԼ���ţ�<a target=\"_blank\" href=\"http://base.51buy.com/installdetail-{$install_info[$i]['SysNo']}.html\" >{$install_info[$i]['SysNo']}</a></span>
														    <span>״̬��{$install_status[$install_info[$i]['Status']]}</span>
														    <span>�����������ڣ�{$InstallTime}</span>
														    <span>�ύʱ��:{$install_info[$i]['CreateTime']}</span></p>
														</div>
														</div>";
				$TPL->set_var($vars_item);
				$TPL->parse('t_areadyinstall_list', 'areadyinstall_list', true);
				$TPL->unset_var(array_keys($vars_item));
			}
		}
	}

	//2.��ʾδԤԼ��Ʒ��Ϣ
	if($no_installed_total_num > 0){
		foreach($no_install_array as $it){
			$items = $it[0];
			$vars_item = array();
			for($i=0 ; $i<$it[1]; $i++){
				$items['new_id'] = $items['product_id'].$i;
				if($items['c3_id'] == '736'){//�յ�
					$vars_item['php_install_material'] = "���߳��ȣ�<select class=\"normal\" id=\"select_gxcd_{$items['new_id']}\">
																	<option value=\"0\">��ѡ��</option>
																	<option value=\"1\">����</option>
																	<option value=\"2\">�ӳ�����</option>
																</select>
																֧�ܣ�<select class=\"short\" id=\"select_zj_{$items['new_id']}\">
																	<option value=\"0\">��ѡ��</option>
																	<option value=\"1\">����֧��</option>
																	<option value=\"2\">��֧��</option>
																</select>
																��ǽ����<select class=\"long\" id=\"select_dqd_{$items['new_id']}\">
																	<option value=\"0\">��ѡ��</option>
																	<option value=\"1\">שǽ���</option>
																	<option value=\"2\">������ǽ���</option>
																	<option value=\"3\">Ԥ���׶�</option>
																	<option value=\"4\">������</option>
																</select>";
				}else{//�յ�
					$vars_item['php_install_material'] = "̨����ʣ�<select class=\"normal\" id=\"select_tpcz_{$items['new_id']}\">
																	<option value=\"0\">��ѡ��</option>
																	<option value=\"1\">�����</option>
																	<option value=\"2\">�������ʯ</option>
																	<option value=\"3\">��Ȼ����ʯ</option>
																	<option value=\"4\">������</option>
																</select>";
				}
				$vars_item['php_receiver_addr'] 		= ToolUtil::transXSSContent($no_install_list['data']['receiver_addr']);
				$vars_item['php_receiver_addr_id'] 		= $no_install_list['data']['receiver_addr_id'];
				$vars_item['php_receiver_mobile']		= $no_install_list['data']['receiver_mobile'];
				$vars_item['php_receiver_phone']		= $no_install_list['data']['receiver_tel'];
				$vars_item['php_product_id']			= $items['product_id'];
				$vars_item['php_product_char_id']		= $items['product_char_id'];
				$vars_item['php_branch_name']			= getManufacturer_name($items['manufacturer']);
				$vars_item['php_product_mode']			= ToolUtil::transXSSContent($items['mode']);
				$vars_item['php_product_img']			= '<img src="' . IProduct::getPic($items['product_char_id'], 'pic160') . '" alt="'.$items['name'].'" title="'.$items['name'].'">';
				$vars_item['php_name']					= ToolUtil::transXSSContent($items['name']);
				$vars_item['php_receiver']				= ToolUtil::transXSSContent($no_install_list['data']['receiver']);
				$vars_item['php_div_id']				= $items['new_id'];
				$vars_item['php_c3_id']					= $items['c3_id'];
				$vars_item['php_tpl_block'] 			= "block";
				$TPL->set_var($vars_item);
				$TPL->parse('t_myinstall_report_list', 'myinstall_report_list', true);
				$TPL->unset_var(array_keys($vars_item));
			}
		}
	}else{
		$vars_item['php_receiver_addr'] 		= "";
		$vars_item['php_receiver_addr_id'] 		= "";
		$vars_item['php_receiver_mobile']		= "";
		$vars_item['php_receiver_phone']		= "";
		$vars_item['php_product_id']			= "";
		$vars_item['php_product_char_id']		= "";
		$vars_item['php_branch_name']			= "";
		$vars_item['php_product_mode']			= "";
		$vars_item['php_product_img']			= "";
		$vars_item['php_name']					= "";
		$vars_item['php_receiver']				= "";
		$vars_item['php_div_id']				= "";
		$vars_item['php_c3_id']					= "";
		$vars_item['php_install_material'] 		= "";
		$vars_item['php_tpl_block'] 			= "none";
		$TPL->set_var($vars_item);
		$TPL->parse('t_myinstall_report_list', 'myinstall_report_list', true);
		$TPL->unset_var(array_keys($vars_item));
	}
	$TPL->set_var('init_receiver_addr', $no_install_list['data']['receiver_addr']);
	$TPL->set_var('init_receiver_addr_id', $no_install_list['data']['receiver_addr_id']);
	$TPL->set_var('init_receiver', $no_install_list['data']['receiver']);
	$TPL->set_var('init_receiver_mobile', empty($no_install_list['data']['receiver_mobile']) ? $no_install_list['data']['receiver_tel'] : $no_install_list['data']['receiver_mobile']);
	$TPL->set_var('order_installedNum', $installed_total_num);
	$TPL->set_var('order_noinstalledNum', $no_installed_total_num);

	//��ַ��Ϣѡ�� �������ַ������Ϣ
	/*$TPL->set_block('contentHandler', 'myinstall_addr_list', 't_myinstall_addr_list');
	$address = IUser::getUserAddress($uid);
	if($address === false){
		Logger::err("IUser::getUserAddress faild-" . IUser::$errCode . "-" . IUser::$errMsg);
		return array('errno' => 1);
	}else{
		global $_District, $_Province, $_City;
		if(isset($address) && !empty($address)){
			foreach($address as $addr){
				$vars_addr = array();
				$vars_addr['php_aid'] 			= $addr['aid'];
				$vars_addr['php_districtID'] 	= $addr['district'];
				$vars_addr['php_workplace'] 	= htmlspecialchars($addr['workplace']);
				$vars_addr['php_name']			= htmlspecialchars($addr['name']);
				$vars_addr['php_mobile']		= htmlspecialchars($addr['mobile']);//empty($addr['mobile']) ? htmlspecialchars($addr['mobile']) : htmlspecialchars($addr['phone']);
				$vars_addr['php_phone']			= htmlspecialchars($addr['phone']);
				$vars_addr['php_district']		= @($_Province[$_District[$addr['district']]['province_id']] . $_City[$_District[$addr['district']]['city_id']]['name'] . $_District[$addr['district']]['name']);
				$vars_addr['php_address']		= htmlspecialchars($addr['address']);
				$TPL->set_var($vars_addr);
				$TPL->parse('t_myinstall_addr_list', 'myinstall_addr_list', true);
				$TPL->unset_var(array_keys($vars_addr));
			}
		}
	}*/

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//��ȡƷ������
function getManufacturer_name($id){
	$name = $id;
	$data = IManufacturerTTC::get($id, array(), array('id', 'name'));
	if(false === $data){
		Logger::err("IManufacturerTTC get" . " errMsg: " .IManufacturerTTC::$errMsg ." errCode: " .IManufacturerTTC::$errCode);
	}else if(empty($data)){
		Logger::err("IManufacturerTTC get empty" . " errMsg: " .IManufacturerTTC::$errMsg ." errCode: " .IManufacturerTTC::$errCode);
	}else{
		$name =$data[0]['name'];
	}
	return $name;
}

//��ȡ��Ʒ��Ϣ
function getProductInfo($pid, $whId, $TPL){
	$html = '';
	$pinfo = IProduct::getBaseInfo($pid, $whId, true);
	if($pinfo === false){
		Logger::err("IProduct::getBaseInfo failed, code:" . IProduct::$errCode . ', msg:' . IProduct::$errMsg . ',pid:' . $pid . ',whid:' . $whId);
		return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL );
	}else if(empty($pinfo) || count($pinfo) <0){
		Logger::err("IProduct::getBaseInfo empty, code:" . IProduct::$errCode . ', msg:' . IProduct::$errMsg . ',pid:' . $pid . ',whid:' . $whId);
		$html .= "<span></snap>";
	}else{
		$product_title = strip_tags($pinfo['name']);
		$product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);
		$img_src = IProduct::getPic($pinfo['product_char_id'], 'small');
		$html .= "<a target=\"_blank\"  href=\"http://item.51buy.com/item-{$pinfo['product_id']}.html\" class=\"img\"><i></i><img src=\"$img_src\" alt=\"$product_title\" title=\"$product_title\"></a>";
	}
	return $html;
}

//������Ϣ���
function _output_error($str, &$TPL) {
	$TPL->set_var ( 'content', '<div class="i_content" style="text-align:center">' . $str . '</div>' );
	$TPL->out ();
}

//�ύ����ԤԼ��װ
function myinstall_add(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		Logger::err("is not uid" . IUser::$errCode . ', msg:' . IUser::$errMsg);
		return array('errno' => 500);
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		Logger::err("uid is empty");
		return array('errno' => 501);
	}
	$installInfo = array('CreateUserSysNo' => $uid);

	if(empty($_POST['order_id'])){
		Logger::err("order_id is empty, uid:" . $uid);
		return array('errno' => 10);
	}
	if(strpos($_POST['order_id'], '100')){
		$installInfo['SoSysNo'] = substr($_POST['order_id'], 3);
	}else if(strpos($_POST['order_id'], '10') && !strpos($_POST['order_id'], '100')){
		$installInfo['SoSysNo'] = substr($_POST['order_id'], 2);
	}else{
		$installInfo['SoSysNo'] = substr($_POST['order_id'], 1);
	}

	$installInfo['soid'] = ToolUtil::transXSSContent($_POST['order_id']);

	if(empty($_POST['BranchName'])){
		Logger::err("BranchName is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 11);
	}
	$installInfo['BranchName'] = ToolUtil::transXSSContent($_POST['BranchName']);

	if(empty($_POST['ProductMode'])){
		Logger::err("ProductMode is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 12);
	}
	$installInfo['ProductMode'] = ToolUtil::transXSSContent($_POST['ProductMode']);

	if(empty($_POST['ProductID'])){
		Logger::err("ProductID is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 13);
	}
	$installInfo['ProductSysNo'] = ToolUtil::transXSSContent($_POST['ProductID']);

	if(empty($_POST['InstallAreaSysNo'])){
		Logger::err("InstallAreaSysNo is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 15);
	}
	$installInfo['InstallAreaSysNo'] =ToolUtil::transXSSContent( $_POST['InstallAreaSysNo']);

	if(empty($_POST['InstallAddress'])){
		Logger::err("InstallAddress is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 16);
	}
	$installInfo['InstallAddress'] = ToolUtil::transXSSContent($_POST['InstallAddress']);

	if(empty($_POST['ContactName'])){
		Logger::err("ContactName is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 17);
	}
	$installInfo['ContactName'] = ToolUtil::transXSSContent($_POST['ContactName']);

	if(empty($_POST['ContactPhone']) && empty($_POST['ContactMobile'])){
		Logger::err("ContactPhone or ContactMobile is empty, uid:" . $uid . "order_id:" . $_POST['order_id'] . "ContactPhone:" . $_POST['ContactPhone'] . "ContactMobile:" . $_POST['ContactMobile']);
		return array('errno' => 18);
	}
	$installInfo['ContactPhone'] = ToolUtil::transXSSContent($_POST['ContactPhone']);
	$installInfo['ContactMobile'] = ToolUtil::transXSSContent($_POST['ContactMobile']);

	if(empty($_POST['InstallTime'])){
		Logger::err("InstallTime is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 20);
	}
	$installInfo['InstallTime'] = ToolUtil::transXSSContent($_POST['InstallTime']);
	$date_new = strtotime(date('Y-m-d', time()));
	$date_my = strtotime($_POST['InstallTime']);
	if(($date_my - $date_new) <= 0){
		return array('errno' => 14);
	}

	$installInfo['Memo'] = ToolUtil::transXSSContent($_POST['Memo']);

	if(empty($_POST['ItemType'])){
		Logger::err("ItemType is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 21);
	}
	$installInfo['ItemType'] = ToolUtil::transXSSContent($_POST['ItemType']);

	if($installInfo['ItemType'] == '739'){//��ˮ��
		if(empty($_POST['PureLandMaterialType'])){//̨�����
			Logger::err("PureLandMaterialType is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
			return array('errno' => 22);
		}
		$installInfo['PureLandMaterialType'] = ToolUtil::transXSSContent($_POST ['PureLandMaterialType']);
	}else{//�յ�
		if(empty($_POST['AirConditionLineType'])){//���߳���
			Logger::err("AirConditionLineType is empty, uid:" . $uid . "order_id:" . $_POST ['order_id']);
			return array('errno' => 23);
		}
		$installInfo['AirConditionLineType'] = ToolUtil::transXSSContent($_POST['AirConditionLineType']);

		if(empty($_POST['AirConditionBracketType'])){//֧��
			Logger::err("AirConditionBracketType is empty, uid:" . $uid . "order_id:" . $_POST ['order_id']);
			return array('errno' => 24);
		}
		$installInfo['AirConditionBracketType'] = ToolUtil::transXSSContent($_POST['AirConditionBracketType']);

		if(empty($_POST['AirConditionWallType'])){//��ǽ��
			Logger::err("AirConditionWallType is empty, uid:" . $uid . "order_id:" . $_POST ['order_id']);
			return array('errno' => 25);
		}
		$installInfo['AirConditionWallType'] = ToolUtil::transXSSContent($_POST ['AirConditionWallType']);
	}

		$result = IInstall::addInstall($uid ,$installInfo);

		if($result === false){
			Logger::err("IInstall::addInstall failed, code:" . IInstall::$errCode . ', msg:' . IInstall::$errMsg . ', uid:' . $uid . " ,order_id:" . $_POST['order_id']);
			return array('errno' => 502 );
		}
		$installInfo['new_id'] = $result;
		return array ('errno' => 0, 'data'=>$result);
}