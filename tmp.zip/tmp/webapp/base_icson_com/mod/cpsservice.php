<?php
/*
 * 主要实现IUser IOrder相关TTC调用
 * 要求对比签名
 * @daopingsun 2012/11/06 14:28
 */
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IOrder.php');
require_once(PHPLIB_ROOT . 'api/IProduct.php');
require_once(PHPLIB_ROOT . 'lib/Logger.php');
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'api/distribution/IBProduct.php');

error_reporting(0);
/*
 * @param 
 * 		account
 * 		sign
 * @return s:
 * 		0 		success
 * 		10001 	param(none-optional) is empty
 *		10002	sign error
 *		10005	checkIcsonAccountExist failed
 * 		
 */
function page_cpsservice_checkIcsonAccountExist(){

	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	//Modified by EdisonTsai on 20:55 2012/11/20 for convert UTF-8 to GBK
	$account = isset($_REQUEST['account']) ? trim(iconv('UTF-8','GBK',$_REQUEST['account'])) : '';

	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($account) || empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param account or sign is empty'));
		exit;
	}
	$var = array('account' => $account , 'sign' => $sign);

		$exists = IUser::checkIcsonAccountExist($account);	
		if ($exists === false) {
			Logger::err("cpsservice IUser::checkIcsonAccountExist FAILED-" . IUser::$errCode . '-' . IUser::$errMsg);
			echo json_encode(array('s' => 10005,'m' => 'CheckIcsonAccountExist failed' .  IUser::$errCode . '-' . IUser::$errMsg));
			exit;
		}else{
			echo json_encode(array('s' => 0 , 'data' => $exists));
			exit;
		}
	
}
/*
 * @param 
 * 		account
 * 		password
 * 		sign
 *    
 * @return s:
 * 		0 		success
 * 		10001 	param(none-optional) is empty
 *		10002	sign error
 *		10006	Register failed
 */
function page_cpsservice_userRegister(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	//Modified by EdisonTsai on 20:55 2012/11/20 for convert UTF-8 to GBK
	$account = isset($_REQUEST['account']) ? trim(iconv('UTF-8','GBK',$_REQUEST['account'])) : '';
	$password = isset($_REQUEST['password'])?trim($_REQUEST['password']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($account) || empty($password) || empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param account or password or sign is empty'));
		exit;
	}
	$var = array('account' => $account ,'password' => $password, 'sign' => $sign);

		$uid = IUser::register($account, $password);

		if ($uid === false) {
			Logger::err("cpsservice IUser::register FAILED-" . IUser::$errCode . '-' . IUser::$errMsg);
			echo json_encode(array('s' => 10006 , 'm' => 'Register failed' . IUser::$errCode . '-' . IUser::$errMsg));
			exit;
		}else {
			Logger::info("cpsservice IUser::register SUCCESS-{$uid}");
			echo json_encode(array('s' => 0 , 'data' => array('uid' =>$uid)));
			exit;
		}
}
/*
 * @param 
 * 		account
 * 		password
 * 		clientIp
 * 		multiLogin
 * 		type
 * 		sign
 * 
 * @return s:
 * 		0 		success
 * 		10001 	param(none-optional) is empty
 *		10002	sign error
 *		10007	Login failed
 */
function page_cpsservice_userLogin(){
	//对整个Post数据进行签名
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}

	//Modified by EdisonTsai on 20:55 2012/11/20 for convert UTF-8 to GBK
	$account = isset($_REQUEST['account']) ? trim(iconv('UTF-8','GBK',$_REQUEST['account'])) : '';

	$password = isset($_REQUEST['password'])?trim($_REQUEST['password']):'';
	$clientIp = isset($_REQUEST['clientIp'])?trim($_REQUEST['clientIp']):'';
	$multiLogin = isset($_REQUEST['multiLogin'])?trim($_REQUEST['multiLogin']):'';
	$type = isset($_REQUEST['type'])?trim($_REQUEST['type']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	
	if(empty($account) || empty($password) || empty($clientIp) || !isset($multiLogin) || !isset($type) || empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param account,password,clientIp,multiLogin,type or sign is empty'));
		exit;
	}
	
	// $var = array(
	// 		'account' => $account ,
	// 		'password' => $password, 
	// 		'clientIp' => $clientIp,
	// 		'multiLogin' => $multiLogin,
	// 		'type' => $type,
	// 		'sign' => $sign
	// 	);
	
		$session = IUser::login($account, $password, $clientIp, $multiLogin, $type);
		if ($session === false) {
			Logger::err("cpsservice IUser::login FAILED-" . IUser::$errCode . '-' . IUser::$errMsg);
			echo json_encode(array('s' => 10007 , 'm' => '	Login failed' . IUser::$errCode . '-' . IUser::$errMsg));
			exit;
		}else{
			echo json_encode(array('s' => 0 , 'data' => array('session' => $session)));
			exit;
		}		
}
/*
 * @param 
 * 		account
 * 		password
 * 		clientIp
 * 		multiLogin
 * 		type
 * 		extra (optional)
 * 		sign
 * @return s:
 * 		 0 		Login Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *      10005 	checkIcsonAccountExist failed
 * 		10006   Register Failed
 *  	10007   Login Failed
 *  	1		other error
 */
function page_cpsservice_checkRegisterLogin(){

	//对整个Post数据进行签名
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	//file_put_contents('/tmp/gangzhao/cps_register.log', "Sign Success \n");
	$account = isset($_POST['account'])?trim(iconv('UTF-8', 'GBK', $_POST['account'])):'';
	$password = isset($_POST['password'])?trim($_POST['password']):'';
	$clientIp = isset($_POST['clientIp'])?trim($_POST['clientIp']):'';
	$multiLogin = isset($_POST['multiLogin'])?trim($_POST['multiLogin']):'';
	$type = isset($_POST['type'])?trim($_POST['type']):'';
//	$extra = isset($_POST['extra'])?trim($_POST['extra']):'';//only usersafekey(json) for 51fanli 
	$sign = isset($_POST['sign'])?trim($_POST['sign']):'';
	
	if(empty($account) || empty($password) || empty($clientIp) || !isset($multiLogin) || !isset($type) || empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param account,password,clientIp,multiLogin,type or sign is empty'));
		exit;
	}
	if(isset($_POST['realname'])){
		$realname = trim(iconv('UTF-8', 'GBK', $_POST['realname']));
	}else{
		$realname = '';
	}
	if(isset($_POST['email'])){
		$email = trim($_POST['email']);
	}else{
		$email = '';
	}
	
	$firstLogin = 0 ; 
	$uid = false;
	$exists = IUser::checkIcsonAccountExist($account);	
	if ($exists === false) {
		//file_put_contents('/tmp/gangzhao/cps_register.log', "User exists Error. \n",FILE_APPEND);
		Logger::err("cpsservice IUser::checkIcsonAccountExist FAILED-" . IUser::$errCode . '-' . IUser::$errMsg);
		echo json_encode(array('s' => 10005 ,'m' => 'CheckIcsonAccountExist failed'.$account. IUser::$errCode . '-' . IUser::$errMsg));
		exit;
	}
	if(isset($exists['exist']) && $exists['exist'] ==0){
		//file_put_contents('/tmp/gangzhao/cps_register.log', "Ready Reg \n",FILE_APPEND);
		$firstLogin = 1 ; 
		$userData['name'] = $realname;
		$userData['email'] = $email;
		
		$uid = IUser::register($account, $password,$userData); 
	
		if ($uid === false) {
			//file_put_contents('/tmp/gangzhao/cps_register.log', "Ready Failed ".IUser::$errMsg."\n",FILE_APPEND);
			Logger::err("cpsservice IUser::register FAILED-" . IUser::$errCode . '-' . IUser::$errMsg);
			echo json_encode(array('s' => 10006,'m' => 'Register failed' .  IUser::$errCode . '-' . IUser::$errMsg));
			exit;
		}else{
			Logger::info("cpsservice IUser::register SUCCESS-{$uid}");
			//Update user type 字段
			if(isset($_POST['user_type'])){
				$update = IUser::updateUser($uid, array(
					'type'	=> $_POST['user_type'] 
				));
				if($update == false){
					cpsservice_error('20002','Update User Type Error');
				}
			}			
		}	
	}
		$session = IUser::login($account, $password, $clientIp, $multiLogin, $type);

	if ($session === false) {	//有可能由于新注册等某些原因导致登录失败，重试三次						
		$retry = 0;
		while($retry < 3){
			//file_put_contents('/tmp/gangzhao/cps_register.log', "Login Failed ".IUser::$errMsg.$retry."\n",FILE_APPEND);
			$session = IUser::login($account, $password, $clientIp, $multiLogin, $type);
			if($session === false){
//				Logger::err("cpsservice IUser::login FAILED-" . IUser::$errCode . '-' . IUser::$errMsg . '- retry:' . $retry);
				$retry++;
				if($retry == 2){
					sleep(1);					
				}	
			}else{			
//				Logger::info("user {$session['uid']} login.");	
				echo json_encode(array('s' => 0 , 'data' => array('session' => $session,'firstLogin' => $firstLogin)));
				exit;
			}	
		}
		if($session === false){
			//file_put_contents('/tmp/gangzhao/cps_register.log', "Ready Failed Try Done ".IUser::$errMsg."\n",FILE_APPEND);
			Logger::err("cpsservice IUser::login FAILED-" . IUser::$errCode . '-' . IUser::$errMsg);
			echo json_encode(array('s' => 10007,'m' => 'Login failed' .  IUser::$errCode . '-' . IUser::$errMsg));	
			exit;
		}
	}else{
		Logger::info("user {$session['uid']} login.");
		echo json_encode(array('s' => 0 , 'data' => array('session' => $session,'firstLogin' => $firstLogin)));
		exit;
	}

}
function cpsservice_error($code,$msg){
	echo json_encode(array('s'=> $code,'m' => $msg));
	exit;
}
/*
 * @param 
 * 			'uid' => $uid,
			'name' => $name,
			'nick' => $nick,
			'address' => $address,
			'email' => $email,
			'zipcode' =>$zipcode,
			'phone' => $phone,
			'mobile' => $mobile,
			'city' => $city,
			'sign' => $sign
 * @return s:
 * 		 0 		updateUser Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *  	1		other error
 */
function page_cpsservice_updateUser(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	$uid = isset($_REQUEST['uid'])?trim($_REQUEST['uid']):'';
	$name = isset($_REQUEST['name'])?trim($_REQUEST['name']):'';
	$nick = isset($_REQUEST['nick'])?trim($_REQUEST['nick']):'';
	$address = isset($_REQUEST['address'])?trim($_REQUEST['address']):'';
	$email = isset($_REQUEST['email'])?trim($_REQUEST['email']):'';
	$zipcode = isset($_REQUEST['zipcode'])?trim($_REQUEST['zipcode']):'';
	$phone = isset($_REQUEST['phone'])?trim($_REQUEST['phone']):'';
	$mobile = isset($_REQUEST['mobile'])?trim($_REQUEST['mobile']):'';
	$city = isset($_REQUEST['city'])?trim($_REQUEST['city']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($uid) || empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param uid or sign is empty'));
		exit;
	}

		$basicinfo = array(
				'name' => $name,
				'nick' => $nick,
				'address' => $address,
				'email' => $email,
				'zipcode' =>$zipcode,
				'phone' => $phone,
				'mobile' => $mobile,
				'city' => $city,
			);
		$basicinfo_ret = IUser::updateUser($uid, $basicinfo);
		if ($basicinfo_ret === false) {
			Logger::err('cpsservice IUser::updateUser FAILED-' . IUser::$errCode . '-' . IUser::$errMsg);
			echo json_encode(array('s' => 1 ,'m' => 'UpdateUser failed' . IUser::$errCode . '-' . IUser::$errMsg));
			exit;
		}
		else {
			Logger::info('cpsservice IUser::updateUser SUCCESS');
			echo json_encode(array('s' => 0));
			exit;
		}
	
}
/*
 * @param
 * 		'uid' =>
 *		'name' => 
		'mobile' => 
		'address' => 
		'district' =>
		'sign' =>
 * @return s:
 * 		 0 		addAddress Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *  	1		other error
 */
function page_cpsservice_addAddress(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	$uid = isset($_REQUEST['uid'])?trim($_REQUEST['uid']):'';
	$name = isset($_REQUEST['name'])?trim($_REQUEST['name']):'';
	$mobile = isset($_REQUEST['mobile'])?trim($_REQUEST['mobile']):'';
	$address = isset($_REQUEST['address'])?trim($_REQUEST['address']):'';
	$district = isset($_REQUEST['district'])?trim($_REQUEST['district']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($uid) || empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param uid or sign is empty'));
		exit;
	}

		$addr = array(
			'name' => $name,
			'mobile' => $mobile,
			'address' => $address,
			'district' => $district,
		);
		$address_ret = IUser::addAddress($uid,$addr);
		if ($address_ret === false) {
//			Logger::err('cpsservice IUser::addAddress FAILED-' . IUser::$errCode . '-' . IUser::$errMsg);
			echo json_encode(array('s' => 1 , 'm' => 'AddAddress failed'. IUser::$errCode . '-' . IUser::$errMsg));
			exit;
		}
		else {
//			Logger::info('cpsservice IUser::addAddress SUCCESS');
			echo json_encode(array('s' => 0));
			exit;
		}

}
/*
 * @param
 * 		'uid' =>
 *		'order_id' => 
		'sign' =>
 * @return s:
 * 		 0 		getOneOrder Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *  	1		other error
 */
function page_cpsservice_getOneOrder(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	$uid = isset($_REQUEST['uid'])?trim($_REQUEST['uid']):'';
	$order_id = isset($_REQUEST['order_id'])?trim($_REQUEST['order_id']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($uid) || empty($order_id)|| empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param uid or orderId or sign is empty'));
		exit;
	}
	$var = array(
		'uid' => $uid,
		'order_id' => $order_id,
		'sign' => $sign
	);
	
		$order = IOrder::getOneOrder($uid, $order_id);

		if ($order === false) {
//			self::setERR(500, "get order {$orderId} FAILED.");
			echo json_encode(array('s' => 1 , 'm' => 'Get order failed' .IOrder::$errCode.'|'.IOrder::$errMsg)); //未找到订单
			exit;
		}else{
		$data = ToolUtil::gbJsonEncode($order);
		$data = iconv('gbk','utf-8',$data);
		echo json_encode(array('s' => 0 , 'data' => $data));
			exit;
		}
}
/*
 * @param
 * 		'uid' =>
 *		'order_id' => 
		'sign' =>
 * @return s:
 * 		 0 		getOneOrderDetail Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *  	1		other error
 */
function page_cpsservice_getOneOrderDetail(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	$uid = isset($_REQUEST['uid'])?trim($_REQUEST['uid']):'';
	$order_id = isset($_REQUEST['order_id'])?trim($_REQUEST['order_id']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($uid) || empty($order_id)|| empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param uid or order_id or sign is empty'));
		exit;
	}
	$var = array(
		'uid' => $uid,
		'order_id' => $order_id,
		'sign' => $sign
	);

		$order = IOrder::getOneOrderDetail($uid, $order_id);
//	file_put_contents('/tmp/daopingsun/testPSF_order_pusher.txt', 'cpsservice:order---'.print_r($order,true)."\n", FILE_APPEND);

		if ($order === false) {
//			self::setERR(500, "get order {$orderId} FAILED.");
			echo json_encode(array('s' => 1 , 'm' => 'Get order failed' .IOrder::$errCode.'|'.IOrder::$errMsg)); //未找到订单
			exit;
		}else{
		$data = ToolUtil::gbJsonEncode($order);
		$data = iconv('gbk','utf-8',$data);
//		file_put_contents('/tmp/daopingsun/testPSF_order_pusher.txt', 'cpsservice:data---'.print_r($data,true)."\n", FILE_APPEND);
		echo json_encode(array('s' => 0 , 'data' => $data));
		exit;
	}	
}
/*
 * @param
 * 		'uid' =>
		'sign' =>
 * @return s:
 * 		 0 		getUserInfo Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *  	1		other error
 */
function page_cpsservice_getUserInfo(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	$uid = isset($_REQUEST['uid'])?trim($_REQUEST['uid']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($uid) || empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param uid or sign is empty'));
			exit;
		}
		
	$userInfo = IUser::getUserInfo($uid);
	if($userInfo === false){
		echo json_encode(array('s' => 1 , 'm' => 'Get userinfo failed' .IUser::$errCode.'|'.IUser::$errMsg)); //未找到订单
		exit;		
	}else{
		if(isset($userInfo['qq']) && !empty($userInfo['qq'])){
			global $_IP_CFG;
			if(isset($_IP_CFG['QQ_OPENIDS']) && is_array($_IP_CFG['QQ_OPENIDS'])){
				$ip_key = array_rand($_IP_CFG['QQ_OPENIDS'],1);
				$ip = $_IP_CFG['QQ_OPENIDS'][$ip_key];
			}else if(isset($_IP_CFG['QQ_OPENIDS'])){
				$ip = $_IP_CFG['QQ_OPENIDS'];
			}

			$url = "http://".$ip.":8080/openid/decopenid.php?func=getopenidbyuin&uin=".$userInfo['qq'];
			$qqinfo = NetUtil::cURLHTTPGet($url);
			$ret = json_decode($qqinfo);
			$openID = strtoupper($ret->openid);
			$userInfo['icsonid'] = 'Login_QQ__'.$openID;
		}
		$data = ToolUtil::gbJsonEncode($userInfo);
		$data = iconv('gbk','utf-8',$data);
		echo json_encode(array('s' => 0 , 'data' => $data));
		exit;
	}	
}
/*
 * @param
 * 		'product_id' =>
 * 		'wh_id' =>
		'sign' =>
 * @return s:
 * 		 0 		getProductBaseInfo Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *  	1		other error
 */
function page_cpsservice_getProductBaseInfo(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	$product_id = isset($_REQUEST['product_id'])?trim($_REQUEST['product_id']):'';
	$wh_id = isset($_REQUEST['wh_id'])?trim($_REQUEST['wh_id']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($product_id) || empty($wh_id) || empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param product_id or wh_id or sign is empty'));
		exit;
	}

	$baseInfo = IProduct::getBaseInfo($product_id , $wh_id);
	if($baseInfo === false){
		echo json_encode(array('s' => 1 , 'm' => 'GetBaseInfo failed' .IProduct::$errCode.'|'.IProduct::$errMsg)); //未找到订单
		exit;		
	}else{
		$data = ToolUtil::gbJsonEncode($baseInfo);
		$data = iconv('gbk','utf-8',$data);
		echo json_encode(array('s' => 0 , 'data' => $data));
		exit;
	}
}
/*
 * @param
 * 		'c3_ids' =>
		'sign' =>
 * @return s:
 * 		 0 		getProductBaseInfo Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *  	1		other error
 */
function page_cpsservice_getCategoryInfo(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	$c3_ids = isset($_REQUEST['c3_ids'])?trim($_REQUEST['c3_ids']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($c3_ids) || empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param c3_ids or sign is empty'));
		exit;
	}

	$categoryInfo = IBProduct::getCategoryInfo($c3_ids,true);
	if($categoryInfo === false){
		echo json_encode(array('s' => 1 , 'm' => 'GetCategoryInfo failed' .IBProduct::$errCode.'|'.IBProduct::$errMsg)); //未找到订单
		exit;		
	}else{
		//1548**880**881
		//个护、清洁、纸品**生活用纸**手帕纸(src:GBK,dest:utf-8)
		$categoryId ='';
		$category  = '';
		foreach($categoryInfo as $k => $v){

	        $categoryId .= $v['id'];
	        $category .= $v['name'];
	        if($k != count($categoryInfo)-1){
	                $categoryId .= '**';
	                $category .= '**';
	        }
		}
		$categoryData = array('category_id' =>  $categoryId , 'category' => $category);

		$data = ToolUtil::gbJsonEncode($categoryData);
		$data = iconv('gbk','utf-8',$data);
		echo json_encode(array('s' => 0 , 'data' => $data));
		exit;
	}
}
/*
 * @param
 * 		'uid' =>
 *		'order_id' => 
		'sign' =>
 * @return s:
 * 		0 		getOrderItems Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *  	1		other error
 */
function page_cpsservice_getOrderItems(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	//file_put_contents('/tmp/daopingsun/cpsservice_1.txt', 'getorderitem---'.'come in'."\n", FILE_APPEND);
	$uid = isset($_REQUEST['uid'])?trim($_REQUEST['uid']):'';
	$order_id = isset($_REQUEST['order_id'])?trim($_REQUEST['order_id']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($uid) || empty($order_id)|| empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param uid or orderId or sign is empty'));
		exit;
	}
	$var = array(
		'uid' => $uid,
		'order_id' => $order_id,
		'sign' => $sign
	);

		$order_items = IOrder::getOrderItems($uid, $order_id);

		//file_put_contents('/tmp/daopingsun/cpsservice.txt', print_r($response,true),FILE_APPEND);
		//file_put_contents('/tmp/daopingsun/cpsservice.txt', 'getorderitem---'.print_r($order_items,true)."\n", FILE_APPEND);
		if($order_items === false){
			echo json_encode(array('s' => 1 , 'm' => 'Get orderItems failed'.IOrder::$errCode.'|'.IOrder::$errMsg)); 
			exit;
		}else{
		$data = ToolUtil::gbJsonEncode($order_items);
		$data = iconv('gbk','utf-8',$data);
		echo json_encode(array('s' => 0 , 'data' => $data));
		exit;
	}
}
/*
 * @param
 * 		'uid' =>
 *		'orderId' => 
		'sign' =>
 * @return s:
 * 		0 		geOrderFlow Success
 * 		10001 	param(none-optional) is empty
 * 		10002 	Sign Error
 *  	1		other error
 */
function page_cpsservice_geOrderFlow(){
	if(!checkSig($_POST)){
		cpsservice_error(10002,'Sign Error'.print_r($_POST,true));
	}
	$uid = isset($_REQUEST['uid'])?trim($_REQUEST['uid']):'';
	$order_id = isset($_REQUEST['orderId'])?trim($_REQUEST['orderId']):'';
	$sign = isset($_REQUEST['sign'])?trim($_REQUEST['sign']):'';
	if(empty($uid) || empty($order_id)|| empty($sign)){
		echo json_encode(array('s' => 10001 , 'm' => 'Param uid or orderId or sign is empty'));
		exit;
	}
	$var = array(
		'uid' => $uid,
		'orderId' => $order_id,
		'sign' => $sign
	);
	
		$order_flow = IOrder::geOrderFlow($uid, $order_id);
		if($order_flow === false ){
			echo json_encode(array('s' => 1 , 'm' => 'Get orderFlow failed'.IOrder::$errCode.'|'.IOrder::$errMsg));
			exit;
		}else{
		$data = ToolUtil::gbJsonEncode($order_flow);
		$data = iconv('gbk','utf-8',$data);
		echo json_encode(array('s' => 0 , 'data' => $data));
		exit;
	}
}
function page_cpsservice_server(){
	file_put_contents('/tmp/daopingsun/cpsServer.txt',print_r($_GET,true),FILE_APPEND);
	echo 'SUCCEED';
}	
function checkSig($var,$extra=array(),$sign_type='MD5'){
    if(!is_array($var) || count($var)<1){
        return false;
    }
    ksort($var);
    reset($var);

    $var = array_map('trim',$var);

	$sigOld = null;
	$vars= $var;

	foreach($vars AS $k=>$v){
		if('sign' == $k){
			$sigOld = $v;
		} else {
			$v = urldecode($v);
			$var[$k]= get_magic_quotes_gpc() ? stripslashes($v) : $v;
		}
	 } 

    $sigNew = genSig($var,$extra,$sign_type);

	unset($var,$vars,$k,$v);

    return $sigOld == $sigNew ? true : false;
}
function genSig($var,$extra=array(),$sign_type='MD5'){
	global $cps_keycode;
	if(!isset($cps_keycode) || empty($cps_keycode)){
		return '0';
	}
	if(!is_array($var) || count($var)<1){
		return '0';
	}
	$rmKeys = array('callback','sign');
	if(count($extra)>=1){
		$rmKeys = array_merge($rmKeys,$extra);
	}
	ksort($var);
	reset($var);
	$var = array_map('trim',$var);
	
	$t = '';
	foreach($var AS $k=>$v){
		$t .= !in_array($k, $rmKeys) ? $k.'='.urlencode($v).'&' : '';
	} 	
//	file_put_contents('/tmp/daopingsun/testPSF_order_pusher.txt', 'cps_keycode---'.print_r($cps_keycode,true)."\n", FILE_APPEND);
	switch($sign_type){
		case 'MD5':
			$t = md5($t.$cps_keycode);break;
		default:
			$t = md5($t.$cps_keycode);break;
	}
	unset($var,$k,$v);
	
	return $t;
}