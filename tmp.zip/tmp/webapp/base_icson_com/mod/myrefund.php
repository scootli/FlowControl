<?php
require_once (PHPLIB_ROOT . 'api/IProduct.php');
require_once (PHPLIB_ROOT . 'api/IRMANew.php');
require_once (PHPLIB_ROOT . 'api/IUser.php');
require_once (PHPLIB_ROOT . 'api/IOrder.php');
require_once (PHPLIB_ROOT . 'inc/district.inc.php');
require_once (PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once (PHPLIB_ROOT . 'api/IShipping.php');
require_once (PHPLIB_ROOT . 'api/IShippingTime.php');
require_once (PHPLIB_ROOT . 'inc/ship.inc.php');

Logger::init ();

//�ҵ��˿�����
function page_myrefund_page(){
	global $rma_refundType, $rma_refundStatus;
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL( 0, "myrefund", array ('titleDesc' => '�˿�����' ) );
	$TPL->set_var('pageName', '�˿�����' );

	$whId = IUser::getSiteId();
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	if($currentPage < 1){$currentPage = 1;}
	$pageSize = 10;
	$refundList = IRMANew::getRefundInfo($uid, $whId, $pageSize, ($currentPage-1));
	if($refundList === false){
		Logger::err("IRMANew::getRefundInfo failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg .',uid:'.$uid, ',whid:'. $whId);
		return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL );
	}

	$TPL->set_file( array ('contentHandler' => 'myrefund_content.tpl'));
	$TPL->set_block('contentHandler', 'refund_list', 't_refund_list');
	if(!empty($refundList['data']) && count($refundList['data']) >0){
		$total = ceil($refundList['total'] / $pageSize);
		foreach($refundList['data'] as $refund){
			$vars = array();
			//��Ʒ��Ϣ
			if(empty($refund['Iproducts'])) {
				$vars['t_refund_list_items'] = '';
			}else{
				$vars['t_refund_list_items'] = get_products_info($refund['Iproducts'], $TPL, $whId);
			}
			//����
			if(empty($refund['RRegister'])) {
				$refund_sysno = $refund['SysNo'];
				if(-1 == $refund['Status']){
					$vars['t_register'] = '<p>�û�����</p>';
				}else{
					$vars['t_register'] = '<a class="todo_link" id="a_refund_'.$refund_sysno.'" href="javascript:void(0);" onclick="G.app.mycenter.myrefund.cancel_refund(this, \''. $refund['SysNo'] .'\'); return false;">ȡ��</a>';
				}
			}else{
				foreach($refund['RRegister'] as &$re){
					$vars['t_register'] = "<a class=\"todo_link\"target=\"_blank\" href=\"http://base.51buy.com/myrefundinfo-{$re['R_RequestSysNo']}-{$re['R_SysNo']}.html\">�鿴����</a>";
				}
				//$vars['t_register'] = get_operation_info($refund['RRegister']);
			}
			$vars['php_sysno'] 			= $refund['SysNo'];
			$vars['php_request_id'] 	= $refund['RequestSysNo'];
			$vars['php_order_id'] 		= $refund['SOID'];
			$vars['php_refund_cash'] 	= sprintf("%1\$.2f", $refund['RequestAmt']);
			$vars['php_refund_point']	=  $refund['RequestPoint'];
			$vars['php_refund_type']	= $rma_refundType[$refund['RefundTypeSysNo']];
			$vars['php_refund_status']	= $rma_refundStatus[$refund['Status']];
			$vars['php_request_time']	= (empty($refund['RequestDate']) || (strtotime($refund['RequestDate']) < 0)) ? '' : $refund['RequestDate'];
			$TPL->set_var($vars);
			$TPL->parse('t_refund_list', 'refund_list', true);
			$TPL->unset_var(array_keys($vars));
			$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myrefund-{page}.html', $currentPage, $total)  . '</div></div>');
		}
	}else{
		$TPL->set_var('page','');
		$TPL->set_var(array('t_refund_list' => '<tr><td colspan="7"><p class="kong">�����û�������˿</p></td></tr>' ) );
	}

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//��д�˿�����
function page_myrefund_report() {
	$uid = ToolUtil::checkLoginOrRedirect ();
	$TPL = TemplateHelper::getBaseTPL ( BaseTPL::NO_LEFT_NAV, "myrefund_report", array ('titleDesc' => '��д�˿�����' ) );

	$TPL->set_var ( array ('pageName' => '��д�˿�����', 'left_nav' => '' ) );

	$TPL->set_file ( array ('contentHandler' => 'myrefund_report_content.tpl' ) );
	$TPL->parse ( 'content', 'contentHandler' );

	$TPL->set_file ( array ('refundBankInfo' => 'refund_bankinfo.tpl' ) );
	$TPL->parse ( 'contentBank', 'refundBankInfo' );
	$TPL->out ();
}

//�����˿�
function myrefund_add(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		Logger::err("is not uid" . IUser::$errCode . ', msg:' . IUser::$errMsg );
		return array ('errno' => 500 );
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		Logger::err("uid is empty");
		return array ('errno' => 501 );
	}

	$refundInfo = array ('user_id' => $uid );

	if(empty($_POST['order_id'])){
		Logger::err("order_id is empty, uid:" . $uid );
		return array('errno' => 10 );
	}

	$refundInfo['order_id'] = $_POST['order_id'];

	if(empty($_POST['order_items'])){
		Logger::err("order_items is empty, uid:" . $uid . "order_id:" . $_POST['order_id']);
		return array('errno' => 11);
	}

	$refundInfo['product_ids'] = explode(',', $_POST['order_items']);
	if(empty($refundInfo['product_ids'])){
		Logger::err("product_ids is empty, uid:" . $uid . "order_id:" . $_POST['order_id'] . "order_items:" . $_POST['order_items']);
		return array('errno' => 12);
	}

	$refundInfo['product_desc'] = ToolUtil::transXSSContent($_POST['product_desc']);

	if(empty($_POST['refund_type'])){
		Logger::err("refund_type is empty");
		return array('errno' => 15);
	}

	if(isset($_POST['pay_type']) && !empty($_POST['pay_type'])){
		$refundInfo['pay_type'] = $_POST['pay_type'];
	}
	$pay_type = $_POST['pay_type'];

	$refundInfo['refund_type'] = $_POST['refund_type'];
	if(2 == $refundInfo['refund_type']){//�˿������п�
		if(empty($_POST['sel_online_pay'])){
			Logger::err ( "sel_online_pay is empty");
			return array ('errno' => 16 );
		}
		$refundInfo['sel_online_pay'] = $_POST['sel_online_pay'];

		if(empty($_POST['area_id'])){
			Logger::err ( "area_id is empty");
			return array ('errno' => 17 );
		}
		$refundInfo['area_id'] = $_POST['area_id'];

		if(empty($_POST['sel_refund_bank'])){
			Logger::err ( "sel_refund_bank is empty");
			return array ('errno' => 18 );
		}
		$refundInfo['refund_bank'] = $_POST['sel_refund_bank'];

		if(empty($_POST['account_name'])){
			Logger::err ( "account_name is empty");
			return array ('errno' => 19 );
		}
		$refundInfo['account_name'] = $_POST['account_name'];

		if(empty($_POST['account_no'])){
			Logger::err ( "account_no is empty");
			return array ('errno' => 20 );
		}
		$refundInfo['account_no'] = $_POST['account_no'];

		if(empty($_POST['mobile_phone'])){
			Logger::err ( "mobile_phone is empty");
			return array ('errno' => 21 );
		}
		$refundInfo['mobile_phone'] = $_POST['mobile_phone'];
		$refundInfo['bank_cityName'] = empty($_POST['bank_cityName']) ? $_POST['area_id'] : $_POST['bank_cityName'];//��������
		$refundInfo['refund_bankName'] = empty($_POST['refund_bankName']) ? $_POST['sel_refund_bank'] : $_POST['refund_bankName'];//֧������
	}else{
		if($pay_type == 15){//�˿�������OK��
			if(empty($_POST['lianhua_ok_id'])){
				Logger::err ( "lianhua_ok_id is empty");
				return array ('errno' => 22 );
			}
			$refundInfo['lianhua_ok_id'] = $_POST['lianhua_ok_id'];
		}


		if($pay_type == 32){//�˿���һ�ǿ�
			if(empty($_POST['yicheng_id'])){
				Logger::err( "yicheng_id is empty");
				return array('errno' => 23);
			}
			$refundInfo['yicheng_id'] = $_POST['yicheng_id'];
		}
	}

	$order = IOrder::getOneOrder($uid, $refundInfo['order_id']);
	if($order === false){
		Logger::err("IOrder::getOneOrder failed, code:" . IOrder::$errCode . ', msg:' . IOrder::$errMsg .',uid:'.$uid . ',order_id:' . $refundInfo['order_id']);
		return array('errno' => 6001);
	}

	if($order['status'] != 4){
		Logger::err("status <> 4");
		return array('errno' => 24 );
	}

	$available = IRMANew::getAvaliableOrderProducts($uid, $refundInfo['order_id'], $refundInfo['product_ids'], $order['hw_id'],1);
	if($available === false){
		Logger::err( "IRMANew::getAvaliableOrderProducts failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg .', uid:' . $uid . ', order_id:' . $refundInfo['order_id']);
		return array('errno' => 6003);
	}

	foreach($refundInfo['product_ids'] as $k => $idItem ){
		if(isset($available[$idItem]) && $available[$idItem] === false){
			Logger::err("IRMANew::getAvaliableOrderProducts this product_is can't refund, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg );
			return array('errno' => 25, 'data' => $idItem);
		}
	}

	$result = IRMANew::addRefund($refundInfo, $order['hw_id']);
	if ($result === false){
		Logger::err("IRMANew::addRefund failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg. ', uid:' . $uid. ',whid:'. $order['hw_id']);
		return array('errno' => 6002 );
	}

	return array('errno' => 0 );
}

// ��ȡ�����˿����Ʒ�б�
function myrefund_getavailableproducts(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		return array('errno' => 500);
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 501);
	}

	if(empty($_GET['order_id'])){
		return array('errno' => 11 );
	}
	$order_id = $_GET['order_id'];

	$whId = IUser::getSiteId();
	$order = IOrder::getOneOrderDetail($uid, $order_id);
	if($order === false){
		Logger::err( "IOrder::getOneOrderDetail failed, code:" . IOrder::$errCode . ', msg:' . IOrder::$errMsg . ',uid:' .$uid. ',order_id:' . $order_id);
		return array('errno' => 6001 );
	}

	if($whId != $order['hw_id']){
		return array('errno' => 12 ,'siteID'=>$order['hw_id']);
	}

	if($order['status'] != 4){
		return array('errno' => 13 );
	}

	if(empty($order['items'])){
		$order['items'] = array ();
	}

	$ids = array();
	foreach($order['items'] as $item){
		$ids[] = $item['product_id'];
		if(empty($item['gift'])) continue;
		foreach($item['gift'] as $gift){
			$ids[] = $gift['product_id'];
		}
	}

	$available = IRMANew::getAvaliableOrderProducts($uid, $order_id, $ids, $order['hw_id'],1);
	if($available === false){
		Logger::err( "IRMANew::getAvaliableOrderProducts failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg .', uid:' . $uid . ', order_id:' . $order_id);
		return array('errno' => 6002);
	}

	foreach($order['items'] as $k => $item){
		if(isset($available[$item['product_id']]) && $available[$item['product_id']] === false) {
			$order['items'][$k]['canrepair'] = false;
		} else {
			$order['items'][$k]['canrepair'] = true;
		}

		if(empty($item['gift'])) continue;
		foreach($item['gift'] as $v => $gift){
			if(isset( $available[$gift['product_id']]) && $available[$gift['product_id']] === false){
				$order['items'][$k]['gift'][$v]['canrepair'] = false;
			} else {
				$order['items'][$k]['gift'][$v]['canrepair'] = true;
			}
		}
	}

	//����ǩ��̬�����¸�ֵ
	$order['is_sign'] = true;//�Ƿ���ǩ����ˮ (Ĭ��true����ǩ����ˮ��)
	if($order['order_date'] < 1324512000){//2012��12��22��֮ǰ�Ķ�������û��ǩ����ˮ�� 1324512000
		$order['is_sign'] = false;
	}

	//�Ƿ�����Ѹ���(����ȫ����):ICSON_DELIVERY,ICSON_DELIVERY_QF.��������ݸ��ݶ����Ƿ�����������ж����ѳ������ۺ��˿�����
	$shipping_type = array(1,22,44,45);
	if(!in_array($order['shipping_type'],$shipping_type)){//����Ѹ���
		if($order['status'] != 4){//����δ����������ϵ�
			$order['refund_type'] = false;//true:��ǩ��(�ѳ���),false:δǩ��(����δ����������ϵ�)
		}else{
			$order['refund_type'] = true;
		}
	}

	return array ('errno' => 0, 'data' => $order );
}

//��ȡ���뵥��Ʒ�б���Ϣ
function get_products_info(&$product, $TPL, $whId) {
	$html = '';
	if (!empty($product)) {
		foreach($product as &$p){
			$pid =  $p['I_ProductSysNo'];
			$pinfo = IProduct::getBaseInfo($pid, $whId, true);
			if($pinfo === false){
				Logger::err("IProduct::getBaseInfo failed, code:" . IProduct::$errCode . ', msg:' . IProduct::$errMsg .', pid:' . $pid . ', whid:' . $whId);
				return _output_error("ϵͳ��æ�����Ժ����ԣ�", $TPL);
			}else if(empty($pinfo) || count($pinfo) <0){
				$html .= "<div class=\"goods_info\"></div>";
			}else{
				$html .= "<div class=\"goods_info\">
							<a href=\"http://item.51buy.com/item-{$pinfo['product_id']}.html\" target=\"_blank\">{$pinfo['name']}</a></dt>
							<p class=\"goods_no nor\">��Ʒ��ţ�{$pinfo['product_char_id']}</p>
						</div>";
			}
		}
	}
	return $html;
}

//����(�鿴����)
function get_operation_info(&$registerInfo) {
	$html = '';
	foreach($registerInfo as &$re){
		$html .= "<a class=\"todo_link\"target=\"_blank\" href=\"http://base.51buy.com/myrefundinfo-{$re['R_RequestSysNo']}-{$re['R_SysNo']}.html\">�鿴����</a>";
	}
	return $html;
}

//����(ȡ������)
function myrefund_cancelrefund(){
	$uid = IUser::getLoginUid();
	if(!$uid){
		Logger::err("is not uid" . IUser::$errCode . ', msg:' . IUser::$errMsg );
		return array ('errno' => 500 );
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		Logger::err("uid is empty");
		return array ('errno' => 501 );
	}

	if(empty($_GET['refund_sysno'])){
		return array('errno' => 1001);
	}
	$refund_sysno = $_GET['refund_sysno'];

	$ret = IRMANew::cancel_refund($uid, $refund_sysno);
	if(false === $ret){
		Logger::err ( "IRMANew::cancel_refund failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg . ', uid:' . $uid);
		return array('errno' => 1002);
	}

	return array('errno' => 0);
}

//��ȡ֧������
function myrefund_getBanks(){
	if(empty($_GET['query_banks'])){
		Logger::err("query_banks is empty");
		return array ('errno' => 1 );
	}
	$query_banks = $_GET['query_banks'];

	$banks = IRMANew::getBas_banks($query_banks);
	if(false === $banks){
		Logger::err( "IRMANew::getBas_banks failed, code:" . IRMANew::$errCode . ', msg:' . IRMANew::$errMsg );
		return array('errno' => 1001);
	}

	if(empty($banks)){
		return array('errno' => 2);
	}
	return array('errno' => 0, 'data'=> $banks);
}

//������ʾģ��
function _output_error($str, &$TPL) {
	$TPL->set_var('content', '<div class="i_content" style="text-align:center">' . $str . '</div>' );
	$TPL->out ();
}