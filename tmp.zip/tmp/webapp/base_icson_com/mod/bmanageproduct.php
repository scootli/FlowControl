<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/Logger.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');
require_once(PHPLIB_ROOT . 'api/ISearch.php');
require_once(PHPLIB_ROOT . 'api/distribution/IBProduct.php');
header('Content-Type:text/html;charset=GB2312');
Logger::init();

/**
 * page - ��ʼѡƷ��������
 */
function page_bmanageproduct_page()
{
	/**
	 * ��ʼ��ѯ���������ʾΪ��
	 * ֱ�����tpl
	 */
	page_bmanageproduct_search();
}

/**
 * page - ���ݲ�ѯ�����ѡƷ��ѯ���ҳ��
 */
function page_bmanageproduct_search()
{
	$uid = ToolUtil::checkLoginOrRedirect(); 
	$TPL = TemplateHelper::getBaseTPL(0,'b_manage_product', array(
		'titleDesc' => 'ѡƷ����'
	));

	$TPL->set_file(array(
		'contentHandler' => 'b_manage_product.tpl'
	));
	
	$TPL->set_var('php_class1',bmanageproduct_getclass1());
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	$pageSize = 24;
	$TPL->set_var('pageName','ѡƷ����');
	$TPL->set_block("contentHandler", 'list', 't_list');
	
	$key = empty( $_GET['productstrid'] ) ? '' :$_GET['productstrid'];

	$input = array(
		'key' => empty( $_GET['productstrid'] ) ? '' : iconv('utf-8','gb2312',urldecode( $_GET['productstrid'])),
		'classId' => empty( $_GET['id'] ) ? '' : intval($_GET['id']) ,
		'currentPage' => empty( $_GET['page'] ) ? 1 : $_GET['page'] + 0,  //��ǰҳ
		'pageSize' => $pageSize, 
		'sort' => 6,
		'desc' =>  1, 
		'day' =>   0,
		'attrInfo' => '', 
		'price' => '', 
		'viewMode' => empty($_GET['viewmode']) ? 1 : ($_GET['viewmode'] - $_GET['viewmode'] % 10 ) / 10 + 0, //�鿴ģʽ
		'option' => empty($_GET['option']) ? '' :  $_GET['option'],
	    'areacode' => 1
	);
	
	$response = ISearch::gets($input);
	if( false === $response)
	{
		Logger::err("ISearch::gets failed-" . ISearch::$errCode . '-' . ISearch::$errMsg);
		return TemplateHelper::outMessage('���磬���������������Ⱥȱ���ɣ����Ͼͺ�~');
	}
	$TPL->set_var('product_str_id' ,ToolUtil::transXSSContent($input['key']));
	$input['key'] = $key;
	if (0 == ($response['totalNum'] + 0))
	{
		$TPL->set_var('t_list', '<tr><td colspan="7"><p class="kong">'.'��ǰ�޷��ϲ�ѯ����Ʒ' .'</p></td></tr>');
		$TPL->set_var('pagehtml', '');
		
		//ҳ��ˢ�º󣬻ָ�������
		if (strlen($input['classId']))
		{
			$category = IBProduct::getCategoryInfo($input['classId'],true);
			$TPL->set_var('rclass3' , $category[2]['id']);
			$TPL->set_var('rclass2' , $category[1]['id']);
			$TPL->set_var('rclass1' , $category[0]['id']);
		}
		$TPL->set_var('list_filter', '');
		$TPL->parse('content', 'contentHandler');
		$TPL->out();
	}
	$data = array();
	$category  = array();
	global $_StockTips; 
	$pids = array();
	foreach ($response['list'] AS $product)
	{
		array_push($pids, $product['sysNo']);
	}
	/**������ȡ�����Ϣ*/
	$stock = IBProduct::getStockInfo($pids);
	/**������ȡ��������Ʒ*/
	$products_added = IBProduct::getProductsByRetailer(array('retailerId'=>$uid,'pids'=> $pids));
	/**������ȡ�����۸���Ϣ*/
	$price_att = IBProduct::getProductDistributionPrice($uid,$pids);
    if (false == $price_att)
    {
        self::$errCode = IBProduct::$errCode;
        self::$errMsg =  basename(__FILE__, '.php') . " |" . __LINE__ . '[get getProductDistributionPrice failed]' . IBProduct::$errMsg;
        return false;
    }
	/**������ȡ��Ʒ������Ϣ*/
    $products_info = IProduct::getProductsInfo($pids);
        if (false === $products_info) 
        {
            self::$errCode = IProductCommonInfoTTC::$errCode;
            self::$errMsg =  basename(__FILE__, '.php') . " |" . __LINE__ . '[get IProductCommonInfoTTC failed]' . IProductCommonInfoTTC::$errMsg;
            return false;
        }
	foreach ($response['list'] as $index => $item)
	{
		$data['product_selected'] =  ' ';
		if(false != $products_added)
		{
			foreach ($products_added['list'] AS $product_added)
			{
				if ($product_added['productId'] == $item['sysNo'])
				{
					$data['product_selected'] = 'disabled= "disabled"';
					break;
				}
			}
		}
		if (!isset($products_info[$item['sysNo']])) 
		{
		   continue;
		}
		$basicinfo = $products_info[$item['sysNo']];
		$data['product_id'] = $item['sysNo'];
		$data['name'] = $item['productTitle']; 
		$data['product_char_id'] = $item['productID'];
		$data['product_url'] = "http://item.51buy.com/productdetail-". $item['sysNo'] . ".html";	
	   
		$data['stock'] = (  (!isset($stock[$item['sysNo']])) || ((isset($stock[$item['sysNo']])) && ($stock[$item['sysNo']] == $_StockTips['not_available'] ))  ) ? '�޻�' : '�л�';
		$data['pic'] = IProduct::getPic($item['productID']) ;
		$data['product_char_id']= $item['productID'];
		$data['category'] = IBProduct::getCategoryInfo($basicinfo['c3_ids']);
		$data['price'] = isset($price_att[$item['sysNo']])? IBProduct::convertToString($price_att[$item['sysNo']]) :'δ����' ;
		$data['product_desc'] = $basicinfo['promotion_word'] ;
		if (('�޻�' === $data['stock']) || !isset($price_att[$item['sysNo']]) || $basicinfo['status'] != 1)
		{
			$data['product_selected'] = 'disabled= "disabled"';
		}
		
		$TPL->set_var($data);
		$TPL->parse('t_list', 'list', true);
	}
	//ҳ��ˢ�º󣬻ָ�������
	if (strlen($input['classId']))
	{
		$category = IBProduct::getCategoryInfo($input['classId'],true);
		$TPL->set_var('rclass3' , $category[2]['id']);
		$TPL->set_var('rclass2' , $category[1]['id']);
		$TPL->set_var('rclass1' , $category[0]['id']);
	}
	
	unset($data);
	unset($category);
	
	$productCount =  $response['totalNum'] + 0;
	$TPL->set_var('pagehtml', 
		'<div class="paginator">' .
		 ToolUtil::getpageHTML(TemplateHelper::getURL('bmanageproduct',$input,array('currentPage'=>'{page}')), $currentPage, ceil( intval($productCount) / $pageSize ))  . '</div>');
	
	$selectedFilter = array();

	$TPL->set_var('list_filter', TemplateHelper::getItemFilter('bmanageproduct',$input,$response,  false, $selectedFilter) );

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

/**
 * json - ����ѡƷ
 */
function bmanageproduct_add()
{
	$uid = ToolUtil::checkLoginOrRedirect();
	if (0 == $uid)
	{
		return ToolUtil::gbJsonEncode(array('errno'=> '500'));
	}
	$uid0 = (isset($_POST['uid']) ? $_POST['uid'] : -1);
	if ($uid != $uid0)
	{
		return array('errno'=> '501');
	}
	
	$product_ids = (isset($_POST['sysno']) ? $_POST['sysno'] : -1);
	if (-1 === $product_ids)
	{
		return ToolUtil::gbJsonEncode(array('errno'=> '501'));
	}
	if (!preg_match('/\d+(o\d+){0,}/', $product_ids))
	{
		return ToolUtil::gbJsonEncode(array('errno'=> '502'));
	}
	$productid_arr = explode('o',$product_ids);
	$time_now = time();
	$sql_arr = array(); 
	$sql_arr_index = 0;
	$result = '';
	$products_delete  = IBProduct::getProductsByRetailer(array('retailerId'=>$uid,'pids'=>$productid_arr),array('isDelete'=>1));
	global $_StockTips; 
	
        $products_info = IProductCommonInfoTTC::gets($productid_arr);
        if (false === ($products_info)) {
            self::$errCode = IProductCommonInfoTTC::$errCode;
            self::$errMsg =  basename(__FILE__, '.php') . " |" . __LINE__ . '[get IProductCommonInfoTTC failed]' . IProductCommonInfoTTC::$errMsg;
            return false;
        }
        
	foreach ($productid_arr as $index => $product_id)
	{	
		$isDelete = false;
		if ((false != $products_delete) && (count($products_delete['list']) > 0))
		{
	        foreach ($products_delete['list'] AS $p_delete)
	        {
	            if ($p_delete['productId'] == $product_id)
	            {
	               $isDelete = true;
                    break;
	            }
	        }
		}
		
		if($isDelete)
		{
		   $result = IBProduct::updateProduct(
                                        array(
                                            'retailerId' => $uid,
                                            'shelveState' => '0',
                                            'updateTime' => $time_now,
                                            'priceingState' => '0',
                                            'topState'=> '0' ,
                                            'addPrice' =>'0' ,
                                            'isDelete' => '0'
                                                ), 
                                         array('productId' => $product_id));
		}
        else
        {
	        $pinfo = false;
            foreach($products_info AS $p_info)
            {
                if ($p_info['product_id'] == $product_id)
                {
                    $pinfo = $p_info;
                    break;
                }
            }
	        if (false === $pinfo)
	        {
	            return array('errno'=> '503');
	        }
	        $category = IBProduct::getCategoryInfo($pinfo['c3_ids'],true);
	        if (false === $category )
	        {
	            return array('errno'=> '504');
	        }
            $sql_arr[$sql_arr_index] = array(
                'productId' => $product_id,
                'retailerId' => $uid ,
                'productNo' => $pinfo['product_char_id'],
                'createTime' => $time_now,
                'updateTime' => $time_now,
                'category1' => $category[0]['id'],
                'category2' => $category[1]['id'],
                'category3' => $category[2]['id'],
                'brandId'  => $pinfo['manufacturer'],
                'shelveState'=> '0',
                'priceingState'=> '0',
                'topState'=> '0',
                'isDelete' => '0',
                'stockState' =>  '1'
            );
	        $sql_arr_index ++ ;
	        unset($category);
        }
	}
	if ($sql_arr_index > 0)
	{
		$result = IBProduct::insertProduct($sql_arr);
	}
	return $result;
}

/**
 * json - ��ȡ��Ʒ����
 */
function bmanageproduct_getclass1() 
{
	$rs = IBProduct::getCategory(1, 0);
	$rs = ToolUtil::gbJsonEncode($rs);
	return $rs;
}

/**
 * json - ��ȡ��Ʒ����
 */
function bmanageproduct_getclass2() 
{
	ToolUtil::checkLoginOrRedirect();
	$class1Id = isset($_POST['class1Id']) ? intval($_POST['class1Id']) : 0;
	$rs = IBProduct::getCategory(2,$class1Id);
	return $rs;
}

/**
 * json - ��ȡ��ƷС��
 */
function bmanageproduct_getclass3()
{
	ToolUtil::checkLoginOrRedirect();
	$class2Id = isset($_POST['class2Id']) ? intval($_POST['class2Id']) : 0;
	$rs = IBProduct::getCategory(3,$class2Id);
	return $rs;
}
