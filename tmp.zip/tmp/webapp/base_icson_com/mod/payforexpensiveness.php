<?php
Logger::init ();

/**
 * ����������ѯҳ��(ҳ��ģ��)
 */
function page_payforexpensiveness_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	
	//��� 20130409
	ToolUtil::setCurrentPageId(3, 11708450);
	
	$TPL = TemplateHelper::getBaseTPL(0, "payforexpensiveness", array ('titleDesc' => '�����'));
	$TPL->set_var('pageName', '�����');
	$TPL->set_var('expensive_class', 'sc_nav_cur_item');

	
	// ��ȡ�û�������Ĺ���ⵥ��
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0);
	if($currentPage < 1) $currentPage = 1;
	$pageSize = 10;

	$GJPlist = EA_GuiJiuPei::getGJPApplies($uid, $pageSize, $currentPage-1);
	if($GJPlist === false){
		Logger::err( "EA_GuiJiuPei::getGJPApplies failed, code:" . EA_GuiJiuPei::$errCode . ', msg:' . EA_GuiJiuPei::$errMsg . ', uid:' . $uid);
		return _output_error( "ϵͳ��æ�����Ժ����ԣ�", $TPL );
	}

	$TPL->set_file(array('contentHandler' => 'payforexpensiveness_content.tpl'));
	$TPL->set_block('contentHandler', 'gjp_order_list', 't_gjp_order_list');
	if(!empty($GJPlist['data']) && count($GJPlist['data']) >0){
		$total = ceil($GJPlist['total'] / $pageSize);
		foreach ($GJPlist['data'] as $item){
			$vars['date'] = date("Y-m-d", $item['create_time']);
			$vars['user_name'] = $item['user_name'];
			$vars['mobile'] = $item['mobile'];
			$data = $item['data'];
			$vars['price'] = $data['price'];
			$vars['jd_price'] = $data['jd_price'];
			$vars['jd_url'] = $data['jd_url'];
			$vars['buy_num'] = $data['buy_num'];

			// ��Ʒ��Ϣ
			$vars['gift'] = '';
			if( !empty($data['gift']) ){
				$gifts = explode(";", urldecode($data['gift']));
				$gift_html = '';
				foreach($gifts as $gift){
					$gift_info = explode(",", $gift);
					$gift_html .= '<p class="zeng"><span class="icon_zeng"  >��</span><a href="http://item.51buy.com/item-'
								. (isset($gift_info[0]) ? $gift_info[0] : '') . '.html" target="_blank">'
								. (isset($gift_info[1]) ? mb_convert_encoding(urldecode($gift_info[1]), 'GBK', 'UTF-8') : '') . '</a></p>';
				}
				$vars['gift'] = $gift_html;
			}

			$product_id = $data['product_id'];
			$product_info = IProductCommonInfoTTC::get($product_id, array(), array('product_char_id', 'product_id', 'name'));
			if (false === $product_info) {
				Logger::err('IProductCommonInfoTTC::get failed-' . IProductCommonInfoTTC::$errCode . '-' . IProductCommonInfoTTC::$errMsg);
				return _output_error("��Ʒ��Ϣ��ȡʧ�ܣ����Ժ����ԣ�", $TPL);
			}
			$vars['gjp_id'] = ( strpos($item['order_char_id'], '10') == 0 ? substr($item['order_char_id'], 2) : $item['order_char_id'] ) . '-' . $product_info[0]['product_id'];
			$vars['pname'] = $product_info[0]['name'];
			$vars['p_pic_url'] = '<a class="img" target="_blank" href="http://item.51buy.com/item-' . $product_id
								 . '.html" class="img"><i></i><img src="' . IProduct::getPic($product_info[0]['product_char_id'], 'small')
								 . '" alt="'. $product_info[0]['name'] .'" title="' . $product_info[0]['name'] . '"></a>';
			$vars['p_url'] = 'http://item.51buy.com/item-' . $product_id . '.html';

			// ����erp�ӿڻ�ȡ����״̬��Ϣ
			$stockNo = (!isset($item['data']['stockNo'])) ? 1 : $item['data']['stockNo'];//�ֲ�ID
			$get_data = call_erp_SelectExpensiveToCompensate($vars['gjp_id'], $stockNo);
			$get_data = $get_data[0];
			$vars['p_status'] = $get_data['status'];
			$vars['p_reason'] = $get_data['reason'];
			$vars['p_price_difference'] = $get_data['price_difference'];

			$has_tip = '<div class="wrap_layout_track">
					<a class="question"></a>
					<div class="layout_popup" style="">
						<div class="layout_inner">'.$get_data['reason'].'</div>
						<div class="layout_arrow_top">
							<span class="">��</span><i>��</i>
						</div>
					</div>
				</div>';

			$p_tip = ($get_data['has_tip'] == true) ? $has_tip : '';
			$vars['p_tip'] = $p_tip;

			$TPL->set_var($vars);
			$TPL->parse('t_gjp_order_list', 'gjp_order_list', true);
			$TPL->unset_var(array_keys($vars));

		}
		$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/payforexpensiveness-{page}.html', $currentPage, $total)  . '</div></div>');
	} else {
		$TPL->set_var('page','');
		$TPL->set_var(array('t_gjp_order_list' => '<td colspan="6"><p class="kong">����û���ύ������</p></td>'));
	}
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

/**
 * ���������ҳ�棨ҳ��ģ�棩
 */
function page_payforexpensiveness_report(){
	$uid = ToolUtil::checkLoginOrRedirect();
	if (empty($uid)) {
		return _output_error("�û���Ϣ��ȡʧ�ܣ����Ժ����ԣ�", $TPL);
	}
	if (!isset($_GET['order_char_id'])) {
		return _output_error("������Ϣ��ȡʧ�ܣ����Ժ����ԣ�", $TPL);
	}

	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, "payforexpensiveness_report", array ('titleDesc' => '��������'));
	$TPL->set_var(array('pageName' => '�����', 'left_nav' => ''));
	$TPL->set_var('expensive_class', 'sc_nav_cur_item');

	$order_id = intval( ToolUtil::transXSSContent($_GET['order_char_id']) );
	$order = IOrder::getOneOrderDetail($uid, $order_id);
	if (false === $order) {
		Logger::err('IOrder::getOneOrder failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);
		return _output_error("������Ϣ��ȡʧ�ܣ����Ժ����ԣ�", $TPL);
	}

	$TPL->set_file(array('contentHandler' => 'payforexpensiveness_report_content.tpl'));
	$TPL->set_block('contentHandler', 'gjp_order_list', 't_gjp_order_list');

	if(EA_GuiJiuPei::validateGJPOrder($uid, $order) == false){
		return _output_error("�����������������", $TPL);
	}

	$info = array();
	$info['user_name'] = $order['receiver'];
	$info['mobile'] = $order['receiver_mobile'];
	$info['p_list'] = array();
	$info['order_date'] = $order['out_time'];
	$ret = EA_GuiJiuPei::get_pids_presented($uid, $order['order_char_id']);
	if (false === $ret) {
		Logger::err('EA_GuiJiuPei::get_pids_presented failed-' . EA_GuiJiuPei::$errCode . '-' . EA_GuiJiuPei::$errMsg);
		return _output_error("û�з��Ϲ����������Ʒ��", $TPL);
	}

	global $GJP_CLASS;
	foreach ($order['items'] as $key => $pinfo) {
		$product_info = IProductCommonInfoTTC::get($pinfo['product_id'], array(), array('c3_ids'));
		if (false === $product_info) {
			Logger::err('IProductCommonInfoTTC::get failed-' . IProductCommonInfoTTC::$errCode . '-' . IProductCommonInfoTTC::$errMsg);
			return _output_error("��Ʒ��Ϣ��ȡʧ�ܣ����Ժ����ԣ�", $TPL);
		}
		foreach ($product_info as $item) {
			if ( in_array($item['c3_ids'], $GJP_CLASS) && !in_array($pinfo['product_char_id'], $ret['data']) ) { // �ǹ������Ʒ && ��Ʒû�������
				//��Ʒ
				$gift_html = '';
				if( isset($pinfo['gift']) && count( $pinfo['gift'] ) > 0 ){
					foreach($pinfo['gift'] as $gift){
						$gift_html .= '<p class="zeng"><span class="icon_zeng"  >��</span><a href="http://item.51buy.com/item-'
									. $gift['product_id'] . '.html" gift_product_id="' . $gift['product_id'] . '"  gift_num="1"  target="_blank">' . $gift['name'] . '</a></p>';
					}
				}

				$info['p_list'][$key] = array(
					'product_id' => $pinfo['product_id'],
					'product_char_id' => $pinfo['product_char_id'],
					'pname' => $pinfo['name'],
					'price' => number_format($pinfo['price']/100, 2),
					'buy_num' => $pinfo['buy_num'],
					'p_list_str' => '<a target="_blank" href="http://item.51buy.com/item-' . $pinfo['product_id']
								 . '.html" class="img"><i></i><img src="' . IProduct::getPic($pinfo['product_char_id'], 'small')
								 . '" alt="'. $pinfo['name'] .'" title="' . $pinfo['name'] . '"></a>',
					'p_url' => '<a target="_blank"  href="http://item.51buy.com/item-' . $pinfo['product_id'] . '.html">' . $pinfo['name'] . '</a>',
					'gift' => $gift_html,
				);

			}
		}
	}
	
	$TPL->set_var('order_id', $order_id);
	$TPL->set_var('user_name', $info['user_name']);
	$TPL->set_var('mobile', $info['mobile']);
	$TPL->set_var('order_date', $info['order_date']);

	if(!empty($info['p_list'])){
		foreach ($info['p_list'] as $v){
			$vars = array(
				'product_id' => $v['product_id'],
				'product_char_id' => $v['product_char_id'],
				'pname' => $v['pname'],
				'price' => $v['price'],
				'buy_num' => $v['buy_num'],
				'p_list_str' => $v['p_list_str'],
				'p_url' => $v['p_url'],
				'gift' => $v['gift'],
			);
			$TPL->set_var($vars);
			$TPL->parse('t_gjp_order_list', 'gjp_order_list', true);
			$TPL->unset_var(array_keys($vars));
		}
	} else {
		$TPL->set_var('page','');
		$TPL->set_var(array('t_gjp_order_list' => '<tr><td colspan="7"><p class="kong">û�з��Ϲ����������Ʒ��</p></td></tr>'));
	}

	$TPL->parse('content', 'contentHandler');
	$TPL->out();

}

/**
 * ��ȡ�û�������Ĺ���ⶩ��
 */
function payforexpensiveness_getvalidorders(){
	$uid = ToolUtil::checkLoginOrRedirect();

	// ��ȡ1��֮�ڵ��û�����
	$page = 0;
	$orders = array();
	while (++$page){
		$ret = IOrder::getUserOrdersInXDays($uid, 1, $page-1, 5);
		if($ret === false){
			Logger::err("IOrder::getUserOrdersInXDays failed, code:" . IOrder::$errCode . ', msg:' . IOrder::$errMsg . ', uid:' . $uid);
			return _output_error("�������Ϣ��ȡʧ�ܣ����Ժ����ԣ�", $TPL);
		} else if(empty($ret['orders'])){
			break;
		}
		foreach ($ret['orders'] as $v){
			$orders[] = $v;
		}
	}

	// ���˷��Ϲ����Ķ���
	$valid_orders = array();
	foreach ($orders as $order){
		if(true === EA_GuiJiuPei::validateGJPOrder($uid, $order)){
			foreach ($order['items'] as $key => $item){
				$order['items'][$key]['img_url'] = IProduct::getPic($item['product_char_id'], 'small');
			}
			$valid_orders[] = $order;
		}
	}

	// ����ֵ
	return array(
		'errno' => 0,
		'data' => $valid_orders
	);
}


/**
 * �ύ����ⶩ��
 */
function payforexpensiveness_deliveryGJPOrder() {
	$uid = ToolUtil::checkLoginOrRedirect();

	//������
	$order_char_id = ToolUtil::transXSSContent(trim($_POST['order_id']));
	if (empty($order_char_id)) {
		return array('errno' => 4);
	}

	//�ֻ�����
	$mobile = ToolUtil::transXSSContent(trim($_POST['mobile']));
	if (empty($mobile)) {
		return array(
			'errno' => 5,
			'data' => '�ֻ����벻��Ϊ�գ�'
		);
	}
	if (!empty($mobile) && !is_numeric($mobile)) {
		return array(
			'errno' => 6,
			'data' => '�ֻ������ʽ����'
		);
	}

	//����
	$user_name = ToolUtil::transXSSContent(trim($_POST['user_name']));
	if (empty($user_name)) {
		return array(
			'errno' => 7,
			'data' => '��������Ϊ�գ�'
		);
	}
	if (!empty($user_name) && mb_strlen($user_name, 'GBK') > 10) {
		return array(
			'errno' => 8,
			'data' => '����������󳤶ȣ�'
		);
	}

	$order = IOrder::getOneOrderDetail($uid, $order_char_id);
	if (false === $order) {
		Logger::err('IOrder::getOneOrder failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);
		return array(
			'errno' => 8,
			'data' => 'ϵͳ��æ�����Ժ�����'
		);
	}

	//��Ʒ������Ϣ
	$data = json_decode($_POST['data'], true);
	foreach ($data as $key => $item) {
		//������
		$item['jd_price'] = ToolUtil::transXSSContent(trim($item['jd_price']));
		if (empty($item['jd_price'])) {
			return array(
				'errno' => 10,
				'data' => '�����۲���Ϊ�գ�'
			);
		}
		if (!empty($item['jd_price']) && !is_numeric($item['jd_price'])) {
			return array(
				'errno' => 11,
				'data' => '�����۸�ʽ������Ҫ�������֣�'
			);
		}
		$data[$key]['jd_price'] = number_format($item['jd_price'], 2, '.', ',');

		//������Ʒ����
		$item['jd_url'] = ToolUtil::transXSSContent(trim($item['jd_url']));
		if (empty($item['jd_url'])) {
			return array(
				'errno' => 13,
				'data' => '������Ʒ���Ӳ���Ϊ�գ�'
			);
		}
		if (!empty($item['jd_url']) && !ToolUtil::checkURL($item['jd_url'])) {
			return array(
				'errno' => 14,
				'data' => '������Ʒ���Ӹ�ʽ����'
			);
		}

		if (substr($item['jd_url'], 0, 4) != 'http') {
			$item['jd_url'] = 'http://' . $item['jd_url'];
		}
		
		$m = preg_match('/^https?\:\/\/item\.jd\.com\/\d+\.html/', $item['jd_url'], $matched);
		if (!$m) {
			return array(
				'errno' => 15,
				'data' => '��������ȷ�ľ�����Ʒ����ҳ��ַ��'
			);
		}

		// ��Ʒid
		$item['product_id'] = ToolUtil::transXSSContent(trim($item['product_id']));
		if (empty($item['product_id'])) {
			return array(
				'errno' => 16,
				'data' => '��Ʒid����Ϊ�գ�'
			);
		}

		// ��Ѹ��,��������
		foreach ($order['items'] as $k => $i){
			if($k == $item['product_id']){
				// �Ż�ȯ�ɱ���̯��
				$discount = max($i['apportToPm'], $i['apportToMkt']);
				if($discount != 0){
					$data[$key]['price'] = number_format( ($i['price'] - $discount / $i['buy_num'])/100, 2 );
				} else {
					$data[$key]['price'] = number_format($i['price']/100, 2);
				}
				$data[$key]['buy_num'] = $i['buy_num'];

				if (str_replace(',', '', number_format($i['price']/100, 2)) <= str_replace(',', '', $item['jd_price'])) {
					return array(
						'errno' => 17,
						'data' => '����д�ľ�����ǰ�۸������Ѹ����۸񣬲���������������'
					);
				}
				break;
			}
		}

		// ��Ʒ��Ϣ
		if(isset($item['gift'])){
			$gift = array();
			foreach ($item['gift'] as $v){
				$gift[] = ToolUtil::transXSSContent($v['id']) . ',' . urlencode(ToolUtil::transXSSContent($v['name'])) . ',' .  ToolUtil::transXSSContent($v['num']);
			}
			$data[$key]['gift'] = implode(";", $gift);
		}

		// ��id
		$data[$key]['stockNo'] = $order['stockNo'];

		/*
		 * ���ñȼ�ϵͳ�ӿڻ�ȡ�����۸�
		 */
		$ret = call_bijia_interface($order_char_id, $item['product_id'], urlencode($item['jd_url']));
		if(!empty($ret)){
			$data[$key]['jd_bijia_price'] = $ret['price'];
			$data[$key]['jd_bijia_gift'] = $ret['gift'];
		} else {
			$data[$key]['jd_bijia_price'] = '--';
			$data[$key]['jd_bijia_gift'] = '--';
		}

		$creat_time = time();

		/*
		 * ����erp�ӿ�Ͷ�ݹ���ⶩ��
		 */
		$post_data = array(
			'order_char_id' => $order_char_id,
			'user_name' => $user_name,
			'uid' => $uid,
			'mobile' => $mobile,
			'order_date' => date("Y-m-d H:i:s", $creat_time),
			'data' => $data[$key]
		);
		$result = call_erp_delivery_order($post_data, $order['stockNo']);
		if($result == -1){
			return array(
				'errno' => 18,
				'data' => 'ϵͳ��æ�����Ժ����ԣ�'
			);
		} else if($result == 2){
			// �ظ��ύ����
			continue;
		}

		/*
		 * ����ⶩ�����
		 */
		$ret = EA_GuiJiuPei::insert($order_char_id, $uid, $key, $data[$key], $creat_time, $user_name, $mobile);
		Logger::info("EA_GuiJiuPei insert : \r\n" . var_export($ret, true));
		if ($ret === false) {
			Logger::err("EA_GuiJiuPei::insert failed, code: " . EA_GuiJiuPei::$errCode . ', msg: ' . EA_GuiJiuPei::$errMsg);
			return array(
				'errno' => 19,
				'data' => 'ϵͳ��æ�����Ժ����ԣ�'
			);
		}
	}

	return array(
		'errno' => 0,
		'data' => '�ύ�ɹ���'
	);
}

//������Ϣ���
function _output_error($str, &$TPL) {
	$TPL->set_var ( 'content', '<div class="i_content" style="text-align:center">' . $str . '</div>' );
	$TPL->out ();
}

/**
 * ���ñȼ�ϵͳ
 */
function call_bijia_interface($order_char_id, $product_id, $url){
	$url = 'http://statistic.51buy.com/bijia/json.php?mod=Website&act=GetProductInfo'
			. '&product_id=' . $product_id
			. '&order_id=' . $order_char_id
			. '&url=' . $url;

	$res = NetUtil::cURLHTTPGet($url, 2);
	if ( false == $res || $res['errCode'] > 0){
		Logger::err("call_bijia_interface failed, code: " . NetUtil::$errCode . ', msg' . NetUtil::$errMsg);
		$res = NetUtil::cURLHTTPGet($url, 2);
		if ( false == $res || $res['errCode'] > 0){
			Logger::err("call_bijia_interface failed again, code: " . NetUtil::$errCode . ', msg' . NetUtil::$errMsg);
		}
	}
	$ret = array();
	if (false != $res){
		$res = ToolUtil::gbJsonDecode($res);
		if($res['errCode'] == 0 && $res['data']['price'] > 0){
			$ret['price'] = $res['data']['price'];
			$ret['gift'] = urlencode( mb_convert_encoding($res['data']['gift_desc'], 'UTF-8', 'GBK') );
		}
	}

	return $ret;
}

/**
 *
 * ����erp�ӿ�Ͷ�ݹ���ⶩ��
 * @param array $data
 * @param int $stockNo
 * @return -1(����)/1����ȷ��/2���ظ��ύ��
 */
function call_erp_delivery_order($data, $stockNo){
	$v = $data['data'];

	$post_data = array();

	$post_data['ApplyNo'] = ( strpos($data['order_char_id'], '10') == 0 ? substr($data['order_char_id'], 2) : $data['order_char_id'] ) . '-' . $v['product_id'];
	$post_data['ApplyTime'] = $data['order_date'];
	$post_data['SOID'] = $data['order_char_id'];
	$post_data['CustomerID'] = $data['uid'];
	$post_data['Tel'] = $data['mobile'];
	$post_data['Status'] = '0';
	$post_data['CustomerName'] = urlencode($data['user_name']);
	$post_data['Quantity'] = $v['buy_num'];
	$product_info = IProductCommonInfoTTC::get($v['product_id'], array(), array('name'));
	if (false === $product_info) {
		Logger::err('IProductCommonInfoTTC::get failed-' . IProductCommonInfoTTC::$errCode . '-' . IProductCommonInfoTTC::$errMsg);
		return -1;
	}

	$post_data['ProductID'] = $v['product_id'];
	$post_data['ProductName'] = urlencode( mb_convert_encoding($product_info[0]['name'], 'UTF-8', 'GBK') );
	$post_data['Price'] = $v['price'];
	$post_data['JDCustomerPrice'] = $v['jd_price'];
	$post_data['JDPrice'] = $v['jd_bijia_price'];
	$post_data['JDLink'] = urlencode(str_replace('http://', '', $v['jd_url']));
	$post_data['JDGift'] = $v['jd_bijia_gift'];

	$post_data['GiftProductID'] = '';
	$post_data['GiftProductName'] = '';
	$post_data['GiftQuantity'] = '';
	if( !empty($v['gift'])){
		$gift_id = array();
		$gift_name = array();
		$gift_count = array();
		$gifts = explode(";", $v['gift']);
		foreach($gifts as $gift){
			$gift_info = explode(",", $gift);
			$gift_id[] = $gift_info[0];
			$gift_name[] = $gift_info[1];
			$gift_count[] = $gift_info[2];
		}
		$post_data['GiftProductID'] = implode(';', $gift_id);
		$post_data['GiftProductName'] = implode(';', $gift_name);
		$post_data['GiftQuantity'] = implode(';', $gift_count);
	}

	// ����erp�ӿ�
	global $_IP_CFG;
	$url =  $_IP_CFG['PAYFOREXPENSIVENESS'] . "/SOService.asmx/InsertExpensiveToCompensate";
	$post_data =json_encode(array($post_data));
	$data = "json={$post_data}&StockSysNo={$stockNo}";
	Logger::info("call_erp_delivery_order post_data : \r\n" . var_export($data, true));

	$res = NetUtil::cURLHTTPPost($url,$data, 15);
	Logger::info("call_erp_delivery_order response : \r\n" . var_export($res, true));
	preg_match("/<int xmlns=\"http:\/\/service.ias.icson.com\/\">(\S+)<\/int>/", $res, $matches);

	if(count($matches) == 2){
		$ret = $matches[1];
		if($ret == '1'){
			return 1;
		}
		else if($ret == '2'){
			return 2;
		}
		else {
			return -1;
		}
	} else {
		return -1;
	}
}


/**
 * ����ERP�ӿ�,��ѯ�����״̬,�⳥����,ԭ��
 * @param string $gjp_id �����id
 * @param int $stockno �ֲ�id
 * @return ���� array()
 */
function call_erp_SelectExpensiveToCompensate($gjp_id, $stockno){
	global $_IP_CFG;
	$url = $_IP_CFG['PAYFOREXPENSIVENESS'] . "/SOService.asmx/SelectExpensiveToCompensate?applyno={$gjp_id}&StockSysNo={$stockno}";
	$res = NetUtil::cURLHTTPGet($url,15);
	$res = urldecode($res);
	$res = iconv("UTF-8", "GBK//IGNORE", $res);

	preg_match("/<string\s*xmlns=\"http:\/\/service\.ias\.icson\.com\/\">(.*)<\/string>/", $res, $matches);
	$data[] = array(
		'status' => '�����',
		'reason' => '',
		'has_tip' => false,
		'price_difference' => '--'
	);

	if(false === $res || empty($matches) ||  empty($matches[1])){
		$err_msg = basename(__FILE__, '.php') . " |" . __LINE__ . '[url get erp SelectExpensiveToCompensate faild] gjp_id:' . $gjp_id . ' stockno:'. $stockno;
		Logger::err('res:' . $res . $err_msg);
		return $data;
	}

	if(empty($matches) || empty($matches[1]) ){
		$err_msg = basename(__FILE__, '.php') . " |" . __LINE__ . '[url get erp SelectExpensiveToCompensate return data is empty] gjp_id:' . $gjp_id . ' stockno:'. $stockno;
		Logger::info('res:' . $res . ' matches:' . var_export($matches, true) . $err_msg);
		return $data;
	}

	$return_data = array();
	if(!empty($matches) && count($matches[1]) > 0){
		$temp_data = preg_replace('/.+?({.+}).+/','$1',$matches[1]);
		$res_data = ToolUtil::gbJsonDecode($temp_data);
		global $GJP_STATUS;
		if(is_array($res_data) && count($res_data) > 0){
			$return_data[] = array(
				'status' => (isset($res_data['Status'])) ? @$GJP_STATUS[$res_data['Status']] : '�����',
				'reason' => ($res_data['Status'] < 0 ) ? ((isset($res_data['Reason']) && empty($res_data['Reason'])) ? '' : $res_data['Reason']) : '',//status:-1(�ܾ�ͨ��) -2(�˿�ʧ��)
				'has_tip' => ($res_data['Status'] < 0) ? true : false,
				'price_difference' => (isset($res_data['PriceDifference']) && empty($res_data['PriceDifference']) || (in_array($res_data['Status'], array('0','1')))) ? '--' : $res_data['PriceDifference']
			);
		}else{
			$return_data[] = array(
				'status' => '�����',
				'reason' => '',
				'has_tip' => false,
				'price_difference' => '--'
			);
		}
	}

	return $return_data;
}










