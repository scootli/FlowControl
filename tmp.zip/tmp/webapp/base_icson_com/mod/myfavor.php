<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');
require_once(PHPLIB_ROOT . 'api/IProduct.php');
require_once(PHPLIB_ROOT . 'api/IProductRelativity.php');
require_once(PHPLIB_ROOT . 'api/IMyFavorite.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');

Logger::init();

function page_myfavor_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, "myfavor", array(
		'titleDesc' => '�ҵ��ղ�'
	));
	//��������
	ToolUtil::setCurrentPageId(3, 11703220);
	
	$TPL->set_var('pageName', '�ҵ��ղ�');
	$TPL->set_var('serverTime', time());//���������ʱ��

	$TPL->set_file(array(
		'contentHandler' => 'myfavor_content.tpl'
	));


	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	$pageSize = 10;

	$whId = IUser::getSiteId();

	global  $_StockTips;


	//���ղص���Ʒ
	$favoritList = IMyFavorite::gets($uid, $whId, $currentPage, $pageSize);
	if($favoritList === false){
		Logger::err('IMyFavorite::gets failed-' . IMyFavorite::$errCode . '-' . IMyFavorite::$errMsg);
		$TPL->set_var('t_favorite_list', '<tr><td colspan="5"><p class="kong">�����쳣�����Ժ�����</p></td></tr>');
		$TPL->set_var('page', '');
		$TPL->set_var('control_panel', '');
	}
	else{
		$total = IMyFavorite::getCount($uid);

		$favor_normal_count = 0;
		$favor_cp_count = 0;

		$TPL->set_block("contentHandler", 'favorite_list', 't_favorite_list');
		$TPL->set_block("contentHandler", 'favorite_cp_list', 't_favorite_cp_list');
		if(!empty($favoritList))
		{
			foreach( $favoritList as $product)
			{

				$baseInfo = IProduct::getBaseInfo($product['product_id'], $whId, true);
				if($baseInfo === false){
					Logger::err('IProduct::getBaseInfo failed-' . IProduct::$errCode . '-' . IProduct::$errMsg);
				}
				$params = array(
					'price' => ($product['price'] == 999999 * 100) ? '' : sprintf("%.2f", $product['price']/100),
					'product_id' => $product['product_id'],
					'product_char_id' => $product['product_char_id'],
					'name' => ToolUtil::transXSSContent($product['name']),
					'stock' => !empty($baseInfo)? $baseInfo['stock'] : '',
					'time' => date("Y-m-d", $product['update_time']),
					'favor_id' => $product['id'],
					'fav_btn' => '',
					'pic' => IProduct::getPic($product['product_char_id'], 'small'),
				);


				if ( ( $baseInfo['flag'] & CP_YCHF ) == CP_YCHF
					|| ( $baseInfo['flag'] & CP_GJRW ) == CP_GJRW )
				{
					$params['notice'] = "<span class='strong'>���ƻ������������빺�ﳵ���뵥������</span>";
					$params['add_cart_str'] = ($baseInfo['stock'] !== $_StockTips['not_available'] && $baseInfo['status'] == 1) ? '<p><a class="btn_strong" target="_blank" href="http://buy.51buy.com/stepone-' . $product['product_id'] . '.html"><span>���빺�ﳵ</span></a></p>' : '';
					$TPL->set_var($params);
					$TPL->set_var('currentPage', $currentPage);
					$TPL->parse('t_favorite_cp_list', 'favorite_cp_list', true);
					$favor_cp_count++;
				}
				else
				{
					$params['add_cart_str'] = ($baseInfo['stock'] !== $_StockTips['not_available'] && $baseInfo['status'] == 1) ? '<p><a class="btn_strong" target="_blank" href="http://buy.51buy.com/cart.html?pid=' . $product['product_id'] . '&pnum=1&mid=0"><span>���빺�ﳵ</span></a></p>' : '';
					$TPL->set_var($params);
					$TPL->set_var('currentPage', $currentPage);
					$TPL->parse('t_favorite_list', 'favorite_list', true);
					$favor_normal_count++;
				}
				$TPL->unset_var($params);
				$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myfavor-{page}.html', $currentPage, ceil($total/$pageSize))  . '</div></div>');
				$TPL->set_var('control_panel', '<div class="select_all wrap_btn"><label><input type="checkbox" onclick="G.app.mycenter.favorite.selectAll(this)"> ȫѡ </label><a class="btn_common" href="#" onclick="G.app.mycenter.favorite.addToCartSelected(this);return false;">���빺�ﳵ</a>&nbsp;<a class="btn_common" href="#" onclick="G.app.mycenter.favorite.removeSelected(this,' .$currentPage. ');return false;">ɾ��</a></div>');
			}

			if( $favor_normal_count == 0 )
			{
				$TPL->set_var('t_favorite_list', '');
			}
			else if( $favor_cp_count == 0 )
			{
				$TPL->set_var('t_favorite_cp_list', '');
			}

		}
		else{
			$TPL->set_var('t_favorite_list', '<tr><td colspan="5"><p class="kong">�����ղ�</p></td></tr>');
			$TPL->set_var('t_favorite_cp_list', '');
			$TPL->set_var('page', '');
			$TPL->set_var('control_panel', '');
		}


	}
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}
//ɾ���ղ�
function myfavor_remove(){
	$uid = IUser::getLoginUid();
	if(empty($_GET['uid']) || empty($uid) || $_GET['uid'] != $uid){
		return array('errno' => 500);
	}

	$product_ids = empty($_GET['product_ids']) ? '' : $_GET['product_ids'];
	$favor_ids = empty($_GET['favor_ids']) ? '' : $_GET['favor_ids'];

	if(empty( $product_ids ) || empty( $favor_ids )){
		return array(
			'errno'	=> 2,
			'data'	=> 0
		);
	}

	$product_ids = split(',', $product_ids);
	$favor_ids = split(',', $favor_ids);

	if(count($product_ids) !== count($favor_ids)){
		return array(
			'errno'	=> 3,
			'data'	=> 0
		);
	}

	foreach($product_ids as $index=>$product_id){
		$product_id = $product_id + 0;
		$favor_id = $favor_ids[$index] + 0;
		$res = IMyFavorite::delete($uid, $product_id, $favor_id);

		if( false == $res ){
			Logger::err('IMyFavorite::delete failed-' . IMyFavorite::$errCode . '-' . IMyFavorite::$errMsg);
			return array('errno' => 4);
		}
	}
	return array('errno' => 0);

}


//add by kunjiang 2012-4-13 for app demand;
function myfavor_getfromapp(){
	$uid = IUser::getLoginUid();
	if(empty($_GET['uid']) || empty($uid) || $_GET['uid'] != $uid){
		return array('errno' => 500);
	}
	$PAGESIZE = 20;
	global  $_StockTips;

	$currentPage = empty($_GET['page'])? 0 : ( $_GET['page'] + 0 );
	$wh_id = IUser::getSiteId();

	//���ղص���Ʒ
	$favoritList = IMyFavorite::gets($uid, $wh_id, $currentPage + 1, $PAGESIZE);
	if($favoritList === false){
		Logger::err('IMyFavorite::gets failed-' . IMyFavorite::$errCode . '-' . IMyFavorite::$errMsg);
		return array("errno" => 1, "data" => "��ȡ�ղؼ�ʧ��");
	}

	if( empty($favoritList) ){
		$TOTAL = 0;
		$result = array();
		$pageInfo = array( "current_page" =>  $currentPage, "page_size" => $PAGESIZE, "total" => $TOTAL, "page_count" => ceil( $TOTAL / $PAGESIZE ) );
		return array("errno" => 0, "data" => array("list" => $result, "page" => $pageInfo));
	}

	$product_ids = array();
	foreach( $favoritList as $item ){
		$product_ids[] = $item['product_id'];
	}

	//��Ʒ��Ϣ
	$gifts = IProduct::getproductsGift($product_ids, $wh_id);
	if(false === $gifts){
		Logger::err("IProduct::getproductsGift error: " . IProduct::$errCode . "; " . IProduct::$errMsg);
		$gifts = array();
	}

	//��ȥ���
	foreach($gifts as &$gift){
		foreach($gift as $key => $val){
			if( $val['type'] === 1 ){
				unset( $gift[$key] );
			}
		}
	}

	//��ȡ������Ʒ����
	$productsInfo = IProduct::getProductsInfo($product_ids, $wh_id, false);
	if (false === $productsInfo) {
		Logger::err("IProduct::getProductsInfo error: " . IProduct::$errCode . "; " . IProduct::$errMsg);
		return array("errno" => 2, "data" => "��ȡ�ղؼ�ʧ��");
	}

	$TOTAL = IMyFavorite::getCount($uid);
	$result = array();
	foreach($favoritList as  $item){
		$product_id = $item['product_id'];
		if ( !isset($productsInfo[$product_id]) ) continue;

		$info = $productsInfo[$product_id];
		$gift = isset($gifts[$product_id]) ? $gifts[$product_id] : array();
		$sale_type = $info['status'] == 1 ? ( $info['stock'] === $_StockTips['not_available'] ? 2 : 1 ) : 3;

		$result[] = array (
			'product_id' 				=> $product_id,
			'product_char_id' 			=> $info[ 'product_char_id' ],
			'name' 						=> $info[ 'name'],
			'show_price' 				=> $info['show_price' ],
			'market_price' 				=> $info['market_price' ],
			'gift_count' 				=> count( $gift ),
			'promotion_word' 			=> $info[ 'promotion_word' ],
			'favor_id' 					=> $item['id'],
			'sale_type' 			=>  $sale_type, //����: 1, �����꣺2, �ݲ����ۣ�3
		);
	}

	$pageInfo = array( "current_page" =>  $currentPage, "page_size" => $PAGESIZE, "total" => $TOTAL, "page_count" => ceil( $TOTAL / $PAGESIZE ) );

	return array("errno" => 0, "data" => array("list" => $result, "page" => $pageInfo));
}

//add by kunjiang 2012-4-13 for app demand;
function myfavor_addfromapp(){
	require_once('IUserProducts.php');

	$uid = IUser::getLoginUid();
	if(empty($uid)){
		return array('errno' => 500);
	}

	if(empty($_GET['uid']) || $_GET['uid'] != $uid){
		return array('errno' => 501);
	}

	if(empty($_POST['pid'])){
		return array('errno' => 1);
	}

	$pid = $_POST['pid'] + 0;

	$add = IMyFavorite::add($uid, $pid);
	$favor_id = 0;

	if($add !== false || IMyFavorite::$errCode == 404 ){
    	$product = IUserProductsTTC::get($uid, array('product_id' => $pid, 'type' => 1, 'status' => 1));
    	if( !empty($product) ){
    		Logger::err("IUserProductsTTC::get error: " . IUserProductsTTC::$errCode . "; " . IUserProductsTTC::$errMsg);
    		$favor_id = $product[0]['id'];
    	}
   	}

	if($add === false){
		if(IMyFavorite::$errCode == 404) {
			return array('errno' => 404, "data" => $favor_id);
		}
		Logger::err('IMyFavorite::add failed-' . IMyFavorite::$errCode . '-' . IMyFavorite::$errMsg);
		return array('errno' => 2);
	}

	return array( 'errno'	=> 0, "data" => $favor_id );
}
// End Of Script