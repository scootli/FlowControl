<?php

require_once(BASE_WEB_ROOT . 'api/IKFImage.php');
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');

define('TFS_PICTURE_HOST', 				'10.156.40.24:13000');
define('TFS_PICTURE_BUSINESS_ID', 		'kfpic');

Logger::init();

function picture_add(){
	$imgtype = $_POST['imgtype'];
    
    if(!ToolUtil::checkInt($imgtype)){
        //return array('errno' => 4,'msg'=>'�����ͼƬ����');
    }
	$toFileId = $_POST['toFileId'];
    //1 = GIF��2 = JPG��3 = PNG
	
	if( (isset($_FILES["file"]))  && (!$_FILES["file"]['error']) ){
		$size = filesize($_FILES['file']['tmp_name']);
		if( ($size> 1024 * 1024 * 5) || ($size < 1024) ){//���ܳ���5M
			return array('errno' => 1001,'msg'=>'�ϴ���ͼƬ���ܳ���5M��С��1K');
		}
		$imgFilePath = $_FILES['file']['tmp_name'];
	} else {
		$imgFilePath='';
		return array('errno' => 1002,'msg'=>'��ѡ��Ҫ�ϴ���ͼƬ');
	}

	$allowed_types = array(1,2,3, 6);
	list($width, $height, $type, $attr) = getimagesize($imgFilePath);

	if(!in_array(strtolower($type),$allowed_types)){
		return array(
			'errno'=>6,
			'msg'=>'���ϴ���ͼƬ���Ͳ���ȷ���������ϴ�����ʽΪjpg|gif|png|bmp��'
		);
	}

	
	//return var_dump( $_FILES['file']);

	$picInfo = array();
	if (!empty($imgFilePath)){
		$uploadRet = IKFImage::upload($imgFilePath, 55546663, $type, 20);
		if ($uploadRet === false){
			// ignore
//				Logger::err(EVENT_UPLOAD_IMG_FAILED, "upload img failed, buyer_id:" . $uin);
			//Logger::err("IKFImage::upload error, code:" . IKFImage::$errCode . ', msg: ' . IKFImage::$errMsg);
			return array(
				'errno'	=> 7,
				'msg'	=> '���粻���������Ժ����ԣ�',
				'err1'	=> IKFImage::$errCode,
				'err2'	=> IKFImage::$errMsg
			);
		} else {
			$picInfo['img_type']	= $type;
			$picInfo['attachment']	= IKFImage::getUrl($uploadRet, "0");
			@unlink($imgFilePath);
		}
	}else{
		return array(
			'errno'	=> 1,
			'msg'	=> '��ѡ��Ҫ�ϴ���ͼƬ'
		);
	}

	return array(
		'errno'		=> 0,
		'data'		=> $picInfo,
		'toFileId'	=> $toFileId
	);
}