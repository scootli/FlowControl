<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');

require_once(PHPLIB_ROOT . 'api/appplatform/platform/web_stub_cntl.php');
require_once(PHPLIB_ROOT . 'api/appplatform/platform/lang_util.php');
require_once(PHPLIB_ROOT . 'api/appplatform/pointsaccountao_stub4php.php');

Logger::init();

function myintegral_page(){
	global $_SCORE_TYPE;

	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, "myintegral", array(
		'titleDesc' => '�ҵĻ���'
	));
	$TPL->set_var('pageName', '�ҵĻ���');

	$TPL->set_file(array(
		'contentHandler' => 'myintegral_content.tpl'
	));

	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	$pageSize = 10;

	$TPL->set_block("contentHandler", 'list', 't_list');
	
	//��ȡ�û�����
	$user = getPointAndList($uid,$currentPage,$pageSize);
	if($user === false){		
		$TPL->set_var('t_list', '');
		$TPL->set_var('page', '');
		$TPL->set_var('content', '');
		$TPL->out();
		return;
	}
	$TPL->set_var('point',  $user['point'] );
	if( $user['next_expired_point'] == 0){
		$TPL->set_var('expired_point_div','');
	}else{
		$TPL->set_var('expired_point_div','<span>������'.$user['next_expired_point'].'���ֽ���'.date('Y��m��d��',$user['next_expired_time']).'����</span>');
	}	
		
	if(empty($user['list'])){		
		$TPL->set_var('t_list', '<tr><td colspan="6"><p class="kong">����ؼ�¼</p></td></tr>');
		$TPL->set_var('page', '');
	}else{
		$scoreType = array();
		foreach ($_SCORE_TYPE as $type){
				$scoreType[$type['id']] = $type['description'];
		}
		foreach($user['list'] as $item){
				$params = array(
						'time' => date('Y-m-d', $item['time'] ),
						'score_type' => isset($scoreType[$item['score_type']]) ? $scoreType[$item['score_type']] : '',
						'score_from' => $item['score_from'],
						'score' => $item['score'],
						'expired_time' => ( $item['score'] > 0? date('Y-m-d', $item['expired_time'] ):'-'  )
				);
				$TPL->set_var($params);
				$TPL->parse('t_list', 'list', true);
				$TPL->unset_var($params);
		}

		$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myintegral-{page}.html', $currentPage, ceil($user['total'] / $pageSize))  . '</div></div>');
	}	
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

function getPointAndList($uid,$currentPage,$pageSize){
	//��ѯ�����˻�ϵͳ
	$cntl = new WebStubCntl();
	$sPassport = "0123456789";
	$cntl->setDwOperatorId($uid);
	$cntl->setSPassport($sPassport);
	$cntl->setDwSerialNo(10002);
	$cntl->setDwUin($uid);
	$cntl->setWVersion(2);		
	$cntl->setCallerName("basemyintegral");

	$getPointsAccouReq = new GetPointsAccountReq();
	$getPointsAccouResp = new GetPointsAccountResp();
	$getPointsAccouReq->machineKey = ToolUtil::getClientIP();
	$getPointsAccouReq->source = __FILE__;
	$getPointsAccouReq->sceneId = 0;
	$getPointsAccouReq->inReserve = "";
	$getPointsAccouReq->icsonUid = $uid;	

	$ret = $cntl->invoke($getPointsAccouReq, $getPointsAccouResp, 2);

	if($ret != 0  ){ 
		Logger::err('Get Points::GetPointsAccount failed-' .$ret . '-' . $getPointsAccouResp->errmsg);
		return false;
	}

	$user['point'] = $getPointsAccouResp->pointsAccountPo->dwPromotionPoints;
	$expiringPoints = $getPointsAccouResp->pointsAccountPo->dwExpiringPromotionPoints;
	$expiringTime = $getPointsAccouResp->pointsAccountPo->dwExpiringPromotionPointsTime;
	if( $expiringTime > 0){
		$user['next_expired_point'] = $expiringPoints ;	
		$user['next_expired_time'] = $expiringTime;
	}else{
		$user['next_expired_point'] = 0;	
	}	

	//����ϸ
	$pointsAccountDetailReq = new GetPointsAccountDetailReq();
	$pointsAccountDetailResp = new GetPointsAccountDetailResp();
	$pointsAccountDetailFilter = new PointsAccountDetailFilterPo();

	$pointsAccountDetailFilter->dwVersion = 0;
	$pointsAccountDetailFilter->ddwIcsonUid = $uid;
	$pointsAccountDetailFilter->dwPointsType = 2 ;//ֻ���Ҵ�������
	
	$pointsAccountDetailFilter->dwPageid = $currentPage-1;
	$pointsAccountDetailFilter->dwPagesize = $pageSize;

	$pointsAccountDetailFilter->cIcsonUid_u = 1;
	$pointsAccountDetailFilter->cPointsType_u = 1;
	$pointsAccountDetailFilter->cPageid_u = 1;
	$pointsAccountDetailFilter->cPagesize_u = 1;

	$pointsAccountDetailReq->machineKey = ToolUtil::getClientIP();
	$pointsAccountDetailReq->source = __FILE__;
	$pointsAccountDetailReq->sceneId = 0;
	$pointsAccountDetailReq->inReserve = "";
	$pointsAccountDetailReq->PointsDetailFilterPo = $pointsAccountDetailFilter;	

	$ret = $cntl->invoke($pointsAccountDetailReq, $pointsAccountDetailResp, 2);

	if($ret != 0 || $pointsAccountDetailResp->result != 0 ){
		Logger::err('Get Points::PointsAccountDetail failed-' .$ret . '-' . $pointsAccountDetailResp->errmsg);		
		$user['total']= 0 ;
		$user['list']  = array();
		return $user;
	}
	
	$pointsDetailList =  $pointsAccountDetailResp->pointsAccountDetailPoList;
	$user['total'] = $pointsDetailList->dwDetailTotalNum;
	$data = array();	
	$detaillist = array();	
	foreach($pointsDetailList->vecPointsAccountDetailPoList as $pointsitem){
		$item = array();
		$item['score'] = $pointsitem->nDetailPoints;
		$item['score_type'] = $pointsitem->dwDetailType;		
		$item['time'] = $pointsitem->dwDetailAddtime;
		if($item['time'] < mktime(0, 0, 0, 5, 16, 2013)){ //���С��2013��5��15�žͶ��϶�Ϊ����ʱ��Ϊ2016��5��31��
			$item['expired_time'] = mktime(0, 0, 0, 5, 31, 2016);
		}else {
			$item['expired_time'] = $pointsitem->dwExpiredTime;
		}
		$item['score_from'] = $pointsitem->strRemarks;
		array_push($detaillist,$item);
	}
	$user['list'] = $detaillist ;

	return $user;
}