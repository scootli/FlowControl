<?php

require_once(PHPLIB_ROOT . 'api/IUser.php');

function page_zhengpinhanghuo_index(){
	ToolUtil::setCurrentPageId(3);
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'titleDesc'	=> '��Ʒ�ͼ�',
		'cssFile' => 'http://st.icson.com/51buy_v3/css/act_help.css?v=[[v_CSS_ACT_HELP]]'
	));
	$TPL->set_file(array(
		'containerHandler'	=> 'zhengpinhanghuo.tpl'
	));
	$TPL->out();
}
