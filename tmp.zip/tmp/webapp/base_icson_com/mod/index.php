<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IProductRelativity.php');
require_once(PHPLIB_ROOT . 'api/IMyFavorite.php');
require_once(PHPLIB_ROOT . 'api/IShoppingCart.php');
require_once(PHPLIB_ROOT . 'api/IProduct.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IOrder.php');
require_once(PHPLIB_ROOT . 'api/IReviewShortMessage.php');

require_once(PHPLIB_ROOT . 'api/appplatform/platform/web_stub_cntl.php');
require_once(PHPLIB_ROOT . 'api/appplatform/platform/lang_util.php');
require_once(PHPLIB_ROOT . 'api/appplatform/pointsaccountao_stub4php.php');

Logger::init();

function index_page() {
	$uid = ToolUtil::checkLoginOrRedirect();

	ToolUtil::setCurrentPageId(3, 11649770); //��������

	$TPL = TemplateHelper::getBaseTPL();
	$TPL->set_file('containerHandler', "index_container.tpl");
	$TPL->set_var('pageName', '�ҵ���Ѹ');
	$TPL->set_var('servertime', time());//���������ʱ��

	$TPL->set_file(array(
		'contentHandler' => 'index_content.tpl', // �м䲿�� + �Ҳ�
		'mainHandler' => 'main.tpl', //�м䲿��
		'rightAsideHandler'=> 'right_aside.tpl'
	));

	//����������Ϣ
	_getUserInfo($uid, $TPL);

	//�ҵĶ���
	_getOrder($uid, $TPL);

	//���ղص���Ʒ
	_getFavorite($uid, $TPL);

	//δ����Ϣ
	_getUnreviewReceivedMessageCount($uid, $TPL);

	$TPL->parse('right_aside', 'rightAsideHandler');
	$TPL->parse('main', 'mainHandler');
	$TPL->parse('content', 'contentHandler');
	//itil�ϱ�
	ToolUtil::itilReport(635755);
	$TPL->out();
}

//δ����Ϣ
function _getUnreviewReceivedMessageCount($uid, $TPL) {
	$count = IShortMessage::getUnreviewReceivedMessageCount($uid);
	$TPL->set_var('unreview_received_message_count', $count > 0 ? '<div class="extra"><b class="icon icon_mess"></b>����<a href="http://base.51buy.com/shortmessage.html">' . $count . '��δ��վ����</a></div>' : '');
}

//����������Ϣ
function _getUserInfo($uid, $TPL) {
	$user = IUser::getUserInfo($uid);		
	if ($user === false) {
		Logger::err('IUser::getUserDetail failed-' . IUser::$errCode . '-' . IUser::$errMsg);
		$params = array(
			'user_icsonid' => '',
			'user_nick' => '',
			'user_point' => '',
			'user_balance'=>'',
			'user_level' => '',
			'user_levelDesc' => '',			
			'user_name_str' => '',
			'email' => '',
			'mobile' => '',
			'user_upgradeExp' => ''
		);
	}	
	else {
		//��ȡ�û��Ļ��ֺ��˻����
		$user = getUserPointAndBalance($user,$uid);
		global $_UserLevel;
		foreach ($_UserLevel as $key => &$ul) {			
			if($user['levelDesc'] == $ul['desc']){
				$user['user_level'] = $key;
				break;
			}
		}	
		
		if(isset( $user['nextLevel']) && $user['nextLevel'] > 0 ){
			$user_upgradeExp = $user['nextLevel'] - $user['exp_point'];
		}else{
			$user_upgradeExp = -1;
		}

		if( $user['next_expired_point'] == 0){
			$TPL->set_var('expired_point_div','');
		}else{
			$TPL->set_var('expired_point_div','������'.$user['next_expired_point'].'���ֽ���'.date('Y��m��d��',$user['next_expired_time']).'����');
		}	

		$email = ToolUtil::transXSSContent( $user['email'] );
		$emailCut = ToolUtil::utfSubstr( $email, 10 );
		$email = strlen($emailCut) !== strlen($email) ? $emailCut . '...' : $emailCut;

		$user_nick = ToolUtil::transXSSContent( $user['nick'] );
		$mobile = ToolUtil::transXSSContent( $user['mobile'] );

		$validateRes = IUser::validateUserFromQQ($uid);
		if ( false === $validateRes) {
			Logger::err('IUser::validateUserFromQQ failed-' . IUser::$errCode . '-' . IUser::$errMsg);
			TemplateHelper::outMessage( '��ȡ�û���Ϣʧ��' );
			return;
		}

		$validateResAli = IUser::validateUserFromALI($uid);

		if ( false === $validateResAli) {
			Logger::err('IUser::validateUserFromALI failed-' . IUser::$errCode . '-' . IUser::$errMsg);
			TemplateHelper::outMessage( '��ȡ�û���Ϣʧ��' );
			return;
		}

		$icsonIdDesc = ToolUtil::transXSSContent( $user['icsonid']);
		$nameDesc = '<li class="user_name">�˺ţ�' . ToolUtil::transXSSContent( $user['icsonid'] ) . '</li>';
		if ($validateRes['validate']) {
			$icsonIdDesc = '<i class="icon_qq">&nbsp;</i>�װ���QQ�û�';
			$nameDesc = '<li><i class="icon_qq">&nbsp;</i>QQ�û�</li>';
		}
		else if ($validateResAli['validate']) {
			$icsonIdDesc = '<i class="icon_alipay">&nbsp;</i>�װ���֧�����û�';
			$nameDesc = '<li><i class="icon_alipay">&nbsp;</i>֧�����û�</li>';
		}

		$params = array(
			'user_icsonid' => $icsonIdDesc,
			'user_nick' => empty($user_nick) ? '<span style="font-weight:normal">��û���ǳƣ�<a href="http://base.51buy.com/myprofile.html">����ȥ��</a></span>' : $user_nick,
			'user_point' => ToolUtil::transXSSContent( $user['user_point'] ),
			'user_balance' =>  ToolUtil::transXSSContent( round($user['user_balance']/10,1) ),
			'user_level' => ToolUtil::transXSSContent( $user['user_level'] ),
			'user_levelDesc' => ToolUtil::transXSSContent( $user['levelDesc'] ),
			'user_name_str' => $nameDesc,
			'user_upgradeExp' => $user_upgradeExp,
			'next_expired_point'=>$user['next_expired_point'],
			'email' => empty($email) ? '<span class="nor">δ��д</span>' : $email,
			'mobile' => empty($mobile) ? '<span class="nor">δ��д</span>' : $mobile
		);
	}
	$TPL->set_var($params);

}

//�ղ�
function _getFavorite($uid, $TPL) {
	$TPL->set_block("mainHandler", 'favorite_list', 't_favorite_list');

	$whId = IUser::getSiteId();
	$favoritList = IMyFavorite::gets($uid, $whId, 1, 5);
	if ($favoritList === false) {
		$TPL->set_var('t_favorite_list', '<tr><td colspan="3"><p class="kong">�����쳣, ���Ժ�����</p></td></tr>');
		return ;
	}
	if ( !empty($favoritList)) {
		foreach( $favoritList as $product) {
			$params = array(
				'price' => ($product['price'] == 999999 * 100) ? '' : sprintf("%.2f", $product['price']/100),
				'product_id' => $product['product_id'],
				'product_char_id' => $product['product_char_id'],
				'name' => $product['name'],
				'time' => date("Y-m-d", $product['update_time']),
				'favor_id' => $product['id'],
				'fav_btn' => '',
				'pic' => IProduct::getPic($product['product_char_id'], 'small'),
			);

			if ( CP_GJRW == ( CP_GJRW & $product['flag'] ) || CP_YCHF == ( CP_YCHF & $product['flag'] ) ) {
				$params['php_add_cart'] = "window.location.href='http://buy.51buy.com/stepone-".$product['product_id'].".html';return false;";
			}
			else {
				$params['php_add_cart'] = "G.logic.constants.goToCartWithThis(this,{pid:'".$product['product_id']."'});return false;";
			}
			$TPL->set_var($params);
			$TPL->parse('t_favorite_list', 'favorite_list', true);
			$TPL->unset_var($params);
		}
	}
	else {
		$TPL->set_var('t_favorite_list', '<tr><td colspan="3"><p class="kong">���ڽ���û���ղ�</p></td></tr>');
	}
}

//����
function _getOrder($uid, $TPL) {
	$TPL->set_block("mainHandler", 'order_list', 't_order_list');

	global $_OrderState;
	$orderList = IOrder::getRecentOrder($uid, 5);
	if ($orderList === false) {
		Logger::err('IOrder::getUserOrders failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);
		$TPL->set_var('t_order_list', '<tr><td colspan="6"><p class="kong">�����쳣, ���Ժ�����</p></td></tr>');
		return;
	}

	if (empty($orderList['orders'])) {
		$TPL->set_var('t_order_list', '<tr><td colspan="6"><p class="kong">���ڽ���û���ύ������</p></td></tr>');
		return;
	}

	//else
	$relation = _getOrderRelation($orderList['orders']); //���Ӷ�����ϵ
	$printParams = array(); //Ҫ��ӡ��

	foreach($orderList['orders'] as &$order) {
		$orderState = ''; //����״̬
		foreach($_OrderState as $key => $arr) {
			if ($order['status'] == $arr['value']) {
				$orderState = $arr['siteName'];
				break;
			}
		}

		$siteId = $order['hw_id'];
		$payInfo = ToolUtil::getPayTypeInfo($order['pay_type'], $siteId); //֧����ʽ
		$payType = false === $payInfo ? "" : $payInfo['IsNet'] == 1 ? "����֧��" : $payInfo['PayTypeName'];
		$cash = sprintf("%.2f", $order['cash'] / 100);

		//��ӡ����
		$pid = ($relation && array_key_exists($order['order_char_id'], $relation)) ? $relation[$order['order_char_id']] : false;

		$order_char_id_str =  "<p><a href='http://base.51buy.com/orderdetail-{$order['order_char_id']}.html' target='_blank'>{$order['order_char_id']}</a></p>"; //�������
		$order_date_str =  '<p class="date">' . date("Y-m-d", $order['order_date']) . '</p>'; //�µ�ʱ��
		$receiver_str =  '<p>' . ToolUtil::transXSSContent( $order['receiver'] ) . '</p>'; //�ջ���
		$status_str =  "<div class='other_info'><p><span class='pay_online'>{$orderState}</span></p></div>"; //����״̬
		$order_cost_str = "<div class='other_info'><p><span class='price'><span class='i_yuan'>&yen;</span>{$cash}</span><b>({$payType})</b></p></div>"; //�������
		$need_pay_str = empty($order['need_pay'])
			? "<a target='_blank' href='http://base.51buy.com/orderdetail-{$order['order_char_id']}.html'>��������</a>"
			: ($pid
				? "<a target='_blank' href='http://pay.51buy.com/redirect_{$pid}' class='yx_btn_strong70'>ȥ����</a>"
				: "<a target='_blank' href='http://pay.51buy.com/redirect_{$order['order_char_id']}' class='yx_btn_strong70'>ȥ����</a>");

		if ($pid && isset($printParams[$pid])) {
			$printParams[ $pid ]['order_char_id_str'] .= $order_char_id_str;
			$printParams[ $pid ]['order_date_str'] .= $order_date_str;
			$printParams[ $pid ]['receiver_str'] .= $receiver_str;
			$printParams[ $pid ]['status_str'] .= $status_str;
			$printParams[ $pid ]['order_cost_str'] .= $order_cost_str;
		}
		else {
			$printParams[ ($pid ? $pid : $order['order_char_id']) ] = array(
				'order_char_id_str' => $order_char_id_str,
				'order_date_str' => $order_date_str,
				'receiver_str' => $receiver_str,
				'status_str' => $status_str,
				'order_cost_str' => $order_cost_str,
				'need_pay_str' => $need_pay_str,
			);
		}
	}

	foreach($printParams as $id => &$params) {
		$TPL->set_var($params);
		$TPL->parse('t_order_list', 'order_list', true);
		$TPL->unset_var($params);
	}
}

/**
 * ��ȡ���Ӷ�����ϵ
 * @param array $orders ��������
 * @return mixed
 */
function _getOrderRelation($orders) {
	$relation = array();
	foreach($orders as &$order) {
		if (isset($order['pOrderId']) && $order['pOrderId'] != $order['order_char_id']) { //pOrderId !
			if (isset($relation[$order['pOrderId']]) && is_array($relation[$order['pOrderId']])) {
				$relation[$order['pOrderId']] ['cOrderIds'] [] = $order['order_char_id'];
				$relation[$order['pOrderId']] ['need_pay'] = $relation[$order['pOrderId']] ['need_pay'] && $order['need_pay'];
			}
			else {
				$relation[$order['pOrderId']] = array(
					'cOrderIds' => array( $order['order_char_id'] ),
					'need_pay' => $order['need_pay'],
				);
			}
		}
	}

	$needed = false; //������Ҫ�ĸ��Ӷ�����ϵ��
	$ret = array(); //cid 2 pid
	foreach($relation as $pid => &$info) {
		if (count($info['cOrderIds']) > 1 && $info['need_pay']) { //���Ӷ���������1�� �ҡ�ȫ���Ӷ�����������Ҫ֧����״̬��
			$needed = true;

			foreach($info['cOrderIds'] as $cid) {
				$ret[$cid] = $pid;
			}
		}
	}

	return $needed ? $ret : false;
}


function getUserPointAndBalance($user,$uid){
	
	//��ѯ�����˻�ϵͳ
	$cntl = new WebStubCntl();
	$sPassport = "0123456789";
	$cntl->setDwOperatorId($uid);
	$cntl->setSPassport($sPassport);
	$cntl->setDwSerialNo(10002);
	$cntl->setDwUin($uid);
	$cntl->setWVersion(2);		
	$cntl->setCallerName("basemyindex");

	$getPointsAccouReq = new GetPointsAccountReq();
	$getPointsAccouResp = new GetPointsAccountResp();
	$getPointsAccouReq->machineKey = ToolUtil::getClientIP();
	$getPointsAccouReq->source = __FILE__;
	$getPointsAccouReq->sceneId = 0;
	$getPointsAccouReq->inReserve = "";
	$getPointsAccouReq->icsonUid = $uid;	

	$ret = $cntl->invoke($getPointsAccouReq, $getPointsAccouResp, 2);

	if($ret != 0  ){ 
		Logger::err('Get Points::GetPointsAccount failed-' .$ret . '-' . $getPointsAccouResp->errmsg);
		return false;
	}

	$user['user_point'] = $getPointsAccouResp->pointsAccountPo->dwPromotionPoints;
	$user['user_balance'] = $getPointsAccouResp->pointsAccountPo->dwCashPoints;
	$expiringPoints = $getPointsAccouResp->pointsAccountPo->dwExpiringPromotionPoints;
	$expiringTime = $getPointsAccouResp->pointsAccountPo->dwExpiringPromotionPointsTime;
	
	if( $expiringTime > 0 ){
		$user['next_expired_point'] = $expiringPoints ;	
		$user['next_expired_time'] = $expiringTime ;	
	}else{
		$user['next_expired_point'] = 0;	
	}	
	return $user;
}