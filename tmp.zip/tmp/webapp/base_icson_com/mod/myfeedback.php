<?php
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IMycentFeedback.php');
require_once(PHPLIB_ROOT . 'api/IOrder.php');
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');

Logger::init();

function page_myfeedback_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$whId = IUser::getSiteId();

	$TPL = TemplateHelper::getBaseTPL(0, 'myfeedback', array(
		'titleDesc' => '�������'
	));

	$TPL->set_var('pageName', '�������');
	$TPL->set_file(array(
			'contentHandler' => 'myfeedback.tpl'
	));

	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	if($currentPage < 1) $currentPage = 1;
	$pagesize = 10;

	//���˷�վ�߼�
	$result = IMycentFeedback::getFeedbackList($whId, $uid, $currentPage - 1, $pagesize);
	if($result === false){
		Logger::err('IMycentFeedback::getFeedbackList failed-' . IMycentFeedback::$errCode . '-' . IMycentFeedback::$errMsg);
		return _output_error('ϵͳ��æ�����Ժ����ԣ�', $TPL);
	}

	//���˷�վ�߼�
	$count = IMycentFeedback::getFeedBackCount($whId, $uid);
	if($count === false){
		Logger::err('IMycentFeedback::getFeedBackCount failed-' . IMycentFeedback::$errCode . '-' . IMycentFeedback::$errMsg);
		$total = 0;
	} else {
		$total = empty($count[0]['computed']) ? 0 : $count[0]['computed'];
		$total = ceil($total / $pagesize);
	}

	$TPL->set_block("contentHandler", 'myfeedback_list', 't_myfeedback_list');
	if (!empty($result)){
		foreach ( $result as $val){
			$params = array(
				'subject' => ToolUtil::transXSSContent($val['Subject']),
				'suggest' => ToolUtil::transXSSContent($val['Suggest']),
				'createTime' => $val['CreateTime'],
				'oldSysNo' => $val['OldSysNo'],
				'memo' => empty($val['Memo']) ? '' : ('<h4 class="tit">��Ѹ: </h4><p>'.ToolUtil::transXSSContent($val['Memo']).'</p>'),
				'sysNo' => $val['SysNo']
			);
			$TPL->set_var($params);
			$TPL->set_var('currentPage', $currentPage);
			$TPL->parse('t_myfeedback_list', 'myfeedback_list', true);
			$TPL->unset_var(array_keys($params));
			$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myfeedback-{page}.html', $currentPage, $total)  . '</div></div>');
		}
	}else {
		$TPL->set_var('t_myfeedback_list', '<tr><td colspan="3"><p class="kong">����û����д��������</p></td></tr>');
		$TPL->set_var('page', '');
	}

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}


//��д�������ҳ��ģ����ʾ
function page_myfeedback_feedbackapply(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, 'feedbackapply', array(
		'titleDesc' => '��д�������'
	));

	$TPL->set_var(array(
		'pageName'	=> '��д�������',
		'left_nav'	=> ''
	));
	$TPL->set_file(array(
			'contentHandler' => 'myfeedback_apply.tpl'
	));

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//�ύ�ҵķ������
function myfeedback_feedbackreport(){
	$uid = IUser::getLoginUid();
	$whId = IUser::getSiteId ();
	if(!$uid){
		return array('errno' => 500);
	}

	if(empty($_POST['mysubject']) || strlen($_POST['mysubject']) > 200){
		return array('errno' => 1);
	}
	$subject = isset($_POST['mysubject']) ? trim($_POST['mysubject']) : '';
	$subject = ToolUtil::transXSSContent($subject);

	if(empty($_POST['mysuggest']) || strlen($_POST['mysuggest']) > 1000){
		return array('errno' => 2);
	}
	$suggest = isset($_POST['mysuggest']) ? trim($_POST['mysuggest']) : '';
	$suggest = ToolUtil::transXSSContent($suggest);

	$email = !empty($_POST['myemail']) ? $_POST['myemail'] : '';
	$email = ToolUtil::transXSSContent($email);
	

	$phone = !empty($_POST['myphone']) ? $_POST['myphone'] : '';
	$phone = ToolUtil::transXSSContent($phone);

	$sosysno = 0;
	if(empty($_POST['mysosysno'])){
		$sosysno = 0;
	}else{
		$order = IOrder::getOneOrder($uid, $_POST['mysosysno']);
		if($order === false){
			Logger::err("IOrder::getOneOrder failed, code:" . IOrder::$errCode . ', msg:' . IOrder::$errMsg);
			return array('errno' => 6001);
		}
		if($order){
			$sosysno = substr($_POST['mysosysno'], 2);
		}
	}

	$userInfo = IUser::getUserInfo($uid);
	if($userInfo === false){
		Logger::err("IUser::getUserInfo failed, code:" . IUser::$errCode . ', msg:' . IUser::$errMsg);
		return array('errno' => 6002);
	}
	$nickName = $userInfo['nick'] ? $userInfo['nick'] : '';
	//���˷�վ�߼�
	$rs = IMycentFeedback::addFeedback($whId, $uid, $sosysno, $subject, $suggest, $nickName, $email, $phone);
	if($rs === false){
		Logger::err("IMycentFeedback::addFeedback failed, code:" . IMycentFeedback::$errCode . ', msg:' . IMycentFeedback::$errMsg);
		return array('errno' => 6003);
	}
	return  array('errno' => 0);
}


//ɾ���ҵķ���
function myfeedback_delfeedback(){
	$uid=IUser::getLoginUid();
	$whId = IUser::getSiteId ();
	if(empty($uid)){
		return array('errno' => 500);
	}

	$sysno = empty($_GET['sysno']) ? '' :$_GET['sysno'];
	if(empty($sysno)){
		return  array('errno' => 1);
	}

	//���˷�վ�߼�
	$rs = IMycentFeedback::delFeedback($whId, $uid, $sysno);
	if($rs === false){
		Logger::err('IMycentFeedback::delFeedback failed-' . IMycentFeedback::$errCode . '-' . IMycentFeedback::$errMsg);
		return array('errno' => 6004);
	}
	return  array('errno' => 0);
}


//������ʾ
function _output_error($str, &$TPL){
	$TPL->set_var('content', '<div class="i_content" style="text-align:center">' . $str . '</div>');
	$TPL->out();
}