<?php
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IDIYUser.class.php');
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');

Logger::init();

function page_mydiyconfig_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, 'mydiyconfig', array(
		'titleDesc' => '�ҵ�װ������'
	));
 
	$TPL->set_var('pageName', '�ҵ�װ������');
	$TPL->set_file(array(
			'contentHandler' => 'mydiyconfig.tpl'
	));
	
	$wid = IUser::getSiteId();
	$result = IDIYUser::getDIYUserList($uid, $wid);
	if($result === false){
		Logger::err('IDIYUser::getDIYUserList failed-' . IDIYUser::$errCode . '-' . IDIYUser::$errMsg);
		return _output_error('ϵͳ��æ�����Ժ����ԣ�[The Information:getDIYUserList -false]', $TPL);
	}
	$TPL->set_block("contentHandler", 'mydiyconfig_list', 't_mydiyconfig_list');
	if (!empty($result)){
		foreach ( array_reverse($result) as $val){
			$params = array(
				'type_name' => ToolUtil::transXSSContent($val['type_name']),
				'createtime' => substr($val['createtime'], 0, 10),
				'uid' => $uid,
				//'createtime' => date('Y-m-d',$val['createtime']),
				'title' => ToolUtil::transXSSContent($val['title']),
				'oid' => $val['oid']
			);
			$TPL->set_var($params);
			$TPL->parse('t_mydiyconfig_list', 'mydiyconfig_list', true);
			$TPL->unset_var(array_keys($params));
		}
	}else {
		$TPL->set_var('t_mydiyconfig_list', '<tr><td colspan="4"><p class="kong">�����û������װ����</p></td></tr>');
	}

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

//ɾ��DIYװ������
function mydiyconfig_deldiyconfig(){
	$uid=IUser::getLoginUid();
	$wid = IUser::getSiteId();
	if(empty($uid)){
		return array('errno' => 500);
	}
	
	$mid = empty($_GET['mid']) ? '' :$_GET['mid'];
	if(empty($mid)){
		return  array('errno' => 1);
	}

	$rs = IDIYUser::delDIYUser($mid, $wid, $uid);
	if($rs === false){
		Logger::err('IDIYUser::delDIYUser failed-' . IDIYUser::$errCode . '-' . IDIYUser::$errMsg);
		return array('errno' => 6001);
	}
	return  array('errno' => 0);
}

//������ʾ
function _output_error($str, &$TPL){
	$TPL->set_var('content', '<div class="i_content" style="text-align:center">' . $str . '</div>');
	$TPL->out();
}