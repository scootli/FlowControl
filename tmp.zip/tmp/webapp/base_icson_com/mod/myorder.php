<?php
require_once( PHPLIB_ROOT . "lib/Config.php");
require_once( PHPLIB_ROOT . "api/IVirtualPay.php");

Logger::init();

/**
 * �ҵĶ���ҳ��
 */
function page_myorder_page() {
	$uid = ToolUtil::checkLoginOrRedirect();

	$beforeOneMonth = false; //1����ǰ������

	//��������
	ToolUtil::setCurrentPageId(3, 11594060);
	if (! empty($_GET['type'])) {
		switch($_GET['type']) {
			case '1':
				ToolUtil::setCurrentPageId(3, 11594070);
				$beforeOneMonth = true;
				break;

			case '2':
				ToolUtil::setCurrentPageId(3, 11594080);
				return virtualorder_page(); //���ⶩ��

			case '3':
				ToolUtil::setCurrentPageId(3, 11594090);
				return virtualorder_page(); //���ⶩ��
		}
	}

	$TPL = TemplateHelper::getBaseTPL(0, "myorder", array(
		'titleDesc' => '�ҵĶ���'
	));
	$TPL->set_file(array(
		'contentHandler' => 'myorder_content.tpl'
	));

	$TPL->set_var('recently_state', 'status_on');
	$TPL->set_var('virtual_Moblie_state', '');

	//����������ѡ��״̬
	if ( $beforeOneMonth ) {
		$TPL->set_var('recentlyOrderSelect', '');
		$TPL->set_var('oneMonthAgoOrderSelect', 'selected');
	}
	else {
		$TPL->set_var('recentlyOrderSelect', 'selected');
		$TPL->set_var('oneMonthAgoOrderSelect', '');
	}

	$TPL->set_var('pageName', '�ҵĶ���');
	$TPL->set_block("contentHandler", 'list', 't_list');

	$currentPage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$pageSize = 10;
	if ($beforeOneMonth) { //һ����֮ǰ
		$orderList = IOrder::getUserOrdersOneMonthAgo($uid, $currentPage - 1, $pageSize);
	}
	else { //����
		$orderList = IOrder::getUserOrdersInOneMonth($uid, $currentPage - 1, $pageSize);
	}

	if ($orderList === false) {
		Logger::err('IOrder::getUserOrders failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);
		$TPL->set_var('t_list', '<tr><td colspan="7"><p class="kong">�����쳣</p></td></tr>');
		$TPL->parse('content', 'contentHandler');
		$TPL->out();
		return;
	}

	$orders = array();  //��ת����ֵ�ṹ
	foreach($orderList['orders'] as &$order) {
		if ($order['order_char_id'] == $order['pOrderId']) {
			$orders[ $order['order_char_id'] ] = $order;
			$orders[ $order['order_char_id'] ] ['isParentOrder'] = false;
		}
		else { //�ӵ�
			$orders[ $order['pOrderId'] ] ['isParentOrder'] = true;
			$orders[ $order['pOrderId'] ] ['pOrderId'] = $order['pOrderId'];
			$orders[ $order['pOrderId'] ] ['order_char_id'] = $order['pOrderId'];
			$orders[ $order['pOrderId'] ] ['subOrders'] [ $order['order_char_id'] ] = $order;
		}
	}
	//���㸸��������
	foreach($orders as &$order) {
		if ($order['isParentOrder']) {
			$order['parent_online_pay_status'] = IOrder::computeParentOrderPayStatus($order['subOrders']); //�ϲ�֧����

			if ($order['parent_online_pay_status']) { //��������ʾ�ϲ�֧��ʱ��ȡ����������������
				foreach($order['subOrders'] as &$subOrder) {
					@$order['coupon_amt'] += intval($subOrder['coupon_amt']);
					@$order['point_pay'] += intval($subOrder['point_pay']);
				}
			}
		}
	}

	if (!empty($orderList['orders'])) {
		$package_orderid_temp = array(); //չʾ���Ķ��������id

		foreach ($orderList['orders'] as &$order) {
			if (in_array($order['order_char_id'], $package_orderid_temp)) {
				continue;
			}

			$pOrderId = $order['pOrderId'];
			$order_char_id = $order['order_char_id']; //�������
			$order_date = date("Y-m-d", $order['order_date']); //�µ�ʱ��
			$receiver = ToolUtil::transXSSContent( $order['receiver'] ); //�ջ���

			$rowspan = '';
			$isPackage = false;//�Ƿ�Ϊ�����

			$package_orderid = array();

			$order_str = ''; //����htm
			$order_btn_str = ''; //����������htm

			if ( (! empty($pOrderId)) && $pOrderId != $order_char_id ) { // �����
				$isPackage = true;
				$packageArray = _get_array_repeats($orderList['orders'], $pOrderId);
				$packageCount = $packageArray['count'];
				$package_orderid = $packageArray['orderid']; //��������Ӷ���id
				$rowspan = ' rowspan="' . $packageCount . '" ';
				$package_orderid_temp = array_merge($package_orderid_temp, $package_orderid);

				$order_str = '<tr>
<td ' . $rowspan .' class="br l">' . $pOrderId . '<p class="st_com date">' . $order_date . '</p>
	<div class="wrap_adress">
		<a class="js_wrap_address" href="javascript:void(0);" order_id="' . $order_char_id . '" class="name">' . $receiver . '<b class="arrow_piont"></b></a>
		<div class="layout_popup">
			<div class="layout_inner"></div>
			<div class="layout_arrow_left"><span>��</span><i>��</i></div>
		</div>
	</div>
</td>';
				$order_btn_str = $orders[$pOrderId]['parent_online_pay_status'] ? _getParentOrderBtnHtml( $orders[$pOrderId] ) : '';
			}
			else {
				$order_str = '<tr>
<td class="l"><a target="_blank" class="order_nu" href="http://base.51buy.com/orderdetail-' . $order_char_id . '-html">' . $order_char_id . '</a><p class="st_com date">' . $order_date . '</p>
	<div class="wrap_adress">
		<a class="js_wrap_address" href="javascript:void(0);" order_id="' . $order_char_id . '" class="name">' . $receiver . '<b class="arrow_piont"></b></a>
		<div class="layout_popup">
			<div class="layout_inner"></div>
			<div class="layout_arrow_left"><span class="">��</span><i>��</i></div>
		</div>
	</div>
</td>';

				$package_orderid[] = $order_char_id;
			}

			$package_index = 1;
			foreach ($package_orderid as $value) {
				$order_detail = IOrder::getOneOrderDetail($uid, $value);
				if ($order_detail === false) {
					Logger::err('IOrder::getOneOrderDetail failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);
					continue; //TODO ��ȡ������¼ʧ��
				}

				//��Ʒ�б�
				$sub_order_info = $isPackage ? ( '<div class="pack"><strong>����' . $package_index . '</strong><a target="_blank" href="http://base.51buy.com/orderdetail-' . $order_detail['order_char_id'] . '-html">' . $order_detail['order_char_id'] .'</a></div>' ) : '';
				$product_list_str = '';
				if (!empty($order_detail['items'])) {
					$limit_display_count = 8;
					foreach ($order_detail['items'] as $index => $product) {
						if ($limit_display_count-- < 1) {
							break;
						}
						$product_title = strip_tags($product['name']);
						$product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);
						$product_list_str.= '<a target="_blank" href="http://item.51buy.com/item-' . $product['product_id'] .'.html" class="img"><i></i><img src="' . IProduct::getPic($product['product_char_id'], 'small') . '" alt="'.$product_title.'" title="'.$product_title.'"></a>';
					}
				}

				//����״̬
				global $_OrderState, $_PAY_MODE, $_OrderDelayStock, $_OrderProcessId;
				$_order_state_str = "";
				if ( in_array($order_detail['status'], array($_OrderState['Origin']['value'], $_OrderState['WaitingPay']['value'], $_OrderState['WaitingManagerAudit']['value'], ))
					&& $_PAY_MODE[$order_detail['hw_id']][$order_detail['pay_type']]['IsNet'] == 1
					&& $order_detail['isPayed'] == 1) { //����֧�� && ״̬Ϊ����˻��֧�� && �Ѹ�����

					$_order_state_str = '��֧����������';
				}
				else {
					foreach ($_OrderState as $key => $arr) {
						if ($order_detail['status'] == $arr['value']) {
							$_order_state_str = $arr['siteName'];
							break;
						}
					}
				}

				$order_delay = '';
				$process_ids = array();
				$order_process_flows = IOrderProcessFlowTTC::get($order_detail['order_id'], array(), array('process_id')); //��ȡ������������
				if (count($order_process_flows) > 0 && is_array($order_process_flows)) {
					foreach($order_process_flows as $process) {
						$process_ids[] = $process['process_id'];
					}
				}

				$orderdelay_check = IOrder::orderDelayCheck($order_detail['order_date'], $order_detail['stockNo'], $order_detail['status'], $process_ids);
				if ($orderdelay_check) {
					$is_delay = IOrder::orderDelay($order_detail['order_char_id'], $order_detail['shipping_type']);
					$order_delay = (isset($is_delay['data']) && $is_delay['data']['order_delay_status'] == 1) ? '<span class="hot">���ӻ���</span>' : '';
					$_order_state_str = $_order_state_str . $order_delay;
				}

				$status = _convertStatusHTML($order_detail['status'], $_order_state_str); //����״̬��ʾhtml

				//�ܽ��
				$siteId = $order_detail['hw_id'];
				$payInfo = ToolUtil::getPayTypeInfo($order_detail['pay_type'], $siteId); //֧����ʽ
				$payTypeName = false === $payInfo ? "" : $payInfo['PayTypeName'];

				$remain_payment_time = empty($order_detail['need_pay']) ? '' : 'ʣ��:' . _getRemainPaymentTimeStr($order_detail, $payInfo); //ʣ�ึ��ʱ��

				$order_cost = sprintf("%.2f", $order_detail['cash'] / 100); //�������
				$shipping_cost = sprintf("%.2f", $order_detail['shipping_cost'] / 100); //�����˷�

				if ( ($order_detail['bits'] & ORDER_SEPARATE_GOODS_INVOICE) == ORDER_SEPARATE_GOODS_INVOICE) { //��Ʊ����
					$invoice_send_info='<div class="layout_inner invoice_box">
	<div class="layout_hd"><h4>��Ʊ����</h4></div>
	<div class="layout_bd"></div>
</div>';
				}
				else {
					$invoice_send_info = '';
				}

				//��������
				$price_protect_block = '';
				$now = time();
				if(($order_detail['status'] != $_OrderState['Return']['value'])//��ȫ���˻�
					&& ($order_detail['status'] != $_OrderState['ManagerCancel']['value'])//��ϵͳ����
					&& ($order_detail['status'] != $_OrderState['CustomerCancel']['value'])//�ǿͻ�����
					&& ($order_detail['status'] != $_OrderState['EmployeeCancel']['value']))//��Ա������
				{
					if(($now - $order_detail['order_date']) > 86400)//�µ�ʱ���24Сʱ��
					{
						$payBack = EA_AutoPayBack::getOnePayBackInfo($order_detail['order_char_id']);
						if($payBack === false)
						{
							Logger::err( "EA_AutoPayBack::getOnePayBackInfo failed, code:" . EA_AutoPayBack::$errCode . ', msg:' . EA_AutoPayBack::$errMsg . ', uid:' . $uid . ' order_char_id:' . $order_detail['order_char_id']);
						}
						else
						{
							if(is_array($payBack) && count($payBack) >0)
							{
								$paid_back_price = 0;//��������
								foreach ($payBack as $pay)
								{
									if($pay['result'] == 1)//ֻ���㲹���ɹ��Ļ���
									{
										$paid_back_price += $pay['paid_back_price'];
										$price_protect_pid[$pay['product_id']] = $pay['paid_back_price'];
									}
								}

								if($paid_back_price >0)//�в�������,�����ɹ�
								{
									$price_protect_block = '<div class="wrap_pp">
									<p class="pp_bd"><i class="dot" onmouseout="javascript:$(this).parent().parent(\'div\').find(\'.layout_popup\').css(\'display\', \'none\');" onmouseover="javascript:$(this).parent().parent(\'div\').find(\'.layout_popup\').css(\'display\', \'block\');"></i>�Ѳ���<span class="price_strong">' . $paid_back_price . '</span>����</p>
									<div style="display:none" class="layout_popup">
										<div class="layout_inner">
											<dl>
												<dt>�۸񱣻�</dt>
												<dd>�û��µ���24Сʱ�ڣ�����Ʒ�ļ۸�����������ǰ�۸�����û�ʵ�ʹ���۸�ģ�ͬʱ���㽵�۷��ȴ���5%�����Է��ϼ۸񱣻���������Ʒ���û��������Ѹ�Զ������Ĳ�ۡ� </dd>
											</dl>
										</div>
										<div class="layout_arrow_top"> <span class="">��</span><i>��</i> </div>
										</div>
									</div>';
								}
							}
						}
					}
				}

				//�����в���
				$order_button_list = empty( $order_btn_str )
					? _getOrderButtonHtml($uid, $order_detail)
					: ( (1 == $package_index) ? $order_btn_str : '' ); //֮ǰ�������ɹ�����֮ǰ�ģ����¼���

				$str = '<td' . ( $isPackage ? ' class="bb l"' : '' ) . '>' . $sub_order_info . '
		<div class="wrap_goods">' . $product_list_str . '</div>
	</td>
	<td ' . ( $isPackage ? 'class="bb"' : '' ) . '>'
		. $status .
		'<p>' . $remain_payment_time . '</p>
		<div class="wrap_layout_track">
			<a class="link_track js_link_track" href="javascript:void(0);" order_id="' . $order_detail['order_char_id'] . '">����<b class="arrow_piont"></b></a>
			<div class="layout_popup">
				<div class="layout_inner order_box">
					<div class="layout_hd"><h4>��������</h4></div>
					<div class="layout_bd"></div>
				</div>'
				.$invoice_send_info.
				'<div class="layout_arrow_top"><span class="">��</span><i>��</i></div>
			</div>
		</div>
	</td>
	<td>
		<div class="other_info">
			<p class="price">
				<span class="price_strong"><span class="i_yuan">&yen;</span>' . $order_cost . '</span>
				<span class="nor">�����˷ѣ�<span class="i_yuan">&yen;</span>' . $shipping_cost . '��</span>
			</p>
			<p>
				<span class="pay_online nor">' . $payTypeName . '</span>
			</p>
			' . $price_protect_block . '
		</div>
	</td>'
	. $order_button_list .
'<tr>';

				$order_str .= $str;

				$package_index++;
			}

			$TPL->set_var('order_list', $order_str);
			$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myorder-'.($beforeOneMonth ? '1' : '0').'-{page}.html', $currentPage, ceil( $orderList['total'] / $pageSize )) . '</div></div>');
			$TPL->parse('t_list', 'list', true);
		}
	}
	else {
		$TPL->set_var('t_list', '<tr>
	<td colspan="6">
		<p class="kong">����' . ($beforeOneMonth ? 'һ����֮ǰ' : '���һ����') . 'û���ύ������</p>
	</td>
</tr>');

		$TPL->set_var('page', '');
	}

	$TPL->parse('content', 'contentHandler');
	//itil�ϱ�
	ToolUtil::itilReport(635759);
	$TPL->out();
}

function virtualorder_page() {
	global $_VP_MobileOrderState;
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0, "myorder", array(
		'titleDesc' => '�ҵĶ���'
	));

	$TPL->set_file(array(
		'contentHandler' => 'virtualOrder_content.tpl'
	));

	$TPL->set_var('virtual_Moblie_state', 'status_on');
	$TPL->set_var('before_one_month_state', '');
	$TPL->set_var('recently_state', '');

	$beforeOneMonth = ($_GET['type'] == "3") ? true : false;

	//����������ѡ��״̬
	if ( $beforeOneMonth ) {
		$TPL->set_var('recentlyOrderSelect', '');
		$TPL->set_var('oneMonthAgoOrderSelect', 'selected');
	}
	else {
		$TPL->set_var('recentlyOrderSelect', 'selected');
		$TPL->set_var('oneMonthAgoOrderSelect', '');
	}

	$ret = explode("-", date("Y-m") );
	$currentYear = $ret[0];
	$currentMonth = $ret[1];

	$begin = "";
	$end = "";

	$currentPage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$pageSize = 10;

	if ($beforeOneMonth) { //һ����֮ǰ
		$orderList = IVirtualPay::getUserOrdersOneMonthAgo($uid, $currentPage - 1, $pageSize);
	}
	else { //����
		$orderList = IVirtualPay::getUserOrdersInOneMonth($uid, $currentPage - 1, $pageSize);
	}

	$TPL->set_var('pageName', '��ֵ����');

	$TPL->set_block("contentHandler", 'list', 't_list');
	if ($orderList === false) {
		Logger::err('IVirtualPay::getUserOrders failed-' . IVirtualPay::$errCode . '-' . IVirtualPay::$errMsg);
		$TPL->set_var('t_list', '<tr><td colspan="7"><p class="kong">�����쳣</p></td></tr>');
		$TPL->parse('content', 'contentHandler');
		$TPL->out();
		return false;
	}
	if (!empty($orderList['orders'])) {
		foreach ( $orderList['orders'] as &$order) {
			//����״̬
			$order['isVirtualOrder'] = true;
			$_orderState = isset($_VP_MobileOrderState[$order['status']]) ? $_VP_MobileOrderState[$order['status']][0] : "";
			//��ֵ������
			$card_str = $order['area'] . str_replace("�й�","",$order['operator']) . ((int)($order['chargeMoney'])/100) . 'Ԫ��ֵ��';

			$siteId = $order['wh_id'];
			$payInfo = ToolUtil::getPayTypeInfo($order['payType'], $siteId); //֧����ʽ
			$PayTypeName = false === $payInfo ? "" : $payInfo['PayTypeName'];

			if (VP_STATUS_INIT == $order['status']) {
				$order_button_list = '<p><a target="_blank" href="http://pay.51buy.com/redirect_'. $order['order_char_id'] . '_1" class="btn_strong70">ȥ����</a></p>';
			}
			else {
				$order_button_list = '';
			}

			$params = array(
				'order_char_id' => $order['order_char_id'], //�������
				'order_id' => $order['orderId'],
				'order_date' => date("Y-m-d G:i:s", $order['orderTime']), //�µ�ʱ��
				'order_cost' => sprintf("%.2f", $order['cash']/100), //�������
				'status' => $_orderState, //����״̬
				'order_create_time' => $order['orderTime'],
				'order_button_list'=>$order_button_list,
				'receiver' => $order['targetId'], //�ջ���
				'pay_type' => $PayTypeName,
				'product_list_str' => $card_str
			);

			$TPL->set_var($params);
			$TPL->parse('t_list', 'list', true);
			$TPL->unset_var($params);

			$TPL->set_var('page', '<div class="page_wrap"><div class="paginator">' . ToolUtil::getpageHTML('http://base.51buy.com/myorder-2-{page}.html', $currentPage, ceil( $orderList['total'] / $pageSize )) . '</div></div>');
		}
	}
	else {
		$TPL->set_var('t_list', '<tr><td colspan="7"><p class="kong">�����û���ύ����ֵ����</p></td></tr>');
		$TPL->set_var('page', '');
	}
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
	return true;
}

/**
 * ��ȡ���ڸö�����ť�� HTML ����
 * @param int $uid �û�ID
 * @param array $order ������Ϣ
 * @return string
 */
function _getOrderButtonHtml($uid, &$order) {
	$str = '';

	$order_char_id = $order['order_char_id'];
	$can_evaluate = false; //�������ۣ�

	if (isset($order['items'])) {
		foreach ($order['items'] as $value) {
			if ($value['can_evaluate']) {
				$can_evaluate = true;
				break;
			}
		}
	}

	$payInfoBtn = '';
	if ($order['pay_type'] == 3 || $order['pay_type'] == 4) { // ���е��or�ʾֻ��
		$payInfoBtn = '<div class="wrap_paydetail">
	<a href="javascript:void(0);" class="btn_normal70 js_wrap_paydetail" order_id="' . $order_char_id . '">������Ϣ</a>
	<div class="layout_popup">
		<div class="layout_inner"> </div>
		<div class="layout_arrow_top">
			<span class="">��</span><i>��</i>
		</div>
	</div>
</div>';
	}

	global $_OrderState;

	switch($order['status']) {

		//�����
		case $_OrderState['Origin']['value']:
		case $_OrderState['WaitingManagerAudit']['value']:
			$str .= $payInfoBtn;
			$str .= empty($order['need_pay']) ? '': '<a target="_blank" href="http://pay.51buy.com/redirect_'. $order_char_id . '" class="btn_strong70">ȥ����</a>';
			$str .= '<p><a href="http://base.51buy.com/orderdetail-'. $order_char_id .'.html" target="_blank">��������</a></p>';
			$str .= '<p><a href="http://service.51buy.com/ordermodify.html?orderid='. $order_char_id .'" target="_blank">�޸Ķ���</a></p>';
			$coupon_str = 'withcoupon="' . (!empty($order['coupon_amt']) ? sprintf("%.2f",$order['coupon_amt']/100) : 0) . '" ';
			$point_str = ' withpoint="' . (!empty($order['point_pay']) ? $order['point_pay']/10 : 0) . '" ';
			$str .= empty($order['can_cancel']) ? '': ('<p><a ' . $coupon_str . $point_str .' href="#" class="cancelBtn" onclick="G.app.mycenter.order.cancel(this, \''. $order_char_id .'\');return false;">ȡ������</a></p>');
			break;

		//Ա������ || ϵͳ����
		case $_OrderState['EmployeeCancel']['value']:
		case $_OrderState['ManagerCancel']['value']:
			$str .= '<p><a href="http://base.51buy.com/orderdetail-'. $order_char_id .'.html" target="_blank">��������</a></p>';

			if ( ($order['flag'] & ORDER_CP) == ORDER_CP ) { // ����Ƕ��ƻ��������޸ļ��빺���urlΪ���ƻ���������
				if ( count($order['items']) > 1) {
					foreach ($order['items'] as &$item) { // ����������Ʒ���ҵ����ƻ�
						if ( ($item['flag'] & CP_YCHF ) == CP_YCHF || ($item['flag'] & CP_GJRW ) == CP_GJRW ) {
							$str .= '<p><a class="second" href="http://buy.51buy.com/stepone-'.$item['product_id'].'.html">���¼��빺�ﳵ</a></p>';
							break;
						}
					}
				}
				else { //TODO ����Ӧ����������ģ�Ҫô�߲������ߵ���Ҳ�Ǵ���
					$str .= '<p><a class="second" href="http://buy.51buy.com/stepone.html">���¼��빺�ﳵ</a></p>';
				}
			}
			else {
				$product_ids = array_keys($order['items']);
				if (!empty($product_ids)) {
					$product_ids_str = implode(',', $product_ids);
					$str .= '<p><a class="second" href="http://buy.51buy.com/cart.html?ids='. $product_ids_str .'">���¼��빺�ﳵ</a></p>';
				}
			}
			break;

		// ��֧��
		case $_OrderState['WaitingPay']['value']:
			$str .= $payInfoBtn;
			$str .= empty($order['need_pay']) ? '': '<a target="_blank" href="http://pay.51buy.com/redirect_'. $order_char_id . '" class="btn_strong70">ȥ����</a>';
			$str .= '<p><a href="http://base.51buy.com/orderdetail-'. $order_char_id .'.html" target="_blank">��������</a></p>';
			$str .= '<p><a href="http://service.51buy.com/ordermodify.html?orderid='. $order_char_id .'" target="_blank">�޸Ķ���</a></p>';
			$coupon_str = 'withcoupon="' . (!empty($order['coupon_amt']) ? sprintf("%.2f",$order['coupon_amt']/100) : 0) . '" ';
			$point_str = ' withpoint="' . (!empty($order['point_pay']) ? $order['point_pay']/10 : 0) . '" ';
			$str .= empty($order['can_cancel']) ? '': ('<p><a ' . $coupon_str . $point_str .' href="#" class="cancelBtn" onclick="G.app.mycenter.order.cancel(this, \''. $order_char_id .'\');return false;">ȡ������</a></p>');
			break;

		// ������
		case $_OrderState['WaitingOutStock']['value']:
			$str .= '<p><a href="http://base.51buy.com/orderdetail-'. $order_char_id .'.html" target="_blank">��������</a></p>';
			$str .= '<p><a href="http://service.51buy.com/ordermodify.html?orderid='. $order_char_id .'" target="_blank">�޸Ķ���</a></p>';
			$str .= '<p><a href="http://service.51buy.com/ordercancel.html?orderid='. $order_char_id .'" target="_blank">ȡ������</a></p>';
			break;

		// �ѳ���
		case $_OrderState['OutStock']['value']:
			$str .= '<p><a href="http://base.51buy.com/orderdetail-'. $order_char_id .'.html" target="_blank">��������</a></p>';
			$now = time();
			if(($now - $order['out_time']) <= 8*3600)//����8Сʱ��
			{
				$str .= '<p><a href="http://service.51buy.com/ordermodify.html?orderid='. $order_char_id .'" target="_blank">�޸Ķ���</a></p>';
				$str .= '<p><a href="http://service.51buy.com/ordercancel.html?orderid='. $order_char_id .'" target="_blank">ȡ������</a></p>';
			}
			
			$str .= '<p><a href="http://base.51buy.com/myrepair.html" target="_blank">����/�˻���</a></p>';

			//modify by allenzhou 2011-12-22 �������۹����޸�
			$product_ids = array_keys($order['items']);
			global $_CP_Sp_Data;
			if ( in_array($_CP_Sp_Data[SP_LT]['CardID'], $product_ids) || in_array($_CP_Sp_Data[SP_DX]['CardID'], $product_ids) ) {
				$str .= '<p>&nbsp</p>';
			}
			else {
//				if ($can_install) {
//					$str .= '<p><a href="http://base.51buy.com/myinstall_report-' . $order_char_id . '.html" class="btn_normal110" target="_blank">����ԤԼ��װ</a></p>';
//				}
				if (count($product_ids) > 1) {
					if ($can_evaluate) {
						$str .='<p><a href="http://base.51buy.com/orderdetail-' . $order_char_id . '.html#review" target="_blank">ȥ��������</a></p>';
					}
				}
				else {
					if ($can_evaluate) {
						$str .='<p><a href="http://item.51buy.com/review-toaddexperience-' . $product_ids[0] . '.html" target="_blank">ȥ��������</a></p>';
					}
				}
			}

			if (EA_GuiJiuPei::validateGJPOrder($uid, $order)) { //�����
				$str .= '<div class="wrap_guijiupei">
	<a class="btn_normal110" href="http://base.51buy.com/payforexpensiveness_report_'. $order_char_id .'.html" target="_blank"><i class="clock"></i>��������</a>
	<div class="layout_popup id_guijiupei_btn">
		<div id="time_countdown_'.$order_char_id.'" class="layout_inner wrap_clock" timestamp="' . $order['out_time'] . '">
			ʣ������ʱ��
			<span class="strong hours_dash"><em class="digit">0</em><em class="digit">0</em></span>ʱ
			<span class="strong minutes_dash"><em class="digit">0</em><em class="digit">0</em></span>��
			<span class="strong seconds_dash"><em class="digit">0</em><em class="digit">0</em></span>��
		</div>
		<div class="layout_arrow_top"><span class="">��</span><i>��</i></div>
	</div>
</div>';
			}

			break;

		// �ͻ�����
		case $_OrderState['CustomerCancel']['value']:
			$str .= '<p><a href="http://base.51buy.com/orderdetail-'. $order_char_id .'.html" target="_blank">��������</a></p>';

			if ( ($order['flag'] & ORDER_CP) == ORDER_CP ) { // ����Ƕ��ƻ��������޸ļ��빺���urlΪ���ƻ���������
				if ( count($order['items']) > 1) {
					foreach ($order['items'] as $item) {
						// ����������Ʒ���ҵ����ƻ�
						if ( ($item['flag'] & CP_YCHF ) == CP_YCHF || ($item['flag'] & CP_GJRW ) == CP_GJRW ) {
							$str .= '<p><a class="second" href="http://buy.51buy.com/stepone-'.$item['product_id'].'.html">���¼��빺�ﳵ</a></p>';
							break;
						}
					}
				}
				else {
					$str .= '<p><a class="second" href="http://buy.51buy.com/stepone.html">���¼��빺�ﳵ</a></p>';
				}
			}
			else {
				$product_ids = array_keys($order['items']);
				if (! empty($product_ids)) {
					$product_ids_str = implode(',', $product_ids);
					$str .= '<p><a class="second" href="http://buy.51buy.com/cart.html?ids='. $product_ids_str .'">���¼��빺�ﳵ</a></p>';
				}
			}
			break;

		// �����˻�
		case $_OrderState['PartlyReturn']['value']:
			$str .= '<p><a href="http://base.51buy.com/orderdetail-'. $order_char_id .'.html" target="_blank">��������</a></p>';

			//modify by allenzhou 2011-12-22 �������۹����޸�
			$product_ids = array_keys($order['items']);
//			if ($can_install === true) {
//				$str .= '<p><a href="http://base.51buy.com/myinstall_report-' . $order_char_id . '.html" class="btn_normal110" target="_blank">����ԤԼ��װ</a></p>';
//			}
			if (count($product_ids) > 1) {
				if ($can_evaluate) {
					$str .='<p><a href="http://base.51buy.com/orderdetail-' . $order_char_id . '.html#review" target="_blank">ȥ��������</a></p>';
				}
				else {
					$str .='<p>&nbsp</p>';
				}
			}
			else {
				if ($can_evaluate) {
					$str .='<p><a href="http://item.51buy.com/review-toaddexperience-' . $product_ids[0] . '.html" target="_blank">ȥ��������</a></p>';
				}
				else {
					$str .='<p>&nbsp</p>';
				}
			}

			if (EA_GuiJiuPei::validateGJPOrder($uid, $order)) { //�����
				$str .= '<p><a class="btn_normal110" href="http://base.51buy.com/payforexpensiveness_report_'
					 . $order_char_id .'.html" target="_blank"><i class="clock"></i>��������</a></p>';
			}

			break;

		//ȫ���˻�
		case $_OrderState['Return']['value']:
			$str .= '<p><a href="http://base.51buy.com/orderdetail-'. $order_char_id .'.html" target="_blank">��������</a></p>';
			break;

		default:
			Logger::err('order status is exception - ' . $order['status']);
			break;
	}

	return '<td>
		<div class="wrap_btn">' . $str . '</div>
	</td>';
}

function page_myorder_modifyinvoice() {
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '');

	$TPL->set_var(array(
		'pageName'	=> '�޸���Ʊ����',
	));

	if (empty($_GET['order_id'])) {
		return TemplateHelper::outMessage("��������");
	}

	$invoice = IOrder::getOrderInvoice($uid, $_GET['order_id']);
	if ($invoice === false) {
		Logger::err("IOrder::getOrderInvoice failed, code: " . IOrder::$errCode . '; msg: ' . IOrder::$errMsg);
		return TemplateHelper::outMessage("ϵͳ��æ�����Ժ����ԣ�");
	}

	$invoice = $invoice[0];

	if ($invoice['type_id'] != INVOICE_TYPE_VAT) {
		return TemplateHelper::outMessage("�ö����ķ�Ʊ������ֵ˰��Ʊ���޷��޸ġ�", 'warn');
	}

	$TPL->set_file(array(
		'contentHandler' => 'myorder_modifyinvoice_content.tpl'
		));

		$vars = array(
		'order_id'	=> addslashes($_GET['order_id']),
		'name'	=> empty($invoice['name']) ? '' : addslashes($invoice['name']),
		'addr'	=> empty($invoice['addr']) ? '' : addslashes($invoice['addr']),
		'phone'	=> empty($invoice['phone']) ? '' : addslashes($invoice['phone']),
		'taxno'	=> empty($invoice['taxno']) ? '' : addslashes($invoice['taxno']),
		'bankno'	=> empty($invoice['bankno']) ? '' : addslashes($invoice['bankno']),
		'bankname'	=> empty($invoice['bankname']) ? '' : addslashes($invoice['bankname']),
		'ivcontent'	=> '' //empty($invoice['content']) ? '' : addslashes($invoice['content'])
		);

		$TPL->set_var($vars);
		$TPL->parse('content', 'contentHandler');
		$TPL->unset_var(array_keys($vars));
		$TPL->out();
}

function myorder_orderflow() {
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	if (!isset($_GET['order_id'])) {
		return array(
			"errno" => 1,
			"data" => "��������"
		);
	}
	$order_id = intval($_GET['order_id']);
	$order_id = (strlen($order_id) == 8) ? "10{$order_id}" : $order_id; //�ֻ�������8λ��ID
	$result = IOrder::geOrderFlow($uid, $order_id);
	if (false === $result) {
		if (IOrder::$errCode === -999) {
			return array(
				"errno" => 2,
				"data" => "����������",
			);
		}
		else {
			Logger::err('IOrder::geOrderFlow failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);

			return array(
				"errno" => 3,
				"data" => "��ѯʧ�ܣ� ���Ժ����ԣ�"
			);
		}
	}

	return array(
		"errno" => 0,
		"data" => $result
	);
}

function myorder_orderReceiverInfo() {
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}
	if (!isset($_GET['order_id'])) {
		return array(
			"errno" => 1,
			"data" => "��������"
			);
	}
	$order_id = intval( $_GET['order_id'] );
	$result = IOrder::getOneOrderDetail($uid, $order_id);
	if (false === $result) {
		if (IOrder::$errCode === -999) {
			return array(
				"errno" => 2,
				"data" => "����������"
				);
		}
		else {
			Logger::err('IOrder::getOneOrderDetail failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);

			return array(
				"errno" => 3,
				"data" => "��ѯʧ�ܣ� ���Ժ����ԣ�"
				);
		}
	}
	$ret = array();
	$ret['receiver_addr'] = $result['receiver_addr'];
	$ret['receiver_mobile'] = $result['receiver_mobile'];
	return array(
		"errno" => 0,
		"data" => $ret
	);
}

function myorder_bankOrPostofficePayInfo() {
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}
	if (!isset($_GET['order_id'])) {
		return array(
			"errno" => 1,
			"data" => "��������"
			);
	}
	$order_id = intval( $_GET['order_id'] );
	$order = IOrder::getOneOrder($uid, $order_id);
	if (false === $order) {
		Logger::err('IOrder::getOneOrder failed-' . IOrder::$errCode . '-' . IOrder::$errMsg);

		return array(
			"errno" => 3,
			"data" => "��ѯʧ�ܣ� ���Ժ����ԣ�"
			);
	}
	global $_StockToStation;
	$stock_hw_id = SITE_SH;
	if ( isset($_StocktoStation[$order['stockNo']]) ) {
		$stock_hw_id = $_StockToStation[$order['stockNo']];
	}

	$message = '';
	if ($order['pay_type'] == 3) { // ���е��
		$message = '
			<a href="javascript:void(0);" class="close">�ر�</a>
			<p>���е�㵽��ʱ��ԼΪ2��4��</p>
			<table class="table_paydetail">
				<tr>
					<td>��	  �� </td>
					<td>�Ϻ���Ѹ��������չ���޹�˾</td>
				</tr>
				<tr>
					<td>��������</td>
					<td>�й����������Ϻ�������֧��</td>
				</tr>
				<tr>
					<td>�ʺ�</td>
					<td>31001528700050010815</td>
				</tr>
				<tr>
					<td colspan="2"><strong>ע�����ڵ�㵥�����;����ע�����Ķ�����</strong>' . $order['order_char_id'] . '</td>
				</tr>
			</table>
			<a href="http://st.51buy.com/help/2-5-banktransfer.htm" target="_blank">�鿴���ึ����Ϣ</a>';
	} else if ($order['pay_type'] == 4) { // �ʾֻ��
		$message = '
			<a href="javascript:void(0);" class="close">�ر�</a>
			<p>�ʾָ����ʱ��ԼΪ1��3��</p>
			<table class="table_paydetail">
				<tr>
					<td>�������</td>
					<td>������</td>
				</tr>
				<tr>
					<td>�̻��ͻ���</td>
					<td><strong>312220031</strong>&nbsp;�������׼ȷ��д��</td>
				</tr>
				<tr>
					<td>�տλ</td>
					<td>�Ϻ���Ѹ��������չ���޹�˾</td>
				</tr>
				<tr>
					<td colspan="2"><strong>ע�����ڵ�㵥�����;����ע�����Ķ�����</strong>' . $order['order_char_id'] . '</td>
				</tr>
			</table>
			<a href="http://st.51buy.com/help/2-4-postal_remittance.htm" target="_blank">�鿴���ึ����Ϣ</a>';
	}
	return array(
		"errno" => 0,
		"data" => $message
	);
}

function myorder_domodifyinvoice() {
	$uid = IUser::getLoginUid();
	if (!$uid) {
		return array('errno' => 500);
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	if (empty($_POST['order_id'])) {
		return array('errno' => 11);
	}
	$order_id = $_POST['order_id'];

	$newVAT = array();
	if (empty($_POST['name'])) {
		return array('errno' => 12);
	}
	$newVAT['invoiceTitle'] = $newVAT['invoiceCompanyName'] = $_POST['name'];

	if (empty($_POST['addr'])) {
		return array('errno' => 13);
	}
	$newVAT['invoiceCompanyAddr'] = $_POST['addr'];

	if (empty($_POST['phone'])) {
		return array('errno' => 14);
	}
	$newVAT['invoiceCompanyTel'] = $_POST['phone'];

	if (empty($_POST['taxno'])) {
		return array('errno' => 15);
	}
	$newVAT['invoiceTaxno'] = $_POST['taxno'];

	if (empty($_POST['bankno'])) {
		return array('errno' => 16);
	}
	$newVAT['invoiceBankNo'] = $_POST['bankno'];

	if (empty($_POST['bankname'])) {
		return array('errno' => 17);
	}
	$newVAT['invoiceBankName'] = $_POST['bankname'];

	//if (empty($_POST['content'])) {
	//	return array('errno' => 18);
	//}
	//$newVAT['invoiceContent'] = $_POST['content'];

	$modify = IOrder::modifyOrderVAT($uid, $order_id, $newVAT);
	if ($modify === false) {
		Logger::err("IOrder::modifyOrderVAT failed, code: " . IOrder::$errCode . ', msg: ' . IOrder::$errMsg);
		if (IOrder::$errCode == -2017 || IOrder::$errCode == -2018 || IOrder::$errCode == -2017) {
			return array('errno' => 100, 'data' => IOrder::$errMsg);
		}
		return array('errno' => 6001);
	}

	return array('errno' => 0);
}

//for test
//	$_GET['type_id'] = 1;
//	$_GET['sysno'] = 1697371630;

//	$_GET['type_id'] = 2;
//	$_GET['sysno'] = 468235346764;

//	$_GET['type_id'] = 3;
// $_GET['sysno'] = 9021019346;
function myorder_deliveryflow() {
	$uid = IUser::getLoginUid();

	if (!$uid) {
		return array('errno' => 500);
	}

	$type_id = isset($_GET['type_id']) ? intval($_GET['type_id']) : 0;
	$sysno = isset($_GET['sysno']) ? $_GET['sysno'] : 0;
	if ( empty($type_id) || empty($type_id) ) {
		return array("errno" => 502, "data" => "��������");
	}
	$result = IOrder::getThirdOrderFlow($type_id, $sysno);
	if (false === $result) {
		Logger::err("IOrder::getThirdOrderFlow failed, code: " . IOrder::$errCode . ', msg: ' . IOrder::$errMsg);
		//���Ժ����Ի���ǰ��Բͨ�ٵݲ�ѯ
		$target_url ="���Ժ����Ի���ǰ��<a target='_blank' href='http://www.yto.net.cn/cn/index/index.html'>Բͨ�ٵ�</a>��ѯ��";
		if ($type_id == 1) {
			return array("errno" => 1, "data" => $target_url);
		}
		if ($type_id == 2) {
			return array("errno" => 2, "data" => '��ȡ��ͨ�����ˮʧ�ܣ� ���Ժ����ԣ�');
		}

		return array("errno" => 1, "data" => "��ȡ��������ˮʧ�ܣ� ���Ժ����ԣ�");
	}

	return array("errno" => 0, "data" => $result);
}

/**
 * �ѽ���״̬�Ķ������û�ɫ���壬����3������ and ��ǩ�գ�
 * ������״̬�ú�ɫ���壬���� ����ˡ���֧�����ѳ��⡢�����С�
 * @param int $status ����״̬���ֱ�ʾ
 * @param string $orderStateStr ����״̬�ַ���ʾ
 * @return string
 */
function _convertStatusHTML($status, $orderStateStr) {
	$str = '';

	global $_OrderState;
	switch($status) {
		case $_OrderState['Origin']['value']:
		case $_OrderState['WaitingManagerAudit']['value']:
		case $_OrderState['WaitingPay']['value']:
		case $_OrderState['OutStock']['value']:
		case $_OrderState['WaitingOutStock']['value']:
			$str .= '<strong>' . $orderStateStr . '</strong>';
			break;

		default:
			$str .= '<span class="st_com">' . $orderStateStr . '</span>';
			break;
	}

	return $str;
}

/**
 * ��ȡʣ�ึ��ʱ��
 * @param array $order_detail ������Ϣ
 * @param array $payInfo ֧����Ϣ
 * @return string
 */
function _getRemainPaymentTimeStr($order_detail, $payInfo) {
	$order_date = $order_detail['order_date'];
	$flag = $order_detail['flag'];

	$remainMinute = 0; //ʣ�����
	if ( ($flag & ORDER_RUSHING_BUY_ONLINE_PAY) == ORDER_RUSHING_BUY_ONLINE_PAY ) { //��ʱ����֧������
		$remainMinute = floor(($order_date + 3600 - $_SERVER['REQUEST_TIME']) / 60);
	}
	else if ($payInfo['IsNet'] === 1) { //��ͨ����֧������
		$remainMinute = floor(($order_date + 172800 - $_SERVER['REQUEST_TIME']) / 60); // 172800 = 24 * 2 * 3600 ����
	}
	else if ($payInfo['SysNo'] == 3) { //���е��
		$remainMinute = floor(($order_date + 345600 - $_SERVER['REQUEST_TIME']) / 60); // 345600 = 24 * 4 * 3600 ����
	}
	else if ($payInfo['SysNo'] == 4) { //�������
		$remainMinute = floor(($order_date + 604800 - $_SERVER['REQUEST_TIME']) / 60); // 604800 = 24 * 7 * 3600 ����
	}

	$ret = '';
	if ($remainMinute > 0) {
		$day = floor($remainMinute / 1440);
		if ($day > 0) {
			$ret .= $day . '��';
		}
		$hour = floor(($remainMinute - $day * 1440) / 60);
		if ($hour > 0) {
			$ret .= $hour . 'Сʱ';
		}
		$minute = ($remainMinute - $day*1400 - $hour*60);
		if ($day==0 && $minute > 0 && $minute < 60) {
			$ret .= $minute . '��';
		}
	}

	return $ret;
}

/*
 * ����order_char_id��Ӧ�Ķ������Ϣ
 * return : array(
 * 				'orderid' => array()
 * 				'count' => int
 * 			)
 */
function _get_array_repeats($array,$int) {
	$package_order_ids = array();
	foreach ($array as $item) {
		$cache[$item["order_char_id"]] = $item["pOrderId"];
	}
	$count = array_count_values($cache);
	$orderid = array_keys($cache, $int);
	foreach ($count as $key => $value) {
		if ($key == $int) {
			$ret['count'] = $value;
		}
	}
	$ret['orderid'] = $orderid;
	return $ret;
}

/**
 * ���ظ�����������������HTML
 * @param array $pOrder �ϲ������ĸ�������Ϣ
 * @return string
 */
function _getParentOrderBtnHtml(&$pOrder) {
	$packageCount = count($pOrder['subOrders']);
	$subOrderIdStr = implode(',', array_keys($pOrder['subOrders']));

	$couponStr = ($pOrder['coupon_amt'] > 0) ? "withcoupon='" . sprintf("%.2f",$pOrder['coupon_amt'] / 100) . "'" : null;
	$pointStr = ($pOrder['point_pay'] > 0) ? "withpoint='" . $pOrder['point_pay'] / 10 . "'" : null;

	$cancelBtn = "<div class='wrap_cancel'>
	<a href='javascript:;' class='cancelBtn' onclick='G.app.mycenter.order.cancel(this, {$pOrder['order_char_id']}, [{$subOrderIdStr}]);return false;' {$couponStr} {$pointStr}>ȡ������</a>
</div>";

	return "<td class='br bl' rowspan='{$packageCount}'>
	<div class='wrap_btn'>
		<div><a target='_blank' href='http://pay.51buy.com/redirect_{$pOrder['order_char_id']}' class='btn_strong70'>ȥ����</a></div>
		{$cancelBtn}
	</div>
</td>";

}