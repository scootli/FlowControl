<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'inc/district.inc.php');
require_once(PHPLIB_ROOT . 'api/appplatform/recv_address.php');

Logger::init();

function page_address_page()
{
	$uid = ToolUtil::checkLoginOrRedirect();

	$TPL = TemplateHelper::getBaseTPL(0, "address", array(
		'titleDesc' => '�ջ���ַ����'
	));
	$TPL->set_var(array(
		'pageName'    => '�ջ���ַ����',
	));

	/*$addressList = IUser::getUserAddress($uid);
	if($addressList === false){
		return TemplateHelper::getMessage('ϵͳ��æ�����Ժ����ԣ�');
	}*/

	$TPL->set_file(array(
		'contentHandler' => 'address_content.tpl'
	));
	/*
	$TPL->set_block('contentHandler', 'address_list', 't_address_list');
	foreach ($addressList as $k => $address){
		$district = _checkDistrictValid($address['district']);
		if($district === false) {
			unset($addressList[$k]);
		} else {
			$addressList[$k]['district_chn'] = $district['full_name'];
		}
	}
	if(empty($addressList)){
		$TPL->set_var('t_address_list', '<tr><td colspan="5">����û�������κ��ջ���ַ��</td></tr>');
	} else {
		foreach ($addressList as $address){
			$vars = array(
				'workplace'	=> htmlspecialchars($address['workplace']),
				'name'	=> htmlspecialchars($address['name']),
				'mobile'	=> htmlspecialchars($address['mobile']),
				'phone'	=> htmlspecialchars($address['phone']),
				'address'	=> htmlspecialchars($address['address']),
				'district_chn'	=> $address['district_chn'],
				'ifdefault_desc'	=> !empty($address['sortfactor']) ? '<strong>Ĭ�ϵ�ַ</strong>' : '<a href="">����ΪĬ�ϵ�ַ</a>'
			);
			$TPL->set_var($vars);
			$TPL->parse('t_address_list', 'address_list', true);
			$TPL->unset_var($vars);
		}
	}*/

	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}

function address_add()
{
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	$newAddr = array();

	if (empty($_POST['name'])) {
		return array('errno' => 3);
	}

	if (strlen($_POST['name']) > MAX_ADDR_NAME_LEN) {
		return array('errno' => 4);
	}

	if (empty($_POST['workplace'])) {
		$_POST['workplace'] = $_POST['name'];
	}

	if (strlen($_POST['workplace']) > MAX_COMPANY_LEN) {
		return array('errno' => 2);
	}
	$newAddr['workplace'] = ToolUtil::transXSSContent($_POST['workplace']);
	$newAddr['name'] = ToolUtil::transXSSContent($_POST['name']);

	if (empty($_POST['mobile']) && empty($_POST['phone'])) {
		return array('errno' => 5);
	}

	if (!empty($_POST['mobile']) && !ToolUtil::checkMobilePhone($_POST['mobile'], 'CHN')) {
		return array('errno' => 6);
	}
	$newAddr['mobile'] = !empty($_POST['mobile']) ? ToolUtil::transXSSContent($_POST['mobile']) : '';

	if (!empty($_POST['phone']) && !ToolUtil::checkPhone($_POST['phone'], 'CHN')) {
		return array('errno' => 7);
	}
	$newAddr['phone'] = !empty($_POST['phone']) ? $_POST['phone'] : '';

	if (empty($_POST['district']) || _checkDistrictValid($_POST['district'] - 0) === false) {
		return array('errno' => 8);
	}
	$newAddr['district'] = ToolUtil::transXSSContent($_POST['district']);

	if (empty($_POST['address'])) {
		return array('errno' => 9);
	}

	if (strlen($_POST['address']) > MAX_ADDR_LEN) {
		return array('errno' => 10);
	}
	$newAddr['address'] = ToolUtil::transXSSContent($_POST['address']);

	if (!empty($_POST['zipcode']) && strlen($_POST['zipcode']) > MAX_ZIPCODE_LEN) {
		return array('errno' => 11);
	}
	$newAddr['zipcode'] = !empty($_POST['zipcode']) ? ToolUtil::transXSSContent($_POST['zipcode']) : '';

	//$insertId = EA_Address::insert($uid, $newAddr);
	$insertId = RecvAddress::addRecvAddr($uid, $newAddr);
	if ($insertId === false) {
		Logger::err('Add addr failed: ' . RecvAddress::$errMsg);
		return array('errno' => 12);
	}

	$newAddr['aid'] = $insertId;
	return array(
		'errno'    => 0,
		'data'     => $newAddr
	);
}

function address_get()
{
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	if (strtolower($_SERVER['REQUEST_METHOD']) != 'post') {
		return array('errno' => 1);
	}

	//$address = IUser::getUserAddress($uid);
	$address = RecvAddress::getRecvAddr($uid);
	if ($address === false) {
		Logger::err('Get addr failed: ' . RecvAddress::$errMsg);
		return array('errno' => 2);
	}

	return array(
		'errno'    => 0,
		'data'     => $address,
	);
}

function address_modify()
{
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	if (empty($_POST['aid'])) {
		return array('errno' => 12);
	}

	$newAddr = array(
		'aid'    => ToolUtil::transXSSContent($_POST['aid']) - 0
	);

	if (isset($_POST['name'])) {
		if (empty($_POST['name'])) {
			return array('errno' => 3);
		}

		if (strlen($_POST['name']) > MAX_ADDR_NAME_LEN) {
			return array('errno' => 4);
		}

		$newAddr['name'] = ToolUtil::transXSSContent($_POST['name']);
	}

	if (empty($_POST['workplace'])) {
		$_POST['workplace'] = ToolUtil::transXSSContent($_POST['name']);
	}

	$newAddr['workplace'] = ToolUtil::transXSSContent($_POST['workplace']);
	// �޸ĵ�ʱ��������ֻ�������ߵ绰���룩���붼����
	/*if(!isset($_POST['mobile']) || !isset($_POST['phone'])){
		return array('errno' => 13);
	}*/

	if (empty($_POST['mobile']) && empty($_POST['phone'])) {
		return array('errno' => 5);
	}

	if (!empty($_POST['mobile']) && !ToolUtil::checkMobilePhone($_POST['mobile'], 'CHN')) {
		return array('errno' => 6);
	}
	$newAddr['mobile'] = !empty($_POST['mobile']) ? $_POST['mobile'] : '';

	if (!empty($_POST['phone']) && !ToolUtil::checkPhone($_POST['phone'], 'CHN')) {
		return array('errno' => 7);
	}
	$newAddr['phone'] = !empty($_POST['phone']) ? $_POST['phone'] : '';

	if (isset($_POST['district'])) {
		if (empty($_POST['district']) || _checkDistrictValid($_POST['district'] - 0) === false) {
			return array('errno' => 8);
		}
		$newAddr['district'] = ToolUtil::transXSSContent($_POST['district']);
	}

	if (isset($_POST['address'])) {
		if (empty($_POST['address'])) {
			return array('errno' => 9);
		}

		if (strlen($_POST['address']) > MAX_ADDR_LEN) {
			return array('errno' => 10);
		}
		$newAddr['address'] = ToolUtil::transXSSContent($_POST['address']);
	}

	if (isset($_POST['zipcode'])) {
		if (!empty($_POST['zipcode']) && strlen($_POST['zipcode']) > MAX_ZIPCODE_LEN) {
			return array('errno' => 11);
		}

		if (!empty($_POST['zipcode'])) 
			$newAddr['zipcode'] = ToolUtil::transXSSContent($_POST['zipcode']);
	}

	$newAddr['uid'] = $uid;
	//$update = EA_Address::update($newAddr, array('aid' => $newAddr['aid']));
	$update = RecvAddress::modifyRecvAddr($uid, $newAddr);
	if ($update === false) {
		Logger::err('Modify addr failed: ' . RecvAddress::$errMsg);
		return array('errno' => 14);
	}

	return array('errno' => 0);
}

function address_del()
{
	$uid = IUser::getLoginUid();
	if (empty($uid)) {
		return array('errno' => 500);
	}

	if (empty($_GET['uid']) || $_GET['uid'] != $uid) {
		return array('errno' => 501);
	}

	if (empty($_POST['aid'])) {
		return array('errno' => 12);
	}

	//$del = IUser::delAddress($uid, $_POST['aid'] - 0);
	$del = RecvAddress::delRecvAddr($uid, $_POST['aid']);
	if ($del === false) {
		Logger::err('Del addr failed: ' . RecvAddress::$errMsg);
		return array('errno' => 1);
	}

	return array('errno' => 0);
}

function _checkDistrictValid($districtId)
{
	global $_District, $_City, $_Province;

	if (!isset($_District[$districtId])) { // ������Ч
		return false;
	}

	$addr = $_District[$districtId];
	if (!isset($_City[$addr['city_id']])) { // �м���Ч
		return false;
	}

	$addr['city_name'] = $_City[$addr['city_id']]['name'];

	if (!isset($_Province[$addr['province_id']])) { // ʡ����Ч
		return false;
	}

	$addr['prov_name'] = $_Province[$addr['province_id']];
	$addr['full_name'] = $addr['prov_name'] . $addr['city_name'] . $addr['name'];
	return $addr;
}

// End Of Script