<?php
require_once(PHPLIB_ROOT . 'api/distribution/IBPreOrder.php');
Logger::init();

function page_borderdetail_page(){
	$uid = ToolUtil::checkLoginOrRedirect();
	$order_id = intval($_GET['order_char_id']);
	$detail = IBPreOrder::getOneOrderDetail($uid, $order_id);
	//Logger::info(var_export($detail,true));
	if($detail['subOrderNum'] > 0)
	{
		// �𵥶�������ʾ����ҳ����ת���ҵĶ���ҳ�档
		ToolUtil::redirect("http://base.51buy.com/bmanageorder.html");
		exit();
	}

	if($detail === false){
		Logger::err('IBPreOrder::getOneOrderDetail failed-' . IBPreOrder::$errCode . '-' . IBPreOrder::$errMsg);
		ToolUtil::redirect("http://base.51buy.com/bmanageorder.html");
	}

	if( !isset($detail['order_char_id'])){
		ToolUtil::redirect("http://base.51buy.com/bmanageorder.html");
	}

	$wh_id = 1; //Ĭ��Ϊ�Ϻ�վ
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'cssFile'	=> 'http://st.icson.com/static_v1/css/mycenter/myorder_detail.css?v=20120815001',
		'titleDesc' => '������������'
	));
	$TPL->set_var('pageName', '<a href="http://base.51buy.com/myorder.html">�����б�</a> > ��������');
	$TPL->set_file(array(
		'contentHandler' => 'b_orderdetail.tpl'
	));

	$TPL->set_block('contentHandler', 'item_list', 't_item_list');
	$TPL->set_var('t_item_list');

	$order_flow = '';
	$_status = "";

	global $_OrderState;
	foreach ($_OrderState as $item){
		if($item['value'] == $detail['status'] ) {
			$_status = $item['desc'];
		}
	}
	$siteId = $detail['hw_id'];

	//֧����ʽ
	$payInfo = ToolUtil::getPayTypeInfo($detail['pay_type'], $siteId); //֧����ʽ
	$PayTypeName = false === $payInfo ? "" : $payInfo['PayTypeName'];
	//���ͷ�ʽ
	$shippingInfo = ToolUtil::getShipTypeInfo($detail['shipping_type'], $siteId );
	$shipping_type = false === $shippingInfo ? "" : $shippingInfo["ShipTypeName"];
	$receiver_mobile = trim( ToolUtil::transXSSContent( $detail['receiver_mobile'] ) );
	$receiver_tel =   trim( ToolUtil::transXSSContent( $detail['receiver_tel'] ) );
	$receiver_mobile = $receiver_mobile . ( !empty($receiver_mobile) && !empty($receiver_tel)? '��' : '') . $receiver_tel;

	$param = array(
		'order_char_id' => $detail['order_char_id'],
		'order_id' => $detail['order_id'],
		'receiver' => ToolUtil::transXSSContent( $detail['receiver'] ),
		'receiver_addr' => ToolUtil::transXSSContent( $detail['receiver_addr'] ),
		'receiver_mobile' => $receiver_mobile,
		'pay_type' => $PayTypeName, //֧����ʽ
		'shipping_type' => $shipping_type, //���ͷ�ʽ
		'expect_dly_date' => ( $detail['shipping_type'] == 1 ) ? '����������ʱ�䣺'. ( empty($detail['expect_dly_date'] ) ? '' : $detail['expect_dly_date'] ). ' '. ( empty($detail['expect_dly_time_span']) ? '' : $detail['expect_dly_time_span'] ) . '��' : '', //��������ʱ��
		'order_cost' => sprintf("%.2f", $detail['order_cost'] / 100),  //�����ܼ�
		'shipping_cost' => sprintf("%.2f", $detail['shipping_cost'] / 100),  //�˷�
		'products_cost' => sprintf("%.2f", ( $detail['order_cost'] - $detail['shipping_cost'] ) / 100), //��Ʒ�ܼ�
		'point_pay' => '', //���ֵֿ�
		'price_cut' => '', //�����Ż�
		'promotion_coupon' => '',
		'cash' => sprintf("%.2f", $detail['cash'] / 100), //�ϼ�
		'prcdfee_str' => empty($detail['prcd_cost']) ? '' : ('<li><span class="l">֧�������ѣ�</span><span class="r">&yen;' . sprintf("%.2f", $detail['prcd_cost'] / 100) . '</span></li>'), //�ϼ�
		'order_desc' => $detail['comment'] != '' ? '<p><span>������ע��</span>' . ToolUtil::transXSSContent( $detail['comment'] ) .'</p>' : '',	 //��ע
		'remain_payment_time' => '', //ʣ�ึ���ʱ��
	);

    $isShoppingGuid = false;
    $retailer = IRetailer::getRetailers(array('uid' => $uid));
    if ($retailer && 1 == $retailer[0]['isShoppingGuide'] && $detail['shop_guide_id']!=0 )
    {
        	$isShoppingGuid = true;
        	$param['distribution_total'] = '<li class="all nopad"><span>�����ܼƣ�</span><span class="txt_price"><span class="yen">&yen;</span>'. 
        	                       sprintf("%.2f", $detail['shop_guide_cost'] / 100) .'</span></li>';
    }
    else 
    {
        $param['distribution_total'] = '';
    }
    $retailer = current($retailer);   
    $TPL->set_var($param);
   
   //��Ʊ��Ϣ

   $invoice = IUser::getUserInvoice($uid,$retailer['invoiceId']);
   if (false === $invoice || 0 === count($invoice))
   {
       Logger::err('IUser::getUserInvoice() fail- ' . $uid . ' ' . $retailer['invoiceId']);
   }
   $invoice = current($invoice);
   //@//@Logger::debug($invoice);
   if(!empty($invoice))
   {
		$isVat = $invoice['type'] == INVOICE_TYPE_VAT;
	    $invoice_explanation_phone = '021-61831107';
		$param = array(
			'invoice_title' => ToolUtil::transXSSContent( $invoice['name']),
			'invoice_type' => _getInvoiceType($invoice['type']),
			'invoice_content' => ToolUtil::transXSSContent( $invoice['content'] ),
			'invoice_name' =>  $isVat ? '<dd class="con"><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>��˾���ƣ�' . ToolUtil::transXSSContent( $invoice['name'] ) . '</dd>' : '',
			'invoice_addr' => $isVat ? '<dd class="con"><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>��˾��ַ��' .ToolUtil::transXSSContent( $invoice['addr'] ) . '</dd>' : '',
			'invoice_phone' => $isVat ? '<dd class="con"><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>��˾�绰��' .ToolUtil::transXSSContent( $invoice['phone'] ) . '</dd>' : '',
			'invoice_taxno' => $isVat ? '<dd class="con"><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>˰�ţ�' .ToolUtil::transXSSContent( $invoice['taxno'] ) . '</dd>' : '',
			'invoice_bankno' => $isVat ? '<dd class="con"><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>�����˺ţ�' .ToolUtil::transXSSContent( $invoice['bankno'] ) . '</dd>' : '',
			'invoice_explanation' => $isVat ? '<dd class="con strong">��ʾ�����״ο�����ֵ˰ר�÷�Ʊ�Ŀͻ���Ӫҵִ�ա�˰��Ǽ�֤������һ����˰���ʸ�֤�顢��������֤������ '.$invoice_explanation_phone.'</dd>' : '',
		);
   }
	else
	{
		$param = array(
			'invoice_title' => '',
			'invoice_type' => '',
			'invoice_content' => '',
			'invoice_name' => '',
			'invoice_addr' => '',
			'invoice_phone' => '',
			'invoice_taxno' => '',
			'invoice_bankno' => '',
			'invoice_explanation' => ''
		);
	}
	$TPL->set_var($param);

	global $_CP_Sp_Data;
	$hasCard = false;

	//������Ʒ
	$linkIds = array();
	$product_other = '';
	if( isset($detail['items'])  && count($detail['items']) > 0 )
	{
		foreach( $detail['items'] as $item)
		{
			
			$url = "<a href='http://item.51buy.com/productdetail-".$item['product_id'].".html' target='_blank'>".$item['name']."</a>";
			$param = array(
				'product_id' => $item['product_id'],
				'product_name' =>  $item['name'],
				'package_info' => '',
				'product_price' => sprintf("%.2f", $item['price']/100),
				'cash_back' => sprintf("%.2f", $item['cash_back']/100),
				'product_weight' => $item['weight'],
				'buy_num' => $item['buy_num'],
				'weight_total' => $item['weight'] * $item['buy_num'],
				'price_total' => sprintf("%.2f", $item['price'] * $item['buy_num'] / 100),
				'warranty' => $item['warranty'], //����
				'product_other' => $product_other,
				'php_url'	=> $url
			);

			//����
			$param['product_gift'] = '';
			if( isset($item['gift']) && count( $item['gift'] ) > 0 ){
				$param['product_gift'] = '<p class="gift_wrap">';
				$wrap = '';
				foreach($item['gift'] as $gift){
					$param['weight_total'] += $gift['weight'] * $gift['buy_num'];
					$param['product_gift'] .= ( $wrap . '<span class="gift">['. $gift['product_type'] .']</span>' . $gift['name'] );
					$wrap = '<br/>';
				}
				$param['product_gift'] .= '</p>';
			}

			array_push($linkIds, $item['product_id']);
			$TPL->set_var($param);
			$TPL->parse('t_item_list', 'item_list', true);
			$TPL->unset_var($param);
		}
	}
	else
	{
		$TPL->set_var('t_item_list', '');
	}

	$html_customerInfo = '';
	//����C�ͻ���Ϣ
	if (isset($detail['customerInfo']))
	{
$html_customerInfo = <<<HTML
  <h4>�ͻ���Ϣ</h4>
  <div class="order_detail">
     <table class="table_order_detail">
           <thead>
               <tr>
                   <th width="15%">����</th>
                   <th width="15%">�ֻ�</th>
                   <th width="15%">�绰</th>
                   <th width="15%">Q Q</th>
                   <th width="40%">��ַ</th>
               </tr>
          </thead>
          <tbody>
                     <tr>
                        <td><p>{$detail['customerInfo']['name']}</p></td>
                        <td><p>{$detail['customerInfo']['mobile']}</p></td>
                        <td><p>{$detail['customerInfo']['phone']}</p></td>
                        <td><p>{$detail['customerInfo']['qq']}</p></td>
                        <td><p>{$detail['customerInfo']['address']}</p></td>
                     </tr>
          </tbody>
      </table>
   </div>
HTML;
	}
	$TPL->set_var('html_customerInfo',$html_customerInfo);
	
	//��Ҫ��������Ҫ����
	_getBtn($detail, $TPL, join(',' , array_reverse($linkIds )));

	$TPL->parse('content', 'contentHandler');
	$TPL->out();

}

function _getInvoiceType($type)
{
            if ($type == INVOICE_TYPE_RETAIL_COMPANY)
            {
                return "��ҵ���۷�Ʊ(��λ)";
            }
            else if ($type == INVOICE_TYPE_VAT)
            {
                return "��ֵ˰רҵ��Ʊ";
            }
            else if ($type == INVOICE_TYPE_VAT_NORMAL)
            {
                return "��ֵ˰��ͨ��Ʊ";
            }
            else if ($type == INVOICE_TYPE_CP_UNICOM)
            {
                return "��ͨͳһ��Ʊ";
            }
            else if ($type == INVOICE_TYPE_CP_TELCOM)
            {
                return "����ͳһ��Ʊ";
            }
            else if ($type == INVOICE_TYPE_CP_MOBILE)
            {
                return "�ƶ�ͳһ��Ʊ";
            }
            else if ($type == INVOICE_TYPE_TITLE)
            {
                return "������Ʊ";
            }
            else 
            {
                return "��ҵ���۷�Ʊ(����)";
            }
}

function _getBtn($detail, $TPL, $linkIds) {
	$order_id = $detail['order_char_id'];
	$status_str = '';
	global $_OrderState, $_PAY_MODE;
	switch($detail['status']) {
		//�����
		case $_OrderState['Origin']['value']:
			$status_str = "�����";
			break;
		case $_OrderState['WaitingOutStock']['value']:
			$status_str = "���ͨ��";
			break;

		//��ͨ��-1
		case $_OrderState['EmployeeCancel']['value']:
				$status_str = "��˲�ͨ��";
		      	break;
		default:
			Logger::err('order status is exception - ' . $detail['status']);
	}

	$TPL->set_var('orderdetail_order_status', $status_str);
}

