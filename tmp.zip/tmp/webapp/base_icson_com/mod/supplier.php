<?php
require_once(PHPLIB_ROOT . 'api/ISupplier.php');
require_once(PHPLIB_ROOT . 'lib/NetUtil.php');//send mail lib @daopingsun 2013/1/30 12:01
function page_supplier_apply(){
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'cssFile'	=> 'http://st.icson.com/static_v1/css/login/supplier.css?v=20120522001',
		'titleDesc'	=> '������ֱͨ��'
	));
	$TPL->set_file(array(
		"containerHandler"	=> "supplier.tpl"
	));
	$TPL->out();
}

function supplier_add(){
	$supplier = ISupplier::addSupplier($_POST);
	if($supplier === false){
		if(ISupplier::$errCode == 916){
			return array('errno' => 21);
		}

		Logger::err("ISupplier::addSupplier failed, code: " . ISupplier::$errCode . ', msg: ' . ISupplier::$errMsg);
		return array('errno' => 6001);
	}
	//send mail @daopingsun 2013/1/30 12:01
	global $mail_keycode,$mail_url;
	$contactPerson = urlencode($_POST['ContactPerson']);
	$email = urlencode($_POST['Email']);
	$t = 'ContactPerson='.$contactPerson.'&Email='.$email.'&';
	$sign = md5($t.$mail_keycode);
	$post_data = $t.'sign='.$sign;
	
	$postRet =NetUtil::cURLHTTPPost($mail_url,$post_data);

	if(empty($postRet)){
		Logger::err("ISupplier::addSupplier send mail failed ");
	}else{
		$postRet = json_decode($postRet,true);
		if($postRet['err_code'] != 0){
			Logger::err("ISupplier::addSupplier send mail failed, code: " . $postRet['err_code']  . ', msg: ' . $postRet['err_msg']);
		}
	}

	return array('errno' => 0);
}