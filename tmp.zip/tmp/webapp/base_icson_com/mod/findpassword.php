<?php
define('PLATFORM_PATH', PHPLIB_ROOT . 'api/appplatform/');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once('../api/IVerifyUserIdentity.php');
require_once(PLATFORM_PATH . 'platform/web_stub_cntl.php');
require_once(PLATFORM_PATH . 'platform/lang_util.php');
require_once(PLATFORM_PATH . 'usericsonao_stub4php.php');
require_once(PHPLIB_ROOT . 'api/IMessageNew.php');

Logger::init();

define('FINDPASSWORD_KEY', 'findpassword5187a3466ddfd0.62543');

/**
 * �����룺
 * 101 ����ȱʧ���ʺ�����
 * 102 ����ȱʧ���ʺ���
 * 103 ����ȱʧ��У����
 * 104 ��ѯ�ʺ���ʧ��
 * 105 ��֤��sessionʧЧ
 * 106 ��֤�����������ʧ��
 * 107 ��֤�����
 * 108 ��ѯ���ֻ�ʧ��
 * 109 ��ѯ������ʧ��
 * 110 ��ѯ�ʺ���Ϣʧ��
 * 111 δͨ����ȫ��֤�����޿����ֻ�
 * 112 �ް��ֻ�������
 * 
 * 113 ��ȡ��֤�룬��������
 * 114 ��ȡ��֤�룬ȡcode����
 * 115 ��ȡ��֤�룬���Ͷ��ų���
 * 116 ��ȡ�������ӣ���������
 * 117 ��ȡ�������ӣ��ֻ������û������
 * 118 ��ȡ���������쳣������ȫ�ʺ����������
 * 119 ��ȡ���������쳣���ް��ʺ�ȴʹ���ʺŸ���
 * 120 ��ȡ���������쳣���ް�����ȴʹ���������
 * 121 ��ȡ�������ӣ��ֻ���֤�벻��ȷ
 * 122 ��ȡ�������ӣ��������û������
 * 123 ��ȡckʧ��
 * 124 ���͸����ʼ�ʧ��
 * 
 * 125 ���ܣ���������
 * 126 ���ܣ�ck����ȷ
 * 127 �ظ���������벻һ��
 * 128 ����ʧ��
 * 
 * 129 �ֻ���ʽ����
 * 130 �����ʽ����
 * 131 ���Ͷ���Ƶ�ʳ���
 * 132 ��ѯ����ʧ��
 * 133 ������;�����һ��
 * 134 ����Ѹ�ʺ�
 * 135 ʱ���ʧЧ
 * 136 ���Ͷ��ţ��ֻ��ź�uid��һ��
 * 137 ���Ͷ���Ƶ�ʳ��ޣ����ʷ���ʧ�ܣ�
 */

/**
 * �޸�����������һ����������
 * @param Template $TPL
 */
function page_findpassword_modify(){
	//����У��
	$uid = empty($_GET['uid']) ? '' : $_GET['uid'];
	$ck = empty($_GET['ck']) ? '' : $_GET['ck'];
	$type = empty($_GET['type']) ? '' : $_GET['type'];
	$key = empty($_GET['key']) ? '' : $_GET['key'];
	$account = empty($_GET['account']) ? '' : $_GET['account'];
	
	if(!$uid || !is_numeric($uid)){
		return TemplateHelper::outMessage('��������', 'error');
	}
	if(!$ck || !$type || !$key){
		return TemplateHelper::outMessage('��������', 'error');
	}
	
	$check_ck = getFindCK($uid);
	if($check_ck !== $ck){
		$htmlContent = '<p>����������ʧЧ���������Ѿ��޸Ĺ������ˡ�</p><p>��ֱ����������<a href="http://base.51buy.com">��¼</a>';
		$htmlContent .= ' ���� <a href="http://base.51buy.com/findpassword_find.html">�����һ�����</a></p>';
		return TemplateHelper::outMessage($htmlContent, 'error');
	}
	
	//xss
	$uid = htmlspecialchars($uid, ENT_QUOTES);
	$ck = htmlspecialchars($ck, ENT_QUOTES);
	$type = htmlspecialchars($type, ENT_QUOTES);
	$key = htmlspecialchars($key, ENT_QUOTES);
	
	$userInfo = IUser::getUserInfo($uid);
	if(!$userInfo){
		return TemplateHelper::outMessage('��ѯ�û�����', 'error');
	}
	$account = $userInfo['icsonid'];
	
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
			'includeFile' => '<!--#include virtual="/sinclude/cssi/login/find_password.html"-->',
			'headerStyle' => 'register'
	));
	$TPL->set_file(array(
			"containerHandler"	=> "findpassword_step3.tpl"
	));
	
	$TPL->set_var('uid', $uid);
	$TPL->set_var('account', $account);
	$TPL->set_var('ck', $ck);
	$TPL->set_var('type', $type);
	$TPL->set_var('key', $key);
	
	$TPL->out();
}

/**
 * �һ����룺��һ������д��¼�ʺ�
 * @param Template $TPL
 */
function page_findpassword_find(){
	//ɾ��base�µ�verifysession������������ͻ
	setcookie('verifysession', 0, time()-3600);
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'includeFile' => '<!--#include virtual="/sinclude/cssi/login/find_password.html"-->',
		'headerStyle' => 'register'
	));
	$TPL->set_file(array(
		"containerHandler"	=> "findpassword_step1.tpl"
	));
	
	$TPL->out();
}

/**
 * �һ����룺�ڶ�����ѡ���һط�ʽ
 * 
 */
function page_findpassword_sendresetemail()
{
	//����У��
	Logger::info("get: " . var_export($_GET, true));
	$uid = empty($_GET['uid']) ? 0 : $_GET['uid'];
	$key = empty($_GET['key']) ? '' : $_GET['key'];
	$stamp = empty($_GET['stamp']) ? '' : $_GET['stamp'];
	if(!$uid || !is_numeric($uid)){
		return TemplateHelper::outMessage('��������', 'error');
	}

	if(!$key){
		return TemplateHelper::outMessage('��������', 'error');
	}
	if(findDecrypt($key) !== $uid){
		return TemplateHelper::outMessage('�û���������', 'error');
	}
	if(!$stamp || $stamp !== getStamp($uid)){
		return TemplateHelper::outMessage('����ʧЧ����ӵ�һ����ʼ�һ�����', 'error');
	}
	
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
			'includeFile' => '<!--#include virtual="/sinclude/cssi/login/find_password.html"-->',
			'headerStyle' => 'register'
	));
	$TPL->set_file(array(
			"containerHandler"	=> "findpassword_step2.tpl"
	));
	
	//��ѯ�û���Ϣ
	$userInfo = IUser::getUserInfo($uid);
	if(!$userInfo){
		return TemplateHelper::outMessage('��ѯ�û�����', 'error');
	}
	//Logger::info('user info: ' . var_export($userInfo, true));
	
	$TPL->set_var('uid', $uid);
	$account = $userInfo['icsonid'];
	$TPL->set_var('account', $account);
	$mobile = '';
	$email = '';
	if(!empty($userInfo['mobile']) && !empty($userInfo['bindMobile'])){
		$mobile = $userInfo['mobile'];
	}
	if(!empty($userInfo['email']) && !empty($userInfo['bindEmail'])){
		$email = $userInfo['email'];
	}
	
	$need_verify = false;
	$mobile_list = array();
	$userVerifyRet = IVerifyUserIdentity::verifyUserIdenty(intval($uid), 1000, $userInfo['point']);
	//Logger::info("verifyUserIdenty Ret = ". print_r($userVerifyRet, true));
	if($userVerifyRet)
	{
		$userVerifyRet = json_decode($userVerifyRet, true);
		//������
		if(1 == $userVerifyRet['need_verify'])
		{
			$need_verify = true;
			if(empty($mobile)){
				$mobile_list = $userVerifyRet['trusted_mobile_list'];
			}
			else{
				$mobile_list[] = $mobile;
			}
		}
	}
	
	//��ȡ�����䡢�ֻ����ܡ����Ǻ�
	$enc_mobile = '';
	$enc_mobile_list = array();
	if($need_verify){
		if(!empty($mobile_list)){
			$enc_mobile_list = array_map('findEncrypt', $mobile_list);
			$mobile_list = array_map('asteriskMobile', $mobile_list);
		}
	}
	else{
		if($mobile){
			$enc_mobile = findEncrypt($mobile);
			$mobile = asteriskMobile($mobile);
		}
	}
	$print_info = array('false', 'true');
	$enc_email = '';
	if($email){
		$enc_email = findEncrypt($email);
		$email = asteriskEmail($email);
	}
	
	$TPL->set_var('need_verify', $need_verify);
	
	$stamp = htmlspecialchars($stamp, ENT_QUOTES);
	$TPL->set_var('stamp', $stamp);
	//��ʾ
	$TPL->set_var('mobile_radio', '');
	$TPL->set_var('email_radio', '');
	$TPL->set_var('hidden_mobile', $mobile);
	$TPL->set_var('hidden_email', $email);
	$TPL->set_var('enc_mobile', $enc_mobile);
	$TPL->set_var('enc_email', $enc_email);
	$TPL->set_var('display_check_mobile', 'none');
	if(!$need_verify){
		$TPL->set_var('display_select', 'block');
		if($mobile){
			$TPL->set_var('select_type', '�ֻ����룺');
			$TPL->set_var('select_value', $mobile);
			$TPL->set_var('check_hint', '��֤���ֻ�');
			$TPL->set_var('display_check_mobile', 'block');
			if(!$email){
				$TPL->set_var('mobile_radio', '<span class="co_orange">�Ѱ��ֻ�</span>');
			}
			else{
				$TPL->set_var('mobile_radio', '<input id="mobile" name="select" value="mobile" type="radio" checked = "checked"/><label for="phone">����֤�ֻ�</label>');
				$TPL->set_var('email_radio', '<input id="email" name="select" value="email" type="radio" /><label for="email">����֤����</label>');
			}
		}
		else{
			if($email){
				$TPL->set_var('email_radio', '<span class="co_orange">�Ѱ�����</span>');
				$TPL->set_var('select_type', '�����ַ��');
				$TPL->set_var('select_value', $email);
				$TPL->set_var('check_hint', '��֤������');
			}
			else{
				return TemplateHelper::outMessage('�ް���Ϣ', 'error');
			}
		}
	}
	//�а�ȫ����
	else{
		$TPL->set_var('display_select', 'none');
		if(empty($mobile_list)){
			return TemplateHelper::outMessage('��ȫ���գ��ް���Ϣ', 'error');
		}
		else{
			//��ѡ������
			$content = '<select name="mobile_list" id="mobile_list">';
			foreach($mobile_list as $i => $m){
				$content .= '<option value="' . $enc_mobile_list[$i] . '">' . $m . '</option>';
			}
			$content .= '</select>';
			$TPL->set_var('mobile_radio', $content);
			
			$TPL->set_var('check_hint', '��֤���ֻ�');
			$TPL->set_var('display_check_mobile', 'block');
		}
	}

	$TPL->out();
}

/**
 * �һ����룺���Ĳ������ܳɹ�
 */
function page_findpassword_changepwdok()
{
	$uid = empty($_GET['uid']) ? 0 : $_GET['uid'];
	if(!$uid || !is_numeric($uid)){
		return TemplateHelper::outMessage('��������', 'error');
	}
	
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
			'includeFile' => '<!--#include virtual="/sinclude/cssi/login/find_password.html"-->',
			'headerStyle' => 'register'
	));
	$TPL->set_file(array(
			"containerHandler"	=> "findpassword_step4.tpl"
	));	
	
	$userInfo = IUser::getUserInfo($uid);
	if($userInfo === false){
		return TemplateHelper::outMessage('��ѯ�û�����');
	}
	if(!empty($userInfo['mobile']) && !empty($userInfo['bindMobile'])){
		$mobile = $userInfo['mobile'];
	}
	if(empty($mobile)){
		$showBindHint = 'block';
		$showBindHint2 = 'none';
	}
	else{
		$showBindHint = 'none';
		$showBindHint2 = 'block';
	}
	$TPL->set_var('showBindHint', $showBindHint);
	$TPL->set_var('showBindHint2', $showBindHint2);
	
	$TPL->out();
}

/**
 * �һ����룺��ʾ�û������������ 
 */
function page_findpassword_emailfeedback()
{
	$email = empty($_GET['email']) ? '' : $_GET['email'];
	$uid = empty($_GET['uid']) ? '' :$_GET['uid'];
	$key = empty($_GET['key']) ? '' : $_GET['key'];
	$stamp = empty($_GET['stamp']) ? '' : $_GET['stamp'];
	
	if(!$uid || !is_numeric($uid)){
		return TemplateHelper::outMessage('��������', 'error');
	}
	if(!$email){
		return TemplateHelper::outMessage('��������', 'error');
	}
	if(!$key){
		return TemplateHelper::outMessage('��������', 'error');
	}
	if(!$stamp || $stamp !== getStamp($uid)){
		return TemplateHelper::outMessage('����ʧЧ����ӵ�һ����ʼ�һ�����', 'error');
	}
	
	$uid = htmlspecialchars($uid, ENT_QUOTES);
	$email = htmlspecialchars($email, ENT_QUOTES);
	$key = htmlspecialchars($key, ENT_QUOTES);
	$stamp = htmlspecialchars($stamp, ENT_QUOTES);
	
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
			'includeFile' => '<!--#include virtual="/sinclude/cssi/login/find_password.html"-->',
			'headerStyle' => 'register'
	));
	$TPL->set_file(array(
			"containerHandler"	=> "findpassword_emailfeedback.tpl"
	));
	
	$TPL->set_var('uid', $uid);
	$TPL->set_var('key', $key);
	$TPL->set_var('email', $email);
	$TPL->set_var('stamp', $stamp);
	$link = getEmailLink($email);
	$TPL->set_var('email_link', $link);
	
	$TPL->out();
}

/**
 * ���������
 */
function findpassword_checkpwd()
{
	$ret = checkPwd();
	header('Content-Type: application/json');
	echo json_encode($ret);
	exit;	
}

function checkPwd()
{
	$uid = empty($_POST['uid']) ? 0 : $_POST['uid'];
	$ck = empty($_POST['ck']) ? '' : $_POST['ck'];
	$pwd1 = empty($_POST['password1']) ? '' : $_POST['password1'];
	$pwd2 = empty($_POST['password2']) ? '' : $_POST['password2'];
	$type = empty($_POST['type']) ? '' : $_POST['type'];
	$key = empty($_POST['key']) ? '' : $_POST['key'];
	if(!$uid || !$ck || !$pwd1 || !$pwd2 || !$type || !$key){
		return array('errno' => 125);
	}
	$check_ck = getFindCK($uid);
	if($check_ck !== $ck){
		return array('errno' => 126);
	}
	
	$userInfo = IUser::getUserInfo($uid);
	if($userInfo === false){
		return array('errno' => 110);
	}
	if($pwd1 !== $pwd2){
		return array('errno' => 127);
	}
	$account = $userInfo['icsonid'];
	
	//��֤������;������Ƿ���ͬ�������ͬ����ʾ�û�
	$item = IUser::_getTTCInfo('IUserPassTTC', $uid);
	if($item === false || count($item) == 0){
		return array('errno' => 132);
	}
	Logger::info('new=' . $pwd1 . ', ' . md5($pwd1) . ', old=' . $item[0]['password'] . ', updatetime=' . $item[0]['updatetime']);
	if($item[0]['password'] === md5($pwd1)){
		return array('errno' => 133);
	}
	
	$modify = IUser::modifyPswWithoutOldPsw($uid, $pwd1);
	if($modify === false){
		Logger::err("IUser::modifyPswWithoutOldPsw failed, code: " . IUser::$errCode . ', msg: ' . IUser::$errMsg);
		return array('errno' => 128);
	}
	
	//test
	$ret = IUserPassTTC::update(array('uid' => $uid, 'updatetime' => time()));
	if($ret === false){
		Logger::err('Update pwd updatetime failed, code=' . IUserPassTTC::$errCode . ', msg: ' . IUserPassTTC::$errMsg);
	}
	
	if($type === 'mobile'){
		$mobile = $key;
		$ret = IMessageNew::sendSMS($uid, 102, 3, 10042, array($account, $account), $mobile) ;
		if($ret === false){
			$errno = 115;
			Logger::err('Send SMS failed, code=' . IMessageNew::$errCode . ', msg=' . IMessageNew::$errMsg);
		}
		Logger::info('change password ok, mobile: ' . $mobile);
	}
	else if($type === 'email'){
		$sendEmail = IMessageNew::sendEmail($uid ,102, 3, 11058, array($account), $email, 0);
		if($sendEmail === false){
			$errno = 124;
			Logger::err('Send email failed, code=' . IMessageNew::$errCode . ', msg=' . IMessageNew::$errMsg);
		}
		Logger::info("change password ok, email: " . $key);
	}
	
	return array('errno' => 0);
}

/**
 * �����û������ȡ�����½��ַ
 */
function getEmailLink($email)
{
	if(empty($email)){
		return '';
	}
	$start = strrpos($email, '@');
	$end = strrpos($email, '.');
	if($start === false || $end === false || $start >= $end){
		return '';
	}
	$start += 1;
	$tag = substr($email, $start, $end-$start);
	$tag_map = array(
		'163' => 'http://mail.163.com/',
		'126' => 'http://mail.126.com/',
		'sina' => 'http://mail.sina.com.cn/',
		'yahoo' => 'http://mail.cn.yahoo.com/',
		'sohu' => 'http://mail.sohu.com/',
		'yeah' => 'http://www.yeah.net/',
		'gmail' => 'http://gmail.google.com/',
		'hotmail' => 'http://www.hotmail.com/',
		'live' => 'http://www.hotmail.com/',
		'qq' => 'https://mail.qq.com/'
	);
	if(array_key_exists($tag, $tag_map)){
		return $tag_map[$tag];
	}
	else{
		return '';
	}
}

/**
 * ��֤�û����룬���ɸ�������
 */
function findpassword_getmodifyurl()
{
		$errno = 0;
		$url = '';
		$message = '';
		
		Logger::info('post: ' . print_r($_POST, true));
		$selectType = empty($_POST['selectType']) ? '' : $_POST['selectType'];
		$uid = empty($_POST['uid']) ?��: $_POST['uid'];
		$inputMobile = empty($_POST['mobile']) ? '' : $_POST['mobile'];
		$inputEmail = empty($_POST['email']) ? '' : $_POST['email'];
		$code = empty($_POST['code']) ? '' : $_POST['code'];
		$encFlag = empty($_POST['encFlag']) ? false : $_POST['encFlag'];
		$stamp = empty($_POST['stamp']) ? false : $_POST['stamp'];
		
		if(!$uid || !is_numeric($uid)){
			$errno = 116;
		}
		else if(!$stamp || $stamp !== getStamp($uid)){
			$errno = 135;
		}
		else if(!$selectType  || !in_array($selectType, array('mobile', 'email'))){
			$errno = 116;
		}
		else if($selectType === 'mobile' && (!$inputMobile || !$code)){
			$errno = 116;
		}
		else if($selectType === 'email' && !$inputEmail){
			$errno = 116;
		}
		else{
			$userInfo = IUser::getUserInfo($uid);
			if(!$userInfo){
				$errno = 110;
			}
			else{
				$account = $userInfo['icsonid'];
				//��ȡ�û���Ϣ�������������֤
				$mobile = '';
				$email = '';
				if(!empty($userInfo['mobile']) && !empty($userInfo['bindMobile'])){
					$mobile = $userInfo['mobile'];
				}
				if(!empty($userInfo['email']) && !empty($userInfo['bindEmail'])){
					$email = $userInfo['email'];
				}
				$need_verify = false;
				$mobile_list = array();
				$userVerifyRet = IVerifyUserIdentity::verifyUserIdenty(intval($uid), 1000, $userInfo['point']);
				Logger::info("verifyUserIdenty Ret = ". print_r($userVerifyRet, true));
				if($userVerifyRet)
				{
					$userVerifyRet = json_decode($userVerifyRet, true);
					if(1 == $userVerifyRet['need_verify'])
					{
						$need_verify = true;
						if(empty($mobile)){
							$mobile_list = $userVerifyRet['trusted_mobile_list'];
						}
						else{
							$mobile_list[] = $mobile;
						}
					}
				}
				
				//�ֻ�����
				if($selectType === 'mobile'){
					if($encFlag){
						$inputMobile = findDecrypt($inputMobile);
					}
					if(ToolUtil::checkMobilePhone($inputMobile) === false){
						$errno = 129;
					}
					else if($need_verify){
						if(!$mobile && !$mobile_list){
							$errno = 119;
						}
						else if($mobile && $mobile !== $inputMobile){
							$errno = 117;
						}
						else if(!in_array($inputMobile, $mobile_list)){
							$errno = 117;
						}
					}
					else{
						if(!$mobile){
							$errno = 120;
						}
						else if($mobile !== $inputMobile){
							$errno = 117;
						}
					}
					if($errno === 0){
						$ret = IVerify::checkMobileVerifyCode($uid, $code, $inputMobile);
						if($ret === false){
							$errno = 121;
						}
					}
				}
				//�������
				else if($selectType === 'email'){
					if($need_verify){
						$errrno = 118;
					}
					else if(!$email){
						$errno = 120;
					}
					else{
						if($encFlag){
							$inputEmail = findDecrypt($inputEmail);
						}
						if($email !== $inputEmail){
							Logger::info("email=$email, input=$inputEmail");
							$errno = 122;
						}
					}
				}
			}
		}
		
		Logger::info("errno=$errno");
		if($errno === 0){
			$ck = getFindCK($uid);
			if($ck === false){
				$errno = 123;
			}
			else{
				if($selectType === 'mobile'){
					$url = "http://base.51buy.com/index.php?mod=findpassword&act=modify&uid=$uid&ck=$ck&type=$selectType&key=$inputMobile";
					Logger::info("findpassword, mobile: $mobile, url: $url");
				}
				else{
					$link = "http://base.51buy.com/index.php?mod=findpassword&act=modify&uid=$uid&ck=$ck&type=$selectType&key=$inputEmail";

					$sendEmail = IMessageNew::sendEmail($uid ,102, 2, 11057, array($account, $link), $email, 0);
					if($sendEmail === false){
						$errno = 124;
						Logger::err('Send email failed, email=' . $email . 'code=' . IMessageNew::$errCode . ', msg=' . IMessageNew::$errMsg);
					}
					Logger::info("findpassword, email: $email, link: $link");
					$key = findEncrypt($email);
					$email = asteriskEmail($email);
					$stamp = getStamp($uid);
					$url = "http://base.51buy.com/findpassword_emailfeedback.html?uid=$uid&email=$email&key=$key&stamp=$stamp";
				}
			}
		}
		
		$ret = json_encode(array('errno' => $errno, 'url' => $url));
		Logger::info('ret=' . var_export($ret, true));
		header('Content-Type: application/json');
		echo $ret;
		exit;
}

/**
 * ���ɸ���ck, �����ϴθ���ʱ��
 * type: mobile\email
 */
function getFindCK($uid)
{
	if(empty($uid)){
		return false;
	}
	$item = IUser::_getTTCInfo('IUserPassTTC', $uid);
	if($item === false){
		Logger::err("IUser::_getTTCInfo('IUserPassTTC', $uid) failed");
		return false;
	}
	else if(count($item) === 0){
		return false;
	}
	else{
		$item = $item[0];
		$updatetime = $item['updatetime'];
		$ret = md5(strtoupper(md5($updatetime . $uid) . FIND_BACK_OP_KEY));
		return $ret;
	}
}

/**
 * ��ȡ���ܺ��ʱ���
 */
function getStamp($uid)
{
	if(empty($uid)){
		return false;
	}
	$item = IUser::_getTTCInfo('IUserPassTTC', $uid);
	if($item === false){
		Logger::err("IUser::_getTTCInfo('IUserPassTTC', $uid) failed");
		return false;
	}
	else if(count($item) === 0){
		return false;
	}
	else{
		$item = $item[0];
		$updatetime = $item['updatetime'];
		$ret = md5(strtoupper(md5($updatetime . 'updatetime') . FIND_BACK_OP_KEY));
		return $ret;
	}
}

/**
 * ��ȡ�ֻ���֤��
 */
function findpassword_getmobilecode()
{
	$errno = 0;
	$code = 0;
	
	$uid = empty($_POST['uid']) ? 0 : $_POST['uid'];
	$inputMobile = empty($_POST['mobile']) ? '' : $_POST['mobile'];
	//����
	$inputMobile = findDecrypt($inputMobile);
	if(!$uid || !$inputMobile || !is_numeric($uid)){
		$errno = 113;
	}
	else if(ToolUtil::checkMobilePhone($inputMobile) === false){
		$errno = 129;
	}
	else{
		$userInfo = IUser::getUserInfo($uid);
		if(!$userInfo){
			$errno = 110;
		}
		else{
			$account = $userInfo['icsonid'];
			//��ȡ�û���Ϣ�������������֤
			$mobile = '';
			if(!empty($userInfo['mobile']) && !empty($userInfo['bindMobile'])){
				$mobile = $userInfo['mobile'];
			}
			$need_verify = false;
			$mobile_list = array();
			$userVerifyRet = IVerifyUserIdentity::verifyUserIdenty(intval($uid), 1000, $userInfo['point']);
			//Logger::info("verifyUserIdenty Ret = ". print_r($userVerifyRet, true));
			if($userVerifyRet)
			{
				$userVerifyRet = json_decode($userVerifyRet, true);
				if(1 == $userVerifyRet['need_verify'])
				{
					$need_verify = true;
					if(empty($mobile)){
						$mobile_list = $userVerifyRet['trusted_mobile_list'];
					}
					else{
						$mobile_list[] = $mobile;
					}
				}
			}
			if($need_verify){
				if(!$mobile && !$mobile_list){
					$errno = 119;
				}
				else if($mobile && $mobile !== $inputMobile){
					$errno = 117;
				}
				else if(!in_array($inputMobile, $mobile_list)){
					$errno = 117;
				}
			}
			else{
				if(!$mobile){
					$errno = 120;
				}
				else if($mobile !== $inputMobile){
					$errno = 117;
				}
			}
		}
	}

	if($errno === 0){
		// Ƶ������
		$ret = IFreqLimit::checkAndAdd(substr($mobile, 2), 17);
		Logger::info('mobile=' . $mobile . ', ret=' . $ret);
		if($ret > 0){
			$errno = 131;
		}
		else if($ret <0 ){
			Logger::err('Freq limit failed: ' . IFreqLimit::$errMsg);
			$errno = 137;
		}
		else{
			$code = IVerify::getMobileVerifyCode($uid, $mobile);
			if($code === false){
				$errno = 114;
			}
	
			$ret = IMessageNew::sendSMS($uid, 102, 2, 10041, array($account, $code), $mobile);
			if($ret === false){
				$errno = 115;
				Logger::err('Send SMS failed, code=' . IMessageNew::$errCode . ', msg=' . IMessageNew::$errMsg);
			}
			Logger::info("Send SMS ok, mobile:  $mobile, code: $code");
		}
	}
	
	//Logger::info("get code, errno: $errno");
	header('Content-Type: application/json');
	echo json_encode(array('errno' => $errno));
	exit;
}

/**
 * ��ȡ��֤��
 */
function findpassword_vcode() 
{
	$clientIp = ToolUtil::getClientIP();
	header('Content-type:image/jpeg');
	global $_IP_CFG;
	for($i = 0; $i < 2; $i++) {
		$ret = get_verify_code(VERIFY_CODE_APPID, $_IP_CFG['verify_code']['code_server'][0]['IP'], $_IP_CFG['verify_code']['code_server'][0]['PORT'], $_IP_CFG['verify_code']['code_server'][1]['IP'], $_IP_CFG['verify_code']['code_server'][1]['PORT'], $clientIp);
		if($ret !== false) {
			setcookie("findpassword_verifysession", $ret['sig'], 0, '/', '.51buy.com');
			echo $ret['img'];
			break;
		}
	}
	exit;
}

/**
 * ��֤��һ��������
 * @return json��ʽ������
 */
function findpassword_verifyinput()
{
	$ret = verifyInput();
	//Logger::info('verifyinput ret: ' . print_r($ret, true));
	header('Content-Type: application/json');
	echo json_encode($ret);
	exit;
}

function verifyInput()
{	
	if(!isset($_POST['checkType'])){
		return array('errno' => 101);
	}

	$checkType = $_POST['checkType'];
	$account = empty($_POST['account']) ? '' : $_POST['account'];
	if(!$account){
		return array('errno' => 102);
	}
	$vcode = empty($_POST['vcode']) ? '' : $_POST['vcode'];
	if(!$vcode){
		return array('errno' => 103);
	}
	

	$ret =verifyVCode($vcode);
	if($ret !== 0){
		return array('errno' => $ret);
	}
	
	//��ȡuid
	$uid = 0;
	//���ݰ󶨵��ֻ��Ż��������
	if($checkType == 2){
		if(is_numeric($account)){
			//global $_MobileStat;
			//$item = IUser::_getTTCInfo('ITelLoginTTC', $account, array('status' => $_MobileStat['bound']));
			$item = IUser::getTelLoginByMobile($account);
			if($item === false || count($item) == 0){
				Logger::err('Get user by tel failed, errCode=' . IUser::$errCode . ', errMsg=' . IUser::$errMsg);
				return array('errno' => 108);
			}
			$item = $item[0];
			$uid = $item['uid'];
		}
		else{
			//global $_EmailStat;
			//$item = IUser::_getTTCInfo('IEmailLoginTTC', $account, array('status' =>$_EmailStat['bound']));
			$item = IUser::getEmailLoginByEmail($account);
			if($item === false || count($item) == 0){
				Logger::err('IEmailLoginTTC failed, errCode=' . IUser::$errCode . ', errMsg=' . IUser::$errMsg);
				return array('errno' => 109);
			}
			$item = $item[0];
			$uid = $item['uid'];
		}
	}
	else{
		/*
		$ret = IUser::_getTTCInfo('IIcsonLoginTTC', $account);
		if($ret === false || count($ret) != 1){
			Logger::err('IIcsonLoginTTC failed, ' . var_export($ret, true) . ', errCode=' . IUser::$errCode . ', errMsg=' . IUser::$errMsg);
			return array('errno' => 104);
		}
		*/
		$item = IUser::getUserInfoByAccount($account);
		if($item === false || count($item) === 0){
			Logger::err('Get user by account failed, ' . IUser::$errCode . ': ' .  IUser::$errMsg);
			return array('errno' => 104);
		}
		$uid =$item[0]['uid'];
	}
	
	$userInfo = IUser::getUserInfo($uid);
	if(!$userInfo){
		Logger::err('Get user info failed: ' . IUser::$errCode, ', ' . IUser::$errMsg);
		return array('errno' => 110);
	}
	//Logger::info('user info: ' . print_r($userInfo, true));
	
	$icsonid = $userInfo['icsonid'];
	if(stripos($icsonid, QQ_ACCOUNT_PRE) === 0
	|| stripos($icsonid, ALIPAY_ACCOUNT_PRE) === 0
	|| stripos($icsonid, SHAUTO_ACCOUNT_PRE) === 0){
		return array('errno' => 134);
	}
	$mobile_list = array();
	$email = '';
	if(!empty($userInfo['mobile']) && !empty($userInfo['bindMobile'])){
		$mobile_list[] = $userInfo['mobile'];
	}
	if(!empty($userInfo['email']) && !empty($userInfo['bindEmail'])){
		$email = $userInfo['email'];
	}
	
	$need_verify = false;
	$userVerifyRet = IVerifyUserIdentity::verifyUserIdenty(intval($uid), 1000, $userInfo['point']);
	//Logger::info("verifyUserIdenty Ret = ". print_r($userVerifyRet, true));
	if($userVerifyRet)
	{
		$userVerifyRet = json_decode($userVerifyRet, true);
		if(1 == $userVerifyRet['need_verify'])
		{
			$need_verify = true;
			if(empty($mobile_list)){
				$mobile_list = $userVerifyRet['trusted_mobile_list'];
			}
		}
	}
	
	//�ж��Ƿ������ת�ڶ���
	if($need_verify){
		if(empty($mobile_list)){
			return array('errno' => 111);
		}
	}
	else{
		if(empty($mobile_list) && !$email){
			return array('errno' => 112);
		}
	}

	$key = findEncrypt($uid);
	$stamp = getStamp($uid);
	return array('errno' => 0, 'uid' => $uid, 'key'=> $key, 'stamp' => $stamp);
}

/**
 * У���˻��İ�ȫ��
 * @param array $userInfo
 * @return boolean
 */
function verfyUser($userInfo)
{
	$userIP = ToolUtil::getClientIP();
	$request=array(
			"scene_id"=>10,
			"time"=>time(),
			"user_id"=> $userInfo["uid"],
			"ip"=>$userIP,
			"vk"=>$_COOKIE["visitkey"],
			"wireless"=>0,
			"total_point"=>$userInfo["point"],     // ������������λ���� ABC
			"deal_id"=>0,           // Ĭ�� A
			"name"=>"",         // �ռ������� A
			"address"=>array(),            // �ռ��˵�ַ A
			"mobile"=>"",
			"total_fee"=>0,     // ������ ��λ�� A
			"point_pay"=>0      // ʹ�û��ָ���
	);
	$req=json_encode($request);
	$net = Config::getIP('VERIFY_IDENTITY');
	if(!$net)
	{
		Logger::err('Config::getIP failed: ' . print_r($net,true));
		return false;
	}
	if($userInfo["uid"]%2==0)
	{
		$ip = $net[0]["IP"];
		$port = $net[0]["PORT"];
	}
	else
	{
		$ip = $net[1]["IP"];
		$port = $net[1]["PORT"];
	}

	$response=NetUtil::udpCmd($ip, $port, $req);
	return $response;
}

/**
 * ��֤У����
 * @return string
 */
function verifyVCode($vcode)
{
	if(!isset($_COOKIE['verifysession'])) {
		return 105;
	}
	else{
		$verifysession = $_COOKIE['verifysession'];
		//Logger::info('verifysession=' . $verifysession);
		global $_IP_CFG;
		$clientIp = ToolUtil::getClientIP();
		$ret = check_verify_code(VERIFY_CODE_APPID, $_IP_CFG['verify_code']['check_server'][0]['IP'], $_IP_CFG['verify_code']['check_server'][0]['PORT'], $_IP_CFG['verify_code']['check_server'][1]['IP'], $_IP_CFG['verify_code']['check_server'][1]['PORT'], $clientIp, $vcode, $verifysession);
		//Logger::info("��֤��: $vcode, ��֤���: $ret");
		if($ret === false) {
			Logger::err("��֤�����[ ret : $ret ]");
			return 107;
		}
	}
	return 0;
}

/**
 * ���ֻ��ż��Ǻ�
 */
function asteriskMobile($mobile)
{
	if(!empty($mobile)){
		$pattern = "/(1\d{2})\d{4}(\d{4})/";
		$replacement = "\$1****\$2";
		return preg_replace($pattern, $replacement, $mobile);
	}
	else{
		return '';
	}
}

/**
 * �������ַ���Ǻ�
 * ���������ַ������ĸʱ��ʾ�������м�*�����Ϊ5��
 */
function asteriskEmail($email)
{
	$emailParts = explode('@', $email);
	$lenLimit = 5;
	$len = strlen($emailParts[0]) - 2;
	if($len<=0){
		return '';
	}
	else if($len>$lenLimit){
		$len = $lenLimit;
	}
	$output = substr_replace($emailParts[0], str_repeat('*', $len), 2, $len);
	return $output . '@' . $emailParts[1];
}

/**
 * ��װ�ļ���/���ܺ���
 */
function findEncrypt($src)
{
	if(!empty($src)){
		$key = FINDPASSWORD_KEY;
		return rawurlencode(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $src, MCRYPT_MODE_CBC, md5(md5($key)))));
	}
	else{
		return '';
	}
}
function findDecrypt($src)
{
	if(!empty($src)){
		$src = rawurldecode($src);
		$key = FINDPASSWORD_KEY;
		return rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode($src), MCRYPT_MODE_CBC, md5(md5($key))), "\0");
	}
	else{
		return '';
	}
}

/**
 * ��������������ʼ����ڶ���
 * @param Template $TPL
 */
function page_findpassword_sendresetemail_old(){
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'cssFile'	=> 'http://st.icson.com/static_v1/css/login/password.css'
	));
	$TPL->set_file(array(
		"containerHandler"	=> "findpassword_step2.tpl"
	));

	$message = '';
	$messageType = 'warn';
	if(empty($_POST['email'])){
		$message = '������Email��ַ';
	} else if(empty($_POST['email2'])){
		$message = '���ظ�����Email��ַ';
	} else {
		$email = $_POST['email'];
		$email2 = $_POST['email2'];
		if(!ToolUtil::checkEmail($email)){
			$message = 'Email��ַ���������������д';
		} else if($email != $email2){
			$message = '����Email��ַ���벻һ��';
		} else {
			$findBack = IUser::findBack($email);
			if($findBack === false){
				if(IUser::$errCode == 29){
					$message = 'û���ʺŰ󶨸�����';
				} else {
					Logger::err('IUser::findBack faild, code:' . IUser::$errCode . ', msg:' . IUser::$errMsg);
					$message = 'ϵͳ��æ�����Ժ�����';
				}
			} else {
				//�������������֤,��Ҫ��url��ȡ��uid��Ȼ����֤�û���ȫ��Ϣ
				preg_match('/.+uid=(\d+).+/i', $findBack, $uid);
				$uid = intval($uid[1]);
				$userInfo = IUser::getUserInfo($uid);
				$cashPoint = $userInfo["point"];
				$isSendEmail = true;
				//Logger::info("findpass uid:".$uid.",cash point:".$cashPoint);
				if(0 < $cashPoint)
				{
					$userVerifyRet = IVerifyUserIdentity::verifyUserIdenty(intval($uid), 1000, $cashPoint);
					//Logger::info("verifyUserIdenty Ret = ".$userVerifyRet);
					if($userVerifyRet)
					{
						$userVerifyRet = json_decode($userVerifyRet, true);
						//Logger::info("page_findpassword_sendresetemail uid:".$uid." userVerifyRet".print_r($userVerifyRet, true));
						if(1 == $userVerifyRet['need_verify'])
						{
							$isSendEmail = false;
							$message = '�����ʺ�������ܱ�й©��Ϊ�������ʺŰ�ȫ�����޷��һ����룬����ϵ�ͷ�400-828-6699���д�����';
						}
					}
				}
				if($isSendEmail)
				{
					Logger::info("Find back password email:".$findBack);
					$sendEmail = IMessage::sendEmail($email, "�һ�����", $findBack);
					if($sendEmail === false){
						Logger::err('IUser::findBack faild, code:' . IUser::$errCode . ', msg:' . IUser::$errMsg);
						$message = '�������������ʼ�ʧ��';
					} else {
						$messageType = 'right';
						$message = '�����ѷ��������޸���Ϣ���������䣺' . htmlspecialchars($email) . '������ 2 ���ڵ�¼����ע����������ʼ�����������޸ġ�';
					}
				}
			}
		}
	}
	$TPL->set_var('password_message_type', $messageType);
	$TPL->set_var("password_message", $message);
	$TPL->out();
}

function findpassword_reset(){
	if(empty($_POST['uid'])){
		return array('errno' => 500);
	}

	$uid = $_POST['uid'];

	if(empty($_POST['icsonid'])){
		return array('errno' => 501);
	}
	$user = IUser::getUserInfo($uid);
	if($user === false){
		Logger::err(IUser::$errMsg);
		return array('errno' => 6002);
	}

	if($user['icsonid'] != $_POST['icsonid']){
		return array('errno' => 15);
	}

	if(empty($_POST['newpassword'])){
		return array('errno' => 12);
	}

	if(empty($_POST['newpassword2'])){
		return array('errno' => 13);
	}

	if($_POST['newpassword'] != $_POST['newpassword2']){
		return array('errno' => 14);
	}

	if(empty($_POST['ck'])){
		return array('errno' => 16);
	}
	$checkCK = IUser::checkFindBackCK(1, $_POST['uid'], $_POST['ck']);
	if($checkCK === false){
		return array('errno' => 16);
	}

	$newPass = $_POST['newpassword'];
	$modify = IUser::modifyPswWithoutOldPsw($uid, $newPass);
	if($modify === false){
		Logger::err("IUser::modifyPswWithoutOldPsw failed, code: " . IUser::$errCode . ', msg: ' . IUser::$errMsg);
		return array('errno' => 6001);
	}

	return array('errno' => 0);
}
