<?php
/**
 * ����ҵ�ͻ���ɫͨ����ģ��
 */
require_once(PHPLIB_ROOT . 'api/ICompanyUser.php');
require_once(PHPLIB_ROOT. 'api/IAdSystem.php');
require_once(BASE_WEB_ROOT . 'inc/CPSTools.php');
Logger::init();

//չʾҳ��
function page_greenchannel_company(){
	$TPL = TemplateHelper::getBaseTPL(BaseTPL::NO_LEFT_NAV, '', array(
		'cssFile'	=> 'http://st.icson.com/static_v1/css/icson/com_customer_v2.css',
		'titleDesc'	=> '��ҵ�ͻ���ɫͨ��',
	));
	$TPL->set_file(array(
		"containerHandler"    => "greenchannel_company_v2.tpl",
	));

	$whId = IUser::getSiteId();
	$ads = array();
	try {
		$ads = IAdSystem::getAdByPosition($whId, '8ge-yewei');
	}
	catch(Exception $e) {
	}

	$ads_html = '';
	foreach($ads as $ads_item) {
		$ads_html .= ' <li><a href="' . $ads_item['url'] . '" target="_blank"><img src="' . $ads_item['img_wide'] . '" alt="" /></a></li>';
	}
	$TPL->set_var('ads', $ads_html);
	$TPL->out();
}

//��ȡ�û���Ϣ
function greenchannel_getuserinfo() {
	if (!isset($_GET['uid'])) {
		return array('error' => -1);
	}
	else {
		$param_uid = intval($_GET['uid']);
		if ($param_uid <= 0) {
			return array('error' => -2);
		}
	}

	$uid = IUser::getLoginUid();
	if ($uid <= 0) {
		return array('error' => -1);
	}
	else if ($uid != $param_uid) {
		return array('error' => -2);
	}

	$user_info = IUser::getUserInfo($uid);
	if (!$user_info) {
		Logger::err("get user info err errCode:".IUser::$errCode." errMsg:".IUser::$errMsg);
		return array('error' => -3);
	}
	else {
		return array('nick' => $user_info['nick'], 'icsonid' => $user_info['icsonid'], 't' => $user_info['type'] == 8 ? true : false);
	}
}

function greenchannel_industry() {
	global $crm_args, $crm_key, $crm_industry_url, $crm_company_scale_url;
	$sign = CPSTools::genSig($crm_args,$crm_key);
	$str = '';
	foreach($crm_args as $key => $arg) {
		$str .= $key . '=' . $arg . '&';
	}
	$str .= 'sign=' . $sign;
	$industry = json_decode(NetUtil::cURLHTTPGet($crm_industry_url . '?' . $str), true);
	if(!$industry) {
		return json_encode(array('error' => -10));
	}
	$scale = json_decode(NetUtil::cURLHTTPGet($crm_company_scale_url . '?' . $str), true);
	if(!$scale) {
		return json_encode(array('error' => -11));
	}
	return json_encode(array('industry' => $industry, 'scale' => $scale));
}

//AJAX POST������������
function greenchannel_addcompany() {
	$uid = IUser::getLoginUid();
	if ($uid <= 0) {
		return array('error' => -1);
	}

	$whId = IUser::getSiteId();
	$company = ICompanyUser::addCompany($_POST, $whId); //ICompanyUser::checkCompanyInfo ���POST��Ϣ

	if ($company === false) {
		Logger::err("ICompanyUser::addCompany failed, code: " . ICompanyUser::$errCode . ', msg: ' . ICompanyUser::$errMsg);
		return array('errno' => ICompanyUser::$errCode, 'data'=>ICompanyUser::$errMsg);
	}
	return array('errno' => 0, 'data'=>$_POST);
}