<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/TTC.php');
require_once(PHPLIB_ROOT . 'lib/TTC2.php');
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/AppAccountAction.php');

Logger::init();

function login_page(){
	if(!isset($_POST['account']) || !isset($_POST['password'])){
		return array('errno' => 1);
	}

	$clientIp = ToolUtil::getClientIP();
	
	if( 0 === strpos($_POST['account'], QQ_ACCOUNT_PRE ) || 0 === strpos($_POST['account'], ALIPAY_ACCOUNT_PRE ) ){
		return array('errno' => 67);
	}

	// ���ֻ��˼���֤����֤
	if(!ToolUtil::is_mobile()) {
		
		// �жϰ�����
		require_once BASE_WEB_ROOT . 'inc/white_list.php';
		if(!in_array($_POST['account'], $white_users)) {
			if(!isset($_POST['vcode'])){
				return array('errno' => 1);
			}
			if(!isset($_COOKIE['verifysession'])) {
				return array('errno' => 2);
			}
			global $_IP_CFG;
			/*for($i = 0; $i < 5; $i++) {
				$ret = check_verify_code(VERIFY_CODE_APPID, $_IP_CFG['verify_code']['check_server'][0]['IP'], $_IP_CFG['verify_code']['check_server'][0]['PORT'], $_IP_CFG['verify_code']['check_server'][1]['IP'], $_IP_CFG['verify_code']['check_server'][1]['PORT'], $clientIp, $_POST['vcode'], $_COOKIE['verifysession']);
				if($ret === true) {
					break;
				} else if($ret === false) {
					return array('errno' => 101);
				}
			}
			if($i == 5) {
				// ��֤�������ͨѶ���󣬺�����֤��
				Logger::err("������֤�������ʧ�ܣ�[ ret : $ret ]");
				return array('errno' => 102);
			}*/
			$ret = check_verify_code(VERIFY_CODE_APPID, $_IP_CFG['verify_code']['check_server'][0]['IP'], $_IP_CFG['verify_code']['check_server'][0]['PORT'], $_IP_CFG['verify_code']['check_server'][1]['IP'], $_IP_CFG['verify_code']['check_server'][1]['PORT'], $clientIp, $_POST['vcode'], $_COOKIE['verifysession']);
			if($ret === false) {
				Logger::err("������֤�������ʧ�ܣ�[ ret : $ret ]");
				return array('errno' => 101);
			}
		}
	}else {
		//��¼�����������߶�,�Ե�¼IP����Ƶ������
		$result = IFreqLimit::checkByIP($clientIp, 'UserLoginFail');
	
		if ($result > 0){
			Logger::INFO('[IFreqLimit][checkByIP][forbid] , code: ' . IFreqLimit::$errCode . ', msg: ' . IFreqLimit::$errMsg . ', IP: ' . $clientIp);
			return array('errno' => 66);
		} else if ($result < 0){
			Logger::ERR('[IFreqLimit][checkByIP][error] , code: ' . IFreqLimit::$errCode . ', msg: ' . IFreqLimit::$errMsg . ', IP: ' . $clientIp);
		} else {
			Logger::INFO('[IFreqLimit][checkByIP][suc], code: ' . IFreqLimit::$errCode . ', msg: ' . IFreqLimit::$errMsg . ', IP: ' . $clientIp);
		}
		
		$session = IUser::wlogin($_POST['account'], $_POST['password'], $clientIp, 1);
		if($session === false){
			Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
			
			if(IUser::$errCode === 66 || IUser::$errCode === 67){
				$result = IFreqLimit::addByStrKey($clientIp, 'UserLoginFail');
				if ($result < 0){
					Logger::ERR('[IFreqLimit][addByStrKey][user][fail], code: ' . IFreqLimit::$errCode . ', msg: ' . IFreqLimit::$errMsg . ', IP: ' . $clientIp);
				}else {
					Logger::INFO('[IFreqLimit][addByStrKey][user][suc], code, code: ' . IFreqLimit::$errCode . ', msg: ' . IFreqLimit::$errMsg . ', IP: ' . $clientIp);
				}
			}
			return array('errno' => empty(IUser::$errCode) ? 6001 : IUser::$errCode);
		}
	
		$user = IUser::getUserInfo($session['uid']);
		if($user === false){
			Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
			return array('errno' => empty(IUser::$errCode) ? 6001 : IUser::$errCode);
		}
	
		//android app : wap������дcookie��������
		if( isset( $_POST['from'] ) && $_POST['from'] === "app" ){
			$token = md5( $session['uid'] . APP_LOGIN_RENEWAL_KEY );
			$deviceType = 0;
			if(isset($_COOKIE["version"])){
				//��¼�����¼�Ŀͻ��˰汾��iosδ���ð汾
				$deviceType = 100;
				Logger::err("login.php::from 51buy App version:" . $_COOKIE["version"] ." login");
			} else {
				$deviceType = 200;
			}
			
			AppAccountAction::insertOrUpdate(array(
				'FUserID' =>  $session['uid'],
				'FDeviceType' =>  $deviceType,
				'FLastLoginTime' => time()
			));
	
			//Ŀǰandroidͨ��json��õ�¼��Ϣ��iosͨ��cookie��ȡ��¼��Ϣ
			setrawcookie("uid", $session['uid'], 0, '/', '.51buy.com');
			setrawcookie("skey", $session['skey'], 0, '/', '.51buy.com');
// 			setrawcookie("wg_skey", $session['wg_skey'], 0, '/', '.51buy.com');
			setrawcookie("token", $token , 0, '/', '.51buy.com');
			return array('errno' => 0, "data" => array($session['uid'], $session['skey'], $token, $session['wg_skey']));
		}
		
		setrawcookie("uid", $session['uid'], 0, '/', '.51buy.com');
		setrawcookie("skey", $session['skey'], 0, '/', '.51buy.com');
// 		setrawcookie("wg_skey", $session['wg_skey'], 0, '/', '.51buy.com');
		setrawcookie("BOUND_QQACCT", isset($user['cqq']) ? $user['cqq'] : '0', 0, '/', '.51buy.com');
		
		return array('errno' => 0);
	}
	
	$session = IUser::login($_POST['account'], $_POST['password'], $clientIp, 1);
	if($session === false){
		Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return array('errno' => empty(IUser::$errCode) ? 6001 : IUser::$errCode);
	}

	$user = IUser::getUserInfo($session['uid']);
	if($user === false){
		Logger::err("IUser::login failed-" . IUser::$errCode . '-' . IUser::$errMsg);
		return array('errno' => empty(IUser::$errCode) ? 6001 : IUser::$errCode);
	}
	//�ϱ���¼
	_registerReport(4, $session['uid'], $_POST['account']);
	_registerReport(6, $session['uid'], $_POST['account']);
	
	setrawcookie("uid", $session['uid'], 0, '/', '.51buy.com');
	setrawcookie("yx_uid", $session['uid'], time() + 3600*24*600, '/', '.51buy.com');
	setrawcookie("skey", $session['skey'], 0, '/', '.51buy.com');
	if(!empty($session['wg_skey'])){
		setrawcookie("wg_skey", $session['wg_skey'], 0, '/', '.51buy.com');
	}
	
	setrawcookie("BOUND_QQACCT", isset($user['cqq']) ? $user['cqq'] : '0', 0, '/', '.51buy.com');
	//��¼��־
	//setrawcookie("login_history", "51buy", 0, '/', '51buy.com');
	return array('errno' => 0, 'hint' => $session['hint']);
}

/**
 * 1. ����ע�����
 * 2. �ύע��
 * 3. �����¼����
 * 4. �ύ��¼
 * 5. ��ȡ��֤��
 * 6. �ύ��֤��
 * $_IP_CFG['USER_REGISTER_REPORT'] =  array(
			array('IP' => '10.191.8.44', 'PORT' => 59891),
			array('IP' => '10.191.8.44', 'PORT' => 59891)
	);
 */
function _registerReport($type, $uid=0, $account=0)
{
    $userIP = ToolUtil::getClientIP();
    $visitKey = isset($_COOKIE["visitkey"]) ? $_COOKIE["visitkey"] : "";
    $verifysession = isset($_COOKIE["verifysession"]) ? $_COOKIE["verifysession"] : "";
    $report = array(
                "user_id"=> $uid,
                "account"=> $account,
                "log_type"=>$type,
                "time" => time(),
                "verifysession" => $verifysession,
                "visitkey"=> $visitKey,
                "ip"=>$userIP
            );
    $req = json_encode($report);
    $address = Config::getIP('USER_REGISTER_REPORT');
    if(!$address)
    {
        Logger::err("_registerReport Get Ip Error:".print_r($address,true));
    }
    //�������ʵ��������ȷ��
    $ip = $address[0]["IP"];
    $port = $address[0]["PORT"];
    $resp = NetUtil::udpCmd($ip, $port, $req, false);
    if($resp === false)
    {
        Logger::err("_registerReport Send Msg Error");
    }
    return;
}

// End Of Script