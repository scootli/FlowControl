<?php
require_once(PHPLIB_ROOT . 'lib/ToolUtil.php');
require_once(PHPLIB_ROOT . 'lib/Logger.php');
require_once(PHPLIB_ROOT . 'lib/Template.php');
require_once(PHPLIB_ROOT . 'api/ISearch.php');
require_once(PHPLIB_ROOT . 'api/distribution/IBProduct.php');
require_once 'bmanageproduct.php';

define('NO_LIMIT_TYPE' , 0);      //0 �� ������
define('ONLY_PRICE_TYPE' , 1);    //1 ��������ɵ���Ʒ
define('PRICE_PUBLISH_TYPE' , 2);  //2 ������������ѷ�������Ʒ
define('DELETE_PRODUCT' , 1); 
define('SHELVEDOWN_PRODUCT' , 2); 
define('TOP_PRODUCT' , 3); 
Logger::init();
/**
 * page - ��ʼ���۷�������
 */
function page_bpricingpublish_page()
{
	/**
	 * ��ʼ��ѯ���������ʾΪ��
	 * ֱ�����tpl
	 */
	page_bpricingpublish_search();
}

/**
 * page - ���ݲ�ѯ�����ѡƷ��ѯ���ҳ��
 */
function page_bpricingpublish_search()
{
	$uid = ToolUtil::checkLoginOrRedirect();
	$TPL = TemplateHelper::getBaseTPL(0,'b_pricing_publish', array(
		'titleDesc' => '���۷���'
	));

	$TPL->set_file(array(
		'contentHandler' => 'b_pricing_publish.tpl'
	));
	$pageSize = 24;
	$TPL->set_var('php_class1',ToolUtil::gbJsonEncode(IBProduct::getCategory(1, 0)));
	$currentPage = empty($_GET['page'])? 1 : ( $_GET['page'] + 0 );
	$TPL->set_var('pageName','���۷���');
	$TPL->set_var('list_filter', '');
	$TPL->set_block("contentHandler", 'list', 't_list');
	
	$product_conditon = array();
	empty( $_GET['productNo'] ) ? null : $product_conditon['productNo'] = iconv('utf-8','gb2312',urldecode($_GET['productNo']));
	empty( $_GET['category1'] ) ? null : $product_conditon['category1'] = $_GET['category1'];
	empty( $_GET['category2'] ) ? null : $product_conditon['category2'] = $_GET['category2'];
	empty( $_GET['category3'] ) ? null : $product_conditon['category3'] = $_GET['category3'];
	if (isset($_GET['shelveState']))
	{
		(intval( $_GET['shelveState'] ) == 2) ? null : $product_conditon['shelveState'] = $_GET['shelveState'];
	}
	if (isset($_GET['topState']))
	{
		(intval( $_GET['topState'] ) == 2) ? null :$product_conditon['topState'] =  $_GET['topState'];
	}
	if (isset($_GET['priceingState']))
	{
		(intval( $_GET['priceingState']) == 2) ? null : $product_conditon['priceingState'] = $_GET['priceingState'];
	}
	$input = array(
		'retailerId' => $uid,
	    'stock' => (!isset( $_GET['stockState'] )) ? 2 : $_GET['stockState']);
	$product_data = IBProduct::getProductsByRetailer($input,$product_conditon,
													 $currentPage,$pageSize);
	//return TemplateHelper::outMessage('������' .$product_conditon['priceingState'] . '  ' );
	if( false === $product_data)
	{
		Logger::err("IBProduct::getPage failed-" . IBProduct::$errCode . '-' . IBProduct::$errMsg);
		return TemplateHelper::outMessage('ϵͳæ�����Ժ�����');
	}
	$productCount =  $product_data['totalNum'] + 0;
	if (0 == $productCount)
	{
		$TPL->set_var('t_list', '<tr><td colspan="10"><p class="kong">'.'��ǰ�޷��ϲ�ѯ����Ʒ' .'</p></td></tr>');
		$TPL->set_var('pagehtml', '');
		$TPL->set_var('data_json','0');
		recover_search_item($TPL ,$product_conditon,$input['stock']);
		$TPL->parse('content', 'contentHandler');
		$TPL->out();
	}
	$data = array();
	$category = array();
	global $_StockTips; 
	include BASE_WEB_ROOT . 'inc/constant_web.inc.php';
	$pids = array();
	foreach ($product_data['list'] AS $product)
	{
		array_push($pids, $product['productId']);
	}
	/**������ȡ�����۸���Ϣ*/
	$price_att = IBProduct::getProductDistributionPrice($uid,$pids);
   /**������ȡ��Ʒ������Ϣ*/
    $products_info = IProduct::getProductsInfo($pids);
        if (false === $products_info) 
        {
            self::$errCode = IProductCommonInfoTTC::$errCode;
            self::$errMsg =  basename(__FILE__, '.php') . " |" . __LINE__ . '[get IProductCommonInfoTTC failed]' . IProductCommonInfoTTC::$errMsg;
            return false;
        }
	$all_data = array();
	foreach ($product_data['list'] as $index => $item)
	{
	    if (!isset($products_info[$item['productId']])) 
        {
           continue;
        }
		$data['product_id'] = $item['productId'];
		$data['pic'] = IProduct::getPic($item['productNo']) ;
		$data['product_url'] = "http://item.51buy.com/productdetail-". $item['productId'] . ".html";		
		$data['priceing_state'] = $_priceing_state[$item['priceingState']];
		$data['top_state'] = $_top_state[$item['topState']];
		$data['shelve_state'] = $_shelve_state[$item['shelveState']];
		$data['category'] = IBProduct::getCategoryInfo($item['category3']);
		$info = $products_info[$item['productId']];
		$data['name'] = $info['name'];
		$data['stock'] =  ($info['stock'] == $_StockTips['not_available'] ) ? '�޻�' : '�л�';
		$data['product_char_id'] = $info['product_char_id'] ;
		isset($price_att[$item['productId']])? ($price = $price_att[$item['productId']]):($price = 0);
		$data['price'] = isset($price_att[$item['productId']])? IBProduct::convertToString($price_att[$item['productId']]) :'δ����' ;
		$data['pricing_button_list'] = get_init_pricing_button_list($item,$data['price']);
		$data['sailprice'] = IBProduct::convertToString(IBProduct::calculateSailPrice($price,$item['priceType'],$item['addPrice']));
		$data['product_desc'] = $info['promotion_word'] ;
		$data['price_type'] = $item['priceType'];
		$data['add_price'] = $item['addPrice'];
		unset($info);
		$TPL->set_var($data);
		$TPL->parse('t_list', 'list', true);
		array_push($all_data,$data);
	}
	$TPL->set_var('data_json',ToolUtil::gbJsonEncode($all_data));
	unset($all_data);
	/**
	 * �ָ������� 
	 */
	recover_search_item($TPL ,$product_conditon, $input['stock']);
	
	unset($data);
	if (($currentPage-1) * $pageSize +1 > $productCount)
	{
		$currentPage = $productCount/$pageSize;
	}
	
	$product_conditon['stockState'] = (!isset( $_GET['stockState'] )) ? 2 : $_GET['stockState'];
	$TPL->set_var('pagehtml', 
		'<div class="paginator">' .
		 ToolUtil::getpageHTML(TemplateHelper::getProductURL($product_conditon), $currentPage, ceil( intval($productCount) / $pageSize ))  . '</div>');
	
	$TPL->parse('content', 'contentHandler');
	$TPL->out();
}


/**
 * json - �������¼���Ʒҳ��
 */
function bpricingpublish_publishpage()
{
	$uid = ToolUtil::checkLoginOrRedirect();
	$type = (isset($_GET['type']) ? $_GET['type'] : -1);
	$type = intval($type);
	if ((-1 === $type) || (($type != 1) && ($type != 2)))
	{
		Logger::ERR('�������¼����Ͷ�ʧ' );
		return TemplateHelper::outMessage('������,������ʧ');
	}
																
	$products = get_product_info_by_product_ids($uid,$_GET['productids'],$type);
	if (false == $products)
	{
		Logger::ERR('product_id��������' . basename(__FILE__, '.php') . " |" . __LINE__ );
		return array('errno' => 401);
	}

	$select_count = 0;
	$ids = array();

	foreach ($products as $item)
	{
		$ids[$select_count] =  $item['productId'];
		$select_count ++;
	}

	return array(
		'errno' => '0',
		'productids' => join('o',$ids)
	);

}

//ҳ��ˢ�º󣬻ָ�������
function recover_search_item($TPL ,$input, $stockState)
{
	$TPL->set_var('rclass1' , !isset($input['category1']) ? '' : $input['category1']);
	$TPL->set_var('rclass2' , !isset($input['category2']) ? '' : $input['category2']);
	$TPL->set_var('rclass3' , !isset($input['category3']) ? '' : $input['category3']);
	
	foreach (array('shelveState','topState','priceingState') as $i => $key)
	{
		if ((isset($input[$key])) && (strval($input[$key]) != '2'))
		{
			$index = ((strval($input[$key]) === '1')?  '1' : '0');
			$TPL->set_var('r'. $key . $index ,'selected="selected"' );
		}
		else 
		{
			$TPL->set_var('r'. $key . '0' ,'' );
			$TPL->set_var('r'. $key . '1' ,'' );
		}
	}
	if ('2' === strval($stockState)) //δѡ����״̬����
	{	
		$TPL->set_var('rstockState0' ,'' );
		$TPL->set_var('rstockState1' ,'' );
	}
	else 
	{
		$index = ((strval($stockState) === '1')?  '1' : '0');
		$TPL->set_var('rstockState' . $index ,'selected="selected"' );
	}
	
	if ((isset($input['productNo'])) && (strlen($input['productNo']) > 0))
	{
		$TPL->set_var('rproduct_str_id' , ToolUtil::transXSSContent($input['productNo']) );
	}
	else 
	{
		$TPL->set_var('rproduct_str_id' , '');
	}
}

/**
 * ����retailerId��productId ��ȡ�����������Ʒ��Ϣ 
 * type�������ж�
 * 0 �� ������
 * 1 ��������ɵ���Ʒ
 * 2 ������������ѷ�������Ʒ
 */
function get_product_info_by_product_ids($uid,$productIds,$type = NO_LIMIT_TYPE)
{
	$product_ids = $productIds;
	if (!preg_match('/^\d+(o\d+){0,}/', $product_ids))
	{
		Logger::ERR('��ƷID������ʧ' );
		return false;
	}
	$productid_arr = explode('o',$product_ids);
	$products = IBProduct::getProductsByRetailer(array('retailerId'=>$uid,'pids'=>$productid_arr));
	if (false === $products ) 
	{
		Logger::ERR('db error' );
		return false;
	}
	$ret_products = array();
	foreach ($products['list'] as $product)
	{
		if (NO_LIMIT_TYPE === $type)
		{
			array_push($ret_products,$product);
		}
		else if ((ONLY_PRICE_TYPE === $type ) &&
					intval($product['priceingState'])) //���� ��Ҫ�������
		{
			array_push($ret_products,$product);
		}
		else if ((PRICE_PUBLISH_TYPE === $type)  &&
					intval($product['priceingState']) && //�¼� ��Ҫ����������ѷ���
					intval($product['shelveState']))
		{
			array_push($ret_products,$product);
		}		
	}
	
	return $ret_products;
}
/**
 *	�����ö�״̬���ϼ�״̬����button�б� 
 */
function get_init_pricing_button_list($product,$price)
{
	$product_id = $product['productId'];
	$top_state = intval($product['topState']);
	$shelve_state = intval($product['shelveState']);
	$priceing_state = intval($product['priceingState']);
	$str  = '';

	$str .= '<div><span class="tip_wrap">';
	$str .= '<a href="javascript:void(0);" class="todo_link" style="position:relative" onclick="G.app.mycenter.pricingpublish.setupPricePop(this,' .  $product_id . ",'" . $price . "');" . '">����</a> </span>';
	if ($shelve_state) $str .= '</div>';   //����ɾ��Ϊһ��
	switch ($shelve_state)
	{
		case 0: //����״̬����ɾ��  1��ʾ����״̬
				
				$str .= '<span class="tip_wrap"><a href="javascript:void(0);" class="todo_link" style="position:relative"  onclick="G.app.mycenter.pricingpublish.deleteProduct(this,' .  $product_id . ");" . '">ɾ��</a></span></div>';
				$str .= '<div><span class="tip_wrap"><a href="javascript:void(0);"  class="todo_link" style="position:relative" onclick="G.app.mycenter.pricingpublish.shelveUpProduct(this,'  .  $product_id . ",'" . $price . "'," . $priceing_state .");" . '">����</a></span>';
				break;
		case 1: 
				$str .= '<div><span class="tip_wrap"><a href="javascript:void(0);" class="todo_link" style="position:relative" onclick="G.app.mycenter.pricingpublish.shelveDownProduct(this,' .  $product_id . ");" . '">�¼�</a></span>';
				break;
		case 2: break;                       
		default:
			Logger::ERR('product shelveState is wrong');
	}
	
	if (1 === $top_state)
	 	$str .= '<span class="tip_wrap"><a href="javascript:void(0);" class="todo_link" style="position:relative" onclick="G.app.mycenter.pricingpublish.topClearProduct(this,' .  $product_id . ");" . '">&nbspȡ���ö�</a></span></div>';
	else if ((0 === $top_state) &&
		(1 === $shelve_state))
	{
		$str .= '<span class="tip_wrap"><a href="javascript:void(0);" class="todo_link" style="position:relative" onclick="G.app.mycenter.pricingpublish.topUpProduct(this,' .  $product_id . ");" . '">&nbsp�ö�</a></span></div>';
	}
	else $str .='</div>';

	return $str;
}

/**
 *	 ���ö���ҳ��������button�б� 
 */
function get_setup_pricing_button_list($product,$price)
{
	$product_id = $product['productId'];
	$str  = '';
	$str .= '<div><span class="tip_wrap"><a href="javascript:void(0);"  class="todo_link"  style="position:relative" onclick="G.app.mycenter.pricingpublish.setupPricePop(this,' .  $product_id . ',"' . $price .  '");' . '">����</a></span>';
	$str .= '<span class="tip_wrap"><a href="javascript:void(0);"  class="todo_link" style="position:relative" onclick="G.app.mycenter.pricingpublish.deleteCol(this,' .  $product_id . ");" . '">ɾ��</a></span></div>';
	
	return $str;
}


/**
 * json - �ö�ѡƷ
 */
function bpricingpublish_topup()
{
	$time_now = time();
	$sql_arr = array(
		'topState' => 1 ,
		'updateTime'  => $time_now
		);
		
	return check_and_update_product_data($sql_arr ,TOP_PRODUCT);
}

/**
 * json - ȡ���ö�ѡƷ
 */
function bpricingpublish_topclear()
{
	$time_now = time();
	$sql_arr = array(
		'topState' => 0 ,
		'updateTime'  => $time_now
		);
		
	return check_and_update_product_data($sql_arr);
}

/**
 * json - ɾ��ѡƷ
 */
function bpricingpublish_delete()
{
	$uid =  ToolUtil::checkLoginOrRedirect();
	if (0 == $uid)
	{
		return  array('errno' => 500);
	}
	$productid_arr = check_product_ids();
	if (false === $productid_arr ) 
	{
		return  array('errno' => 502);
	}
	
	$result = IBProduct::removeProducts($uid,$productid_arr);
	if (false === $result)
	{
		return false;
	}
	if (is_array($result))
	{
		return  array('errno' => 501,'data' =>$result);
	}
	
	return $result;
}

/**
 * json - ����ѡƷ
 */
function bpricingpublish_shelveup()
{
	$time_now = time();
	$sql_arr = array(
		'shelveState' => 1 ,
		'updateTime'  => $time_now
	);

	return pubulish_product($sql_arr);
}

/**
 * json - �¼�ѡƷ
 */
function bpricingpublish_shelvedown()
{
	$time_now = time();
	$sql_arr = array(
			'shelveState' => 0 ,
			'updateTime'  => $time_now,
			'topState'  => 0
		);
		
	return check_and_update_product_data($sql_arr ,SHELVEDOWN_PRODUCT);
}

/**
 *  json �������ö���
 */
function bpricingpublish_setupprice()
{
	$uid = ToolUtil::checkLoginOrRedirect();
	$time_now = time();
	$input = array('type','value');
	$safe = array();
	foreach ($input as $key)
	{
		$safe[$key] = intval(isset($_POST[$key]) ? $_POST[$key] : -1);
		if (-1 === $safe[$key])
		{
			Logger::ERR('������ʧ' . basename(__FILE__, '.php') . " |" . __LINE__ );
			return false;
		}
	}
	
	if (0 === $safe['type']) $safe['value'] = $safe['value'] * 100;
	$sql_arr = array(
			'priceType' => $safe['type'] ,
			'addPrice' => $safe['value'],
			'priceingState' => 1,
			'updateTime'  => $time_now
		);
		
	return check_and_update_product_data($sql_arr);
}

/**
 *  json �����������ö���
 */
function bpricingpublish_batchsaveprice()
{
    $uid0 = (isset($_POST['uid']) ? $_POST['uid'] : -1);
    $uid = ToolUtil::checkLoginOrRedirect();
    if ($uid0 != $uid) 
    {
        return false;
    }
    
	$time_now = time();
	$pids1 = (isset($_POST['pids1']) ? $_POST['pids1'] : -1);
	if ((-1 != $pids1) && ('' != $pids1) && (null != $pids1) )
	{
		if (!preg_match('/\d+(o\d+){0,}/', $pids1))
		{
		    return false;
		}
	}
	
	$result = false;
	$sql_arr = array(
            'updateTime'  => $time_now,
	        'priceingState' => '1',
            'retailerId'   => $uid
        );
        
	if ((-1 != $pids1) && ('' != $pids1) && (null != $pids1))
    {
	    $type1 = intval(isset($_POST['type1']) ? $_POST['type1'] : -1);
	    if (-1 === $type1)
	    {
	        return false;
	    }
	    $value1 = intval(isset($_POST['value1']) ? $_POST['value1'] : -1);
	    if (-1 === $value1)
	    {
	        return false;
	    }
	    if (0 === $type1) 
	    {
	        $value1 = $value1 * 100;
	    }
        $sql_arr['priceType'] = $type1;
        $sql_arr['addPrice'] = $value1;
        $sql_arr['productIds'] = explode('o',$pids1);
   
    	$result = IBProduct::updateProduct($sql_arr,array());
    } 

	$pids2param = isset($_POST['pids2']) ? $_POST['pids2'] : '';
	if ('' != $pids2param)
	{
		$pids2_arr = explode('o',$pids2param);
		foreach ($pids2_arr AS $product_price)
		{
		   $arr = explode('e',$product_price);
		   if (count($arr) < 3)
		   {
		       return false; //�����Ƿ�
		   }
		   if (intval($arr[1]) > 1 || intval($arr[1]) < 0)
		   {
		       return false ; //�����Ƿ�
		   }
		   $value2 = intval($arr[2]);
		   if (0 === intval($arr[1])) 
		   {
		   	   $value2 = intval($arr[2]) * 100;
		   }
		   
		   $sql_arr['priceType'] = $arr[1];
		   $sql_arr['addPrice'] = $value2;
		   $sql_arr['productIds'] = array($arr[0]);
		   $result = IBProduct::updateProduct($sql_arr,array());
		}
	}

	return $result;
}

/**
 *  json ��ȡ���涨����Ϣ
 */
function bpricingpublish_getsaveprice()
{
	$uid = ToolUtil::checkLoginOrRedirect();
	if (0 === $uid)
	{
		return  array('errno'=> 500);
	}
	$product_id = intval(isset($_GET['sysno']) ? $_GET['sysno'] : -1);
	if (-1 === $product_id)
	{
		return false;
	}
	$result = IBProduct::getProductsByRetailer(array('retailerId'=>$uid,'pids'=>array($product_id)));
	if ((false === $result) || (count($result['list']) <= 0))
	{
		return  array('errno'=> 501);
	}

	$ret_arr = array(
		'priceType' => $result['list'][0]['priceType'],
		'addPrice' => ($result['list'][0]['priceType']=='0') ? intval($result['list'][0]['addPrice']) / 100 : intval($result['list'][0]['addPrice']),
		'errno'	=> '0'
	);
	
	return  $ret_arr;
}

/**
 *  json �������ö��۲�����
 */
function bpricingpublish_pricepublish()
{
	$time_now = time();
	$type = intval(isset($_POST['type']) ? $_POST['type'] : -1);
	if (-1 === $type)
	{
		return false;
	}
	$value = intval(isset($_POST['value']) ? $_POST['value'] : -1);
	if (-1 === $value)
	{
		return false;
	}
	if (0 === $type) $value = $value * 100;
	$sql_arr = array(
			'priceType' => $type ,
			'addPrice' => $value,
			'shelveState' => '1',  //״̬��Ϊ����
			'priceingState' => '1',//����״̬��Ϊ�Ѷ���
			'updateTime'  => $time_now
		);
		
	return pubulish_product($sql_arr);
}

function pubulish_product($condition)
{
	$uid =  ToolUtil::checkLoginOrRedirect();
	if (0 == $uid)
	{
		return  array('errno' => 500);
	}
	$productid_arr = check_product_ids();
	if (false === $productid_arr ) 
	{
		return  array('errno' => 501);
	}
	
	$price = IBProduct::getProductDistributionPrice($uid,$productid_arr);
	/**������ȡ�����Ϣ*/
	$stock = IBProduct::getStockInfo($productid_arr);
	if ((false === $price) || (false ===$stock))
	{
		return  array('errno' => 501);
	}
	global $_StockTips; 
	/**
	 * ɸѡ���ɷ�������Ʒ
	 */
	$array_not_publish = array();  //��¼���ɷ�������Ʒ
	$array_can_publish = $productid_arr;   //��¼�ɷ�������Ʒ
	foreach ($productid_arr as  $product_id)
	{
		if ((!isset($price[$product_id])) ||
			 (!isset($stock[$product_id])) || 
			 ($stock[$product_id] == $_StockTips['not_available'] )
			)
		{
			array_push($array_not_publish,$product_id);
			
			$key = array_search($product_id,$array_can_publish);
			unset($array_can_publish[$key]); 	//ɾ����pid
			continue;
		}
	}
	/**
	 * ����������Ʒ 
	 */
	$result = true;
	if (count($array_can_publish) > 0)
	{
		$condition['retailerId'] = $uid;
		$condition['productIds'] = $array_can_publish;
		$result = IBProduct::
					updateProduct($condition,array());
	}

	if (count($array_not_publish) > 0)
	{
		return array('errno'=> 504,'data' =>$array_not_publish);
	}
	else
   		return $result;
}

/**
 * ������Ʒ״̬��Ϣ
 * ��ȷ����ֵ ���󷵻�false
 * type = 1  delete
 * type = 2  �¼�
 * type = 3  �ö�
 */ 
function check_and_update_product_data($sqlArr ,$type = 0)
{
	$uid =  ToolUtil::checkLoginOrRedirect();
	if (0 == $uid)
	{
		return array('errno'=> 500);
	}
	$productid_arr = check_product_ids();
	if (false === $productid_arr ) 
	{
		return false;
	}
	if (!is_array($sqlArr))
	{
		return false;
	}
	
	$products = IBProduct::getProductsByRetailer(array('retailerId'=>$uid,'pids'=>$productid_arr));
	if (false === $products ) 
	{
		Logger::ERR('db error' );
		return false;
	}
	
	$array_no_shelve = array();  //��¼�����¼ܵ���Ʒ
	foreach ($products['list'] as $product)
	{
		if (SHELVEDOWN_PRODUCT === $type) //�¼�
		{
			if (intval($product['shelveState']) != 1) 
			{
				array_push($array_no_shelve,$product['productNo']);
				$key = array_search($product['productId'],$productid_arr);
				unset($productid_arr[$key]); 	//ɾ����pid
			}
		}
	}
	$result = true;
	if (TOP_PRODUCT === $type) //�ö�
	{//�����ö�״̬����Ҫ�ж��Ƿ񳬹�30���ö��޶�
		$result = IBProduct::
					setTopProduct($sqlArr,$uid,$productid_arr[0]);
	}
	else 
	{
		$sqlArr['retailerId'] = $uid;
		$sqlArr['productIds'] = $productid_arr;
		$result = IBProduct::
					updateProduct($sqlArr,array());
	}

	if (count($array_no_shelve)) 
	{
		return array('errno'=> 502,'data' =>$array_no_shelve);
	}
	
	return $result;
}

/**
 * �ڲ�ʹ�ã������ƷID������
 * ��ȷ����ֵ ���󷵻�false
 */
function check_product_ids( )
{
	$uid0 = (isset($_POST['uid']) ? $_POST['uid'] : -1);
	$uid = ToolUtil::checkLoginOrRedirect();
	if ($uid0 != $uid) 
	{
		return false;
	}
	$product_ids = (isset($_POST['sysno']) ? $_POST['sysno'] : -1);
	if (-1 === $product_ids)
	{
		return false;
	}
	if (!preg_match('/\d+(o\d+){0,}/', $product_ids))
	{
		return false;
	}
	$productid_arr = explode('o',$product_ids);
	return $productid_arr;
}



	
	