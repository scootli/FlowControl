<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/PHPLIB/lib/Config.php");

define("BASE_WEB_ROOT", WEB_ROOT . "base_icson_com/");
define("BASE_PAGE_TPL_DIR", BASE_WEB_ROOT . "tpl/");

require_once(BASE_WEB_ROOT . 'inc/constant_web.inc.php');

// ��� module ��
if (!empty($_REQUEST['mod'])) {
	$mod_name = preg_replace("/[^a-zA-Z]/", '',trim($_REQUEST['mod']));
} else {
	$mod_name = 'main';
}

$mod_file = BASE_WEB_ROOT . 'mod/'.$mod_name.'.php';
if ( !in_array($mod_name, $mod_list, true) || !file_exists($mod_file) ) {
	// ��¼���ʵ� url
	$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
	$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
	Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
	ToolUtil::redirect("http://www.51buy.com/");
}

// ��� act ��
if (!empty($_REQUEST['act'])) {
	$act_name = preg_replace("/[^a-zA-Z]/", '', trim($_REQUEST['act']));
} else {
	$act_name = 'page';
}

// ���html�ĺ���ǰ׺��page_����������json��
$func_name = 'page_' . $mod_name . '_' . $act_name;

require_once $mod_file;
if (!function_exists($func_name)) {
	$func_name = $mod_name . '_page';
	if (!function_exists($func_name)) {
		$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
		$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
		Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
		ToolUtil::redirect("http://www.51buy.com/");
	}
}

require_once(BASE_WEB_ROOT . 'inc/TemplateHelper.php');

ToolUtil::noCacheHeader();
$func_name();