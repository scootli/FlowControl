<?php
/**
 * IVipActivate.class.php
 * @desc         QQ会员激活易迅会员数据存储接口
 * @package
 * @Copyright    (c) 1998-2013 Tencent Inc. All Rights Reserved
 * @Author       icemanwu@tencent.com
 * @Version      1.0.0
 */

/**
 #激活流水的存储格式#
 key:{uid}
 value:{"source":{source},"wg_uid":{wg_uid},"qq":{qq},"state":{state},"act_date":{act_date},"act_timestamp":{act_timestamp},"act_exp_point":{act_exp_point},"act_virtual_exp":{act_virtual_exp},"act_level":{act_level},"act_qqvip_level":{act_qqvip_level},"after_act_virtual_exp":{after_act_virtual_exp}","after_act_level":{after_act_level},formal_date":{formal_date},"formal_timestamp":{formal_timestamp},"formal_need_point":{formal_need_point},"formal_exp_point":{formal_exp_point},"formal_virtual_exp":{formal_virtual_exp},"formal_level":{formal_level},"after_formal_virtual_exp":{after_formal_virtual_exp},"after_formal_level":{after_formal_level},"last_update_time":{last_update_time}}

 #激活名单的存储格式#
 key:{year-month-day-hour-minute}
 value:{uid,uid,...}
 */

//激活流水数据操作类
class IVipActivateFlow {
	public static $errCode = 0;		//错误码
	public static $errMsg = "";		//错误信息

	private static $servers = array();
	private static $bid = ACTIVE_FLOW_BID_NAME;
	private static $tm = NULL;		//tmem操作对象

	/*
	 * 初始化错误信息与tmem句柄
	 * @return 成功:true,失败:false
	 */
	private static function init(){
		//初始化错误码与错误信息
		self::$errCode = 0;
		self::$errMsg  = "";

		//从配置中心获取ip列表
		if(empty(self::$servers)){
			$server_count = configcenter4_get_serv_count(ACTIVE_FLOW_SVR_NAME,0);
			if(empty($server_count) || $server_count == 0){
				self::$errCode = -1;
				self::$errMsg = "get ip and port failed";
				return false;
			}
			for($i=0;$i<$server_count;$i++){
				$ipAndPort = configcenter4_get_serv(ACTIVE_FLOW_SVR_NAME, 0, $i);
				$servers[] = $ipAndPort;
			}
		}
		self::$bid = ACTIVE_FLOW_BID_NAME;
		if(empty(self::$tm)){
			self::$tm = new tmem(0, 1);
			//tmem所有操作失败都返回false，错误码调用errno()查看
			$ret = self::$tm->set_servers($servers, 2000, 2);
			if($ret === false){
				self::$errCode = self::$tm->errno();
				self::$errMsg = "tmem set_servers failed. [servers]:".implode(",", $servers);
				return false;
			}
		}
		
		return true;
	}

	/**
	 * 获取激活流水
	 * @return 失败:false,成功:激活流水，key-value类型的数组
	 */
	public static function get($uid){
		$ret = self::init();
		if($ret === false){
			return false;
		}
		
		//从tmem中获取uid的值
		$flow = @self::$tm->get(self::$bid, $uid);
		if($flow === false){
			self::$errCode = self::$tm->errno();
			self::$errMsg = "tmem get failed. [bid]:". self::$bid ." [key]:$uid";
			return false;
		}

		return json_decode($flow, true);
	}
	
	/**
	 * 设置激活流水，包括add和update
	 * @param $uid 用户uid
	 * @param $flowArray key-value类型的数组
	 * @return 成功:ture,失败:false
	 */
	public static function set($uid, $flowArray){
		$ret = self::init() ;
		if($ret === false){
			return false;
		}
		
		//添加一条新记录
		$flowStr = json_encode($flowArray);
		$ret = self::$tm->set(self::$bid, $uid, $flowStr);
		if($ret === false){//操作失败
			self::$errCode = self::$tm->errno();
			self::$errMsg = "tmem set failed. [bid]:". self::$bid ." [key]:$uid [value]:".$flowStr;
			return false;
		}

		return true;
	}

	/**
	 * 删除指定的激活流水记录
	 * @param $uid 用户uid
	 * @return 成功:ture,失败:false
	 */
	public static function del($uid){
		$ret = self::init();
		if($ret === false){
			return false;
		}
		
		//删除指定的流水记录
		$ret = self::$tm->del(self::$bid, $uid);
		if($ret === false){//操作失败
			self::$errCode = self::$tm->errno();
			self::$errMsg = "tmem del failed. [bid]:". self::$bid ." [key]:$uid";
			return false;
		}

		return true;
	}

}

//激活名单数据操作类
class IVipActivateList {
	public static $errCode = 0;		//错误码
	public static $errMsg = "";		//错误信息

	private static $servers = array();
	private static $bid = ACTIVE_LIST_BID_NAME;
	private static $tm = NULL;		//tmem操作对象

	/*
	 * 初始化错误信息与tmem句柄
	 * @return 成功:true,失败:false
	 */
	private static function init(){
		//初始化错误码与错误信息
		self::$errCode = 0;
		self::$errMsg  = "";

		//从配置中心获取ip列表
		if(empty(self::$servers)){
			$server_count = configcenter4_get_serv_count(ACTIVE_LIST_SVR_NAME,0);
			if(empty($server_count) || $server_count == 0){
				self::$errCode = -1;
				self::$errMsg = "get ip and port failed";
				return false;
			}
			for($i=0;$i<$server_count;$i++){
				$ipAndPort = configcenter4_get_serv(ACTIVE_LIST_SVR_NAME, 0, $i);
				$servers[] = $ipAndPort;
			}
		}
		self::$bid = ACTIVE_LIST_BID_NAME;
		if(empty(self::$tm)){
			self::$tm = new tmem(0, 1);
			//tmem所有操作失败都返回false，错误码调用errno()查看
			$ret = self::$tm->set_servers($servers, 2000, 2);
			if($ret === false){
				self::$errCode = self::$tm->errno();
				self::$errMsg = "tmem set_servers failed. [servers]:".implode(",", $servers);
				return false;
			}
		}
		
		return true;
	}

	/**
	 * 获取激活名单
	 * @param $key 指定的某一分钟,例如：2013_05_20_15_08
	 * @param &$cas cas值
	 * @param &$expire_timestamp 过期时间
	 * @return 失败:false,成功:Index的值
	 */
	public static function casget($key, &$cas, &$expire_timestamp){
		$ret = self::init();
		if($ret === false){
			return false;
		}
		
		//从tmem中获取激活名单
		$casValue = 0;
		$timestamp = 0;
		$list = @self::$tm->casget(self::$bid, $key, $casValue, $timestamp);
		if($list === false){
			self::$errCode = self::$tm->errno();
			self::$errMsg = "tmem casget failed. [bid]:". self::$bid ." [key]:$key";
			return false;
		}

		$cas = $casValue;
		$expire_timestamp = $timestamp;

		return $list;
	}

	/**
	 * 添加或更新激活名单
	 * @param $key:指定的某一分钟,例如：2013_05_20_15_08
	 * @param $list:要设置的激活名单
	 * @param $cas:cas值
	 * @param $expire_seconds:有效时间(单位：s)
	 * @return 成功:ture,失败:false
	 */
	public static function casset($key, $list, $cas, $expire_seconds){
		$ret = self::init();
		if($ret === false){
			return false;
		}

		//设置激活名单
		$ret = self::$tm->casset(self::$bid, $key, $list, $cas, $expire_seconds);
		if(($ret === false) || ($ret === NULL)){//操作失败
			self::$errCode = self::$tm->errno();
			self::$errMsg = "tmem casset failed. [bid]:". self::$bid ." [key]:$key [value]:$list [cas]:$cas [expire_seconds]:$expire_seconds";
			return false;
		}

		return true;
	}

	/**
	 * 获取激活名单
	 * @param $key 指定的某一分钟,例如：2013_05_20_15_08
	 * @return 失败:false,成功:Index的值
	 */
	public static function get($key){
		$ret = self::init();
		if($ret === false){
			return false;
		}
		
		//从tmem中获取激活名单
		$list = @self::$tm->get(self::$bid, $key);
		if($list === false){
			self::$errCode = self::$tm->errno();
			self::$errMsg = "tmem get failed. [bid]:". self::$bid ." [key]:$key";
			return false;
		}

		return $list;
	}

	/**
	 * 添加或更新激活名单
	 * @param $key:指定的某一分钟,例如：2013_05_20_15_08
	 * @param $list:要设置的激活名单
	 * @return 成功:ture,失败:false
	 */
	public static function set($key, $list){
		$ret = self::init();
		if($ret === false){
			return false;
		}

		//设置激活名单
		$ret = self::$tm->set(self::$bid, $key, $list);
		if(($ret === false) || ($ret === NULL)){//操作失败
			self::$errCode = self::$tm->errno();
			self::$errMsg = "tmem set failed. [bid]:". self::$bid ." [key]:$key [value]:$list";
			return false;
		}

		return true;
	}

	/**
	 * 删除激活名单
	 * @param $key 要删除的激活名单的key
	 * @return 成功:ture,失败:false
	 */
	public static function del($key){
		$ret = self::init();
		if($ret === false){
			return false;
		}
		
		//删除指定的激活名单
		$ret = self::$tm->del(self::$bid, $key);
		if($ret === false){//操作失败
			self::$errCode = self::$tm->errno();
			self::$errMsg = "tmem del failed. [bid]:". self::$bid ." [key]:".$key;
			return false;
		}

		return true;
	}

}

?>
