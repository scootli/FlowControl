<?php
/*
 * ����ʵ����֤�û����ݿ��ż���ȡ�����ֻ��б�
 * 
 */
require_once(PHPLIB_ROOT . 'lib/NetUtil.php');

class IVerifyUserIdentity
{
	public static $errCode = 0;
	public static $errMsg = '';

	//�������ɵ�email��֤�룬���а�����uid
	public static function verifyUserIdenty($uid, $sceneId, $cashPoint)
	{
		$userIP = ToolUtil::getClientIP();
        $request=array(
           "scene_id"=>$sceneId,
           "time"=>time(),
            "user_id"=> $uid,
            "ip"=> $userIP,
            "vk"=>$_COOKIE["visitkey"],
            "wireless"=>0,
            "total_point"=>$cashPoint,      // ������������λ���� ABC
            "deal_id"=>0,                   // Ĭ�� A
            "name"=>"",                     // �ռ������� A
            "address"=>array(),             // �ռ��˵�ַ A
            "mobile"=>"",
            "total_fee"=>0,                 // ������ ��λ�� A
            "point_pay"=>0                  // ʹ�û��ָ���      
        );
        $req=json_encode($request);
        $net = Config::getIP('VERIFY_IDENTITY');
        if(!$net)
        {
        	Logger::err("ip get err".print_r($net,true));
        	return false;
        }
        if($uid%2==0)
        {
            $ip = $net[0]["IP"];
            $port = $net[0]["PORT"];
        }
        else
        {
            $ip = $net[1]["IP"];
            $port = $net[1]["PORT"];
        }

        $response=NetUtil::udpCmd($ip, $port, $req);

        return $response;
				
	}
    public static function changePasswordReport($uid, $success)
    {
        $userIP = ToolUtil::getClientIP();
        $visitKey = $_COOKIE["visitkey"];
        $report = array(
                    "user_id"=> $uid,
                    "modify_time" => time(),
                    "modify_suc" => $success,
                    "visitkey"=> $visitKey,
                    "ip"=>$userIP
                );
        $req = json_encode($report);
        $address = Config::getIP('USER_CHANGE_PWD_REPORT');
        if(!$address)
        {
            Logger::err("IVerifyUserIdentity changePasswordReport Get Ip Error:".print_r($address,true));
        }
        //�������ʵ��������ȷ��
        $ip = $address[0]["IP"];
        $port = $address[0]["PORT"];
        $resp = NetUtil::udpCmd($ip, $port, $req, false);
        if($resp === false)
        {
            Logger::err("IVerifyUserIdentity changePasswordReport Send Msg Error");
        }
        return;
    }
}
