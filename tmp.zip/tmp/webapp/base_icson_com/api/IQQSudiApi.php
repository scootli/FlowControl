<?php

/*
	qq�ٵݽӿڲ�ѯ�� ��jsonp����
*/


//��Ѹ�Խ�����id
define('LOGIS_COMPANY_ID_51BUY',	'zj001yixun');
define('LOGIS_COMPANY_ID_YTO',		'056yuantong');

//��ѯkey
define('LOGIS_SOURCE', 		'ICSON');
define('LOGIS_KEY',			'5cvX7FPGdqVP69DSb8iQmQchMTTwJ4E3');


class IQQSudi{
	
	//��ѯ������Ϣ
	public static function getLogisUrl($logis_id, $company_id){

		$sign = md5('companyId' .$company_id .'deliverId' . $logis_id . 'detailNumber0source' .LOGIS_SOURCE . LOGIS_KEY);
		
		$url = 'http://sudi.qq.com/logistics/index.php/querylogis/getlogisJson';
		$url .= '?deliverId=' . $logis_id;
		$url .= '&companyId=' . $company_id;
		$url .= '&detailNumber=0';
		$url .= '&source=' . LOGIS_SOURCE;
		$url .= '&sign=' . $sign;

		return $url;
	}
}