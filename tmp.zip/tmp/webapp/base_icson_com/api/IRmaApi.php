<?php

/*
	�ۺ�ӿھ�̬��
*/

require_once(PHPLIB_ROOT . "lib/NetUtil.php");

define('SECRET_TOKEN',			'51buy#2013%0529');
define('RMA_API_URL',			'http://servicerma.icson.com/rma.api');
define('RMA_API_CALLER_ID',		11001);

Logger::init();

class IRmaApi{
	
	//��ȡָ�����۵����ۺ���Ʒ�����б�
	public static function getPostsaleNumByOrderId($orderId){
		$args = array(
				'method'	=> 'Request.GetProductRMANum',
				'SoSysNo'	=> $orderId
		);
		
		$data = self::_send($args);
		if($data === false){
			return array(
					'return_code'		=> 1,
					'return_message'	=> 'api��ѯʧ��'
			);
		}
		
		return $data;
	}
	
	//��ȡ�ۺ������б�
	public static function getPostsaleByOrderId($orderId, $siteId){
		$args = array(
				'method'	=> 'Request.GetListBySoSysNo',
				'SiteSysNo'	=> $siteId,
				'SoSysNo'	=> $orderId
		);
		
		$data = self::_send($args);
		if($data === false){
			return array(
					'return_code'		=> 1,
					'return_message'	=> 'api��ѯʧ��'
			);
		}
		
		return $data;
	}
	
	//�����ۺ�
	public static function addPostsale($data){
		$args = array(
				'method'		=> 'Request.Create'
		);
		foreach($data AS $key => $val){
			$args[$key] = $val;
		}
		
		$data = self::_send($args);
		if($data === false){
			return array(
					'return_code'		=> 1,
					'return_message'	=> 'api��ѯʧ��'
			);
		}
		
		return $data;
	}
	
	//��ȡ�ۺ�����
	public static function getPostsaleDetail($postsaleId){
		$args = array(
				'method'		=> 'Request.GetDetailBySysNo',
				'ReqSysNo'		=> $postsaleId
		);
		
		$data = self::_send($args);
		if($data === false){
			return array(
					'return_code'		=> 1,
					'return_message'	=> 'api��ѯʧ��'
			);
		}
		
		return $data;
	}
	
	//�ۺ���ˮ��¼
	public static function getPostsaleLogs($postsaleId){
		$args = array(
				'method'		=> 'Request.GetCusLogList',
				'ReqSysNo'		=> $postsaleId
		);
		
		$data = self::_send($args);
		if($data === false){
			return array(
					'return_code'		=> 1,
					'return_message'	=> 'api��ѯʧ��'
			);
		}
		
		return $data;
	}
	
	//�ͻ�����
	public static function addPostsaleMessage($postsaleId, $msg, $siteId){
		$args = array(
				'method'		=> 'Request.CreateMessage',
				'ReqSysNo'		=> $postsaleId,
				'MsgContent'	=> $msg,
				'SiteSysNo'		=> $siteId
		);
		
		$data = self::_send($args);
		if($data === false){
			return array(
					'return_code'		=> 1,
					'return_message'	=> 'api��ѯʧ��'
			);
		}
		
		return $data;
	}
	
	//��ȡ�ۺ����Լ�¼
	public static function getPostsaleMessage($postsaleId, $page = 0){
		$pageSize = 99;
		$args = array(
				'method'	=> 'Request.GetMessageList',
				'ReqSysNo'	=> $postsaleId,
				'PageIndex'	=> $page,
				'PageSize'	=> $pageSize
		);
		
		$data = self::_send($args);
		if($data === false){
			return array(
					'return_code'		=> 1,
					'return_message'	=> 'api��ѯʧ��'
			);
		}
		
		return $data;
	}
	
	//��ȡָ���û��ۺ����뵥�б�
	public static function getPostsaleByUid($uid, $siteId){
		$pageSize = 10;
		$args = array(
				'method'		=> 'Request.GetListByCustomerSysNo',
				'CustomerSysNo'	=> $uid,
				'SiteSysNo'		=> $siteId
		);
		
		$data = self::_send($args);
		if($data === false){
			return array(
					'return_code'		=> 1,
					'return_message'	=> 'api��ѯʧ��'
			);
		}
		
		return $data;
	}
	
	//��ѯȡ����ַ
	public static function getPickUpAddress($cityId, $shipId){
		$args = array(
				'method'		=> 'pickup.getstockinfo',
				'CitySysNo'		=> $cityId,
				'ShipTypeSysNo'	=> $shipId
		);
		
		$data = self::_send($args);
		if($data === false){
			return array(
					'return_code'		=> 1,
					'return_message'	=> 'api��ѯʧ��'
			);
		}
		
		return $data;
	}
	
	//���ӿ��Ƿ�ok
	public static function checkAPI(){
		
	}
	
	
	//�����󲢽�������
	private static function _send($args = array()){
		$args['callerid']	= RMA_API_CALLER_ID;
		$args['format']		= 'json';
		ksort($args);
		$query = '';
		$data = '';
		foreach($args AS $key => $val){
			if(!is_numeric($val) && $key != 'method'){
				$val = iconv('gbk', 'utf-8', $val);
				$val = strtolower(urlencode($val));
			}
			$data	.= $key . '='.($val) . '&';
			$query	.= $key . ($val);
		}
		$sign = md5($query . SECRET_TOKEN);
		$data .= 'sign='.$sign;
		//var_dump(explode("&", $data));
		$ret = NetUtil::cURLHTTPPost(RMA_API_URL, $data);

		if(!ret || $ret == ''){
			Logger::err('RmaAPI query fail: '.$url);
			return array('return_code' => 1, 'msg' => '�ڲ�����������');
		}
		
		$ret = iconv('utf-8', 'gbk', $ret);
		$data = ToolUtil::gbJsonDecode($ret);

		if(!$data){
			Logger::err('RmaAPI data decode error: '.$ret);
			return array('return_code' => 1, 'msg' => '�ڲ�����������');
		}
		
		return $data;
	}
}