<?php

$environment = getEnvironment();
require_once( BASE_WEB_ROOT.'inc/vip/vip.activate.' . $environment . '.php' );

/**
* 利用配置中心的手工服务 vip.51buy.com.env 
* dev环境端口为30001, beta：30002 gamma：30003, idc：30004
*/
function getEnvironment()
{
	@$environment = explode (':', configcenter4_get_serv("vip.51buy.com.env", 0, 0) );
	@$port = $environment[1];
	switch ($port)
	{
		case 30001: return "dev"; //dev环境
		case 30002:	return "beta"; //beta环境
		case 30003:	return "gamma"; //gamma环境
		default:    return "idc";//idc环境
	}
}
		
?>