<?php
require_once(PHPLIB_ROOT . 'api/IUser.php');
require_once(PHPLIB_ROOT . 'api/IIndex.php');
require_once(PHPLIB_ROOT . 'api/ISearch.php');
require_once(PHPLIB_ROOT . 'api/distribution/IBProduct.php');
require_once(PHPLIB_ROOT . 'inc/actMacthProduct.inc.php');
require_once(PHPLIB_ROOT . 'inc/actCarProductConfig.inc.php');
require_once(PHPLIB_ROOT . 'inc/actCarProductData.inc.php');

class TemplateHelper{
	private static $allowedTypes = array(
		"right", "warn", /*"info", */"error"/*, "help"*/
	);
	/**
	* ������ʾ��Ϣ��ȫҳ����ʾ
	*
	* @param string $message ��ʾ��Ϣ����
	* @param string $type ��ʾ��Ϣ����
	*/
	public static function outMessage($message, $type = 'info'){
		global $_WEBSITE_CFG;

		$TPL = new Template(BASE_PAGE_TPL_DIR, 'keep');
		$TPL->set_file(array(
			'baseHandler' => 'base.tpl',
			'headerHandler' => 'header.tpl',  //����
			'containerHandler' => 'message.tpl',
			'footerHandler' => 'footer.tpl' //�ײ�
		));

		if(!in_array($type, self::$allowedTypes)){
			$type = 'warn';
		}

		$extMessage = '';
		if(is_array($message)){
			$tmp = array_shift($message);
			foreach ($message as $m){
				$extMessage .= '<p>' . $m . '</p>';
			}
			if($extMessage){
				$extMessage = '<div class="bd">' . $extMessage . '</div>';
			}
			$message = '<strong class="tit">' . $tmp . '</strong>';
		} else {
			$message = '<strong class="tit">' . $message . '</strong>';
		}

		if(empty($extMessage)) $message .= '<br />';
		$message = '<div class="para_blo para_big">
<div class="inner"> <b class="icon icon_msg4 icon_msg4_' . $type . '"></b>
<div class="hd">' . $message . '</div>
' . $extMessage . '
</div></div>';

		$vars = array(
			"message"	=> $message
		);
		$TPL->set_var($vars);
		$TPL->parse('container', 'containerHandler');
		$TPL->unset_var(array_keys($vars));
		//$_siteId = IUser::getSiteIdWrapper(); //�人վ(modify by allenzhou 20120911 ȥ���人վ�����)
		$_siteId = IUser::getSiteId();
		$defaultSearch = IIndex::getTopSearch($_siteId); //Ĭ���������ù��λ����
		$vars = array(
			//"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteIdWrapper()]) ? $_WEBSITE_CFG[IUser::getSiteIdWrapper()]['contact_number'] : '', //�人վ
			"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteId()]) ? $_WEBSITE_CFG[IUser::getSiteId()]['contact_number'] : '', //modify by allenzhou 20120911 ȥ���人վ�����
			"nav_list_str"  => IUser::getNavList(),
			'global_default_search' => empty($defaultSearch) ? json_encode(array()) : json_encode($defaultSearch), //ҳͷ������
			//"wap_icson_enter" => (isset($_WEBSITE_CFG[IUser::getSiteIdWrapper()]) && ($_WEBSITE_CFG[IUser::getSiteIdWrapper()]['site_id'] == 1))?  '<li class="item"><a ytag="00007" href="http://act.51buy.com/promo-3105.html">�ֻ���Ѹ</a></li>': ''
			"wap_icson_enter" => (isset($_WEBSITE_CFG[IUser::getSiteId()]) && ($_WEBSITE_CFG[IUser::getSiteId()]['site_id'] == 1))?  '<li class="item"><a ytag="00007" href="http://act.51buy.com/promo-3105.html">�ֻ���Ѹ</a></li>': ''//modify by allenzhou 20120911 ȥ���人վ�����
		);
		$TPL->set_var($vars);
		$TPL->parse('header', 'headerHandler');
		$TPL->parse('footer', 'footerHandler');
		$TPL->unset_var(array_keys($vars));
		$TPL->set_var("cate_site", IUser::getCateClass());
		$shandiansongInfo = IUser::getShanDianSongInfo();
		$TPL->set_var('shandiansong_info_text', $shandiansongInfo['text']);
		$TPL->set_var('shandiansong_info_hover', $shandiansongInfo['hover']);
		$TPL->set_var('cod_desc', IUser::isCashOnDelivery() ? '' : 'stand_seven');

		$baseVars = array(
			"header_css"	=> '<link href="http://st.icson.com/static_v1/css/header/header_full.css?v=[[V_CSS_HEADER_FULL]]" rel="stylesheet" type="text/css" />', // default
			"title_desc"	=> '',
			"css_file"	=> '',
			"includeFile" => ''
		);

		$pageIdInfo = ToolUtil::getCurrentPageId();
		$baseVars['yPageId'] = $pageIdInfo['yPageId'];
		$baseVars['yPageLevel'] = $pageIdInfo['yPageLevel'];
		$TPL->set_var($baseVars);
		$TPL->pparse("output", "baseHandler");
	}

	public static function getBaseTPL($flag = 0, $curTabName = '', $opt = array()){
		$tpl = new BaseTPL();
		$tpl->init($flag, $curTabName, $opt);
		$tpl->set_var("cate_site", IUser::getCateClass());
		$shandiansongInfo = IUser::getShanDianSongInfo();
		$tpl->set_var('shandiansong_info_text', $shandiansongInfo['text']);
		$tpl->set_var('shandiansong_info_hover', $shandiansongInfo['hover']);
		$tpl->set_var('cod_desc', IUser::isCashOnDelivery() ? '' : 'stand_seven');
		return $tpl;
	}

	/**
	 *
	 */
	public static function getAttributeList($response, $category_id){

		$attributeList = array();


		if( isset($response["Property"])){
			$attrs = $response["Property"];

			if(is_array($attrs)){

				$ret = array();

				foreach($attrs as $attr){
					if( $attr[3] > 0){
						$ret[] = array(
							"attr_id" => $attr[1],
							"attr_value" => $attr[0],
							"sort_factor" => $attr[2]
						);
					}
				}

				$attributeList = ToolUtil::multi_array_sort($ret, 'sort_factor',  SORT_ASC);
			}
		}

		return $attributeList;
	}

	/**
	 *
	 *
	 */
	public static function getFilterUrl($baseurl,$input, $attr_id, $option_id = '',$isManageProduct = true){

		if ($isManageProduct)
		{
			$value = $input['option'];
			$options = explode('a', $value);
			if(strpos($value, $attr_id.'e') === false){
				$options[] = $attr_id.'e'.$option_id;
			} else {
				$tmp = explode($attr_id.'e', $value);
				if (!empty($tmp[0])) {
					$options[] = $attr_id.'e'.$option_id;
				}
			}

			$ret = array();
			foreach($options as $option){
				$data = explode('e', $option);
				if($data[0] == $attr_id)
					$data[1] = $option_id;
				if(!empty($data[1]) )
					$ret[] = join('e', $data);
			}

			return self::getURL($baseurl,$input, array('currentPage' => 1, 'option' => join('a', $ret) ) );
		}
		else
			return self::getProductURL($input,$attr_id ,$option_id);
	}
	/**
	 *  �����µĲ���ƴװҳ��URL
	 */
	public  static function getURL($baseurl,$oldParams, $newParams, $showHash = false){

		$keys = array('classId', 'price', 'sort', 'viewMode',  'pageSize', 'day', 'currentPage', 'option', 'attrInfo');

		$res = array();
		foreach($keys as $key){
			$res[] =  ( isset($newParams[$key])? $newParams[$key] : $oldParams[$key] ) . ( $key == 'viewMode' ? ( isset($newParams['desc'])? $newParams['desc'] : $oldParams['desc']) : '' );
		}
		$res = 'http://base.51buy.com/' . $baseurl . '/' .join('-', $res) . ".html";
		if( isset( $oldParams['key'] ) ){
			$res.= '?q='.(isset($newParams['key'])? urlencode( $newParams['key'] ) : urlencode( $oldParams['key'] ));
		}
		$res.= $showHash ? '#base' : '';
		return $res;
	}

	/**
	 *  ��Ʒ����-�����µĲ���ƴװҳ��URL
	 */
	public  static function getProductURL($params,$attr_id = '',$option_id='')
	{
		$keys = array('category3','priceingState','topState', 'shelveState','category2','category1', 'stockState'  );
		$res = array();
		foreach ($keys as $key)
		{
			$pos = strpos($key, 'category');
			if (false === $pos)
			{
				$res[] = !isset($params[$key]) ? '2' : $params[$key];
			}
			else
			{
				$res[] = !isset($params[$key]) ? '' : $params[$key];
			}
		}
		if (strlen($attr_id) > 0)
		{
			$value = !isset($params['option']) ? '' :  $params['option'];
			$options = explode('a', $value);
			if(strpos($value, $attr_id.'e') === false){
				$options[] = $attr_id.'e'.$option_id;
			} else {
				$tmp = explode($attr_id.'e', $value);
				if (!empty($tmp[0])) {
					$options[] = $attr_id.'e'.$option_id;
				}
			}

			$ret = array();
			foreach($options as $option){
				$data = explode('e', $option);
				if($data[0] == $attr_id)
					$data[1] = $option_id;
				if(!empty($data[1]) )
					$ret[] = join('e', $data);
			}
			$res = 'http://base.51buy.com/' . join('-', $res) . '-1-' . join('a', $ret) . '-';
		}
		else
		{
			$option = !isset($params['option']) ? '' :  $params['option'];
			$res = 'http://base.51buy.com/' . join('-', $res) . '-{page}-'. $option . '-';
		}

		$res.= '.html?q=' . (isset($params['productNo'])? urlencode( $params['productNo'] ) : '');

		return $res;
	}

	/**
	 *
	 */
	public static function getItemFilter($baseurl,$input,$response, $isExpand = false, &$selectedFilter, $isManageProduct = true){

		global $_category;
		global $_brand;
		global $_catena;
		global $_model;
		$TPL = new Template(BASE_PAGE_TPL_DIR, 'keep');

		$TPL->set_file('handler', 'b_item_filter.tpl');

		$category_id =  $input['classId'];

		$attributeList = self::getAttributeList($response,$category_id);

		$TPL->set_block('handler', 'attr_block', 't_attr_block');
		$str = "";
		$flag = 0;
		$selectedArray = array();

		$more_str = array();
		$ytagBase = 41000;

		$MAX_ROW = 4;

		foreach( $attributeList as $attributeIndex => $attribute){

			$str = '';
			$mulRow = true;

				$options =  self::getsearchNavOption($response, $attribute['attr_id']);

				if(empty($options)) continue;

				$mulRow = count($options) > 1;

				$options = ToolUtil::multi_array_sort($options, 'sort_factor', SORT_ASC);

				$str.= "<dd><dl>";
				$allSelected = ( false === preg_match( '/(^|a)' . $attribute['attr_id'].'e[0-9]+(a|$)/i', $input['option']) );



				$str.='<dt><strong><a ytag="' . ($ytagBase++) . '" href="' . self::getFilterUrl($baseurl,$input, $attribute['attr_id'],'',$isManageProduct) . '"' .  ( $allSelected ? ' class="current"' : '') . '>ȫ��</a></strong></dt>';
				foreach($options as $k => $option){
					$isSelected = !$allSelected  && preg_match( '/(^|a)' . $option['attr_id'].'e'.$option['option_id'] . '(a|$)/i', $input['option']);
					if($isSelected){
						//������Ʒ������
						$key = ($attribute['attr_value']=="Ʒ��"?'brand':count($selectedArray));

						$selectedArray[$key] = array(
							'attr_id' => $option['attr_id'],
							'option_id' => $option['option_id'],
							'option_name' => $option['option_value']
						);
					}
					$str.= '<dd><a ytag="' . ($ytagBase++) . '" lg="1022"'.($isSelected ? ' class="current"':'').' href="' . self::getFilterUrl($baseurl,$input, $option['attr_id'],  $option['option_id'],$isManageProduct) . '">' . $option['option_value'] .'</a></dd>';
				}
				$str.="</dl></dd>";


			if(true === $mulRow){
				$flag++;

				$_optionData = array(
					'attr_name' => $attribute['attr_value'],
					'attr_option' => $str,
					'li_class' => false === $isExpand && ( $flag > ( $MAX_ROW ) ) ? ' class="hidden"' : ''
				);

				$TPL->set_var($_optionData );
				$TPL->parse("t_attr_block", "attr_block", true);
				$TPL->unset_var( $_optionData );

				if( $flag > $MAX_ROW ){
					$more_str[] = $attribute['attr_value'];
				}
			}

		}

		if($flag === 0 && empty($selectedArray)){
			return '';
		}

		if($flag === 0){
			$TPL->set_var('t_attr_block', '');
		}

		//��ѡ��
		if(!empty($selectedArray)){
			$str = '<dl id="selected" class="selected_area" style="display: block;"> <dt>���Ѿ�ѡ��</dt><dd><ul class="selected cf">';
        	foreach($selectedArray as $key => $selected){
        		$selectedFilter[$key] = $selected;
        		if ($isManageProduct)
        			$str.= '<li><a ytag="' . ($ytagBase++) . '" href="' . (!isset($selected['attr_id']) ? self::getURL($baseurl,$input, array('price' => '0') )  : self::getFilterUrl($baseurl,$input, $selected['attr_id'],'',$isManageProduct) ) . '"><i>&nbsp;</i> ' . $selected['option_name'] . '</a></li>';
        		else
        			$str.= '<li><a ytag="' . ($ytagBase++) . '" href="' . (!isset($selected['attr_id']) ? self::getProductURL($input )  : self::getFilterUrl($baseurl,$input, $selected['attr_id'],'',$isManageProduct) ) . '"><i>&nbsp;</i> ' . $selected['option_name'] . '</a></li>';
        	}
         	$str.= '</ul></dd></dl>';
			$TPL->set_var('select_item', $str);
		}
		else
			$TPL->set_var('select_item', '');

		//�رգ�����
		if( $flag > $MAX_ROW){
			$more_str_word =  empty($more_str) ? '' :  implode($more_str, ' ') ;

			$ingor = mb_strlen($more_str_word,'gbk') > 23 ? '..' : '';

			$more_str_word = empty($ingor) ?  mb_substr($more_str_word,0, 23,'gbk')  : ( mb_substr($more_str_word,0, 22, 'gbk') . $ingor );

			$more_str = empty($more_str) ? '' :  ( '<span class="m">��' . $more_str_word   . '��</span>' );

			$TPL->set_var('more_btn', '<div class="wrap_close status_' . ( $isExpand ? 'up' : 'down' ) . '"><p><a ytag="40001" lg="1023" class="btn_click" href="#" onclick="G.app.list.switchFilter(this, \'s\');return false" morestr="' . $more_str_word . '"><b></b>' . ( $isExpand ? '����' : ('����' . $more_str)) . '</a></p></div>');
		}
		else
			$TPL->set_var('more_btn', '');

		return $TPL->parse('output', 'handler');
	}

	public static function getsearchNavOption( $response, $attr_id ){
		$ret = array();

		if( isset($response["Property"])){
			$attrs = $response["Property"];

			if(is_array($attrs)){
				foreach($attrs as $attr){
					if( $attr[2] > 0 && $attr[1] == $attr_id ){

						if( is_array($attr[3])){
							foreach($attr[3] as $option){
								if($option["clusterCount"] > 0){
									$ret[] = array(
										"attr_id" => $attr_id ,
										"option_id" => $option["clusterId"],
										"option_value" => $option["clusterName"],
										"sort_factor" => $option["clusterOrder"]
									);
								}
							}
						}

						break;
					}
				}
			}
		}
		$ret = ToolUtil::multi_array_sort($ret, 'sort_factor',  SORT_ASC);

		return $ret;
	}


}

class BaseTPL extends Template {
	const NO_LEFT_NAV	= 1; // 1 << 0
	private $flag = 0;
	private static $DBName = "retailer";
	private static $tableName = "t_notice";
	private static $tabArray = array(
		"myorder",
		"myfavor",
		"mycoupon",
		"myintegral",
		"shortmessage",
		"myrepair_report",
		"myrepair",
		"myprofile",
		"address",
		"mypassword",
		"mydiyconfig",
		"myemailorder",
		"myrecomend",
		"mynotify",
		"myfeedback",
		"myconsult",
		"myinform",
		"myrepairinfo",
		"myrefund",
		"myrefundinfo",
		"myinstall",
		"installdetail",
		"payforexpensiveness",
		"giftcard",
		"mygiftcard", //�°���Ʒ��
		"mypriceprotect",
		"mybalance"
	);
	/**
	 * �����̣�δ��ͨ��������ർ��
	 */
	private static $tabArrayDistribution = array(
        "b_pricing_publish",
        "b_manage_product",
        "b_manage_shop",
        "b_manage_salesman",
        "b_manage_setting",
	);
	/**
	 * ������ ��ർ��
	 */
	private static $tabArrayB = array(
        "b_manage_order",
        "b_pricing_publish",
        "b_manage_product",
        "b_manage_shop",
        "b_manage_salesman",
        "b_manage_setting",
        "b_product_list",
        "b_notice",
        "myprofile",
        "b_approval_order",
        "b_product_order", //��̨�µ�
        "b_sail_report",   //���۱���
        "b_manage_address", //�ջ���ַ
	    "b_manage_client"  //�ͻ�����
    );
	private $opt = array();

	public function setOpt($options){
		foreach ($options as $k => $option){
			$this->opt[$k] = $option;
		}
	}

	public function init($flag = 0, $curTabName = '', $options = array()){
		parent::Template(BASE_PAGE_TPL_DIR, 'keep');

		$this->opt = $options;

		$baseTplFile = 'base.tpl';
		if($curTabName === 'myrepair' || $curTabName === 'myinstall' || $curTabName === 'payforexpensiveness'){
			$baseTplFile = 'base_service.tpl';
		}

		if( isset($this->opt['SSL']) && $this->opt['SSL'] === true )
		{
			$this->set_file(array(
			'baseHandler' => 'base_ssl.tpl',
			'containerHandler' => 'container.tpl',
			'footerHandler' => 'footer_ssl.tpl' //�ײ�
			));
		}
		else
		{
			$this->set_file(array(
			'baseHandler' => $baseTplFile,
			'containerHandler' => 'container.tpl',
			'footerHandler' => 'footer.tpl' //�ײ�
			));
		}

		$headerTPLFile = 'header.tpl';
		if(!empty($this->opt['headerStyle'])){
			if($this->opt['headerStyle'] == 'none'){
				$headerTPLFile = 'header_none.tpl';
			} else if($this->opt['headerStyle'] == 'login'){
				$headerTPLFile = 'header_login.tpl';
			} else if($this->opt['headerStyle'] == 'loginold'){
				$headerTPLFile = 'header_loginold.tpl';
				$this->set_file(array(
					'baseHandler' => 'baseold_ssl.tpl',
					'containerHandler' => 'container.tpl',
					'footerHandler' => 'footer_ssl.tpl' //�ײ�
				));
			} else if($this->opt['headerStyle'] == 'min'){
				$headerTPLFile = 'header_min.tpl';
			} else if($this->opt['headerStyle'] == 'retailer'){
				$headerTPLFile = 'header_retailer.tpl';
				$this->set_file("footerHandler", 'footer_retailer.tpl');
			} else if ( $this->opt['headerStyle'] == 'register' ){
				$headerTPLFile = 'header_register.tpl';
			} else if ( $this->opt['headerStyle'] == 'agreement' ){
				$headerTPLFile = 'header_agreement.tpl';
			}
		}

		$this->set_file("headerHandler", $headerTPLFile);

		$this->flag = empty($flag) ? 0 : $flag;

		if($this->flag & (self::NO_LEFT_NAV)){
			$this->set_var("left_nav", "");
		} else {
			$uid = ToolUtil::checkLoginOrRedirect();
			$user = IUser::getUserInfo($uid);
			$isShoppingGuide = 0;
			$isDistribution = 0;

/*
 * �رշ�������� modified by derongzeng 2012-12-17
			require_once (PHPLIB_ROOT . 'api/IRetailer.php');
			$retailer = IRetailer::getRetailers(array('uid' => $uid));
			if (is_array($retailer) && count($retailer)>0 && $retailer[0]['level']>0)
		    {
		       $isDistribution = 1;
		       $isShoppingGuide = intval($retailer[0]['isShoppingGuide']);
		    }

*/
			if (!$isDistribution) {
				$this->set_file("leftNavHandler", "left_nav.tpl");
				$tabVars = array();
				if (in_array($curTabName,self::$tabArrayB))
				{
					if ('myprofile' != $curTabName)
					{
				        header("Location: http://base.51buy.com/index.html");
                        exit;
					}
				}
				foreach (self::$tabArray as $tab){
					if( 'mypassword' === $tab){
						$uid = IUser::getLoginUid();
						$res = IUser::validateUserFromQQ($uid);
						if( false ===  $res['validate']){
							$res = IUser::validateUserFromALI($uid);
							if( false ===  $res['validate']){
								$tabVars[$tab] = '<li' . ( $curTabName == $tab ? ' class="status_hover"' : '' ) . '><a href="http://base.51buy.com/mypassword.html">��¼����</a></li>';
							} else {
								$tabVars[$tab] = '';
							}
						}
						else{
							$tabVars[$tab] = '';
						}
					}
					else{
						$tabVars[$tab] = $curTabName == $tab ? ' class="status_hover"' : '';
					}
				}
				$this->set_var($tabVars);
				$this->parse("left_nav", "leftNavHandler");
				$this->unset_var(self::$tabArray);
			}
			else {
				/**
				 * ��������ʾ�µ���ർ��
				 */
				$MSDB = ToolUtil::getDBObj(self::$DBName);
				$sql="SELECT notice_theme from t_notice WHERE notice_statue = 1";
				$ret=$MSDB->getRows($sql);
				$data['new_notice_title']=$ret[0]['notice_theme'];
				$this->set_var($data);

			    if (in_array($curTabName,self::$tabArray))
                {//����ԭc�û�������
                    if ('myprofile' != $curTabName)
                    {
                        header("Location: http://base.51buy.com/index.html");
                        exit;
                    }
                }
			    $this->opt['cssFile'] = 'http://st.icson.com/static_v1/css/mycenter/distributor_my_index.css';
			    $leftnave = "b_left_nav.tpl";
			    if (1 == $isShoppingGuide)
			    {
			       $leftnave = "b_left_nav_guide.tpl";
			    }
			    else {
				    if (in_array($curTabName,self::$tabArrayDistribution))
	                {//�ǵ����û����õ�������
	                        header("Location: http://base.51buy.com/index.html");
	                        exit;
	                }
			    }
				$this->set_file("leftNavHandler", $leftnave);
				$this->set_file("baseHandler", "b_base.tpl");
				$this->set_file("containerHandler", "b_container.tpl");
				$this->set_var('store_class', '');
				$tabVars = array();
				foreach (self::$tabArrayB as $tab) {
					$tabVars[$tab] = $curTabName == $tab ? ' class="status_hover"' : '';
				}
				$this->set_var($tabVars);
				$this->parse("left_nav", "leftNavHandler");
				$this->unset_var(self::$tabArrayB);
			}
		}
	}

	public function out(){
		global $_WEBSITE_CFG;

		$this->parse('header', 'headerHandler');
		$this->parse('container', 'containerHandler');
		$this->parse('footer', 'footerHandler');
		//$_siteId = IUser::getSiteIdWrapper(); //�人վ(modify by allenzhou 20120911 ȥ���人վ�����)
		$_siteId = IUser::getSiteId();

		$defaultSearch = IIndex::getTopSearch($_siteId); //Ĭ���������ù��λ����
		$baseVars = array(
			"header_css"	=> '<link href="http://st.icson.com/static_v1/css/header/header_full.css?v=[[V_CSS_HEADER_FULL]]" rel="stylesheet" type="text/css" />', // default
			//"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteIdWrapper()]) ? $_WEBSITE_CFG[IUser::getSiteIdWrapper()]['contact_number'] : '', //�人վ
			"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteId()]) ? $_WEBSITE_CFG[IUser::getSiteId()]['contact_number'] : '', //�人վ(modify by allenzhou 20120911 ȥ���人վ�����)
			"nav_list_str"  => IUser::getNavList( !empty($this->opt['headerConfig'])? $this->opt['headerConfig'] : array() ),
			'global_default_search' => empty($defaultSearch) ? json_encode(array()) : json_encode($defaultSearch), //ҳͷ������
			//"wap_icson_enter" => (isset($_WEBSITE_CFG[IUser::getSiteIdWrapper()]) && ($_WEBSITE_CFG[IUser::getSiteIdWrapper()]['site_id'] == 1))?  '<li class="item"><a ytag="00007" href="http://act.51buy.com/promo-3105.html">�ֻ���Ѹ</a></li>': ''//modify by allenzhou 20120911 ȥ���人վ�����
			"wap_icson_enter" => (isset($_WEBSITE_CFG[IUser::getSiteId()]) && ($_WEBSITE_CFG[IUser::getSiteId()]['site_id'] == 1))?  '<li class="item"><a ytag="00007" href="http://act.51buy.com/promo-3105.html">�ֻ���Ѹ</a></li>': ''
		);

		if(!empty($this->opt['headerStyle'])){
			if($this->opt['headerStyle'] == 'none' || $this->opt['headerStyle'] == 'min' || $this->opt['headerStyle'] == 'register' ){
				$baseVars['header_css'] = '<link href="http://st.icson.com/static_v1/css/header/header_min.css?v=[[V_CSS_HEADER_MIN]]" rel="stylesheet" type="text/css" />';
			}
		}

		if(!empty($this->opt['titleDesc'])){
			$baseVars['title_desc'] = $this->opt['titleDesc'] . ' - �ҵ���Ѹ - ';
		} else {
			$baseVars['title_desc'] = '�ҵ���Ѹ - ';
		}

		if(!empty($this->opt['cssFile'])){
			$baseVars['css_file'] = '<link href="' . $this->opt['cssFile'] . '" rel="stylesheet" type="text/css" />';
		} else {
			$baseVars['css_file'] = '<link href="http://st.icson.com/static_v1/css/mycenter/mycenter.css?v=20130131001" rel="stylesheet" type="text/css" />';
		}
		
		if(!empty($this->opt['includeFile'])){
			$baseVars['includeFile'] = $this->opt['includeFile'];
		}
		else{
			$baseVars['includeFile'] = '';
		}

		$pageIdInfo = ToolUtil::getCurrentPageId();
		$baseVars['yPageId'] = $pageIdInfo['yPageId'];
		$baseVars['yPageLevel'] = $pageIdInfo['yPageLevel'];

		$this->set_var($baseVars);
		$this->pparse("output", "baseHandler");
	}
}

// End Of Script