<?php
class ConfigDistributor
{
	static $cacheTime = 600; //600 ��
}