<?php

$white_users = array(
	'tencent_cgi1',
	'tencent_cgi2',
	'tencent_cgi3',
	'tencent_cgi4',
	'tencent_cgi5',
	'tencent_cgi6',
	'tencent_cgi7',
	'tencent_cgi8',
	'tencent_cgi9',
	'tencent_cgi10',
	'tencent_test01',
	'tencent_test02',
	'tencent_test03',
	'tencent_test04',
	'tencent_test05',
	'tencent_test06',
	'tencent_test07',
	'tencent_test08',
	'tencent_test09',
	'tencent_test10'
);