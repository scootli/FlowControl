<?php

$mod_list = array(
	"address",
	"favor",
	'invoice',
	'login',
	'user',
	'myprofile',
	'myorder',
	'mypassword',
	'myintegral',
	'mycoupon',
	'myfavor',
	'myrepair',
	'index',
	'address',
	'orderdetail',
	'shortmessage',
	'findpassword',
	'supplier',
    'greenchannel',
	'myemailorder',
	'myrecomend',
	'mynotify',
	'mydiyconfig',
	'myfeedback',
	'myconsult',
	'myinform',
	'myrepairinfo',
	'shandiansong',
	'zhengpinhanghuo',
	'jiadianshangmenanzhuang',
	'retailer',
	'myrefund',
	'myrefundinfo',
	'myinstall',
	'installdetail',
	'bmanageproduct',
	'bpricingpublish',
	'bmanageuser',
	'bmanageorder',
	'distributor',
    'bproductlist', //������̨�µ�
    'bnotice',
    'borderdetail', //����Ԥ��������
    'bmanageclient',
    'bsailreport',   //�������۱���
    'bmanageclientdetail',
	'cpsservice',
	'payforexpensiveness', //�����
	'giftcard', //��Ʒ��
	'mygiftcard', //�°���Ʒ��
	'mypriceprotect', //�۸񱣻�
	'agreement',  //��Ѹʹ������
	'picture',
	'score',
	'mybalance',
	'registerAndLogin',
	'vip'//��Ѹ��Ա
);

$_top_state = array(
	0 => '��',
	1 => '��'
	);

$_priceing_state = array(
	0 => '��',
	1 => '��'
	);

$_shelve_state = array(
	0 => '�¼�',
	1 => '����',
	2 => '��ɾ��'
	);

$_price_type = array(
	0 => '�Ӽ۸�',
	1 => '�Ӱٷֱ�'
	);

$_stock_state = array(
	0 => '�޻�',
	1 => '�л�'
	);
$cps_keycode = 'Wdk2&23%22DDs#2(js)2';
$mail_keycode = '9ZO5np^fI7wtfgWw~KCf6';
$mail_url = 'http://app.api.51buy.com/email.json';
$crm_key = 'CrmAdmin';
$crm_host = 'crm.icson.com';
$crm_args = array('r1' => '1', 'r2' => '2');
$crm_industry_url = 'http://crm.icson.com/api/industry.json';
$crm_company_scale_url = 'http://crm.icson.com/api/companyScale.json';
$crm_company_save_url = 'http://crm.icson.com/api/companyUserSave.json';