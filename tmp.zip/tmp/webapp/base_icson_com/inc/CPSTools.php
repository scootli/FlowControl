<?php
/**
 * Tools工具类
 * 在此封装一些常用的方法
 */

class CPSTools{
	/**
	 * 错误编码
	 */
	public static $errCode = 0;
	/**
	 * 错误信息,无错误为''
	 */
	public static $errMsg  = '';

	/**
	 * 清除错误信息,在每个函数的开始调用
	 */
	private static function clearError()
	{
		self::$errCode = 0;
		self::$errMsg	= '';
	}

/**
 *----------------------------------------------------------
 * Cookie 设置、获取、清除 (支持数组或对象直接设置) 2009-07-9
 * @modified by EdisonTsai on 14:27 2012/12/27 for support setrawcookie mode
 * Modified by Edison tsai on 11:36 2012/01/13 for add HttpOnly & Secure settings
 * Modified by Edison tsai on 14:36 2010/12/10 for add new features for set cookies are encrypt or not
 * Modified by Edison tsai on 14:33 2010/12/10 for remove encrypt for cookies' value
 * Modified by Edison tsai at 14:27 2010/06/01 for the cookies key
 *----------------------------------------------------------
 * 1 获取cookie: cookie('name')
 * 2 清空当前设置前缀的所有cookie: cookie(null)
 * 3 删除指定前缀所有cookie: cookie(null,'REST_') | 注：前缀将不区分大小写
 * 4 设置cookie: cookie('name','value') | 指定保存时间: cookie('name','value',3600)
 * 5 删除cookie: cookie('name',null)
 *----------------------------------------------------------
 * $option 可用设置prefix,expire,path,domain,secure,httpOnly
 * 支持数组形式:cookie('name','value',array('expire'=>1,'prefix'=>'REST_'))
 * 支持query形式字符串:cookie('name','value','prefix=tp_&expire=10000')
 *-----------------------------------------------------------
 * $isEncrypt 是否加密,1=yes;0=no(default)
 * 若是加密,将使用XxteaEncrypt进行处理
 */
public static function cookie($name,$value='',$option=null,$isEncrypt=0, $isRaw=false)
{
    // 默认设置
//    $cookie_conf = Rest::getConf('cookie_conf');
    $prefix 	=  Rest::getConf('COOKIE_PREFIX');
    $expire 	=  Rest::getConf('COOKIE_EXPIRE');
    $path 		=  Rest::getConf('COOKIE_PATH');
    $domain 	=  Rest::getConf('COOKIE_DOMAIN');
    $key 		=  Rest::getConf('COOKIE_KEY');
    $httponly 	=  Rest::getConf('COOKIE_HTTPONLY');
    
    $config = array(
    
        'prefix' 		=> 	$prefix, // cookie 名称前缀
        'expire' 		=> 	$expire, // cookie 保存时间
        'path'   		=> 	$path,   // cookie 保存路径
        'domain' 		=> 	$domain, // cookie 有效域名
		'key'    		=> 	$key,    // cookie key
		'httponly'		=>	$httponly	// cookie 限于http协议访问
		
    );

    $setcookie = false === $isRaw ? 'setcookie' : 'setrawcookie';
    

    // 参数设置(会覆盖黙认设置)
    if (0 === $option || !empty($option)) {
        if (is_numeric($option)){
            $option = array('expire'=>$option);
		}
        elseif( is_string($option) ){
            parse_str($option,$option);
		}

		$config = array_merge($config,array_change_key_case($option));
    }

    // 清除指定前缀的所有cookie
    if (is_null($name)) {
       if (empty($_COOKIE)) return;
       // 要删除的cookie前缀，不指定则删除config设置的指定前缀
       $prefix = empty($value)? $config['prefix'] : $value;
       if (!empty($prefix))// 如果前缀为空字符串将不作处理直接返回
       {
           foreach($_COOKIE as $key=>$val) {
               if (0 === stripos($key,$prefix)){
                    $setcookie($_COOKIE[$key],'',time()-3600,$config['path'],$config['domain']);
                    unset($_COOKIE[$key]);
               }
           }
       }
       return;
    }
    $name = $config['prefix'].$name;
    if (''===$value){

		#Modified by Edison tsai at 12:26 2010/06/19 for add Xxtea decrypt XxteaDecrypt(base64_decode($_COOKIE[$name]))
        return isset($_COOKIE[$name]) ? (!$isEncrypt ? $_COOKIE[$name] : self::authCode($_COOKIE[$name])) : null;// 获取指定Cookie
    }else {
        if (is_null($value)) {
            $setcookie($name,'',time()-3600,$config['path'],$config['domain']);
            unset($_COOKIE[$name]);// 删除指定cookie
        }else {
            // 设置cookie
            $expire = !empty($config['expire'])? time()+ intval($config['expire']):0;

			/*
			 * Security & Http Only are processing
			 * Added by Edison tsai on 14:34 2012/01/14
			 */

			 $secure			= isset($_SERVER['SERVER_PORT']) && 443 == $_SERVER['SERVER_PORT'] ? true : false;
			 $config['path']	= $config['httponly'] && PHP_VERSION < '5.2.0' ? $config['path'].'; HttpOnly' : $config['path'];

            /* Modified by Edison tsai at 12:02 2010/06/01 for remove serialize mode 
			$setcookie($name,serialize($value),$expire,$config['path'],$config['domain']);
            $_COOKIE[$name] = serialize($value);*/
			#Modified by Edison tsai at 12:23 2010/06/19 for add Xxtea encrypt base64_encode(XxteaEncrypt($value))
			$isEncrypt && $value = self::authCode($value,'ENCODE');

			if(PHP_VERSION < '5.2.0'){
					
				$setcookie($name,$value,$expire,$config['path'],$config['domain'],$secure);
				
			} else {

				$setcookie($name,$value,$expire,$config['path'],$config['domain'],$secure,$config['httponly']);
					
			} //end if


            $_COOKIE[$name] = $value;
        }
    }
}


public static function authCode($str, $operate = 'DECODE', $key = '', $expiry = 0) {

	$ckey_length = 4;
	$key = md5($key != '' ? $key : Rest::getConf('COOKIE_KEY'));
	$keya = md5(substr($key, 0, 16));
	$keyb = md5(substr($key, 16, 16));
	$keyc = $ckey_length ? ($operate == 'DECODE' ? substr($str, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';

	$cryptkey = $keya.md5($keya.$keyc);
	$key_length = strlen($cryptkey);

	$str = $operate == 'DECODE' ? base64_decode(substr($str, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($str.$keyb), 0, 16).$str;

	$str_length = strlen($str);

	$result = '';
	$box = range(0, 255);

	$rndkey = array();
	for($i = 0; $i <= 255; $i++) {
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);
	}

	for($j = $i = 0; $i < 256; $i++) {
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;
		$tmp = $box[$i];
		$box[$i] = $box[$j];
		$box[$j] = $tmp;
	}

	for($a = $j = $i = 0; $i < $str_length; $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;
		$tmp = $box[$a];
		$box[$a] = $box[$j];
		$box[$j] = $tmp;
		$result .= chr(ord($str[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
	}

	if($operate == 'DECODE') {
		if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
			return substr($result, 26);
		} else {
			return '';
		}
	} else {
		return $keyc.str_replace('=', '', base64_encode($result));
	}

}


// 获取客户端IP地址
public static function get_client_ip(){
		   if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
		       $ip = getenv("HTTP_CLIENT_IP");
		   else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
		       $ip = getenv("HTTP_X_FORWARDED_FOR");
		   else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
		       $ip = getenv("REMOTE_ADDR");
		   else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
		       $ip = $_SERVER['REMOTE_ADDR'];
		   else
		       $ip = "unknown";
		   return($ip);
	}

/**
 * Get local IP
 * 
 * @param 	string 	$eth 	the network interface card ID
 * @return 	string
 * @date 	11:37 2013/02/05
 * @author 	EdisonTsai
 */
public static function get_local_ip($eth='eth1'){
	$ip = '';
	if(function_exists('qp_get_local_ip')){
		$ip = qp_get_local_ip();
		$ip = isset($ip[$eth]) ? trim($ip[$eth]) : (isset($ip['eth0']) ? trim($ip['eth0']) : '127.0.0.1');
	}

	return $ip;
}

public static function isEmail($email) {
	return strlen($email) > 5 && preg_match("/^[\w\-\.]+@[\w\-\.]+(\.\w+)+$/", $email);
}

//取得字符串的长度，包括中英文。
public static function getStrlen($text){
	if (function_exists('mb_substr')) {
		$length=mb_strlen($text,'UTF-8');
	} elseif (function_exists('iconv_substr')) {
		$length=iconv_strlen($text,'UTF-8');
	} else {
		preg_match_all("/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/", $text, $ar);   
		$length=count($ar[0]);
	}
	return $length;
}

public static function fileExt($f) {
	return trim(strtolower(substr(strrchr($f, '.'), 1)));
}

public static function checkWebAddr($url){ 
 return preg_match('/^http(s)?:\/\/[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(\/.*)?$/i', $url);
}


	/**
	* Check the signature is true or false
	* the array_pop might has bug if param key over than 's', for now
	* we use another parse to remove it
	*
	* @param array	$var		the POST array
	* @param array	$extra		the extra array for skip
	* @param string	$skey		the secret key of current user
	* @param string	$sign_type	the sign type, default is 'MD5'
	*
	* @modified by EdisonTsai on 14:45 2012/09/09 for add skey param
	* @modified by EdisonTsai on 11:16 2012/09/07 for replace sig to sign
	* @Modified by Edison tsai on 17:33 2011/06/07 for add extra array
	* @modified by Edison tsai on 15:41 2011/05/26 for add new parse for remove 'sig' key
	* @modified by Edison tsai on 15:44 2011/05/07 for integrate with genSig function
	* @create 19:26 2011/05/06
	* @author Edison tsai
	* @return Boolean
	*/
	public static function checkSig($var,$skey,$extra=array(),$sign_type='MD5'){

        if(!is_array($var) || count($var)<1 || empty($skey)){
                return false;
        }

        ksort($var);
        reset($var);

        $var = array_map('trim',$var);

        #Remove sig param

        #$sigOld = array_pop($var);
		$sigOld = null;
		$vars	= $var;

		 foreach($vars AS $k=>$v){
			if('sign' == $k){
				$sigOld = $v;
			} else {
				$v		= urldecode($v);
				$var[$k]= get_magic_quotes_gpc() ? stripslashes($v) : $v;
			}
		 } #end foreach

        $sigNew = self::genSig($var,$skey,$extra,$sign_type);
		unset($var,$vars,$k,$v);

        return $sigOld == $sigNew ? true : false;

	}

	/**
	* Gen sig key
	*
	* @param array	$var		the POST array
	* @param array	$extra		the extra array for skip
	* @param string	$skey		the secret key of current user
	* @param string	$sign_type	the sign type, default is 'MD5'
	*
	* @modified by EdisonTsai on 11:16 2012/09/07 for plugin with TTC
	* @Modified by Edison tsai on 17:29 2011/06/07 for add extra array
	* @Modified by Edison tsai on 16:26 2011/06/07 for add $settings  
	* @modified by Edison tsai on 15:35 2011/05/07 for remove is_sig params,
	*	and add remove callback parse.
	* @modified by Edison tsai on 15:51 2011/05/07 for add TTL parse.
	* @create 20:12 2011/05/06
	* @author Edison tsai
	* @return String
	*/
	public static function genSig($var,$skey,$extra=array(),$sign_type='MD5'){

	if(!is_array($var) || count($var)<1 || empty($skey)){
		return '0';
	}

	$rmKeys = array('callback','sign');

	if(count($extra)>=1){
		$rmKeys = array_merge($rmKeys,$extra);
	}

	ksort($var);
	reset($var);


	$var = array_map('trim',$var);

	$t = '';

	 foreach($var AS $k=>$v){
		#modified by EdisonTsai on 11:28 2012/09/07 for replace '@' to '&'
		#Added by Edison tsai on 15:34 2011/05/07 for remove callback params
		//$k	= strtolower($k);
		$t .= !in_array($k, $rmKeys) ? $k.'='.urlencode($v).'&' : '';
	 } #end foreach

		 switch($sign_type){
				case 'MD5':
							$t = md5($t.$skey);break;
				//TODO: Only support MD5 for now, add new encrypt what you need.
				default:
							$t = md5($t.$skey);break;
		 }

		 	unset($var,$k,$v);

		return $t;
	}
	/**
	 * 重定向页面，防止意外缓存
	 * @param string $url 目标url
	 * @modified by EdisonTsai on 19:08 2012/11/19 for set redirect URL more safety
	 */
	public static function redirect($url){
		//Check URL is ok or not
		//强制绑定51buy.com，暂不作配置
		$baseURL = Rest::getConf('DefaultURL');
		$baseURL = !is_array($baseURL) && strlen($baseURL) > 7 ? $baseURL : 'http://www.51buy.com/';

		if(!preg_match("/^https?:\/\/([^\.]+\.|)51buy\.com/i", $url)){
			$url = $baseURL;
		}

		unset($baseURL);
		
			self::noCacheHeader();
			header('HTTP/1.1 301 Moved Permanently');
			header('Location:' . $url);
			exit;
	}

	/**
	 * 强制无缓存
	 * @param string $url 目标url
	 */
	public static function noCacheHeader(){
		header( 'Expires: Mon, 26 Jul 1997 05:00:00 GMT' );
		header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s' ) . ' GMT' );
		header( 'Cache-Control: max-age=0' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate' );
		header( 'Cache-Control: post-check=0, pre-check=0', false );
		header( 'Pragma: no-cache' );
	}

	/**
	 * PHP 版本escape，CPS功能时引入
	 * @param string $str
	 */
	public static function escape($str) {
		preg_match_all("/[\x80-\xff].|[\x01-\x7f]+/", $str, $r);
		$ar = $r[0];
		foreach($ar as $k=>$v) {
			if (ord($v[0]) < 128) {
				$ar[$k] = rawurlencode($v);
			}
			else {
				$ar[$k] = "%u" . bin2hex(mb_convert_encoding($v, 'UCS-2', 'GBK'));
			}
		}
		return join('', $ar);
	}

	/**
	 * 批量增加目录
	 *
	 * @param string $path 	整个路径
	 * @author EdisonTsai
	 * @return void
	 */
	public static function createDirs($path)
	{
	  
	  if (!is_dir($path))
	  {
	   $directory_path = '';
	   $directories = explode('/',$path);
	   
	   foreach($directories as $directory)
	   {
	     $directory_path .= $directory.'/';
		 is_dir($directory_path) or mkdir($directory_path, 0777);
	   }
	  }
	}

	/**
 	 * unpackCookie
 	 *
 	 * @param $cookie,$mid
 	 * @return array
 	 */
 	public static function unpackCookie($cookie, $mid) {
		$cpsCookie = explode(',', $cookie);
		$retArr = array();
		switch($mid) {
			case 1000000001: //上汽
				break;
			case 1000000002: //领科特
				if(count($cpsCookie) == 2 && strlen($cpsCookie[0]) > 0){
					$retArr = array_combine(array('cookie', 'cookie_time'), $cpsCookie);
				}//和其他的CPS提供商不同
				break;
			case 1000000003: //彩贝
				if(count($cpsCookie) == 4){
					$retArr = array_combine(array('open_id', 'login_from', 'attach', 'cookie_time'), $cpsCookie);
				}
				break;
			case 1000000004: //成果
				if(count($cpsCookie) == 2 && strlen($cpsCookie[0]) > 0){
					$retArr = array_combine(array('click_id', 'cookie_time'), $cpsCookie);
				}
				break;
			case 1000000005: //唯一
				if(count($cpsCookie) == 2 && strlen($cpsCookie[0]) > 0){
					$retArr = array_combine(array('cid', 'cookie_time'), $cpsCookie);
				}
				break;
			case 1000000006: //51比购
				if(count($cpsCookie) == 2 && strlen($cpsCookie[0]) > 0){
					$retArr = array_combine(array('u_id', 'cookie_time'), $cpsCookie);
				}
				break;
			case 1000000007: //51返利
				if(count($cpsCookie) == 4){
					$retArr = array_combine(array('u_id', 'tracking_code', 'username','cookie_time'), $cpsCookie);
				}
				break;
			case 1000000008: //网易有道
				if(count($cpsCookie) == 3){
					$retArr = array_combine(array('unionid', 'userid', 'cookie_time'), $cpsCookie);
				}
				break;
			case 1000000009: //QQ团购 不接入
				break;
			case 1000000010: //亿起发
				if(count($cpsCookie) == 4){
					$retArr = array_combine(array('src', 'cid', 'wi', 'cookie_time'), $cpsCookie);
				}
				break;
			case 1000000011: //etao
				if(count($cpsCookie) == 2){
					$retArr = array_combine(array('ali_b2ctrackid', 'cookie_time'), $cpsCookie);
				}
				break;
			default: //集成站长的接口
				if(count($cpsCookie) == 3){
					$retArr = array_combine(array('cookie_time', 'uid', 'cps_extra'), $cpsCookie);
				}
				break;
		}
		if(count($retArr) == 0){
			return array('err_code' => 1 ,'err_msg' => 'cookie error');
		}else{
			return array('err_code' => 0 , 'data'=> $retArr);
		}
 	}
 	
 	/**
 	 * get merchants ID via sysid
 	 *
 	 * @param 	string 	$sysid
 	 * @return 	array
 	 * @var 	added by wheelswang, modified by EdisonTsai for optimize on 20:37 2013/01/22
	 * @modified by EdisonTsai on 12:05 2013/01/25 for get mid from file
 	 */
 	public static function getMid($sysid){

 		$sysid 	= trim($sysid);

		//调用CMEM模块
		$cmem = CMemFactory::getCMEM('CPSMerchants');
		$merchants_info = $cmem->get('mer_'.$sysid);
		if( $merchants_info != false && !empty($merchants_info[0]) ){
			//调用cmem获取到数据。
			$merchants_info = $merchants_info[0];
			$m_info = json_decode($merchants_info,true);
			if( isset($m_info['status']) && trim($m_info['status']) >1 ){
				$result = array(	'mid' 		=> 	isset($m_info['mid']) ? $m_info['mid'] : 0,
									'type' 		=> 	isset($m_info['type']) ? trim($m_info['type']) : 0,
									'keycode' 	=> 	isset($m_info['keycode']) ? trim($m_info['keycode']) : '',
									'status'	=>	isset($m_info['status']) ? trim($m_info['status']) : 0
								);
				
 				return $result;
			}
		}else{

			//获取之前的落地配置进去Cmem
			$merc	= Rest::getConf('MechantsData');

			 if(is_array($merc[$sysid]) && isset($merc[$sysid]['mid']) && isset($merc[$sysid]['status'])){
				$cmem_set_res = $cmem->set('mer_'.$sysid,json_encode($merc[$sysid]));
				return $merc[$sysid];
			 }
		}
 	}

	/**
	 * Get Microsecond
	 *
	 * @return float
	 * @date   18:15 2013/02/17
	 * @author EdisonTsai
	 */
	public static function getMicrotime(){
		list($usec, $sec) = explode(' ', microtime());
		return ((float)($usec*1000000) + (float)($sec*1000000));
	}

	/**
	 * EK模板引擎的外部模板引入函数
	 *
	 * @param	string	$tpl 模板名称
	 * @return	string
	 * @date	15:45 2013/04/25
	 * @author	EdisonTsai
	 */
	public static function template($tpl){
		
		$t = new ekTemplate();

		if(empty($tpl)){
			$t->_Halt('No template name input.');
		}

		//模板文件路径[Template File dir]
		$tplfile = $t->tpl_default_dir.'/'.$tpl.'.'.$t->tpl_file_ext;
	    
		//构造编译文件[Define compile file]
		$compiledtplfile = $t->templateCacheDir.'/'.$tpl.'.'.$t->tpl_file_id.'.php';

		if( !@is_file($compiledtplfile) | ( @filemtime($tplfile) > @filemtime($compiledtplfile) ) | ( time() - @filemtime($compiledtplfile) > $t->tpl_refresh_time && $t->tpl_refresh_time != '0' ) )
		//文件不存在或者创建日期超出刷新时间(此条件当刷新时间为0时不进行操作)，若检测出模板文件的日期大于缓存文件时重新编译
		  { 
			 //编译模板[Compile template]
			$t->tpl_compile($tplfile,$compiledtplfile);
		  }

		  unset($t, $tpl);

		return $compiledtplfile;
		
	}

} //End of script