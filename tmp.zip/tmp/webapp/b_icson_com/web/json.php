<?php
error_reporting(E_ALL);
set_magic_quotes_runtime(0);

$magic_quotes_gpc = get_magic_quotes_gpc();
date_default_timezone_set('Asia/Shanghai');

define("DEFAULT_CACHE_TIME", 300);

require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define("B_WEB_ROOT", WEB_ROOT . "b_icson_com/");
define('CACHE_PATH', B_WEB_ROOT.'cache/');
define("ACT_PAGE_TPL_DIR", B_WEB_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, B_WEB_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

require_once(B_WEB_ROOT. 'inc/constant.inc.php');

// �������ͷ������(�Ա� modules ���ܹ��޸�)
$wrap_header = array(
	"httpv1_0"	=> "HTTP/1.0 200 OK",
	//"httpv1_1"	=> "HTTP/1.1 200 OK",
	"cache"		=> "Cache-Control: max-age=" . DEFAULT_CACHE_TIME,
	"expires"	=> "Expires: " . gmdate( 'D, d M Y H:i:s', time() + DEFAULT_CACHE_TIME) . ' GMT',
	"type"     => "Content-type:text/html; charset=" . (defined('CHARSET') ? CHARSET : 'GB2312'),
);

// ��� module ��
if (!empty($_REQUEST['mod'])){
	$mod_name = preg_replace("/[^a-zA-Z]/", '',trim($_REQUEST['mod']));
} else {
	$mod_name = 'main';
}


$mod_file = B_WEB_ROOT . 'mod/'.$mod_name.'.php';

if( !file_exists($mod_file)){
	$mod_file = B_WEB_ROOT . 'areas/'.$siteInfo['name'].'/mod/'.$mod_name.'.php';
	$tpl_directory = B_WEB_ROOT . 'areas/'.$siteInfo['name'].'/tpl';
	
	if( !file_exists($mod_file)){
		$mod_file = B_WEB_ROOT . 'areas/default/mod/'.$mod_name.'.php';
		$tpl_directory = B_WEB_ROOT . 'areas/default/tpl';
	}
	define("DEFAULT_TPL_DIR", B_WEB_ROOT . 'areas/default/tpl');
	define("CURRENT_TPL_DIR", $tpl_directory);
}

if ( !in_array($mod_name, $mod_list, true) || !file_exists($mod_file) ){
	// ��¼���ʵ� url
	$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
	$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
	Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
	ToolUtil::redirect("http://www.51buy.com/");
}

// ��� act ��
if (!empty($_REQUEST['act'])){
	$act_name = preg_replace("/[^a-zA-Z0-9]/", '', trim($_REQUEST['act']));
} else {
	$act_name = 'page';
}

$func_name = $mod_name . '_' . $act_name;

require_once $mod_file;
if (!function_exists($func_name)){
	$func_name = $mod_name . '_page';
	if(!function_exists($func_name)){
		$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
		$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
		Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
		ToolUtil::redirect("http://www.51buy.com/");
	}
}

// ��� json �ַ���(��Ϊ�����п�����Ҫ�޸� $wrap_header ��������Ҫ��ִ��)
if (isset($_GET['jsontype']) && $_GET['jsontype'] === 'str'){
    $json_str = $func_name();
} else {
    $json_str = ToolUtil::gbJsonEncode($func_name());
}

// ��ȫ�������������� header
if (is_array($wrap_header))
{
    foreach ($wrap_header as $key => $header_line)
    {
        @header($header_line);
    }
}

// �������Ļص�������
$callback_function = (empty($_REQUEST['callback']) || !preg_match("/^[a-zA-Z0-9_$\.]+$/", trim($_REQUEST['callback'])))
    ? '' : trim($_REQUEST['callback']);

$is_json_format = (empty($_REQUEST['fmt']) || !preg_match("/^[0-9]+$/", trim($_REQUEST['fmt'])))
    ? 0 : intval($_REQUEST['fmt']);

// �������iframe��ʽ�����json��Ϣ
if ( $is_json_format == 0 )
{
    if ( empty( $callback_function ) )
    {
        echo $json_str;
    }
    else
    {
		if(isset($_REQUEST['exception'])){
			echo 'try{'."$callback_function($json_str)".';}catch(e){};';
		}
		else{
			echo "$callback_function($json_str);";
		}
    }
}
else
{
    echo <<<EOT
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn" lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="utf-8" />
<meta name="robots" content="all" />
<meta name="author" content="Tencent-ISRD" />
<meta name="Copyright" content="Tencent" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<title>POST - ICSON</title>
</head>
<body>
<script type="text/javascript">
<!--
document.domain="51buy.com";
frameElement.callback($json_str);
//-->
</script>
</body>
</html>
EOT;
}
?>