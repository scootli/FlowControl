<?php
error_reporting(E_ALL);
set_magic_quotes_runtime(0);

$magic_quotes_gpc = get_magic_quotes_gpc();
date_default_timezone_set('Asia/Shanghai');

require_once("Config.php");
define('LIB_PATH', PHPLIB_ROOT."lib/");
define('API_PATH', PHPLIB_ROOT."api/");
define("B_WEB_ROOT", WEB_ROOT . "b_icson_com/");
define('CACHE_PATH', B_WEB_ROOT.'cache/');
define("ACT_PAGE_TPL_DIR", B_WEB_ROOT . "tpl/");

require_once(PHPLIB_ROOT . 'lib/TMAutoload.php');
TMAutoload::getInstance()->setDirs(array(LIB_PATH, API_PATH, B_WEB_ROOT.'lib/'))
    ->setSavePath(CACHE_PATH.'autoload/')->execute();

require_once(B_WEB_ROOT. 'inc/constant.inc.php');

// ��� module ��
if (!empty($_REQUEST['mod'])) {
	$mod_name = preg_replace("/[^a-zA-Z]/", '',trim($_REQUEST['mod']));
} else {
	$mod_name = 'main';
}

$siteInfo = IUser::getSiteInfo( empty($_GET['site_id']) || $_GET['site_id'] == 1 ? null : $_GET['site_id'] );

if (false === $siteInfo) {
	IUser::redirectOldSite();
}

$mod_file = B_WEB_ROOT . 'mod/'.$mod_name.'.php';

if (!file_exists($mod_file)) {
	$mod_file = B_WEB_ROOT . 'areas/'.$siteInfo['name'].'/mod/'.$mod_name.'.php';
	$tpl_directory = B_WEB_ROOT . 'areas/'.$siteInfo['name'].'/tpl';

	if (!file_exists($mod_file)) {
		$mod_file = B_WEB_ROOT . 'areas/default/mod/'.$mod_name.'.php';
		$tpl_directory = B_WEB_ROOT . 'areas/default/tpl';
	}
	define("DEFAULT_TPL_DIR", B_WEB_ROOT . 'areas/default/tpl');
	define("CURRENT_TPL_DIR", $tpl_directory);
}
if ( !in_array($mod_name, $mod_list, true) || !file_exists($mod_file) ) {
	// ��¼���ʵ� url
	$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
	$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
	Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
	ToolUtil::redirect("http://www.51buy.com/");
}

// ��� act ��
if (!empty($_REQUEST['act'])) {
	$act_name = preg_replace("/[^a-zA-Z]/", '', trim($_REQUEST['act']));
} else {
	$act_name = 'page';
}

// ���html�ĺ���ǰ׺��page_����������json��
$func_name = 'page_' . $mod_name . '_' . $act_name;

require_once $mod_file;

if (!function_exists($func_name)) {
	$func_name = $mod_name . '_page';
	if (!function_exists($func_name)) {
		$queryString = $_SERVER['REQUEST_URI'] . '?' . $_SERVER['QUERY_STRING'];
		$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
		Logger::err('CRI-UNEXPECTED-VISITOR:' . $queryString . '-refer:' . $referer);
		ToolUtil::redirect("http://www.51buy.com/");
	}
}

ToolUtil::noCacheHeader();
$func_name($siteInfo);
// End Of Script