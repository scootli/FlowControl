<?php
define('SALEFIELD', 1);
define('PRICEFIELD', 2);
define('EVALUATEFIELD', 4);
define('DEFAULTFIELD', 6);

class TemplateHelper{
	private static $allowedTypes = array(
		"right", "warn", /*"info", */"error"/*, "help"*/
	);
	/**
	* ������ʾ��Ϣ��ȫҳ����ʾ
	*
	* @param string $message ��ʾ��Ϣ����
	* @param string $type ��ʾ��Ϣ����
	*/
	public static function outMessage($message, $type = 'notice'){
		global $_WEBSITE_CFG;


		$TPL = new Template(ACT_PAGE_TPL_DIR, 'keep');
		$TPL->set_file(array(
			'baseHandler' => 'base.tpl',
			'headerHandler' => 'header.tpl',  //����
			'containerHandler' => 'message.tpl',
			'footerHandler' => 'footer.tpl' //�ײ�
		));

		if(!in_array($type, self::$allowedTypes)){
			$type = 'warn';
		}

		$extMessage = '';
		if(is_array($message)){
			$tmp = array_shift($message);
			foreach ($message as $m){
				$extMessage .= '<p>' . $m . '</p>';
			}
			if($extMessage){
				$extMessage = '<div class="bd">' . $extMessage . '</div>';
			}
			$message = '<strong class="tit">' . $tmp . '</strong>';
		} else {
			$message = '<strong class="tit">' . $message . '</strong>';
		}

		if(empty($extMessage)) $message .= '<br />';
		$message = '<div class="para_blo para_' . $type . '">
<div class="inner"> <b class="icon icon_msg4 icon_msg4_' . $type . '"></b>
<div class="hd">' . $message . '</div>
' . $extMessage . '
</div></div>';

		$vars = array(
			"message"	=> $message
		);
		$TPL->set_var($vars);
		$TPL->parse('container', 'containerHandler');
		$TPL->unset_var(array_keys($vars));
		$_siteId = IUser::getSiteIdWrapper(); //�人վ
		$vars = array(
//			"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteId()]) ? $_WEBSITE_CFG[IUser::getSiteId()]['contact_number'] : '',
			"i_contact_number" => isset($_WEBSITE_CFG[$_siteId]) ? $_WEBSITE_CFG[$_siteId]['contact_number'] : '', //�人վ
			"nav_list_str"  => IUser::getNavList()
		);
		$TPL->set_var($vars);
		$TPL->parse('header', 'headerHandler');
		$TPL->parse('footer', 'footerHandler');
		$TPL->unset_var(array_keys($vars));
		$TPL->set_var('is_open', '');//Ĭ�Ϸ��ർ������
		$TPL->set_var('cate_site', IUser::getCateClass());
		$shandiansongInfo = IUser::getShanDianSongInfo();
		$TPL->set_var('shandiansong_info_text', $shandiansongInfo['text']);
		$TPL->set_var('shandiansong_info_hover', $shandiansongInfo['hover']);
		$TPL->set_var('cod_desc', IUser::isCashOnDelivery() ? '' : 'stand_seven');
		
		$baseVars = array(
			"header_css"	=> '<link href="http://st.icson.com/static_v1/css/header/header_full.css?v=[[V_CSS_HEADER_FULL]]" rel="stylesheet" type="text/css" />', // default
			"title_desc"	=> '',
			"css_file"	=> '',
			"before_body"	=> '',
		);

		$pageIdInfo = ToolUtil::getCurrentPageId();
		$baseVars['yPageId'] = $pageIdInfo['yPageId'];
		$baseVars['yPageLevel'] = $pageIdInfo['yPageLevel'];
		$TPL->set_var($baseVars);
		$TPL->pparse("output", "baseHandler");
	}

	public static function getBaseTPL($opt = array()){
		$tpl = new BaseTPL();
		$tpl->init($opt);
		return $tpl;
	}

	public static function productsSort(&$products){
		global  $_StockTips;

		$notSale = array();
		$saleEmtpy = array();
		$sale = array();

		foreach($products as $item){
			//�ݲ�����
			if($item['status'] != 1){
				$notSale[] = $item;
			}
			//�� �� ��
			else if($item['stock'] === $_StockTips['not_available']){
				$saleEmtpy[] = $item;
			}
			else{
				$sale[] = $item;
			}
		}

		return array_merge($sale, $saleEmtpy, $notSale);
	}
	public static function getSaleMessage($productInfo){
		global  $_StockTips;
		$isOnSale = true;
		$message = "";

		if($productInfo['status'] != 1){
			$message = '�� �� ��';
//			$message = '�ݲ�����';
			$isOnSale = false;
		} else if($productInfo['stock'] === $_StockTips['not_available']){
			$message = '�� �� ��';
			$isOnSale = false;
		} else if($productInfo['stock'] === $_StockTips['arrival2-7']){
			$message = '2~7���ڷ���';
		} else if($productInfo['stock'] === $_StockTips['arrival1-3']){
			$message = '1~3���ڷ���';
		}
		else{
			$message = '24Сʱ����';
		}

		return array(
			"onSale" => $isOnSale,
			"message" => $message
		);
	}

	//��Ʒ��Ϣ�б�
	public static function getProductList($input, $response, $selectedFilter){
		$TPL = new Template(ACT_PAGE_TPL_DIR, 'keep');

		if( empty($response) || !isset( $response['list'] ) || !isset( $response['totalNum'] ) || $response['totalNum'] == 0){
			$TPL->set_file('handler', 'list_empty.tpl');
			if(is_array($selectedFilter) && count($selectedFilter) > 0){
				$filterNames = '';
				$space = '';
				foreach( $selectedFilter as $index=>$item){
					$filterNames.= $space . $item['option_name'];
					$space = ' ';
				}
				$TPL->set_var('empty_message', '��Ǹ��û���ҵ� �� <strong>' . $filterNames . '</strong> �� ��صĲ�Ʒ!&nbsp;&nbsp;<a href="' . self::getURL($input, array('option' => '' , 'price' =>  0)) . '" target="_self">�鿴ȫ����Ʒ</a>');
			}
			else{
				$TPL->set_var('empty_message', '��Ǹ��û���ҵ���صĲ�Ʒ!');
			}
			return $TPL->parse('output', 'handler');
		}
		$productList = $response['list'];
		$productCount =  $response['totalNum'] + 0;;

		$TPL->set_file('handler', 'item_list.tpl');
		$TPL->set_block('handler', 'item_block', 't_item_block');

		$siteId = IUser::getSiteId();

		$result = array();

		if( $productCount > 0){

			$product_ids = array();
			foreach($productList as $item){
				$product_id = self::getProductSysNo($item['sysNo']);
				$product_ids[] = $product_id;
				$result[$product_id] = $item;
			}
			//��Ʒ��Ϣ
			$whInfo = IProduct::getProductsInfo($product_ids, $siteId, false);
			if( false === $whInfo ){
				Logger::err("IProduct::getProductsInfo error: " . IProduct::$errCode . "; " . IProduct::$errMsg);
				self::outMessage();
				exit();
			}
			//��Ʒ��Ʒ��
			$giftInfos = IProduct::getProductsGift($product_ids, $siteId);
			if( false === $giftInfos ){
				Logger::err("IProduct::getGift error: " . IProduct::$errCode . "; " . IProduct::$errMsg);
				$giftInfos = array();
			}

			if(count($whInfo) > 0 ){
				$whInfo = self::productsSort($whInfo);

				if(empty($whInfo)){
					$TPL->set_var('t_item_block', '' );
				} else {
					$ytagPrefix = 2000;
					foreach($whInfo as $index=>$wi){

						$product_id = $wi['product_id'];

						if(!isset($result[$product_id])){
							continue;
						}

						$item = $result[$product_id];
						$saleInfo = self::getSaleMessage($wi);
						$ytagPrefix++;

						$_itemData = array(
				            "productTitle" =>  $wi['name'],
							"mouseTitle" => htmlspecialchars(strip_tags( $wi['name']), ENT_QUOTES),
				            "price" => sprintf("%.2f", $wi['show_price']/100),
				            "marketprice" => sprintf("%.2f", $wi['market_price']/100),
				            "gift" => isset($giftInfos[$product_id]) ? '<div class="wrap_gifts "><b class="icon_gifts" pid="'. $product_id .'">��</b></div>' : "",
							"index" => $index + 1,
				            "sysNo" =>  $product_id,
				            "productID" => $item['productID'],
				            "promotionDesc" => $item['promotionDesc'],
				            "manufacturerCode" => $item['manufacturerCode'],
				            "manufacturerName" => $item['manufacturerName'],
							"product_url" => "http://item.51buy.com/item-". $product_id . ".html",
				            "onlineQty" => $item['onlineQty'],
						    'ytagPrefix' => $ytagPrefix,
				            "promotionType" => $item['promotionType'],
							"noticeOrCart" =>  true === $saleInfo['onSale'] ? '<a ytag="'.$ytagPrefix.'2" href="#" lgtype="1" lg="1013" pos="' . ($index + 101) . '" onclick="G.logic.constants.goToCartWithThis(this,{ppid:\''.$item['productTypeMasterid'].'\',pid:\''. $product_id .'\'}'.');logStat.chkItem(' . ($index + 101) . ', ' . $product_id . ',\'\');return false;" class="btn_strong">���빺�ﳵ</a>' : '<a lg="1014" pos="' . ($index + 101) .'" onclick="logStat.chkItem(100,' . $product_id . ',\'\')" class="btn_common" href="http://item.51buy.com/item-' . $product_id . '.html">' . $saleInfo['message'] . '</a>',
							'evaluate' => $item['evaluationNum'] > 0 ? '<p class="comment">���� ��<span class="icon_star"><b style="width:'. ( $item['gradeNum'] * 10 ) . '%"></b></span>(<a ytag="'.$ytagPrefix.'3" pos="'. ( $index + 201 ) .'" lg="1011" onclick="logStat.chkItem('. ( $index + 201 ) .','. $product_id .',\'\')" href="http://item.51buy.com/item-'. $product_id .'.html#review_box" target="_blank">' . $item['evaluationNum'] . '��</a>)</p>' : '<p class="comment">�������� (<a ytag="'.$ytagPrefix.'3" onclick="logStat.chkItem('. ( $index + 201 ) .','. $product_id .',\'\')" pos="'. ( $index + 201 ) .'" lg="1012" href="http://item.51buy.com/review-toadddiscussion-'. $product_id .'.html" target="_blank">������һ������</a>)</p>',
							'pic' => IProduct::getPic($item['productID'], 'middle'),
						);
						$TPL->set_var( $_itemData );
						$TPL->parse("t_item_block", "item_block", true);
						$TPL->unset_var( $_itemData );
					}
				}
			}
			else{
				$TPL->set_var('t_item_block', '' );
			}
		} else {
			$TPL->set_var('t_item_block', '' );
		}
		//��ʾģʽ
		$TPL->set_var("viewmode", '<span class="viewmode '. ($input['viewMode'] == 1 ? "status_pic" : "status_list") .'"><a ytag="39980" class="icon_pic" lg="1002" name="list" href="'. self::getURL($input, 'viewMode', '1') .'"><b></b>ͼƬ</a><a ytag="39981" class="icon_list" lg="1003" href="'. self::getURL($input, 'viewMode', '0') .'"><b></b>�б�</a></span>');

		//�Ƿ��շ���
		$TPL->set_var("isDay", $input['day'] == 1 ? 'checked="checked"' : '');

		//�����ֶ�
		$TPL->set_var( $input );

		$isDesc = $input['desc'] == 1? true : false;

		$currentFieldName = '';
		$isPriceColumn = false;
		$isSaleColumn = false;
		$isEvaluateColumn = false;
		$isDefaultColumn = false;
		switch( $input['sort']){
			case PRICEFIELD:
				$currentFieldName = $input['desc'] ? '�۸�Ӹߵ���' : '�۸�ӵ͵���';
				$isPriceColumn = true;
				break;
			case SALEFIELD:
				$currentFieldName = '�����Ӹߵ���';
				$isSaleColumn = true;
				break;
			case EVALUATEFIELD:
				$currentFieldName = '���۴Ӹߵ���';
				$isEvaluateColumn = true;
				break;
			case DEFAULTFIELD:
				$currentFieldName = 'Ĭ������';
				$isDefaultColumn = true;
				break;
		}

		//�۸�����
		$TPL->set_var('order_price', '<a ytag="39982" lg="1005" pos="2" class="' . ( $isPriceColumn ? ( $isDesc ? 'status_down' : 'status_up' ) : 'order_up' ) . '" href="' . self::getURL($input, array( 'desc' =>  $isPriceColumn ?  ( $isDesc ? '0' : '1' ): '0' , 'sort' => PRICEFIELD )) . '"><b></b>�۸�</a> ');

		//��������
		$TPL->set_var('order_sale', '<a ytag="39983" lg="1006" class="' . ( $isSaleColumn ? 'status_down' : 'order_down' ) . '" href="' . self::getURL($input, array( 'desc' =>  '1' , 'sort' => SALEFIELD )) . '"><b></b>����</a> ');

		//��������
		$TPL->set_var('order_evaluate', '<a ytag="39983" lg="1007" class="' . ( $isEvaluateColumn ? 'status_down' : 'order_down' ) . '" href="' . self::getURL($input, array( 'desc' => '1' , 'sort' => EVALUATEFIELD  )) . '"><b></b>����</a> ');

		//����ʽ - ��ǰ����
		$TPL->set_var('current_sort_type', '<a ytag="39984" class="title" href="javascript:;" id="current_sort_type">' . $currentFieldName . '<b></b> </a>');

		//����ʽ - �۸�ӵ͵���
		$TPL->set_var('price_asc', self::getURL($input, array( 'sort' => PRICEFIELD, 'desc' => '0' )));
		//����ʽ-�۸�Ӹߵ���
		$TPL->set_var('price_desc', self::getURL($input, array( 'sort' => PRICEFIELD, 'desc' => '1' )));
		//�����Ӹߵ���
		$TPL->set_var('sale_desc', self::getURL($input, array( 'sort' =>  SALEFIELD, 'desc' => '1' )));
		//���۴Ӹߵ���
		$TPL->set_var('evaluate_desc', self::getURL($input, array( 'sort' =>  EVALUATEFIELD, 'desc' => '1' )));
		//����ʽ-Ĭ������
		$TPL->set_var('sort_default', self::getURL($input, array( 'sort' => DEFAULTFIELD, 'desc' => '1' )));

		//��ʽ��ʽ
		$TPL->set_var('show_type', $input['viewMode'] == 1 ? 'id_pic' : 'id_list');

		//��ҳ��Ϣ
		$TPL->set_var("page_html", self::getpageHTML( self::getURL($input, 'currentPage','{page}' ) . '#list', $input['currentPage'], ceil( $productCount / $input['pageSize'] ), 4 ));

		return $TPL->parse('output', 'handler');
	}

	public static function getItemFilter( $input, $isExpand = false, &$selectedFilter){

		$TPL = new Template(LIST_PAGE_TPL_DIR, 'keep');
		$TPL->set_file('handler', 'item_filter.tpl');

		$category_id = $input['classId'];
		$attributeList = ISearchNavAttrTTC::get($category_id, array('status' => 0));
		$attributeList = ToolUtil::multi_array_sort($attributeList, 'sort_factor',  SORT_ASC );
		if( empty($attributeList ) ){
			$attributeList = array();
		}
		$attributeList[] = array("attr_value" => '�۸�����');

		$TPL->set_block('handler', 'attr_block', 't_attr_block');
		$str = "";
		$flag = 0;
		$attributeListCount = count($attributeList);
		foreach( $attributeList as $attributeIndex => $attribute){
			$priceRow = ( $attributeIndex === ( $attributeListCount - 1 ) );
			$options = $priceRow ? self::getPriceData($category_id) : ISearchNavOptionTTC::get($attribute['attr_id'], array('status' => 0 ));
			if(!empty($options)){
				$flag++;
				//�۸�������
				$str = '';
				if($priceRow){
					$str.= "<dd><dl>";
					$allSelected = empty( $input['price'] ) ? true : false;
					$str.='<dt><strong><a href="' . self::getURL($input, 'price', '0' ) . '"' .  ( $allSelected ? ' class="current"' : '') . '>ȫ��</a></strong></dt>';
					foreach($options as $option){
						$isSelected = ( !$allSelected && ( $input['price'] === $option['option_id'] ) );
						if($isSelected){
							$selectedArray[] = array(
								'option_id' => $option['option_id'],
								'option_name' => $option['option_value']
							);
						}
						$str.= '<dd><a'.($isSelected ? ' class="current"':'').' href="' . self::getURL($input, array('currentPage' => 1, 'price' => $option['option_id']) ) . '">' . $option['option_value'] . '</a></dd>';
					}
					$str.="</dl></dd>";
				}
				else{
					$str.= "<dd><dl>";
					$allSelected = ( false === eregi( "(^|a)" . $attribute['attr_id'].'e[0-9]+(a|$)', $input['option']) );
					$str.='<dt><strong><a href="' . self::getFilterUrl($input, $attribute['attr_id']) . '"' .  ( $allSelected ? ' class="current"' : '') . '>ȫ��</a></strong></dt>';
					foreach($options as $option){
						$isSelected = !$allSelected  && eregi( '(^|a)' . $option['attr_id'].'e'.$option['option_id'] . '(a|$)', $input['option']);
						if($isSelected){
							$selectedArray[] = array(
								'attr_id' => $option['attr_id'],
								'option_id' => $option['option_id'],
								'option_name' => $option['option_value']
							);
						}
						$str.= '<dd><a'.($isSelected ? ' class="current"':'').' href="' . self::getFilterUrl($input, $option['attr_id'],  $option['option_id']) . '">' . $option['option_value'] . '</a></dd>';
					}
					$str.="</dl></dd>";
				}
				$_optionData = array(
					'attr_name' => $attribute['attr_value'],
					'attr_option' => $str,
					'li_class' => false === $isExpand && $attributeIndex > 2 ? ' class="hidden"' : ''
				);
				$TPL->set_var($_optionData );
				$TPL->parse("t_attr_block", "attr_block", true);
				$TPL->unset_var( $_optionData );
			}
		}

		if($flag === 0){
			return '';
		}

		//��ѡ��
		if(!empty($selectedArray)){
			$str = '<dl id="selected" class="selected_area" style="display: block;"> <dt>���Ѿ�ѡ��</dt><dd><ul class="selected cf">';
        	foreach($selectedArray as $selected){
        		$selectedFilter[] = $selected;
        		$str.= '<li><a href="' . (!isset($selected['attr_id']) ? self::getURL($input, 'price', '0' )  : self::getFilterUrl($input, $selected['attr_id']) ) . '"><i>&nbsp;</i> ' . $selected['option_name'] . '</a></li>';
        	}
         	$str.= '</ul></dd></dl>';
			$TPL->set_var('select_item', $str);
		}
		else
			$TPL->set_var('select_item', '');

		//�رգ�����
		if( $flag > 3){
			$TPL->set_var('more_btn', '<div class="wrap_close status_' . ( $isExpand ? 'up' : 'down' ) . '"><p><a class="btn_click" href="#" onclick="G.app.list.switchFilter(this, \'list\');return false"><b></b>' . ( $isExpand ? '����' : '����') . '</a></p></div>');
		}
		else
			$TPL->set_var('more_btn', '');

		return $TPL->parse('output', 'handler');
	}

	public static function getPathAndPageTitle($input, $response){
		$ret = false;
		$pathData = !empty($response) && isset($response['Path']) ? $response['Path'] : false;

		if( !empty($pathData) ){
			$item = ICategoryTTC::get($pathData[0]['ItemId'] - 100000000, array('level' => '3'), array('name', 'parent_id'), 1);
			$parent = null;
			$pparent = null;
			if( !empty($item) ){
				$parent = ICategoryTTC::get($item[0]["parent_id"], array('level' => '2'), array('parent_id', 'name'), 1);
				if( !empty($parent)){
					$pparent = ICategoryTTC::get($parent[0]['parent_id'], array('level' => '1'), array('name'), 1);
					if( !empty( $pparent ) ){
						$ret = array(
							'path' => $ret = '<a href="http://www.51buy.com">��ҳ</a> &gt; <span>'.$pparent[0]['name'].'<span> &gt; <span>'.$parent[0]['name'].'</a> &gt; <a href="'. self::getURL($input, array()) .'">' . $item[0]['name'] . '</a>',
							'title' => $pparent[0]['name'] . ' - ' . $item[0]['name']
						);

					}
				}
			}
		}

		return $ret;
	}

	/*
	 *
	 * ��������id�Ͳ���ֵ�����ص�ǰ����ֵ
	 * @author oscarzhu
	 * @param array $input	ҳ���������
	 * @param int 	$attr_id ����id
	 * @return string
	 *
	 */
	public static function getAttrValutFromId($input, $attr_id){

		$value = $input['option'];
		$options = split('a', $value);
		if(strpos($value, $attr_id.'e') === false){
			return '';
		}

		$ret = array();
		foreach($options as $option){
			$data = split('e', $option);
			if($data[0] == $attr_id)
				return $data[1];
		}

		return '';
	}


	public static function getFilterUrl($input, $attr_id, $option_id = ''){

		$value = $input['option'];
		$options = split('a', $value);
		if(strpos($value, $attr_id.'e') === false){
			$options[] = $attr_id.'e'.$option_id;
		}

		$ret = array();
		foreach($options as $option){
			$data = split('e', $option);
			if($data[0] == $attr_id)
				$data[1] = $option_id;
			if(!empty($data[1]) )
				$ret[] = join('e', $data);
		}

		return self::getURL($input, array('currentPage' => 1, 'option' => join('a', $ret) ) );
	}

	//�����µĲ���ƴװҳ��URL
	public  static function getURL($oldParams, $newParams, $value = ''){

		if( !is_array($newParams) ){
			$newParams = array(
				$newParams => $value
			);
		}
		$keys = array('classId', 'price', 'sort', 'viewMode',  'pageSize', 'day', 'currentPage', 'option', 'attrInfo');

		$res = array();
		foreach($keys as $key){
			$res[] =  ( isset($newParams[$key])? $newParams[$key] : $oldParams[$key] ) . ( $key == 'viewMode' ? ( isset($newParams['desc'])? $newParams['desc'] : $oldParams['desc']) : '' );
		}
		$res = join('-', $res) . ".html";
		if( isset( $oldParams['key'] ) )
			$res.= '?q='.(isset($newParams['key'])? urlencode( $newParams['key'] ) : urlencode( $oldParams['key'] ));
		return $res;
	}

	public static function getProductSysNo($sysNo){
		$wh_id = IUser::getSiteId();
		return IProduct::getProductIdFromSearch($sysNo, $wh_id);
	}

	/**
	 * ���ɷ�ҳhtml
	 *
	 * @param string $url urlģ��,  ����: page.html?page={page}
	 * @param Number ��ǰҳ��
	 * @param Number $pageCount ҳ��
	 * $param Number neighborLength ��ʾ����ҳ��ĸ���
	 */
	public static function getpageHTML($url, $currentPage, $pageCount, $neighborLength = 3){

		if($pageCount < 2 )
		return "";

		$start = $currentPage  - $neighborLength;
		$end = $currentPage + $neighborLength;

		if($start <= 4){
			$start = 2;
		}

		$start = $start > 1 ? $start : 2;

		$end = 2* $neighborLength - ($start < $currentPage? ($currentPage - $start ) : 0 ) + $currentPage;
		$end = $end < $pageCount ? $end : ( $pageCount - 1 );

		$str = "";
		//��һҳ
		$str.= $currentPage == 1 ? '<span class="page-start"><b>&lt;</b>��һҳ</span>' : '<a lg="1015" pos="'. ( $currentPage - 1 ).'" href="' . str_replace("{page}", $currentPage - 1, $url) . '" class="page-prev"><b>&lt;</b>��һҳ</a>';

		//��һҳ
		$str.= $currentPage == 1 ? "" : '<a lg="1015" pos="1" href="' . str_replace("{page}", 1, $url) . '">1</a>';

		//���ھ�
		if( $start != 2 )
		$str.= '<span class="page-break">...</span>';
		for($i = $start; $i < $currentPage; $i++){
			$str.=  '<a lg="1015" pos="'.$i.'" href="' . str_replace("{page}", $i, $url) . '">' . $i . '</a>';
		}

		//��ǰҳ
		$str.= '<span class="page-this">' . $currentPage . '</span>';

		//���ھ�
		for($i = $currentPage + 1; $i < $end + 1; $i++){
			$str.=  '<a lg="1015" pos="'.$i.'" href="' . str_replace("{page}", $i, $url) . '">' . $i . '</a>';
		}

		if( $end != $pageCount - 1 )
		$str.= '<span class="page-break">...</span>';

		//���һҳ
		$str.= $currentPage != $pageCount  ? '<a lg="1015" pos="'.$pageCount.'" href="' . str_replace("{page}", $pageCount, $url) . '">' . $pageCount . '</a>' : '';

		//��һҳ
		$str.= $currentPage != $pageCount  ? '<a lg="1015" pos="'.( $currentPage + 1 ).'" href="' .  str_replace("{page}", $currentPage + 1, $url) . '" class="page-next">��һҳ<b>&gt;</b></a>' : '<span class="page-end">��һҳ<b>&gt;</b></span>';

		//�������ת
		$str.= '<span class="page-skip"> ����<input type="text" value="' . $currentPage . '" maxlength="3">ҳ<button lg="1016" value="go" onclick="var a=parseInt($(this).parent().find(\'input[type=text]\').val(),10);a=(!!a&&a>0&&a<='. $pageCount .')?a:1;window.location.href=\''.str_replace("{page}", '\'+a+\'', $url).'\'">ȷ��</button></span>';

		return $str;
	}


	//���λ
	public static function getAdvertise($list, $linkClass = false, $needLi = false, $count = 0){
		if(empty($list)) return '';
		$str = '';
		$ytag = 11000;
		foreach($list as $index => $item){
			if($count === 0 || $index < $count){
				$isPic = $item['type'] == '1';
	            $str.= ( $needLi ? '<li>' : '') . '<a ytag="' . ($ytag++) . '" title="' . strip_tags($item['title']) . '" '.( $item['open_mode'] == '1' ? ' target="_blank"' : '').(!empty($linkClass)? ( ' class="'.$linkClass.'"' ) : '').' href="' . $item['href'] . '">' . ($isPic? '<img'.( !empty($item['width'])? ( ' width="'. ( $item['width'] + 0 ).'px"' ) : '' ).(!empty($item['height'])? ( ' height="' . ( $item['height'] + 0 ).'px"' ) : '') . ' src="' . $item['src'] . '">' : $item['title'] ). '</a>' . ( $needLi ? '</li>' : '');
			}
		}

        return $str;
	}

	//�ֲ�
	public static function getSlidePlay($list){
		$ret = array();
		if(!empty($list)){
			foreach($list as $item){
				array_push($ret, array("href" => $item['href'], "text"=>'', "img_b" => $item['src'], "img_s" => $item['surl']));
			}
		}
		return ToolUtil::gbJsonEncode($ret);
	}

	//��¥��Ʒ
	public static function getFloorProducts($list){

		global $_StockTips;
		$str = '';
		$i=0;
		static $ytagBase = 2000;
		$ytagBase += 100;

		foreach($list as $index=>$item){
			$ytagPrefix = $ytagBase + $i * 10;
			if($i==5)
				break;
			$flag = "";
			if($i==4)
				$flag = "overflow";
			$i++;
 			$comment =	$item['review_count'] > 0 ? '<p class="comment">���� ��<span class="icon_star"><b style="width:'. ( round($item['score']/5 * 100) ) . '%"></b></span>
	                  (<a ytag="' . $ytagPrefix . '0" pos="'. ( $index + 201 ) .'" lg="1011" onclick="logStat.chkItem('. ( $index + 201 ) .','. $item['product_id'] .',\'\')"
	                  href="http://item.51buy.com/item-'.$item['product_id'].'.html#review_box" target="_blank">' . $item['review_count'] . '��</a>)</p>'
	                  : '<p class="comment">�������� (<a ytag="' . $ytagPrefix . '1"  onclick="logStat.chkItem('. ( $index + 201 ) .','. $item['product_id'] .',\'\')" pos="'.
	                  ( $index + 201 ) .'" lg="1012" href="http://item.51buy.com/review-toadddiscussion-'.$item['product_id'].'.html" target="_blank">������һ������</a>)</p>';

	        $product_title = strip_tags($item['name']);
			$product_title = empty($product_title) ? "" : htmlspecialchars($product_title, ENT_QUOTES);

			$str .='<li class="item '.$flag.'"><a ytag="' . $ytagPrefix . '2"  class="img_wrap" href="http://item.51buy.com/item-' . $item['product_id'] . '.html" target="_blank"><img src="' . IProduct::getPic($item['product_char_id'], 'pic160') . '" alt="' . $product_title . '" title="' . $product_title . '"></a>
                    <p class="name"><a ytag="' . $ytagPrefix . '3"  href="http://item.51buy.com/item-' . $item['product_id'] . '.html" target="_blank" title="' . $product_title . '">' . $item['name'] . '</a></p>
                    <p class="discount strong">' . $item['promotion_word'] . '</p>
                    <p class="price_wrap"><span class="i_price price_now">&yen;' . sprintf("%0.2f", $item['show_price'] / 100) . '</span> <del class="i_price">&yen;' . sprintf("%0.2f", $item['market_price'] / 100) . '</del></p>
                    '.$comment.'
                    <div class="layout_wrap">'
                    . ( $item['gift_count'] > 0 ? '
                    <div class="icon_wrap">
                    	<b class="logo_16x16 logo_gift" pid="' . $item['product_id'] . '"></b>
                        <div class="layout_popup">
                        <div class="layout_inner wrap_gifts"></div>
                        <div class="layout_arrow_bottom"> <span class="">��</span><i>��</i> </div>
                        </div></div>' : '')

                  .'</div>
                  </li>';
		}

		return $str;

	}

	public static function getJS($url, $needPrefix = true,  $charset = 'gb2312'){
		return '<script type="text/javascript" src="' . ( $needPrefix ? 'http://st.icson.com/static_v1/js/' : '') . $url . '" charset="' . $charset . '"></script>' . "\n";
	}

	public static function getCSS($url, $needPrefix = true){
		return '<link href="' . ( $needPrefix ? 'http://st.icson.com/static_v1/css/' : '') . $url . '" rel="stylesheet" type="text/css" />' . "\n";
	}

}

class BaseTPL extends Template {
	private $opt = array();

	public function setOpt($options){
		foreach ($options as $k => $option){
			$this->opt[$k] = $option;
		}
	}

	public function init($options = array()){
		parent::Template(ACT_PAGE_TPL_DIR, 'keep');

		$this->opt = $options;

		$headerTPLFile = 'header.tpl';
		if(!empty($this->opt['headerStyle'])){
			if($this->opt['headerStyle'] == 'none'){
				$headerTPLFile = 'header_none.tpl';
			} else if($this->opt['headerStyle'] == 'login'){
				$headerTPLFile = 'header_login.tpl';
			} else if($this->opt['headerStyle'] == 'min'){
				$headerTPLFile = 'header_min.tpl';
			}
		}

		$containerTPLFile = 'container.tpl';
		if(!empty($this->opt['containerTPL'])){
			$containerTPLFile = $this->opt['containerTPL'];
		}
		$this->set_var('cate_site', IUser::getCateClass());
		$shandiansongInfo = IUser::getShanDianSongInfo();
		$this->set_var('shandiansong_info_text', $shandiansongInfo['text']);
		$this->set_var('shandiansong_info_hover', $shandiansongInfo['hover']);
		$this->set_var('cod_desc', IUser::isCashOnDelivery() ? '' : 'stand_seven');
		
		$this->set_file(array(
			'baseHandler' => 'base.tpl',
			'headerHandler'	=> $headerTPLFile,
			'containerHandler' => $containerTPLFile,
			'footerHandler' => 'footer.tpl' //�ײ�
		));
	}

	/**
	 * ���or����ҳ������
	 * @param boolean $return �Ƿ񷵻ش���������HTML
	 * @return mixed false ��pparse���أ�html��parse������
	 */
	public function out($return = false){
		global $_WEBSITE_CFG;

		$this->parse('header', 'headerHandler');
		$this->parse('container', 'containerHandler');
		$this->parse('footer', 'footerHandler');

		$_siteId = IUser::getSiteIdWrapper(); //�人վ
		$baseVars = array(
			"header_css"	=> '<link href="http://st.icson.com/static_v1/css/header/header_full.css?v=[[V_CSS_HEADER_FULL]]" rel="stylesheet" type="text/css" />', // default
//			"i_contact_number" => isset($_WEBSITE_CFG[IUser::getSiteId()]) ? $_WEBSITE_CFG[IUser::getSiteId()]['contact_number'] : '',
			"i_contact_number" => isset($_WEBSITE_CFG[$_siteId]) ? $_WEBSITE_CFG[$_siteId]['contact_number'] : '', //�人վ
			"nav_list_str"  => $this->bNavList( !empty($this->opt['headerConfig'])? $this->opt['headerConfig'] : array() ),
			"wap_icson_enter" => (isset($_WEBSITE_CFG[IUser::getSiteIdWrapper()]) && ($_WEBSITE_CFG[IUser::getSiteIdWrapper()]['site_id'] == 1))?  '<li class="item"><a ytag="00007" href="http://act.51buy.com/promo-3105.html">�ֻ���Ѹ</a></li>': ''
		);

		if(!empty($this->opt['headerStyle'])){
			if($this->opt['headerStyle'] == 'none' || $this->opt['headerStyle'] == 'min'){
				$baseVars['header_css'] = '<link href="http://st.icson.com/static_v1/css/header/header_min.css?v=[[V_CSS_HEADER_MIN]]" rel="stylesheet" type="text/css" />';
			}
		}

		if(!empty($this->opt['titleDesc'])){
			$baseVars['title_desc'] = $this->opt['titleDesc'] . ' - ';
		} else {
			$baseVars['title_desc'] = '';
		}

		if(!empty($this->opt['cssFile'])){
			$baseVars['css_file'] = '<link href="' . $this->opt['cssFile'] . '" rel="stylesheet" type="text/css" />';
		} else {
			$baseVars['css_file'] = '';
		}

		if(!empty($this->opt['before_body'])){
			$baseVars['before_body'] = $this->opt['before_body'];
		} else {
			$baseVars['before_body'] = '';
		}

		$pageIdInfo = ToolUtil::getCurrentPageId();
		$baseVars['yPageId'] = $pageIdInfo['yPageId'];
		$baseVars['yPageLevel'] = $pageIdInfo['yPageLevel'];
		$this->set_var($baseVars);

		return ($return) ? $this->parse("output", "baseHandler") : $this->pparse("output", "baseHandler");
	}


	//�����̵���
	public function bNavList($opt = array()) {
		$str = '';
		$opt = is_array($opt) ? $opt : array();
		$currentPage = isset($opt['currentPage'])? $opt['currentPage'] : '';
		$currentPage = $currentPage == 'nav_distributor' && in_array($_SERVER['PHP_SELF'], array('/', '/index.html')) ? 'nav_distributor_b' : '';
		
		$CONFIG = array(
			array( 'label' => '��ͻ���ҳ', 'id' => 'nav_distributor_b', 'href' => 'http://b.51buy.com', 'hotName' => 'I.NAV.HOME.B', 'ytag' => '04100'),
			array( 'label' => '�칫�ر�', 'id' => 'nav_office_b', 'href' => 'http://event.51buy.com/event/478cfee.html', 'hotName' => 'I.NAV.OFFICE.B', 'ytag' => '04101'),
			array( 'label' => 'Ա������', 'id' => 'nav_employee_b', 'href' => 'http://event.51buy.com/event/4819461.html', 'hotName' => 'I.NAV.EMPLOYEE.B', 'ytag' => '04102'),
			array( 'label' => '��Ʒ����', 'id' => 'nav_gift_b', 'href' => 'http://event.51buy.com/event/479d18f.html', 'hotName' => 'I.NAV.GIFT.B', 'ytag' => '04103'),
		);

		foreach ($CONFIG as $index => $item) {
			$str .= '<li' . ($item['id'] === $currentPage ? ' class="current"' : '')
				. ' id="' . $item['id'] . '"><a href="' . $item['href'] . '"' . ($item['ytag'] ? ' ytag="' . $item['ytag'] . '"' : '') . '>'
				. $item['label'] .  "</a></li>\n";
		}

		return $str;
	}

}
// End Of Script