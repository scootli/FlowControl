<?php

class ICouponFlow {

	public static $topicId = 7409;	// topic id in MsqQ
	public static $producerName = 'coupon_test';

	public static $consumerId = 70190;

	// 流水类型
	const FLOW_TYPE_COUPON	= 0;
	const FLOW_TYPE_BATCH	= 1;

	// 优惠券操作类型
	const COUPON_OP_TYPE_FETCH  = 0; // 领取
	const COUPON_OP_TYPE_USE    = 1; // 使用
	const COUPON_OP_TYPE_RETURN = 2; // 返还
	const COUPON_OP_TYPE_CHECK	= 3; // 批价
	const COUPON_OP_TYPE_INVALID= 4; // 作废

	// 优惠券操作来源
	const COUPON_OP_SRC_USER	= 0;	// 用户
	const COUPON_OP_SRC_CS		= 1;	// 客服
	const COUPON_OP_SRC_SYSTEM	= 2;	// 系统
	const COUPON_OP_SRC_SINGLE	= 3;	// 单品返券
	const COUPON_OP_SRC_FULL	= 4;	// 满赠券

	// 批次操作类型
	const BATCH_OP_TYPE_CREATE	= 0;	// 生成
	const BATCH_OP_TYPE_ACTIVE	= 1;	// 激活
	const BATCH_OP_TYPE_INVALID = 2;	// 作废
	const BATCH_OP_TYPE_MODIFY	= 3;	// 修改

	/**
	 * 写优惠券流水
	 * array(
	 *		'coupon_code' => 
	 *		'batch'	=>
	 *		'coupon_type' =>
	 *		'op_type' =>
	 *		'op_src'	=>
	 *		'uid'		=>
	 *		'ip'	=>
	 *		'op_user' =>
	 *		'order_id'=>
	 *		'order_status'=>
	 *		'comment'=>
	 * )
	 */
	public static function writeCouponFlow($param){
		return self::writeFlow($param, self::FLOW_TYPE_COUPON);
	}

	/**
	 * 写批次流水
	 * array(
	 *		'batch'	=>
	 *		'coupon_type' =>
	 *		'coupon_code' =>
	 *		'coupon_name' =>
	 *		'op_type' =>
	 *		'op_user' =>
	 *		'value' =>
	 *		'comment'=>
	 * )
	 */
	public static function writeBatchFlow($param){
		return self::writeFlow($param, self::FLOW_TYPE_BATCH);
	}

	public static function writeFlow($param, $type){
		$op_time = empty($_SERVER['REQUEST_TIME']) ? '' : $_SERVER['REQUEST_TIME'];
		$ip = ToolUtil::getClientIP();
		$user_agent = empty($_SERVER['HTTP_USER_AGENT']) ? '' : $_SERVER['HTTP_USER_AGENT'];
		$uri = empty($_SERVER['REQUEST_URI']) ? '' : $_SERVER['REQUEST_URI'];
		$referer = empty($_SERVER['HTTP_REFERER']) ? '' : $_SERVER['HTTP_REFERER'];
		$visitkey = empty($_COOKIE['visitkey']) ? '' : $_COOKIE['visitkey'];
		$server_ip = empty($_SERVER['SERVER_ADDR']) ? '' : $_SERVER['SERVER_ADDR'];
		$param['op_time'] = $op_time;
		$param['ip'] = $ip;
		$param['user_agent'] = $user_agent;
		$param['uri'] = $uri;
		$param['referer'] = $referer;
		$param['visitkey'] = $visitkey;
		$param['server_ip'] = $server_ip;

		$flow = array(
				'type' => $type,
				'data' => $param
			);

		$msg = ToolUtil::gbJsonEncode($flow);
		$ret = MsgQV5::send(self::$topicId, self::$producerName, $msg);
		if ($ret === false) {
			Logger::err('msgq extension not exist');
		}else{
			Logger::err(var_export($ret, true));
		}
	}

	public static function getCouponFlow($coupon_code){
		$db = Config::getDB('coupon_flow');
		if ($db === false) {
			Logger::err('get coupon flow db failed, errCode: ' . Config::$errCode . ' errMsg: ' . Config::$errMsg);
			return false;
		}

		$sql = "select * from t_coupon_flow where coupon_code = '" . $coupon_code . "'";
		$ret = $db->getRows($sql);
		if ($ret === false) {
			Logger::err('select coupon flow record failed, errCode: ' . $db->errCode . ' errMsg: ' . $db->errMsg);
			return false;
		}

		return $ret;
	}

	public static function getBatchFlow($batchno){
		$db = Config::getDB('coupon_flow');
		if ($db === false) {
			Logger::err('get coupon flow db failed, errCode: ' . Config::$errCode . ' errMsg: ' . Config::$errMsg);
			return false;
		}

		$sql = 'select * from t_batch_flow where batch = ' . $batchno;
		$ret = $db->getRows($sql);
		if ($ret === false) {
			Logger::err('select batch flow record failed, errCode: ' . $db->errCode . ' errMsg: ' . $db->errMsg);
			return false;
		}

		return $ret;
	}
}
