<?php
/**
 * 消息中心biz设置
 *
 * @author rongxu
 */
class ISmsBizs {
	
	const Price_Record = 2;

}