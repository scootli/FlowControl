<?php
class ILoveCarBiz{
	private $ILoveCar;
	public function __construct($sql='SET NAMES UTF8'){
		$this->ILoveCar=new ILoveCar($sql);
	}

	/**
	*通过车型年款获取与之关联的保养项数量
	*@param $styleId 年款ID
	**/
	public function getValidMaintainCount($styleId){
		$sql='SELECT count(*) AS total FROM `car_maintain_category` WHERE style_id='.$styleId.' AND status=1';
		$row=$this->ILoveCar->getRow($sql);
		return $row['total'];
	}

	/**
	*获取当前保养间隔的下一次保养项
	*@param $styleId int 车年款
	*@param $miles int 当前已行驶公里数
	**/
	public function getNextMaintainItems($styleId,$miles){
		$sql='SELECT id,miles FROM `car_maintain_interval` WHERE style_id='.$styleId.' AND miles>'.$miles.' ORDER BY miles ASC LIMIT 1';
		$rs=array();
		$row=$this->ILoveCar->getRow($sql);
		if($row){
			$itvId=$row['id'];
			$sql='SELECT cat_id FROM `car_maintain_category` WHERE itv_id='.$itvId.' AND status=1 ORDER BY sort DESC';
			$rs[$row['miles']]=$this->ILoveCar->getRows($sql);
		}
		return $rs;
	}


	/**
	*通过车型年款，类目获取关联的品类与属性、属性值相关信息
	**/
	public function getAssocPropertyValues($styleId,$catId){
		$sql='SELECT ccat_id,prop_id,pval_id FROM `car_property_values` WHERE style_id='.$styleId.' AND cat_id='.$catId.' AND status=1';
		$key='car_property_values_getpvals_'.$styleId.'_'.$catId;
		$data=$this->getData($key);
		if(empty($data)){
			$data=$this->ILoveCar->getRows($sql);
			if($data){
				$this->setData($key, $data,600);
			}
		}
		return $data;
	}

	/**
	*读取所有的类目信息
	**/
	public function getCustomCategories(){
		$key='product_category_getall';
		$data=$this->getData($key);
		if(empty($data)){
			$sql='SELECT id,name,cat_id FROM `product_category` WHERE status=1 ORDER BY sort ASC';
		 	$data=$this->ILoveCar->getRows($sql);
		 	if($data){
		 		$this->setData($key, $data,3600);
		 	}
		}
		return $data;
		
	}

	/**
	*读取该车型在行驶到特定的公里数时应当进行养护的类目
	**/
	public function getPrdCategoriesByStyleMiles($styleId,$miles){
		$sql='SELECT id FROM `car_maintain_interval` WHERE style_id='.$styleId;
		$sql.=' AND miles<='.$miles.' ORDER BY miles DESC LIMIT 1';
		$rs=array();
		$row=$this->ILoveCar->getRow($sql);
		if($row){
			$itvId=$row['id'];
			$sql='SELECT cat_id FROM `car_maintain_category` WHERE itv_id='.$itvId.' AND status=1 ORDER BY sort DESC';
			$rs=$this->ILoveCar->getRows($sql);
		}
		return $rs;
	}

	public function getTabItemsContent($tabId){
		$result=array();
		//get title
		$key='lovecar_maintain_subject_catid_'.$tabId;
		$data=$this->getData($key);
		if(empty($data)){
			$sql='SELECT id,s_title,m_title FROM `maintain_subject`  WHERE cat_id='.$tabId.' ORDER BY sort ASC';
			$data=$this->ILoveCar->getRows($sql);
			if($data){
				$this->setData($key,$data,1800);
			}
		}
		if($data){
			foreach($data as $row){
				$catId=$row['id'];
				$key='lovecar_maintain_content_catid_'.$catId;
				$rt=$this->getData($key);
				if(empty($rt)){
					$sql='SELECT title,url FROM `maintain_content` WHERE cat_id='.$row['id'];
					$rt=$this->ILoveCar->getRows($sql);
					if($rt){
						$this->setData($key,$rt,1800);
					}
				}
				$result[$catId]=array('p'=>$row,'s'=>$rt);
			}
		}
		return $result;
	}

	/**
	*获取推荐保养套餐
	**/
	public function getRecommendMeal($catId,$groupId,$limit=3){
		$key='lovecar_car_recommend_meal'.$catId.'_'.$groupId.'_'.$limit;
		$data=$this->getData($key);
		if(empty($data)){
			$sql='SELECT * FROM `car_recommend_meal` WHERE cat_id='.$catId.' AND group_id='.$groupId.' ORDER BY sort ASC LIMIT '.$limit;
			$data=$this->ILoveCar->getRows($sql);
			if($data){
				$this->setData($key, $data,3600);
			}
		}
		return $data;
	}

	/**
	*获取自定义的热门品牌
	*@deprecated
	**/
	public function getCustomHotsBrand(){
		return array(
			array('id'=>57,'name'=>'大众','icon'=>''),
			array('id'=>61,'name'=>'别克','icon'=>''),
			array('id'=>62,'name'=>'雪佛兰','icon'=>''),
			array('id'=>58,'name'=>'斯柯达','icon'=>''),
			array('id'=>7,'name'=>'福特','icon'=>''),
			array('id'=>80,'name'=>'丰田','icon'=>''),
			array('id'=>21,'name'=>'日产','icon'=>''),
			array('id'=>29,'name'=>'本田','icon'=>''),
			array('id'=>9,'name'=>'马自达','icon'=>''),
		);
	}

	public function delUserCar($uid,$styleId){
		$sql='UPDATE `car_user` SET status=0 WHERE uid='.$uid.' AND style_id='.$styleId;
		return $this->ILoveCar->update($sql);
	}

	//通过年款获取该车的详细信息
	public function getStyleInfo($styleId){
		$key='lovecar_car_style_list1_'.$styleId.'_all_info';
		$data=$this->getData($key);
		if(empty($data)){
			$tableName='`car_style_list`';
			$data=array();
			$sql='SELECT parent_id,name FROM '.$tableName.' WHERE level=4 AND sys_no='.$styleId;
			$row=$this->ILoveCar->getRow($sql);
			if(empty($row)){
				return $data;
			}
			$data['styleId']=array('id'=>$styleId,'name'=>$row['name']);
			$parentId=$row['parent_id'];
			$sql='SELECT parent_id,name FROM '.$tableName.' WHERE level=3 AND sys_no='.$parentId;
			$row=$this->ILoveCar->getRow($sql);
			if(empty($row)){
				return $data;
			}
			$data['dspId']=array('id'=>$parentId,'name'=>$row['name']);
			$parentId=$row['parent_id'];
			$sql='SELECT parent_id,name FROM '.$tableName.' WHERE level=2 AND sys_no='.$parentId;
			$row=$this->ILoveCar->getRow($sql);
			if(empty($row)){
				return $data;
			}
			$data['typeId']=array('id'=>$parentId,'name'=>$row['name']);
			$parentId=$row['parent_id'];
			$sql='SELECT name FROM '.$tableName.' WHERE level=1 AND sys_no='.$parentId;
			$row=$this->ILoveCar->getRow($sql);
			if(empty($row)){
				return $data;
			}
			$data['brandId']=array('id'=>$parentId,'name'=>$row['name']);
			$this->setData($key,$data,21600);
		}
		return $data;
	}
	//获取用户的车型
	public function getUserCars($userId){
		$sql='SELECT * FROM `car_user` WHERE uid='.$userId.' AND status=1';
		return $this->ILoveCar->getRows($sql);
	}

	public function getImagesUrl($ids){
		$sql='SELECT id,host_id,filename FROM `file_list` WHERE id IN('.implode(',',$ids).')';
		$rows=$this->ILoveCar->getRows($sql);
		$rt=array();
		if($rows){
			$hostList=array(2=>'img2.icson.com',3=>'img3.icson.com');
			foreach($rows as $row){
				$rt[$row['id']]=sprintf('http://%s/lovecar/%s',$hostList[$row['host_id']],$row['filename']);
			}
		}
		return $rt;
	}

	/**
	* 获取合作品牌
	**/
	public function getCorpList(){
		$key='lovecar_maintain_content_list_9999';
		$data=$this->getData($key);
		if(empty($data)){
			$sql='SELECT * FROM `maintain_content` WHERE cat_id=9999 AND status=1 ORDER BY sort ASC';
			$data=$this->ILoveCar->getRows($sql);
			$this->setData($key,$data,3600);
		}
		return $data;
	}

	public function getItemList($level,$parentId){
		$key='car_style_list_'.$level.'_'.$parentId;
		$data=$this->getData($key);
		if(empty($data)){
			$sql='SELECT sys_no,name FROM `car_style_list` WHERE level='.$level.' AND parent_id='.$parentId .' AND status=1 ORDER BY sort ASC';
			$data=$this->ILoveCar->getRows($sql);
			if($data){
				$this->setData($key, $data,3600);
			}
		}
		return $data;
	}

	public function addUserCar($data){
		$this->ILoveCar->insertOrUpdate($data,array('status'=>1),'car_user');
	}

	public function getUserCarByStyleId($uid,$styleId){
		$sql='SELECT id FROM `car_user` WHERE uid='.$uid.' AND style_id='.$styleId.' LIMIT 1';
		return $this->ILoveCar->getRow($sql);
	}

	public function getUserCarsNumber($uid){
		$uid=intval($uid);
		if(empty($uid)){
			return FALSE;
		}
		$sql='SELECT COUNT(*) as total FROM `car_user` WHERE uid='.$uid.' AND status=1';
		$row=$this->ILoveCar->getRow($sql);
		return $row['total'];
	}

	//获取品牌车系列表
	public function getBrandList(){
		$tableName='`car_style_list`';
		$result=array();
		$sql='SELECT sys_no,name,image_id FROM '.$tableName.' WHERE level=1 AND status=1 AND image_id>0 ORDER BY name ASC';
		$rows1=$this->ILoveCar->getRows($sql);
		if($rows1){
			$brandIds=array();
			foreach($rows1 as $row){
				$sysNo=$row['sys_no'];
				$brandIds[]=$sysNo;
				$icon_urls=$this->getImagesUrl((array)$row['image_id']);
				$result[$sysNo]['img_url']=array_pop($icon_urls);
				$result[$sysNo]['p']=$row['name'];
			}
			$sql='SELECT name,sys_no,parent_id FROM '.$tableName.' WHERE level=2 AND status=1 AND parent_id IN('.implode(',',$brandIds).')';
			$rows2=$this->ILoveCar->getRows($sql);
			if($rows2){
				foreach($rows2 as $row){
					$parentId=$row['parent_id'];
					$result[$parentId]['s'][]=$row;
				}
			}
		}
		return $result;
	}

	//获取用户关联车的最后记录行驶里程数
	public function getLastRecord4UserCar($carId){
		$sql='SELECT * FROM `car_run_mile` WHERE car_id='.$carId.' ORDER BY created DESC LIMIT 1';
		return $this->ILoveCar->getRow($sql);
	}
	//添加当日里程
	public function addRecordMile($data){
		return $this->ILoveCar->insertRow($data,'car_run_mile');
	}

	//获取当日记录列表
	public function getRecordMileList($carId,$limit){
		$sql='SELECT * FROM `car_run_mile` WHERE car_id='.$carId.' ORDER BY created DESC LIMIT '.$limit;
		return $this->ILoveCar->getRows($sql);
	}

	/**
	*设置数据缓存
	*@param $key string
	*@param $data mixded
	*@param $time int seconds for cache,default 1 month
	**/
	public function setData($key,$data,$time=25923000){
		if($key&&$data){
			$cacheKey=md5($key);
			$timestamp=time()+intval($time);
			$cacheObj=serialize(array('d'=>$data,'t'=>$timestamp));
			return IDataCache::setData($cacheKey,$cacheObj);
		}
		return FALSE;
	}

	/**
	*通过key获取缓存数据
	*@param $key string
	*/
	public function getData($key){
		if($key){
			$cacheKey=md5($key);
			$rt=IDataCache::getData($cacheKey);
			if($rt!==FALSE){
				$data=unserialize($rt);
				$timestamp=$data['t'];
				if($timestamp>time()){
					return $data['d'];
				}
				IDataCache::delData($cacheKey);
			}
			return FALSE;
		}
		return FALSE;
	}

}