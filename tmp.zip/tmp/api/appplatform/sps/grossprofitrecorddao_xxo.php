<?php

//source idl: com.icson.grossprofitcontrol.idl.UpdateRecordReq.java

if (!class_exists('GrossProfitControlRecord_Bo')) {
class GrossProfitControlRecord_Bo
{
		/**
		 *  �汾��   
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * Id  ��¼id
		 *
		 * 版本 >= 0
		 */
		var $ddwId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cId_u; //uint8_t

		/**
		 * businessId
		 *
		 * 版本 >= 0
		 */
		var $ddwBusinessId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cBusinessId_u; //uint8_t

		/**
		 * skuid  
		 *
		 * 版本 >= 0
		 */
		var $ddwSkuId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cSkuId_u; //uint8_t

		/**
		 * �۸����ͣ�1:һ�����ۣ�2:��������ۣ�3:��Ա�ۣ�4���ݼ�
		 *
		 * 版本 >= 0
		 */
		var $dwPriceType; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cPriceType_u; //uint8_t

		/**
		 * ���� id
		 *
		 * 版本 >= 0
		 */
		var $dwRegionId; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cRegionId_u; //uint8_t

		/**
		 * ���� id
		 *
		 * 版本 >= 0
		 */
		var $ddwPriceSceneId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cPriceSceneId_u; //uint8_t

		/**
		 * ��Դ id
		 *
		 * 版本 >= 0
		 */
		var $ddwPriceSourceId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cPriceSourceId_u; //uint8_t

		/**
		 * product_id
		 *
		 * 版本 >= 0
		 */
		var $strProductId; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cProductId_u; //uint8_t

		/**
		 * product_name
		 *
		 * 版本 >= 0
		 */
		var $strProductName; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cProductName_u; //uint8_t

		/**
		 * ���ܲ���
		 *
		 * 版本 >= 0
		 */
		var $dwEnerySavePrice; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cEnerySavePrice_u; //uint8_t

		/**
		 * ������ݹ���
		 *
		 * 版本 >= 0
		 */
		var $strLadderNumRule; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cLadderNumRule_u; //uint8_t

		/**
		 * �������
		 *
		 * 版本 >= 0
		 */
		var $strPriceRuleName; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cPriceRuleName_u; //uint8_t

		/**
		 * ����URL
		 *
		 * 版本 >= 0
		 */
		var $strPriceRuleUrl; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cPriceRuleUrl_u; //uint8_t

		/**
		 * �ID�б�
		 *
		 * 版本 >= 0
		 */
		var $strActiveIdList; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cActiveIdList_u; //uint8_t

		/**
		 * EDMID�б�
		 *
		 * 版本 >= 0
		 */
		var $strEdmIdList; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cEdmIdList_u; //uint8_t

		/**
		 * �۸�����
		 *
		 * 版本 >= 0
		 */
		var $strPriceDesc; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cPriceDesc_u; //uint8_t

		/**
		 * ���򴴽���
		 *
		 * 版本 >= 0
		 */
		var $strPriceRuleCreator; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cPriceRuleCreator_u; //uint8_t

		/**
		 * �ɱ���̯��
		 *
		 * 版本 >= 0
		 */
		var $dwPriceCoster; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cPriceCoster_u; //uint8_t

		/**
		 * ��Ӫ��ۣ����ռ۸�
		 *
		 * 版本 >= 0
		 */
		var $dwSpsMultPrice; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cSpsMultPrice_u; //uint8_t

		/**
		 * ��۵Ļ�׼��
		 *
		 * 版本 >= 0
		 */
		var $dwPriceBase; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cPriceBase_u; //uint8_t

		/**
		 * �ÿ���Ʒ�ŻݵĽ��
		 *
		 * 版本 >= 0
		 */
		var $dwPriceDiscount; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cPriceDiscount_u; //uint8_t

		/**
		 * priceCost �ɱ��� 
		 *
		 * 版本 >= 0
		 */
		var $dwPriceCost; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cPriceCost_u; //uint8_t

		/**
		 * �Ż����� 1:�ۿ� 2������ 3������
		 *
		 * 版本 >= 0
		 */
		var $dwFavorType; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cFavorType_u; //uint8_t

		/**
		 * �Ż���
		 *
		 * 版本 >= 0
		 */
		var $dwFavorValue; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cFavorValue_u; //uint8_t

		/**
		 * ��ʱ��ۿ�ʼʱ��
		 *
		 * 版本 >= 0
		 */
		var $dwStartTime; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cStartTime_u; //uint8_t

		/**
		 * ��ʱ��۽���ʱ��
		 *
		 * 版本 >= 0
		 */
		var $dwEndTime; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cEndTime_u; //uint8_t

		/**
		 *  timedPrice index �Ϸ�ֵΪ1-10�����֧��10��timefield������ ����coss���5��(1-5)���û�5�� 10�������� TODO:
		 *
		 * 版本 >= 0
		 */
		var $wTimedPriceIndex; //uint16_t

		/**
		 * 版本 >= 0
		 */
		var $cTimedPriceIndex_u; //uint8_t

		/**
		 * ���òֿ⣬��ʽ����
		 *
		 * 版本 >= 0
		 */
		var $strPriceStoreHouse; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cPriceStoreHouse_u; //uint8_t

		/**
		 * ��ݹ���
		 *
		 * 版本 >= 0
		 */
		var $strPriceUserIdentityRule; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cPriceUserIdentityRule_u; //uint8_t

		/**
		 * ��۹���������� 0-���� 1-�޸�
		 *
		 * 版本 >= 0
		 */
		var $wOperType; //uint16_t

		/**
		 * 版本 >= 0
		 */
		var $cOperType_u; //uint8_t

		/**
		 * ����ԭ��
		 *
		 * 版本 >= 0
		 */
		var $strReason; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cReason_u; //uint8_t

		/**
		 * �������� 0 �������� 1 �߼����� 2 �м����� 3 ��������
		 *
		 * 版本 >= 0
		 */
		var $cTypeApprovel; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cTypeApprovel_u; //uint8_t

		/**
		 * ������
		 *
		 * 版本 >= 0
		 */
		var $strApprover; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cApprover_u; //uint8_t

		/**
		 * ����������
		 *
		 * 版本 >= 0
		 */
		var $strApproverBak; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cApproverBak_u; //uint8_t

		/**
		 * ��λ���������� 0 ���������� 1 �������� 2 ����������
		 *
		 * 版本 >= 0
		 */
		var $cWhoApprovaled; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cWhoApprovaled_u; //uint8_t

		/**
		 * ������/״̬ 0 ����� 1 �����  2 ��˲�ͨ��  3 ��ֹ 4 ɾ��
		 *
		 * 版本 >= 0
		 */
		var $wApprovalState; //uint16_t

		/**
		 * 版本 >= 0
		 */
		var $cApprovalState_u; //uint8_t

		/**
		 * ����������
		 *
		 * 版本 >= 0
		 */
		var $strApproverDesc; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cApproverDesc_u; //uint8_t

		/**
		 * ��¼���ʱ��
		 *
		 * 版本 >= 0
		 */
		var $dwTimeInsert; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cTimeInsert_u; //uint8_t

		/**
		 * ��������ʱ��
		 *
		 * 版本 >= 0
		 */
		var $dwTimeApply; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cTimeApply_u; //uint8_t

		/**
		 * ����������ʱ��
		 *
		 * 版本 >= 0
		 */
		var $dwTimeApprovaled; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cTimeApprovaled_u; //uint8_t

		/**
		 * ��ֹ��
		 *
		 * 版本 >= 0
		 */
		var $strStopper; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cStopper_u; //uint8_t

		/**
		 * ��ֹʱ��
		 *
		 * 版本 >= 0
		 */
		var $dwTimeStop; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cTimeStop_u; //uint8_t

		/**
		 * ��ֹԭ������
		 *
		 * 版本 >= 0
		 */
		var $strStopDesc; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cStopDesc_u; //uint8_t

		/**
		 * ��record״̬ 0 ������״̬ 1 ����״̬
		 *
		 * 版本 >= 0
		 */
		var $cRecordState; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cRecordState_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->cVersion_u = 0; // uint8_t
			 $this->ddwId = 0; // uint64_t
			 $this->cId_u = 0; // uint8_t
			 $this->ddwBusinessId = 0; // uint64_t
			 $this->cBusinessId_u = 0; // uint8_t
			 $this->ddwSkuId = 0; // uint64_t
			 $this->cSkuId_u = 0; // uint8_t
			 $this->dwPriceType = 0; // uint32_t
			 $this->cPriceType_u = 0; // uint8_t
			 $this->dwRegionId = 0; // uint32_t
			 $this->cRegionId_u = 0; // uint8_t
			 $this->ddwPriceSceneId = 0; // uint64_t
			 $this->cPriceSceneId_u = 0; // uint8_t
			 $this->ddwPriceSourceId = 0; // uint64_t
			 $this->cPriceSourceId_u = 0; // uint8_t
			 $this->strProductId = ""; // std::string
			 $this->cProductId_u = 0; // uint8_t
			 $this->strProductName = ""; // std::string
			 $this->cProductName_u = 0; // uint8_t
			 $this->dwEnerySavePrice = 0; // uint32_t
			 $this->cEnerySavePrice_u = 0; // uint8_t
			 $this->strLadderNumRule = ""; // std::string
			 $this->cLadderNumRule_u = 0; // uint8_t
			 $this->strPriceRuleName = ""; // std::string
			 $this->cPriceRuleName_u = 0; // uint8_t
			 $this->strPriceRuleUrl = ""; // std::string
			 $this->cPriceRuleUrl_u = 0; // uint8_t
			 $this->strActiveIdList = ""; // std::string
			 $this->cActiveIdList_u = 0; // uint8_t
			 $this->strEdmIdList = ""; // std::string
			 $this->cEdmIdList_u = 0; // uint8_t
			 $this->strPriceDesc = ""; // std::string
			 $this->cPriceDesc_u = 0; // uint8_t
			 $this->strPriceRuleCreator = ""; // std::string
			 $this->cPriceRuleCreator_u = 0; // uint8_t
			 $this->dwPriceCoster = 0; // uint32_t
			 $this->cPriceCoster_u = 0; // uint8_t
			 $this->dwSpsMultPrice = 0; // uint32_t
			 $this->cSpsMultPrice_u = 0; // uint8_t
			 $this->dwPriceBase = 0; // uint32_t
			 $this->cPriceBase_u = 0; // uint8_t
			 $this->dwPriceDiscount = 0; // uint32_t
			 $this->cPriceDiscount_u = 0; // uint8_t
			 $this->dwPriceCost = 0; // uint32_t
			 $this->cPriceCost_u = 0; // uint8_t
			 $this->dwFavorType = 0; // uint32_t
			 $this->cFavorType_u = 0; // uint8_t
			 $this->dwFavorValue = 0; // uint32_t
			 $this->cFavorValue_u = 0; // uint8_t
			 $this->dwStartTime = 0; // uint32_t
			 $this->cStartTime_u = 0; // uint8_t
			 $this->dwEndTime = 0; // uint32_t
			 $this->cEndTime_u = 0; // uint8_t
			 $this->wTimedPriceIndex = 0; // uint16_t
			 $this->cTimedPriceIndex_u = 0; // uint8_t
			 $this->strPriceStoreHouse = ""; // std::string
			 $this->cPriceStoreHouse_u = 0; // uint8_t
			 $this->strPriceUserIdentityRule = ""; // std::string
			 $this->cPriceUserIdentityRule_u = 0; // uint8_t
			 $this->wOperType = 0; // uint16_t
			 $this->cOperType_u = 0; // uint8_t
			 $this->strReason = ""; // std::string
			 $this->cReason_u = 0; // uint8_t
			 $this->cTypeApprovel = 0; // uint8_t
			 $this->cTypeApprovel_u = 0; // uint8_t
			 $this->strApprover = ""; // std::string
			 $this->cApprover_u = 0; // uint8_t
			 $this->strApproverBak = ""; // std::string
			 $this->cApproverBak_u = 0; // uint8_t
			 $this->cWhoApprovaled = 0; // uint8_t
			 $this->cWhoApprovaled_u = 0; // uint8_t
			 $this->wApprovalState = 0; // uint16_t
			 $this->cApprovalState_u = 0; // uint8_t
			 $this->strApproverDesc = ""; // std::string
			 $this->cApproverDesc_u = 0; // uint8_t
			 $this->dwTimeInsert = 0; // uint32_t
			 $this->cTimeInsert_u = 0; // uint8_t
			 $this->dwTimeApply = 0; // uint32_t
			 $this->cTimeApply_u = 0; // uint8_t
			 $this->dwTimeApprovaled = 0; // uint32_t
			 $this->cTimeApprovaled_u = 0; // uint8_t
			 $this->strStopper = ""; // std::string
			 $this->cStopper_u = 0; // uint8_t
			 $this->dwTimeStop = 0; // uint32_t
			 $this->cTimeStop_u = 0; // uint8_t
			 $this->strStopDesc = ""; // std::string
			 $this->cStopDesc_u = 0; // uint8_t
			 $this->cRecordState = 0; // uint8_t
			 $this->cRecordState_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化 �汾��    类型为uint32_t
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwId); // 序列化Id  ��¼id 类型为uint64_t
			$bs->pushUint8_t($this->cId_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwBusinessId); // 序列化businessId 类型为uint64_t
			$bs->pushUint8_t($this->cBusinessId_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwSkuId); // 序列化skuid   类型为uint64_t
			$bs->pushUint8_t($this->cSkuId_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwPriceType); // 序列化�۸����ͣ�1:һ�����ۣ�2:��������ۣ�3:��Ա�ۣ�4���ݼ� 类型为uint32_t
			$bs->pushUint8_t($this->cPriceType_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwRegionId); // 序列化���� id 类型为uint32_t
			$bs->pushUint8_t($this->cRegionId_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwPriceSceneId); // 序列化���� id 类型为uint64_t
			$bs->pushUint8_t($this->cPriceSceneId_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwPriceSourceId); // 序列化��Դ id 类型为uint64_t
			$bs->pushUint8_t($this->cPriceSourceId_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strProductId); // 序列化product_id 类型为std::string
			$bs->pushUint8_t($this->cProductId_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strProductName); // 序列化product_name 类型为std::string
			$bs->pushUint8_t($this->cProductName_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwEnerySavePrice); // 序列化���ܲ��� 类型为uint32_t
			$bs->pushUint8_t($this->cEnerySavePrice_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strLadderNumRule); // 序列化������ݹ��� 类型为std::string
			$bs->pushUint8_t($this->cLadderNumRule_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strPriceRuleName); // 序列化������� 类型为std::string
			$bs->pushUint8_t($this->cPriceRuleName_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strPriceRuleUrl); // 序列化����URL 类型为std::string
			$bs->pushUint8_t($this->cPriceRuleUrl_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strActiveIdList); // 序列化�ID�б� 类型为std::string
			$bs->pushUint8_t($this->cActiveIdList_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strEdmIdList); // 序列化EDMID�б� 类型为std::string
			$bs->pushUint8_t($this->cEdmIdList_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strPriceDesc); // 序列化�۸����� 类型为std::string
			$bs->pushUint8_t($this->cPriceDesc_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strPriceRuleCreator); // 序列化���򴴽��� 类型为std::string
			$bs->pushUint8_t($this->cPriceRuleCreator_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwPriceCoster); // 序列化�ɱ���̯�� 类型为uint32_t
			$bs->pushUint8_t($this->cPriceCoster_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwSpsMultPrice); // 序列化��Ӫ��ۣ����ռ۸� 类型为uint32_t
			$bs->pushUint8_t($this->cSpsMultPrice_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwPriceBase); // 序列化��۵Ļ�׼�� 类型为uint32_t
			$bs->pushUint8_t($this->cPriceBase_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwPriceDiscount); // 序列化�ÿ���Ʒ�ŻݵĽ�� 类型为uint32_t
			$bs->pushUint8_t($this->cPriceDiscount_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwPriceCost); // 序列化priceCost �ɱ���  类型为uint32_t
			$bs->pushUint8_t($this->cPriceCost_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwFavorType); // 序列化�Ż����� 1:�ۿ� 2������ 3������ 类型为uint32_t
			$bs->pushUint8_t($this->cFavorType_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwFavorValue); // 序列化�Ż��� 类型为uint32_t
			$bs->pushUint8_t($this->cFavorValue_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwStartTime); // 序列化��ʱ��ۿ�ʼʱ�� 类型为uint32_t
			$bs->pushUint8_t($this->cStartTime_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwEndTime); // 序列化��ʱ��۽���ʱ�� 类型为uint32_t
			$bs->pushUint8_t($this->cEndTime_u); // 序列化 类型为uint8_t
			$bs->pushUint16_t($this->wTimedPriceIndex); // 序列化 timedPrice index �Ϸ�ֵΪ1-10�����֧��10��timefield������ ����coss���5��(1-5)���û�5�� 10�������� TODO: 类型为uint16_t
			$bs->pushUint8_t($this->cTimedPriceIndex_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strPriceStoreHouse); // 序列化���òֿ⣬��ʽ���� 类型为std::string
			$bs->pushUint8_t($this->cPriceStoreHouse_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strPriceUserIdentityRule); // 序列化��ݹ��� 类型为std::string
			$bs->pushUint8_t($this->cPriceUserIdentityRule_u); // 序列化 类型为uint8_t
			$bs->pushUint16_t($this->wOperType); // 序列化��۹���������� 0-���� 1-�޸� 类型为uint16_t
			$bs->pushUint8_t($this->cOperType_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strReason); // 序列化����ԭ�� 类型为std::string
			$bs->pushUint8_t($this->cReason_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cTypeApprovel); // 序列化�������� 0 �������� 1 �߼����� 2 �м����� 3 �������� 类型为uint8_t
			$bs->pushUint8_t($this->cTypeApprovel_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strApprover); // 序列化������ 类型为std::string
			$bs->pushUint8_t($this->cApprover_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strApproverBak); // 序列化���������� 类型为std::string
			$bs->pushUint8_t($this->cApproverBak_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cWhoApprovaled); // 序列化��λ���������� 0 ���������� 1 �������� 2 ���������� 类型为uint8_t
			$bs->pushUint8_t($this->cWhoApprovaled_u); // 序列化 类型为uint8_t
			$bs->pushUint16_t($this->wApprovalState); // 序列化������/״̬ 0 ����� 1 �����  2 ��˲�ͨ��  3 ��ֹ 4 ɾ�� 类型为uint16_t
			$bs->pushUint8_t($this->cApprovalState_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strApproverDesc); // 序列化���������� 类型为std::string
			$bs->pushUint8_t($this->cApproverDesc_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwTimeInsert); // 序列化��¼���ʱ�� 类型为uint32_t
			$bs->pushUint8_t($this->cTimeInsert_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwTimeApply); // 序列化��������ʱ�� 类型为uint32_t
			$bs->pushUint8_t($this->cTimeApply_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwTimeApprovaled); // 序列化����������ʱ�� 类型为uint32_t
			$bs->pushUint8_t($this->cTimeApprovaled_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strStopper); // 序列化��ֹ�� 类型为std::string
			$bs->pushUint8_t($this->cStopper_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwTimeStop); // 序列化��ֹʱ�� 类型为uint32_t
			$bs->pushUint8_t($this->cTimeStop_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strStopDesc); // 序列化��ֹԭ������ 类型为std::string
			$bs->pushUint8_t($this->cStopDesc_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cRecordState); // 序列化��record״̬ 0 ������״̬ 1 ����״̬ 类型为uint8_t
			$bs->pushUint8_t($this->cRecordState_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化 �汾��    类型为uint32_t
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwId = $bs->popUint64_t(); // 反序列化Id  ��¼id 类型为uint64_t
			$this->cId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwBusinessId = $bs->popUint64_t(); // 反序列化businessId 类型为uint64_t
			$this->cBusinessId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwSkuId = $bs->popUint64_t(); // 反序列化skuid   类型为uint64_t
			$this->cSkuId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwPriceType = $bs->popUint32_t(); // 反序列化�۸����ͣ�1:һ�����ۣ�2:��������ۣ�3:��Ա�ۣ�4���ݼ� 类型为uint32_t
			$this->cPriceType_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwRegionId = $bs->popUint32_t(); // 反序列化���� id 类型为uint32_t
			$this->cRegionId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwPriceSceneId = $bs->popUint64_t(); // 反序列化���� id 类型为uint64_t
			$this->cPriceSceneId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwPriceSourceId = $bs->popUint64_t(); // 反序列化��Դ id 类型为uint64_t
			$this->cPriceSourceId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strProductId = $bs->popString(); // 反序列化product_id 类型为std::string
			$this->cProductId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strProductName = $bs->popString(); // 反序列化product_name 类型为std::string
			$this->cProductName_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwEnerySavePrice = $bs->popUint32_t(); // 反序列化���ܲ��� 类型为uint32_t
			$this->cEnerySavePrice_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strLadderNumRule = $bs->popString(); // 反序列化������ݹ��� 类型为std::string
			$this->cLadderNumRule_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strPriceRuleName = $bs->popString(); // 反序列化������� 类型为std::string
			$this->cPriceRuleName_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strPriceRuleUrl = $bs->popString(); // 反序列化����URL 类型为std::string
			$this->cPriceRuleUrl_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strActiveIdList = $bs->popString(); // 反序列化�ID�б� 类型为std::string
			$this->cActiveIdList_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strEdmIdList = $bs->popString(); // 反序列化EDMID�б� 类型为std::string
			$this->cEdmIdList_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strPriceDesc = $bs->popString(); // 反序列化�۸����� 类型为std::string
			$this->cPriceDesc_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strPriceRuleCreator = $bs->popString(); // 反序列化���򴴽��� 类型为std::string
			$this->cPriceRuleCreator_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwPriceCoster = $bs->popUint32_t(); // 反序列化�ɱ���̯�� 类型为uint32_t
			$this->cPriceCoster_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwSpsMultPrice = $bs->popUint32_t(); // 反序列化��Ӫ��ۣ����ռ۸� 类型为uint32_t
			$this->cSpsMultPrice_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwPriceBase = $bs->popUint32_t(); // 反序列化��۵Ļ�׼�� 类型为uint32_t
			$this->cPriceBase_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwPriceDiscount = $bs->popUint32_t(); // 反序列化�ÿ���Ʒ�ŻݵĽ�� 类型为uint32_t
			$this->cPriceDiscount_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwPriceCost = $bs->popUint32_t(); // 反序列化priceCost �ɱ���  类型为uint32_t
			$this->cPriceCost_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwFavorType = $bs->popUint32_t(); // 反序列化�Ż����� 1:�ۿ� 2������ 3������ 类型为uint32_t
			$this->cFavorType_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwFavorValue = $bs->popUint32_t(); // 反序列化�Ż��� 类型为uint32_t
			$this->cFavorValue_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwStartTime = $bs->popUint32_t(); // 反序列化��ʱ��ۿ�ʼʱ�� 类型为uint32_t
			$this->cStartTime_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwEndTime = $bs->popUint32_t(); // 反序列化��ʱ��۽���ʱ�� 类型为uint32_t
			$this->cEndTime_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->wTimedPriceIndex = $bs->popUint16_t(); // 反序列化 timedPrice index �Ϸ�ֵΪ1-10�����֧��10��timefield������ ����coss���5��(1-5)���û�5�� 10�������� TODO: 类型为uint16_t
			$this->cTimedPriceIndex_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strPriceStoreHouse = $bs->popString(); // 反序列化���òֿ⣬��ʽ���� 类型为std::string
			$this->cPriceStoreHouse_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strPriceUserIdentityRule = $bs->popString(); // 反序列化��ݹ��� 类型为std::string
			$this->cPriceUserIdentityRule_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->wOperType = $bs->popUint16_t(); // 反序列化��۹���������� 0-���� 1-�޸� 类型为uint16_t
			$this->cOperType_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strReason = $bs->popString(); // 反序列化����ԭ�� 类型为std::string
			$this->cReason_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cTypeApprovel = $bs->popUint8_t(); // 反序列化�������� 0 �������� 1 �߼����� 2 �м����� 3 �������� 类型为uint8_t
			$this->cTypeApprovel_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strApprover = $bs->popString(); // 反序列化������ 类型为std::string
			$this->cApprover_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strApproverBak = $bs->popString(); // 反序列化���������� 类型为std::string
			$this->cApproverBak_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cWhoApprovaled = $bs->popUint8_t(); // 反序列化��λ���������� 0 ���������� 1 �������� 2 ���������� 类型为uint8_t
			$this->cWhoApprovaled_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->wApprovalState = $bs->popUint16_t(); // 反序列化������/״̬ 0 ����� 1 �����  2 ��˲�ͨ��  3 ��ֹ 4 ɾ�� 类型为uint16_t
			$this->cApprovalState_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strApproverDesc = $bs->popString(); // 反序列化���������� 类型为std::string
			$this->cApproverDesc_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwTimeInsert = $bs->popUint32_t(); // 反序列化��¼���ʱ�� 类型为uint32_t
			$this->cTimeInsert_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwTimeApply = $bs->popUint32_t(); // 反序列化��������ʱ�� 类型为uint32_t
			$this->cTimeApply_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwTimeApprovaled = $bs->popUint32_t(); // 反序列化����������ʱ�� 类型为uint32_t
			$this->cTimeApprovaled_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strStopper = $bs->popString(); // 反序列化��ֹ�� 类型为std::string
			$this->cStopper_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwTimeStop = $bs->popUint32_t(); // 反序列化��ֹʱ�� 类型为uint32_t
			$this->cTimeStop_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strStopDesc = $bs->popString(); // 反序列化��ֹԭ������ 类型为std::string
			$this->cStopDesc_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cRecordState = $bs->popUint8_t(); // 反序列化��record״̬ 0 ������״̬ 1 ����״̬ 类型为uint8_t
			$this->cRecordState_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.icson.grossprofitcontrol.idl.GetRecordReq.java

if (!class_exists('GrossProfitControlKey_Bo')) {
class GrossProfitControlKey_Bo
{
		/**
		 *  �汾��   
		 *
		 * 版本 >= 0
		 */
		var $cVersion; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * businessId
		 *
		 * 版本 >= 0
		 */
		var $ddwBusinessId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cBusinessId_u; //uint8_t

		/**
		 * skuid  
		 *
		 * 版本 >= 0
		 */
		var $ddwSkuId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cSkuId_u; //uint8_t

		/**
		 * ���� id��д��ʱ����
		 *
		 * 版本 >= 0
		 */
		var $dwRegionId; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cRegionId_u; //uint8_t

		/**
		 * ���� id ����
		 *
		 * 版本 >= 0
		 */
		var $ddwPriceSceneId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cPriceSceneId_u; //uint8_t

		/**
		 * ��Դ id ����
		 *
		 * 版本 >= 0
		 */
		var $ddwPriceSourceId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cPriceSourceId_u; //uint8_t

		/**
		 *  timedPrice index �Ϸ�ֵΪ1-10�����֧��10��timefield������ ����coss���5��(1-5)���û�5�� 10�������� TODO:
		 *
		 * 版本 >= 0
		 */
		var $wTimedPriceIndex; //uint16_t

		/**
		 * 版本 >= 0
		 */
		var $cTimedPriceIndex_u; //uint8_t

		/**
		 * Id
		 *
		 * 版本 >= 0
		 */
		var $ddwId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cId_u; //uint8_t


		 function __construct() {
			 $this->cVersion = 0; // uint8_t
			 $this->cVersion_u = 0; // uint8_t
			 $this->ddwBusinessId = 0; // uint64_t
			 $this->cBusinessId_u = 0; // uint8_t
			 $this->ddwSkuId = 0; // uint64_t
			 $this->cSkuId_u = 0; // uint8_t
			 $this->dwRegionId = 0; // uint32_t
			 $this->cRegionId_u = 0; // uint8_t
			 $this->ddwPriceSceneId = 0; // uint64_t
			 $this->cPriceSceneId_u = 0; // uint8_t
			 $this->ddwPriceSourceId = 0; // uint64_t
			 $this->cPriceSourceId_u = 0; // uint8_t
			 $this->wTimedPriceIndex = 0; // uint16_t
			 $this->cTimedPriceIndex_u = 0; // uint8_t
			 $this->ddwId = 0; // uint64_t
			 $this->cId_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint8_t($this->cVersion); // 序列化 �汾��    类型为uint8_t
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwBusinessId); // 序列化businessId 类型为uint64_t
			$bs->pushUint8_t($this->cBusinessId_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwSkuId); // 序列化skuid   类型为uint64_t
			$bs->pushUint8_t($this->cSkuId_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwRegionId); // 序列化���� id��д��ʱ���� 类型为uint32_t
			$bs->pushUint8_t($this->cRegionId_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwPriceSceneId); // 序列化���� id ���� 类型为uint64_t
			$bs->pushUint8_t($this->cPriceSceneId_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwPriceSourceId); // 序列化��Դ id ���� 类型为uint64_t
			$bs->pushUint8_t($this->cPriceSourceId_u); // 序列化 类型为uint8_t
			$bs->pushUint16_t($this->wTimedPriceIndex); // 序列化 timedPrice index �Ϸ�ֵΪ1-10�����֧��10��timefield������ ����coss���5��(1-5)���û�5�� 10�������� TODO: 类型为uint16_t
			$bs->pushUint8_t($this->cTimedPriceIndex_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwId); // 序列化Id 类型为uint64_t
			$bs->pushUint8_t($this->cId_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->cVersion = $bs->popUint8_t(); // 反序列化 �汾��    类型为uint8_t
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwBusinessId = $bs->popUint64_t(); // 反序列化businessId 类型为uint64_t
			$this->cBusinessId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwSkuId = $bs->popUint64_t(); // 反序列化skuid   类型为uint64_t
			$this->cSkuId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwRegionId = $bs->popUint32_t(); // 反序列化���� id��д��ʱ���� 类型为uint32_t
			$this->cRegionId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwPriceSceneId = $bs->popUint64_t(); // 反序列化���� id ���� 类型为uint64_t
			$this->cPriceSceneId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwPriceSourceId = $bs->popUint64_t(); // 反序列化��Դ id ���� 类型为uint64_t
			$this->cPriceSourceId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->wTimedPriceIndex = $bs->popUint16_t(); // 反序列化 timedPrice index �Ϸ�ֵΪ1-10�����֧��10��timefield������ ����coss���5��(1-5)���û�5�� 10�������� TODO: 类型为uint16_t
			$this->cTimedPriceIndex_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwId = $bs->popUint64_t(); // 反序列化Id 类型为uint64_t
			$this->cId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.icson.grossprofitcontrol.idl.GetIndexByOperatorResp.java

if (!class_exists('GrossProfitIndex_Bo')) {
class GrossProfitIndex_Bo
{
		/**
		 *  �汾��   
		 *
		 * 版本 >= 0
		 */
		var $cVersion; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * ������id
		 *
		 * 版本 >= 0
		 */
		var $strApplicant; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cApplicant_u; //uint8_t

		/**
		 * �������� 0 �������� 1 �߼����� 2 �м����� 3 ��������
		 *
		 * 版本 >= 0
		 */
		var $cTypeApprovel; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cTypeApprovel_u; //uint8_t

		/**
		 * ������
		 *
		 * 版本 >= 0
		 */
		var $strApprover; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cApprover_u; //uint8_t

		/**
		 * ����������
		 *
		 * 版本 >= 0
		 */
		var $strApproverBak; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cApproverBak_u; //uint8_t

		/**
		 * ��ֹ��
		 *
		 * 版本 >= 0
		 */
		var $strStopper; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cStopper_u; //uint8_t

		/**
		 * ��λ���������� 1 �������� 2 ����������
		 *
		 * 版本 >= 0
		 */
		var $cWhoApprovaled; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cWhoApprovaled_u; //uint8_t

		/**
		 * skuid  
		 *
		 * 版本 >= 0
		 */
		var $ddwSkuId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cSkuId_u; //uint8_t

		/**
		 * product_id
		 *
		 * 版本 >= 0
		 */
		var $strProductId; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cProductId_u; //uint8_t

		/**
		 * product_name
		 *
		 * 版本 >= 0
		 */
		var $strProductName; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cProductName_u; //uint8_t

		/**
		 * Id  ��¼id
		 *
		 * 版本 >= 0
		 */
		var $ddwId; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cId_u; //uint8_t

		/**
		 * ������/״̬
		 *
		 * 版本 >= 0
		 */
		var $wApprovalState; //uint16_t

		/**
		 * 版本 >= 0
		 */
		var $cApprovalState_u; //uint8_t

		/**
		 * ��������ʱ��
		 *
		 * 版本 >= 0
		 */
		var $dwTimeApply; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cTimeApply_u; //uint8_t

		/**
		 * �۸�����
		 *
		 * 版本 >= 0
		 */
		var $strPriceDesc; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cPriceDesc_u; //uint8_t


		 function __construct() {
			 $this->cVersion = 0; // uint8_t
			 $this->cVersion_u = 0; // uint8_t
			 $this->strApplicant = ""; // std::string
			 $this->cApplicant_u = 0; // uint8_t
			 $this->cTypeApprovel = 0; // uint8_t
			 $this->cTypeApprovel_u = 0; // uint8_t
			 $this->strApprover = ""; // std::string
			 $this->cApprover_u = 0; // uint8_t
			 $this->strApproverBak = ""; // std::string
			 $this->cApproverBak_u = 0; // uint8_t
			 $this->strStopper = ""; // std::string
			 $this->cStopper_u = 0; // uint8_t
			 $this->cWhoApprovaled = 0; // uint8_t
			 $this->cWhoApprovaled_u = 0; // uint8_t
			 $this->ddwSkuId = 0; // uint64_t
			 $this->cSkuId_u = 0; // uint8_t
			 $this->strProductId = ""; // std::string
			 $this->cProductId_u = 0; // uint8_t
			 $this->strProductName = ""; // std::string
			 $this->cProductName_u = 0; // uint8_t
			 $this->ddwId = 0; // uint64_t
			 $this->cId_u = 0; // uint8_t
			 $this->wApprovalState = 0; // uint16_t
			 $this->cApprovalState_u = 0; // uint8_t
			 $this->dwTimeApply = 0; // uint32_t
			 $this->cTimeApply_u = 0; // uint8_t
			 $this->strPriceDesc = ""; // std::string
			 $this->cPriceDesc_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint8_t($this->cVersion); // 序列化 �汾��    类型为uint8_t
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strApplicant); // 序列化������id 类型为std::string
			$bs->pushUint8_t($this->cApplicant_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cTypeApprovel); // 序列化�������� 0 �������� 1 �߼����� 2 �м����� 3 �������� 类型为uint8_t
			$bs->pushUint8_t($this->cTypeApprovel_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strApprover); // 序列化������ 类型为std::string
			$bs->pushUint8_t($this->cApprover_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strApproverBak); // 序列化���������� 类型为std::string
			$bs->pushUint8_t($this->cApproverBak_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strStopper); // 序列化��ֹ�� 类型为std::string
			$bs->pushUint8_t($this->cStopper_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cWhoApprovaled); // 序列化��λ���������� 1 �������� 2 ���������� 类型为uint8_t
			$bs->pushUint8_t($this->cWhoApprovaled_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwSkuId); // 序列化skuid   类型为uint64_t
			$bs->pushUint8_t($this->cSkuId_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strProductId); // 序列化product_id 类型为std::string
			$bs->pushUint8_t($this->cProductId_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strProductName); // 序列化product_name 类型为std::string
			$bs->pushUint8_t($this->cProductName_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwId); // 序列化Id  ��¼id 类型为uint64_t
			$bs->pushUint8_t($this->cId_u); // 序列化 类型为uint8_t
			$bs->pushUint16_t($this->wApprovalState); // 序列化������/״̬ 类型为uint16_t
			$bs->pushUint8_t($this->cApprovalState_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwTimeApply); // 序列化��������ʱ�� 类型为uint32_t
			$bs->pushUint8_t($this->cTimeApply_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strPriceDesc); // 序列化�۸����� 类型为std::string
			$bs->pushUint8_t($this->cPriceDesc_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->cVersion = $bs->popUint8_t(); // 反序列化 �汾��    类型为uint8_t
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strApplicant = $bs->popString(); // 反序列化������id 类型为std::string
			$this->cApplicant_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cTypeApprovel = $bs->popUint8_t(); // 反序列化�������� 0 �������� 1 �߼����� 2 �м����� 3 �������� 类型为uint8_t
			$this->cTypeApprovel_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strApprover = $bs->popString(); // 反序列化������ 类型为std::string
			$this->cApprover_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strApproverBak = $bs->popString(); // 反序列化���������� 类型为std::string
			$this->cApproverBak_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strStopper = $bs->popString(); // 反序列化��ֹ�� 类型为std::string
			$this->cStopper_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cWhoApprovaled = $bs->popUint8_t(); // 反序列化��λ���������� 1 �������� 2 ���������� 类型为uint8_t
			$this->cWhoApprovaled_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwSkuId = $bs->popUint64_t(); // 反序列化skuid   类型为uint64_t
			$this->cSkuId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strProductId = $bs->popString(); // 反序列化product_id 类型为std::string
			$this->cProductId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strProductName = $bs->popString(); // 反序列化product_name 类型为std::string
			$this->cProductName_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwId = $bs->popUint64_t(); // 反序列化Id  ��¼id 类型为uint64_t
			$this->cId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->wApprovalState = $bs->popUint16_t(); // 反序列化������/״̬ 类型为uint16_t
			$this->cApprovalState_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwTimeApply = $bs->popUint32_t(); // 反序列化��������ʱ�� 类型为uint32_t
			$this->cTimeApply_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strPriceDesc = $bs->popString(); // 反序列化�۸����� 类型为std::string
			$this->cPriceDesc_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}

?>