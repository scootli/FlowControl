<?php
namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.Nca_v3_bo.java
class PublistNode_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $optionId;	//<uint32_t> 属性值id(版本>=0)
	private $type;	//<uint32_t> 类型:1属性，3类目，4品类(版本>=0)
	private $name;	//<std::string> name(版本>=0)
	private $propertyStr;	//<std::string> property(版本>=0)
	private $anyChildren;	//<uint32_t> 是否有后继节点(版本>=0)
	private $desc;	//<std::string> sDesc(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->type = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->propertyStr = "";	//<std::string>
		$this->anyChildren = 0;	//<uint32_t>
		$this->desc = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\PublistNode_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\PublistNode_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->optionId);	//<uint32_t> 属性值id
		$bs->pushUint32_t($this->type);	//<uint32_t> 类型:1属性，3类目，4品类
		$bs->pushString($this->name);	//<std::string> name
		$bs->pushString($this->propertyStr);	//<std::string> property
		$bs->pushUint32_t($this->anyChildren);	//<uint32_t> 是否有后继节点
		$bs->pushString($this->desc);	//<std::string> sDesc
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t> 导航id
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t> 属性项id
		$this->_arr_value['optionId'] = $bs->popUint32_t();	//<uint32_t> 属性值id
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t> 类型:1属性，3类目，4品类
		$this->_arr_value['name'] = $bs->popString();	//<std::string> name
		$this->_arr_value['propertyStr'] = $bs->popString();	//<std::string> property
		$this->_arr_value['anyChildren'] = $bs->popUint32_t();	//<uint32_t> 是否有后继节点
		$this->_arr_value['desc'] = $bs->popString();	//<std::string> sDesc

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.Nca_v3_bo.java
class OrderNavBoEx_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navNode;	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息(版本>=0)
	private $fullPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径(版本>=0)
	private $metaSearchPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径(版本>=0)
	private $childNode;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航(版本>=0)
	private $childAttrId;	//<std::vector<std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性(版本>=0)
	private $attrDic;	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navNode = new \c2cent\bo\nca_v3\NavEntry_v3();	//<c2cent::bo::nca_v3::CNavEntry_v3>
		$this->fullPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->metaSearchPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childNode = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childAttrId = new \stl_vector2('stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> ');	//<std::vector<std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > >
		$this->attrDic = new \stl_map2('uint32_t,\c2cent\bo\nca_v3\AttrBo_v3');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\OrderNavBoEx_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\OrderNavBoEx_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushObject($this->navNode,'\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$bs->pushObject($this->fullPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$bs->pushObject($this->metaSearchPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$bs->pushObject($this->childNode,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
		$bs->pushObject($this->childAttrId,'stl_vector');	//<std::vector<std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性
		$bs->pushObject($this->attrDic,'stl_map');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navNode'] = $bs->popObject('\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$this->_arr_value['metaSearchPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$this->_arr_value['childNode'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
		$this->_arr_value['childAttrId'] = $bs->popObject('stl_vector<stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> >');	//<std::vector<std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性
		$this->_arr_value['attrDic'] = $bs->popObject('stl_map<uint32_t,\c2cent\bo\nca_v3\AttrBo_v3>');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.Nca_v3_bo.java
class NavMatchKey_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $matchInfo;	//<std::string> Matchinfo(版本>=0)
	private $pathInfo;	//<std::string> PathInfo(版本>=0)
	private $matchType;	//<uint32_t> MatchType(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->matchInfo = "";	//<std::string>
		$this->pathInfo = "";	//<std::string>
		$this->matchType = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\NavMatchKey_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\NavMatchKey_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushString($this->matchInfo);	//<std::string> Matchinfo
		$bs->pushString($this->pathInfo);	//<std::string> PathInfo
		$bs->pushUint32_t($this->matchType);	//<uint32_t> MatchType
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t> 导航id
		$this->_arr_value['matchInfo'] = $bs->popString();	//<std::string> Matchinfo
		$this->_arr_value['pathInfo'] = $bs->popString();	//<std::string> PathInfo
		$this->_arr_value['matchType'] = $bs->popUint32_t();	//<uint32_t> MatchType

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.Nca_v3_bo.java
class NavBo_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navNode;	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息(版本>=0)
	private $fullPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径(版本>=0)
	private $metaSearchPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径(版本>=0)
	private $childNode;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navNode = new \c2cent\bo\nca_v3\NavEntry_v3();	//<c2cent::bo::nca_v3::CNavEntry_v3>
		$this->fullPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->metaSearchPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childNode = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\NavBo_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\NavBo_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushObject($this->navNode,'\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$bs->pushObject($this->fullPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$bs->pushObject($this->metaSearchPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$bs->pushObject($this->childNode,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navNode'] = $bs->popObject('\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$this->_arr_value['metaSearchPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$this->_arr_value['childNode'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.Nca_v3_bo.java
class NavBoEx_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navNode;	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息(版本>=0)
	private $fullPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径(版本>=0)
	private $metaSearchPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径(版本>=0)
	private $childNode;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航(版本>=0)
	private $childAttrId;	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性(版本>=0)
	private $attrDic;	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navNode = new \c2cent\bo\nca_v3\NavEntry_v3();	//<c2cent::bo::nca_v3::CNavEntry_v3>
		$this->fullPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->metaSearchPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childNode = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childAttrId = new \stl_map2('uint32_t,stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> ');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > >
		$this->attrDic = new \stl_map2('uint32_t,\c2cent\bo\nca_v3\AttrBo_v3');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\NavBoEx_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\NavBoEx_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushObject($this->navNode,'\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$bs->pushObject($this->fullPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$bs->pushObject($this->metaSearchPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$bs->pushObject($this->childNode,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
		$bs->pushObject($this->childAttrId,'stl_map');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性
		$bs->pushObject($this->attrDic,'stl_map');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navNode'] = $bs->popObject('\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$this->_arr_value['metaSearchPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$this->_arr_value['childNode'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
		$this->_arr_value['childAttrId'] = $bs->popObject('stl_map<uint32_t,stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> >');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性
		$this->_arr_value['attrDic'] = $bs->popObject('stl_map<uint32_t,\c2cent\bo\nca_v3\AttrBo_v3>');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.NavBoEx_v3.java
class NavEntry_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $pNavId;	//<uint32_t> 父导航id(版本>=0)
	private $name;	//<std::string> 导航名称(版本>=0)
	private $type;	//<uint32_t> 导航类型(版本>=0)
	private $catalog;	//<uint32_t> 导航分类(版本>=0)
	private $note;	//<std::string> 备注(版本>=0)
	private $order;	//<uint32_t> 排序字段(版本>=0)
	private $propertyStr;	//<std::string> 导航property(版本>=0)
	private $searchCond;	//<std::string> 搜索条件(版本>=0)
	private $hasAttr;	//<uint32_t> 是否有属性(版本>=0)
	private $customStr1;	//<std::string> 导航预留自定义串1(版本>=0)
	private $customStr2;	//<std::string> 导航预留自定义串2(版本>=0)
	private $metaCatalog;	//<uint32_t>  metaclass type(版本>=0)
	private $customUint2;	//<uint32_t> 导航预留自定义整形字段2(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->pNavId = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->type = 0;	//<uint32_t>
		$this->catalog = 0;	//<uint32_t>
		$this->note = "";	//<std::string>
		$this->order = 0;	//<uint32_t>
		$this->propertyStr = "";	//<std::string>
		$this->searchCond = "";	//<std::string>
		$this->hasAttr = 0;	//<uint32_t>
		$this->customStr1 = "";	//<std::string>
		$this->customStr2 = "";	//<std::string>
		$this->metaCatalog = 0;	//<uint32_t>
		$this->customUint2 = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\NavEntry_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\NavEntry_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->pNavId);	//<uint32_t> 父导航id
		$bs->pushString($this->name);	//<std::string> 导航名称
		$bs->pushUint32_t($this->type);	//<uint32_t> 导航类型
		$bs->pushUint32_t($this->catalog);	//<uint32_t> 导航分类
		$bs->pushString($this->note);	//<std::string> 备注
		$bs->pushUint32_t($this->order);	//<uint32_t> 排序字段
		$bs->pushString($this->propertyStr);	//<std::string> 导航property
		$bs->pushString($this->searchCond);	//<std::string> 搜索条件
		$bs->pushUint32_t($this->hasAttr);	//<uint32_t> 是否有属性
		$bs->pushString($this->customStr1);	//<std::string> 导航预留自定义串1
		$bs->pushString($this->customStr2);	//<std::string> 导航预留自定义串2
		$bs->pushUint32_t($this->metaCatalog);	//<uint32_t>  metaclass type
		$bs->pushUint32_t($this->customUint2);	//<uint32_t> 导航预留自定义整形字段2
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t> 导航id
		$this->_arr_value['mapId'] = $bs->popUint32_t();	//<uint32_t> 地图id
		$this->_arr_value['pNavId'] = $bs->popUint32_t();	//<uint32_t> 父导航id
		$this->_arr_value['name'] = $bs->popString();	//<std::string> 导航名称
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t> 导航类型
		$this->_arr_value['catalog'] = $bs->popUint32_t();	//<uint32_t> 导航分类
		$this->_arr_value['note'] = $bs->popString();	//<std::string> 备注
		$this->_arr_value['order'] = $bs->popUint32_t();	//<uint32_t> 排序字段
		$this->_arr_value['propertyStr'] = $bs->popString();	//<std::string> 导航property
		$this->_arr_value['searchCond'] = $bs->popString();	//<std::string> 搜索条件
		$this->_arr_value['hasAttr'] = $bs->popUint32_t();	//<uint32_t> 是否有属性
		$this->_arr_value['customStr1'] = $bs->popString();	//<std::string> 导航预留自定义串1
		$this->_arr_value['customStr2'] = $bs->popString();	//<std::string> 导航预留自定义串2
		$this->_arr_value['metaCatalog'] = $bs->popUint32_t();	//<uint32_t>  metaclass type
		$this->_arr_value['customUint2'] = $bs->popUint32_t();	//<uint32_t> 导航预留自定义整形字段2

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.Nca_v3_bo.java
class AttrBo_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $name;	//<std::string> 属性项名称(版本>=0)
	private $property;	//<uint32_t> property(版本>=0)
	private $type;	//<uint32_t> 类型(版本>=0)
	private $pAttrId;	//<uint32_t> 父属性项id(版本>=0)
	private $pOptionId;	//<uint32_t> 父属性值id(版本>=0)
	private $desc;	//<std::string> 属性项描述(版本>=0)
	private $order;	//<uint32_t> 属性项排序(版本>=0)
	private $options;	//<std::vector<c2cent::bo::nca_v3::COptionBo_v3> > 属性值集合(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->property = 0;	//<uint32_t>
		$this->type = 0;	//<uint32_t>
		$this->pAttrId = 0;	//<uint32_t>
		$this->pOptionId = 0;	//<uint32_t>
		$this->desc = "";	//<std::string>
		$this->order = 0;	//<uint32_t>
		$this->options = new \stl_vector2('\c2cent\bo\nca_v3\OptionBo_v3');	//<std::vector<c2cent::bo::nca_v3::COptionBo_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\AttrBo_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\AttrBo_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushString($this->name);	//<std::string> 属性项名称
		$bs->pushUint32_t($this->property);	//<uint32_t> property
		$bs->pushUint32_t($this->type);	//<uint32_t> 类型
		$bs->pushUint32_t($this->pAttrId);	//<uint32_t> 父属性项id
		$bs->pushUint32_t($this->pOptionId);	//<uint32_t> 父属性值id
		$bs->pushString($this->desc);	//<std::string> 属性项描述
		$bs->pushUint32_t($this->order);	//<uint32_t> 属性项排序
		$bs->pushObject($this->options,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::COptionBo_v3> > 属性值集合
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t> 属性项id
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t> 导航id
		$this->_arr_value['name'] = $bs->popString();	//<std::string> 属性项名称
		$this->_arr_value['property'] = $bs->popUint32_t();	//<uint32_t> property
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t> 类型
		$this->_arr_value['pAttrId'] = $bs->popUint32_t();	//<uint32_t> 父属性项id
		$this->_arr_value['pOptionId'] = $bs->popUint32_t();	//<uint32_t> 父属性值id
		$this->_arr_value['desc'] = $bs->popString();	//<std::string> 属性项描述
		$this->_arr_value['order'] = $bs->popUint32_t();	//<uint32_t> 属性项排序
		$this->_arr_value['options'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\OptionBo_v3>');	//<std::vector<c2cent::bo::nca_v3::COptionBo_v3> > 属性值集合

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.AttrBo_v3.java
class OptionBo_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $optionId;	//<uint32_t> 属性值id(版本>=0)
	private $type;	//<uint32_t> 类型(版本>=0)
	private $property;	//<uint32_t> property(版本>=0)
	private $order;	//<uint32_t> 属性值排序(版本>=0)
	private $name;	//<std::string> 属性值名称(版本>=0)
	private $subAttrIds;	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 属性值下的子属性值对(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->type = 0;	//<uint32_t>
		$this->property = 0;	//<uint32_t>
		$this->order = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->subAttrIds = new \stl_map2('uint32_t,stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> ');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\OptionBo_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\OptionBo_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->optionId);	//<uint32_t> 属性值id
		$bs->pushUint32_t($this->type);	//<uint32_t> 类型
		$bs->pushUint32_t($this->property);	//<uint32_t> property
		$bs->pushUint32_t($this->order);	//<uint32_t> 属性值排序
		$bs->pushString($this->name);	//<std::string> 属性值名称
		$bs->pushObject($this->subAttrIds,'stl_map');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 属性值下的子属性值对
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t> 属性项id
		$this->_arr_value['optionId'] = $bs->popUint32_t();	//<uint32_t> 属性值id
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t> 类型
		$this->_arr_value['property'] = $bs->popUint32_t();	//<uint32_t> property
		$this->_arr_value['order'] = $bs->popUint32_t();	//<uint32_t> 属性值排序
		$this->_arr_value['name'] = $bs->popString();	//<std::string> 属性值名称
		$this->_arr_value['subAttrIds'] = $bs->popObject('stl_map<uint32_t,stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> >');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 属性值下的子属性值对

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.OptionBo_v3.java
class SubAttrOption_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $optionId;	//<uint32_t> 属性值id(版本>=0)
	private $property;	//<uint32_t> 值对property(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->property = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\SubAttrOption_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\SubAttrOption_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->optionId);	//<uint32_t> 属性值id
		$bs->pushUint32_t($this->property);	//<uint32_t> 值对property
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t> 属性项id
		$this->_arr_value['optionId'] = $bs->popUint32_t();	//<uint32_t> 属性值id
		$this->_arr_value['property'] = $bs->popUint32_t();	//<uint32_t> 值对property

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}
