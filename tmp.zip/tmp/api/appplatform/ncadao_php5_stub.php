<?php
// source idl: com.b2b2c.nca.idl.NcaDao.java
namespace b2b2c;
require_once "ncadao_php5_xxoo.php";

namespace b2b2c\nca\dao;
class GetAllMetaClassReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetAllMetaClassReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetAllMetaClassReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601805;
	}
}

class GetAllMetaClassResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $nav;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 品类数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['nav'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608805;
	}
}

namespace b2b2c\nca\dao;
class GetAllMetaClass_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetAllMetaClass_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetAllMetaClass_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011805;
	}
}

class GetAllMetaClass_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018805;
	}
}

namespace b2b2c\nca\dao;
class GetAttrTextReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $inAttrBoList;	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 属性列表(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->inAttrBoList = new \stl_vector2('\c2cent\bo\nca_v3\AttrBo_v3');	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetAttrTextReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetAttrTextReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushObject($this->inAttrBoList,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 属性列表

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x5360180a;
	}
}

class GetAttrTextResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $outAttrBoList;	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 属性列表(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['outAttrBoList'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\AttrBo_v3>');	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 属性列表
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x5360880a;
	}
}

namespace b2b2c\nca\dao;
class GetAttrText_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $navId;	//<uint32_t> 导航id，必填(版本>=0)
	private $inAttrBoList;	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 属性列表，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->inAttrBoList = new \stl_vector2('\b2b2c\nca\ddo\AttrDdo');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetAttrText_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetAttrText_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id，必填
		$bs->pushObject($this->inAttrBoList,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 属性列表，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA001180a;
	}
}

class GetAttrText_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $outAttrBoList;	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 属性列表(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['outAttrBoList'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\AttrDdo>');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 属性列表
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA001880a;
	}
}

namespace b2b2c\nca\dao;
class GetGroupNavReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $groupId;	//<uint32_t> 业务号,即数据文件中mty标识的数字(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->mapId = 0;	//<uint32_t>
		$this->groupId = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetGroupNavReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetGroupNavReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->groupId);	//<uint32_t> 业务号,即数据文件中mty标识的数字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x5360180f;
	}
}

class GetGroupNavResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $navList;	//<std::vector<c2cent::bo::nca_v3::CNavBo_v3> > 业务下所有的导航数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['navList'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavBo_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavBo_v3> > 业务下所有的导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x5360880f;
	}
}

namespace b2b2c\nca\dao;
class GetItemInfo_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $param;	//<std::map<uint64_t,b2b2c::nca::ddo::CParam_GetItemInfo_ALL> > key是商品id，value是Param_GetItemInfo_ALL(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->param = new \stl_map2('uint64_t,\b2b2c\nca\ddo\Param_GetItemInfo_ALL');	//<std::map<uint64_t,b2b2c::nca::ddo::CParam_GetItemInfo_ALL> >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetItemInfo_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetItemInfo_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushObject($this->param,'stl_map');	//<std::map<uint64_t,b2b2c::nca::ddo::CParam_GetItemInfo_ALL> > key是商品id，value是Param_GetItemInfo_ALL
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA001182D;
	}
}

class GetItemInfo_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $ret;	//<std::map<uint64_t,b2b2c::nca::ddo::CResult_GetItemInfo_ALL> > key是商品id，value是Result_GetItemInfo_ALL(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['ret'] = $bs->popObject('stl_map<uint64_t,\b2b2c\nca\ddo\Result_GetItemInfo_ALL>');	//<std::map<uint64_t,b2b2c::nca::ddo::CResult_GetItemInfo_ALL> > key是商品id，value是Result_GetItemInfo_ALL
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA001882D;
	}
}

namespace b2b2c\nca\dao;
class GetMetaAttr_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $metaId;	//<uint32_t> 品类id(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $attrOnly;	//<uint32_t> 是否只需要属性项信息，而不需要属性值信息(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->metaId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->attrOnly = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetaAttr_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetaAttr_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->attrOnly);	//<uint32_t> 是否只需要属性项信息，而不需要属性值信息
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA001182C;
	}
}

class GetMetaAttr_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attr;	//<b2b2c::nca::ddo::CAttrDdo> 属性项(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attr'] = $bs->popObject('\b2b2c\nca\ddo\AttrDdo');	//<b2b2c::nca::ddo::CAttrDdo> 属性项
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA001882C;
	}
}

namespace b2b2c\nca\dao;
class GetMetaByCatalogReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $catalog;	//<uint32_t> 分类(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->catalog = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetaByCatalogReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetaByCatalogReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->catalog);	//<uint32_t> 分类

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601806;
	}
}

class GetMetaByCatalogResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $nav;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 品类数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['nav'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608806;
	}
}

namespace b2b2c\nca\dao;
class GetMetaByCatalog_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $catalog;	//<uint32_t> 分类，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->catalog = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetaByCatalog_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetaByCatalog_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->catalog);	//<uint32_t> 分类，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011806;
	}
}

class GetMetaByCatalog_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018806;
	}
}

namespace b2b2c\nca\dao;
class GetMetaClassReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $metaId;	//<uint32_t> 品类id(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->metaId = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetaClassReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetaClassReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601801;
	}
}

class GetMetaClassResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $meta;	//<c2cent::bo::nca_v3::CNavBo_v3> 品类数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['meta'] = $bs->popObject('\c2cent\bo\nca_v3\NavBo_v3');	//<c2cent::bo::nca_v3::CNavBo_v3> 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608801;
	}
}

namespace b2b2c\nca\dao;
class GetMetaClassAttrDic_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetaClassAttrDic_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetaClassAttrDic_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011811;
	}
}

class GetMetaClassAttrDic_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attrDic;	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> > 品类属性字典(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attrDic'] = $bs->popObject('stl_map<uint32_t,\b2b2c\nca\ddo\AttrDdo>');	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> > 品类属性字典
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018811;
	}
}

namespace b2b2c\nca\dao;
class GetMetaClassExReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $metaId;	//<uint32_t> 品类id(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->metaId = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetaClassExReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetaClassExReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601802;
	}
}

class GetMetaClassExResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $meta;	//<c2cent::bo::nca_v3::CNavBoEx_v3> 品类数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['meta'] = $bs->popObject('\c2cent\bo\nca_v3\NavBoEx_v3');	//<c2cent::bo::nca_v3::CNavBoEx_v3> 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608802;
	}
}

namespace b2b2c\nca\dao;
class GetMetaClassEx_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetaClassEx_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetaClassEx_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011802;
	}
}

class GetMetaClassEx_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $meta;	//<b2b2c::nca::ddo::CNavExDdo> 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['meta'] = $bs->popObject('\b2b2c\nca\ddo\NavExDdo');	//<b2b2c::nca::ddo::CNavExDdo> 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018802;
	}
}

namespace b2b2c\nca\dao;
class GetMetaClass_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类Id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetaClass_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetaClass_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类Id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011801;
	}
}

class GetMetaClass_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $meta;	//<b2b2c::nca::ddo::CNavDdo> 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['meta'] = $bs->popObject('\b2b2c\nca\ddo\NavDdo');	//<b2b2c::nca::ddo::CNavDdo> 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018801;
	}
}

namespace b2b2c\nca\dao;
class GetMetaV2_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $pubMapId;	//<uint32_t> 发布地图id，必填(版本>=0)
	private $searchMapId;	//<uint32_t> 搜索地图id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->pubMapId = 0;	//<uint32_t>
		$this->searchMapId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetaV2_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetaV2_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->pubMapId);	//<uint32_t> 发布地图id，必填
		$bs->pushUint32_t($this->searchMapId);	//<uint32_t> 搜索地图id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011818;
	}
}

class GetMetaV2_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $meta;	//<b2b2c::nca::ddo::CNavDdo> 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['meta'] = $bs->popObject('\b2b2c\nca\ddo\NavDdo');	//<b2b2c::nca::ddo::CNavDdo> 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018818;
	}
}

namespace b2b2c\nca\dao;
class GetMeta_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $metaId;	//<uint32_t> 品类Id(版本>=0)
	private $needAttrDic;	//<uint32_t> 是否需要填充属性字典(版本>=0)
	private $attrOnly;	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->metaId = 0;	//<uint32_t>
		$this->needAttrDic = 0;	//<uint32_t>
		$this->attrOnly = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMeta_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMeta_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类Id
		$bs->pushUint32_t($this->needAttrDic);	//<uint32_t> 是否需要填充属性字典
		$bs->pushUint32_t($this->attrOnly);	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011820;
	}
}

class GetMeta_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $meta;	//<b2b2c::nca::ddo::CNavExDdo> 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['meta'] = $bs->popObject('\b2b2c\nca\ddo\NavExDdo');	//<b2b2c::nca::ddo::CNavExDdo> 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018820;
	}
}

namespace b2b2c\nca\dao;
class GetMetas_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $metaId;	//<std::set<uint32_t> > 品类Id，批量，不填表示获取全部的品类(版本>=0)
	private $needAttrDic;	//<uint32_t> 是否需要填充属性字典(版本>=0)
	private $attrOnly;	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->metaId = new \stl_set2('uint32_t');	//<std::set<uint32_t> >
		$this->needAttrDic = 0;	//<uint32_t>
		$this->attrOnly = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMetas_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMetas_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushObject($this->metaId,'stl_set');	//<std::set<uint32_t> > 品类Id，批量，不填表示获取全部的品类
		$bs->pushUint32_t($this->needAttrDic);	//<uint32_t> 是否需要填充属性字典
		$bs->pushUint32_t($this->attrOnly);	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011821;
	}
}

class GetMetas_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $meta;	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['meta'] = $bs->popObject('stl_map<uint32_t,\b2b2c\nca\ddo\NavExDdo>');	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018821;
	}
}

namespace b2b2c\nca\dao;
class GetMultiFullPath_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $metaId;	//<std::set<uint32_t> > 品类id，必填，一次最多300个(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->metaId = new \stl_set2('uint32_t');	//<std::set<uint32_t> >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetMultiFullPath_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetMultiFullPath_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushObject($this->metaId,'stl_set');	//<std::set<uint32_t> > 品类id，必填，一次最多300个
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011816;
	}
}

class GetMultiFullPath_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $fullPath;	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CNavEntryDdo> > > key是品类id，Value是对应的全路径(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_map<uint32_t,stl_vector<\b2b2c\nca\ddo\NavEntryDdo> >');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CNavEntryDdo> > > key是品类id，Value是对应的全路径
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018816;
	}
}

namespace b2b2c\nca\dao;
class GetNavReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetNavReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetNavReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601803;
	}
}

class GetNavResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $nav;	//<c2cent::bo::nca_v3::CNavBo_v3> 导航数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['nav'] = $bs->popObject('\c2cent\bo\nca_v3\NavBo_v3');	//<c2cent::bo::nca_v3::CNavBo_v3> 导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608803;
	}
}

namespace b2b2c\nca\dao;
class GetNavAttrOpReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetNavAttrOpReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetNavAttrOpReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601813;
	}
}

class GetNavAttrOpResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attr;	//<c2cent::bo::nca_v3::CAttrBo_v3> 属性实体里有导航属性关系里所有属性值(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attr'] = $bs->popObject('\c2cent\bo\nca_v3\AttrBo_v3');	//<c2cent::bo::nca_v3::CAttrBo_v3> 属性实体里有导航属性关系里所有属性值
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0x53608813;
	}
}

namespace b2b2c\nca\dao;
class GetNavAttrOp_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetNavAttrOp_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetNavAttrOp_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011817;
	}
}

class GetNavAttrOp_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attr;	//<b2b2c::nca::ddo::CAttrDdo> 属性实体里有导航属性关系里所有属性值(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attr'] = $bs->popObject('\b2b2c\nca\ddo\AttrDdo');	//<b2b2c::nca::ddo::CAttrDdo> 属性实体里有导航属性关系里所有属性值
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018817;
	}
}

namespace b2b2c\nca\dao;
class GetNavExReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetNavExReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetNavExReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601804;
	}
}

class GetNavExResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $nav;	//<c2cent::bo::nca_v3::CNavBoEx_v3> 导航数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['nav'] = $bs->popObject('\c2cent\bo\nca_v3\NavBoEx_v3');	//<c2cent::bo::nca_v3::CNavBoEx_v3> 导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608804;
	}
}

namespace b2b2c\nca\dao;
class GetNavExOrder_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $navId;	//<uint32_t> 导航id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetNavExOrder_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetNavExOrder_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011815;
	}
}

class GetNavExOrder_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $navOrder;	//<b2b2c::nca::ddo::CNavExOrderDdo> 导航数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['navOrder'] = $bs->popObject('\b2b2c\nca\ddo\NavExOrderDdo');	//<b2b2c::nca::ddo::CNavExOrderDdo> 导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018815;
	}
}

namespace b2b2c\nca\dao;
class GetNavEx_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $navId;	//<uint32_t> 导航id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetNavEx_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetNavEx_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011804;
	}
}

class GetNavEx_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<b2b2c::nca::ddo::CNavExDdo> 导航数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('\b2b2c\nca\ddo\NavExDdo');	//<b2b2c::nca::ddo::CNavExDdo> 导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018804;
	}
}

namespace b2b2c\nca\dao;
class GetNav_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $navId;	//<uint32_t> 导航id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetNav_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetNav_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011803;
	}
}

class GetNav_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<b2b2c::nca::ddo::CNavDdo> 导航数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('\b2b2c\nca\ddo\NavDdo');	//<b2b2c::nca::ddo::CNavDdo> 导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018803;
	}
}

namespace b2b2c\nca\dao;
class GetNavsReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $navId;	//<std::vector<uint32_t> > 导航id(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = new \stl_vector2('uint32_t');	//<std::vector<uint32_t> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetNavsReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetNavsReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushObject($this->navId,'stl_vector');	//<std::vector<uint32_t> > 导航id

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601815;
	}
}

class GetNavsResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $nav;	//<std::vector<c2cent::bo::nca_v3::CNavBo_v3> > 导航数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['nav'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavBo_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavBo_v3> > 导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608815;
	}
}

namespace b2b2c\nca\dao;
class GetOrderNavExReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $orderType;	//<uint32_t> 排序方法 1表示按照order字段升序排序(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->orderType = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetOrderNavExReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetOrderNavExReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushUint32_t($this->orderType);	//<uint32_t> 排序方法 1表示按照order字段升序排序

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601810;
	}
}

class GetOrderNavExResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $nav;	//<c2cent::bo::nca_v3::COrderNavBoEx_v3> 导航数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['nav'] = $bs->popObject('\c2cent\bo\nca_v3\OrderNavBoEx_v3');	//<c2cent::bo::nca_v3::COrderNavBoEx_v3> 导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608810;
	}
}

namespace b2b2c\nca\dao;
class GetPathByNavId_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $navId;	//<uint32_t> 导航id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetPathByNavId_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetPathByNavId_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA001180f;
	}
}

class GetPathByNavId_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $fullPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 导航路径(版本>=0)
	private $childNav;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 子节点集合(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 导航路径
		$this->_arr_value['childNav'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 子节点集合
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA001880f;
	}
}

namespace b2b2c\nca\dao;
class GetPubNav_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $navId;	//<uint32_t> 导航Id，必填(版本>=0)
	private $needAttrDic;	//<uint32_t> 是否需要填充属性字典。叶子导航是品类，这个时候是有属性的(版本>=0)
	private $attrOnly;	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->navId = 0;	//<uint32_t>
		$this->needAttrDic = 0;	//<uint32_t>
		$this->attrOnly = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetPubNav_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetPubNav_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航Id，必填
		$bs->pushUint32_t($this->needAttrDic);	//<uint32_t> 是否需要填充属性字典。叶子导航是品类，这个时候是有属性的
		$bs->pushUint32_t($this->attrOnly);	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011822;
	}
}

class GetPubNav_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<b2b2c::nca::ddo::CNavExDdo> 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('\b2b2c\nca\ddo\NavExDdo');	//<b2b2c::nca::ddo::CNavExDdo> 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018822;
	}
}

namespace b2b2c\nca\dao;
class GetPubNavs_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $navId;	//<std::set<uint32_t> > 导航Id，批量，必填(版本>=0)
	private $needAttrDic;	//<uint32_t> 是否需要填充属性字典。叶子导航是品类，这个时候是有属性的(版本>=0)
	private $attrOnly;	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->navId = new \stl_set2('uint32_t');	//<std::set<uint32_t> >
		$this->needAttrDic = 0;	//<uint32_t>
		$this->attrOnly = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetPubNavs_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetPubNavs_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushObject($this->navId,'stl_set');	//<std::set<uint32_t> > 导航Id，批量，必填
		$bs->pushUint32_t($this->needAttrDic);	//<uint32_t> 是否需要填充属性字典。叶子导航是品类，这个时候是有属性的
		$bs->pushUint32_t($this->attrOnly);	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011823;
	}
}

class GetPubNavs_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('stl_map<uint32_t,\b2b2c\nca\ddo\NavExDdo>');	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018823;
	}
}

namespace b2b2c\nca\dao;
class GetPubPathReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $optionId;	//<uint32_t> 属性值id(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->navId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetPubPathReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetPubPathReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->optionId);	//<uint32_t> 属性值id

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x5360180e;
	}
}

class GetPubPathResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $subNode;	//<std::vector<c2cent::bo::nca_v3::CPublistNode_v3> > 发布路径节点数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['subNode'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\PublistNode_v3>');	//<std::vector<c2cent::bo::nca_v3::CPublistNode_v3> > 发布路径节点数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x5360880e;
	}
}

namespace b2b2c\nca\dao;
class GetPubPath_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $navId;	//<uint32_t>  导航id，必填(版本>=0)
	private $attrId;	//<uint32_t>  属性项id，必填(版本>=0)
	private $optionId;	//<uint32_t>  属性值id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetPubPath_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetPubPath_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t>  导航id，必填
		$bs->pushUint32_t($this->attrId);	//<uint32_t>  属性项id，必填
		$bs->pushUint32_t($this->optionId);	//<uint32_t>  属性值id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA001180e;
	}
}

class GetPubPath_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $subNode;	//<std::vector<b2b2c::nca::ddo::CPublistNodeDdo> > 发布路径节点数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['subNode'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\PublistNodeDdo>');	//<std::vector<b2b2c::nca::ddo::CPublistNodeDdo> > 发布路径节点数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA001880e;
	}
}

namespace b2b2c\nca\dao;
class GetPublishInfoReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $metaClassId;	//<uint32_t> 类目id(版本>=0)
	private $classPath;	//<std::string> 非空则取一级属性(版本>=0)
	private $attrPath;	//<std::string> 属性串(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->metaClassId = 0;	//<uint32_t>
		$this->classPath = "";	//<std::string>
		$this->attrPath = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetPublishInfoReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetPublishInfoReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->metaClassId);	//<uint32_t> 类目id
		$bs->pushString($this->classPath);	//<std::string> 非空则取一级属性
		$bs->pushString($this->attrPath);	//<std::string> 属性串

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x5360180d;
	}
}

class GetPublishInfoResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $nav;	//<c2cent::bo::nca_v3::CNavBoEx_v3> 导航数据(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['nav'] = $bs->popObject('\c2cent\bo\nca_v3\NavBoEx_v3');	//<c2cent::bo::nca_v3::CNavBoEx_v3> 导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x5360880d;
	}
}

namespace b2b2c\nca\dao;
class GetPublishInfo_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $metaClassId;	//<uint32_t> 类目id，必填(版本>=0)
	private $classPath;	//<std::string> 非空则取一级属性，必填(版本>=0)
	private $attrPath;	//<std::string> 属性串，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->metaClassId = 0;	//<uint32_t>
		$this->classPath = "";	//<std::string>
		$this->attrPath = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetPublishInfo_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetPublishInfo_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->metaClassId);	//<uint32_t> 类目id，必填
		$bs->pushString($this->classPath);	//<std::string> 非空则取一级属性，必填
		$bs->pushString($this->attrPath);	//<std::string> 属性串，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA001180d;
	}
}

class GetPublishInfo_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<b2b2c::nca::ddo::CNavExDdo> 导航数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('\b2b2c\nca\ddo\NavExDdo');	//<b2b2c::nca::ddo::CNavExDdo> 导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA001880d;
	}
}

namespace b2b2c\nca\dao;
class GetSearchInfoReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $attrIn;	//<std::string> 属性串，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->attrIn = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetSearchInfoReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetSearchInfoReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushString($this->attrIn);	//<std::string> 属性串，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601814;
	}
}

class GetSearchInfoResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attrOut;	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 排序的属性项(版本>=0)
	private $searchPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 面包屑(版本>=0)
	private $brotherNode;	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > > key是面包屑每级的导航id，Value是面包屑每级的兄弟节点列表(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attrOut'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\AttrBo_v3>');	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 排序的属性项
		$this->_arr_value['searchPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 面包屑
		$this->_arr_value['brotherNode'] = $bs->popObject('stl_map<uint32_t,stl_vector<\c2cent\bo\nca_v3\NavEntry_v3> >');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > > key是面包屑每级的导航id，Value是面包屑每级的兄弟节点列表
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0x53608814;
	}
}

namespace b2b2c\nca\dao;
class GetSearchInfo4SX_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $attrIn;	//<std::map<uint32_t,std::set<uint32_t> > > 入参过滤值，key是属性项id，value是值id的集合，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->attrIn = new \stl_map2('uint32_t,stl_set<uint32_t> ');	//<std::map<uint32_t,std::set<uint32_t> > >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetSearchInfo4SX_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetSearchInfo4SX_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushObject($this->attrIn,'stl_map');	//<std::map<uint32_t,std::set<uint32_t> > > 入参过滤值，key是属性项id，value是值id的集合，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0021801;
	}
}

class GetSearchInfo4SX_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attrOut;	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 排序的属性项(版本>=0)
	private $brotherNode;	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CNavEntryDdo> > > key是面包屑每级的导航id，Value是面包屑每级的兄弟节点列表(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attrOut'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\AttrDdo>');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 排序的属性项
		$this->_arr_value['brotherNode'] = $bs->popObject('stl_map<uint32_t,stl_vector<\b2b2c\nca\ddo\NavEntryDdo> >');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CNavEntryDdo> > > key是面包屑每级的导航id，Value是面包屑每级的兄弟节点列表
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0028801;
	}
}

namespace b2b2c\nca\dao;
class GetSearchNav_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $navId;	//<uint32_t> 导航Id，必填(版本>=0)
	private $needAttrDic;	//<uint32_t> 是否需要填充属性字典。叶子导航是品类，这个时候是有属性的(版本>=0)
	private $attrOnly;	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->navId = 0;	//<uint32_t>
		$this->needAttrDic = 0;	//<uint32_t>
		$this->attrOnly = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetSearchNav_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetSearchNav_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航Id，必填
		$bs->pushUint32_t($this->needAttrDic);	//<uint32_t> 是否需要填充属性字典。叶子导航是品类，这个时候是有属性的
		$bs->pushUint32_t($this->attrOnly);	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011824;
	}
}

class GetSearchNav_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<b2b2c::nca::ddo::CNavExDdo> 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('\b2b2c\nca\ddo\NavExDdo');	//<b2b2c::nca::ddo::CNavExDdo> 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018824;
	}
}

namespace b2b2c\nca\dao;
class GetSearchNavs_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $navId;	//<std::set<uint32_t> > 导航Id，批量，必填(版本>=0)
	private $needAttrDic;	//<uint32_t> 是否需要填充属性字典。叶子导航是品类，这个时候是有属性的(版本>=0)
	private $attrOnly;	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->navId = new \stl_set2('uint32_t');	//<std::set<uint32_t> >
		$this->needAttrDic = 0;	//<uint32_t>
		$this->attrOnly = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetSearchNavs_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetSearchNavs_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushObject($this->navId,'stl_set');	//<std::set<uint32_t> > 导航Id，批量，必填
		$bs->pushUint32_t($this->needAttrDic);	//<uint32_t> 是否需要填充属性字典。叶子导航是品类，这个时候是有属性的
		$bs->pushUint32_t($this->attrOnly);	//<uint32_t> 属性字典中是否只需要属性项，而不需要属性值
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011825;
	}
}

class GetSearchNavs_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 品类数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('stl_map<uint32_t,\b2b2c\nca\ddo\NavExDdo>');	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 品类数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018825;
	}
}

namespace b2b2c\nca\dao;
class GetSearchTopNavByCatalog_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $catalog;	//<uint32_t> 频道Id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->catalog = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetSearchTopNavByCatalog_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetSearchTopNavByCatalog_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushUint32_t($this->catalog);	//<uint32_t> 频道Id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011828;
	}
}

class GetSearchTopNavByCatalog_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 一级导航数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('stl_map<uint32_t,\b2b2c\nca\ddo\NavExDdo>');	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 一级导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018828;
	}
}

namespace b2b2c\nca\dao;
class GetSearchTopNavByCatalogs_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $catalog;	//<std::set<uint32_t> > 频道Id，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->catalog = new \stl_set2('uint32_t');	//<std::set<uint32_t> >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetSearchTopNavByCatalogs_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetSearchTopNavByCatalogs_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushObject($this->catalog,'stl_set');	//<std::set<uint32_t> > 频道Id，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011829;
	}
}

class GetSearchTopNavByCatalogs_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $nav;	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 一级导航数据(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['nav'] = $bs->popObject('stl_map<uint32_t,\b2b2c\nca\ddo\NavExDdo>');	//<std::map<uint32_t,b2b2c::nca::ddo::CNavExDdo> > 一级导航数据
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018829;
	}
}

namespace b2b2c\nca\dao;
class GetStaticAttrReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $attrId;	//<uint32_t> 属性项Id(版本>=0)
	private $isNeedOptions;	//<uint32_t> 是否需要属性值,0:不需要,1：需要(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->attrId = 0;	//<uint32_t>
		$this->isNeedOptions = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetStaticAttrReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetStaticAttrReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项Id
		$bs->pushUint32_t($this->isNeedOptions);	//<uint32_t> 是否需要属性值,0:不需要,1：需要

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601807;
	}
}

class GetStaticAttrResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $attr;	//<c2cent::bo::nca_v3::CAttrBo_v3> 属性项(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['attr'] = $bs->popObject('\c2cent\bo\nca_v3\AttrBo_v3');	//<c2cent::bo::nca_v3::CAttrBo_v3> 属性项
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608807;
	}
}

namespace b2b2c\nca\dao;
class GetStaticAttrOp_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $attrId;	//<uint32_t> 属性项Id，必填(版本>=0)
	private $optionId;	//<uint32_t> 指定属性值id(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetStaticAttrOp_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetStaticAttrOp_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项Id，必填
		$bs->pushUint32_t($this->optionId);	//<uint32_t> 指定属性值id
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011814;
	}
}

class GetStaticAttrOp_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attr;	//<b2b2c::nca::ddo::CAttrDdo> 属性项(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attr'] = $bs->popObject('\b2b2c\nca\ddo\AttrDdo');	//<b2b2c::nca::ddo::CAttrDdo> 属性项
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018814;
	}
}

namespace b2b2c\nca\dao;
class GetStaticAttr_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $attrId;	//<uint32_t> 属性项Id，必填(版本>=0)
	private $isNeedOptions;	//<uint32_t> 是否需要属性值，必填;0:不需要,1：需要 (版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->isNeedOptions = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("GetStaticAttr_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetStaticAttr_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项Id，必填
		$bs->pushUint32_t($this->isNeedOptions);	//<uint32_t> 是否需要属性值，必填;0:不需要,1：需要 
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011807;
	}
}

class GetStaticAttr_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attr;	//<b2b2c::nca::ddo::CAttrDdo> 属性项(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attr'] = $bs->popObject('\b2b2c\nca\ddo\AttrDdo');	//<b2b2c::nca::ddo::CAttrDdo> 属性项
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018807;
	}
}

namespace b2b2c\nca\dao;
class IsAttrStrValidReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $attrString;	//<std::string> 属性串(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrString = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("IsAttrStrValidReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("IsAttrStrValidReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushString($this->attrString);	//<std::string> 属性串

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x5360180b;
	}
}

class IsAttrStrValidResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $sReason;	//<std::string> 错误消息(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['sReason'] = $bs->popString();	//<std::string> 错误消息
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x5360880b;
	}
}

namespace b2b2c\nca\dao;
class IsAttrStrValid_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $navId;	//<uint32_t> 导航id，必填(版本>=0)
	private $attrString;	//<std::string> 属性串，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrString = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("IsAttrStrValid_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("IsAttrStrValid_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id，必填
		$bs->pushString($this->attrString);	//<std::string> 属性串，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA001180b;
	}
}

class IsAttrStrValid_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reason;	//<std::string> 错误消息(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reason'] = $bs->popString();	//<std::string> 错误消息
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA001880b;
	}
}

namespace b2b2c\nca\dao;
class MakeAttrTextReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $attrBoList;	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 属性结构体列表(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrBoList = new \stl_vector2('\c2cent\bo\nca_v3\AttrBo_v3');	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("MakeAttrTextReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("MakeAttrTextReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushObject($this->attrBoList,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 属性结构体列表

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601808;
	}
}

class MakeAttrTextResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $attrString;	//<std::string> 属性串(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['attrString'] = $bs->popString();	//<std::string> 属性串
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608808;
	}
}

namespace b2b2c\nca\dao;
class MakeAttrText_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $navId;	//<uint32_t> 导航id，必填(版本>=0)
	private $attrBoList;	//<std::vector<b2b2c::nca::ddo::CAttrDdo> >  属性结构体列表 (版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrBoList = new \stl_vector2('\b2b2c\nca\ddo\AttrDdo');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("MakeAttrText_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("MakeAttrText_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id，必填
		$bs->pushObject($this->attrBoList,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> >  属性结构体列表 
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011808;
	}
}

class MakeAttrText_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attrString;	//<std::string> 属性串(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attrString'] = $bs->popString();	//<std::string> 属性串
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018808;
	}
}

namespace b2b2c\nca\dao;
class ParseAttr4SXOnly_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $saleAttrsIn;	//<std::map<uint32_t,std::vector<uint32_t> > > 解析销售属性，key是属性项id，值是需要解释的项id的集合，必填(版本>=0)
	private $commAttrsIn;	//<std::map<uint32_t,std::string> > 解析一般展示属性，传进来是个属性id串,key作为这个串的标志，不限定是什么值，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->saleAttrsIn = new \stl_map2('uint32_t,stl_vector<uint32_t> ');	//<std::map<uint32_t,std::vector<uint32_t> > >
		$this->commAttrsIn = new \stl_map2('uint32_t,stl_string');	//<std::map<uint32_t,std::string> >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("ParseAttr4SXOnly_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ParseAttr4SXOnly_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushObject($this->saleAttrsIn,'stl_map');	//<std::map<uint32_t,std::vector<uint32_t> > > 解析销售属性，key是属性项id，值是需要解释的项id的集合，必填
		$bs->pushObject($this->commAttrsIn,'stl_map');	//<std::map<uint32_t,std::string> > 解析一般展示属性，传进来是个属性id串,key作为这个串的标志，不限定是什么值，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0021810;
	}
}

class ParseAttr4SXOnly_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $fullPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 面包屑(版本>=0)
	private $saleAttrsOut;	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> > 解析销售属性(版本>=0)
	private $commAttrsOut;	//<std::map<uint32_t,std::string> > 解析一般展示属性(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 面包屑
		$this->_arr_value['saleAttrsOut'] = $bs->popObject('stl_map<uint32_t,\b2b2c\nca\ddo\AttrDdo>');	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> > 解析销售属性
		$this->_arr_value['commAttrsOut'] = $bs->popObject('stl_map<uint32_t,stl_string>');	//<std::map<uint32_t,std::string> > 解析一般展示属性
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0028810;
	}
}

namespace b2b2c\nca\dao;
class ParseAttr4SX_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $saleAttrsIn;	//<std::map<uint32_t,std::vector<uint32_t> > > 解析销售属性，key是属性项id，值是需要解释的项id的集合，必填(版本>=0)
	private $commAttrsIn;	//<std::map<uint32_t,std::string> > 解析一般展示属性，传进来是个属性id串,key作为这个串的标志，不限定是什么值，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->saleAttrsIn = new \stl_map2('uint32_t,stl_vector<uint32_t> ');	//<std::map<uint32_t,std::vector<uint32_t> > >
		$this->commAttrsIn = new \stl_map2('uint32_t,stl_string');	//<std::map<uint32_t,std::string> >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("ParseAttr4SX_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ParseAttr4SX_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushObject($this->saleAttrsIn,'stl_map');	//<std::map<uint32_t,std::vector<uint32_t> > > 解析销售属性，key是属性项id，值是需要解释的项id的集合，必填
		$bs->pushObject($this->commAttrsIn,'stl_map');	//<std::map<uint32_t,std::string> > 解析一般展示属性，传进来是个属性id串,key作为这个串的标志，不限定是什么值，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011810;
	}
}

class ParseAttr4SX_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $fullPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 面包屑(版本>=0)
	private $saleAttrsOut;	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> > 解析销售属性(版本>=0)
	private $commAttrsOut;	//<std::map<uint32_t,std::string> > 解析一般展示属性(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 面包屑
		$this->_arr_value['saleAttrsOut'] = $bs->popObject('stl_map<uint32_t,\b2b2c\nca\ddo\AttrDdo>');	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> > 解析销售属性
		$this->_arr_value['commAttrsOut'] = $bs->popObject('stl_map<uint32_t,stl_string>');	//<std::map<uint32_t,std::string> > 解析一般展示属性
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018810;
	}
}

namespace b2b2c\nca\dao;
class ParseAttrTextReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $attrString;	//<std::string> 属性串(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrString = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("ParseAttrTextReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ParseAttrTextReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushString($this->attrString);	//<std::string> 属性串

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601809;
	}
}

class ParseAttrTextResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $attrBoList;	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 属性(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['attrBoList'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\AttrBo_v3>');	//<std::vector<c2cent::bo::nca_v3::CAttrBo_v3> > 属性
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x53608809;
	}
}

namespace b2b2c\nca\dao;
class ParseAttrTextMultiMeta_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $commAttrsIn;	//<std::map<uint32_t,std::map<uint32_t,std::string> > > 属性串，必填，外层map的key是一个标志，内层map的key是品类(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->commAttrsIn = new \stl_map2('uint32_t,stl_map<uint32_t,stl_string> ');	//<std::map<uint32_t,std::map<uint32_t,std::string> > >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("ParseAttrTextMultiMeta_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ParseAttrTextMultiMeta_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushObject($this->commAttrsIn,'stl_map');	//<std::map<uint32_t,std::map<uint32_t,std::string> > > 属性串，必填，外层map的key是一个标志，内层map的key是品类
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011813;
	}
}

class ParseAttrTextMultiMeta_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $commAttrsOut;	//<std::map<uint32_t,std::string> > 属性串，必填，map的key是一个标志，string是解析好的属性串(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['commAttrsOut'] = $bs->popObject('stl_map<uint32_t,stl_string>');	//<std::map<uint32_t,std::string> > 属性串，必填，map的key是一个标志，string是解析好的属性串
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018813;
	}
}

namespace b2b2c\nca\dao;
class ParseAttrTextNoCheck_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $navId;	//<uint32_t> 导航id，必填(版本>=0)
	private $attrString;	//<std::string> 属性串，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrString = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("ParseAttrTextNoCheck_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ParseAttrTextNoCheck_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id，必填
		$bs->pushString($this->attrString);	//<std::string> 属性串，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011812;
	}
}

class ParseAttrTextNoCheck_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attrBoList;	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 属性(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attrBoList'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\AttrDdo>');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 属性
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018812;
	}
}

namespace b2b2c\nca\dao;
class ParseAttrText_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $attrStr;	//<std::string> 属性串，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->metaId = 0;	//<uint32_t>
		$this->attrStr = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("ParseAttrText_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ParseAttrText_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushString($this->attrStr);	//<std::string> 属性串，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011826;
	}
}

class ParseAttrText_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attr;	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 解析结果(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attr'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\AttrDdo>');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 解析结果
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018826;
	}
}

namespace b2b2c\nca\dao;
class ParseAttrText_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $mapId;	//<uint32_t> 地图id，必填(版本>=0)
	private $navId;	//<uint32_t> 导航id，必填(版本>=0)
	private $attrString;	//<std::string> 属性串，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrString = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("ParseAttrText_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ParseAttrText_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id，必填
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id，必填
		$bs->pushString($this->attrString);	//<std::string> 属性串，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011809;
	}
}

class ParseAttrText_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attrBoList;	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 属性(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attrBoList'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\AttrDdo>');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 属性
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018809;
	}
}

namespace b2b2c\nca\dao;
class ParseAttrTexts_ALLReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $aPIControl;	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关(版本>=0)
	private $attrIn;	//<std::map<uint32_t,std::set<std::string> > > key:品类id，value:属性串们，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->aPIControl = new \b2b2c\nca\ddo\APIControl();	//<b2b2c::nca::ddo::CAPIControl>
		$this->attrIn = new \stl_map2('uint32_t,stl_set<stl_string> ');	//<std::map<uint32_t,std::set<std::string> > >
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("ParseAttrTexts_ALLReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ParseAttrTexts_ALLReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushObject($this->aPIControl,'\b2b2c\nca\ddo\APIControl');	//<b2b2c::nca::ddo::CAPIControl> 调用控制，业务相关
		$bs->pushObject($this->attrIn,'stl_map');	//<std::map<uint32_t,std::set<std::string> > > key:品类id，value:属性串们，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011827;
	}
}

class ParseAttrTexts_ALLResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attrOut;	//<std::map<uint32_t,std::map<std::string,std::vector<b2b2c::nca::ddo::CAttrDdo> > > > key：品类id；value：又是一个map，其中key是属性串，value是解析结果(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attrOut'] = $bs->popObject('stl_map<uint32_t,stl_map<stl_string,stl_vector<\b2b2c\nca\ddo\AttrDdo> > >');	//<std::map<uint32_t,std::map<std::string,std::vector<b2b2c::nca::ddo::CAttrDdo> > > > key：品类id；value：又是一个map，其中key是属性串，value是解析结果
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018827;
	}
}

namespace b2b2c\nca\dao;
class SearchPubNavByKeyReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> Source(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)
	private $needAttr;	//<uint32_t> 是否需要搜索属性,0:不需要,1:需要(版本>=0)
	private $key;	//<std::string> 关键词(版本>=0)
	private $count;	//<uint32_t> 需要的个数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
		$this->needAttr = 0;	//<uint32_t>
		$this->key = "";	//<std::string>
		$this->count = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("SearchPubNavByKeyReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SearchPubNavByKeyReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> Source
		$bs->pushString($this->inReserve);	//<std::string> InReserve
		$bs->pushUint32_t($this->needAttr);	//<uint32_t> 是否需要搜索属性,0:不需要,1:需要
		$bs->pushString($this->key);	//<std::string> 关键词
		$bs->pushUint32_t($this->count);	//<uint32_t> 需要的个数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x5360180c;
	}
}

class SearchPubNavByKeyResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $navMatchKeyList;	//<std::vector<c2cent::bo::nca_v3::CNavMatchKey_v3> > 结果集(版本>=0)
	private $outReserve;	//<std::string> OutReserve(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['navMatchKeyList'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavMatchKey_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavMatchKey_v3> > 结果集
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> OutReserve

	}

	function getCmdId() {
		return 0x5360880c;
	}
}

namespace b2b2c\nca\dao;
class SearchPubNavByKey_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码，必填(版本>=0)
	private $source;	//<std::string> 调用来源，必填(版本>=0)
	private $sceneId;	//<uint32_t> 场景Id，必填(版本>=0)
	private $needAttr;	//<uint32_t> 是否需要搜索属性，必填;0:不需要,1:需要 (版本>=0)
	private $key;	//<std::string> 关键词，必填(版本>=0)
	private $count;	//<uint32_t> 需要的个数，必填(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->sceneId = 0;	//<uint32_t>
		$this->needAttr = 0;	//<uint32_t>
		$this->key = "";	//<std::string>
		$this->count = 0;	//<uint32_t>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("SearchPubNavByKey_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SearchPubNavByKey_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码，必填
		$bs->pushString($this->source);	//<std::string> 调用来源，必填
		$bs->pushUint32_t($this->sceneId);	//<uint32_t> 场景Id，必填
		$bs->pushUint32_t($this->needAttr);	//<uint32_t> 是否需要搜索属性，必填;0:不需要,1:需要 
		$bs->pushString($this->key);	//<std::string> 关键词，必填
		$bs->pushUint32_t($this->count);	//<uint32_t> 需要的个数，必填
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA001180c;
	}
}

class SearchPubNavByKey_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $navMatchKeyList;	//<std::vector<b2b2c::nca::ddo::CNavMatchKeyDdo> >  结果集 (版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['navMatchKeyList'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavMatchKeyDdo>');	//<std::vector<b2b2c::nca::ddo::CNavMatchKeyDdo> >  结果集 
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA001880c;
	}
}

namespace b2b2c\nca\dao;
class TransAttrStrReq{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> source(版本>=0)
	private $metaId;	//<uint32_t> 品类id(版本>=0)
	private $attrA;	//<std::string> 源属性串，拍拍旧格式(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->metaId = 0;	//<uint32_t>
		$this->attrA = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("TransAttrStrReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("TransAttrStrReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> source
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id
		$bs->pushString($this->attrA);	//<std::string> 源属性串，拍拍旧格式
		$bs->pushString($this->inReserve);	//<std::string> InReserve

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601816;
	}
}

class TransAttrStrResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $attrB;	//<std::string> 目标属性串B，拍拍新格式(版本>=0)
	private $attrC;	//<std::string> 目标属性串C，拍拍新格式(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['attrB'] = $bs->popString();	//<std::string> 目标属性串B，拍拍新格式
		$this->_arr_value['attrC'] = $bs->popString();	//<std::string> 目标属性串C，拍拍新格式

	}

	function getCmdId() {
		return 0x53608816;
	}
}

namespace b2b2c\nca\dao;
class TransAttrStr2Req{
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> source(版本>=0)
	private $metaId;	//<uint32_t> 品类id(版本>=0)
	private $attrB;	//<std::string> 目标属性串B，拍拍新格式(版本>=0)
	private $inReserve;	//<std::string> InReserve(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->metaId = 0;	//<uint32_t>
		$this->attrB = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("TransAttrStr2Req\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("TransAttrStr2Req\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> source
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id
		$bs->pushString($this->attrB);	//<std::string> 目标属性串B，拍拍新格式
		$bs->pushString($this->inReserve);	//<std::string> InReserve

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x53601817;
	}
}

class TransAttrStr2Resp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $attrA;	//<std::string> 源属性串，拍拍旧格式(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['attrA'] = $bs->popString();	//<std::string> 源属性串，拍拍旧格式

	}

	function getCmdId() {
		return 0x53608817;
	}
}

namespace b2b2c\nca\dao;
class TransAttrStr2_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码(版本>=0)
	private $source;	//<std::string> 调用来源(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $attr3;	//<std::string> 源属性串，格式版本:3(版本>=0)
	private $inReserve;	//<std::string> 请求保留字(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->metaId = 0;	//<uint32_t>
		$this->attr3 = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("TransAttrStr2_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("TransAttrStr2_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码
		$bs->pushString($this->source);	//<std::string> 调用来源
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushString($this->attr3);	//<std::string> 源属性串，格式版本:3
		$bs->pushString($this->inReserve);	//<std::string> 请求保留字

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA001181A;
	}
}

class TransAttrStr2_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attr2;	//<std::string> 目标属性串，格式版本:2(版本>=0)
	private $textAttr;	//<std::string> 目标属性串，所有属性项和属性值都解析成字符串(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attr2'] = $bs->popString();	//<std::string> 目标属性串，格式版本:2
		$this->_arr_value['textAttr'] = $bs->popString();	//<std::string> 目标属性串，所有属性项和属性值都解析成字符串
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA001881A;
	}
}

namespace b2b2c\nca\dao;
class TransAttrStr_WGReq{
	private $_arr_value=array();	//数组形式的类
	private $machineKey;	//<std::string> 机器码(版本>=0)
	private $source;	//<std::string> 来源(版本>=0)
	private $metaId;	//<uint32_t> 品类id，必填(版本>=0)
	private $attrA;	//<std::string> 源属性串，拍拍旧格式(版本>=0)
	private $inReserve;	//<std::string> 保留字段(版本>=0)

	function __construct() {
		$this->machineKey = "";	//<std::string>
		$this->source = "";	//<std::string>
		$this->metaId = 0;	//<uint32_t>
		$this->attrA = "";	//<std::string>
		$this->inReserve = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("TransAttrStr_WGReq\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();	
					if(class_exists($class,false)){						
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}	
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);				
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("TransAttrStr_WGReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function Serialize($bs){
		$bs->pushString($this->machineKey);	//<std::string> 机器码
		$bs->pushString($this->source);	//<std::string> 来源
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id，必填
		$bs->pushString($this->attrA);	//<std::string> 源属性串，拍拍旧格式
		$bs->pushString($this->inReserve);	//<std::string> 保留字段

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0xA0011819;
	}
}

class TransAttrStr_WGResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $attrC;	//<std::string> 目标属性串C，网购格式(版本>=0)
	private $textAttrC;	//<std::string> 目标属性串C，网购格式，所有属性项和属性值都解析成字符串(版本>=0)
	private $outReserve;	//<std::string> 输出保留字(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			return "errmsg is not define.";
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['attrC'] = $bs->popString();	//<std::string> 目标属性串C，网购格式
		$this->_arr_value['textAttrC'] = $bs->popString();	//<std::string> 目标属性串C，网购格式，所有属性项和属性值都解析成字符串
		$this->_arr_value['outReserve'] = $bs->popString();	//<std::string> 输出保留字

	}

	function getCmdId() {
		return 0xA0018819;
	}
}
