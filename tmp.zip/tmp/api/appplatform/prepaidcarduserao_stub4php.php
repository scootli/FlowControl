<?php
// source idl: com.b2b2c.unifiedaccount.idl.PrepaidCardUserAo.java
require_once "prepaidcarduserao_xxo.php";

class BindDealToUserCardTradeReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $icsonUid;
	var $tradeId;
	var $dealId;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->icsonUid = 0; // uint64_t
		 $this->tradeId = 0; // uint64_t
		 $this->dealId = ""; // std::string
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushUint64_t($this->icsonUid); // 序列化易迅Uid, 必填 类型为uint64_t
		$bs->pushUint64_t($this->tradeId); // 序列化交易id, 必填 类型为uint64_t
		$bs->pushString($this->dealId); // 序列化订单号, 必填 类型为std::string
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x3110180a;
	}
}

class BindDealToUserCardTradeResp {
	var $result;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x3110880a;
	}
}

class BindUserCardReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $userCardBindParamPo;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->userCardBindParamPo = new UserCardBindParamPo(); // b2b2c::unifiedaccount::po::CUserCardBindParamPo
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushObject($this->userCardBindParamPo,'UserCardBindParamPo'); // 序列化绑定参数, 必填 类型为b2b2c::unifiedaccount::po::CUserCardBindParamPo
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x31101805;
	}
}

class BindUserCardResp {
	var $result;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x31108805;
	}
}

class BindUserCardUnLoginReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $accessVerifyPo;
	var $userCardBindParamPo;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->accessVerifyPo = new PrepaidCardAccessVerifyPo(); // b2b2c::unifiedaccount::po::CPrepaidCardAccessVerifyPo
		 $this->userCardBindParamPo = new UserCardBindParamPo(); // b2b2c::unifiedaccount::po::CUserCardBindParamPo
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushObject($this->accessVerifyPo,'PrepaidCardAccessVerifyPo'); // 序列化接口校验参数Po, 必填 类型为b2b2c::unifiedaccount::po::CPrepaidCardAccessVerifyPo
		$bs->pushObject($this->userCardBindParamPo,'UserCardBindParamPo'); // 序列化绑定参数, 必填 类型为b2b2c::unifiedaccount::po::CUserCardBindParamPo
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x31101806;
	}
}

class BindUserCardUnLoginResp {
	var $result;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x31108806;
	}
}

class CancelUserCardReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $accessVerifyPo;
	var $userCardFallbackParamPo;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->accessVerifyPo = new PrepaidCardAccessVerifyPo(); // b2b2c::unifiedaccount::po::CPrepaidCardAccessVerifyPo
		 $this->userCardFallbackParamPo = new UserCardFallbackParamPo(); // b2b2c::unifiedaccount::po::CUserCardFallbackParamPo
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushObject($this->accessVerifyPo,'PrepaidCardAccessVerifyPo'); // 序列化接口校验参数Po, 必填 类型为b2b2c::unifiedaccount::po::CPrepaidCardAccessVerifyPo
		$bs->pushObject($this->userCardFallbackParamPo,'UserCardFallbackParamPo'); // 序列化用户退款参数PO, 取消无需填退款单, 取消额度为0则不校验取消预付卡额度 类型为b2b2c::unifiedaccount::po::CUserCardFallbackParamPo
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x31101809;
	}
}

class CancelUserCardResp {
	var $result;
	var $refundTradeId;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->refundTradeId = $bs->popUint64_t(); // 反序列化取消交易id, 购物流程可根据需要记录该交易id 类型为uint64_t
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x31108809;
	}
}

class ConsumeUserCardReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $userCardConsumeParamPo;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->userCardConsumeParamPo = new UserCardConsumeParamPo(); // b2b2c::unifiedaccount::po::CUserCardConsumeParamPo
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushObject($this->userCardConsumeParamPo,'UserCardConsumeParamPo'); // 序列化用户消费预付卡参数PO 类型为b2b2c::unifiedaccount::po::CUserCardConsumeParamPo
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x31101807;
	}
}

class ConsumeUserCardResp {
	var $result;
	var $tradeId;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->tradeId = $bs->popUint64_t(); // 反序列化返回交易id, 卡系统生成标记唯一的交易id, 交易流程需记录该id 类型为uint64_t
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x31108807;
	}
}

class FindUserCardListReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $userCardFilterPo;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->userCardFilterPo = new UserCardFilterPo(); // b2b2c::unifiedaccount::po::CUserCardFilterPo
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushObject($this->userCardFilterPo,'UserCardFilterPo'); // 序列化绑定预付卡查询条件, 必填 类型为b2b2c::unifiedaccount::po::CUserCardFilterPo
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x31101802;
	}
}

class FindUserCardListResp {
	var $result;
	var $userCardPoList;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->userCardPoList = $bs->popObject('UserCardPoList'); // 反序列化返回用户绑定卡列表 类型为b2b2c::unifiedaccount::po::CUserCardPoList
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x31108802;
	}
}

class FindUserCardTradeListReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $userCardTradeLogFilterPo;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->userCardTradeLogFilterPo = new UserCardTradeLogFilterPo(); // b2b2c::unifiedaccount::po::CUserCardTradeLogFilterPo
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushObject($this->userCardTradeLogFilterPo,'UserCardTradeLogFilterPo'); // 序列化查询消费记录条件 类型为b2b2c::unifiedaccount::po::CUserCardTradeLogFilterPo
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x31101803;
	}
}

class FindUserCardTradeListResp {
	var $result;
	var $userCardTradeLogPoList;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->userCardTradeLogPoList = $bs->popObject('UserCardTradeLogPoList'); // 反序列化返回用户消费记录 类型为b2b2c::unifiedaccount::po::CUserCardTradeLogPoList
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x31108803;
	}
}

class GetCardInfoByCardNumberReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $icsonUid;
	var $cardNumber;
	var $passwd;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->icsonUid = 0; // uint64_t
		 $this->cardNumber = ""; // std::string
		 $this->passwd = ""; // std::string
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushUint64_t($this->icsonUid); // 序列化查询用户易迅uid 类型为uint64_t
		$bs->pushString($this->cardNumber); // 序列化预付卡卡号, 必填 类型为std::string
		$bs->pushString($this->passwd); // 序列化预付卡密码, 查询已绑定可不填 类型为std::string
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x31101801;
	}
}

class GetCardInfoByCardNumberResp {
	var $result;
	var $userCardPo;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->userCardPo = $bs->popObject('UserCardPo'); // 反序列化用户预付卡信息PO 类型为b2b2c::unifiedaccount::po::CUserCardPo
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x31108801;
	}
}

class GetUserCardTotalReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $icsonUid;
	var $infoType;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->icsonUid = 0; // uint64_t
		 $this->infoType = 0; // uint32_t
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushUint64_t($this->icsonUid); // 序列化易迅uid, 必填 类型为uint64_t
		$bs->pushUint32_t($this->infoType); // 序列化查询条件(默认0, 通过组合查询如0x01|0x02), 0: 返回有效期内的各参数, 0x01: 需返回过期数 0x02: 需返回已用完数 类型为uint32_t
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x31101804;
	}
}

class GetUserCardTotalResp {
	var $result;
	var $userCardTotalPo;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->userCardTotalPo = $bs->popObject('UserCardTotalPo'); // 反序列化返回用户绑定预付卡汇总信息 类型为b2b2c::unifiedaccount::po::CUserCardTotalPo
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x31108804;
	}
}

class RefundUserCardReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $optionId;
	var $accessVerifyPo;
	var $userCardFallbackParamPo;
	var $inReserve;

	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->optionId = 0; // uint32_t
		 $this->accessVerifyPo = new PrepaidCardAccessVerifyPo(); // b2b2c::unifiedaccount::po::CPrepaidCardAccessVerifyPo
		 $this->userCardFallbackParamPo = new UserCardFallbackParamPo(); // b2b2c::unifiedaccount::po::CUserCardFallbackParamPo
		 $this->inReserve = ""; // std::string
	}	

	function Serialize(&$bs){
		$bs->pushString($this->machineKey); // 序列化机器码,必填,调用方可填写一个随机串接口,为空则返回参数错误 类型为std::string
		$bs->pushString($this->source); // 序列化调用来源文件名称,必填,为空则返回参数错误 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id,必填（目前填0即可） 类型为uint32_t
		$bs->pushUint32_t($this->optionId); // 序列化选项ID(默认为utf8): 0-中文使用utf8编码, 1-中文使用gbk编码 类型为uint32_t
		$bs->pushObject($this->accessVerifyPo,'PrepaidCardAccessVerifyPo'); // 序列化接口校验参数Po, 必填 类型为b2b2c::unifiedaccount::po::CPrepaidCardAccessVerifyPo
		$bs->pushObject($this->userCardFallbackParamPo,'UserCardFallbackParamPo'); // 序列化用户卡退款参数PO, 退款参数中退款流水号必填 类型为b2b2c::unifiedaccount::po::CUserCardFallbackParamPo
		$bs->pushString($this->inReserve); // 序列化请求保留字  类型为std::string

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x31101808;
	}
}

class RefundUserCardResp {
	var $result;
	var $refundTradeId;
	var $outReserve;
	var $errmsg;

	function Unserialize(&$bs){
		$this->result = $bs->popUint32_t();
		$this->refundTradeId = $bs->popUint64_t(); // 反序列化退款交易id, 购物流程可根据需要记录该退款交易id 类型为uint64_t
		$this->outReserve = $bs->popString(); // 反序列化返回保留字  类型为std::string
		$this->errmsg = $bs->popString(); // 反序列化错误信息  类型为std::string

	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x31108808;
	}
}
?>