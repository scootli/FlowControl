<?php

//source idl: com.b2b2c.unifiedaccount.idl.GetUserCardTotalResp.java

if (!class_exists('UserCardTotalPo')) {
class UserCardTotalPo
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 易迅uid
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 用户账户当前可用余额(不包括未到使用时间的卡), 单位分
		 *
		 * 版本 >= 0
		 */
		var $ddwAvailableBalance; //uint64_t

		/**
		 * 用户已绑定可使用预付卡数
		 *
		 * 版本 >= 0
		 */
		var $dwUsableCardNum; //uint32_t

		/**
		 * 用户即将到期预付卡数
		 *
		 * 版本 >= 0
		 */
		var $dwWillExpireCardNum; //uint32_t

		/**
		 * 卡已过期数量
		 *
		 * 版本 >= 0
		 */
		var $dwExpireCardNum; //uint32_t

		/**
		 * 卡被限制使用数量
		 *
		 * 版本 >= 0
		 */
		var $dwLimitedCardNum; //uint32_t

		/**
		 * 已用完的数量
		 *
		 * 版本 >= 0
		 */
		var $dwUsedCardNum; //uint32_t

		/**
		 * reserve  预留字段,无用
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cIcsonUid_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cAvailableBalance_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cUsableCardNum_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cWillExpireCardNum_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cExpireCardNum_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cLimitedCardNum_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cUsedCardNum_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cReserve_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->ddwAvailableBalance = 0; // uint64_t
			 $this->dwUsableCardNum = 0; // uint32_t
			 $this->dwWillExpireCardNum = 0; // uint32_t
			 $this->dwExpireCardNum = 0; // uint32_t
			 $this->dwLimitedCardNum = 0; // uint32_t
			 $this->dwUsedCardNum = 0; // uint32_t
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cIcsonUid_u = 0; // uint8_t
			 $this->cAvailableBalance_u = 0; // uint8_t
			 $this->cUsableCardNum_u = 0; // uint8_t
			 $this->cWillExpireCardNum_u = 0; // uint8_t
			 $this->cExpireCardNum_u = 0; // uint8_t
			 $this->cLimitedCardNum_u = 0; // uint8_t
			 $this->cUsedCardNum_u = 0; // uint8_t
			 $this->cReserve_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅uid 类型为uint64_t
			$bs->pushUint64_t($this->ddwAvailableBalance); // 序列化用户账户当前可用余额(不包括未到使用时间的卡), 单位分 类型为uint64_t
			$bs->pushUint32_t($this->dwUsableCardNum); // 序列化用户已绑定可使用预付卡数 类型为uint32_t
			$bs->pushUint32_t($this->dwWillExpireCardNum); // 序列化用户即将到期预付卡数 类型为uint32_t
			$bs->pushUint32_t($this->dwExpireCardNum); // 序列化卡已过期数量 类型为uint32_t
			$bs->pushUint32_t($this->dwLimitedCardNum); // 序列化卡被限制使用数量 类型为uint32_t
			$bs->pushUint32_t($this->dwUsedCardNum); // 序列化已用完的数量 类型为uint32_t
			$bs->pushString($this->strReserve); // 序列化reserve  预留字段,无用 类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cIcsonUid_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cAvailableBalance_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cUsableCardNum_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cWillExpireCardNum_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cExpireCardNum_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cLimitedCardNum_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cUsedCardNum_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cReserve_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅uid 类型为uint64_t
			$this->ddwAvailableBalance = $bs->popUint64_t(); // 反序列化用户账户当前可用余额(不包括未到使用时间的卡), 单位分 类型为uint64_t
			$this->dwUsableCardNum = $bs->popUint32_t(); // 反序列化用户已绑定可使用预付卡数 类型为uint32_t
			$this->dwWillExpireCardNum = $bs->popUint32_t(); // 反序列化用户即将到期预付卡数 类型为uint32_t
			$this->dwExpireCardNum = $bs->popUint32_t(); // 反序列化卡已过期数量 类型为uint32_t
			$this->dwLimitedCardNum = $bs->popUint32_t(); // 反序列化卡被限制使用数量 类型为uint32_t
			$this->dwUsedCardNum = $bs->popUint32_t(); // 反序列化已用完的数量 类型为uint32_t
			$this->strReserve = $bs->popString(); // 反序列化reserve  预留字段,无用 类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cIcsonUid_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cAvailableBalance_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cUsableCardNum_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cWillExpireCardNum_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cExpireCardNum_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cLimitedCardNum_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cUsedCardNum_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cReserve_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.FindUserCardTradeListResp.java

if (!class_exists('UserCardTradeLogPoList')) {
class UserCardTradeLogPoList
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 易迅uid
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 总数
		 *
		 * 版本 >= 0
		 */
		var $dwTotalNum; //uint32_t

		/**
		 * 预付卡消费列表
		 *
		 * 版本 >= 0
		 */
		var $vecUserCardTradeLogPoList; //std::vector<b2b2c::unifiedaccount::po::CUserCardTradeLogPo> 

		/**
		 * reserve  预留字段,无用
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->dwTotalNum = 0; // uint32_t
			 $this->vecUserCardTradeLogPoList = new stl_vector('UserCardTradeLogPo'); // std::vector<b2b2c::unifiedaccount::po::CUserCardTradeLogPo> 
			 $this->strReserve = ""; // std::string
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅uid 类型为uint64_t
			$bs->pushUint32_t($this->dwTotalNum); // 序列化总数 类型为uint32_t
			$bs->pushObject($this->vecUserCardTradeLogPoList,'stl_vector'); // 序列化预付卡消费列表 类型为std::vector<b2b2c::unifiedaccount::po::CUserCardTradeLogPo> 
			$bs->pushString($this->strReserve); // 序列化reserve  预留字段,无用 类型为std::string
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅uid 类型为uint64_t
			$this->dwTotalNum = $bs->popUint32_t(); // 反序列化总数 类型为uint32_t
			$this->vecUserCardTradeLogPoList = $bs->popObject('stl_vector<UserCardTradeLogPo>'); // 反序列化预付卡消费列表 类型为std::vector<b2b2c::unifiedaccount::po::CUserCardTradeLogPo> 
			$this->strReserve = $bs->popString(); // 反序列化reserve  预留字段,无用 类型为std::string

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.UserCardTradeLogPoList.java

if (!class_exists('UserCardTradeLogPo')) {
class UserCardTradeLogPo
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 流水id
		 *
		 * 版本 >= 0
		 */
		var $ddwTradeLogId; //uint64_t

		/**
		 * 易迅uid
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 卡号
		 *
		 * 版本 >= 0
		 */
		var $strCardNumber; //std::string

		/**
		 * 操作类型: 1-入账  2-出账 3-绑定
		 *
		 * 版本 >= 0
		 */
		var $dwOperateType; //uint32_t

		/**
		 * 出入帐(消耗或订单回退)卡值, 单位为分
		 *
		 * 版本 >= 0
		 */
		var $ddwOperateValue; //uint64_t

		/**
		 * 卡余额, 单位为分
		 *
		 * 版本 >= 0
		 */
		var $ddwCardBalance; //uint64_t

		/**
		 * 操作ip
		 *
		 * 版本 >= 0
		 */
		var $strOperateIp; //std::string

		/**
		 * 操作mac
		 *
		 * 版本 >= 0
		 */
		var $strOperateMac; //std::string

		/**
		 * 创建时间
		 *
		 * 版本 >= 0
		 */
		var $ddwCreateTime; //uint64_t

		/**
		 * 修改时间(目前只关联订单号的时间)
		 *
		 * 版本 >= 0
		 */
		var $ddwLastUpdateTime; //uint64_t

		/**
		 * 统一订单号
		 *
		 * 版本 >= 0
		 */
		var $strDealId; //std::string

		/**
		 * 退款单号
		 *
		 * 版本 >= 0
		 */
		var $strRefundId; //std::string

		/**
		 * 备注
		 *
		 * 版本 >= 0
		 */
		var $strRemarks; //std::string

		/**
		 * 保留
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cTradeLogId_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cIcsonUid_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardNumber_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cOperateType_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cOperateValue_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardBalance_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cOperateIp_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cOperateMac_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCreateTime_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cLastUpdateTime_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cRefundId_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cDealId_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cRemarks_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cReserve_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwTradeLogId = 0; // uint64_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->strCardNumber = ""; // std::string
			 $this->dwOperateType = 0; // uint32_t
			 $this->ddwOperateValue = 0; // uint64_t
			 $this->ddwCardBalance = 0; // uint64_t
			 $this->strOperateIp = ""; // std::string
			 $this->strOperateMac = ""; // std::string
			 $this->ddwCreateTime = 0; // uint64_t
			 $this->ddwLastUpdateTime = 0; // uint64_t
			 $this->strDealId = ""; // std::string
			 $this->strRefundId = ""; // std::string
			 $this->strRemarks = ""; // std::string
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cTradeLogId_u = 0; // uint8_t
			 $this->cIcsonUid_u = 0; // uint8_t
			 $this->cCardNumber_u = 0; // uint8_t
			 $this->cOperateType_u = 0; // uint8_t
			 $this->cOperateValue_u = 0; // uint8_t
			 $this->cCardBalance_u = 0; // uint8_t
			 $this->cOperateIp_u = 0; // uint8_t
			 $this->cOperateMac_u = 0; // uint8_t
			 $this->cCreateTime_u = 0; // uint8_t
			 $this->cLastUpdateTime_u = 0; // uint8_t
			 $this->cRefundId_u = 0; // uint8_t
			 $this->cDealId_u = 0; // uint8_t
			 $this->cRemarks_u = 0; // uint8_t
			 $this->cReserve_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwTradeLogId); // 序列化流水id 类型为uint64_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅uid 类型为uint64_t
			$bs->pushString($this->strCardNumber); // 序列化卡号 类型为std::string
			$bs->pushUint32_t($this->dwOperateType); // 序列化操作类型: 1-入账  2-出账 3-绑定 类型为uint32_t
			$bs->pushUint64_t($this->ddwOperateValue); // 序列化出入帐(消耗或订单回退)卡值, 单位为分 类型为uint64_t
			$bs->pushUint64_t($this->ddwCardBalance); // 序列化卡余额, 单位为分 类型为uint64_t
			$bs->pushString($this->strOperateIp); // 序列化操作ip 类型为std::string
			$bs->pushString($this->strOperateMac); // 序列化操作mac 类型为std::string
			$bs->pushUint64_t($this->ddwCreateTime); // 序列化创建时间 类型为uint64_t
			$bs->pushUint64_t($this->ddwLastUpdateTime); // 序列化修改时间(目前只关联订单号的时间) 类型为uint64_t
			$bs->pushString($this->strDealId); // 序列化统一订单号 类型为std::string
			$bs->pushString($this->strRefundId); // 序列化退款单号 类型为std::string
			$bs->pushString($this->strRemarks); // 序列化备注 类型为std::string
			$bs->pushString($this->strReserve); // 序列化保留 类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cTradeLogId_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cIcsonUid_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardNumber_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cOperateType_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cOperateValue_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardBalance_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cOperateIp_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cOperateMac_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCreateTime_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cLastUpdateTime_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cRefundId_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cDealId_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cRemarks_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cReserve_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwTradeLogId = $bs->popUint64_t(); // 反序列化流水id 类型为uint64_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅uid 类型为uint64_t
			$this->strCardNumber = $bs->popString(); // 反序列化卡号 类型为std::string
			$this->dwOperateType = $bs->popUint32_t(); // 反序列化操作类型: 1-入账  2-出账 3-绑定 类型为uint32_t
			$this->ddwOperateValue = $bs->popUint64_t(); // 反序列化出入帐(消耗或订单回退)卡值, 单位为分 类型为uint64_t
			$this->ddwCardBalance = $bs->popUint64_t(); // 反序列化卡余额, 单位为分 类型为uint64_t
			$this->strOperateIp = $bs->popString(); // 反序列化操作ip 类型为std::string
			$this->strOperateMac = $bs->popString(); // 反序列化操作mac 类型为std::string
			$this->ddwCreateTime = $bs->popUint64_t(); // 反序列化创建时间 类型为uint64_t
			$this->ddwLastUpdateTime = $bs->popUint64_t(); // 反序列化修改时间(目前只关联订单号的时间) 类型为uint64_t
			$this->strDealId = $bs->popString(); // 反序列化统一订单号 类型为std::string
			$this->strRefundId = $bs->popString(); // 反序列化退款单号 类型为std::string
			$this->strRemarks = $bs->popString(); // 反序列化备注 类型为std::string
			$this->strReserve = $bs->popString(); // 反序列化保留 类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cTradeLogId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cIcsonUid_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardNumber_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cOperateType_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cOperateValue_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardBalance_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cOperateIp_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cOperateMac_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCreateTime_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cLastUpdateTime_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cRefundId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cDealId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cRemarks_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cReserve_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.FindUserCardTradeListReq.java

if (!class_exists('UserCardTradeLogFilterPo')) {
class UserCardTradeLogFilterPo
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 易迅uid, 必填
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 页码,分页处理, 从0开始
		 *
		 * 版本 >= 0
		 */
		var $dwPageId; //uint32_t

		/**
		 * 每页显示记录条数,分页处理, 最大查询条数定义为20, 必填
		 *
		 * 版本 >= 0
		 */
		var $dwPageSize; //uint32_t

		/**
		 * reserve  预留字段,无用
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cIcsonUid_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cState_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cPageId_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cPageSize_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cReserve_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->dwPageId = 0; // uint32_t
			 $this->dwPageSize = 0; // uint32_t
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cIcsonUid_u = 0; // uint8_t
			 $this->cState_u = 0; // uint8_t
			 $this->cPageId_u = 0; // uint8_t
			 $this->cPageSize_u = 0; // uint8_t
			 $this->cReserve_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅uid, 必填 类型为uint64_t
			$bs->pushUint32_t($this->dwPageId); // 序列化页码,分页处理, 从0开始 类型为uint32_t
			$bs->pushUint32_t($this->dwPageSize); // 序列化每页显示记录条数,分页处理, 最大查询条数定义为20, 必填 类型为uint32_t
			$bs->pushString($this->strReserve); // 序列化reserve  预留字段,无用 类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cIcsonUid_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cState_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cPageId_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cPageSize_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cReserve_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅uid, 必填 类型为uint64_t
			$this->dwPageId = $bs->popUint32_t(); // 反序列化页码,分页处理, 从0开始 类型为uint32_t
			$this->dwPageSize = $bs->popUint32_t(); // 反序列化每页显示记录条数,分页处理, 最大查询条数定义为20, 必填 类型为uint32_t
			$this->strReserve = $bs->popString(); // 反序列化reserve  预留字段,无用 类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cIcsonUid_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cState_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cPageId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cPageSize_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cReserve_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.FindUserCardListResp.java

if (!class_exists('UserCardPoList')) {
class UserCardPoList
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 易迅uid
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 总数
		 *
		 * 版本 >= 0
		 */
		var $dwTotalNum; //uint32_t

		/**
		 * 预付卡列表
		 *
		 * 版本 >= 0
		 */
		var $vecUserCardPoList; //std::vector<b2b2c::unifiedaccount::po::CUserCardPo> 

		/**
		 * reserve  预留字段,无用
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->dwTotalNum = 0; // uint32_t
			 $this->vecUserCardPoList = new stl_vector('UserCardPo'); // std::vector<b2b2c::unifiedaccount::po::CUserCardPo> 
			 $this->strReserve = ""; // std::string
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅uid 类型为uint64_t
			$bs->pushUint32_t($this->dwTotalNum); // 序列化总数 类型为uint32_t
			$bs->pushObject($this->vecUserCardPoList,'stl_vector'); // 序列化预付卡列表 类型为std::vector<b2b2c::unifiedaccount::po::CUserCardPo> 
			$bs->pushString($this->strReserve); // 序列化reserve  预留字段,无用 类型为std::string
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅uid 类型为uint64_t
			$this->dwTotalNum = $bs->popUint32_t(); // 反序列化总数 类型为uint32_t
			$this->vecUserCardPoList = $bs->popObject('stl_vector<UserCardPo>'); // 反序列化预付卡列表 类型为std::vector<b2b2c::unifiedaccount::po::CUserCardPo> 
			$this->strReserve = $bs->popString(); // 反序列化reserve  预留字段,无用 类型为std::string

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.UserCardPoList.java

if (!class_exists('UserCardPo')) {
class UserCardPo
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 易迅uid
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 卡号
		 *
		 * 版本 >= 0
		 */
		var $strCardNumber; //std::string

		/**
		 * 绑定时间
		 *
		 * 版本 >= 0
		 */
		var $ddwBindTime; //uint64_t

		/**
		 * 卡面额, 单位为分
		 *
		 * 版本 >= 0
		 */
		var $ddwCardValue; //uint64_t

		/**
		 * 卡余额, 单位为分
		 *
		 * 版本 >= 0
		 */
		var $ddwCardBalance; //uint64_t

		/**
		 * 卡状态: 0-未定义(查询Q卡失败等) 1-可使用 2-可使用冻结 3-作废 4-初始化 5-可查询 6-可查询冻结
		 *
		 * 版本 >= 0
		 */
		var $dwCardState; //uint32_t

		/**
		 * 卡时间状态: 1-当前可使用(非即将过期) 2-当前可使用且即将过期 3-未到有效期 4 已过期
		 *
		 * 版本 >= 0
		 */
		var $dwCardTimeState; //uint32_t

		/**
		 * 卡有效起始日期
		 *
		 * 版本 >= 0
		 */
		var $ddwValidDateBegin; //uint64_t

		/**
		 * 卡有效截止日期
		 *
		 * 版本 >= 0
		 */
		var $ddwValidDateEnd; //uint64_t

		/**
		 * 最后更新时间
		 *
		 * 版本 >= 0
		 */
		var $ddwLastUpdateTime; //uint64_t

		/**
		 * 保留
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cIcsonUid_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardNumber_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cBindTime_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardValue_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardBalance_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardState_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardTimeState_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cValidDateBegin_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cValidDateEnd_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cLastUpdateTime_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cReserve_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->strCardNumber = ""; // std::string
			 $this->ddwBindTime = 0; // uint64_t
			 $this->ddwCardValue = 0; // uint64_t
			 $this->ddwCardBalance = 0; // uint64_t
			 $this->dwCardState = 0; // uint32_t
			 $this->dwCardTimeState = 0; // uint32_t
			 $this->ddwValidDateBegin = 0; // uint64_t
			 $this->ddwValidDateEnd = 0; // uint64_t
			 $this->ddwLastUpdateTime = 0; // uint64_t
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cIcsonUid_u = 0; // uint8_t
			 $this->cCardNumber_u = 0; // uint8_t
			 $this->cBindTime_u = 0; // uint8_t
			 $this->cCardValue_u = 0; // uint8_t
			 $this->cCardBalance_u = 0; // uint8_t
			 $this->cCardState_u = 0; // uint8_t
			 $this->cCardTimeState_u = 0; // uint8_t
			 $this->cValidDateBegin_u = 0; // uint8_t
			 $this->cValidDateEnd_u = 0; // uint8_t
			 $this->cLastUpdateTime_u = 0; // uint8_t
			 $this->cReserve_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅uid 类型为uint64_t
			$bs->pushString($this->strCardNumber); // 序列化卡号 类型为std::string
			$bs->pushUint64_t($this->ddwBindTime); // 序列化绑定时间 类型为uint64_t
			$bs->pushUint64_t($this->ddwCardValue); // 序列化卡面额, 单位为分 类型为uint64_t
			$bs->pushUint64_t($this->ddwCardBalance); // 序列化卡余额, 单位为分 类型为uint64_t
			$bs->pushUint32_t($this->dwCardState); // 序列化卡状态: 0-未定义(查询Q卡失败等) 1-可使用 2-可使用冻结 3-作废 4-初始化 5-可查询 6-可查询冻结 类型为uint32_t
			$bs->pushUint32_t($this->dwCardTimeState); // 序列化卡时间状态: 1-当前可使用(非即将过期) 2-当前可使用且即将过期 3-未到有效期 4 已过期 类型为uint32_t
			$bs->pushUint64_t($this->ddwValidDateBegin); // 序列化卡有效起始日期 类型为uint64_t
			$bs->pushUint64_t($this->ddwValidDateEnd); // 序列化卡有效截止日期 类型为uint64_t
			$bs->pushUint64_t($this->ddwLastUpdateTime); // 序列化最后更新时间 类型为uint64_t
			$bs->pushString($this->strReserve); // 序列化保留 类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cIcsonUid_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardNumber_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cBindTime_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardValue_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardBalance_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardState_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardTimeState_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cValidDateBegin_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cValidDateEnd_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cLastUpdateTime_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cReserve_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅uid 类型为uint64_t
			$this->strCardNumber = $bs->popString(); // 反序列化卡号 类型为std::string
			$this->ddwBindTime = $bs->popUint64_t(); // 反序列化绑定时间 类型为uint64_t
			$this->ddwCardValue = $bs->popUint64_t(); // 反序列化卡面额, 单位为分 类型为uint64_t
			$this->ddwCardBalance = $bs->popUint64_t(); // 反序列化卡余额, 单位为分 类型为uint64_t
			$this->dwCardState = $bs->popUint32_t(); // 反序列化卡状态: 0-未定义(查询Q卡失败等) 1-可使用 2-可使用冻结 3-作废 4-初始化 5-可查询 6-可查询冻结 类型为uint32_t
			$this->dwCardTimeState = $bs->popUint32_t(); // 反序列化卡时间状态: 1-当前可使用(非即将过期) 2-当前可使用且即将过期 3-未到有效期 4 已过期 类型为uint32_t
			$this->ddwValidDateBegin = $bs->popUint64_t(); // 反序列化卡有效起始日期 类型为uint64_t
			$this->ddwValidDateEnd = $bs->popUint64_t(); // 反序列化卡有效截止日期 类型为uint64_t
			$this->ddwLastUpdateTime = $bs->popUint64_t(); // 反序列化最后更新时间 类型为uint64_t
			$this->strReserve = $bs->popString(); // 反序列化保留 类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cIcsonUid_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardNumber_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cBindTime_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardValue_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardBalance_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardState_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardTimeState_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cValidDateBegin_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cValidDateEnd_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cLastUpdateTime_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cReserve_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.FindUserCardListReq.java

if (!class_exists('UserCardFilterPo')) {
class UserCardFilterPo
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 易迅uid, 必填
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 卡查询状态, 0:所有   1:当前可用  2:未到有效期 3:即将过期 4:已过期  5:当前不可用(被限制的卡，如冻结作废等) 6:已用完的卡(余额为0)
		 *
		 * 版本 >= 0
		 */
		var $dwState; //uint32_t

		/**
		 * 页码,分页处理, 从0开始
		 *
		 * 版本 >= 0
		 */
		var $dwPageId; //uint32_t

		/**
		 * 每页显示记录条数,分页处理, 最大查询条数定义为100
		 *
		 * 版本 >= 0
		 */
		var $dwPageSize; //uint32_t

		/**
		 * 排序条件默认按预付卡接收时间倒序排序(即:0x01|0x02), 升序:0x00(默认) 倒序:0x01, 排序条件:0x02-按券卡绑定时间排序, 0x04-按卡截止时间排序
		 *
		 * 版本 >= 0
		 */
		var $dwSortOrder; //uint32_t

		/**
		 * reserve  预留字段,无用
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cIcsonUid_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cState_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cPageId_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cPageSize_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cSortOrder_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cReserve_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->dwState = 0; // uint32_t
			 $this->dwPageId = 0; // uint32_t
			 $this->dwPageSize = 0; // uint32_t
			 $this->dwSortOrder = 0; // uint32_t
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cIcsonUid_u = 0; // uint8_t
			 $this->cState_u = 0; // uint8_t
			 $this->cPageId_u = 0; // uint8_t
			 $this->cPageSize_u = 0; // uint8_t
			 $this->cSortOrder_u = 0; // uint8_t
			 $this->cReserve_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅uid, 必填 类型为uint64_t
			$bs->pushUint32_t($this->dwState); // 序列化卡查询状态, 0:所有   1:当前可用  2:未到有效期 3:即将过期 4:已过期  5:当前不可用(被限制的卡，如冻结作废等) 6:已用完的卡(余额为0) 类型为uint32_t
			$bs->pushUint32_t($this->dwPageId); // 序列化页码,分页处理, 从0开始 类型为uint32_t
			$bs->pushUint32_t($this->dwPageSize); // 序列化每页显示记录条数,分页处理, 最大查询条数定义为100 类型为uint32_t
			$bs->pushUint32_t($this->dwSortOrder); // 序列化排序条件默认按预付卡接收时间倒序排序(即:0x01|0x02), 升序:0x00(默认) 倒序:0x01, 排序条件:0x02-按券卡绑定时间排序, 0x04-按卡截止时间排序 类型为uint32_t
			$bs->pushString($this->strReserve); // 序列化reserve  预留字段,无用 类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cIcsonUid_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cState_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cPageId_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cPageSize_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cSortOrder_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cReserve_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅uid, 必填 类型为uint64_t
			$this->dwState = $bs->popUint32_t(); // 反序列化卡查询状态, 0:所有   1:当前可用  2:未到有效期 3:即将过期 4:已过期  5:当前不可用(被限制的卡，如冻结作废等) 6:已用完的卡(余额为0) 类型为uint32_t
			$this->dwPageId = $bs->popUint32_t(); // 反序列化页码,分页处理, 从0开始 类型为uint32_t
			$this->dwPageSize = $bs->popUint32_t(); // 反序列化每页显示记录条数,分页处理, 最大查询条数定义为100 类型为uint32_t
			$this->dwSortOrder = $bs->popUint32_t(); // 反序列化排序条件默认按预付卡接收时间倒序排序(即:0x01|0x02), 升序:0x00(默认) 倒序:0x01, 排序条件:0x02-按券卡绑定时间排序, 0x04-按卡截止时间排序 类型为uint32_t
			$this->strReserve = $bs->popString(); // 反序列化reserve  预留字段,无用 类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cIcsonUid_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cState_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cPageId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cPageSize_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cSortOrder_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cReserve_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.ConsumeUserCardReq.java

if (!class_exists('UserCardConsumeParamPo')) {
class UserCardConsumeParamPo
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 易迅Uid, 必填
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 消费总额, 单位分
		 *
		 * 版本 >= 0
		 */
		var $ddwConsumeTotalValue; //uint64_t

		/**
		 * 支付流水号(业务保证唯一, 防重入), 必填
		 *
		 * 版本 >= 0
		 */
		var $strPaySequenceNo; //std::string

		/**
		 * 卡消费信息, 必填
		 *
		 * 版本 >= 0
		 */
		var $vecUserCardConsumePoList; //std::vector<b2b2c::unifiedaccount::po::CUserCardConsumePo> 

		/**
		 * 备注
		 *
		 * 版本 >= 0
		 */
		var $strRemarks; //std::string

		/**
		 * 保留字段
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cIcsonUid_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cConsumeTotalValue_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cPaySequenceNo_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cUserCardConsumePoList_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cReserve_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->ddwConsumeTotalValue = 0; // uint64_t
			 $this->strPaySequenceNo = ""; // std::string
			 $this->vecUserCardConsumePoList = new stl_vector('UserCardConsumePo'); // std::vector<b2b2c::unifiedaccount::po::CUserCardConsumePo> 
			 $this->strRemarks = ""; // std::string
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cIcsonUid_u = 0; // uint8_t
			 $this->cConsumeTotalValue_u = 0; // uint8_t
			 $this->cPaySequenceNo_u = 0; // uint8_t
			 $this->cUserCardConsumePoList_u = 0; // uint8_t
			 $this->cReserve_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅Uid, 必填 类型为uint64_t
			$bs->pushUint64_t($this->ddwConsumeTotalValue); // 序列化消费总额, 单位分 类型为uint64_t
			$bs->pushString($this->strPaySequenceNo); // 序列化支付流水号(业务保证唯一, 防重入), 必填 类型为std::string
			$bs->pushObject($this->vecUserCardConsumePoList,'stl_vector'); // 序列化卡消费信息, 必填 类型为std::vector<b2b2c::unifiedaccount::po::CUserCardConsumePo> 
			$bs->pushString($this->strRemarks); // 序列化备注 类型为std::string
			$bs->pushString($this->strReserve); // 序列化保留字段 类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cIcsonUid_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cConsumeTotalValue_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cPaySequenceNo_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cUserCardConsumePoList_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cReserve_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅Uid, 必填 类型为uint64_t
			$this->ddwConsumeTotalValue = $bs->popUint64_t(); // 反序列化消费总额, 单位分 类型为uint64_t
			$this->strPaySequenceNo = $bs->popString(); // 反序列化支付流水号(业务保证唯一, 防重入), 必填 类型为std::string
			$this->vecUserCardConsumePoList = $bs->popObject('stl_vector<UserCardConsumePo>'); // 反序列化卡消费信息, 必填 类型为std::vector<b2b2c::unifiedaccount::po::CUserCardConsumePo> 
			$this->strRemarks = $bs->popString(); // 反序列化备注 类型为std::string
			$this->strReserve = $bs->popString(); // 反序列化保留字段 类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cIcsonUid_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cConsumeTotalValue_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cPaySequenceNo_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cUserCardConsumePoList_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cReserve_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.UserCardConsumeParamPo.java

if (!class_exists('UserCardConsumePo')) {
class UserCardConsumePo
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 卡号, 必填
		 *
		 * 版本 >= 0
		 */
		var $strCardNumber; //std::string

		/**
		 * 卡号密码， 可选， 如果是已绑定卡，密码可选， 非已绑定卡，必须带密码
		 *
		 * 版本 >= 0
		 */
		var $strCardPasswd; //std::string

		/**
		 * 消费卡额度, 单位为分, 暂不填
		 *
		 * 版本 >= 0
		 */
		var $ddwConsumeValue; //uint64_t

		/**
		 * 保留
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardNumber_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardPasswd_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cConsumeValue_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cRemarks_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->strCardNumber = ""; // std::string
			 $this->strCardPasswd = ""; // std::string
			 $this->ddwConsumeValue = 0; // uint64_t
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cCardNumber_u = 0; // uint8_t
			 $this->cCardPasswd_u = 0; // uint8_t
			 $this->cConsumeValue_u = 0; // uint8_t
			 $this->cRemarks_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushString($this->strCardNumber); // 序列化卡号, 必填 类型为std::string
			$bs->pushString($this->strCardPasswd); // 序列化卡号密码， 可选， 如果是已绑定卡，密码可选， 非已绑定卡，必须带密码 类型为std::string
			$bs->pushUint64_t($this->ddwConsumeValue); // 序列化消费卡额度, 单位为分, 暂不填 类型为uint64_t
			$bs->pushString($this->strReserve); // 序列化保留 类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardNumber_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardPasswd_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cConsumeValue_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cRemarks_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->strCardNumber = $bs->popString(); // 反序列化卡号, 必填 类型为std::string
			$this->strCardPasswd = $bs->popString(); // 反序列化卡号密码， 可选， 如果是已绑定卡，密码可选， 非已绑定卡，必须带密码 类型为std::string
			$this->ddwConsumeValue = $bs->popUint64_t(); // 反序列化消费卡额度, 单位为分, 暂不填 类型为uint64_t
			$this->strReserve = $bs->popString(); // 反序列化保留 类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardNumber_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardPasswd_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cConsumeValue_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cRemarks_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.CancelUserCardReq.java

if (!class_exists('UserCardFallbackParamPo')) {
class UserCardFallbackParamPo
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 易迅Uid, 必填
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 交易id, 必填
		 *
		 * 版本 >= 0
		 */
		var $ddwTradeId; //uint64_t

		/**
		 * 退款单号, 有退款单的，需填该参数
		 *
		 * 版本 >= 0
		 */
		var $strRefundId; //std::string

		/**
		 * 卡回退额度, 单位为分, 必填
		 *
		 * 版本 >= 0
		 */
		var $ddwFallbackValue; //uint64_t

		/**
		 * 备注
		 *
		 * 版本 >= 0
		 */
		var $strRemarks; //std::string

		/**
		 * 保留字段
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cIcsonUid_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cTradeId_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cRefundId_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cFallbackValue_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cRemarks_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cReserve_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->ddwTradeId = 0; // uint64_t
			 $this->strRefundId = ""; // std::string
			 $this->ddwFallbackValue = 0; // uint64_t
			 $this->strRemarks = ""; // std::string
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cIcsonUid_u = 0; // uint8_t
			 $this->cTradeId_u = 0; // uint8_t
			 $this->cRefundId_u = 0; // uint8_t
			 $this->cFallbackValue_u = 0; // uint8_t
			 $this->cRemarks_u = 0; // uint8_t
			 $this->cReserve_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅Uid, 必填 类型为uint64_t
			$bs->pushUint64_t($this->ddwTradeId); // 序列化交易id, 必填 类型为uint64_t
			$bs->pushString($this->strRefundId); // 序列化退款单号, 有退款单的，需填该参数 类型为std::string
			$bs->pushUint64_t($this->ddwFallbackValue); // 序列化卡回退额度, 单位为分, 必填 类型为uint64_t
			$bs->pushString($this->strRemarks); // 序列化备注 类型为std::string
			$bs->pushString($this->strReserve); // 序列化保留字段 类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cIcsonUid_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cTradeId_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cRefundId_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cFallbackValue_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cRemarks_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cReserve_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅Uid, 必填 类型为uint64_t
			$this->ddwTradeId = $bs->popUint64_t(); // 反序列化交易id, 必填 类型为uint64_t
			$this->strRefundId = $bs->popString(); // 反序列化退款单号, 有退款单的，需填该参数 类型为std::string
			$this->ddwFallbackValue = $bs->popUint64_t(); // 反序列化卡回退额度, 单位为分, 必填 类型为uint64_t
			$this->strRemarks = $bs->popString(); // 反序列化备注 类型为std::string
			$this->strReserve = $bs->popString(); // 反序列化保留字段 类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cIcsonUid_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cTradeId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cRefundId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cFallbackValue_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cRemarks_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cReserve_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.BindUserCardUnLoginReq.java

if (!class_exists('PrepaidCardAccessVerifyPo')) {
class PrepaidCardAccessVerifyPo
{
		/**
		 * 版本号 
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 账户的接入业务ID， 向后台开发人员申请
		 *
		 * 版本 >= 0
		 */
		var $dwAccessBussinessID; //uint32_t

		/**
		 * 操作者名,业务方控制，可用于后台查询入账的操作人员  
		 *
		 * 版本 >= 0
		 */
		var $strOperatorName; //std::string

		/**
		 * 操作校验码，接口安全考虑 ， 向后台开发人员申请
		 *
		 * 版本 >= 0
		 */
		var $strOperateVerifyCode; //std::string

		/**
		 * reserve  预留字段，无用  
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cAccessBussinessID_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cOperatorName_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cOperateVerifyCode_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cReserve_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->dwAccessBussinessID = 0; // uint32_t
			 $this->strOperatorName = ""; // std::string
			 $this->strOperateVerifyCode = ""; // std::string
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cAccessBussinessID_u = 0; // uint8_t
			 $this->cOperatorName_u = 0; // uint8_t
			 $this->cOperateVerifyCode_u = 0; // uint8_t
			 $this->cReserve_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号  类型为uint32_t
			$bs->pushUint32_t($this->dwAccessBussinessID); // 序列化账户的接入业务ID， 向后台开发人员申请 类型为uint32_t
			$bs->pushString($this->strOperatorName); // 序列化操作者名,业务方控制，可用于后台查询入账的操作人员   类型为std::string
			$bs->pushString($this->strOperateVerifyCode); // 序列化操作校验码，接口安全考虑 ， 向后台开发人员申请 类型为std::string
			$bs->pushString($this->strReserve); // 序列化reserve  预留字段，无用   类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cAccessBussinessID_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cOperatorName_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cOperateVerifyCode_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cReserve_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号  类型为uint32_t
			$this->dwAccessBussinessID = $bs->popUint32_t(); // 反序列化账户的接入业务ID， 向后台开发人员申请 类型为uint32_t
			$this->strOperatorName = $bs->popString(); // 反序列化操作者名,业务方控制，可用于后台查询入账的操作人员   类型为std::string
			$this->strOperateVerifyCode = $bs->popString(); // 反序列化操作校验码，接口安全考虑 ， 向后台开发人员申请 类型为std::string
			$this->strReserve = $bs->popString(); // 反序列化reserve  预留字段，无用   类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cAccessBussinessID_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cOperatorName_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cOperateVerifyCode_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cReserve_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}


//source idl: com.b2b2c.unifiedaccount.idl.BindUserCardReq.java

if (!class_exists('UserCardBindParamPo')) {
class UserCardBindParamPo
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 易迅Uid, 必填
		 *
		 * 版本 >= 0
		 */
		var $ddwIcsonUid; //uint64_t

		/**
		 * 预付卡卡号, 必填
		 *
		 * 版本 >= 0
		 */
		var $strCardNumber; //std::string

		/**
		 * 预付卡密码, 必填
		 *
		 * 版本 >= 0
		 */
		var $strPasswd; //std::string

		/**
		 * 保留字段
		 *
		 * 版本 >= 0
		 */
		var $strReserve; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cIcsonUid_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cCardNumber_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cPasswd_u; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cReserve_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->ddwIcsonUid = 0; // uint64_t
			 $this->strCardNumber = ""; // std::string
			 $this->strPasswd = ""; // std::string
			 $this->strReserve = ""; // std::string
			 $this->cVersion_u = 0; // uint8_t
			 $this->cIcsonUid_u = 0; // uint8_t
			 $this->cCardNumber_u = 0; // uint8_t
			 $this->cPasswd_u = 0; // uint8_t
			 $this->cReserve_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint64_t($this->ddwIcsonUid); // 序列化易迅Uid, 必填 类型为uint64_t
			$bs->pushString($this->strCardNumber); // 序列化预付卡卡号, 必填 类型为std::string
			$bs->pushString($this->strPasswd); // 序列化预付卡密码, 必填 类型为std::string
			$bs->pushString($this->strReserve); // 序列化保留字段 类型为std::string
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cIcsonUid_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cCardNumber_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cPasswd_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cReserve_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->ddwIcsonUid = $bs->popUint64_t(); // 反序列化易迅Uid, 必填 类型为uint64_t
			$this->strCardNumber = $bs->popString(); // 反序列化预付卡卡号, 必填 类型为std::string
			$this->strPasswd = $bs->popString(); // 反序列化预付卡密码, 必填 类型为std::string
			$this->strReserve = $bs->popString(); // 反序列化保留字段 类型为std::string
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cIcsonUid_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cCardNumber_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cPasswd_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cReserve_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}
}

?>