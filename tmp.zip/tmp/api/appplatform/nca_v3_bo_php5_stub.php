<?php
// source idl: com.b2b2c.nca.idl.Nca_v3_bo.java
namespace c2cent;
require_once "nca_v3_bo_php5_xxoo.php";
