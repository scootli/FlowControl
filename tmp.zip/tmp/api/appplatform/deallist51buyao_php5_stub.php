<?php
// source idl: com.ecc.deal.idl.DealList51BuyAo.java
namespace ecc;
require_once "deallist51buyao_php5_xxoo.php";

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SysQueryBdealListReq',false)){
class SysQueryBdealListReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $totalNumFlag;	//<uint32_t> 总数列表控制位(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealListQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->totalNumFlag = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealListQueryBo();	//<ecc::deal::bo::CDealListQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SysQueryBdealListReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SysQueryBdealList\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushUint32_t($this->totalNumFlag);	//<uint32_t> 总数列表控制位
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealListQueryBo');	//<ecc::deal::bo::CDealListQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x632b1806;
	}
}
}

if(!class_exists('ecc\deal\ao\SysQueryBdealListResp',false)){
class SysQueryBdealListResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $totalNum;	//<uint32_t> 总数(版本>=0)
	private $bdealListInfo;	//<ecc::deal::po::CBdealPoList> 返回的订单信息(版本>=0)
	private $errMsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['totalNum'] = $bs->popUint32_t();	//<uint32_t> 总数
		$this->_arr_value['bdealListInfo'] = $bs->popObject('\ecc\deal\po\BdealPoList');	//<ecc::deal::po::CBdealPoList> 返回的订单信息
		$this->_arr_value['errMsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x632b8806;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SysQueryDealListReq',false)){
class SysQueryDealListReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $totalNumFlag;	//<uint32_t> 总数列表控制位(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealListQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->totalNumFlag = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealListQueryBo();	//<ecc::deal::bo::CDealListQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SysQueryDealListReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SysQueryDealList\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushUint32_t($this->totalNumFlag);	//<uint32_t> 总数列表控制位
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealListQueryBo');	//<ecc::deal::bo::CDealListQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x632b1802;
	}
}
}

if(!class_exists('ecc\deal\ao\SysQueryDealListResp',false)){
class SysQueryDealListResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $totalNum;	//<uint32_t> 总数(版本>=0)
	private $dealListInfo;	//<ecc::deal::po::CDealPoList> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['totalNum'] = $bs->popUint32_t();	//<uint32_t> 总数
		$this->_arr_value['dealListInfo'] = $bs->popObject('\ecc\deal\po\DealPoList');	//<ecc::deal::po::CDealPoList> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x632b8802;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SysQueryRefundListReq',false)){
class SysQueryRefundListReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $totalNumFlag;	//<uint32_t> 总数列表控制位(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CRefundListQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->totalNumFlag = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\RefundListQueryBo();	//<ecc::deal::bo::CRefundListQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SysQueryRefundListReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SysQueryRefundList\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushUint32_t($this->totalNumFlag);	//<uint32_t> 总数列表控制位
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\RefundListQueryBo');	//<ecc::deal::bo::CRefundListQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x632b1804;
	}
}
}

if(!class_exists('ecc\deal\ao\SysQueryRefundListResp',false)){
class SysQueryRefundListResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $totalNum;	//<uint32_t> 总数(版本>=0)
	private $refundList;	//<ecc::deal::po::CDealRefundPoList> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['totalNum'] = $bs->popUint32_t();	//<uint32_t> 总数
		$this->_arr_value['refundList'] = $bs->popObject('\ecc\deal\po\DealRefundPoList');	//<ecc::deal::po::CDealRefundPoList> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x632b8804;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SysQueryTradeListReq',false)){
class SysQueryTradeListReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $totalNumFlag;	//<uint32_t> 总数列表控制位(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealListQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->totalNumFlag = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealListQueryBo();	//<ecc::deal::bo::CDealListQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SysQueryTradeListReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SysQueryTradeList\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushUint32_t($this->totalNumFlag);	//<uint32_t> 总数列表控制位
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealListQueryBo');	//<ecc::deal::bo::CDealListQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x632b1808;
	}
}
}

if(!class_exists('ecc\deal\ao\SysQueryTradeListResp',false)){
class SysQueryTradeListResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $totalNum;	//<uint32_t> 总数(版本>=0)
	private $tradeListInfo;	//<ecc::deal::po::CTradePoList> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['totalNum'] = $bs->popUint32_t();	//<uint32_t> 总数
		$this->_arr_value['tradeListInfo'] = $bs->popObject('\ecc\deal\po\TradePoList');	//<ecc::deal::po::CTradePoList> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x632b8808;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\UserQueryBdealListReq',false)){
class UserQueryBdealListReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $totalNumFlag;	//<uint32_t> 总数列表控制位(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealListQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->totalNumFlag = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealListQueryBo();	//<ecc::deal::bo::CDealListQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("UserQueryBdealListReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("UserQueryBdealList\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushUint32_t($this->totalNumFlag);	//<uint32_t> 总数列表控制位
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealListQueryBo');	//<ecc::deal::bo::CDealListQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x632b1805;
	}
}
}

if(!class_exists('ecc\deal\ao\UserQueryBdealListResp',false)){
class UserQueryBdealListResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $totalNum;	//<uint32_t> 总数(版本>=0)
	private $bdealListInfo;	//<ecc::deal::po::CBdealPoList> 返回的订单信息(版本>=0)
	private $errMsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['totalNum'] = $bs->popUint32_t();	//<uint32_t> 总数
		$this->_arr_value['bdealListInfo'] = $bs->popObject('\ecc\deal\po\BdealPoList');	//<ecc::deal::po::CBdealPoList> 返回的订单信息
		$this->_arr_value['errMsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x632b8805;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\UserQueryDealListReq',false)){
class UserQueryDealListReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $totalNumFlag;	//<uint32_t> 总数列表控制位(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealListQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->totalNumFlag = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealListQueryBo();	//<ecc::deal::bo::CDealListQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("UserQueryDealListReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("UserQueryDealList\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushUint32_t($this->totalNumFlag);	//<uint32_t> 总数列表控制位
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealListQueryBo');	//<ecc::deal::bo::CDealListQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x632b1801;
	}
}
}

if(!class_exists('ecc\deal\ao\UserQueryDealListResp',false)){
class UserQueryDealListResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $totalNum;	//<uint32_t> 总数(版本>=0)
	private $dealListInfo;	//<ecc::deal::po::CDealPoList> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['totalNum'] = $bs->popUint32_t();	//<uint32_t> 总数
		$this->_arr_value['dealListInfo'] = $bs->popObject('\ecc\deal\po\DealPoList');	//<ecc::deal::po::CDealPoList> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x632b8801;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\UserQueryRefundListReq',false)){
class UserQueryRefundListReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $totalNumFlag;	//<uint32_t> 总数列表控制位(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CRefundListQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->totalNumFlag = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\RefundListQueryBo();	//<ecc::deal::bo::CRefundListQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("UserQueryRefundListReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("UserQueryRefundList\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushUint32_t($this->totalNumFlag);	//<uint32_t> 总数列表控制位
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\RefundListQueryBo');	//<ecc::deal::bo::CRefundListQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x632b1803;
	}
}
}

if(!class_exists('ecc\deal\ao\UserQueryRefundListResp',false)){
class UserQueryRefundListResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $totalNum;	//<uint32_t> 总数(版本>=0)
	private $refundList;	//<ecc::deal::po::CDealRefundPoList> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['totalNum'] = $bs->popUint32_t();	//<uint32_t> 总数
		$this->_arr_value['refundList'] = $bs->popObject('\ecc\deal\po\DealRefundPoList');	//<ecc::deal::po::CDealRefundPoList> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x632b8803;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\UserQueryTradeListReq',false)){
class UserQueryTradeListReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $totalNumFlag;	//<uint32_t> 总数列表控制位(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealListQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->totalNumFlag = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealListQueryBo();	//<ecc::deal::bo::CDealListQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("UserQueryTradeListReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("UserQueryTradeList\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushUint32_t($this->totalNumFlag);	//<uint32_t> 总数列表控制位
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealListQueryBo');	//<ecc::deal::bo::CDealListQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x632b1807;
	}
}
}

if(!class_exists('ecc\deal\ao\UserQueryTradeListResp',false)){
class UserQueryTradeListResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $totalNum;	//<uint32_t> 总数(版本>=0)
	private $tradeListInfo;	//<ecc::deal::po::CTradePoList> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['totalNum'] = $bs->popUint32_t();	//<uint32_t> 总数
		$this->_arr_value['tradeListInfo'] = $bs->popObject('\ecc\deal\po\TradePoList');	//<ecc::deal::po::CTradePoList> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x632b8807;
	}
}
}