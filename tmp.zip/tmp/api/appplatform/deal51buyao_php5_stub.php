<?php
// source idl: com.ecc.deal.idl.Deal51BuyAo.java
namespace ecc;
require_once "deal51buyao_php5_xxoo.php";

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\AuditDealReq',false)){
class AuditDealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $auditParams;	//<ecc::deal::bo::CEventParamsAuditDealBo> 审核订单参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->auditParams = new \ecc\deal\bo\EventParamsAuditDealBo();	//<ecc::deal::bo::CEventParamsAuditDealBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("AuditDealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("AuditDeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->auditParams,'\ecc\deal\bo\EventParamsAuditDealBo');	//<ecc::deal::bo::CEventParamsAuditDealBo> 审核订单参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041808;
	}
}
}

if(!class_exists('ecc\deal\ao\AuditDealResp',false)){
class AuditDealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048808;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\BackfillDealInfoReq',false)){
class BackfillDealInfoReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数(版本>=0)
	private $backfillParams;	//<ecc::deal::bo::CBackfillDealBo> 下单的订单信息(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->backfillParams = new \ecc\deal\bo\BackfillDealBo();	//<ecc::deal::bo::CBackfillDealBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("BackfillDealInfoReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("BackfillDealInfo\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数
		$bs->pushObject($this->backfillParams,'\ecc\deal\bo\BackfillDealBo');	//<ecc::deal::bo::CBackfillDealBo> 下单的订单信息
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041802;
	}
}
}

if(!class_exists('ecc\deal\ao\BackfillDealInfoResp',false)){
class BackfillDealInfoResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048802;
	}
}
}
namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\CSCreateBuyDealReq',false)){
class CSCreateBuyDealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数(版本>=0)
	private $orderList;	//<ecc::deal::po::COrderPoList> 下单的订单信息(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->orderList = new \ecc\deal\po\OrderPoList();	//<ecc::deal::po::COrderPoList>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("CSCreateBuyDealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("CSCreateBuyDeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数
		$bs->pushObject($this->orderList,'\ecc\deal\po\OrderPoList');	//<ecc::deal::po::COrderPoList> 下单的订单信息
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304181c;
	}
}
}

if(!class_exists('ecc\deal\ao\CSCreateBuyDealResp',false)){
class CSCreateBuyDealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的交易单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的交易单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304881c;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\CSCreateBuyDealV2Req',false)){
class CSCreateBuyDealV2Req{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数(版本>=0)
	private $orderData;	//<ecc::deal::po::CBuyPo> 下单信息(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->orderData = new \ecc\deal\po\BuyPo();	//<ecc::deal::po::CBuyPo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("CSCreateBuyDealV2Req\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("CSCreateBuyDealV2\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数
		$bs->pushObject($this->orderData,'\ecc\deal\po\BuyPo');	//<ecc::deal::po::CBuyPo> 下单信息
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041824;
	}
}
}

if(!class_exists('ecc\deal\ao\CSCreateBuyDealV2Resp',false)){
class CSCreateBuyDealV2Resp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的交易单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的交易单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048824;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\CancelBuyDealReq',false)){
class CancelBuyDealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 事件参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("CancelBuyDealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("CancelBuyDeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 事件参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041805;
	}
}
}

if(!class_exists('ecc\deal\ao\CancelBuyDealResp',false)){
class CancelBuyDealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的交易单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的交易单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048805;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\CancelSupersessionReq',false)){
class CancelSupersessionReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("CancelSupersessionReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("CancelSupersession\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304181e;
	}
}
}

if(!class_exists('ecc\deal\ao\CancelSupersessionResp',false)){
class CancelSupersessionResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304881e;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\CloseDealReq',false)){
class CloseDealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $closeParams;	//<ecc::deal::bo::CEventParamsCloseDealBo> 关闭订单参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->closeParams = new \ecc\deal\bo\EventParamsCloseDealBo();	//<ecc::deal::bo::CEventParamsCloseDealBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("CloseDealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("CloseDeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->closeParams,'\ecc\deal\bo\EventParamsCloseDealBo');	//<ecc::deal::bo::CEventParamsCloseDealBo> 关闭订单参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041807;
	}
}
}

if(!class_exists('ecc\deal\ao\CloseDealResp',false)){
class CloseDealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048807;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\ConfirmRecvReq',false)){
class ConfirmRecvReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $signParams;	//<ecc::deal::bo::CEventParamsCorpSignBo> 签收事件参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->signParams = new \ecc\deal\bo\EventParamsCorpSignBo();	//<ecc::deal::bo::CEventParamsCorpSignBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ConfirmRecvReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("ConfirmRecv\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->signParams,'\ecc\deal\bo\EventParamsCorpSignBo');	//<ecc::deal::bo::CEventParamsCorpSignBo> 签收事件参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304180a;
	}
}
}

if(!class_exists('ecc\deal\ao\ConfirmRecvResp',false)){
class ConfirmRecvResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304880a;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\CreateBuyDealReq',false)){
class CreateBuyDealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数(版本>=0)
	private $orderList;	//<ecc::deal::po::COrderPoList> 下单的订单信息(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->orderList = new \ecc\deal\po\OrderPoList();	//<ecc::deal::po::COrderPoList>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("CreateBuyDealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("CreateBuyDeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数
		$bs->pushObject($this->orderList,'\ecc\deal\po\OrderPoList');	//<ecc::deal::po::COrderPoList> 下单的订单信息
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041801;
	}
}
}

if(!class_exists('ecc\deal\ao\CreateBuyDealResp',false)){
class CreateBuyDealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的交易单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的交易单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048801;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\CreateBuyDealV2Req',false)){
class CreateBuyDealV2Req{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数(版本>=0)
	private $orderData;	//<ecc::deal::po::CBuyPo> 下单信息(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->orderData = new \ecc\deal\po\BuyPo();	//<ecc::deal::po::CBuyPo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("CreateBuyDealV2Req\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("CreateBuyDealV2\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数
		$bs->pushObject($this->orderData,'\ecc\deal\po\BuyPo');	//<ecc::deal::po::CBuyPo> 下单信息
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041823;
	}
}
}

if(!class_exists('ecc\deal\ao\CreateBuyDealV2Resp',false)){
class CreateBuyDealV2Resp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的交易单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的交易单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048823;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\CreateRefundReq',false)){
class CreateRefundReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $refundParams;	//<ecc::deal::bo::CEventParamsCorpCreateRefundBo> 退款参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->refundParams = new \ecc\deal\bo\EventParamsCorpCreateRefundBo();	//<ecc::deal::bo::CEventParamsCorpCreateRefundBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("CreateRefundReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("CreateRefund\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->refundParams,'\ecc\deal\bo\EventParamsCorpCreateRefundBo');	//<ecc::deal::bo::CEventParamsCorpCreateRefundBo> 退款参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304180d;
	}
}
}

if(!class_exists('ecc\deal\ao\CreateRefundResp',false)){
class CreateRefundResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304880d;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\GetBoughtNumReq',false)){
class GetBoughtNumReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $params;	//<ecc::deal::bo::CBoughtNumQueryBo> 查询参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->params = new \ecc\deal\bo\BoughtNumQueryBo();	//<ecc::deal::bo::CBoughtNumQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("GetBoughtNumReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("GetBoughtNum\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->params,'\ecc\deal\bo\BoughtNumQueryBo');	//<ecc::deal::bo::CBoughtNumQueryBo> 查询参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041821;
	}
}
}

if(!class_exists('ecc\deal\ao\GetBoughtNumResp',false)){
class GetBoughtNumResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $boughtNum;	//<uint32_t> 购买数(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['boughtNum'] = $bs->popUint32_t();	//<uint32_t> 购买数
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048821;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\MarkShipReq',false)){
class MarkShipReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $shipParams;	//<ecc::deal::bo::CEventParamsCorpShipBo> 发货参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->shipParams = new \ecc\deal\bo\EventParamsCorpShipBo();	//<ecc::deal::bo::CEventParamsCorpShipBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("MarkShipReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("MarkShip\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->shipParams,'\ecc\deal\bo\EventParamsCorpShipBo');	//<ecc::deal::bo::CEventParamsCorpShipBo> 发货参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041809;
	}
}
}

if(!class_exists('ecc\deal\ao\MarkShipResp',false)){
class MarkShipResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048809;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\ModifyCouponReq',false)){
class ModifyCouponReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $couponParams;	//<ecc::deal::bo::CEventParamsModifyCouponBo> 修改参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->couponParams = new \ecc\deal\bo\EventParamsModifyCouponBo();	//<ecc::deal::bo::CEventParamsModifyCouponBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ModifyCouponReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("ModifyCoupon\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->couponParams,'\ecc\deal\bo\EventParamsModifyCouponBo');	//<ecc::deal::bo::CEventParamsModifyCouponBo> 修改参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041814;
	}
}
}

if(!class_exists('ecc\deal\ao\ModifyCouponResp',false)){
class ModifyCouponResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048814;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\ModifyDealPriceReq',false)){
class ModifyDealPriceReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $modifyPriceParams;	//<ecc::deal::bo::CEventParamsModifyDealPriceBo> 修改参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->modifyPriceParams = new \ecc\deal\bo\EventParamsModifyDealPriceBo();	//<ecc::deal::bo::CEventParamsModifyDealPriceBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ModifyDealPriceReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("ModifyDealPrice\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->modifyPriceParams,'\ecc\deal\bo\EventParamsModifyDealPriceBo');	//<ecc::deal::bo::CEventParamsModifyDealPriceBo> 修改参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041816;
	}
}
}

if(!class_exists('ecc\deal\ao\ModifyDealPriceResp',false)){
class ModifyDealPriceResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048816;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\ModifyInvoiceReq',false)){
class ModifyInvoiceReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $invoiceParams;	//<ecc::deal::bo::CEventParamsModifyInvoiceBo> 修改参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->invoiceParams = new \ecc\deal\bo\EventParamsModifyInvoiceBo();	//<ecc::deal::bo::CEventParamsModifyInvoiceBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ModifyInvoiceReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("ModifyInvoice\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->invoiceParams,'\ecc\deal\bo\EventParamsModifyInvoiceBo');	//<ecc::deal::bo::CEventParamsModifyInvoiceBo> 修改参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041813;
	}
}
}

if(!class_exists('ecc\deal\ao\ModifyInvoiceResp',false)){
class ModifyInvoiceResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048813;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\ModifyPayTypeReq',false)){
class ModifyPayTypeReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $modifyParams;	//<ecc::deal::bo::CEventParamsModifyPayTypeBo> 修改参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->modifyParams = new \ecc\deal\bo\EventParamsModifyPayTypeBo();	//<ecc::deal::bo::CEventParamsModifyPayTypeBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ModifyPayTypeReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("ModifyPayType\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->modifyParams,'\ecc\deal\bo\EventParamsModifyPayTypeBo');	//<ecc::deal::bo::CEventParamsModifyPayTypeBo> 修改参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041811;
	}
}
}

if(!class_exists('ecc\deal\ao\ModifyPayTypeResp',false)){
class ModifyPayTypeResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048811;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\ModifyReceiveInfoReq',false)){
class ModifyReceiveInfoReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $recvInfoParams;	//<ecc::deal::bo::CEventParamsModifyRecvInfoBo> 修改参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->recvInfoParams = new \ecc\deal\bo\EventParamsModifyRecvInfoBo();	//<ecc::deal::bo::CEventParamsModifyRecvInfoBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ModifyReceiveInfoReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("ModifyReceiveInfo\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->recvInfoParams,'\ecc\deal\bo\EventParamsModifyRecvInfoBo');	//<ecc::deal::bo::CEventParamsModifyRecvInfoBo> 修改参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041812;
	}
}
}

if(!class_exists('ecc\deal\ao\ModifyReceiveInfoResp',false)){
class ModifyReceiveInfoResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048812;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\ModifyScoreReq',false)){
class ModifyScoreReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $scoreParams;	//<ecc::deal::bo::CEventParamsModifyScoreBo> 修改参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->scoreParams = new \ecc\deal\bo\EventParamsModifyScoreBo();	//<ecc::deal::bo::CEventParamsModifyScoreBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ModifyScoreReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("ModifyScore\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->scoreParams,'\ecc\deal\bo\EventParamsModifyScoreBo');	//<ecc::deal::bo::CEventParamsModifyScoreBo> 修改参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041815;
	}
}
}

if(!class_exists('ecc\deal\ao\ModifyScoreResp',false)){
class ModifyScoreResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048815;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\ModifySeparateInvoiceReq',false)){
class ModifySeparateInvoiceReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $modifyParams;	//<ecc::deal::bo::CSyncSeparateInvoiceBo> 修改发票参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->modifyParams = new \ecc\deal\bo\SyncSeparateInvoiceBo();	//<ecc::deal::bo::CSyncSeparateInvoiceBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ModifySeparateInvoiceReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("ModifySeparateInvoice\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->modifyParams,'\ecc\deal\bo\SyncSeparateInvoiceBo');	//<ecc::deal::bo::CSyncSeparateInvoiceBo> 修改发票参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041820;
	}
}
}

if(!class_exists('ecc\deal\ao\ModifySeparateInvoiceResp',false)){
class ModifySeparateInvoiceResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048820;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\ModifyValueAddedTaxInvoiceReq',false)){
class ModifyValueAddedTaxInvoiceReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $modifyParams;	//<ecc::deal::bo::CSyncValueAddedTaxInvoiceBo> 修改发票参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->modifyParams = new \ecc\deal\bo\SyncValueAddedTaxInvoiceBo();	//<ecc::deal::bo::CSyncValueAddedTaxInvoiceBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("ModifyValueAddedTaxInvoiceReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("ModifyValueAddedTaxInvoice\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->modifyParams,'\ecc\deal\bo\SyncValueAddedTaxInvoiceBo');	//<ecc::deal::bo::CSyncValueAddedTaxInvoiceBo> 修改发票参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304181f;
	}
}
}

if(!class_exists('ecc\deal\ao\ModifyValueAddedTaxInvoiceResp',false)){
class ModifyValueAddedTaxInvoiceResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304881f;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\NotifyBuyDealPaymentReq',false)){
class NotifyBuyDealPaymentReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $payParams;	//<ecc::deal::bo::CEventParamsPayBo> 支付通知事件参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->payParams = new \ecc\deal\bo\EventParamsPayBo();	//<ecc::deal::bo::CEventParamsPayBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("NotifyBuyDealPaymentReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("NotifyBuyDealPayment\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->payParams,'\ecc\deal\bo\EventParamsPayBo');	//<ecc::deal::bo::CEventParamsPayBo> 支付通知事件参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041803;
	}
}
}

if(!class_exists('ecc\deal\ao\NotifyBuyDealPaymentResp',false)){
class NotifyBuyDealPaymentResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的交易单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的交易单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048803;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\NotifyDealPaymentReq',false)){
class NotifyDealPaymentReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $payParams;	//<ecc::deal::bo::CEventParamsPayBo> 支付通知事件参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->payParams = new \ecc\deal\bo\EventParamsPayBo();	//<ecc::deal::bo::CEventParamsPayBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("NotifyDealPaymentReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("NotifyDealPayment\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->payParams,'\ecc\deal\bo\EventParamsPayBo');	//<ecc::deal::bo::CEventParamsPayBo> 支付通知事件参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041804;
	}
}
}

if(!class_exists('ecc\deal\ao\NotifyDealPaymentResp',false)){
class NotifyDealPaymentResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048804;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\OperateGoodsReq',false)){
class OperateGoodsReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $operGoodsParams;	//<ecc::deal::bo::CEventParamsOperGoodsBo> 增删商品参数(版本>=0)
	private $modifyPriceParams;	//<ecc::deal::bo::CEventParamsModifyDealPriceBo> 修改价格参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->operGoodsParams = new \ecc\deal\bo\EventParamsOperGoodsBo();	//<ecc::deal::bo::CEventParamsOperGoodsBo>
		$this->modifyPriceParams = new \ecc\deal\bo\EventParamsModifyDealPriceBo();	//<ecc::deal::bo::CEventParamsModifyDealPriceBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("OperateGoodsReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("OperateGoods\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->operGoodsParams,'\ecc\deal\bo\EventParamsOperGoodsBo');	//<ecc::deal::bo::CEventParamsOperGoodsBo> 增删商品参数
		$bs->pushObject($this->modifyPriceParams,'\ecc\deal\bo\EventParamsModifyDealPriceBo');	//<ecc::deal::bo::CEventParamsModifyDealPriceBo> 修改价格参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041817;
	}
}
}

if(!class_exists('ecc\deal\ao\OperateGoodsResp',false)){
class OperateGoodsResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048817;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\QueryIcsonBdealReq',false)){
class QueryIcsonBdealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealQueryBo();	//<ecc::deal::bo::CDealQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("QueryIcsonBdealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("QueryIcsonBdeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealQueryBo');	//<ecc::deal::bo::CDealQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041822;
	}
}
}

if(!class_exists('ecc\deal\ao\QueryIcsonBdealResp',false)){
class QueryIcsonBdealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048822;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\QueryIcsonDealReq',false)){
class QueryIcsonDealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealQueryBo();	//<ecc::deal::bo::CDealQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("QueryIcsonDealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("QueryIcsonDeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealQueryBo');	//<ecc::deal::bo::CDealQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041806;
	}
}
}

if(!class_exists('ecc\deal\ao\QueryIcsonDealResp',false)){
class QueryIcsonDealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048806;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\RefuseDealReq',false)){
class RefuseDealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $signParams;	//<ecc::deal::bo::CEventParamsCorpSignBo> 签收事件参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->signParams = new \ecc\deal\bo\EventParamsCorpSignBo();	//<ecc::deal::bo::CEventParamsCorpSignBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("RefuseDealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("RefuseDeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->signParams,'\ecc\deal\bo\EventParamsCorpSignBo');	//<ecc::deal::bo::CEventParamsCorpSignBo> 签收事件参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304180b;
	}
}
}

if(!class_exists('ecc\deal\ao\RefuseDealResp',false)){
class RefuseDealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304880b;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SyncDealActionReq',false)){
class SyncDealActionReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数(版本>=0)
	private $actionParams;	//<ecc::deal::bo::CSyncDealActionBo> 订单操作信息(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->actionParams = new \ecc\deal\bo\SyncDealActionBo();	//<ecc::deal::bo::CSyncDealActionBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SyncDealActionReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SyncDealAction\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数
		$bs->pushObject($this->actionParams,'\ecc\deal\bo\SyncDealActionBo');	//<ecc::deal::bo::CSyncDealActionBo> 订单操作信息
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041810;
	}
}
}

if(!class_exists('ecc\deal\ao\SyncDealActionResp',false)){
class SyncDealActionResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048810;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SyncEvalStateReq',false)){
class SyncEvalStateReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数(版本>=0)
	private $evalParams;	//<ecc::deal::bo::CModifyEvalStateBo> 设置评论状态参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->evalParams = new \ecc\deal\bo\ModifyEvalStateBo();	//<ecc::deal::bo::CModifyEvalStateBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SyncEvalStateReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SyncEvalState\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础参数
		$bs->pushObject($this->evalParams,'\ecc\deal\bo\ModifyEvalStateBo');	//<ecc::deal::bo::CModifyEvalStateBo> 设置评论状态参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304181d;
	}
}
}

if(!class_exists('ecc\deal\ao\SyncEvalStateResp',false)){
class SyncEvalStateResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的交易单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的交易单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304881d;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SyncNonMonetaryDealInfoReq',false)){
class SyncNonMonetaryDealInfoReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $dealInfoIn;	//<ecc::deal::po::CDealPo> 修改订单的内容，填充需要修改的字段及其UFlag，不修改的字段请勿填写(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->dealInfoIn = new \ecc\deal\po\DealPo();	//<ecc::deal::po::CDealPo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SyncNonMonetaryDealInfoReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SyncNonMonetaryDealInfo\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->dealInfoIn,'\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 修改订单的内容，填充需要修改的字段及其UFlag，不修改的字段请勿填写
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304180f;
	}
}
}

if(!class_exists('ecc\deal\ao\SyncNonMonetaryDealInfoResp',false)){
class SyncNonMonetaryDealInfoResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfoUpdate;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfoUpdate'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304880f;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SyncPickingReq',false)){
class SyncPickingReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $pickParams;	//<ecc::deal::bo::CEventParamsPickBo> 签收事件参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->pickParams = new \ecc\deal\bo\EventParamsPickBo();	//<ecc::deal::bo::CEventParamsPickBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SyncPickingReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SyncPicking\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->pickParams,'\ecc\deal\bo\EventParamsPickBo');	//<ecc::deal::bo::CEventParamsPickBo> 签收事件参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304180c;
	}
}
}

if(!class_exists('ecc\deal\ao\SyncPickingResp',false)){
class SyncPickingResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304880c;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SyncRefundReq',false)){
class SyncRefundReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $baseParams;	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数(版本>=0)
	private $refundParams;	//<ecc::deal::bo::CEventParamsCorpSyncRefundBo> 退款参数(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->baseParams = new \ecc\deal\bo\EventParamsBaseBo();	//<ecc::deal::bo::CEventParamsBaseBo>
		$this->refundParams = new \ecc\deal\bo\EventParamsCorpSyncRefundBo();	//<ecc::deal::bo::CEventParamsCorpSyncRefundBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SyncRefundReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SyncRefund\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushObject($this->baseParams,'\ecc\deal\bo\EventParamsBaseBo');	//<ecc::deal::bo::CEventParamsBaseBo> 基础事件参数
		$bs->pushObject($this->refundParams,'\ecc\deal\bo\EventParamsCorpSyncRefundBo');	//<ecc::deal::bo::CEventParamsCorpSyncRefundBo> 退款参数
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304180e;
	}
}
}

if(!class_exists('ecc\deal\ao\SyncRefundResp',false)){
class SyncRefundResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304880e;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SysQueryBdealReq',false)){
class SysQueryBdealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealQueryBo();	//<ecc::deal::bo::CDealQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SysQueryBdealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SysQueryBdeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealQueryBo');	//<ecc::deal::bo::CDealQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304181b;
	}
}
}

if(!class_exists('ecc\deal\ao\SysQueryBdealResp',false)){
class SysQueryBdealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304881b;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\SysQueryDealReq',false)){
class SysQueryDealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealQueryBo();	//<ecc::deal::bo::CDealQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("SysQueryDealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("SysQueryDeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealQueryBo');	//<ecc::deal::bo::CDealQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041819;
	}
}
}

if(!class_exists('ecc\deal\ao\SysQueryDealResp',false)){
class SysQueryDealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048819;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\UserQueryBdealReq',false)){
class UserQueryBdealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealQueryBo();	//<ecc::deal::bo::CDealQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("UserQueryBdealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("UserQueryBdeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealQueryBo');	//<ecc::deal::bo::CDealQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x6304181a;
	}
}
}

if(!class_exists('ecc\deal\ao\UserQueryBdealResp',false)){
class UserQueryBdealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $bdealInfo;	//<ecc::deal::po::CBdealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['bdealInfo'] = $bs->popObject('\ecc\deal\po\BdealPo');	//<ecc::deal::po::CBdealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x6304881a;
	}
}
}

namespace ecc\deal\ao;
if(!class_exists('ecc\deal\ao\UserQueryDealReq',false)){
class UserQueryDealReq{
	private $_routeKey;
	private $_arr_value=array();	//数组形式的类
	private $source;	//<std::string> 请求来源(版本>=0)
	private $machineKey;	//<std::string> 用户的MachineKey(版本>=0)
	private $verifyToken;	//<std::string> 订单系统分配的校验token(版本>=0)
	private $infoType;	//<uint32_t> 信息类型(版本>=0)
	private $historyFlag;	//<uint8_t> 历史订单标识，0当前订单 1历史订单(版本>=0)
	private $version;	//<uint32_t> 需要返回的数据版本(版本>=0)
	private $queryFilter;	//<ecc::deal::bo::CDealQueryBo> 查询条件(版本>=0)
	private $reserveIn;	//<std::string> 接口预留参数(版本>=0)

	function __construct() {
		$this->source = "";	//<std::string>
		$this->machineKey = "";	//<std::string>
		$this->verifyToken = "";	//<std::string>
		$this->infoType = 0;	//<uint32_t>
		$this->historyFlag = 0;	//<uint8_t>
		$this->version = 0;	//<uint32_t>
		$this->queryFilter = new \ecc\deal\bo\DealQueryBo();	//<ecc::deal::bo::CDealQueryBo>
		$this->reserveIn = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				$this->initClass($name,$val,$this->$name);
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("UserQueryDealReq\\{$name}：不存在此变量，请查询stub。");
		}
	}

	function initClass($name,$val,$obj){
		if(!is_array($val)) exit("UserQueryDeal\\{$name}：请直接赋值为数组，无需new ***。");
		$base=array('bool','byte','uint8_t','int8_t','uint16_t','int16_t','uint32_t','int32_t','uint64_t','int64_t','long','int','string','stl_string');
		if(strpos(get_class($obj), 'stl_')===0){			
			$class=$obj->element_type;
			$arr = array();	
			if(in_array($class, $base)){
				$arr=$val;
			}else if(strpos($class,'stl_')===0){
				$cls=explode("<", $class);
				$cls="\\".trim($cls[0])."2";
				$start=strpos($obj->element_type,'<')+1;
				$end= strrpos($obj->element_type,'>');
				$parm= trim(substr($obj->element_type, $start,$end-$start));
				foreach($val as $k => $v){					
					$arr[$k]=new $cls($parm);
					$this->initClass($name.'\\'.$k,$v,$arr[$k]);
				}		
			}else{
				foreach ($val as $key => $value) {
					$arr[$key]=new $class();
					foreach($value as $k => $v){
						if(is_object($arr[$key]->$k)){
							$this->initClass($name.'\\'.$k,$v,$arr[$key]->$k);
						}else{
							$arr[$key]->$k=$v;
						}
					}	
				}					
			}
			$obj->setValue($arr);				
		}else{
			foreach($val as $k => $v){
				if(is_object($obj->$k)){
					$this->initClass($name.'\\'.$k,$v,$obj->$k);
				}else{
					$obj->$k=$v;
				}	
			}
		}	
	}
	
	function getRouteKey(){
		if($this->_routeKey){
			return $this->{$this->_routeKey};
		}
		
		return null;
	}
	
	function Serialize($bs){
		$bs->pushString($this->source);	//<std::string> 请求来源
		$bs->pushString($this->machineKey);	//<std::string> 用户的MachineKey
		$bs->pushString($this->verifyToken);	//<std::string> 订单系统分配的校验token
		$bs->pushUint32_t($this->infoType);	//<uint32_t> 信息类型
		$bs->pushUint8_t($this->historyFlag);	//<uint8_t> 历史订单标识，0当前订单 1历史订单
		$bs->pushUint32_t($this->version);	//<uint32_t> 需要返回的数据版本
		$bs->pushObject($this->queryFilter,'\ecc\deal\bo\DealQueryBo');	//<ecc::deal::bo::CDealQueryBo> 查询条件
		$bs->pushString($this->reserveIn);	//<std::string> 接口预留参数

		return $bs->isGood();
	}
	
	function getCmdId(){
		return 0x63041818;
	}
}
}

if(!class_exists('ecc\deal\ao\UserQueryDealResp',false)){
class UserQueryDealResp{
	private $result;	
	private $_arr_value=array();	//数组形式的类
	private $dealInfo;	//<ecc::deal::po::CDealPo> 返回的订单信息(版本>=0)
	private $errmsg;	//<std::string> 错误信息(版本>=0)
	private $reserveOut;	//<std::string> 输出预留参数(版本>=0)

	function __get($name){
		if($name=="errmsg" && !array_key_exists('errmsg', $this->_arr_value)){
			if(array_key_exists('errMsg', $this->_arr_value)){
				$name='errMsg';
			}else{
				return "errmsg is not define.";
			}
		}
		return $this->_arr_value[$name];
	}
	
	function Unserialize($bs){
		$this->_arr_value['result'] = $bs->popUint32_t();
		$this->_arr_value['dealInfo'] = $bs->popObject('\ecc\deal\po\DealPo');	//<ecc::deal::po::CDealPo> 返回的订单信息
		$this->_arr_value['errmsg'] = $bs->popString();	//<std::string> 错误信息
		$this->_arr_value['reserveOut'] = $bs->popString();	//<std::string> 输出预留参数

	}

	function getCmdId() {
		return 0x63048818;
	}
}
}