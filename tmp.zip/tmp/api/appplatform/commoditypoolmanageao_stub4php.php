<?php
// source idl: com.icson.commoditypoolmanage.idl.commodityPoolManageAo.java

require_once PHPLIB_ROOT . 'api/appplatform/commoditypoolmanageao_xxo.php';

//请求
class getCommodityByPoolReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $poolId;
	var $termNumber;
	var $termOffset;
	var $getOption;
	var $inReserve;
	var $ExtentIn;


	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->poolId = 0; // uint32_t
		 $this->termNumber = 0; // uint32_t
		 $this->termOffset = 0; // int
		 $this->getOption = 0; // uint8_t
		 $this->inReserve = ""; // std::string
		 $this->ExtentIn = new stl_map('stl_string,stl_string'); // std::map<std::string,std::string> 
	}	


	function Serialize(&$bs) {
		$bs->pushString($this->machineKey); // 序列化用户机器码 类型为std::string
		$bs->pushString($this->source); // 序列化请求来源 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id 类型为uint32_t
		$bs->pushUint32_t($this->poolId); // 序列化商品池id 类型为uint32_t
		$bs->pushUint32_t($this->termNumber); // 序列化期数 类型为uint32_t
		$bs->pushInt32_t($this->termOffset); // 序列化期数偏移量，当期数为0时有意义，0不偏移，1代表下一期，-1代表上一期 类型为int
		$bs->pushUint8_t($this->getOption); // 序列化查询选项，0为无，其他值尚未设定 类型为uint8_t
		$bs->pushString($this->inReserve); // 序列化保留输入字 类型为std::string
		$bs->pushObject($this->ExtentIn, 'stl_map'); // 序列化扩展输入字  类型为std::map<std::string,std::string> 

	
		return $bs->isGood();
	}
	
	function getCmdId() {
		return 0x890c1006;
	}
}
//回复
class getCommodityByPoolResp {
	var $result;
	var $errmsg;
	var $goodsList;
	var $outReserve;
	var $ExtentOut;



	function Unserialize(&$bs) {
		$this->result = $bs->popUint32_t();
		$this->errmsg = $bs->popString(); // 反序列化错误信息 类型为std::string
		$this->goodsList = $bs->popObject('stl_vector<CommodityInfoBO> '); // 反序列化返回的商品列表 类型为std::vector<icson::commoditypoolmanage::bo::CCommodityInfoBO> 
		$this->outReserve = $bs->popString(); // 反序列化保留输出信息 类型为std::string
		$this->ExtentOut = $bs->popObject('stl_map<stl_string,stl_string> '); // 反序列化扩展输出信息 类型为std::map<std::string,std::string> 


	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x890c8006;
	}
}
//请求
class getPoolByIdReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $poolId;
	var $termGetOption;
	var $inReserve;
	var $ExtentIn;


	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->poolId = 0; // uint32_t
		 $this->termGetOption = 0; // uint32_t
		 $this->inReserve = ""; // std::string
		 $this->ExtentIn = new stl_map('stl_string,stl_string'); // std::map<std::string,std::string> 
	}	


	function Serialize(&$bs) {
		$bs->pushString($this->machineKey); // 序列化用户机器码 类型为std::string
		$bs->pushString($this->source); // 序列化请求来源 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id 类型为uint32_t
		$bs->pushUint32_t($this->poolId); // 序列化商品池id 类型为uint32_t
		$bs->pushUint32_t($this->termGetOption); // 序列化获取期数的设定，0代表不获取，1代表获取当前期，2代表获取所有期数，10000+n代表获取第n期，如10001代表获取第一期 类型为uint32_t
		$bs->pushString($this->inReserve); // 序列化保留输入字 类型为std::string
		$bs->pushObject($this->ExtentIn, 'stl_map'); // 序列化扩展输入字  类型为std::map<std::string,std::string> 

	
		return $bs->isGood();
	}
	
	function getCmdId() {
		return 0x890c1001;
	}
}
//回复
class getPoolByIdResp {
	var $result;
	var $poolInfo;
	var $errmsg;
	var $outReserve;
	var $ExtentOut;



	function Unserialize(&$bs) {
		$this->result = $bs->popUint32_t();
		$this->poolInfo = $bs->popObject('CommodityPoolInfoBO'); // 反序列化返回商品池信息 类型为icson::commoditypoolmanage::bo::CCommodityPoolInfoBO
		$this->errmsg = $bs->popString(); // 反序列化错误信息 类型为std::string
		$this->outReserve = $bs->popString(); // 反序列化保留输出信息 类型为std::string
		$this->ExtentOut = $bs->popObject('stl_map<stl_string,stl_string> '); // 反序列化扩展输出信息 类型为std::map<std::string,std::string> 


	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x890c8001;
	}
}
//请求
class queryPoolReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $params;
	var $queryOption;
	var $inReserve;
	var $ExtentIn;


	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->params = new stl_map('stl_string,stl_string'); // std::map<std::string,std::string> 
		 $this->queryOption = 0; // uint8_t
		 $this->inReserve = ""; // std::string
		 $this->ExtentIn = new stl_map('stl_string,stl_string'); // std::map<std::string,std::string> 
	}	


	function Serialize(&$bs) {
		$bs->pushString($this->machineKey); // 序列化用户机器码 类型为std::string
		$bs->pushString($this->source); // 序列化请求来源 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id 类型为uint32_t
		$bs->pushObject($this->params, 'stl_map'); // 序列化查询where参数，针对poolName会使用模糊查询 类型为std::map<std::string,std::string> 
		$bs->pushUint8_t($this->queryOption); // 序列化查询选项，0为无，其他值尚未设定 类型为uint8_t
		$bs->pushString($this->inReserve); // 序列化保留输入字 类型为std::string
		$bs->pushObject($this->ExtentIn, 'stl_map'); // 序列化扩展输入字  类型为std::map<std::string,std::string> 

	
		return $bs->isGood();
	}
	
	function getCmdId() {
		return 0x890c1005;
	}
}
//回复
class queryPoolResp {
	var $result;
	var $errmsg;
	var $poolList;
	var $outReserve;
	var $ExtentOut;



	function Unserialize(&$bs) {
		$this->result = $bs->popUint32_t();
		$this->errmsg = $bs->popString(); // 反序列化错误信息 类型为std::string
		$this->poolList = $bs->popObject('stl_vector<CommodityPoolInfoBO> '); // 反序列化返回的商品池列表 类型为std::vector<icson::commoditypoolmanage::bo::CCommodityPoolInfoBO> 
		$this->outReserve = $bs->popString(); // 反序列化保留输出信息 类型为std::string
		$this->ExtentOut = $bs->popObject('stl_map<stl_string,stl_string> '); // 反序列化扩展输出信息 类型为std::map<std::string,std::string> 


	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x890c8005;
	}
}
//请求
class saveCommodityReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $poolId;
	var $termNumber;
	var $action;
	var $entityType;
	var $saveOption;
	var $commodityList;
	var $oprUser;
	var $inReserve;
	var $ExtentIn;


	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->poolId = 0; // uint32_t
		 $this->termNumber = 0; // uint32_t
		 $this->action = 0; // uint8_t
		 $this->entityType = 0; // uint8_t
		 $this->saveOption = 0; // uint8_t
		 $this->commodityList = new stl_vector('CommodityInfoBO'); // std::vector<icson::commoditypoolmanage::bo::CCommodityInfoBO> 
		 $this->oprUser = ""; // std::string
		 $this->inReserve = ""; // std::string
		 $this->ExtentIn = new stl_map('stl_string,stl_string'); // std::map<std::string,std::string> 
	}	


	function Serialize(&$bs) {
		$bs->pushString($this->machineKey); // 序列化用户机器码 类型为std::string
		$bs->pushString($this->source); // 序列化请求来源 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id 类型为uint32_t
		$bs->pushUint32_t($this->poolId); // 序列化商品池id 类型为uint32_t
		$bs->pushUint32_t($this->termNumber); // 序列化期数，必须大于0 类型为uint32_t
		$bs->pushUint8_t($this->action); // 序列化操作必须显示传递，0-非法 1-insert 2-update 3-remove 类型为uint8_t
		$bs->pushUint8_t($this->entityType); // 序列化实体类型，0代表商品，默认是0,1代表素材 类型为uint8_t
		$bs->pushUint8_t($this->saveOption); // 序列化保存选项，0为仅针对传入的商品做增、删、改操作，1为insert时做覆盖操作,remove时直接清理所有商品，相当于先清理旧商品之后再插入 类型为uint8_t
		$bs->pushObject($this->commodityList, 'stl_vector'); // 序列化商品列表 类型为std::vector<icson::commoditypoolmanage::bo::CCommodityInfoBO> 
		$bs->pushString($this->oprUser); // 序列化操作人英文名 类型为std::string
		$bs->pushString($this->inReserve); // 序列化保留输入字 类型为std::string
		$bs->pushObject($this->ExtentIn, 'stl_map'); // 序列化扩展输入字  类型为std::map<std::string,std::string> 

	
		return $bs->isGood();
	}
	
	function getCmdId() {
		return 0x890c1002;
	}
}
//回复
class saveCommodityResp {
	var $result;
	var $errCommodityList;
	var $errmsg;
	var $outReserve;
	var $ExtentOut;



	function Unserialize(&$bs) {
		$this->result = $bs->popUint32_t();
		$this->errCommodityList = $bs->popObject('stl_vector<CommodityInfoBO> '); // 反序列化返回失败的商品列表 类型为std::vector<icson::commoditypoolmanage::bo::CCommodityInfoBO> 
		$this->errmsg = $bs->popString(); // 反序列化错误信息 类型为std::string
		$this->outReserve = $bs->popString(); // 反序列化保留输出信息 类型为std::string
		$this->ExtentOut = $bs->popObject('stl_map<stl_string,stl_string> '); // 反序列化扩展输出信息 类型为std::map<std::string,std::string> 


	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x890c8002;
	}
}
//请求
class savePoolReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $poolInfo;
	var $action;
	var $oprUser;
	var $inReserve;
	var $ExtentIn;


	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->poolInfo = new CommodityPoolInfoBO(); // icson::commoditypoolmanage::bo::CCommodityPoolInfoBO
		 $this->action = 0; // uint32_t
		 $this->oprUser = ""; // std::string
		 $this->inReserve = ""; // std::string
		 $this->ExtentIn = new stl_map('stl_string,stl_string'); // std::map<std::string,std::string> 
	}	


	function Serialize(&$bs) {
		$bs->pushString($this->machineKey); // 序列化用户机器码 类型为std::string
		$bs->pushString($this->source); // 序列化请求来源 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id 类型为uint32_t
		$bs->pushObject($this->poolInfo, 'CommodityPoolInfoBO'); // 序列化商品池信息 类型为icson::commoditypoolmanage::bo::CCommodityPoolInfoBO
		$bs->pushUint32_t($this->action); // 序列化操作必须显示传递，0-非法 1-insert 2-update 3-remove 暂不支持3 类型为uint32_t
		$bs->pushString($this->oprUser); // 序列化操作人英文名 类型为std::string
		$bs->pushString($this->inReserve); // 序列化保留输入字 类型为std::string
		$bs->pushObject($this->ExtentIn, 'stl_map'); // 序列化扩展输入字  类型为std::map<std::string,std::string> 

	
		return $bs->isGood();
	}
	
	function getCmdId() {
		return 0x890c1003;
	}
}
//回复
class savePoolResp {
	var $result;
	var $errmsg;
	var $outReserve;
	var $ExtentOut;



	function Unserialize(&$bs) {
		$this->result = $bs->popUint32_t();
		$this->errmsg = $bs->popString(); // 反序列化错误信息 类型为std::string
		$this->outReserve = $bs->popString(); // 反序列化保留输出信息 类型为std::string
		$this->ExtentOut = $bs->popObject('stl_map<stl_string,stl_string> '); // 反序列化扩展输出信息 类型为std::map<std::string,std::string> 


	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x890c8003;
	}
}
//请求
class saveTermReq {
	var $machineKey;
	var $source;
	var $sceneId;
	var $termInfo;
	var $action;
	var $oprUser;
	var $inReserve;
	var $ExtentIn;


	function __construct() {
		 $this->machineKey = ""; // std::string
		 $this->source = ""; // std::string
		 $this->sceneId = 0; // uint32_t
		 $this->termInfo = new CommodityTermInfoBO(); // icson::commoditypoolmanage::bo::CCommodityTermInfoBO
		 $this->action = 0; // uint32_t
		 $this->oprUser = ""; // std::string
		 $this->inReserve = ""; // std::string
		 $this->ExtentIn = new stl_map('stl_string,stl_string'); // std::map<std::string,std::string> 
	}	


	function Serialize(&$bs) {
		$bs->pushString($this->machineKey); // 序列化用户机器码 类型为std::string
		$bs->pushString($this->source); // 序列化请求来源 类型为std::string
		$bs->pushUint32_t($this->sceneId); // 序列化场景id 类型为uint32_t
		$bs->pushObject($this->termInfo, 'CommodityTermInfoBO'); // 序列化商品池期数信息 类型为icson::commoditypoolmanage::bo::CCommodityTermInfoBO
		$bs->pushUint32_t($this->action); // 序列化操作必须显示传递，0-非法 1-insert 2-update 3-remove 暂不支持3 类型为uint32_t
		$bs->pushString($this->oprUser); // 序列化操作人英文名 类型为std::string
		$bs->pushString($this->inReserve); // 序列化保留输入字 类型为std::string
		$bs->pushObject($this->ExtentIn, 'stl_map'); // 序列化扩展输入字  类型为std::map<std::string,std::string> 

	
		return $bs->isGood();
	}
	
	function getCmdId() {
		return 0x890c1004;
	}
}
//回复
class saveTermResp {
	var $result;
	var $errmsg;
	var $outReserve;
	var $ExtentOut;



	function Unserialize(&$bs) {
		$this->result = $bs->popUint32_t();
		$this->errmsg = $bs->popString(); // 反序列化错误信息 类型为std::string
		$this->outReserve = $bs->popString(); // 反序列化保留输出信息 类型为std::string
		$this->ExtentOut = $bs->popObject('stl_map<stl_string,stl_string> '); // 反序列化扩展输出信息 类型为std::map<std::string,std::string> 


	
		return $bs->isGood();
	}

	function getCmdId() {
		return 0x890c8004;
	}
}

?>