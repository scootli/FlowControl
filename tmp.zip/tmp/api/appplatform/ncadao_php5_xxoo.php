<?php
namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.SearchPubNavByKeyResp.java
class NavMatchKey_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $matchInfo;	//<std::string> Matchinfo(版本>=0)
	private $pathInfo;	//<std::string> PathInfo(版本>=0)
	private $matchType;	//<uint32_t> MatchType(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->matchInfo = "";	//<std::string>
		$this->pathInfo = "";	//<std::string>
		$this->matchType = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\NavMatchKey_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\NavMatchKey_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushString($this->matchInfo);	//<std::string> Matchinfo
		$bs->pushString($this->pathInfo);	//<std::string> PathInfo
		$bs->pushUint32_t($this->matchType);	//<uint32_t> MatchType
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t> 导航id
		$this->_arr_value['matchInfo'] = $bs->popString();	//<std::string> Matchinfo
		$this->_arr_value['pathInfo'] = $bs->popString();	//<std::string> PathInfo
		$this->_arr_value['matchType'] = $bs->popUint32_t();	//<uint32_t> MatchType

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.NcaDao.java
class NavMatchKeyDdo{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint8_t>  版本号, version需要小写 (版本>=0)
	private $navId;	//<uint32_t>  导航id (版本>=0)
	private $matchInfo;	//<std::string>  Matchinfo (版本>=0)
	private $pathInfo;	//<std::string>  PathInfo (版本>=0)
	private $matchType;	//<uint32_t>  MatchType (版本>=0)

	function __construct(){
		$this->version = 0;	//<uint8_t>
		$this->navId = 0;	//<uint32_t>
		$this->matchInfo = "";	//<std::string>
		$this->pathInfo = "";	//<std::string>
		$this->matchType = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\NavMatchKeyDdo\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\NavMatchKeyDdo\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint8_t($this->version);	//<uint8_t>  版本号, version需要小写 
		$bs->pushUint32_t($this->navId);	//<uint32_t>  导航id 
		$bs->pushString($this->matchInfo);	//<std::string>  Matchinfo 
		$bs->pushString($this->pathInfo);	//<std::string>  PathInfo 
		$bs->pushUint32_t($this->matchType);	//<uint32_t>  MatchType 
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint8_t();	//<uint8_t>  版本号, version需要小写 
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t>  导航id 
		$this->_arr_value['matchInfo'] = $bs->popString();	//<std::string>  Matchinfo 
		$this->_arr_value['pathInfo'] = $bs->popString();	//<std::string>  PathInfo 
		$this->_arr_value['matchType'] = $bs->popUint32_t();	//<uint32_t>  MatchType 

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.GetPubPath_WGResp.java
class PublistNodeDdo{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint8_t>  版本号, version需要小写 (版本>=0)
	private $navId;	//<uint32_t>  导航id (版本>=0)
	private $attrId;	//<uint32_t>  属性项id (版本>=0)
	private $optionId;	//<uint32_t>  属性值id (版本>=0)
	private $type;	//<uint32_t>  类型:1属性，3类目，4品类 (版本>=0)
	private $name;	//<std::string>  name (版本>=0)
	private $propertyStr;	//<std::string>  property (版本>=0)
	private $anyChildren;	//<uint32_t>  是否有后继节点 (版本>=0)
	private $desc;	//<std::string>  sDesc (版本>=0)

	function __construct(){
		$this->version = 0;	//<uint8_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->type = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->propertyStr = "";	//<std::string>
		$this->anyChildren = 0;	//<uint32_t>
		$this->desc = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\PublistNodeDdo\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\PublistNodeDdo\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint8_t($this->version);	//<uint8_t>  版本号, version需要小写 
		$bs->pushUint32_t($this->navId);	//<uint32_t>  导航id 
		$bs->pushUint32_t($this->attrId);	//<uint32_t>  属性项id 
		$bs->pushUint32_t($this->optionId);	//<uint32_t>  属性值id 
		$bs->pushUint32_t($this->type);	//<uint32_t>  类型:1属性，3类目，4品类 
		$bs->pushString($this->name);	//<std::string>  name 
		$bs->pushString($this->propertyStr);	//<std::string>  property 
		$bs->pushUint32_t($this->anyChildren);	//<uint32_t>  是否有后继节点 
		$bs->pushString($this->desc);	//<std::string>  sDesc 
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint8_t();	//<uint8_t>  版本号, version需要小写 
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t>  导航id 
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t>  属性项id 
		$this->_arr_value['optionId'] = $bs->popUint32_t();	//<uint32_t>  属性值id 
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t>  类型:1属性，3类目，4品类 
		$this->_arr_value['name'] = $bs->popString();	//<std::string>  name 
		$this->_arr_value['propertyStr'] = $bs->popString();	//<std::string>  property 
		$this->_arr_value['anyChildren'] = $bs->popUint32_t();	//<uint32_t>  是否有后继节点 
		$this->_arr_value['desc'] = $bs->popString();	//<std::string>  sDesc 

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.GetPubPathResp.java
class PublistNode_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $optionId;	//<uint32_t> 属性值id(版本>=0)
	private $type;	//<uint32_t> 类型:1属性，3类目，4品类(版本>=0)
	private $name;	//<std::string> name(版本>=0)
	private $propertyStr;	//<std::string> property(版本>=0)
	private $anyChildren;	//<uint32_t> 是否有后继节点(版本>=0)
	private $desc;	//<std::string> sDesc(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->type = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->propertyStr = "";	//<std::string>
		$this->anyChildren = 0;	//<uint32_t>
		$this->desc = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\PublistNode_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\PublistNode_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->optionId);	//<uint32_t> 属性值id
		$bs->pushUint32_t($this->type);	//<uint32_t> 类型:1属性，3类目，4品类
		$bs->pushString($this->name);	//<std::string> name
		$bs->pushString($this->propertyStr);	//<std::string> property
		$bs->pushUint32_t($this->anyChildren);	//<uint32_t> 是否有后继节点
		$bs->pushString($this->desc);	//<std::string> sDesc
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t> 导航id
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t> 属性项id
		$this->_arr_value['optionId'] = $bs->popUint32_t();	//<uint32_t> 属性值id
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t> 类型:1属性，3类目，4品类
		$this->_arr_value['name'] = $bs->popString();	//<std::string> name
		$this->_arr_value['propertyStr'] = $bs->popString();	//<std::string> property
		$this->_arr_value['anyChildren'] = $bs->popUint32_t();	//<uint32_t> 是否有后继节点
		$this->_arr_value['desc'] = $bs->popString();	//<std::string> sDesc

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.GetOrderNavExResp.java
class OrderNavBoEx_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navNode;	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息(版本>=0)
	private $fullPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径(版本>=0)
	private $metaSearchPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径(版本>=0)
	private $childNode;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航(版本>=0)
	private $childAttrId;	//<std::vector<std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性(版本>=0)
	private $attrDic;	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navNode = new \c2cent\bo\nca_v3\NavEntry_v3();	//<c2cent::bo::nca_v3::CNavEntry_v3>
		$this->fullPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->metaSearchPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childNode = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childAttrId = new \stl_vector2('stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> ');	//<std::vector<std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > >
		$this->attrDic = new \stl_map2('uint32_t,\c2cent\bo\nca_v3\AttrBo_v3');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\OrderNavBoEx_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\OrderNavBoEx_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushObject($this->navNode,'\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$bs->pushObject($this->fullPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$bs->pushObject($this->metaSearchPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$bs->pushObject($this->childNode,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
		$bs->pushObject($this->childAttrId,'stl_vector');	//<std::vector<std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性
		$bs->pushObject($this->attrDic,'stl_map');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navNode'] = $bs->popObject('\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$this->_arr_value['metaSearchPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$this->_arr_value['childNode'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
		$this->_arr_value['childAttrId'] = $bs->popObject('stl_vector<stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> >');	//<std::vector<std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性
		$this->_arr_value['attrDic'] = $bs->popObject('stl_map<uint32_t,\c2cent\bo\nca_v3\AttrBo_v3>');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.GetNavExOrder_WGResp.java
class NavExOrderDdo{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint8_t>  版本号, version需要小写 (版本>=0)
	private $navNode;	//<b2b2c::nca::ddo::CNavEntryDdo>  导航信息 (版本>=0)
	private $fullPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  导航路径 (版本>=0)
	private $metaSearchPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  搜索导航路径 (版本>=0)
	private $childNode;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  儿子导航 (版本>=0)
	private $childAttrId;	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >  直接儿子属性 (版本>=0)
	private $attrDic;	//<std::vector<b2b2c::nca::ddo::CAttrDdo> >  属性字典 (版本>=0)

	function __construct(){
		$this->version = 0;	//<uint8_t>
		$this->navNode = new \b2b2c\nca\ddo\NavEntryDdo();	//<b2b2c::nca::ddo::CNavEntryDdo>
		$this->fullPath = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
		$this->metaSearchPath = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
		$this->childNode = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
		$this->childAttrId = new \stl_map2('uint32_t,stl_vector<\b2b2c\nca\ddo\SubAttrOptionDdo> ');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >
		$this->attrDic = new \stl_vector2('\b2b2c\nca\ddo\AttrDdo');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\NavExOrderDdo\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\NavExOrderDdo\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint8_t($this->version);	//<uint8_t>  版本号, version需要小写 
		$bs->pushObject($this->navNode,'\b2b2c\nca\ddo\NavEntryDdo');	//<b2b2c::nca::ddo::CNavEntryDdo>  导航信息 
		$bs->pushObject($this->fullPath,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  导航路径 
		$bs->pushObject($this->metaSearchPath,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  搜索导航路径 
		$bs->pushObject($this->childNode,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  儿子导航 
		$bs->pushObject($this->childAttrId,'stl_map');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >  直接儿子属性 
		$bs->pushObject($this->attrDic,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> >  属性字典 
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint8_t();	//<uint8_t>  版本号, version需要小写 
		$this->_arr_value['navNode'] = $bs->popObject('\b2b2c\nca\ddo\NavEntryDdo');	//<b2b2c::nca::ddo::CNavEntryDdo>  导航信息 
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  导航路径 
		$this->_arr_value['metaSearchPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  搜索导航路径 
		$this->_arr_value['childNode'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  儿子导航 
		$this->_arr_value['childAttrId'] = $bs->popObject('stl_map<uint32_t,stl_vector<\b2b2c\nca\ddo\SubAttrOptionDdo> >');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >  直接儿子属性 
		$this->_arr_value['attrDic'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\AttrDdo>');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> >  属性字典 

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.GetMetaClass_WGResp.java
class NavDdo{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint8_t>  版本号, version需要小写 (版本>=0)
	private $navNode;	//<b2b2c::nca::ddo::CNavEntryDdo>  导航信息 (版本>=0)
	private $fullPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  导航路径 (版本>=0)
	private $metaSearchPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  搜索导航路径 (版本>=0)
	private $childNode;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  儿子导航 (版本>=0)

	function __construct(){
		$this->version = 0;	//<uint8_t>
		$this->navNode = new \b2b2c\nca\ddo\NavEntryDdo();	//<b2b2c::nca::ddo::CNavEntryDdo>
		$this->fullPath = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
		$this->metaSearchPath = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
		$this->childNode = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\NavDdo\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\NavDdo\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint8_t($this->version);	//<uint8_t>  版本号, version需要小写 
		$bs->pushObject($this->navNode,'\b2b2c\nca\ddo\NavEntryDdo');	//<b2b2c::nca::ddo::CNavEntryDdo>  导航信息 
		$bs->pushObject($this->fullPath,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  导航路径 
		$bs->pushObject($this->metaSearchPath,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  搜索导航路径 
		$bs->pushObject($this->childNode,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  儿子导航 
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint8_t();	//<uint8_t>  版本号, version需要小写 
		$this->_arr_value['navNode'] = $bs->popObject('\b2b2c\nca\ddo\NavEntryDdo');	//<b2b2c::nca::ddo::CNavEntryDdo>  导航信息 
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  导航路径 
		$this->_arr_value['metaSearchPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  搜索导航路径 
		$this->_arr_value['childNode'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  儿子导航 

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.GetMetaClassEx_WGResp.java
class NavExDdo{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint8_t>  版本号, version需要小写 (版本>=0)
	private $navNode;	//<b2b2c::nca::ddo::CNavEntryDdo>  导航信息 (版本>=0)
	private $fullPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  导航路径 (版本>=0)
	private $metaSearchPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  搜索导航路径 (版本>=0)
	private $childNode;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  儿子导航 (版本>=0)
	private $childAttrId;	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >  直接儿子属性 (版本>=0)
	private $attrDic;	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> >  属性字典 (版本>=0)

	function __construct(){
		$this->version = 0;	//<uint8_t>
		$this->navNode = new \b2b2c\nca\ddo\NavEntryDdo();	//<b2b2c::nca::ddo::CNavEntryDdo>
		$this->fullPath = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
		$this->metaSearchPath = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
		$this->childNode = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
		$this->childAttrId = new \stl_map2('uint32_t,stl_vector<\b2b2c\nca\ddo\SubAttrOptionDdo> ');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >
		$this->attrDic = new \stl_map2('uint32_t,\b2b2c\nca\ddo\AttrDdo');	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\NavExDdo\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\NavExDdo\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint8_t($this->version);	//<uint8_t>  版本号, version需要小写 
		$bs->pushObject($this->navNode,'\b2b2c\nca\ddo\NavEntryDdo');	//<b2b2c::nca::ddo::CNavEntryDdo>  导航信息 
		$bs->pushObject($this->fullPath,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  导航路径 
		$bs->pushObject($this->metaSearchPath,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  搜索导航路径 
		$bs->pushObject($this->childNode,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  儿子导航 
		$bs->pushObject($this->childAttrId,'stl_map');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >  直接儿子属性 
		$bs->pushObject($this->attrDic,'stl_map');	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> >  属性字典 
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint8_t();	//<uint8_t>  版本号, version需要小写 
		$this->_arr_value['navNode'] = $bs->popObject('\b2b2c\nca\ddo\NavEntryDdo');	//<b2b2c::nca::ddo::CNavEntryDdo>  导航信息 
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  导航路径 
		$this->_arr_value['metaSearchPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  搜索导航路径 
		$this->_arr_value['childNode'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >  儿子导航 
		$this->_arr_value['childAttrId'] = $bs->popObject('stl_map<uint32_t,stl_vector<\b2b2c\nca\ddo\SubAttrOptionDdo> >');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >  直接儿子属性 
		$this->_arr_value['attrDic'] = $bs->popObject('stl_map<uint32_t,\b2b2c\nca\ddo\AttrDdo>');	//<std::map<uint32_t,b2b2c::nca::ddo::CAttrDdo> >  属性字典 

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.GetMetaClassExResp.java
class NavBoEx_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navNode;	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息(版本>=0)
	private $fullPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径(版本>=0)
	private $metaSearchPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径(版本>=0)
	private $childNode;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航(版本>=0)
	private $childAttrId;	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性(版本>=0)
	private $attrDic;	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navNode = new \c2cent\bo\nca_v3\NavEntry_v3();	//<c2cent::bo::nca_v3::CNavEntry_v3>
		$this->fullPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->metaSearchPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childNode = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childAttrId = new \stl_map2('uint32_t,stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> ');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > >
		$this->attrDic = new \stl_map2('uint32_t,\c2cent\bo\nca_v3\AttrBo_v3');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\NavBoEx_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\NavBoEx_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushObject($this->navNode,'\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$bs->pushObject($this->fullPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$bs->pushObject($this->metaSearchPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$bs->pushObject($this->childNode,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
		$bs->pushObject($this->childAttrId,'stl_map');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性
		$bs->pushObject($this->attrDic,'stl_map');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navNode'] = $bs->popObject('\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$this->_arr_value['metaSearchPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$this->_arr_value['childNode'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
		$this->_arr_value['childAttrId'] = $bs->popObject('stl_map<uint32_t,stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> >');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 直接儿子属性
		$this->_arr_value['attrDic'] = $bs->popObject('stl_map<uint32_t,\c2cent\bo\nca_v3\AttrBo_v3>');	//<std::map<uint32_t,c2cent::bo::nca_v3::CAttrBo_v3> > 属性字典

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.GetItemInfo_ALLResp.java
class Result_GetItemInfo_ALL{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号(版本>=0)
	private $searchPath;	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 搜索路径，下标0表示一级导航，下标最大表示叶子导航(版本>=0)
	private $searchBrotherPath;	//<std::vector<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > > 搜索路径上每一级的兄弟节点，下标0表示一级导航的兄弟，下标最大表示叶子导航的兄弟(版本>=0)
	private $attr;	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 商品属性串解析出的属性项(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->searchPath = new \stl_vector2('\b2b2c\nca\ddo\NavEntryDdo');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> >
		$this->searchBrotherPath = new \stl_vector2('stl_vector<\b2b2c\nca\ddo\NavEntryDdo> ');	//<std::vector<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > >
		$this->attr = new \stl_vector2('\b2b2c\nca\ddo\AttrDdo');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\Result_GetItemInfo_ALL\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\Result_GetItemInfo_ALL\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号
		$bs->pushObject($this->searchPath,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 搜索路径，下标0表示一级导航，下标最大表示叶子导航
		$bs->pushObject($this->searchBrotherPath,'stl_vector');	//<std::vector<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > > 搜索路径上每一级的兄弟节点，下标0表示一级导航的兄弟，下标最大表示叶子导航的兄弟
		$bs->pushObject($this->attr,'stl_vector');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 商品属性串解析出的属性项
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号
		$this->_arr_value['searchPath'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\NavEntryDdo>');	//<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > 搜索路径，下标0表示一级导航，下标最大表示叶子导航
		$this->_arr_value['searchBrotherPath'] = $bs->popObject('stl_vector<stl_vector<\b2b2c\nca\ddo\NavEntryDdo> >');	//<std::vector<std::vector<b2b2c::nca::ddo::CNavEntryDdo> > > 搜索路径上每一级的兄弟节点，下标0表示一级导航的兄弟，下标最大表示叶子导航的兄弟
		$this->_arr_value['attr'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\AttrDdo>');	//<std::vector<b2b2c::nca::ddo::CAttrDdo> > 商品属性串解析出的属性项

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.GetItemInfo_ALLReq.java
class Param_GetItemInfo_ALL{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号(版本>=0)
	private $metaId;	//<uint32_t> 品类id(版本>=0)
	private $attrStr;	//<std::string> 属性串(版本>=0)
	private $needSearchPath;	//<uint32_t> 是否需要搜索路径，0表示不需要(版本>=0)
	private $needSearchBrotherPath;	//<uint32_t> 是否需要搜索路径上每一级的兄弟节点，0表示不需要(版本>=0)
	private $needAttr;	//<uint32_t> 是否需要解析属性串，0表示不需要(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->metaId = 0;	//<uint32_t>
		$this->attrStr = "";	//<std::string>
		$this->needSearchPath = 0;	//<uint32_t>
		$this->needSearchBrotherPath = 0;	//<uint32_t>
		$this->needAttr = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\Param_GetItemInfo_ALL\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\Param_GetItemInfo_ALL\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号
		$bs->pushUint32_t($this->metaId);	//<uint32_t> 品类id
		$bs->pushString($this->attrStr);	//<std::string> 属性串
		$bs->pushUint32_t($this->needSearchPath);	//<uint32_t> 是否需要搜索路径，0表示不需要
		$bs->pushUint32_t($this->needSearchBrotherPath);	//<uint32_t> 是否需要搜索路径上每一级的兄弟节点，0表示不需要
		$bs->pushUint32_t($this->needAttr);	//<uint32_t> 是否需要解析属性串，0表示不需要
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号
		$this->_arr_value['metaId'] = $bs->popUint32_t();	//<uint32_t> 品类id
		$this->_arr_value['attrStr'] = $bs->popString();	//<std::string> 属性串
		$this->_arr_value['needSearchPath'] = $bs->popUint32_t();	//<uint32_t> 是否需要搜索路径，0表示不需要
		$this->_arr_value['needSearchBrotherPath'] = $bs->popUint32_t();	//<uint32_t> 是否需要搜索路径上每一级的兄弟节点，0表示不需要
		$this->_arr_value['needAttr'] = $bs->popUint32_t();	//<uint32_t> 是否需要解析属性串，0表示不需要

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.GetGroupNavResp.java
class NavBo_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navNode;	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息(版本>=0)
	private $fullPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径(版本>=0)
	private $metaSearchPath;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径(版本>=0)
	private $childNode;	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navNode = new \c2cent\bo\nca_v3\NavEntry_v3();	//<c2cent::bo::nca_v3::CNavEntry_v3>
		$this->fullPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->metaSearchPath = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
		$this->childNode = new \stl_vector2('\c2cent\bo\nca_v3\NavEntry_v3');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\NavBo_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\NavBo_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushObject($this->navNode,'\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$bs->pushObject($this->fullPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$bs->pushObject($this->metaSearchPath,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$bs->pushObject($this->childNode,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navNode'] = $bs->popObject('\c2cent\bo\nca_v3\NavEntry_v3');	//<c2cent::bo::nca_v3::CNavEntry_v3> 导航信息
		$this->_arr_value['fullPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 导航路径
		$this->_arr_value['metaSearchPath'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 搜索导航路径
		$this->_arr_value['childNode'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\NavEntry_v3>');	//<std::vector<c2cent::bo::nca_v3::CNavEntry_v3> > 儿子导航

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.GetAttrTextReq.java
class AttrBo_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $name;	//<std::string> 属性项名称(版本>=0)
	private $property;	//<uint32_t> property(版本>=0)
	private $type;	//<uint32_t> 类型(版本>=0)
	private $pAttrId;	//<uint32_t> 父属性项id(版本>=0)
	private $pOptionId;	//<uint32_t> 父属性值id(版本>=0)
	private $desc;	//<std::string> 属性项描述(版本>=0)
	private $order;	//<uint32_t> 属性项排序(版本>=0)
	private $options;	//<std::vector<c2cent::bo::nca_v3::COptionBo_v3> > 属性值集合(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->property = 0;	//<uint32_t>
		$this->type = 0;	//<uint32_t>
		$this->pAttrId = 0;	//<uint32_t>
		$this->pOptionId = 0;	//<uint32_t>
		$this->desc = "";	//<std::string>
		$this->order = 0;	//<uint32_t>
		$this->options = new \stl_vector2('\c2cent\bo\nca_v3\OptionBo_v3');	//<std::vector<c2cent::bo::nca_v3::COptionBo_v3> >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\AttrBo_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\AttrBo_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushString($this->name);	//<std::string> 属性项名称
		$bs->pushUint32_t($this->property);	//<uint32_t> property
		$bs->pushUint32_t($this->type);	//<uint32_t> 类型
		$bs->pushUint32_t($this->pAttrId);	//<uint32_t> 父属性项id
		$bs->pushUint32_t($this->pOptionId);	//<uint32_t> 父属性值id
		$bs->pushString($this->desc);	//<std::string> 属性项描述
		$bs->pushUint32_t($this->order);	//<uint32_t> 属性项排序
		$bs->pushObject($this->options,'stl_vector');	//<std::vector<c2cent::bo::nca_v3::COptionBo_v3> > 属性值集合
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t> 属性项id
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t> 导航id
		$this->_arr_value['name'] = $bs->popString();	//<std::string> 属性项名称
		$this->_arr_value['property'] = $bs->popUint32_t();	//<uint32_t> property
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t> 类型
		$this->_arr_value['pAttrId'] = $bs->popUint32_t();	//<uint32_t> 父属性项id
		$this->_arr_value['pOptionId'] = $bs->popUint32_t();	//<uint32_t> 父属性值id
		$this->_arr_value['desc'] = $bs->popString();	//<std::string> 属性项描述
		$this->_arr_value['order'] = $bs->popUint32_t();	//<uint32_t> 属性项排序
		$this->_arr_value['options'] = $bs->popObject('stl_vector<\c2cent\bo\nca_v3\OptionBo_v3>');	//<std::vector<c2cent::bo::nca_v3::COptionBo_v3> > 属性值集合

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.AttrBo_v3.java
class OptionBo_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $optionId;	//<uint32_t> 属性值id(版本>=0)
	private $type;	//<uint32_t> 类型(版本>=0)
	private $property;	//<uint32_t> property(版本>=0)
	private $order;	//<uint32_t> 属性值排序(版本>=0)
	private $name;	//<std::string> 属性值名称(版本>=0)
	private $subAttrIds;	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 属性值下的子属性值对(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->type = 0;	//<uint32_t>
		$this->property = 0;	//<uint32_t>
		$this->order = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->subAttrIds = new \stl_map2('uint32_t,stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> ');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > >
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\OptionBo_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\OptionBo_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->optionId);	//<uint32_t> 属性值id
		$bs->pushUint32_t($this->type);	//<uint32_t> 类型
		$bs->pushUint32_t($this->property);	//<uint32_t> property
		$bs->pushUint32_t($this->order);	//<uint32_t> 属性值排序
		$bs->pushString($this->name);	//<std::string> 属性值名称
		$bs->pushObject($this->subAttrIds,'stl_map');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 属性值下的子属性值对
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t> 属性项id
		$this->_arr_value['optionId'] = $bs->popUint32_t();	//<uint32_t> 属性值id
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t> 类型
		$this->_arr_value['property'] = $bs->popUint32_t();	//<uint32_t> property
		$this->_arr_value['order'] = $bs->popUint32_t();	//<uint32_t> 属性值排序
		$this->_arr_value['name'] = $bs->popString();	//<std::string> 属性值名称
		$this->_arr_value['subAttrIds'] = $bs->popObject('stl_map<uint32_t,stl_vector<\c2cent\bo\nca_v3\SubAttrOption_v3> >');	//<std::map<uint32_t,std::vector<c2cent::bo::nca_v3::CSubAttrOption_v3> > > 属性值下的子属性值对

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.OptionBo_v3.java
class SubAttrOption_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $attrId;	//<uint32_t> 属性项id(版本>=0)
	private $optionId;	//<uint32_t> 属性值id(版本>=0)
	private $property;	//<uint32_t> 值对property(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->property = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\SubAttrOption_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\SubAttrOption_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->attrId);	//<uint32_t> 属性项id
		$bs->pushUint32_t($this->optionId);	//<uint32_t> 属性值id
		$bs->pushUint32_t($this->property);	//<uint32_t> 值对property
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t> 属性项id
		$this->_arr_value['optionId'] = $bs->popUint32_t();	//<uint32_t> 属性值id
		$this->_arr_value['property'] = $bs->popUint32_t();	//<uint32_t> 值对property

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.GetAllMetaClass_WGResp.java
class NavEntryDdo{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint8_t>  版本号, version需要小写 (版本>=0)
	private $navId;	//<uint32_t>  导航id (版本>=0)
	private $mapId;	//<uint32_t>  地图id (版本>=0)
	private $pNavId;	//<uint32_t>  父导航id (版本>=0)
	private $name;	//<std::string>  导航名称 (版本>=0)
	private $type;	//<uint32_t>  导航类型 (版本>=0)
	private $catalog;	//<uint32_t>  导航分类 (版本>=0)
	private $note;	//<std::string>  备注 (版本>=0)
	private $order;	//<uint32_t>  排序字段 (版本>=0)
	private $propertyStr;	//<std::string>  导航property (版本>=0)
	private $searchCond;	//<std::string>  搜索条件 (版本>=0)
	private $hasAttr;	//<uint32_t>  是否有属性 (版本>=0)
	private $customStr1;	//<std::string>  导航预留自定义串1 (版本>=0)
	private $customStr2;	//<std::string>  导航预留自定义串2 (版本>=0)
	private $customUint1;	//<uint32_t>  导航预留自定义整形字段1 (版本>=0)
	private $customUint2;	//<uint32_t>  导航预留自定义整形字段2 (版本>=0)
	private $isPreDelete;	//<uint32_t>  是否预删除，0为否，其余为是 (版本>=140)
	private $isCooperatorFirst;	//<uint32_t>  是否合作伙伴优先，0为否，其余为是 (版本>=140)
	private $isLowPriceFirst;	//<uint32_t>  是否低价优先，0为否，其余为是 (版本>=140)
	private $isHighPriceFirst;	//<uint32_t>  是否高价优先，0为否，其余为是 (版本>=140)

	function __construct(){
		$this->version = 140;	//<uint8_t>
		$this->navId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->pNavId = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->type = 0;	//<uint32_t>
		$this->catalog = 0;	//<uint32_t>
		$this->note = "";	//<std::string>
		$this->order = 0;	//<uint32_t>
		$this->propertyStr = "";	//<std::string>
		$this->searchCond = "";	//<std::string>
		$this->hasAttr = 0;	//<uint32_t>
		$this->customStr1 = "";	//<std::string>
		$this->customStr2 = "";	//<std::string>
		$this->customUint1 = 0;	//<uint32_t>
		$this->customUint2 = 0;	//<uint32_t>
		$this->isPreDelete = 0;	//<uint32_t>
		$this->isCooperatorFirst = 0;	//<uint32_t>
		$this->isLowPriceFirst = 0;	//<uint32_t>
		$this->isHighPriceFirst = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\NavEntryDdo\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\NavEntryDdo\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint8_t($this->version);	//<uint8_t>  版本号, version需要小写 
		$bs->pushUint32_t($this->navId);	//<uint32_t>  导航id 
		$bs->pushUint32_t($this->mapId);	//<uint32_t>  地图id 
		$bs->pushUint32_t($this->pNavId);	//<uint32_t>  父导航id 
		$bs->pushString($this->name);	//<std::string>  导航名称 
		$bs->pushUint32_t($this->type);	//<uint32_t>  导航类型 
		$bs->pushUint32_t($this->catalog);	//<uint32_t>  导航分类 
		$bs->pushString($this->note);	//<std::string>  备注 
		$bs->pushUint32_t($this->order);	//<uint32_t>  排序字段 
		$bs->pushString($this->propertyStr);	//<std::string>  导航property 
		$bs->pushString($this->searchCond);	//<std::string>  搜索条件 
		$bs->pushUint32_t($this->hasAttr);	//<uint32_t>  是否有属性 
		$bs->pushString($this->customStr1);	//<std::string>  导航预留自定义串1 
		$bs->pushString($this->customStr2);	//<std::string>  导航预留自定义串2 
		$bs->pushUint32_t($this->customUint1);	//<uint32_t>  导航预留自定义整形字段1 
		$bs->pushUint32_t($this->customUint2);	//<uint32_t>  导航预留自定义整形字段2 
		if($this->version >= 140){
			$bs->pushUint32_t($this->isPreDelete);	//<uint32_t>  是否预删除，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isCooperatorFirst);	//<uint32_t>  是否合作伙伴优先，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isLowPriceFirst);	//<uint32_t>  是否低价优先，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isHighPriceFirst);	//<uint32_t>  是否高价优先，0为否，其余为是 
		}
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint8_t();	//<uint8_t>  版本号, version需要小写 
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t>  导航id 
		$this->_arr_value['mapId'] = $bs->popUint32_t();	//<uint32_t>  地图id 
		$this->_arr_value['pNavId'] = $bs->popUint32_t();	//<uint32_t>  父导航id 
		$this->_arr_value['name'] = $bs->popString();	//<std::string>  导航名称 
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t>  导航类型 
		$this->_arr_value['catalog'] = $bs->popUint32_t();	//<uint32_t>  导航分类 
		$this->_arr_value['note'] = $bs->popString();	//<std::string>  备注 
		$this->_arr_value['order'] = $bs->popUint32_t();	//<uint32_t>  排序字段 
		$this->_arr_value['propertyStr'] = $bs->popString();	//<std::string>  导航property 
		$this->_arr_value['searchCond'] = $bs->popString();	//<std::string>  搜索条件 
		$this->_arr_value['hasAttr'] = $bs->popUint32_t();	//<uint32_t>  是否有属性 
		$this->_arr_value['customStr1'] = $bs->popString();	//<std::string>  导航预留自定义串1 
		$this->_arr_value['customStr2'] = $bs->popString();	//<std::string>  导航预留自定义串2 
		$this->_arr_value['customUint1'] = $bs->popUint32_t();	//<uint32_t>  导航预留自定义整形字段1 
		$this->_arr_value['customUint2'] = $bs->popUint32_t();	//<uint32_t>  导航预留自定义整形字段2 
		if($this->version >= 140){
			$this->_arr_value['isPreDelete'] = $bs->popUint32_t();	//<uint32_t>  是否预删除，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isCooperatorFirst'] = $bs->popUint32_t();	//<uint32_t>  是否合作伙伴优先，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isLowPriceFirst'] = $bs->popUint32_t();	//<uint32_t>  是否低价优先，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isHighPriceFirst'] = $bs->popUint32_t();	//<uint32_t>  是否高价优先，0为否，其余为是 
		}

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace c2cent\bo\nca_v3;	//source idl: com.b2b2c.nca.idl.GetAllMetaClassResp.java
class NavEntry_v3{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $navId;	//<uint32_t> 导航id(版本>=0)
	private $mapId;	//<uint32_t> 地图id(版本>=0)
	private $pNavId;	//<uint32_t> 父导航id(版本>=0)
	private $name;	//<std::string> 导航名称(版本>=0)
	private $type;	//<uint32_t> 导航类型(版本>=0)
	private $catalog;	//<uint32_t> 导航分类(版本>=0)
	private $note;	//<std::string> 备注(版本>=0)
	private $order;	//<uint32_t> 排序字段(版本>=0)
	private $propertyStr;	//<std::string> 导航property(版本>=0)
	private $searchCond;	//<std::string> 搜索条件(版本>=0)
	private $hasAttr;	//<uint32_t> 是否有属性(版本>=0)
	private $customStr1;	//<std::string> 导航预留自定义串1(版本>=0)
	private $customStr2;	//<std::string> 导航预留自定义串2(版本>=0)
	private $metaCatalog;	//<uint32_t>  metaclass type(版本>=0)
	private $customUint2;	//<uint32_t> 导航预留自定义整形字段2(版本>=0)

	function __construct(){
		$this->version = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->mapId = 0;	//<uint32_t>
		$this->pNavId = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->type = 0;	//<uint32_t>
		$this->catalog = 0;	//<uint32_t>
		$this->note = "";	//<std::string>
		$this->order = 0;	//<uint32_t>
		$this->propertyStr = "";	//<std::string>
		$this->searchCond = "";	//<std::string>
		$this->hasAttr = 0;	//<uint32_t>
		$this->customStr1 = "";	//<std::string>
		$this->customStr2 = "";	//<std::string>
		$this->metaCatalog = 0;	//<uint32_t>
		$this->customUint2 = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("c2cent\bo\nca_v3\NavEntry_v3\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("c2cent\bo\nca_v3\NavEntry_v3\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->navId);	//<uint32_t> 导航id
		$bs->pushUint32_t($this->mapId);	//<uint32_t> 地图id
		$bs->pushUint32_t($this->pNavId);	//<uint32_t> 父导航id
		$bs->pushString($this->name);	//<std::string> 导航名称
		$bs->pushUint32_t($this->type);	//<uint32_t> 导航类型
		$bs->pushUint32_t($this->catalog);	//<uint32_t> 导航分类
		$bs->pushString($this->note);	//<std::string> 备注
		$bs->pushUint32_t($this->order);	//<uint32_t> 排序字段
		$bs->pushString($this->propertyStr);	//<std::string> 导航property
		$bs->pushString($this->searchCond);	//<std::string> 搜索条件
		$bs->pushUint32_t($this->hasAttr);	//<uint32_t> 是否有属性
		$bs->pushString($this->customStr1);	//<std::string> 导航预留自定义串1
		$bs->pushString($this->customStr2);	//<std::string> 导航预留自定义串2
		$bs->pushUint32_t($this->metaCatalog);	//<uint32_t>  metaclass type
		$bs->pushUint32_t($this->customUint2);	//<uint32_t> 导航预留自定义整形字段2
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t> 导航id
		$this->_arr_value['mapId'] = $bs->popUint32_t();	//<uint32_t> 地图id
		$this->_arr_value['pNavId'] = $bs->popUint32_t();	//<uint32_t> 父导航id
		$this->_arr_value['name'] = $bs->popString();	//<std::string> 导航名称
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t> 导航类型
		$this->_arr_value['catalog'] = $bs->popUint32_t();	//<uint32_t> 导航分类
		$this->_arr_value['note'] = $bs->popString();	//<std::string> 备注
		$this->_arr_value['order'] = $bs->popUint32_t();	//<uint32_t> 排序字段
		$this->_arr_value['propertyStr'] = $bs->popString();	//<std::string> 导航property
		$this->_arr_value['searchCond'] = $bs->popString();	//<std::string> 搜索条件
		$this->_arr_value['hasAttr'] = $bs->popUint32_t();	//<uint32_t> 是否有属性
		$this->_arr_value['customStr1'] = $bs->popString();	//<std::string> 导航预留自定义串1
		$this->_arr_value['customStr2'] = $bs->popString();	//<std::string> 导航预留自定义串2
		$this->_arr_value['metaCatalog'] = $bs->popUint32_t();	//<uint32_t>  metaclass type
		$this->_arr_value['customUint2'] = $bs->popUint32_t();	//<uint32_t> 导航预留自定义整形字段2

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.NcaDao.java
class AttrDdo{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint8_t>  版本号, version需要小写 (版本>=0)
	private $attrId;	//<uint32_t>  属性项id (版本>=0)
	private $navId;	//<uint32_t>  导航id (版本>=0)
	private $name;	//<std::string>  属性项名称，按照优先级NameSeller>NameOperator>NameOriginal得到的综合结果(版本>=0)
	private $property;	//<uint32_t>  property (版本>=0)
	private $type;	//<uint32_t>  类型 (版本>=0)
	private $pAttrId;	//<uint32_t>  父属性项id (版本>=0)
	private $pOptionId;	//<uint32_t>  父属性值id (版本>=0)
	private $desc;	//<std::string>  属性项描述 (版本>=0)
	private $order;	//<uint32_t>  属性项排序 (版本>=0)
	private $options;	//<std::vector<b2b2c::nca::ddo::COptionDdo> >  属性值集合 (版本>=0)
	private $isOptional;	//<uint32_t>  是否选项，0为否，其余为是 (版本>=140)
	private $isText;	//<uint32_t>  是否文本，0为否，其余为是 (版本>=140)
	private $isSingle;	//<uint32_t>  是否单选，0为否，其余为是 (版本>=140)
	private $isMulti;	//<uint32_t>  是否多选，0为否，其余为是 (版本>=140)
	private $isMust;	//<uint32_t>  是否可选，0为否，其余为是 (版本>=140)
	private $isSpuKey;	//<uint32_t>  是否关键属性，0为否，其余为是 (版本>=140)
	private $isSpuComm;	//<uint32_t>  是否SPU一般属性，0为否，其余为是 (版本>=140)
	private $isSkuSale;	//<uint32_t>  是否销售属性，0为否，其余为是 (版本>=140)
	private $isSkuComm;	//<uint32_t>  是否一般属性，0为否，其余为是 (版本>=140)
	private $isSearchJoint;	//<uint32_t>  是否搜索聚合属性，0为否，其余为是 (版本>=140)
	private $isHideSX;	//<uint32_t>  是否商详隐藏属性，0为否，其余为是 (版本>=140)
	private $isSellerAttrAlias;	//<uint32_t>  是否支持卖家对属性项设置别名，0为否，其余为是 (版本>=141)
	private $isSellerOptAlias;	//<uint32_t>  是否支持卖家对属性值设置别名，0为否，其余为是 (版本>=141)
	private $nameOriginal;	//<std::string> 原始名(版本>=142)
	private $nameOperator;	//<std::string> 运营加挂时定义的别名(版本>=142)
	private $nameSeller;	//<std::string> 卖家自定义名(版本>=142)

	function __construct(){
		$this->version = 142;	//<uint8_t>
		$this->attrId = 0;	//<uint32_t>
		$this->navId = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->property = 0;	//<uint32_t>
		$this->type = 0;	//<uint32_t>
		$this->pAttrId = 0;	//<uint32_t>
		$this->pOptionId = 0;	//<uint32_t>
		$this->desc = "";	//<std::string>
		$this->order = 0;	//<uint32_t>
		$this->options = new \stl_vector2('\b2b2c\nca\ddo\OptionDdo');	//<std::vector<b2b2c::nca::ddo::COptionDdo> >
		$this->isOptional = 0;	//<uint32_t>
		$this->isText = 0;	//<uint32_t>
		$this->isSingle = 0;	//<uint32_t>
		$this->isMulti = 0;	//<uint32_t>
		$this->isMust = 0;	//<uint32_t>
		$this->isSpuKey = 0;	//<uint32_t>
		$this->isSpuComm = 0;	//<uint32_t>
		$this->isSkuSale = 0;	//<uint32_t>
		$this->isSkuComm = 0;	//<uint32_t>
		$this->isSearchJoint = 0;	//<uint32_t>
		$this->isHideSX = 0;	//<uint32_t>
		$this->isSellerAttrAlias = 0;	//<uint32_t>
		$this->isSellerOptAlias = 0;	//<uint32_t>
		$this->nameOriginal = "";	//<std::string>
		$this->nameOperator = "";	//<std::string>
		$this->nameSeller = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\AttrDdo\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\AttrDdo\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint8_t($this->version);	//<uint8_t>  版本号, version需要小写 
		$bs->pushUint32_t($this->attrId);	//<uint32_t>  属性项id 
		$bs->pushUint32_t($this->navId);	//<uint32_t>  导航id 
		$bs->pushString($this->name);	//<std::string>  属性项名称，按照优先级NameSeller>NameOperator>NameOriginal得到的综合结果
		$bs->pushUint32_t($this->property);	//<uint32_t>  property 
		$bs->pushUint32_t($this->type);	//<uint32_t>  类型 
		$bs->pushUint32_t($this->pAttrId);	//<uint32_t>  父属性项id 
		$bs->pushUint32_t($this->pOptionId);	//<uint32_t>  父属性值id 
		$bs->pushString($this->desc);	//<std::string>  属性项描述 
		$bs->pushUint32_t($this->order);	//<uint32_t>  属性项排序 
		$bs->pushObject($this->options,'stl_vector');	//<std::vector<b2b2c::nca::ddo::COptionDdo> >  属性值集合 
		if($this->version >= 140){
			$bs->pushUint32_t($this->isOptional);	//<uint32_t>  是否选项，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isText);	//<uint32_t>  是否文本，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isSingle);	//<uint32_t>  是否单选，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isMulti);	//<uint32_t>  是否多选，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isMust);	//<uint32_t>  是否可选，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isSpuKey);	//<uint32_t>  是否关键属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isSpuComm);	//<uint32_t>  是否SPU一般属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isSkuSale);	//<uint32_t>  是否销售属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isSkuComm);	//<uint32_t>  是否一般属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isSearchJoint);	//<uint32_t>  是否搜索聚合属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$bs->pushUint32_t($this->isHideSX);	//<uint32_t>  是否商详隐藏属性，0为否，其余为是 
		}
		if($this->version >= 141){
			$bs->pushUint32_t($this->isSellerAttrAlias);	//<uint32_t>  是否支持卖家对属性项设置别名，0为否，其余为是 
		}
		if($this->version >= 141){
			$bs->pushUint32_t($this->isSellerOptAlias);	//<uint32_t>  是否支持卖家对属性值设置别名，0为否，其余为是 
		}
		if($this->version >= 142){
			$bs->pushString($this->nameOriginal);	//<std::string> 原始名
		}
		if($this->version >= 142){
			$bs->pushString($this->nameOperator);	//<std::string> 运营加挂时定义的别名
		}
		if($this->version >= 142){
			$bs->pushString($this->nameSeller);	//<std::string> 卖家自定义名
		}
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint8_t();	//<uint8_t>  版本号, version需要小写 
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t>  属性项id 
		$this->_arr_value['navId'] = $bs->popUint32_t();	//<uint32_t>  导航id 
		$this->_arr_value['name'] = $bs->popString();	//<std::string>  属性项名称，按照优先级NameSeller>NameOperator>NameOriginal得到的综合结果
		$this->_arr_value['property'] = $bs->popUint32_t();	//<uint32_t>  property 
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t>  类型 
		$this->_arr_value['pAttrId'] = $bs->popUint32_t();	//<uint32_t>  父属性项id 
		$this->_arr_value['pOptionId'] = $bs->popUint32_t();	//<uint32_t>  父属性值id 
		$this->_arr_value['desc'] = $bs->popString();	//<std::string>  属性项描述 
		$this->_arr_value['order'] = $bs->popUint32_t();	//<uint32_t>  属性项排序 
		$this->_arr_value['options'] = $bs->popObject('stl_vector<\b2b2c\nca\ddo\OptionDdo>');	//<std::vector<b2b2c::nca::ddo::COptionDdo> >  属性值集合 
		if($this->version >= 140){
			$this->_arr_value['isOptional'] = $bs->popUint32_t();	//<uint32_t>  是否选项，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isText'] = $bs->popUint32_t();	//<uint32_t>  是否文本，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isSingle'] = $bs->popUint32_t();	//<uint32_t>  是否单选，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isMulti'] = $bs->popUint32_t();	//<uint32_t>  是否多选，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isMust'] = $bs->popUint32_t();	//<uint32_t>  是否可选，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isSpuKey'] = $bs->popUint32_t();	//<uint32_t>  是否关键属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isSpuComm'] = $bs->popUint32_t();	//<uint32_t>  是否SPU一般属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isSkuSale'] = $bs->popUint32_t();	//<uint32_t>  是否销售属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isSkuComm'] = $bs->popUint32_t();	//<uint32_t>  是否一般属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isSearchJoint'] = $bs->popUint32_t();	//<uint32_t>  是否搜索聚合属性，0为否，其余为是 
		}
		if($this->version >= 140){
			$this->_arr_value['isHideSX'] = $bs->popUint32_t();	//<uint32_t>  是否商详隐藏属性，0为否，其余为是 
		}
		if($this->version >= 141){
			$this->_arr_value['isSellerAttrAlias'] = $bs->popUint32_t();	//<uint32_t>  是否支持卖家对属性项设置别名，0为否，其余为是 
		}
		if($this->version >= 141){
			$this->_arr_value['isSellerOptAlias'] = $bs->popUint32_t();	//<uint32_t>  是否支持卖家对属性值设置别名，0为否，其余为是 
		}
		if($this->version >= 142){
			$this->_arr_value['nameOriginal'] = $bs->popString();	//<std::string> 原始名
		}
		if($this->version >= 142){
			$this->_arr_value['nameOperator'] = $bs->popString();	//<std::string> 运营加挂时定义的别名
		}
		if($this->version >= 142){
			$this->_arr_value['nameSeller'] = $bs->popString();	//<std::string> 卖家自定义名
		}

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.AttrDdo.java
class OptionDdo{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint8_t>  版本号, version需要小写(版本>=0)
	private $attrId;	//<uint32_t>  属性项id (版本>=0)
	private $optionId;	//<uint32_t>  属性值id (版本>=0)
	private $type;	//<uint32_t>  类型 (版本>=0)
	private $property;	//<uint32_t>  property (版本>=0)
	private $order;	//<uint32_t>  属性值排序 (版本>=0)
	private $name;	//<std::string> 属性值名称，按照优先级NameSeller>NameOperator>NameOriginal得到的综合结果(版本>=0)
	private $subAttrIds;	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >  属性值下的子属性值对 (版本>=0)
	private $nameOriginal;	//<std::string> 原始名(版本>=142)
	private $nameOperator;	//<std::string> 运营加挂时定义的别名(版本>=142)
	private $nameSeller;	//<std::string> 卖家自定义名(版本>=142)

	function __construct(){
		$this->version = 142;	//<uint8_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->type = 0;	//<uint32_t>
		$this->property = 0;	//<uint32_t>
		$this->order = 0;	//<uint32_t>
		$this->name = "";	//<std::string>
		$this->subAttrIds = new \stl_map2('uint32_t,stl_vector<\b2b2c\nca\ddo\SubAttrOptionDdo> ');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >
		$this->nameOriginal = "";	//<std::string>
		$this->nameOperator = "";	//<std::string>
		$this->nameSeller = "";	//<std::string>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\OptionDdo\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\OptionDdo\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint8_t($this->version);	//<uint8_t>  版本号, version需要小写
		$bs->pushUint32_t($this->attrId);	//<uint32_t>  属性项id 
		$bs->pushUint32_t($this->optionId);	//<uint32_t>  属性值id 
		$bs->pushUint32_t($this->type);	//<uint32_t>  类型 
		$bs->pushUint32_t($this->property);	//<uint32_t>  property 
		$bs->pushUint32_t($this->order);	//<uint32_t>  属性值排序 
		$bs->pushString($this->name);	//<std::string> 属性值名称，按照优先级NameSeller>NameOperator>NameOriginal得到的综合结果
		$bs->pushObject($this->subAttrIds,'stl_map');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >  属性值下的子属性值对 
		if($this->version >= 142){
			$bs->pushString($this->nameOriginal);	//<std::string> 原始名
		}
		if($this->version >= 142){
			$bs->pushString($this->nameOperator);	//<std::string> 运营加挂时定义的别名
		}
		if($this->version >= 142){
			$bs->pushString($this->nameSeller);	//<std::string> 卖家自定义名
		}
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint8_t();	//<uint8_t>  版本号, version需要小写
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t>  属性项id 
		$this->_arr_value['optionId'] = $bs->popUint32_t();	//<uint32_t>  属性值id 
		$this->_arr_value['type'] = $bs->popUint32_t();	//<uint32_t>  类型 
		$this->_arr_value['property'] = $bs->popUint32_t();	//<uint32_t>  property 
		$this->_arr_value['order'] = $bs->popUint32_t();	//<uint32_t>  属性值排序 
		$this->_arr_value['name'] = $bs->popString();	//<std::string> 属性值名称，按照优先级NameSeller>NameOperator>NameOriginal得到的综合结果
		$this->_arr_value['subAttrIds'] = $bs->popObject('stl_map<uint32_t,stl_vector<\b2b2c\nca\ddo\SubAttrOptionDdo> >');	//<std::map<uint32_t,std::vector<b2b2c::nca::ddo::CSubAttrOptionDdo> > >  属性值下的子属性值对 
		if($this->version >= 142){
			$this->_arr_value['nameOriginal'] = $bs->popString();	//<std::string> 原始名
		}
		if($this->version >= 142){
			$this->_arr_value['nameOperator'] = $bs->popString();	//<std::string> 运营加挂时定义的别名
		}
		if($this->version >= 142){
			$this->_arr_value['nameSeller'] = $bs->popString();	//<std::string> 卖家自定义名
		}

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.OptionDdo.java
class SubAttrOptionDdo{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint8_t>  版本号, version需要小写 (版本>=0)
	private $attrId;	//<uint32_t>  属性项id (版本>=0)
	private $optionId;	//<uint32_t>  属性值id (版本>=0)
	private $property;	//<uint32_t>  值对property (版本>=0)

	function __construct(){
		$this->version = 0;	//<uint8_t>
		$this->attrId = 0;	//<uint32_t>
		$this->optionId = 0;	//<uint32_t>
		$this->property = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\SubAttrOptionDdo\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\SubAttrOptionDdo\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint8_t($this->version);	//<uint8_t>  版本号, version需要小写 
		$bs->pushUint32_t($this->attrId);	//<uint32_t>  属性项id 
		$bs->pushUint32_t($this->optionId);	//<uint32_t>  属性值id 
		$bs->pushUint32_t($this->property);	//<uint32_t>  值对property 
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint8_t();	//<uint8_t>  版本号, version需要小写 
		$this->_arr_value['attrId'] = $bs->popUint32_t();	//<uint32_t>  属性项id 
		$this->_arr_value['optionId'] = $bs->popUint32_t();	//<uint32_t>  属性值id 
		$this->_arr_value['property'] = $bs->popUint32_t();	//<uint32_t>  值对property 

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}

namespace b2b2c\nca\ddo;	//source idl: com.b2b2c.nca.idl.NcaDao.java
class APIControl{
	private $_arr_value=array();	//数组形式的类
	private $version;	//<uint32_t> 版本号, version需要小写(版本>=0)
	private $charset;	//<uint32_t> 入参编码类型，1:GBK，2:UTF-8(版本>=0)
	private $source;	//<uint32_t> 来源，1:易讯(版本>=0)
	private $option;	//<uint32_t> 跟Source和具体接口有关的选项，具体看各个接口对于APIControl参数的说明（如果有的话）(版本>=0)
	private $charsetRsp;	//<uint32_t> 回参编码类型，0表示与入参编码类型相同，1:GBK，2:UTF-8(版本>=1)

	function __construct(){
		$this->version = 1;	//<uint32_t>
		$this->charset = 0;	//<uint32_t>
		$this->source = 0;	//<uint32_t>
		$this->option = 0;	//<uint32_t>
		$this->charsetRsp = 0;	//<uint32_t>
	}

	function __set($name,$val){
		if(isset($this->$name)){
			if(is_object($this->$name)){
				if(!is_array($val)) exit("b2b2c\nca\ddo\APIControl\\{$name}：请直接赋值为数组，无需new ***。");
				if(strpos(get_class($this->$name), 'stl_')===0){
					$class=$this->$name->element_type;
					$arr = array();
					if(class_exists($class,false)){
						for($i=0;$i<count($val);$i++){
							$arr[$i]=new $class();
							foreach($val[$i] as $k => $v){
								$arr[$i]->$k=$v;
							}
						}
					}else{
						$arr=$val;
					}
					$this->$name->setValue($arr);
				}else{
					foreach($val as $k => $v){
						$this->$name->$k=$v;
					}
				}
			}else{
				if($name=="version" && ($val < 0 || $val > $this->version)){
					exit("Version error.It must be > 0 and < {$this->version} (default version).Now value is {$val}.");
				}
				$this->$name=$val;
			}
			if(isset($this->{$name.'_u'})){
				$this->{$name.'_u'}=1;
			}
		}else{
			exit("b2b2c\nca\ddo\APIControl\\{$name}：不存在此变量，请查询xxoo。");
		}
	}

	function __get($name){
		return $this->$name;
	}

	function serialize($bs){
		$bs->pushUint32_t($this->getClassLen());
		$this->serialize_internal($bs);
	}

	function serialize_internal($bs){
		$bs->pushUint32_t($this->version);	//<uint32_t> 版本号, version需要小写
		$bs->pushUint32_t($this->charset);	//<uint32_t> 入参编码类型，1:GBK，2:UTF-8
		$bs->pushUint32_t($this->source);	//<uint32_t> 来源，1:易讯
		$bs->pushUint32_t($this->option);	//<uint32_t> 跟Source和具体接口有关的选项，具体看各个接口对于APIControl参数的说明（如果有的话）
		if($this->version >= 1){
			$bs->pushUint32_t($this->charsetRsp);	//<uint32_t> 回参编码类型，0表示与入参编码类型相同，1:GBK，2:UTF-8
		}
	}

	function unserialize($bs){
		$class_len = $bs->popUint32_t();
		$startPop  = $bs->getReadLength();
		$this->_arr_value['version'] = $bs->popUint32_t();	//<uint32_t> 版本号, version需要小写
		$this->_arr_value['charset'] = $bs->popUint32_t();	//<uint32_t> 入参编码类型，1:GBK，2:UTF-8
		$this->_arr_value['source'] = $bs->popUint32_t();	//<uint32_t> 来源，1:易讯
		$this->_arr_value['option'] = $bs->popUint32_t();	//<uint32_t> 跟Source和具体接口有关的选项，具体看各个接口对于APIControl参数的说明（如果有的话）
		if($this->version >= 1){
			$this->_arr_value['charsetRsp'] = $bs->popUint32_t();	//<uint32_t> 回参编码类型，0表示与入参编码类型相同，1:GBK，2:UTF-8
		}

		/**********************为了支持多个版本的客户端************************/
		$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
		for($idx = 0;$idx < $needPopLen;$idx++){
			$bs->popUint8_t();
		}
		/**********************为了支持多个版本的客户端************************/
		
		return $this->_arr_value;
	}

	function getClassLen(){
		$len_bs = new \ByteStream2();
		$len_bs->setRealWrite(false);
		$this->serialize_internal($len_bs);
		$class_len = $len_bs->getWrittenLength();

		return $class_len;
	}
}
