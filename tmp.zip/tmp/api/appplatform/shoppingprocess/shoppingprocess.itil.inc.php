<?php
/*
 * �������̵�ITIL��ģ������
 */

global $shoppingProcessItil;

$shoppingProcessItil = array(
	"order"     =>  array(
        "order" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "orderDB" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "inventoryDB" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "shoppingcart" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "product" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "inventory" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "tying" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "package" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "tyingMind" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "tyingEWarranty" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "tyingGift" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "singleCoupon" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "delivery" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "payType" => array(
            "req"	 => 0,
			"succ"	 => 0,
			"failed" => 0,
			),
        "user"    => array(
            "req"	 => 0,
            "succ"	 => 0,
            "failed" => 0,
        ),

    ),
    "process"   =>  array(
        "process" => array(
            "req"	 => 0,
            "succ"	 => 0,
            "failed" => 0,
        ),
    ),
    "cart"      =>  array(
        "cart" => array(
            "req"	 => 0,
            "succ"	 => 0,
            "failed" => 0,
        ),
    ),
);