<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hedyhe
 * Date: 13-4-24
 * Time: 上午18:07
 * To change this template use File | Settings | File Templates.
 */

if(!defined("PHPLIB_ROOT")) {
    define('PHPLIB_ROOT', '/data/release/PHPLIB/');
}

define('ICSON_BOOKING_TYPE_SPECIFIC_DATE',11); //bookingtype 下指定的bookingvalue为字符串
define('WEB_STUB_TIME_OUT',3);
define('SHOPPING_PROCESS_INVENTORY_SCENE_ID', 10008);

require_once PHPLIB_ROOT."api/appplatform/shoppingprocess/include/attachmentao_stub4php.php";
require_once PHPLIB_ROOT."api/appplatform/shoppingprocess/include/productinventorydao_stub4php.php";
require_once PHPLIB_ROOT."api/appplatform/shoppingprocess/include/shippingao_stub4php.php";
require_once PHPLIB_ROOT."api/appplatform/shoppingprocess/include/shippingao_xxo.php";
require_once PHPLIB_ROOT."api/appplatform/shoppingprocess/include/dashousellao_stub4php.php";
require_once PHPLIB_ROOT."api/appplatform/shoppingprocess/include/dashousellao_xxo.php";
require_once PHPLIB_ROOT."api/appplatform/shoppingprocess/include/skuorderao_stub4php.php";
require_once PHPLIB_ROOT."api/appplatform/shoppingprocess/include/paytypeao_stub4php.php";
require_once PHPLIB_ROOT."api/appplatform/shoppingprocess/include/detailviewao_stub4php.php";
require_once PHPLIB_ROOT."api/appplatform/pointsaccountao_stub4php.php";
require_once PHPLIB_ROOT."api/appplatform/platform/web_stub_cntl.php";
require_once PHPLIB_ROOT."api/appplatform/platform/lang_util.php";
class WebCntl{
    public static function initCntl($uid)
    {
        $_cntl = new WebStubCntl();
        $sPassport = "0123456789";
        $_cntl->setDwOperatorId($uid);
        $_cntl->setSPassport($sPassport);
        $_cntl->setDwSerialNo(10002);
        $_cntl->setDwUin($uid);
        $_cntl->setWVersion(2);
        $_cntl->setCallerName("ICSON_shoppingprocess");
        return $_cntl;
    }
}

class AttachmentOperator{

    /*根据规则Id列表货套餐*/
    public  static function GetPackageByRules($stationId,$areaId,$rulesId,$uid = 0){
       // GetPackageByRuleIdsResp

        if($uid == 0 ) {
            $uid = rand(0,1000);
        }

        $vecRule = new stl_vector();
		$vecRule->setType('uint32_t');
		$vecRule->setValue($rulesId);
		
		$req = new GetPackageByRuleIdsReq;
        $resp = new GetPackageByRuleIdsResp;


		$req->stationId = $stationId;
		$req->areaId = $areaId;
		$req->rulesId = $vecRule;
		$req->ReserveIn = "";
		$req->machineKey = __FILE__;
		$req->sceneId = 0;


        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        //return (array('resp'=>$resp, 'ret'=>$ret));
        if($ret != 0 ) {
            return array(
                'code' => $ret,
                'msg'  =>'invoke err'
            );
        }
		$maprulPackage = array();
		$maprulPackage = $resp->MapMRuleIdPackage->getValue();
		$rulePackage = array();
		foreach ( $maprulPackage as $key =>$value) {
			$product = array();
			foreach ($value -> vecVecPackageInfo as $pacInfoVale) {

                $product[] = array(
                    'productId' => $pacInfoVale ->dwProductId,
				    'name' =>  $pacInfoVale ->strName,
				    'productCharId' =>  $pacInfoVale ->strProductCharId,
				    'price' =>  $pacInfoVale ->nPrice,
				    'packageCashBack' =>  $pacInfoVale ->dwPackageCashBack
                 );

                /*
                $product[] = array(
                   'product_id'      => $pacInfoVale ->dwProductId,
                   'buy_count'       => 0,
                   'main_product_id' => $pacInfoVale -> strName,
                   'price_id'        => 0,
                   'name'            => $pacInfoVale -> strName,
                   'type'            =>  0,
                   'package_id'      => $value -> dwRuleId,
                   'unique_id'       => $pacInfoVale -> dwProductId . "_" . $value -> dwRuleId,
                   'pkg_cash_back'   =>  $pacInfoVale -> dwPackageCashBack,
                   'price'           =>    $pacInfoVale -> nPrice,
                   'marketPrice'     =>    $pacInfoVale -> nMarketPrice,
                   'productCharId'   =>    $pacInfoVale -> strProductCharId,
                   'whId'            =>     $pacInfoVale -> dwWhId,
                   'flag'            =>    $pacInfoVale -> nFlag,
                   'status'          =>    $pacInfoVale -> nStatus,
                   'restrictedTransType'          =>    $pacInfoVale -> nRestrictedTransType,
                   'promotionWord'          =>     $pacInfoVale -> strPromotionWord,
                   'availableNum'          =>     $pacInfoVale -> nAvailableNum,
                   'virtualNum'          =>     $pacInfoVale -> nVirtualNum,
                   'psyStock'          =>     $pacInfoVale -> dwPsyStock,
                   'arrivalDays'          =>     $pacInfoVale -> nArrivalDays,
                   'costPrice'          =>    $pacInfoVale -> nCostPrice,
                   'numLimit'          =>     $pacInfoVale -> nNumLimit,
                   'c3Ids'          =>     $pacInfoVale -> strC3Ids,
                   'weight'          =>     $pacInfoVale -> dwWeight,
                   'picNum'          =>     $pacInfoVale -> dwPicNum,
                   'color'          =>     $pacInfoVale -> nColor,
                   'size'          =>     $pacInfoVale -> nProductSize,
                   'cashBack'     =>    $pacInfoVale -> dwPackageCashBack + $pacInfoVale -> nCashBack,
				);
                */
			}
			$rulePackage[$key] = array(
								'version' => $value->wVersion,
								'promotionName' => $value->strPromotionName,
								'ruleId' => $value -> dwRuleId,
								'vecPackageInfo' =>$product
								);
		}
		//进行数据转换
        return (array(
            'code' => $ret,
            'msg'  =>'',
            'data' => array(
                     'result' => $resp->result,
                     'mapMRuleIdPackage' =>$rulePackage,
                     'errmsg' => $resp->errmsg,

                     )
        ));

    }
    /*根据主商品id列表获取赠品和组件*/
    public  static function GetGift($stationId,$areaId,$productIds ,$uid = 0){

        if($uid == 0 ) {
            $uid = rand(0,1000);
        }
        $vecProduct = new stl_vector();
		$vecProduct->setType('uint32_t');
		$vecProduct->setValue($productIds);
		
		$mainProduct = new MainProduct();
        $mainProduct->wVersion = 0 ;
        $mainProduct->vecMainProductIdList = $vecProduct;
		
		$req = new GetGiftReq;
        $resp = new GetGiftResp;

		$req->stationId = $stationId;
		$req->areaId = $areaId;
		$req->Mainproduct = $mainProduct;
		$req->ReserveIn = "";
		$req->machineKey = __FILE__;
		$req->sceneId = 0;


        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
       // return (array('resp'=>$resp, 'ret'=>$ret));
        if($ret != 0 ) {
            return array(
                'code' => $ret,
                'msg'  =>'invoke err'
            );
        }
		//进行数据转换
		
		$mapGift = array();
		foreach ($resp -> MapMainIdGift ->getValue() as $key => $value ) {
			$vecgift = array();
			foreach ($value ->getValue() as $giftValue) {
				$giftid = $giftValue -> dwGiftId;
				$vecgift[] = array(
                    'product_id' => $giftValue -> dwGiftId,
				    'name'       => $giftValue -> strName,
				    'num'        => $giftValue -> dwNum,
				    'product_char_id' => $giftValue -> strProductCharId,
				    'type'       =>  $giftValue -> dwType,
				    'stock_num'  =>  $giftValue -> dwStockNum,
				    'weight'     =>  $giftValue -> dwWeight,
				    'status'     =>  $giftValue -> nStatus,
				    'marketprice'     =>  $giftValue -> dwMarketPrice,
                );
			}
			$mapGift[$key] = $vecgift;
		}
		
        return (array(
            'code' => $ret,
            'msg'  =>'',
            'data' => array(
                     'result' => $resp -> result,
                     'MapMainIdGift' => $mapGift,
                     'errmsg' => $resp -> errmsg
                     )
        ));


    }

    /*根据主商品id列表获取单品赠券*/
    public  static function GetSingleProCoupon($stationId,$areaId,$productIds,$uid = 0){
        if($uid == 0 ) {
            $uid = rand(0,1000);
        }

        $vecProduct = new stl_vector();
        $vecProduct->setType('uint32_t');
        $vecProduct->setValue($productIds);

        $mainProduct = new MainProduct();
        $mainProduct->wVersion = 0 ;
        $mainProduct->vecMainProductIdList = $vecProduct;

        $req = new GetPromotionReq;
        $resp = new GetPromotionResp;


        $req->stationId = $stationId;
        $req->areaId = $areaId;
        $req->Mainproduct = $mainProduct;
        $req->type = 1;
        $req->ReserveIn = "";
        $req->machineKey = __FILE__;
        $req->sceneId = 0;


        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        //return (array('resp'=>$resp, 'ret'=>$ret));
		if($ret != 0 ) {
            return array(
                'code' => $ret,
                'msg'  =>'invoke err'
            );
        }
		//进行数据转换
		
		$mapMainCouponinfo = array();
		
		foreach($resp -> promotion as $key => $coupon) {
			$vecCouponinfo = array();
			foreach ( $coupon->vecVecMainIdCoupon -> getValue() as $value ) {
				$couponinfo = array();
				foreach($value ->vecVecCouponInfo ->getValue()  as $Info) {
					$couponinfo[] = array(
                        'version' => $Info -> wVersion,
                        'batch' => $Info ->  dwBatch,
                        'status' => $Info -> nStatus,
					    'name' => $Info -> strName,
					    'amt' => $Info -> nAmt,
                        'validTimeFrom' =>  $Info-> dwValidTimeFrom,
                        'validTimeTo' => $Info -> dwValidTimeTo,
                    );
				}
				$vecCouponinfo[] = array(
                    'version' => $value ->wVersion,
                    'ruleId' => $value -> dwRuleId,
                    'promotionName' => $value -> strPromotionName,
                    'vecCouponInfo' => $couponinfo,
				    'vecPidList' => $value -> vecVecPidList->getValue(),
			        'beginTime' => $value -> dwBeginTime,
				    'endTime' => $value -> dwEndTime,
                    'accountType' => $value -> dwAccountType,
                    'whId' => $value -> dwWhId,
                    'joinLimit' => $value -> dwJoinLimit,
                    'url'  =>  $value -> strUrl,
                    'comment' => $value -> strComment,
                     );
			}
            $mapMainCouponinfo[$key]['version'] = $coupon -> wVersion;
			$mapMainCouponinfo[$key]['vecMainIdCoupon'] = $vecCouponinfo;
		}
	
	
			
        return (array(
            'code' => $ret,
            'msg'  =>'',
            'data' => array(
                     'result' => $resp -> result,
                     'promotion' => $mapMainCouponinfo,
                     'errmsg' => $resp -> errmsg
                     )
        ));
    }
}



class ProductInventoryOperator{

    /*根据商品Id 获取商品信息*/
    public static function GetProductInfo($stationId,$productIds,$uid = 0) {
        if($uid == 0 ) {
            $uid = rand(0,1000);
        }

        $vecProduct = new stl_vector();
        $vecProduct->setType('uint32_t');
        $vecProduct->setValue($productIds);

        $productParam = new ProductParam();
        $productParam->dwVersion = 0 ;
        $productParam->vecProductIdList = $vecProduct;
        $productParam->dwWhId = $stationId;

        $req = new GetProductInfoReq;
        $resp = new GetProductInfoResp;

        $req->productParam = $productParam;
        $req->source = __FILE__;
        $req->reserveIn = "";

        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
       // return (array('resp'=>$resp, 'ret'=>$ret));
        if($ret != 0 ) {
            return array(
                'code' => $ret,
                'msg'  =>'invoke err'
            );
        }
		//进行数据转换
		$productsData = array();
		
		foreach ($resp -> productInfoList->getValue() as $key => $value) {
            $productsData[$key]['version'] = $value ->wVersion;
			$productsData[$key]['productId'] = $key;
            $productsData[$key]['whId'] =  $value -> dwWhId ;
            $productsData[$key]['flag'] =  $value -> nFlag ;
            $productsData[$key]['type'] = $value -> nType ;
            $productsData[$key]['type2'] = $value -> nType2 ;
            $productsData[$key]['status'] = $value -> nStatus ;
            $productsData[$key]['restrictedTransType'] = $value -> nRestrictedTransType ;
            $productsData[$key]['onShelfTime'] = $value -> dwOnShelfTime ;
            $productsData[$key]['promotionWord'] = $value -> strPromotionWord ;
            $productsData[$key]['promotionStart'] = $value -> dwPromotionStart ;
            $productsData[$key]['promotionEnd'] = $value -> dwPromotionEnd ;
            $productsData[$key]['availableNum'] = $value -> nAvailableNum ;
            $productsData[$key]['virtualNum'] = $value -> nVirtualNum ;
            $productsData[$key]['arrivalDays'] = $value -> nArrivalDays ;
            $productsData[$key]['marketPrice'] = $value -> nMarketPrice ;
            $productsData[$key]['price'] = $value -> nPrice ;
            $productsData[$key]['cashBack'] = $value -> nCashBack ;
            $productsData[$key]['costPrice'] = $value -> nCostPrice ;
            $productsData[$key]['numLimit'] = $value -> nNumLimit ;
            $productsData[$key]['isClearWh'] = $value -> nIsClearWh ;
            $productsData[$key]['pointType'] = $value -> nPointType ;
            $productsData[$key]['point'] = $value -> nPoint ;
            $productsData[$key]['vipPrice'] = $value -> strVipPrice ;
            $productsData[$key]['updateTime'] = $value -> dwUpdateTime ;
            $productsData[$key]['psyStock'] = $value -> dwPsyStock ;
            $productsData[$key]['multiPriceType'] = $value -> nMultiPriceType ;
            $productsData[$key]['productSaleType'] = $value -> nProductSaleType ;
            $productsData[$key]['businessUnitCostPrice'] = $value -> nBusinessUnitCostPrice ;
            $productsData[$key]['saleModel'] = $value -> nSaleModel ;
            $productsData[$key]['lowestNum'] = $value -> nLowestNum ;
            $productsData[$key]['bookingType'] = $value -> nBookingType ;
            $productsData[$key]['bookingValue'] = $value -> strBookingValue ;
			$productsData[$key]['c3Ids'] = $value -> strC3Ids;
			$productsData[$key]['productCharId'] =  $value -> strProductCharId;
			$productsData[$key]['mode'] =  $value -> strMode; 
			$productsData[$key]['name'] =  $value -> strName;
			$productsData[$key]['weight'] =  $value -> dwWeight;
			$productsData[$key]['picNum'] =  $value -> dwPicNum;
			$productsData[$key]['barcode'] =   $value -> strBarcode ;
			$productsData[$key]['color'] =   $value -> nColor ;
			$productsData[$key]['productSize'] =  $value -> nProductSize ;
			$productsData[$key]['manufacturer'] = $value -> nManufacturer ;
			$productsData[$key]['warranty'] =  $value -> strWarranty ;
			$productsData[$key]['masterid'] =  $value -> dwMasterid ;
            $productsData[$key]['selleraddressid'] =  $value -> nSellerAddressId ;
            $productsData[$key]['sellerid'] =  $value -> nSellerId ;

		}
			
        return (array(
            'code' => $ret,
            'msg'  =>'',
            'data' => array(
                     'result' => $resp -> result,
                     'productInfoList' => $productsData,
                     'errMsg' => $resp -> errMsg,
                     )
        ));
    }
    /*获取库存*/

    public static function GetInventory($stationId,$areaId,$productIds,$uid = 0){
        if($uid == 0 ) {
            $uid = rand(0,1000);
        }
        $vecProduct = new stl_vector();
        $vecProduct->setType('uint32_t');
        $vecProduct->setValue($productIds);

        $inventoryParam = new InventoryParam();
        $inventoryParam->dwVersion = 0 ;
        $inventoryParam->vecProductIdList = $vecProduct;
        $inventoryParam->dwDistrictId = $areaId;
        $inventoryParam->dwWhId = $stationId;
        $inventoryParam->dwStockId =  $stationId;

        $req = new GetInventeoryInfoReq;
        $resp = new GetInventeoryInfoResp;

        $req->inventoryParam = $inventoryParam;
        $req->source = __FILE__;
        $req->reserveIn = "";


        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        //return (array('resp'=>$resp, 'ret'=>$ret));
		if($ret != 0 ) {
            return array(
                'code' => $ret,
                'msg'  =>'invoke err'
            );
        }
       //进行数据转换
		$inventoryData = array();
		
		foreach ($resp -> inventoryInfoList->getValue() as $key => $value) {
            $inventoryDatap[$key]['version'] = $value-> dwVersion;
			$inventoryData[$key]['productId'] = $value->dwProductId;
			$inventoryData[$key]['saleStockId'] = $value -> dwSaleStockId;
			$inventoryData[$key]['supplyStockId'] =  $value -> dwSupplyStockId;
			$inventoryData[$key]['availableNum'] =  $value -> nAvailableNum; 
			$inventoryData[$key]['virtualNum'] =  $value -> nVirtualNum;
			$inventoryData[$key]['accountNum'] =  $value -> nAccountNum;
		}
			
        return (array(
            'code' => $ret,
            'msg'  =>'',
            'data' => array(
                     'result' => $resp -> result,
                     'inventoryInfoList' => $inventoryData,
                     'errmsg' => $resp -> errMsg
                     )
        ));

    }
}


class StockDCWhOperator{
    //根据仓Id获取站
    public  static function  GetSiteByStock($stockIds,$uid=0) {

		if($uid == 0 ) {
            $uid = rand(0,1000);
        }
        $vecStock = new stl_vector();
        $vecStock->setType('uint32_t');
        $vecStock->setValue($stockIds);



        $req = new GetSiteByStockReq;
        $resp = new GetSiteByStockResp;

        $req->stockId = $vecStock;
        $req->source = __FILE__;


        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        //return (array('resp'=>$resp, 'ret'=>$ret));
		if($ret != 0 ) {
            return array(
                'code' => $ret,
                'msg'  =>'invoke err'
            );
        }
        return (array(
            'code' => $ret,
            'msg'  =>'',
            'data' => array(
                     'result' => $resp -> result,
                     'stockToSite' => $resp->stockToSite->getValue(),
                     'errmsg' => $resp -> errMsg
                     )
        ));
    }
    
	
	// 根据三级地址及分站id，获取对应的DC
    public static function GetDCByDistrictAndSite($district,$siteId,$uid=0) {
       
		if($uid == 0 ) {
            $uid = rand(0,1000);
        }

        $req = new GetDCByDistrictAndSiteReq;
        $resp = new GetDCByDistrictAndSiteResp;

        $req->districtId =  $district;
		$req->siteId =  $siteId;
        $req->source = __FILE__;


        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        //return (array('resp'=>$resp, 'ret'=>$ret));
		if($ret != 0 ) {
            return array(
                'code' => $ret,
                'msg'  =>'invoke err'
            );
        }
        return (array(
            'code' => $ret,
            'msg'  =>'',
            'data' => array(
                     'result' => $resp -> result,
                     'dcId' => $resp->dcId,
                     'errmsg' => $resp -> errMsg
                     )
        ));
    }
}

class ShippingOperator{

    private static function _getShippingParam($inputitems,$inventorys){
        $productList = array();

		$items = array();
        foreach($inputitems as $value) {
            if( !isset($items[$value['product_id']] )) {
                $items[$value['product_id']] = $value;
                $items[$value['product_id']]['price'] = $value['price'] * $value['buy_count'];
            } else {
                $items[$value['product_id']]['price'] += ($value['price'] * $value['buy_count'] ) ;
                $items[$value['product_id']]['buy_count'] += $value['buy_count'] ;
            }
        }

        foreach ($items as $key => $item) {
            
			//库存信息
            $inventoryInfo = new InventoryInfo();
            $productid =  $item['product_id'];
            $inventoryInfo -> dwVersion = $inventorys[ $productid ]['version'];
            $inventoryInfo -> dwProductId = $inventorys[ $productid ]['productId'];
            $inventoryInfo -> dwSaleStockId = $inventorys[ $productid ]['saleStockId'];
            $inventoryInfo -> dwSupplyStockId = $inventorys[ $productid ]['supplyStockId'];
            $inventoryInfo -> nAvailableNum = $inventorys[ $productid ]['availableNum'];
            $inventoryInfo -> nVirtualNum = $inventorys[$productid ]['virtualNum'];
            $inventoryInfo -> nAccountNum = $inventorys[ $productid ]['accountNum'];

            //赠品信息

            $arrGiftInfo = array();
            foreach($item['gift'] as $giftid => $giftvalue ) {
                $giftinfo =  new GiftInfo4Shipping();
                $giftinfo -> dwVersion = 1;
                $giftinfo -> dwGiftWeight = $giftvalue['weight'];
                $giftinfo -> dwStockNum = $giftvalue['stock_num'];
                $giftinfo -> dwGiftNum = $giftvalue['num'];

                $giftUnitPo = new ProductUnitPo();
                $giftUnitPo -> ddwProductSysno = $giftid;
                $giftUnitPo -> cProductSysno_u = 1;
                $giftUnitPo -> dwProductNum = $giftvalue['num'];
                $giftUnitPo -> cProductNum_u = 1;
                $giftUnitPo -> dwProductWeight = $giftvalue['weight'];
                $giftUnitPo ->cProductWeight_u = 1;
                $giftinfo -> oSizeInfo = $giftUnitPo;
                $giftinfo -> cSizeInfo_u = 1;

                $arrGiftInfo[] = $giftinfo;
            }

            $vecGiftInfo = new stl_vector();
            $vecGiftInfo->setType(GiftInfo4Shipping);
            $vecGiftInfo->setValue($arrGiftInfo);

            $shippParam = new ShippingParam();
            $shippParam -> dwVersion = 1;
            $shippParam -> cVersion_u = 1;
            $shippParam -> dwProductId = $productid;
            $shippParam -> cProductId_u = 1;
            $shippParam -> dwBookingType = $item['booking_type'];
            $shippParam -> cBookingType_u = 1;
            if(ICSON_BOOKING_TYPE_SPECIFIC_DATE == $item['booking_type']) { //这种情况下booking_value为日期的字符串
                $shippParam -> dwBookingValue = strtotime($item['booking_value']);
            } else {
                $shippParam -> dwBookingValue = $item['booking_value'];
            }
            $shippParam -> cBookingValue_u = 1;
           
            if($item['restricted_trans_type'] > 0) {
				$shippParam -> dwRestrictedTransType = $item['restricted_trans_type'];
                $shippParam -> cRestrictedTransType_u = 1;
            }
            $shippParam -> oInventoryInfo = $inventoryInfo; //库存信息的填充
            $shippParam -> cInventoryInfo_u = 1;
            $shippParam -> dwSellerId = $item['seller_id']; //卖家的id
            $shippParam -> cSellerId_u = 1;
            $shippParam -> dwSellerStockId  = $item['seller_address_id'];
            $shippParam -> cSellerStockId_u = 1;
            $shippParam -> dwFlag = $item['flag'];
            $shippParam -> dwPrice = $item['price'];
            $shippParam -> dwWeight = $item['weight'];
            $shippParam -> dwBuyCount = $item['buy_count'];
            $shippParam -> cBuyCount_u = 1;
            $shippParam -> dwCashBack = $item['cash_back'];
            $shippParam -> dwC3Ids = $item['c3_ids'];
            $shippParam -> vecGiftList = $vecGiftInfo; //赠品的信息
            $shippParam -> dwType = $item['type'];
            $shippParam -> cType_u = 1;

            $productUnitPo = new ProductUnitPo();
            $productUnitPo -> ddwProductSysno = $productid;
            $productUnitPo -> cProductSysno_u = 1;
            $productUnitPo -> dwProductNum = $item['buy_count'];
            $productUnitPo -> cProductNum_u = 1;
            $productUnitPo -> dwProductWeight = $item['weight'];
            $productUnitPo -> cProductWeight_u = 1;
            $shippParam -> oSizeInfo = $productUnitPo;
            $shippParam -> cSizeInfo_u = 1;

            $productList[$productid] = $shippParam;
        }


        $mapProduct = new stl_map();
        $mapProduct->setType(uint32_t,ShippingParam);
        $mapProduct->setValue($productList);
        return $mapProduct;
    }

    public static function getShippingforOrder($whId,$destinationId,$dc,$items,$inventorys,$couponPrice=0,$uid =0,$userLevel=0,$sceneId = 0){
        if (0 == $uid) {
            $uid = rand(0,1000);
        }
        $req = new getShippingInfo4OrderReq;
        $resp = new getShippingInfo4OrderResp;
       // Map < uint32_t, ShippingParam > productList;


        $mapProduct = self::_getShippingParam($items,$inventorys);
        $mapExt = new stl_map();
        $mapExt->setType(string,string);
        $mapExt -> setValue( array() );

        $req -> whId = $whId;
        $req -> destination = $destinationId;
        $req -> dc = $dc ;
        $req -> userLevel =  $userLevel;
        $req -> productList = $mapProduct;
        $req -> couponPrice = $couponPrice;
        $req -> extIn = $mapExt;
        $req -> sceneId = $sceneId;
        $req -> source = __FILE__;
        $req -> machineKey = __FILE__;
        $req -> ReserveIn = '';
      // print_r($req);
       // Logger::info("getshippinginfo  req ===". print_r($req,true));
        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
       // print_r("getshippingOrder\n");
        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }

    public static function getShippingOrsforOrder($whId,$destinationId,$dc,$items,$inventorys,$couponPrice=0,$uid =0,$userLevel=0,$sceneId = 0, $isOrder = "0"){
        if (0 == $uid) {
            $uid = rand(0,1000);
        }
        $req = new getShippingOrsOrdersReq;
        $resp = new getShippingOrsOrdersResp;


        $mapProduct = self::_getShippingParam($items,$inventorys);
        $mapExt = new stl_map();
        $mapExt->setType(string,string);
        $mapExt -> setValue( array("isPlaceOrder" => $isOrder) );
        $req -> whId = $whId;
        $req -> destination = $destinationId;
        $req -> dc = $dc ;
        $req -> userLevel =  $userLevel;
        $req -> userId =  $uid;
        $req -> productList = $mapProduct;
        $req -> couponPrice = $couponPrice;
        $req -> extIn = $mapExt;
        $req -> sceneId = $sceneId;
        $req -> source = __FILE__;
        $req -> machineKey = __FILE__;
        $req -> ReserveIn = '';
        $cntl = WebCntl::initCntl($uid);
        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        //Logger::info("-------------" .print_r($resp, true));
        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }

    public static function getShippingforCart($whId,$destinationId,$dc,$inputitems,$inventorys,$uid =0,$userLevel=0,$sceneId = 0){
        if (0 == $uid) {
            $uid = rand(0,1000);
        }
        $req = new getShippingInfo4CartReq;
        $resp = new getShippingInfo4CartResp;


        // Map < uint32_t, ShippingParam > productList;
        $arrShippSmallParam = array();
		
		$items = array();
        foreach($inputitems as $value) {
            if( !isset($items[$value['product_id']] )) {
                $items[$value['product_id']] = $value;
                $items[$value['product_id']]['price'] = $value['price'] * $value['buy_count'];
            } else {
                $items[$value['product_id']]['price'] += ($value['price'] * $value['buy_count'] ) ;
                $items[$value['product_id']]['buy_count'] += $value['buy_count'] ;
            }
        }
        foreach ($items as $key => $item) {

            $productid =  $item['product_id'];
            //库存信息
            //库存信息
            $inventoryInfo = new InventoryInfo();
            $inventoryInfo -> dwVersion = $inventorys[$productid]['version'];
            $inventoryInfo -> dwProductId = $inventorys[$productid]['productId'];
            $inventoryInfo -> dwSaleStockId = $inventorys[$productid]['saleStockId'];
            $inventoryInfo -> dwSupplyStockId = $inventorys[$productid]['supplyStockId'];
            $inventoryInfo -> nAvailableNum = $inventorys[$productid]['availableNum'];
            $inventoryInfo -> nVirtualNum = $inventorys[$productid]['virtualNum'];
            $inventoryInfo -> nAccountNum = $inventorys[$productid]['accountNum'];




            $ShippSmallParam = new ShippingSmallParam();

            $ShippSmallParam -> dwVersion = 1;
            $ShippSmallParam -> cVersion_u = 1;
            $ShippSmallParam -> dwProductId = $productid ;
            $ShippSmallParam -> cProductId_u = 1;
            $ShippSmallParam -> dwSellerId = $item['seller_id'];
            $ShippSmallParam -> cSellerId_u = 1;
            $ShippSmallParam -> dwBookingType = $item['booking_type'];
            $ShippSmallParam -> cBookingType_u = 1;
            if(ICSON_BOOKING_TYPE_SPECIFIC_DATE == $item['booking_type']) { //这种情况下booking_value为日期的字符串
                $ShippSmallParam -> dwBookingValue = strtotime($item['booking_value']);
            } else {
                $ShippSmallParam -> dwBookingValue = $item['booking_value'];
            }
            $ShippSmallParam -> cBookingValue_u = 1;
            
            if($item['restricted_trans_type'] > 0) {
				$ShippSmallParam -> dwRestrictedTransType = $item['restricted_trans_type'];
                $ShippSmallParam -> cRestrictedTransType_u = 1;
            }

            $ShippSmallParam -> dwBuyCount = $item['buy_count'];
            $ShippSmallParam -> cBuyCount_u = 1;
            $ShippSmallParam -> oInventoryInfo = $inventoryInfo; //库存信息的填充
            $ShippSmallParam -> cInventoryInfo_u = 1;

            $ShippSmallParam -> dwFlag = $item['flag'];
            $ShippSmallParam -> cFlag_u = 1;
            $ShippSmallParam -> dwType = $item['type'];
            $ShippSmallParam -> cType_u = 1;

            $arrShippSmallParam[$productid ] = $ShippSmallParam;
        }


        $mapShippingParam = new stl_map();
        $mapShippingParam -> setType(uint32_t,ShippingSmallParam);
        $mapShippingParam -> setValue($arrShippSmallParam);

        $mapExt = new stl_map();
        $mapExt->setType(string,string);
        $mapExt -> setValue( array() );


        $req-> whId = $whId;
        $req -> shippingParamList = $mapShippingParam;
        $req -> destination = $destinationId;
        $req -> dc = $dc ;
        $req -> extIn = $mapExt;
        $req -> sceneId = $sceneId;
        $req -> source = __FILE__;
        $req -> machineKey = __FILE__;
        $req -> ReserveIn = '';

       // Logger::info("for cart === ".json_encode($req));
        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        //  print_r($resp);
        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }


    public static function getShippingforPlaceOrder($whId,$destinationId,$dc,$items,$inventorys,$orderPrice=0,$uid =0,$userLevel=0,$sceneId = 0, $isOrder = "0") {
        if (0 == $uid) {
            $uid = rand(0,1000);
        }
        $req = new getShippingInfo4PlaceOrderReq;
        $resp = new getShippingInfo4PlaceOrderResp;

        // Map < uint32_t, ShippingParam > productList;
        $mapProduct =self:: _getShippingParam($items,$inventorys);

        $mapExt = new stl_map();
        $mapExt->setType(string,string);
        $mapExt -> setValue( array("isPlaceOrder" => $isOrder) );
        $req -> whId = $whId;
        $req -> destination = $destinationId;
        $req -> dc = $dc ;
        $req -> userLevel =  $userLevel;
        $req -> productList = $mapProduct;
        $req -> orderPrice = $orderPrice;
        $req -> extIn = $mapExt;
        $req -> sceneId = $sceneId;
        $req -> source = __FILE__;
        $req -> machineKey = __FILE__;
        $req -> ReserveIn = '';
      //  print_r($req);


        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        //print_r("getshipping4PlaceOrder\n");
        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }


    public static function getShippingPack($whId,$destinationId,$dc,$items,$inventorys,$orderPrice=0,$uid =0,$sceneId = 0) {
        if (0 == $uid) {
            $uid = rand(0,1000);
        }
        $req = new getPackagesReq;
        $resp = new getPackagesResp;

        // Map < uint32_t, ShippingParam > productList;

        $mapProduct = self::_getShippingParam($items,$inventorys);

        $mapExt = new stl_map();
        $mapExt->setType(string,string);
        $mapExt -> setValue( array() );

        $req -> whId = $whId;
        $req -> destination = $destinationId;
        $req -> dc = $dc ;
        $req -> productList = $mapProduct;
        $req -> extIn = $mapExt;
        $req -> sceneId = $sceneId;
        $req -> source = __FILE__;
        $req -> machineKey = __FILE__;
        $req -> ReserveIn = '';
        // print_r($req);



        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        $json_resp = json_encode($resp);

        //print_r("getshippingPackage\n");
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }
}


class TyingOperator{

    //将输入的item转换为以MainProductId 为key的数组 这里是否要剔除掉套餐数据
    private static function _getmapMain($inputItems) {
        $mapitem = array();
        $matchitem = array();
        foreach($inputItems as $item) {
            if( ($item['main_product_id'] >0 ) && ($item['package_id'] == 0) ) {
                $findflag =0;
                $mainproduct = $item['main_product_id'] ;
                foreach($inputItems as $value ) {
                    //剔除掉套餐添加进来的商品
                    if( ($mainproduct == $value['product_id']) && ($value['package_id'] == 0) ) {
                        $findflag = 1;
                        if( !array_key_exists( $mainproduct , $mapitem ) ) {
                            $mapitem[$mainproduct]['product_id'] = $mainproduct;
                            $mapitem[$mainproduct]['type'] = 0; //普通商品的类型
                            $mapitem[$mainproduct]['buy_count'] =  $value['buy_count'];
                            $mapitem[$mainproduct]['prodcut'] = array();
                        }

                        break;

                    }
                }
                if( 0 == $findflag ) {
                    continue;
                }
                $product = $item['product_id'] ;
                if( array_key_exists( $mainproduct , $mapitem ) ) {
                    if( array_key_exists( $product , $mapitem[$mainproduct]['prodcut'] ) ) {
                        // 这里处理是否合理？
                        $mapitem[$mainproduct]['product'][$product]['buy_count'] =  $mapitem[$mainproduct][$product]['buy_count'] + $item['buy_count'];
                    } else {
                        $mapitem[$mainproduct]['product'][$product] =  $item;
                    }
                    $matchitem[$product] = 1;
                } else {
                    $mapitem[$mainproduct]['product'][$product] =  $item;
                }
                $matchitem[$mainproduct] = 1;
            }
        }
        //这里将没有添加到这个列表中的所有其他商品也进行添加.
        foreach($inputItems as $value) {
            if( !array_key_exists($value['product_id'] , $matchitem)) {
                if($value['package_id'] == 0 ) {
                    $mapitem[$value['product_id']]['type'] = 0; //普通商品的类型
                    $mapitem[$value['product_id']]['buy_count'] = $value['buy_count'];
                    $mapitem[$value['product_id']]['product_id'] = $value['product_id'];
                    $mapitem[$value['product_id']]['product'] = array();

                }
            }
        }
        return $mapitem;
    }



    private static function _getInputTogetherSell($inputitems){
        $mapItem =self::_getmapMain($inputitems);

        //组装入参
        $inputParam = new CheckTogetherSellParamBo;

        //stl_vector
        $vecSellCheck = new  stl_vector();
        $SellCheck = array();
        foreach($mapItem as $key => $item) {

            $vecRulesChecked = new stl_vector();
            $arrRule = array();
            foreach($item['product'] as $id => $it) {
                $rule = new TogetherSellCheckRuleBo;
                $rule -> dwVersion = 0;
                $rule -> cVersion_u = 1;
                $rule -> dwSubProductId = $id;
                $rule -> cSubProductId_u = 1;
                $rule -> dwBuyNum = $it['buy_count'];
                $rule -> cBuyNum_u = 1;
                $rule -> dwRuleType = 1; //1 表示随心配
                $rule -> cRuleType_u = 1;
                $arrRule[] = $rule;
            }
            $vecRulesChecked ->setValue($arrRule);

            $sellbo = new TogetherSellCheckBo;
            $sellbo -> dwVersion = 0;
            $sellbo -> cVersion_u = 1;
            $sellbo -> dwType = $item['type'];  //商品类型
            $sellbo -> cType_u = 1;
            $sellbo -> dwMainProductId = $key;
            $sellbo -> cMainProductId_u = 1;
            $sellbo -> dwMainBuyNum = $item['buy_count'];
            $sellbo -> cMainBuyNum_u = 1;

            $sellbo ->vecRulesChecked = $vecRulesChecked;
            $sellbo -> cRulesChecked_u = 1;
            $SellCheck[] = $sellbo;
        }
        $vecSellCheck -> setValue($SellCheck);


        $inputParam -> vecTogetherSellCheckVec = $vecSellCheck;
        $inputParam -> cTogetherSellCheckVec_u =1;
        $inputParam -> dwVersion = 0 ;
        $inputParam -> cVersion_u = 1;
        return $inputParam;
    }

    public static function GetTying($inputitems,$whId,$desinationId,$uid=0) {
        if (0 == $uid) {
            $uid = rand(0,1000);
        }

        $req = new CheckTogetherSellReq;
        $resp = new CheckTogetherSellResp;
        $inputParam = self::_getInputTogetherSell($inputitems);
        $req -> machineKey = __FILE__;
        $req -> source = __FILE__;
        $req -> sceneId = 1000000;  //与服务提供方协商采用设个sceneId 目前无特殊含义2013-05-17 hedyhe
        $req -> whId = $whId;
        $req -> regionId = $desinationId;
        $req -> Uid = $uid;
        $req -> checkParam = $inputParam;
        $req -> ReserveIn = "";

        $cntl = WebCntl::initCntl($uid);
        $json_req = json_encode($req);
       // print_r(json_decode($json_req,true));
        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }

}

class UniInventoryOperator{
    private static function _parameterHash($fixupInfoPo)
    {
        $paraHash  = $fixupInfoPo->ddwProductSysno . "|";
        $paraHash .= $fixupInfoPo->ddwStockSysno . "|";
        $paraHash .= $fixupInfoPo->ddwOrderToken . "|";
        $paraHash .= $fixupInfoPo->ddwOrderSequence . "|";
        $paraHash .= $fixupInfoPo->ddwOrderSysno . "|";
        $paraHash .= $fixupInfoPo->ddwUserNo . "|";
        $paraHash .= "0|";
        $paraHash .= $fixupInfoPo->dwOrderDecreasedNum . "|";
        $paraHash .= "0|0|0|0|";

        return $paraHash;
    }
    private static function _parameterFactory($uid, $modifyType, $inventroyData)
    {
        Logger::info("_parameterFactory ==". ToolUtil::gbJsonEncode($inventroyData));
        $fixupInfoPo = new OmsFixupInfoPo();
        $fixupInfoPo->dwVersion = 0;
        $fixupInfoPo->cVersion_u = 1;
        $fixupInfoPo->ddwProductSysno = $inventroyData['product_id'];
        $fixupInfoPo->cProductSysno_u = 1;
        $fixupInfoPo->ddwStockSysno = $inventroyData['sys_stock'];
        $fixupInfoPo->cStockSysno_u = 1;
        $fixupInfoPo->ddwOrderToken = $inventroyData['order_id'];
        $fixupInfoPo->cOrderToken_u = 1;
        $fixupInfoPo->ddwOrderSequence = $inventroyData['order_creat_time'];
        $fixupInfoPo->cOrderSequence_u = 1;
        $fixupInfoPo->ddwOrderSysno = $inventroyData['order_id'];
        $fixupInfoPo->cOrderSysno_u = 1;
        $fixupInfoPo->ddwUserNo = $uid;
        $fixupInfoPo->cUserNo_u = 1;
        $fixupInfoPo->ddwPlatform = 1;
        $fixupInfoPo->cPlatform_u = 1;
        $fixupInfoPo->dwOrderDecreasedNum = $inventroyData['buy_count'];
        $fixupInfoPo->cOrderDecreasedNum_u = 1;
        $fixupInfoPo->dwOrderSource = 7;
        $fixupInfoPo->cOrderSource_u = 1;
        $fixupInfoPo->dwOrderType = $inventroyData['order_type'];
        $fixupInfoPo->cOrderType_u = 1;
        $fixupInfoPo->strFixupHash = self::_parameterHash($fixupInfoPo);

        $event4AppPo = new Event4AppPo();
        $event4AppPo->dwVersion = 0;
        $event4AppPo->cVersion_u = 1;
        $event4AppPo->ddwEventId = $inventroyData['order_id'];
        $event4AppPo->cEventId_u = 1;
        $event4AppPo->dwEventType = 1;
        $event4AppPo->cEventId_u = 1;
        $event4AppPo->dwEventSourceId = 1;
        $event4AppPo->cEventSourceId_u = 1;
        $event4AppPo->dwEventModifyType = $modifyType;
        $event4AppPo->cEventModifyType_u = 1;
        $event4AppPo->dwEventCreateTime = $inventroyData['order_creat_time'];
        $event4AppPo->cEventCreateTime_u = 1;
        $event4AppPo->dwEventExcuteTime = time();
        $event4AppPo->cEventExcuteTime_u = 1;
        $event4AppPo->strOperatorId = $uid;
        $event4AppPo->cOperatorId_u = 1;
        $event4AppPo->dwOperatorClientIp = ToolUtil::getClientIP();
        $event4AppPo->cOperatorClientIp_u = 1;

        Logger::info("_parameterFactory" . ToolUtil::gbJsonEncode($fixupInfoPo));
        Logger::info("_parameterFactory111" . ToolUtil::gbJsonEncode($event4AppPo));
        return array(
            'fixupInfoPo' => $fixupInfoPo,
            'event4AppPo' => $event4AppPo,
        );
    }

    /**
     * 统一库存后台调用接口--库存锁定
     * @param $uid                  用户UID
     * @param $inventroyData        库存锁定相关信息
     * @return array
     */
    public static function LockProductInventory($uid, $inventroyData)
    {
        IShoppingProcess::Log("LockProductInventory Start: " . ToolUtil::gbJsonEncode($inventroyData), true, "uniinventory");
        $req = new LockProductReq;
        $resp = new LockProductResp;
        $inputPara = self::_parameterFactory($uid, 1, $inventroyData);
        $req -> machineKey = __FILE__;
        $req -> source = __FILE__;
        $req -> sceneId = SHOPPING_PROCESS_INVENTORY_SCENE_ID;
        $req -> lockType = 0;                           //非活动库存锁定填0
        $req -> fixupInfoPo = $inputPara['fixupInfoPo'];
        $req -> eventPo = $inputPara['event4AppPo'];

        //IShoppingProcess::Log("LockProductInventory req: " . ToolUtil::gbJsonEncode($req));
        $cntl = WebCntl::initCntl($uid);
        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        IShoppingProcess::Log("LockProductInventory Finish: [ret:{$ret}]" . ToolUtil::gbJsonEncode($resp), true, "uniinventory");
        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }

    /**
     * 统一库存后台调用接口--库存解锁
     * @param $uid                      用户UID
     * @param $inventroyData            库存锁定相关信息
     * @return array
     */
    public static function UnlockProductInventory($uid, $inventroyData)
    {
        IShoppingProcess::Log("UnlockProductInventory Start: " . ToolUtil::gbJsonEncode($inventroyData), true, "uniinventory");
        $req = new UnlockProductReq;
        $resp = new UnlockProductResp;

        $inputPara = self::_parameterFactory($uid, 2, $inventroyData);
        $req -> machineKey = __FILE__;
        $req -> source = __FILE__;
        $req -> sceneId = SHOPPING_PROCESS_INVENTORY_SCENE_ID;
        $req -> fixupInfoPo = $inputPara['fixupInfoPo'];
        $req -> eventPo = $inputPara['event4AppPo'];

        $cntl = WebCntl::initCntl($uid);
        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        IShoppingProcess::Log("UnlockProductInventory Finish: [ret:{$ret}]" . ToolUtil::gbJsonEncode($resp), true, "uniinventory");
        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }
}
class PayTypeOperator{

    //根据所有可用的支付方式信息
    public static function GetAllPayTypeInfo($shippingType, $wh_id = 1, $productidArr = array(), $userType = false, $cartType = 0, $uid = 0) {
        if($uid == 0 ) {
            $uid = rand(0,1000);
        }

        $vecProduct = new stl_vector();
        $vecProduct->setType('uint32_t');
        $vecProduct->setValue($productidArr);

        $payTypeParam = new PayTypeParam();
        $payTypeParam->dwVersion = 0;

        $payTypeParam->dwShipTypeId = $shippingType;
        $payTypeParam->cShipTypeId_u = 1;
        $payTypeParam->dwWhId = $wh_id;
        $payTypeParam->cWhId_u = 1;
        $payTypeParam->dwUid = $uid;
        $payTypeParam->cUid_u = 1;
        $payTypeParam->strUserType = $userType;
        $payTypeParam->cUserType_u = 1;
        $payTypeParam->dwCartType = $cartType;
        $payTypeParam->cCartType_u = 1;
        $payTypeParam->vecProductIdList = $vecProduct;
        $payTypeParam->cProductIdList_u = 1;

        $req = new GetAllPayTypeInfoReq;
        $resp = new GetAllPayTypeInfoResp;

        $req->payTypeParam = $payTypeParam;
        $req->source = __FILE__;
        $req->reserveIn = "";

        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }

    //根据指定的支付方式信息
    public static function GetPayTypeInfo($payTypeId, $shippingType, $whId = 1, $productidArr = array(), $userType = false, $cartType = 0, $uid = 0) {
        if($uid == 0 ) {
            $uid = rand(0,1000);
        }

        $vecProduct = new stl_vector();
        $vecProduct->setType('uint32_t');
        $vecProduct->setValue($productidArr);

        $payTypeParam = new PayTypeParam();
        $payTypeParam->dwVersion = 0;

        $payTypeParam->dwPayTypeId = $payTypeId;
        $payTypeParam->cPayTypeId_u = 1;

        $payTypeParam->dwShipTypeId = $shippingType;
        $payTypeParam->cShipTypeId_u = 1;
        $payTypeParam->dwWhId = $whId;
        $payTypeParam->cWhId_u = 1;
        $payTypeParam->dwUid = $uid;
        $payTypeParam->cUid_u = 1;
        $payTypeParam->strUserType = $userType;
        $payTypeParam->cUserType_u = 1;
        $payTypeParam->dwCartType = $cartType;
        $payTypeParam->cCartType_u = 1;
        $payTypeParam->vecProductIdList = $vecProduct;
        $payTypeParam->cProductIdList_u = 1;

        $req = new GetPayTypeInfoReq;
        $resp = new GetPayTypeInfoResp;

        $req->payTypeParam = $payTypeParam;
        $req->source = __FILE__;
        $req->reserveIn = "";

        $cntl = WebCntl::initCntl($uid);

        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }
}

class PointOperator{
    public static function GetUserPoints($uid)
    {
        $req = new GetPointsAccountReq();
        $resp = new GetPointsAccountResp();

        $req->source = __FILE__;
        $req->machineKey = ToolUtil::getClientIP();
        $req->sceneId = 0;
        $req->icsonUid = $uid;
        $cntl = WebCntl::initCntl($uid);
        $ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);

        $json_resp = json_encode($resp);
        return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
    }
}

class SkuViewOperator{
	/**
	* 获取商品信息--调用商品系统AO
	* @param $productIds	商品id数组
	* @param $whId			分站ID
	* @param $areaId		国标地域ID
	* @param $uid 			用户uid
	* @return array
	*/
	public static function GetSkuListInfo4ShopCart($productIds, $whId, $areaId = 0, $uid = 0)
	{
		if($uid == 0 ) {
            $uid = rand(0,1000);
        }
		
		$skuListFilterArr = array();
		foreach ($productIds as $pid)
		{
			$skuFilterPo = new ViewSkuFilterPo();
			
			$skuFilterPo->dwVersion = 0;
			$skuFilterPo->cVersion_u = 1;
			$skuFilterPo->strCommodityId = "icson-".$pid;
			$skuFilterPo->cCommodityId_u = 1;
			
			$skuListFilterArr[] = $skuFilterPo;
		}
		
		$skuListFilter = new stl_vector();
        $skuListFilter->setType('ViewSkuFilterPo');
        $skuListFilter->setValue($skuListFilterArr);
		
		$req = new FetchSkuListInfo4ShopCartReq;
        $resp = new FetchSkuListInfo4ShopCartResp;
		
		$req->machineKey = "shopcart";
		$req->source = __FILE__;
		$req->sceneId = 0x8001;

		$req->skuListFilter = $skuListFilter;
		$req->areaId = $areaId;
		
		$cntl = WebCntl::initCntl($uid);
		
		$ret = $cntl->invoke($req, $resp, WEB_STUB_TIME_OUT);
		
		if($ret != 0) {
            return array(
                'ret'	=> $ret,
                'resp'	=> 'invoke err',
            );
        }
		
		$json_resp = json_encode($resp);
		return array(
            'ret' => $ret,
            'resp' => json_decode($json_resp,true),
        );
	}
}

