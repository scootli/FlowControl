<?php

//source idl: com.icson.commoditypoolmanage.idl.commodityPoolManageAo.java


class CommodityInfoBO
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 商品池ID
		 *
		 * 版本 >= 0
		 */
		var $dwPoolID; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cPoolID_u; //uint8_t

		/**
		 * 期数编号，从1开始
		 *
		 * 版本 >= 0
		 */
		var $dwTermNumber; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cTermNumber_u; //uint8_t

		/**
		 * 商品id
		 *
		 * 版本 >= 0
		 */
		var $strCommodityId; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cCommodityId_u; //uint8_t

		/**
		 * 商品数据，key-value格式，可实现按需更新，key为商品表字段
		 *
		 * 版本 >= 0
		 */
		var $mapCommodityData; //std::map<std::string,std::string> 

		/**
		 * 版本 >= 0
		 */
		var $cCommodityData_u; //uint8_t

		/**
		 * 操作结果，0代表无误
		 *
		 * 版本 >= 0
		 */
		var $dwErrCode; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cErrCode_u; //uint8_t

		/**
		 * 操作错误信息
		 *
		 * 版本 >= 0
		 */
		var $strErrMsg; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cErrMsg_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->cVersion_u = 0; // uint8_t
			 $this->dwPoolID = 0; // uint32_t
			 $this->cPoolID_u = 0; // uint8_t
			 $this->dwTermNumber = 0; // uint32_t
			 $this->cTermNumber_u = 0; // uint8_t
			 $this->strCommodityId = ""; // std::string
			 $this->cCommodityId_u = 0; // uint8_t
			 $this->mapCommodityData = new stl_map('stl_string,stl_string'); // std::map<std::string,std::string> 
			 $this->cCommodityData_u = 0; // uint8_t
			 $this->dwErrCode = 0; // uint32_t
			 $this->cErrCode_u = 0; // uint8_t
			 $this->strErrMsg = ""; // std::string
			 $this->cErrMsg_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwPoolID); // 序列化商品池ID 类型为uint32_t
			$bs->pushUint8_t($this->cPoolID_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwTermNumber); // 序列化期数编号，从1开始 类型为uint32_t
			$bs->pushUint8_t($this->cTermNumber_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strCommodityId); // 序列化商品id 类型为std::string
			$bs->pushUint8_t($this->cCommodityId_u); // 序列化 类型为uint8_t
			$bs->pushObject($this->mapCommodityData, 'stl_map'); // 序列化商品数据，key-value格式，可实现按需更新，key为商品表字段 类型为std::map<std::string,std::string> 
			$bs->pushUint8_t($this->cCommodityData_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwErrCode); // 序列化操作结果，0代表无误 类型为uint32_t
			$bs->pushUint8_t($this->cErrCode_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strErrMsg); // 序列化操作错误信息 类型为std::string
			$bs->pushUint8_t($this->cErrMsg_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwPoolID = $bs->popUint32_t(); // 反序列化商品池ID 类型为uint32_t
			$this->cPoolID_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwTermNumber = $bs->popUint32_t(); // 反序列化期数编号，从1开始 类型为uint32_t
			$this->cTermNumber_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strCommodityId = $bs->popString(); // 反序列化商品id 类型为std::string
			$this->cCommodityId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->mapCommodityData = $bs->popObject('stl_map<stl_string,stl_string> '); // 反序列化商品数据，key-value格式，可实现按需更新，key为商品表字段 类型为std::map<std::string,std::string> 
			$this->cCommodityData_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwErrCode = $bs->popUint32_t(); // 反序列化操作结果，0代表无误 类型为uint32_t
			$this->cErrCode_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strErrMsg = $bs->popString(); // 反序列化操作错误信息 类型为std::string
			$this->cErrMsg_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}


//source idl: com.icson.commoditypoolmanage.idl.commodityPoolManageAo.java


class CommodityPoolInfoBO
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 商品池ID
		 *
		 * 版本 >= 0
		 */
		var $dwPoolID; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cPoolID_u; //uint8_t

		/**
		 * 商品池名称
		 *
		 * 版本 >= 0
		 */
		var $strPoolName; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cPoolName_u; //uint8_t

		/**
		 * 商品池类型：0-常规,4-素材
		 *
		 * 版本 >= 0
		 */
		var $cPoolType; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cPoolType_u; //uint8_t

		/**
		 * 商品池分类
		 *
		 * 版本 >= 0
		 */
		var $dwFolderId; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $dwFolderId_u; //uint32_t

		/**
		 * 排序字段
		 *
		 * 版本 >= 0
		 */
		var $strOrderField; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cOrderField_u; //uint8_t

		/**
		 * 排序方向，0升序1降序
		 *
		 * 版本 >= 0
		 */
		var $cOrderDir; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cOrderDir_u; //uint8_t

		/**
		 * 是否系统内建（非人工创建）商品池
		 *
		 * 版本 >= 0
		 */
		var $cBuiltIn; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cBuiltIn_u; //uint8_t

		/**
		 * 策略类型：0-无,1-bi,2-a/b test
		 *
		 * 版本 >= 0
		 */
		var $cStrategy; //uint8_t

		/**
		 * 版本 >= 0
		 */
		var $cStrategy_u; //uint8_t

		/**
		 * 当前期，从1开始
		 *
		 * 版本 >= 0
		 */
		var $dwCurrentTerm; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cCurrentTerm_u; //uint8_t

		/**
		 * 分仓id，wsid
		 *
		 * 版本 >= 0
		 */
		var $dwSiteArea; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cSiteArea_u; //uint8_t

		/**
		 * 商品池的运营相关人员名字，用分号隔开，以便快速找到跟进人，亦可用于告警等机制
		 *
		 * 版本 >= 0
		 */
		var $strRelatedUser; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cRelatedUser_u; //uint8_t

		/**
		 * 商品池描述
		 *
		 * 版本 >= 0
		 */
		var $strDescription; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cDescription_u; //uint8_t

		/**
		 * 扩展数据
		 *
		 * 版本 >= 0
		 */
		var $strExtData; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cExtData_u; //uint8_t

		/**
		 * 扩展表单数据类型
		 *
		 * 版本 >= 0
		 */
		var $strCustomDataList; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cCustomDataList_u; //uint8_t

		/**
		 * bit属性
		 *
		 * 版本 >= 0
		 */
		var $bitsetBitProperty; //std::bitset<32> 

		/**
		 * 版本 >= 0
		 */
		var $cBitProperty_u; //uint8_t

		/**
		 * 期数列表
		 *
		 * 版本 >= 0
		 */
		var $vecTermList; //std::vector<icson::commoditypoolmanage::bo::CCommodityTermInfoBO> 

		/**
		 * 版本 >= 0
		 */
		var $cTermList_u; //uint8_t

		/**
		 * 操作结果，0代表无误
		 *
		 * 版本 >= 0
		 */
		var $dwErrCode; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cErrCode_u; //uint8_t

		/**
		 * 操作错误信息
		 *
		 * 版本 >= 0
		 */
		var $strErrMsg; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cErrMsg_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->cVersion_u = 0; // uint8_t
			 $this->dwPoolID = 0; // uint32_t
			 $this->cPoolID_u = 0; // uint8_t
			 $this->strPoolName = ""; // std::string
			 $this->cPoolName_u = 0; // uint8_t
			 $this->cPoolType = 0; // uint8_t
			 $this->cPoolType_u = 0; // uint8_t
			 $this->dwFolderId = 0; // uint32_t
			 $this->dwFolderId_u = 0; // uint32_t
			 $this->strOrderField = ""; // std::string
			 $this->cOrderField_u = 0; // uint8_t
			 $this->cOrderDir = 0; // uint8_t
			 $this->cOrderDir_u = 0; // uint8_t
			 $this->cBuiltIn = 0; // uint8_t
			 $this->cBuiltIn_u = 0; // uint8_t
			 $this->cStrategy = 0; // uint8_t
			 $this->cStrategy_u = 0; // uint8_t
			 $this->dwCurrentTerm = 0; // uint32_t
			 $this->cCurrentTerm_u = 0; // uint8_t
			 $this->dwSiteArea = 0; // uint32_t
			 $this->cSiteArea_u = 0; // uint8_t
			 $this->strRelatedUser = ""; // std::string
			 $this->cRelatedUser_u = 0; // uint8_t
			 $this->strDescription = ""; // std::string
			 $this->cDescription_u = 0; // uint8_t
			 $this->strExtData = ""; // std::string
			 $this->cExtData_u = 0; // uint8_t
			 $this->strCustomDataList = ""; // std::string
			 $this->cCustomDataList_u = 0; // uint8_t
			 $this->bitsetBitProperty = new stl_bitset('32'); // std::bitset<32> 
			 $this->cBitProperty_u = 0; // uint8_t
			 $this->vecTermList = new stl_vector('CommodityTermInfoBO'); // std::vector<icson::commoditypoolmanage::bo::CCommodityTermInfoBO> 
			 $this->cTermList_u = 0; // uint8_t
			 $this->dwErrCode = 0; // uint32_t
			 $this->cErrCode_u = 0; // uint8_t
			 $this->strErrMsg = ""; // std::string
			 $this->cErrMsg_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwPoolID); // 序列化商品池ID 类型为uint32_t
			$bs->pushUint8_t($this->cPoolID_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strPoolName); // 序列化商品池名称 类型为std::string
			$bs->pushUint8_t($this->cPoolName_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cPoolType); // 序列化商品池类型：0-常规,4-素材 类型为uint8_t
			$bs->pushUint8_t($this->cPoolType_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwFolderId); // 序列化商品池分类 类型为uint32_t
			$bs->pushUint32_t($this->dwFolderId_u); // 序列化 类型为uint32_t
			$bs->pushString($this->strOrderField); // 序列化排序字段 类型为std::string
			$bs->pushUint8_t($this->cOrderField_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cOrderDir); // 序列化排序方向，0升序1降序 类型为uint8_t
			$bs->pushUint8_t($this->cOrderDir_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cBuiltIn); // 序列化是否系统内建（非人工创建）商品池 类型为uint8_t
			$bs->pushUint8_t($this->cBuiltIn_u); // 序列化 类型为uint8_t
			$bs->pushUint8_t($this->cStrategy); // 序列化策略类型：0-无,1-bi,2-a/b test 类型为uint8_t
			$bs->pushUint8_t($this->cStrategy_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwCurrentTerm); // 序列化当前期，从1开始 类型为uint32_t
			$bs->pushUint8_t($this->cCurrentTerm_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwSiteArea); // 序列化分仓id，wsid 类型为uint32_t
			$bs->pushUint8_t($this->cSiteArea_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strRelatedUser); // 序列化商品池的运营相关人员名字，用分号隔开，以便快速找到跟进人，亦可用于告警等机制 类型为std::string
			$bs->pushUint8_t($this->cRelatedUser_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strDescription); // 序列化商品池描述 类型为std::string
			$bs->pushUint8_t($this->cDescription_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strExtData); // 序列化扩展数据 类型为std::string
			$bs->pushUint8_t($this->cExtData_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strCustomDataList); // 序列化扩展表单数据类型 类型为std::string
			$bs->pushUint8_t($this->cCustomDataList_u); // 序列化 类型为uint8_t
			$bs->pushObject($this->bitsetBitProperty, 'stl_bitset'); // 序列化bit属性 类型为std::bitset<32> 
			$bs->pushUint8_t($this->cBitProperty_u); // 序列化 类型为uint8_t
			$bs->pushObject($this->vecTermList, 'stl_vector'); // 序列化期数列表 类型为std::vector<icson::commoditypoolmanage::bo::CCommodityTermInfoBO> 
			$bs->pushUint8_t($this->cTermList_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwErrCode); // 序列化操作结果，0代表无误 类型为uint32_t
			$bs->pushUint8_t($this->cErrCode_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strErrMsg); // 序列化操作错误信息 类型为std::string
			$bs->pushUint8_t($this->cErrMsg_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwPoolID = $bs->popUint32_t(); // 反序列化商品池ID 类型为uint32_t
			$this->cPoolID_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strPoolName = $bs->popString(); // 反序列化商品池名称 类型为std::string
			$this->cPoolName_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cPoolType = $bs->popUint8_t(); // 反序列化商品池类型：0-常规,4-素材 类型为uint8_t
			$this->cPoolType_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwFolderId = $bs->popUint32_t(); // 反序列化商品池分类 类型为uint32_t
			$this->dwFolderId_u = $bs->popUint32_t(); // 反序列化 类型为uint32_t
			$this->strOrderField = $bs->popString(); // 反序列化排序字段 类型为std::string
			$this->cOrderField_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cOrderDir = $bs->popUint8_t(); // 反序列化排序方向，0升序1降序 类型为uint8_t
			$this->cOrderDir_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cBuiltIn = $bs->popUint8_t(); // 反序列化是否系统内建（非人工创建）商品池 类型为uint8_t
			$this->cBuiltIn_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->cStrategy = $bs->popUint8_t(); // 反序列化策略类型：0-无,1-bi,2-a/b test 类型为uint8_t
			$this->cStrategy_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwCurrentTerm = $bs->popUint32_t(); // 反序列化当前期，从1开始 类型为uint32_t
			$this->cCurrentTerm_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwSiteArea = $bs->popUint32_t(); // 反序列化分仓id，wsid 类型为uint32_t
			$this->cSiteArea_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strRelatedUser = $bs->popString(); // 反序列化商品池的运营相关人员名字，用分号隔开，以便快速找到跟进人，亦可用于告警等机制 类型为std::string
			$this->cRelatedUser_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strDescription = $bs->popString(); // 反序列化商品池描述 类型为std::string
			$this->cDescription_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strExtData = $bs->popString(); // 反序列化扩展数据 类型为std::string
			$this->cExtData_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strCustomDataList = $bs->popString(); // 反序列化扩展表单数据类型 类型为std::string
			$this->cCustomDataList_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->bitsetBitProperty = $bs->popObject('stl_bitset<32> '); // 反序列化bit属性 类型为std::bitset<32> 
			$this->cBitProperty_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->vecTermList = $bs->popObject('stl_vector<CommodityTermInfoBO> '); // 反序列化期数列表 类型为std::vector<icson::commoditypoolmanage::bo::CCommodityTermInfoBO> 
			$this->cTermList_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwErrCode = $bs->popUint32_t(); // 反序列化操作结果，0代表无误 类型为uint32_t
			$this->cErrCode_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strErrMsg = $bs->popString(); // 反序列化操作错误信息 类型为std::string
			$this->cErrMsg_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}


//source idl: com.icson.commoditypoolmanage.idl.commodityPoolManageAo.java


class CommodityTermInfoBO
{
		/**
		 * 版本号
		 *
		 * 版本 >= 0
		 */
		var $dwVersion; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cVersion_u; //uint8_t

		/**
		 * 商品池ID
		 *
		 * 版本 >= 0
		 */
		var $dwPoolID; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cPoolID_u; //uint8_t

		/**
		 * 期数编号，从1开始
		 *
		 * 版本 >= 0
		 */
		var $dwTermNumber; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cTermNumber_u; //uint8_t

		/**
		 * 外部系统期数id，与外部系统映射时需用到
		 *
		 * 版本 >= 0
		 */
		var $dwTmsSourceId; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cTmsSourceId_u; //uint8_t

		/**
		 * 期数名
		 *
		 * 版本 >= 0
		 */
		var $strTermName; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cTermName_u; //uint8_t

		/**
		 * 描述
		 *
		 * 版本 >= 0
		 */
		var $strDescription; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cDescription_u; //uint8_t

		/**
		 * 备注
		 *
		 * 版本 >= 0
		 */
		var $strRemarks; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cRemarks_u; //uint8_t

		/**
		 * 期数开始时间，格式为YmdHis
		 *
		 * 版本 >= 0
		 */
		var $ddwBeginTime; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cBeginTime_u; //uint8_t

		/**
		 * 期数结束时间，格式为YmdHis
		 *
		 * 版本 >= 0
		 */
		var $ddwEndTime; //uint64_t

		/**
		 * 版本 >= 0
		 */
		var $cEndTime_u; //uint8_t

		/**
		 * 操作结果，0代表无误
		 *
		 * 版本 >= 0
		 */
		var $dwErrCode; //uint32_t

		/**
		 * 版本 >= 0
		 */
		var $cErrCode_u; //uint8_t

		/**
		 * 操作错误信息
		 *
		 * 版本 >= 0
		 */
		var $strErrMsg; //std::string

		/**
		 * 版本 >= 0
		 */
		var $cErrMsg_u; //uint8_t


		 function __construct() {
			 $this->dwVersion = 0; // uint32_t
			 $this->cVersion_u = 0; // uint8_t
			 $this->dwPoolID = 0; // uint32_t
			 $this->cPoolID_u = 0; // uint8_t
			 $this->dwTermNumber = 0; // uint32_t
			 $this->cTermNumber_u = 0; // uint8_t
			 $this->dwTmsSourceId = 0; // uint32_t
			 $this->cTmsSourceId_u = 0; // uint8_t
			 $this->strTermName = ""; // std::string
			 $this->cTermName_u = 0; // uint8_t
			 $this->strDescription = ""; // std::string
			 $this->cDescription_u = 0; // uint8_t
			 $this->strRemarks = ""; // std::string
			 $this->cRemarks_u = 0; // uint8_t
			 $this->ddwBeginTime = 0; // uint64_t
			 $this->cBeginTime_u = 0; // uint8_t
			 $this->ddwEndTime = 0; // uint64_t
			 $this->cEndTime_u = 0; // uint8_t
			 $this->dwErrCode = 0; // uint32_t
			 $this->cErrCode_u = 0; // uint8_t
			 $this->strErrMsg = ""; // std::string
			 $this->cErrMsg_u = 0; // uint8_t
		}

		 function serialize($bs) {
			$bs->pushUint32_t($this->getClassLen());
			$this->serialize_internal($bs);
		}

		 function serialize_internal($bs) {
			$bs->pushUint32_t($this->dwVersion); // 序列化版本号 类型为uint32_t
			$bs->pushUint8_t($this->cVersion_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwPoolID); // 序列化商品池ID 类型为uint32_t
			$bs->pushUint8_t($this->cPoolID_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwTermNumber); // 序列化期数编号，从1开始 类型为uint32_t
			$bs->pushUint8_t($this->cTermNumber_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwTmsSourceId); // 序列化外部系统期数id，与外部系统映射时需用到 类型为uint32_t
			$bs->pushUint8_t($this->cTmsSourceId_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strTermName); // 序列化期数名 类型为std::string
			$bs->pushUint8_t($this->cTermName_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strDescription); // 序列化描述 类型为std::string
			$bs->pushUint8_t($this->cDescription_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strRemarks); // 序列化备注 类型为std::string
			$bs->pushUint8_t($this->cRemarks_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwBeginTime); // 序列化期数开始时间，格式为YmdHis 类型为uint64_t
			$bs->pushUint8_t($this->cBeginTime_u); // 序列化 类型为uint8_t
			$bs->pushUint64_t($this->ddwEndTime); // 序列化期数结束时间，格式为YmdHis 类型为uint64_t
			$bs->pushUint8_t($this->cEndTime_u); // 序列化 类型为uint8_t
			$bs->pushUint32_t($this->dwErrCode); // 序列化操作结果，0代表无误 类型为uint32_t
			$bs->pushUint8_t($this->cErrCode_u); // 序列化 类型为uint8_t
			$bs->pushString($this->strErrMsg); // 序列化操作错误信息 类型为std::string
			$bs->pushUint8_t($this->cErrMsg_u); // 序列化 类型为uint8_t
		}

		 function unserialize($bs) {
			$class_len = $bs->popUint32_t();
			$startPop = $bs->getReadLength();
			$this->dwVersion = $bs->popUint32_t(); // 反序列化版本号 类型为uint32_t
			$this->cVersion_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwPoolID = $bs->popUint32_t(); // 反序列化商品池ID 类型为uint32_t
			$this->cPoolID_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwTermNumber = $bs->popUint32_t(); // 反序列化期数编号，从1开始 类型为uint32_t
			$this->cTermNumber_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwTmsSourceId = $bs->popUint32_t(); // 反序列化外部系统期数id，与外部系统映射时需用到 类型为uint32_t
			$this->cTmsSourceId_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strTermName = $bs->popString(); // 反序列化期数名 类型为std::string
			$this->cTermName_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strDescription = $bs->popString(); // 反序列化描述 类型为std::string
			$this->cDescription_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strRemarks = $bs->popString(); // 反序列化备注 类型为std::string
			$this->cRemarks_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwBeginTime = $bs->popUint64_t(); // 反序列化期数开始时间，格式为YmdHis 类型为uint64_t
			$this->cBeginTime_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->ddwEndTime = $bs->popUint64_t(); // 反序列化期数结束时间，格式为YmdHis 类型为uint64_t
			$this->cEndTime_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->dwErrCode = $bs->popUint32_t(); // 反序列化操作结果，0代表无误 类型为uint32_t
			$this->cErrCode_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t
			$this->strErrMsg = $bs->popString(); // 反序列化操作错误信息 类型为std::string
			$this->cErrMsg_u = $bs->popUint8_t(); // 反序列化 类型为uint8_t

			/**********************为了支持多个版本的客户端************************/
			$needPopLen = $class_len - ($bs->getReadLength() - $startPop);
			for ($idx=0; $idx<$needPopLen; $idx++) {
				$bs->popUint8_t();
			}
			/**********************为了支持多个版本的客户端************************/
			

			return $this;
		}

		 function getClassLen() {
			$len_bs = new ByteStream();
			$len_bs->setRealWrite(false);
			$this->serialize_internal($len_bs);
			$class_len = $len_bs->getWrittenLength();

			return $class_len;
		}

}

?>