<?php
/**
 *
 * @author: pengfei
 */
require_once("/data/release/PHPLIB/lib/Config.php");

$key_maps = array(
	"max_use_times" => "max_use_degree",
	"category" => "category_coll",
	"productids" => "product_coll",
	"manufactory" => "manufactory_coll",
	"user_grade" => "user_grade_coll",
	"wh_id" => "area_coll"
	);

class ICouponBatchUpdater{
	public static $errMsg;
	public static $errCode;

	public static function add_task($batch_info)
	{
		if(!$batch_info)
		{
			self::$errMsg = "batch_info is null";
			return false;
		}

		$batchno = $batch_info['batch'];

		if( isset($batch_info['valid_time_from']) && $batch_info['valid_time_from'] < 0)
		{
			self::$errMsg = "valid_time_from ({$batch_info['valid_time_from']}) is illegal";
			return false;
		}

		if( isset($batch_info['valid_time_to']) && $batch_info['valid_time_to'] < 0)
		{
			self::$errMsg = "valid_time_to ({$batch_info['valid_time_to']}) is illegal";
			return false;
		}

		$ret = IDataCache::getData('COUPON_UPDATE_BATCH_INFO');
		if($ret === false) {
			if(IDataCache::$errCode === IDataCache::ERROR_NO_DATA || IDataCache::$errCode === IDataCache::ERROR_KEY_EXPIRED) {
				$batches = array();
			} else {
				self::$errMsg = "Getting data to cmem failed";
				return false;
			}
		} else {
			$batches = unserialize($ret);
		}
		
		if($batches)
		{
			// merge existing task
			$merge =  false;
			foreach ($batches as &$batch) {
				if($batch['batch'] == $batchno)
				{
					$merge = true;
					foreach($batch_info as $key => $value)
					{
						$batch["$key"] = $value;
					}
				}
			}

			// if not merge, add it
			if(!$merge)
			{
				$batches[] = $batch_info;
			}
		}
		else
		{
			$batches = array();
			$batches[] = $batch_info;
		}
		
		$ret = IDataCache::setData('COUPON_UPDATE_BATCH_INFO', serialize($batches));
		if($ret === false) {
			self::$errMsg = "Saving data to cmem failed";
			return false;
		}

		return true;
	}

	// update batch info from CMEM
	public static function update()
	{

		$ret = IDataCache::getData('COUPON_UPDATE_BATCH_INFO');
		if($ret === false) {
			if(IDataCache::$errCode === IDataCache::ERROR_NO_DATA || IDataCache::$errCode === IDataCache::ERROR_KEY_EXPIRED) {
				$batches = array();
			} else {
				self::$errMsg = "Getting data to cmem failed";
				return false;
			}
		} else {
			$batches = unserialize($ret);
		}
		
		foreach ($batches as $batch) {
			if(false == self::update_coupon_info($batch))
			{
				return false;
			}
		}
		
		// check if data changed
		$ret = IDataCache::getData('COUPON_UPDATE_BATCH_INFO');
		if($ret === false) {
			if(IDataCache::$errCode === IDataCache::ERROR_NO_DATA || IDataCache::$errCode === IDataCache::ERROR_KEY_EXPIRED) {
				$batches = array();
			} else {
				self::$errMsg = "Getting data to cmem failed";
				return false;
			}
		} else {
			$batches2 = unserialize($ret);
		}
		$diff = array_diff($batches2, $batches);
		$ret = IDataCache::setData('COUPON_UPDATE_BATCH_INFO', serialize($diff));
		if($ret === false) {
			self::$errMsg = "Saving data to cmem failed";
			return false;
		}

		return true;
	}

	public static function update_batch_info($batch_info)
	{
		if(!$batch_info)
		{
			self::$errMsg = "batch_info is null";
			return false;
		}

		$batchno = $batch_info['batch'];
		unset($batch_info['batch']);

		if(isset($batch_info['coupon_amt']) || isset($batch_info['sale_amt']))
		{
			self::$errMsg = "coupon_amt and sale_amt can't be updated";
			return false;
		}

		$msDB = ToolUtil::getMSDBObj('ICSON_CORE');
		if (false === $msDB)
		{
			self::$errCode = Config::$errCode;
			self::$errMsg = Config::$errMsg;
			return false;
		}

		$sql = "select * from t_coupon_resource where batch={$batchno}";
		$batch_resource = $msDB->getRows($sql);
		if (false === $batch_resource)
		{
			self::$errCode = $msDB->errCode;
			self::$errMsg = $msDB->errMsg;
			return false;
		}
		
		// check t_coupon_resource first
		if(count($batch_resource) == 0)
		{
			self::$errMsg = "batch number $batchno doesn't exist";
			return false;
		}

		// update t_coupon_resource now
		$sql = 'UPDATE t_coupon_resource SET ';
		foreach($batch_info as $key=>$value)
		{
			if($key == "coupon_name")
			{
				$sql .=  "$key='$value',";
			}
			else 
			{
				$sql .=  "$key=$value,";
			}
			
		}
		$sql.='rowModifyDate=' . time() . '  WHERE batch=' . $batchno;
		$ret = $msDB->execSql($sql);
		if (false === $ret) {
			self::$errCode = $msDB->errCode; 
			self::$errMsg =  $msDB->errMsg;
			return  false;
		}

		return true;
	}

	// update batch info by param batch_info
	public static function update_coupon_info($batch_info)
	{
		if(!$batch_info)
		{
			self::$errMsg = "batch_info is null";
			return false;
		}

		$batchno = $batch_info['batch'];
		unset($batch_info['batch']);

		if(isset($batch_info['coupon_amt']) || isset($batch_info['sale_amt']))
		{
			self::$errMsg = "coupon_amt and sale_amt can't be updated";
			return false;
		}

		$msDB = ToolUtil::getMSDBObj('ICSON_CORE');
		if (false === $msDB)
		{
			self::$errCode = Config::$errCode;
			self::$errMsg = Config::$errMsg;
			return false;
		}

		$sql = "select * from t_coupon_resource where batch=$batchno";
		$batch_resource = $msDB->getRows($sql);
		if (false === $batch_resource)
		{
			self::$errCode = $msDB->errCode;
			self::$errMsg = $msDB->errMsg;
			return false;
		}
		
		// check t_coupon_resource first
		if(count($batch_resource) == 0)
		{
			self::$errMsg = "batch number $batchno doesn't exist";
			return false;
		}

		$dbtab_coupon = ToolUtil::getDBNumAndTableNum('coupon');
		for($i = 0; $i < $dbtab_coupon['dbnum']; ++$i)
		{
			$mysql_dbCoupon = ToolUtil::getDBObj('coupon', $i);
			if(empty($mysql_dbCoupon) || false === $mysql_dbCoupon)
			{
				self::$errMsg = ToolUtil::$errMsg ;
				return false;
			}

			for($j = 0; $j < $dbtab_coupon['tabnum']; ++$j)
			{
				$table_coupon = ToolUtil::getDBTableName('coupon', $j);

				$sql = "select coupon_code,valid_time_from,valid_time_to from $table_coupon where batchno = $batchno";
				$couponsInfo = $mysql_dbCoupon->getRows($sql);
				if(false === $couponsInfo)
				{
					self::$errMsg = $mysql_dbCoupon->errMsg;
					return false;
				}

				if(count($couponsInfo) == 0)
				{
					continue;
				}


				foreach($couponsInfo as $coupon)
				{
					// TODO: update now
					$up_info = array( 'coupon_code' => $coupon['coupon_code']);
					foreach($batch_info as $key => $value)
					{
						if("valid_time_from" == $key)
						{
							$up_info["valid_time_from"]=($value>10000)?$value:($value-$batch_resource)*24*3600+$coupon['valid_time_from'];
						}
						elseif("valid_time_to" == $key)
						{
							$up_info["valid_time_to"]=($value>10000)?$value:($value-$batch_resource)*24*3600+$coupon['valid_time_to'];
						}
						elseif(isset($key_maps[$key]))
						{
							$up_info[$key_maps[$key]] = $value;
						}else
						{
							$up_info[$key]=$value;
						}
					}

					$ret = ICouponTTC::update($up_info); // TODO: or update db and purge TTC ?
					if (false === $ret) {
						self::$errCode = ICouponTTC::$errCode;
						self::$errMsg = ICouponTTC::$errMsg;
						return false;
					}
				}
			}
		} // END coupon dbnum

		return true;
	} // END update_coupon_info
}

