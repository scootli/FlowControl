<?php
/* desc   : �������л������ļ�
** author : hongbinyao
** date   : 2013-07-11
*/
if (!defined("PHPLIB_ROOT")) {
	define('PHPLIB_ROOT', '/data/release/PHPLIB/');
}
require_once(PHPLIB_ROOT . "lib/Config.php");

class DealInGray{
	public static function ifInGray($uid){
		$readSwitch = 1;//Ĭ��Ϊ�������Ҷ�
		$modBool = false;
		@$icsonDealReadSwitch = explode (':', configcenter4_get_serv("IcsonDealReadSwitch", 0, 0) );
		@$readSwitch = $icsonDealReadSwitch[1];//1�������Ҷȡ�2ȡģ�ҶȺͰ�������3ȫ��
		if(readSwitch == 3){//ȫ��
			return true;
		}else if(readSwitch == 2){//ȡģ�ҶȺͰ�����
			$modNum = 0;
			$equNum = 0;
			@$icsonLoginMod=explode (':', configcenter4_get_serv("IcsonDealReadMod", 0, 0) );
			@$modNum = $icsonLoginMod[1];
			// if($modNum != 1){
				// @$icsonLoginEqu=explode (':', configcenter4_get_serv("IcsonDealReadEqu", 0, 0) );
				// @$equNum = $icsonLoginEqu[1];
				// $modBool = ($uid%$modNum == $equNum);
			// }
			$modBool = ($uid%$modNum == $equNum);
		}
		$grayUidArr = array();
		$environment = Config::getEnvName();
		switch ($environment){
			case 'dev.':
				global $devUidArr;
				// $grayUidArr = array(30566559,30566558,30566570,30566322);
				$grayUidArr = array(30566559,30566183,30566571);
				break;
			case 'test55.':
				global $betaUidArr;
				$grayUidArr = array(106728029,106728943,106728749,106729018,106728999,106728968,106729008,106729022,106729023,106728775,106728441,106729035,106729034);
				break;
			case 'beta.':
				global $gammaUidArr;
				$grayUidArr = array(206148795,4393386,193703306,176962539,192023164,207174920,207915010,207950603,207950855,25232596,8661902,206746710,416883381);
				break;
			default:
				global $idcUidArr;
				$grayUidArr = array(198176676,5341499,4306069,91941045,175846745,195883265,17418995,196902649,690054,193703306,4393386,207915010,59680989,177836835,207830009,25232596,8661902,206746710,416883381);
				break;
		}

		$inGray = in_array($uid, $grayUidArr) || $modBool;
		// echo "modNum:".$modNum.",equNum:".$equNum;
		return $inGray;
	}
}
?>
