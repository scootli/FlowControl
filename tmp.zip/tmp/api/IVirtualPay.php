<?php 
require_once(PHPLIB_ROOT . 'inc/virtualPayType.inc.php');
/**
 * �����ֵ
 * @author robinguo
 * @version 1.0
 * @updated 22-����-2012 15:56:54
 */

//�������ֻ����룬ͬ��ʧ�ܴ����������ޱ���
define('VP_DEV_MOBILE',						'18605898269');
//������Ա�ֻ����룬����澯
define('VP_FINANCIAL_MOBILE',				'13761774309');
 

define('VP_PAIPAI_API_URL',					'http://api.paipai.com');
define('VP_PAIPAI_MOBILE_SUBMIT_URL',		'/vb2c/vsaleMobileSubmit.xhtml');
define('VP_PAIPAI_MOBILE_QUERY_URL',		'/vb2c/vsaleMobileQuery.xhtml');

define('VP_PAIPAI_UID',						'2285038846');
define('VP_PAIPAI_SPID',					'29230000ea03aa00684f800af261b662');
define('VP_PAIPAI_TOKEN',					'feec32880f27aa00684fcc8688730ccf');
define('VP_PAIPAI_SECRETKEY',				'0x8n9obe5rw1u8w6gd8hxcwa58kzqx9w');


define("VP_REQUEST_LIMIT_TIMECOUNT",		"300");//����apiƽ̨��������ÿ5����1000�� 
define("VP_REQUEST_LIMIT",					"1000");//����apiƽ̨��������ÿ5����1000��

//���ⶩ������
define('VP_ORDER_TYPE_MOBILE',				'1');//�ֻ���ֵ
define('VP_ORDER_TYPE_QQ',					'2');//Q��
define('VP_ORDER_TYPE_GAME',				'3');//���ζ���

$_VP_Order_Type = array(
	VP_ORDER_TYPE_MOBILE 	=> '�ֻ���ֵ',
    VP_ORDER_TYPE_QQ 		=> 'Q��',
	VP_ORDER_TYPE_GAME		=> '����'
);  

//����ͬ����־λ
define('VP_ORDER_SYN_YES',					'1');//��Ҫͬ��
define('VP_ORDER_SYN_NO',					'0');//����Ҫͬ��
define('VP_ORDER_SYN_ALERT_LIMIT',			'20');//ͬ��ʧ�ܱ�������
 



//����״̬
define('VP_STATUS_INVALID',					'-1');//������
define('VP_STATUS_INIT',					'0');//��ʼ����δ֧��
define('VP_STATUS_USERPAID',				'1');//�û���֧����δ��ֵ
define('VP_STATUS_ICSONPAY_SUCCESS',		'2');//��Ѹ�˻��ѿۿ�ɹ�
define('VP_STATUS_ICSONPAY_FAIL',			'3');//��Ѹ�˻��ۿ�ʧ��
define('VP_STATUS_ONCHARGE',				'4');//��ֵ��
define('VP_STATUS_SUCCESS',					'5');//��ֵ�ɹ�
define('VP_STATUS_CHARGE_FAIL',				'6');//��ֵʧ��
define('VP_STATUS_ICSONPAY_REFUND',			'7');//��Ѹ�˻��˿���
define('VP_STATUS_ICSONPAY_REFUND_SUCCESS',	'8');//��Ѹ�˻��˿�ɹ�
define('VP_STATUS_USER_REFUND_SUCCESS',		'9');//�û��˻��˿�ɹ�(��ֹ״̬)

//���Ĳඩ��״̬ 
define('VP_PAIPAI_STATUS_INIT',					'1');//���������ɹ���֧���� ��Ӧ VP_STATUS_USERPAID
define('VP_PAIPAI_STATUS_INVAID',				'7');//������ȡ��(ԭ��:֧��ʧ��) ��Ӧ VP_STATUS_ICSONPAY_FAIL
define('VP_PAIPAI_STATUS_ICSONPAY_TELSEND',		'2');//�µ���֧���ɹ���֪ͨ������ ��Ӧ VP_STATUS_ICSONPAY_SUCCESS
define('VP_PAIPAI_STATUS_ICSONPAY_ONSEND',		'3');//����������(˵��:֧���ɹ������ڷ���) ��Ӧ VP_STATUS_ONCHARGE
define('VP_PAIPAI_STATUS_CHARGE_FAIL',			'4');//�����˿���(˵��:֧���ɹ�����ֵʧ��) ��Ӧ VP_STATUS_CHARGE_FAIL 
																							//VP_STATUS_ICSONPAY_REFUND
define('VP_PAIPAI_STATUS_REFUND_SUCCESS',		'6');//�������˿�(˵��:֧���ɹ�����ֵʧ��) ��Ӧ VP_STATUS_ICSONPAY_REFUND_SUCCESS
define('VP_PAIPAI_STATUS_CHARGE_SUCCESS',		'5');//�����ѳ�ֵ����(˵��:֧���ɹ�����ֵ�ɹ�) ��Ӧ VP_STATUS_SUCCESS

//�ֻ���ֵ����״̬ [0]Ϊ�û���չʾ״̬ [1]Ϊ��վ��̨չʾ״̬
$_VP_MobileOrderState = array(	
	VP_STATUS_INVALID => 				array('������','������'),
	VP_STATUS_INIT => 					array('��֧��','��ʼ����δ֧��'),
	VP_STATUS_USERPAID => 				array('��ֵ��','�û���֧����δ��ֵ'),
	VP_STATUS_ICSONPAY_SUCCESS => 		array('��ֵ��','��Ѹ�˻��ۿ�ɹ�'),
	VP_STATUS_ICSONPAY_FAIL =>	 		array('��ֵʧ���˿�','��Ѹ�˻��ۿ�ʧ��'),
	VP_STATUS_ONCHARGE => 				array('��ֵ��','��ֵ��'),
	VP_STATUS_SUCCESS => 				array('��ֵ�ɹ�','��ֵ�ɹ�'),
	VP_STATUS_CHARGE_FAIL => 			array('��ֵʧ���˿�','��ֵʧ��'),
	VP_STATUS_ICSONPAY_REFUND => 		array('��ֵʧ���˿�','��Ѹ�˻��˿���'),
	VP_STATUS_ICSONPAY_REFUND_SUCCESS =>array('��ֵʧ���˿�','��Ѹ�˻��˿�ɹ�'),
	VP_STATUS_USER_REFUND_SUCCESS => 	array('���˿�','�û��˻��˿�ɹ�')
);

$_LS_SALESMAN = array(
    '--android--' => 888888,
	'--mobile--' => 666666,
	'--iphone--' => 999999
);


class IVirtualPay
{
	public static $dbName ='ICSON_CORE'; 
	public static $tableName = 't_virtualpay_order';
	public static $old_TableName = 't_virtualpay_order_old';
	public static $priceTableName = 't_virtualpay_price';
	
	public static $ERPDBName ='ERP_1';
	public static $ERPSoDBName = 'SO';
	public static $ERPFinanceDBName = 'Icson_Finance';
	public static $ERPflowTableName = 'SOFinance_VirtualPay';
	
	/**
	 * ������
	 */
	public static $errCode = 0;
	/**
	 * ������Ϣ
	 */
	public static $errMsg = '';
 
	/**
	 * ��������֧����������ֻ֧���ֻ�������д������Ԥ��
	 * 
	 * @param array newOrder = array(
			'uid'			=> XXX,
			'payType' 		=> XXX,
			'type' 			=> XXX,
			'targetId' 		=> XXX,
			'chargeMoney' 	=> XXX,
			'payMoney' 		=> XXX,
			'hasPaidMoney' 	=> XXX,
			'operator' 		=> XXX,
			'area' 			=> XXX, 
			'desc' 			=> XXX

		)	 
		��ȷ���� array('errCode' => 0, 'errMsg' => array('order_char_id' => ������,
													   'payType' => ֧����ʽ,
													   'targetId' => ��ֵ�ʺ�));
		���󷵻� array('errCode' => ������, 'errMsg' => '������Ϣ');
	 */  
	public static function createOrder($newOrder)
	{	
		// ITIL�ϱ�
		itil_report(635182); 
		//У������ 
		if (!is_array($newOrder) || empty($newOrder)) {
			// ITIL�ϱ�
			itil_report(635208);
		
			self::$errCode = -2000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "newOrder is empty";
			Logger::err(self::$errMsg);
			return array('errNo' => -2000, 'errMsg' => '��������Ϊ��!');
		}

		if (!isset($newOrder['uid']) || $newOrder['uid'] <= 0) {
			// ITIL�ϱ�
			itil_report(635208);

			self::$errCode = -2001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "newOrder[uid] is empty";
			Logger::err(self::$errMsg);
			return array('errNo' => -2001, 'errMsg' => '�û�idΪ��!');
		}
		
		//����ֵ��Ϣ
		if (false === self::_checkChargeInfo($newOrder)) {
			// ITIL�ϱ�
			itil_report(635208);

			return false;
		}
		
		//���֧����ʽ
		if (false === self::_checkPayType($newOrder)) {
			// ITIL�ϱ�
			itil_report(635208);

			return false;
		}
		
		if(VP_ORDER_TYPE_MOBILE == $newOrder['type'])
		{
			return self::_createMobileOrder($newOrder);
		}
		// ITIL�ϱ�
		itil_report(635208);
		return array('errNo' => 11, 'errMsg' => '��ֵ���Ͳ���ȷ!');
	}
	
	/**
	 * ��ȡһ���¶���id
	 * 
	 * ��ȷ���ض����ţ����󷵻�false
	 */
	private static function _newOrderId()
	{
		$newId = IIdGenerator::getNewId('so_sequence');
		if (false === $newId || $newId <= 0) {
			self::$errCode = IIdGenerator::$errCode;
			self::$errMsg = IIdGenerator::$errMsg;
			return  false;
		} 
		return $newId;
	}
	

	/**
	 * ���֧������
	 * ���붩����Ϣ array(
						'payType' 		=> XXX,
					);
	 
	 * ��ȷ����true ���󷵻�false
	 */	
	private static function _checkPayType(&$newOrder)
	{ 
		global $_PAY_MODE;  
		$payType = $_PAY_MODE[1];
		
		if (!isset($newOrder['payType']) || !isset($payType[$newOrder['payType']])) {
			self::$errCode = -2002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "֧����ʽ����ȷ";
			Logger::err(self::$errMsg);
			return false;
		}

		if ($payType[$newOrder['payType']]['IsOnlineShow'] == 0) {
			self::$errCode = -2003;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "��������֧����ʽ";
			Logger::err(self::$errMsg);
			return false;
		} 
		return true;
	}
	
	/**
	 * ����ֵ��Ϣ�Ϸ���
	 * 
	 * ���붩����Ϣ
	 
		��ȷ����true ���󷵻�false
	 */	
	private static function _checkChargeInfo(&$newOrder)
	{
		global $_VP_Card_Price;
		global $_VP_Card_Category;
		//����ֵ�ʺ�
		
		//���uid
		$userInfo = IUsersTTC::get($newOrder['uid'],array());
		if (!is_array($userInfo)) { 
			self::$errCode = -2004;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "�û�id����ȷ!";
			Logger::err(self::$errMsg);
			return false;
		}
		
		if(VP_ORDER_TYPE_MOBILE == $newOrder['type'])
		{//�ֻ���ֵ  
			$mobileRegExp = '/^((\(\d{3}\))|(\d{3}\-))?1\d{10}$/';
			//�����Ӫ�̺͵�����ֵ��ֵ��ֵ���
			if(!isset($_VP_Card_Price[$newOrder['operator']]))
			{
				self::$errCode = -2005;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "��Ӫ����Ϣ����ȷ";
				Logger::err(self::$errMsg);
				return false;			
			}
			else if(!isset($_VP_Card_Category[$newOrder['chargeMoney']][1]) || $_VP_Card_Category[$newOrder['chargeMoney']][1] != $newOrder['productId'])
			{
				self::$errCode = -2006;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "��ֵ����Ʒid����ȷ";
				Logger::err(self::$errMsg);
				return false;			
			}
			else if(!isset($_VP_Card_Price[$newOrder['operator']][$newOrder['area']]))
			{
				self::$errCode = -2007;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "��ֵ������ȷ";
				Logger::err(self::$errMsg);
				return false;			
			}
			else if(!isset($_VP_Card_Price[$newOrder['operator']][$newOrder['area']][$newOrder['chargeMoney']]))
			{
				self::$errCode = -2008;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "��ֵ����ȷ";
				Logger::err(self::$errMsg);
				return false;			
			}
			else if($_VP_Card_Price[$newOrder['operator']][$newOrder['area']][$newOrder['chargeMoney']] != $newOrder['payMoney'])
			{
				self::$errCode = -2009;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "֧������ȷ";
				Logger::err(self::$errMsg);
				return false;			
			}			
			
			//����ֻ���
			if(!preg_match($mobileRegExp,$newOrder['targetId']))
			{
				self::$errCode = -2010;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "��ֵ���벻��ȷ";
				Logger::err(self::$errMsg);
				return false;				
			}		
		} 
		return true;
	}
	
	/**
	 * �����ֻ������ֵ����
	 * 
		��ȷ����true ���󷵻�false
	 */
	private static function _createMobileOrder(&$newOrder)
	{
		
		//���ɶ���id
		$orderId = self::_newOrderId();
		if(false === $orderId)
		{	
			// ITIL�ϱ�
			itil_report(635208);
			self::$errCode = -3001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "��ȡ������ʧ��";
			Logger::error(__FILE__ . '.php' . '|' . __LINE__ . " ��ȡ������ʧ��" . self::$errCode . '|' . self::$errMsg);
			return false;
		}

		$soitemID = IIdGenerator::getNewId('So_Item_Sequence');
		$financeSysNo = IIdGenerator::getNewId('Finance_NetPay_sequence');
		
		global $_LS_SALESMAN;
		//���붩�����ݿ�
		$order = array();
		$order['uid'] = $newOrder['uid']; 
		$order['orderId'] = $orderId;
		$order['order_char_id'] = sprintf("%s%09d", "1", $orderId % 1000000000);
		$order['payType'] = $newOrder['payType'];
		$order['type'] = $newOrder['type'];
		$order['targetId'] = $newOrder['targetId'];
		$order['productId'] = $newOrder['productId'];
		$order['wh_id'] = $newOrder['wh_id'];
		$order['soitemID'] = $soitemID;
		$order['financeSysNo'] = $financeSysNo;
		$order['chargeMoney'] = $newOrder['chargeMoney'] * 100;
		$order['payMoney'] = $newOrder['payMoney'] * 100;
		$order['operator'] = $newOrder['operator'];
		$order['area'] = $newOrder['area'];
		$order['orderTime'] = time(); 
		$order['status'] = VP_STATUS_INIT;
		$order['salesman'] =  isset($newOrder['ls']) ? $_LS_SALESMAN[$newOrder['ls']] : '';
		$order['synFlag'] = VP_ORDER_SYN_NO; //֧����ɺ��ͬ��״̬  		
		 
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			// ITIL�ϱ�
			itil_report(635208);
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed" . $orderDb->errMsg;  
			Logger::err(self::$errMsg);
			return  false;
		}
		
		if(false === $orderDb->insert(self::$tableName,$order))
		{
			// ITIL�ϱ�
			itil_report(635208);
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "insert OrderDB failed". $orderDb->errMsg;
			Logger::err(self::$errMsg); 
			return  false;			
		}
	  
		return array('errCode' => 0, 'errMsg' => array('order_char_id' => $order['order_char_id'],
													   'uid' => $order['uid'],
													   'payType' => $order['payType'],
													   'targetId' => $order['targetId'])); 
	}
		
	/**
	 * ���ò�ѯ����ֵ���� ����״̬ ��ֵ�л���Ѹ�˻��ۿ�ɹ�
	 */
	public static function CallSysOrderScript()
	{
		///�ú���û��ʹ������
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed" . $orderDb->errMsg;
			Logger::err(self::$errMsg); 
			return  false;
		}  
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid]
					  ,[payType] as pay_type
					  ,[type]
					  ,[targetId]
					  ,[productId] 
					  ,[wh_id] as hw_id
					  ,[chargeMoney]
					  ,[payMoney] as cash
					  ,[hasPaidMoney]
					  ,[operator]
					  ,[area]
					  ,[orderTime]
					  ,[payTime]
					  ,[icsonPayTime]
					  ,[successTime]
					  ,[refuncTime]
					  ,[payFlow]
					  ,[orderFlow]
					  ,[synFlag]
					  ,[status]
					  ,[desc] FROM ' . self::$tableName . ' WHERE OR status=' . VP_STATUS_ONCHARGE . ' OR status=' . VP_STATUS_ICSONPAY_SUCCESS;		
		if(false === $orders)
		{
			self::$errCode = -4001;
			self::$errMsg .= basename(__FILE__, '.php') . " |" . __LINE__ . "select OrderDB failed"; 
			return  false;			
		}  
		return $orders;			
	}

	/**
	 * ��������״̬д�붩��״̬
	 */
	public static function getChargeStatus(&$data)
	{  
		// ITIL�ϱ�
		itil_report(635183); 
		if(isset($data['errorCode']) && $data['errorCode'] != 0)
		{ 
			if('1217' == $data['errorCode'])
			{//��Ʒȱ��,֪ͨ�˿�
				$ret = self::setIcsonPayFail($data);
				//��Ӧ VP_STATUS_ICSONPAY_FAIL ����״̬�� �Ƿ���Ҫ����
				self::$errCode = -1001;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ������Ʒȱ�� " . $data['errorCode'] . $data['errorMessage'] . self::$errMsg;
				if(false === $ret)
				{
					self::$errCode = -1000;
					self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���¶���״̬ʧ�� " . self::$errMsg;
					Logger::err(self::$errMsg); 
					return false;
				}   
				//�޸Ķ���״̬�������˿�����
				return true;				
			}
			if('1096' == $data['errorCode'])
			{//�Ƹ�ͨ���㣬֪ͨ��Ǯ��ǰ̨�˿ڷ��
				self::$errCode = -1002;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " �Ƹ�ͨ���� " . $data['errorCode'] . $data['errorMessage'];
				Logger::err(self::$errMsg);
				//���͸澯����
				$message = "��Ѹ�����ֵ�Ƹ�ͨ�ʺ����㣬���ֵ!";
				$ret = IMessage::sendSMSMessage(VP_FINANCIAL_MOBILE,$message);
				if(false === $ret)
				{ 
					$logger = new Logger('sysVirtualPayFlow');
					$logger->err('send message failed: ' . $message); 
				}
				return false;				
			} 
			if('12290' == $data['errorCode'])
			{//signУ��ʧ��
				self::$errCode = -1003;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "����У������� " . $data['errorCode'] . $data['errorMessage']; 
				Logger::err(self::$errMsg);
				return false;				
			} 
			self::$errCode = -1004;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "����״̬���� " . $data['errorCode'] . $data['errorMessage'];
			Logger::err(self::$errMsg);
			//����ͬ�������Ƿ�Ҫ����ͬ������
			return false;			
		}
		if(!isset($data['dealState']))
		{//�Ȳ鿴�Ƿ��ж���״̬
			self::$errCode = -1005;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���Ķ���״̬Ϊ�� " . $data['errorCode'] . $data['errorMessage']; 
			Logger::err(self::$errMsg);
			return false;		
		}
		else
		{ 
			if(VP_PAIPAI_STATUS_INIT == $data['dealState'])
			{
				//���Ķ��������ɹ���֧���� ��Ӧ VP_STATUS_USERPAID
				//���������������
				return true;
			}
			if(VP_PAIPAI_STATUS_INVAID == $data['dealState'])
			{	//������ȡ��(ԭ��:֧��ʧ��)
			
				//����״̬��Ѹ����ʧ��
				$ret = self::setIcsonPayFail($data);
				//��Ӧ VP_STATUS_ICSONPAY_FAIL ����״̬�� �Ƿ���Ҫ����
				if(false === $ret)
				{
					self::$errCode = -1006;
					self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���¶���״̬ʧ�� " . self::$errMsg; 
					Logger::err(self::$errMsg);
					return false;
				} 
				return true;
			}
			if(VP_PAIPAI_STATUS_ICSONPAY_TELSEND == $data['dealState'])
			{	//�µ���֧���ɹ���֪ͨ������  
				$ret = self::setIcsonPaySuccess($data);
				//��Ӧ VP_STATUS_ICSONPAY_SUCCESS ���¶���״̬��д����Ѹ֧��ʱ��
				if(false === $ret)
				{
					self::$errCode = -1006;
					self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���¶���״̬ʧ�� " . self::$errMsg; 
					Logger::err(self::$errMsg);
					return false;
				} 
				return true;
			}
			if(VP_PAIPAI_STATUS_ICSONPAY_ONSEND == $data['dealState'])
			{
				//����������(˵��:֧���ɹ������ڷ���)  
				
				$ret = self::setUserOnCharge($data); 
				if(false === $ret)
				{
					self::$errCode = -1006;
					self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���¶���״̬ʧ�� " . self::$errMsg; 
					Logger::err(self::$errMsg);
					return false;
				}
				return true;
			}
			if(VP_PAIPAI_STATUS_CHARGE_FAIL == $data['dealState'])
			{
				//�����˿���(˵��:֧���ɹ�����ֵʧ��)
				$ret = self::setUserChargeFail($data); 
				if(false === $ret)
				{
					self::$errCode = -1006;
					self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���¶���״̬ʧ�� " . self::$errMsg; 
					Logger::err(self::$errMsg);
					return false;
				}
				return true;
			}
			if(VP_PAIPAI_STATUS_REFUND_SUCCESS == $data['dealState'])
			{
				//�������˿�(˵��:֧���ɹ�����ֵʧ��)  
				$ret = self::setIcsonRefundSuccess($data);
				//��Ӧ VP_STATUS_ICSONPAY_REFUND_SUCCESS д���˿�ʱ�� ״̬ ���¶���״̬���˿�ʱ�䣬�������£���erp����
				if(false === $ret)
				{
					self::$errCode = -1006;
					self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���¶���״̬ʧ�� " . self::$errMsg; 
					Logger::err(self::$errMsg);
					return false;
				}
				return true;
			}
			if(VP_PAIPAI_STATUS_CHARGE_SUCCESS == $data['dealState'])
			{	
				//�����ѳ�ֵ����(˵��:֧���ɹ�����ֵ�ɹ�)  
				$ret = self::setChargeSuccess($data);//���¶���״̬���ɹ�ʱ�䣬�������£���erp����
				if(false === $ret)
				{
					self::$errCode = -1006;
					self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���¶���״̬ʧ�� " . self::$errMsg; 
					Logger::err(self::$errMsg);
					return false;
				}
				return true;
			}
		}
		self::$errCode = -1007;
		self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ����״̬δ֪ " . self::$errMsg; 
		Logger::err(self::$errMsg);
		return false;
	}

	/**
	 * ��ѯ��֧����δ��ֵ�Ķ���,���ýӿ������ֵ,����״̬ �û���֧����δ��ֵ
	 */
	public static function SearchNeedRequestOrder()
	{
		// ITIL�ϱ�
		itil_report(635184); 
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed" . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return  false;
		}  
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid] 
					  ,[payType] as pay_type
					  ,[type]
					  ,[targetId]
					  ,[productId] 
					  ,[wh_id] as hw_id
					  ,[chargeMoney] 
					  ,[payMoney] as cash
					  ,[hasPaidMoney]
					  ,[operator]
					  ,[area]
					  ,[orderTime]
					  ,[payTime]
					  ,[icsonPayTime]
					  ,[successTime]
					  ,[refuncTime]
					  ,[payFlow]
					  ,[orderFlow]
					  ,[synFlag]
					  ,[status]
					  ,[desc] FROM ' . self::$tableName . ' WHERE status=' . VP_STATUS_ONCHARGE . ' OR status=' . VP_STATUS_ICSONPAY_SUCCESS . ' OR status=' . VP_STATUS_CHARGE_FAIL . ' OR status=' . VP_STATUS_ICSONPAY_REFUND . ' OR status=' . VP_STATUS_USERPAID;
		$orders = $orderDb->getRows($sql);  
		if(false === $orders)
		{
			self::$errCode = -4001;
			self::$errMsg .= basename(__FILE__, '.php') . " |" . __LINE__ . "select OrderDB failed"; 
			return  false;			
		}  
		return $orders;				
	}

	/**
	 * ��ѯ��֧���Ĵ����û���֧��״̬�Ķ���
	 */
	public static function SearchUserPaidOrder()
	{
		// ITIL�ϱ�
		itil_report(635185);
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed" . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return  false;
		}  
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid]
					  ,[payType] as pay_type
					  ,[type]
					  ,[targetId]
					  ,[productId]
					  ,[wh_id] as hw_id
					  ,[chargeMoney]
					  ,[payMoney] as cash
					  ,[hasPaidMoney]
					  ,[operator]
					  ,[area]
					  ,[orderTime]
					  ,[payTime]
					  ,[icsonPayTime]
					  ,[successTime]
					  ,[refuncTime]
					  ,[payFlow]
					  ,[orderFlow]
					  ,[synFlag]
					  ,[status]
					  ,[desc] FROM ' . self::$tableName . ' WHERE status=' . VP_STATUS_USERPAID;	
		$orders = $orderDb->getRows($sql);  
		if(false === $orders)
		{
			self::$errCode = -4001;
			self::$errMsg .= basename(__FILE__, '.php') . " |" . __LINE__ . "select OrderDB failed"; 
			return  false;			
		}  
		return $orders;				
	}
	
	/**
	 * �������鿴�����ֵ�Ķ����б�
	 */
	public static function getVirtualOrdersLists($data)
	{		
		// ITIL�ϱ�
		itil_report(635186);
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed". $orderDb->errMsg; 
			Logger::err(self::$errMsg);  
			return  false;
		}  
		$sql = 'SELECT  [orderId]
						,[order_char_id]
						,[uid]
						,[payType]
						,[type]
						,[targetId]
						,[productId]
						,[wh_id]
						,[chargeMoney]
						,[payMoney]
						,[hasPaidMoney]
						,[soitemID]
						,[financeSysNo]
						,[operator]
						,[area]
						,[orderTime]
						,[payTime]
						,[icsonPayTime]
						,[successTime]
						,[refuncTime]
						,[payFlow]
						,[orderFlow]
						,[synFlag]
						,[status] 
						,[icsonPaidMoney]
					    ,[payType] as pay_type
					    ,[wh_id] as hw_id
					    ,[payMoney] as cash FROM ' . self::$tableName . ' WHERE orderId!=0 ';
		if (isset($data['uid'])) 
		{
			$sql .=  " AND uid=" . $data['uid'];
		}
		if (isset($data['payType'])) 
		{
			$sql .=  " AND payType=" . $data['payType'];
		}
		if (isset($data['operator']))
		{
			$sql .= " AND operator like '%" . str_replace(' ','%',$data['operator']) . "%' ";
		}
		if (isset($data['area']))
		{
			$sql .= " AND area like '%" . str_replace(' ','%',$data['area']) . "%' ";
		}
		if (isset($data['valid_time_from']) && isset($data['valid_time_to'])) 
		{
			$sql .= " AND orderTime>=" . $data['valid_time_from'] . " AND orderTime<=" . $data['valid_time_to'];		
		}
		if (isset($data['status'])) 
		{
			$sql .=  " AND status=" . $data['status'];
		}
		if (isset($data['orderId'])) 
		{
			$sql .=  " AND orderId=" . $data['orderId'];
		}
		if (isset($data['order_char_id'])) 
		{
			$sql .=  " AND order_char_id=" . $data['order_char_id'];
		}
		if (isset($data['type'])) 
		{
			$sql .=  " AND type=" . $data['type'];
		}
		if (isset($data['targetId'])) 
		{
			$sql .=  " AND targetId=" . $data['targetId'];
		}  
		if (isset($data['chargeMoney'])) 
		{
			$sql .=  " AND chargeMoney=" . $data['chargeMoney'];
		}        
		if (isset($data['orderFlow'])) 
		{
			$sql .=  " AND orderFlow=" . $data['orderFlow'];
		}    
		 
		$orders = $orderDb->getRows($sql); 
		if(false === $orders)
		{
			self::$errCode = -4001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "select OrderDB failed" . $orderDb->errMsg; 
			return  false;			
		}  
		return $orders;		
	}

	/**
	 * ��������ѯ�����ֵ�۸���Ϣ
	 */
	public static function getVirtualPayPrice($data = array())
	{		
		// ITIL�ϱ�
		itil_report(635187);
		$priceDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($priceDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get priceDb failed". $priceDb->errMsg; 
			Logger::err(self::$errMsg);  
			return  false;
		}  
		$sql = 'SELECT [productId]
					  ,[chargeMoney]
					  ,[payMoney]
					  ,[wh_id]
					  ,[operator]
					  ,[area]
					  ,[synTime]
					  ,[editUser]
					  ,[price_desc]
				FROM ' . self::$priceTableName . ' WHERE productId!=0 ';
		if (isset($data['productId'])) 
		{
			$sql .=  " AND productId=" . $data['productId'];
		} 
		if (isset($data['operator']))
		{
			$sql .= " AND operator like '%" . str_replace(' ','%',$data['operator']) . "%' ";
		}
		if (isset($data['area']))
		{
			$sql .= " AND area like '%" . str_replace(' ','%',$data['area']) . "%' ";
		}
		 
		$prices = $priceDb->getRows($sql); 
		if(false === $prices)
		{
			self::$errCode = -4001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "select priceDb failed" . $priceDb->errMsg; 
			return  false;			
		}  
		return $prices;		
	}
	
	/**
	 * ��������ѯ�����ֵ�۸���Ϣ
	 */
	public static function _updatePrice($data)
	{	
		$condition = " productId!=0 ";
		if (isset($data['productId'])) 
		{
			$condition .=  " AND productId=" . $data['productId'];
		} 
		if (isset($data['area'])) 
		{
			$condition .=  " AND area='" . $data['area'] . "'";
		} 
		if (isset($data['operator'])) 
		{
			$condition .=  " AND operator='" . $data['operator'] . "'";
		}  
		$updateData = array();
		if (isset($data['payMoney']))
		{
			$updateData['payMoney'] = $data['payMoney'];
		}	
		if (isset($data['editUser']))
		{
			$updateData['editUser'] = $data['editUser'];
		}	
		if (isset($data['synTime']))
		{
			$updateData['synTime'] = $data['synTime'];
		}	
		$priceDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($priceDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get priceDb failed". $priceDb->errMsg; 
			Logger::err(self::$errMsg);  
			return  false;
		}   
		
        $ret = $priceDb->update(self::$priceTableName,$updateData,$condition); 
		if (false === $ret) {
			self::$errCode = $priceDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $priceDb->errMsg;
			Logger::err(self::$errMsg);
			return false;
		} 	
		return true;		
	}
	
	/**
	 * 	��ѯ�û�����
	���룺
		uid;�û�id 
		page�� �ڼ�ҳ����0��ʼ
		pagesize��ÿҳ��¼��

	�����
	total :�ܽ������
	orders:��������
		order_char_id������id
		targetId����ֵ�ʺ�
		status �� ����״̬ 
		pay_type��֧����ʽ
		cash �� �ֽ�֧��
	*/ 
	public static function getUserOrdersInOneMonth($uid, $page, $pageSize)
	{
		// ITIL�ϱ�
		itil_report(635188);
		if (!isset($uid) || $uid <= 0) {
			self::$errCode = -2001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid[$uid] is empty";  
			Logger::err(self::$errMsg);
			return false;
		}		
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed" . $orderDb->errMsg;
			Logger::err(self::$errMsg);
			return  false;
		}  

		$sql = 'select count(*) as total_num from ' . self::$tableName . ' where uid=' . $uid;
		$total =  $orderDb->getRows($sql);
		if (false === $total) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = $orderDb->errMsg;
			Logger::err(self::$errMsg);			
			return false;
		}
		$total = $total[0]['total_num'];
		if ($total == 0) {
			return array('total'=>$total, 'orders'=>array());
		}
		$sql = 'SELECT * FROM (
								SELECT [orderId]
									  ,[order_char_id]
									  ,[uid]
									  ,[payType]
									  ,[type]
									  ,[targetId]
									  ,[productId]
									  ,[wh_id]
									  ,[chargeMoney]
									  ,[payMoney] as cash
									  ,[hasPaidMoney]
									  ,[operator]
									  ,[area]
									  ,[orderTime]
									  ,[payTime]
									  ,[icsonPayTime]
									  ,[successTime]
									  ,[refuncTime]
									  ,[status]
									  ,row_number() OVER (ORDER BY orderTime DESC) rn
									  FROM  ' . self::$tableName . '  where uid=' . $uid . ') tmpres
		WHERE rn >' .  $page*$pageSize . ' AND rn<=' .($page+1)*$pageSize ;
		$orders =  $orderDb->getRows($sql);
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = $orderDb->errMsg;
			Logger::err(self::$errMsg);
			return false;
		}
		if (count($orders) == 0) {
		 	return array('total'=>$total, 'orders'=>$orders);
		 }
		return array('total'=>$total, 'orders'=>$orders);
	}
	/**
	 * 	��ѯ�û�����
	���룺
		uid;�û�id 
		page�� �ڼ�ҳ����0��ʼ
		pagesize��ÿҳ��¼��

	�����
	total :�ܽ������
	orders:��������
		order_char_id������id
		targetId����ֵ�ʺ�
		status �� ����״̬ 
		pay_type��֧����ʽ
		cash �� �ֽ�֧��
	*/ 
	public static function getUserOrdersOneMonthAgo($uid, $page, $pageSize)
	{
		// ITIL�ϱ�
		itil_report(635189);
		if (!isset($uid) || $uid <= 0) {
			self::$errCode = -2001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid[$uid] is empty";  
			Logger::err(self::$errMsg);
			return false;
		}		
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed" . $orderDb->errMsg;
			Logger::err(self::$errMsg);
			return  false;
		}  

		$sql = 'select count(*) as total_num from ' . self::$old_TableName . ' where uid=' . $uid;
		$total =  $orderDb->getRows($sql);
		if (false === $total) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = $orderDb->errMsg;
			Logger::err(self::$errMsg);			
			return false;
		}
		$total = $total[0]['total_num'];
		if ($total == 0) {
			return array('total'=>$total, 'orders'=>array());
		}
		$sql = 'SELECT * FROM (
								SELECT [orderId]
									  ,[order_char_id]
									  ,[uid]
									  ,[payType]
									  ,[type]
									  ,[targetId]
									  ,[productId]
									  ,[wh_id]
									  ,[chargeMoney]
									  ,[payMoney] as cash
									  ,[hasPaidMoney]
									  ,[operator]
									  ,[area]
									  ,[orderTime]
									  ,[payTime]
									  ,[icsonPayTime]
									  ,[successTime]
									  ,[refuncTime]
									  ,[status]
									  ,row_number() OVER (ORDER BY orderTime DESC) rn
									  FROM  ' . self::$old_TableName . '  where uid=' . $uid . ') tmpres
		WHERE rn >' .  $page*$pageSize . ' AND rn<=' .($page+1)*$pageSize ;
		$orders =  $orderDb->getRows($sql);
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = $orderDb->errMsg;
			Logger::err(self::$errMsg);
			return false;
		}
		if (count($orders) == 0) {
		 	return array('total'=>$total, 'orders'=>$orders);
		 }
		return array('total'=>$total, 'orders'=>$orders);
	}	 
	
	/**
	 * ��ѯ��һ�����ֵ������Ϣ
	 *  
	 */
	public static function getVirtualOrder($uid,$order_char_id)
	{		
		// ITIL�ϱ�
		itil_report(635190);
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed" . $orderDb->errMsg;
			Logger::err(self::$errMsg); 
			return  false;
		} 
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid]
					  ,[payType]
					  ,[type]
					  ,[targetId]
					  ,[productId]
					  ,[wh_id]
					  ,[chargeMoney]
					  ,[payMoney]
					  ,[hasPaidMoney]
					  ,[operator]
					  ,[area]
					  ,[orderTime]
					  ,[payTime]
					  ,[icsonPayTime]
					  ,[successTime]
					  ,[refuncTime]
					  ,[payFlow]
					  ,[orderFlow]
					  ,[synFlag]
					  ,[status]
					  ,[desc] FROM ' . self::$tableName . ' WHERE [uid]=' . $uid . ' AND [order_char_id]=' . $order_char_id;
		$order = $orderDb->getRows($sql); 
		if(false === $order)
		{
			self::$errCode = -4001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "select OrderDB failed";
			Logger::err(__FILE__ . '.php' . '|' . __LINE__ . " �������ݿ�ʧ��" . $orderDb->errCode . '|' . $orderDb->errMsg); 
			return  false;			
		}  

		if (0 >=  count($order)) {
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders";
			return false;
		}
		return $order[0];
	}
    /**
     * ���ݶ����Ż�ȡ��Դ����
     *
     */
    public static function getSalesmanByOrderid($order_char_id)
    {
    	// ITIL�ϱ�
		itil_report(635191);
        $orderDb = ToolUtil::getMSDBObj(self::$dbName);
        if (empty($orderDb)) {
            self::$errCode = -4000;
            self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed" . $orderDb->errMsg;
            Logger::err(self::$errMsg);
            return  false;
        }
        $sql = 'SELECT [salesman] FROM ' . self::$tableName . ' WHERE [order_char_id]='.$order_char_id;
        $order = $orderDb->getRows($sql);
        if(false === $order)
        {
            self::$errCode = -4001;
            self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "select OrderDB failed";
            Logger::err(__FILE__ . '.php' . '|' . __LINE__ . " �������ݿ�ʧ��" . $orderDb->errCode . '|' . $orderDb->errMsg);
            return  false;
        }

        if (0 >=  count($order)) {
            self::$errCode = -4002;
            self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders";
            return false;
        }
        return $order[0];
    }
	/**
	 * ��ѯ�����ֵ������Ϣ��ת����֧���������ݸ�ʽ
	 *  
	 */
	public static function getVirtualOrderToPay($uid,$order_char_id)
	{		
		// ITIL�ϱ�
		itil_report(635192);
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get OrderDB failed";  
			return  false;
		}  
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid]
					  ,[payType] as pay_type
					  ,[type]
					  ,[targetId]
					  ,[productId]
					  ,[wh_id] as hw_id
					  ,[chargeMoney]
					  ,[payMoney] as cash
					  ,[hasPaidMoney]
					  ,[operator]
					  ,[area]
					  ,[orderTime]
					  ,[orderTime] as order_date
					  ,[payTime]
					  ,[icsonPayTime]
					  ,[successTime]
					  ,[refuncTime]
					  ,[payFlow]
					  ,[orderFlow]
					  ,[synFlag]
					  ,[status]
					  ,[desc] FROM ' . self::$tableName . ' WHERE [uid]=' . $uid . ' AND [order_char_id]=' . $order_char_id;
		$order = $orderDb->getRows($sql); 
		if(false === $order)
		{
			self::$errCode = -4001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "select OrderDB failed";
			Logger::err(__FILE__ . '.php' . '|' . __LINE__ . " �������ݿ�ʧ��" . $orderDb->errCode . '|' . $orderDb->errMsg); 
			return  false;			
		} 
		if(0 === count($order))
		{
			self::$errCode = -4003;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "select OrderDB null";
			return false;
		}  
		if($order[0]['hasPaidMoney'] != $order[0]['cash'])
		{
			$order[0]['isPayed'] = 0;		
		}
		else
		{
			$order[0]['isPayed'] = 1;			
		}
		return $order[0];
	}	
	
	/**
	 * ����֧����ɺ��޸Ķ���״̬
	 *  
	 */
	public static function setOrderPayed($uid, $order_char_id, $cash, $payFlow)
	{	
		// ITIL�ϱ�
		itil_report(635193);
		// ֧���ɹ����¼֧���ɹ�֪ͨ�ؼ���Ϣ
		Logger::info('[Pay Success and Change Order State] [' . basename(__FILE__, '.php') . '] [ ' . __LINE__ . ' ] | [uid=' . $uid . '] [order_char_id=' . $order_char_id . '] [cash=' . $cash . '] [payFlow=' . $payFlow . ']');

		// ����У��
		if (!isset($order_char_id) || $order_char_id == "") {
			// ITIL�ϱ�
			itil_report(635207);
			self::$errCode = -2000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "order_char_id[$order_char_id] is empty";
			Logger::err(self::$errMsg);
			return false;
		}

		if (!isset($uid) || $uid <= 0) {
			// ITIL�ϱ�
			itil_report(635207);
			self::$errCode = -2001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid[$uid] is empty";
			Logger::err(self::$errMsg);
			return false;
		}

		if (!isset($cash) || $cash <= 0) {
			// ITIL�ϱ�
			itil_report(635207);
			self::$errCode = -2020;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[$cash] is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		
		if (!isset($payFlow)) {
			// ITIL�ϱ�
			itil_report(635207);
			self::$errCode = -2021;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[$payFlow] is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			// ITIL�ϱ�
			itil_report(635207);
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg); 
			return  false;
		}   
 		// ��ѯ��������
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid]
					  ,[payType]
					  ,[type]
					  ,[targetId]
					  ,[productId]
					  ,[wh_id]
					  ,[chargeMoney]
					  ,[payMoney]
					  ,[hasPaidMoney]
					  ,[soitemID]
					  ,[financeSysNo]
					  ,[operator]
					  ,[area]
					  ,[orderTime]
					  ,[payTime]
					  ,[payFlow]
					  ,[synFlag]
					  ,[status]
					  ,[salesman]
					  FROM ' . self::$tableName . ' WHERE [uid]=' . $uid . ' AND [order_char_id]=' . $order_char_id;
		$orders = $orderDb->getRows($sql);
		if (false === $orders) {
			// ITIL�ϱ�
			itil_report(635207);
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}

		if (0 >= count($orders)) {
			// ITIL�ϱ�
			itil_report(635207);
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders"; 
			Logger::err(self::$errMsg);
			return false;
		}
		$order = &$orders[0];
		// ��������У��
        if (bccomp($cash, $order['payMoney'], 0)) {
        		// ITIL�ϱ�
				itil_report(635207);
                self::$errCode = -1008;
                self::$errMsg = "�û�֧�� $cash ������Ӧ֧����� ({$order['payMoney']})"; 
				Logger::err(self::$errMsg);
                return false;
        }
        // ������У��
        if ($order['status'] != VP_STATUS_INIT && $order['status'] != VP_STATUS_INVALID) {
            return true;
        }
		
		// ����������ش�������������⣬��ʱע�ͣ��ȶ���ɾ�� - hongfuguan
		//�����񣬸������ݿ�
		/*$sql = "begin transaction";
		$ret = $orderDb->execSql($sql);
		if (false === $ret) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg='����virtualPay orderdb����ʧ��'  . $orderDb->errMsg;
			Logger::err(self::$errMsg);
			return  false;
		}*/	

		// ���¶���״̬
		$now = time();
        
        $sql = 'update ' . self::$tableName . ' set 
						status=' . VP_STATUS_USERPAID . ',
						payTime=' . $now . ',
						payFlow=\'' . $payFlow . '\',
						hasPaidMoney=' . $order['payMoney'] . ' 
						where uid=' . $uid . ' and order_char_id=\'' . $order_char_id . '\'';
        $ret = $orderDb->execSql($sql); 
		if (false === $ret || $orderDb->getAffectedRows() != 1) {
			// ITIL�ϱ�
			itil_report(635207);
			if (1 != $orderDb->getAffectedRows()) {
				self::$errCode = -2013;
				self::$errMsg = "�û���Ӧ����������(" . $data['order_char_id'] . ") blongs to user" . $data['uid']. $orderDb->errMsg;  
				Logger::err(self::$errMsg);
			}
			else
			{
				self::$errCode = $orderDb->errCode;
				self::$errMsg = $orderDb->errMsg;
				Logger::err(self::$errMsg);
			}
			/*$sql = "rollback"; 
			$orderDb->execSql($sql); */
			return false;
		} 
		
		$order['payTime'] = $now;
		$order['status'] = VP_STATUS_USERPAID;
		$order['payFlow'] = $payFlow;
		$order['hasPaidMoney'] = $order['payMoney'];
		unset($order['hw_id']);
		unset($order['pay_type']);
		
		
		//����erp���ݿ�
		$erpDb = ToolUtil::getMSDBObj(self::$ERPSoDBName);
		if(false === $erpDb->insert(self::$tableName,$order))
		{
			// ITIL�ϱ�
			itil_report(635205);
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "insert ERPOrderDB failed". $erpDb->errMsg;
			Logger::err(self::$errMsg);
			/*$sql = "rollback"; 
			$orderDb->execSql($sql);*/ 
			//return  false;			
		}		
		
		if(false === self::_updateERP($order))
		{
			// ITIL�ϱ�
			itil_report(635205); 
			/*$sql = "rollback"; 
			$orderDb->execSql($sql); */
			//return false;
		}
	
		/*$sql = "commit";
		$orderDb->execSql($sql);   */
		  
		//���ýӿ������ķ����µ�����,������״̬ 
		$ret = self::sendOrderToPaiPai($order); 
		return true;
	}
	 
	//����cmdid
	/*
	 *���磺http://api.paipai.com/item/addItem.xhtml����requestURLPath="/item/addItem.xhtml "����Ӧ��cmdid="item.addItem"��
	 *���磺http://api.paipai.com/deal/getDeal.xhtml����requestURLPath="/deal/getDeal.xhtml "����Ӧ��cmdid="deal.getDeal"��
	*/
	static public function _paipaiCreateCmdid($requestURLPath)
	{	
		if(strlen($requestURLPath)==0)return false;
		if($requestURLPath{0} != '/')return false;
		if(strpos($requestURLPath,'/')===false)return false;
		if(strpos($requestURLPath,'.')===false)return false;
		$pos_start = 1;
		$pos_end = strpos($requestURLPath,'.');
		$cmd = substr($requestURLPath,$pos_start,$pos_end-1);
		$cmd = str_replace('/','.',$cmd);
		return $cmd;
		
	} 
	 
	/**
	 * ����ǩ��
	 * @param $paramArr��api��������
	 * @return $sign
	 */
	static private function _paipaiCreateSign ($paramArr,$cmdid='') {
		ksort($paramArr);
		$sign = $cmdid;
		foreach ($paramArr as $key => $val) {
			if ($key !='' && $val !='') {
				$sign .= $key.$val;
			}
		}
		$sign .= VP_PAIPAI_SECRETKEY;
		$sign = md5($sign);
		return $sign;
	}
	
	/**
	 * �����ַ������� 
	 * @param $paramArr��api��������
	 * @return $strParam
	 */
	static private function _paipaiCreateStrParam ($paramArr) {
		$strParam = '';
		foreach ($paramArr as $key => $val) {
			if ($key != '' && $val !='') {
				$strParam .= $key.'='.urlencode($val).'&';
			}
		}
		return $strParam;
	}
	
	/*
		�����ķ����¶�������
	*/
	public static function sendOrderToPaiPai(&$data)
	{   
		// ITIL�ϱ�
		itil_report(635194);
		$requestURLPath = VP_PAIPAI_MOBILE_SUBMIT_URL;
		
		$paipaiParamArr = array(
			'uin' => VP_PAIPAI_UID,
			'token' => VP_PAIPAI_TOKEN,
			'spid' => VP_PAIPAI_SPID,
		);

        //������Դ����
        $vb2ctag = '';
        $order_char_id = $data['order_char_id'];
        $result = self::getSalesmanByOrderid($order_char_id);
        if(($result['salesman']==999999) || ($result['salesman']==999998))
        {
            $vb2ctag = '4_2018_3_945_60';
        }elseif(($result['salesman']==888888) || ($result['salesman']==888886)){
            $vb2ctag = '4_2017_3_944_60';
        }else{
            $vb2ctag = '3_1007_1_162_18';
        }
		//API�û�����
		$userParamArr = array(
			'amount' => $data['chargeMoney'], 
			'format' => 'json', 
			'mobile' => $data['targetId'], 
			'mobileArea' => $data['area'], 
			'mobileProvider' => $data['operator'],
			'pureData' => '1', 
			'spDealId' => $data['order_char_id'],
            		'vb2ctag'  => $vb2ctag
		);

		//�ܲ�������
		$paramArr = $paipaiParamArr + $userParamArr; 
		
		//��֯����
		$cmdid = self::_paipaiCreateCmdid($requestURLPath);
		if(false === $cmdid)
		{
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get Url Cmd id error "; 
			Logger::err(self::$errMsg);
			return false;		
		}
		$sign = self::_paipaiCreateSign($paramArr,$cmdid);
		$strParam = self::_paipaiCreateStrParam($paramArr);
		$strParam .= 'sign='.$sign;
		$strParam = VP_PAIPAI_API_URL .$requestURLPath.'?'.$strParam;


///д������ˮ��־�����ߺ�ɾ��		
self::_setVritualPayFlow($strParam);
//д������ˮ��־�����ߺ�ɾ��					 
				 
		$res = NetUtil:: cURLHTTPGet($strParam, 15); 
		if (false === $res) {
			self::setOrderSysFlag($data['uid'],$data['order_char_id'],$data['synFlag']);
			self::$errCode =NetUtil::$errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "send mobile request to paipai error " . NetUtil::$errMsg; 
			Logger::err(self::$errMsg);
			return false; 
		} 
		else
		{
			self::setOrderSysFlag($data['uid'],$data['order_char_id'],$data['synFlag'],true);		
		}		
/*д������ˮ��־�����ߺ�ɾ��*/		
self::_setVritualPayFlow($res);
/*д������ˮ��־�����ߺ�ɾ��*/	
		//����apiƽ̨bug�����ܷ�����ȷ��json���飬��Ҫȥ��ĩβ���ź����
		$resNow = str_replace(",
}", "}", $res); 	
		if($resNow == $res)
		{ 
			$resNow = str_replace(",\n}", "}", $res);
			if($resNow == $res)
			{
				$lastPos = strrpos($res,","); 
				$resNow = substr_replace($res,"",$lastPos,1);
			}
		}
		$res = $resNow;

		$res = ToolUtil::gbJsonDecode($res);
		$res['order_char_id'] = $data['order_char_id'];
		$res['uid'] = $data['uid'];
		$res['mobile'] = $data['targetId'];
		$res['dealId'] = isset($res['dealId'])?$res['dealId']:0;		 
		
/*д������ˮ��־�����ߺ�ɾ��*/		
self::_setVritualPayFlow($res);
/*д������ˮ��־�����ߺ�ɾ��*/				
		
		if(false === self::getChargeStatus($res))
		{		
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "getChargeStatus error " . self::$errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}
		return true;
	}
	
	/*
	
	�����ķ��Ͳ�ѯ��������
	
	*/	
	public static function queryOrderToPaiPai(&$data)
	{   
		// ITIL�ϱ�
		itil_report(635195);

		$requestURLPath = VP_PAIPAI_MOBILE_QUERY_URL;
		
		$paipaiParamArr = array(
			'uin' => VP_PAIPAI_UID,
			'token' => VP_PAIPAI_TOKEN,
			'spid' => VP_PAIPAI_SPID,
		);

		//API�û�����
		$userParamArr = array(
			'format' => 'json', 
			'pureData' => '1', 
			'spDealId' => $data['order_char_id']
		); 

		//�ܲ�������
		$paramArr = $paipaiParamArr + $userParamArr; 
		
		//��֯����
		$cmdid = self::_paipaiCreateCmdid($requestURLPath);
		if(false === $cmdid)
		{
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get Url Cmd id error "; 
			Logger::err(self::$errMsg);
			return false;		
		}
		$sign = self::_paipaiCreateSign($paramArr,$cmdid);
		$strParam = self::_paipaiCreateStrParam($paramArr);
		$strParam .= 'sign='.$sign;
		$strParam = VP_PAIPAI_API_URL .$requestURLPath.'?'.$strParam;
		 
///д������ˮ��־�����ߺ�ɾ��		
self::_setVritualPayFlow($strParam);
//д������ˮ��־�����ߺ�ɾ��	
		$res = NetUtil:: cURLHTTPGet($strParam, 15);  
		if (false === $res) {
			self::setOrderSysFlag($data['uid'],$data['order_char_id'],$data['synFlag']);
			self::$errCode =NetUtil::$errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "send mobile request to paipai error " . NetUtil::$errMsg; 
			Logger::err(self::$errMsg);
			return false; 
		}
		else
		{
			self::setOrderSysFlag($data['uid'],$data['order_char_id'],$data['synFlag'],true);		
		}  
///д������ˮ��־�����ߺ�ɾ��		
self::_setVritualPayFlow($res);
//д������ˮ��־�����ߺ�ɾ��	
		//����apiƽ̨bug�����ܷ�����ȷ��json���飬��Ҫȥ��ĩβ���ź����
		$resNow = str_replace(",
}", "}", $res); 	
		if($resNow == $res)
		{ 
			$resNow = str_replace(",\n}", "}", $res);
		}
		$res = $resNow;
		
///д������ˮ��־�����ߺ�ɾ��		
self::_setVritualPayFlow($res);
//д������ˮ��־�����ߺ�ɾ��	
		$res = ToolUtil::gbJsonDecode($res);
		$res['order_char_id'] = $data['order_char_id'];
		$res['uid'] = $data['uid'];
		$res['mobile'] = $data['targetId'];
		$res['dealId'] = isset($res['dealId'])?$res['dealId']:0;
		 
		
/*д������ˮ��־�����ߺ�ɾ��*/		
self::_setVritualPayFlow($res);
/*д������ˮ��־�����ߺ�ɾ��*/	
		if(false === self::getChargeStatus($res)) 
		{		
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "getChargeStatus error " . self::$errMsg;
			Logger::err(self::$errMsg); 
			return false;
		}
		return true;
	}
	
	/**
	 * ���ĳ�ֵ��Ѹ�˻��ۿ�ʧ��
	 *  
	 */
	public static function setIcsonPayFail(&$data)
	{//��Ӧ VP_STATUS_ICSONPAY_FAIL ����״̬�� �Ƿ���Ҫ����
		// ITIL�ϱ�
		itil_report(635196);
		 
		//���� ��Ѹ�˻���Ǯ? 
		//֪ͨ�ɹ�����
		if (!isset($data['order_char_id'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "order_char_id is empty";
			Logger::err(self::$errMsg);
			return false;
		}	
		if (!isset($data['uid'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['mobile'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "mobile is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['dealId'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "dealId is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg;  
			Logger::err(self::$errMsg);
			return  false;
		}   
		$now = time();
		$order_char_id = $data['order_char_id'];
		$uid = $data['uid'];
		
		//�Ȳ�ѯ״̬�Ƿ��Ѿ�����,���δ����ֱ���˳�
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid] 
					  ,[orderFlow] 
					  ,[status] FROM ' . self::$tableName . ' WHERE uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';		
		$orders = $orderDb->getRows($sql);		
		
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}

		if (0 >= count($orders)) {
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders"; 
			Logger::err(self::$errMsg);
			return false;
		}
		$order = $orders[0];
		
		if(VP_STATUS_ICSONPAY_FAIL == $order['status'])
		{
			if($data['dealId'] != $order['orderFlow'])
			{
				self::$errCode = -1009;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���Ķ����Ŵ���";
				Logger::err(self::$errMsg); 
				return false;					
			}
			else
			{ 
				//״̬�������Ѹ���,�����ٴθ���
				return true;			
			}		
		}
		
		//�����񣬸������ݿ�
		$sql = "begin transaction";
		$ret = $orderDb->execSql($sql);
		if (false === $ret) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg='����virtualPay orderdb����ʧ��'  . $orderDb->errMsg;
			Logger::err(self::$errMsg);
			return  false;
		}
		
		
		$now = time();
        
        $sql = 'update ' . self::$tableName . ' set 
						status=' . VP_STATUS_ICSONPAY_FAIL . ', 
						orderFlow=' . $data['dealId'] . ',
						icsonPayTime=' . $now . ' 
						where uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';
        $ret = $orderDb->execSql($sql); 
		if (false === $ret || $orderDb->getAffectedRows() != 1) {
			if (1 != $orderDb->getAffectedRows()) {
				self::$errCode = -2013;
				self::$errMsg = "�û���Ӧ����������(" . $data['order_char_id'] . ") blongs to user" . $data['uid']; 
				Logger::err(self::$errMsg); 
			}
			else
			{
				self::$errCode = $orderDb->errCode;
				self::$errMsg = $orderDb->errMsg;
				Logger::err(self::$errMsg);
			}
			$sql = "rollback"; 
			$orderDb->execSql($sql); 
			return false;
		} 
		
		$order['orderFlow'] = $data['dealId'];
		$order['icsonPayTime'] = $now;
		$order['status'] = VP_STATUS_ICSONPAY_FAIL;
		 
		$erpData = array(					
			'SOSysNo' => $order['orderId'],
			'TradeTime' => $now,
			'TradeAmt' => $data['payFee'],
			'PaiPaiNo' => $data['dealId'],
			'VirtualStatus' => VP_STATUS_ICSONPAY_FAIL 
		);
		
		if(false === self::_updateERP($order,$erpData))
		{ 
			// ITIL�ϱ�
			itil_report(635205);
			$sql = "rollback"; 
			$orderDb->execSql($sql); 
			return false;
		}
	
		$sql = "commit";
		$orderDb->execSql($sql);  
		return true; 
	}	
	
	/**
	 * ��������Ѹ�˻��˿�ɹ�
	 *  
	 */
	public static function setIcsonRefundSuccess(&$data)
	{
		// ITIL�ϱ�
		itil_report(635197);
		
		//��Ӧ VP_STATUS_ICSONPAY_REFUND_SUCCESS д���˿�ʱ�� ״̬ ���¶���״̬���˿�ʱ�䣬�������£���erp����
		if (!isset($data['order_char_id'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "order_char_id is empty";
			Logger::err(self::$errMsg);
			return false;
		}	
		if (!isset($data['uid'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['mobile'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "mobile is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['dealId'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "dealId is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg); 
			return  false;
		}   
		$now = time();
		
		$data['dealPayTime'] = strtotime($data['dealPayTime']); 		
		$data['dealSuccessTime'] = strtotime($data['dealSuccessTime']); 

		
		//�Ȳ�ѯ״̬�Ƿ��Ѿ�����,���δ����ֱ���˳�
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid] 
					  ,[orderFlow] 
					  ,[status] FROM ' . self::$tableName . ' WHERE uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';		
		$orders = $orderDb->getRows($sql);		
		
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}

		if (0 >= count($orders)) {
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders"; 
			Logger::err(self::$errMsg);
			return false;
		}
		$order = &$orders[0];
		
		if(VP_STATUS_ICSONPAY_REFUND_SUCCESS == $order['status'])
		{
			if($data['dealId'] != $order['orderFlow'])
			{
				self::$errCode = -1009;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���Ķ����Ŵ���"; 
				Logger::err(self::$errMsg);
				return false;					
			}
			else
			{  
				//״̬�������Ѹ���,�����ٴθ���
				return true;			
			}		
		}

		
		//�����񣬸������ݿ�
		$sql = "begin transaction";
		$ret = $orderDb->execSql($sql);
		if (false === $ret) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg='����virtualPay orderdb����ʧ��'  . $orderDb->errMsg;
			Logger::err(self::$errMsg);
			return  false;
		}
        
        $sql = 'update ' . self::$tableName . ' set 
						status=' . VP_STATUS_ICSONPAY_REFUND_SUCCESS . ', 
						orderFlow=' . $data['dealId'] . ' , 
						icsonPayTime=' . $data['dealPayTime'] . ',
						successTime=' . $data['dealSuccessTime'] . ',
						refuncTime=' . $now . ' ,
						icsonPaidMoney=' . $data['payFee'] . '  
						where uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';
        $ret = $orderDb->execSql($sql); 
		if (false === $ret || $orderDb->getAffectedRows() != 1) {
			if (1 != $orderDb->getAffectedRows()) {
				self::$errCode = -2013;
				self::$errMsg = "�û���Ӧ����������(" . $data['order_char_id'] . ") blongs to user" . $data['uid']; 
				Logger::err(self::$errMsg); 
			}
			else
			{
				self::$errCode = $orderDb->errCode;
				self::$errMsg = $orderDb->errMsg;
				Logger::err(self::$errMsg);
			}
			$sql = "rollback"; 
			$orderDb->execSql($sql); 
			return false;
		} 
		
		
		$order['status'] = VP_STATUS_ICSONPAY_REFUND_SUCCESS; 
		$order['orderFlow'] = $data['dealId'];
		$order['icsonPayTime'] = $data['dealPayTime'];
		$order['successTime'] = $data['dealSuccessTime'];
		$order['refuncTime'] = $now;
		$order['icsonPaidMoney'] = $data['payFee'];
		
		$erpData = array(		
			'SOSysNo' => $order['orderId'],
			'TradeTime' => time(),
			'TradeAmt' => $data['payFee'],
			'PaiPaiNo' => $data['dealId'],
			'VirtualStatus' => VP_STATUS_ICSONPAY_REFUND_SUCCESS
		);
		
		if(false === self::_updateERP($order,$erpData))
		{ 
			// ITIL�ϱ�
			itil_report(635205);
			$sql = "rollback"; 
			$orderDb->execSql($sql); 
			return false;
		}
	
		$sql = "commit";
		$orderDb->execSql($sql);   
		return true;		
	}

	
	/**
	 * ��Ѹ���û��˿�ɹ�
	 *  
	 */
	public static function setUserRefundSuccess(&$data)
	{ 
		// ITIL�ϱ�
		itil_report(635198);
		
		if (!isset($data['order_char_id'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "order_char_id is empty";
			Logger::err(self::$errMsg);
			return false;
		}	
		if (!isset($data['uid'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg;  
			Logger::err(self::$errMsg);
			return  false;
		}   
		$now = time();

		//�Ȳ�ѯ״̬�Ƿ��Ѿ�����,���δ����ֱ���˳�
		$sql = 'SELECT [order_char_id]
					  ,[uid] 
					  ,[orderFlow] 
					  ,[status] FROM ' . self::$tableName . ' WHERE uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';		
		$orders = $orderDb->getRows($sql);		
		
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}

		if (0 >= count($orders)) {
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders"; 
			Logger::err(self::$errMsg);
			return false;
		}
		$order = &$orders[0];
		
				
		if(VP_STATUS_USER_REFUND_SUCCESS == $order['status'])
		{ 
			//״̬�������Ѹ���,�����ٴθ���
			return true; 
		}
		
        $sql = 'update ' . self::$tableName . ' set 
						status=' . VP_STATUS_USER_REFUND_SUCCESS . ' 
						where uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';
        $ret = $orderDb->execSql($sql);
        if (false === $ret) {
                self::$errCode = $orderDb->errCode;
                self::$errMsg = $orderDb->errMsg; 
				Logger::err(self::$errMsg);
                return false;
        }

        if (1 != $orderDb->getAffectedRows()) {
                self::$errCode = -2013;
                self::$errMsg = "�û���Ӧ����������(" . $data['order_char_id'] . ") blongs to user" . $data['uid']; 
				Logger::err(self::$errMsg);
                return false;
        }
		return true;		
	}
	/**
	 * ���ĳ�ֵ��Ѹ�˻��ۿ�ɹ�
	 *  
	 */
	public static function setIcsonPaySuccess(&$data)
	{//��Ӧ VP_STATUS_ICSONPAY_SUCCESS ����״̬��
		// ITIL�ϱ�
		itil_report(635199);
		
		if (!isset($data['order_char_id'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "order_char_id is empty";
			Logger::err(self::$errMsg);
			return false;
		}	
		if (!isset($data['uid'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['mobile'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "mobile is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['dealId'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "dealId is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg;  
			Logger::err(self::$errMsg);
			return  false;
		}   
		$data['dealPayTime'] = strtotime($data['dealPayTime']); 


		//�Ȳ�ѯ״̬�Ƿ��Ѿ�����,���δ����ֱ���˳�
		$sql = 'SELECT [order_char_id]
					  ,[uid] 
					  ,[orderFlow] 
					  ,[icsonPaidMoney] 
					  ,[status] FROM ' . self::$tableName . ' WHERE uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';		
		$orders = $orderDb->getRows($sql);		
		
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}

		if (0 >= count($orders)) {
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders"; 
			Logger::err(self::$errMsg);
			return false;
		}
		$order = &$orders[0];
		
		if(VP_STATUS_ICSONPAY_SUCCESS == $order['status'])
		{
			if($data['dealId'] != $order['orderFlow'])
			{
				self::$errCode = -1009;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���Ķ����Ŵ���"; 
				Logger::err(self::$errMsg);
				return false;					
			}
			else
			{  
				//״̬�������Ѹ���,�����ٴθ���
				return true;			
			}		
		} 
		
        $sql = 'update ' . self::$tableName . ' set 
						status=' . VP_STATUS_ICSONPAY_SUCCESS . ', 
						orderFlow=' . $data['dealId'] . ',
						icsonPayTime=' . $data['dealPayTime'] . ',
						icsonPaidMoney=' . $data['payFee'] . '  
						where uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';
        $ret = $orderDb->execSql($sql);
        if (false === $ret) {
                self::$errCode = $orderDb->errCode;
                self::$errMsg = $orderDb->errMsg; 
				Logger::err(self::$errMsg);
                return false;
        } 

        if (1 != $orderDb->getAffectedRows()) {
                self::$errCode = -2013;
                self::$errMsg = "�û���Ӧ����������(" . $data['order_char_id'] . ") blongs to user" . $data['uid']; 
				Logger::err(self::$errMsg);
                return false;
        }
		return true;		
	}	
	
	/**
	 * ��ֵ�ɹ����޸ĳ�ֵ�ɹ�״̬
	 *  
	 */
	public static function setChargeSuccess(&$data)
	{//��Ӧ VP_STATUS_ICSONPAY_SUCCESS ����״̬��  
		// ITIL�ϱ�
		itil_report(635200);
		
		if (!isset($data['order_char_id'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "order_char_id is empty";
			Logger::err(self::$errMsg);
			return false;
		}	
		if (!isset($data['uid'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['mobile'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "mobile is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['dealId'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "dealId is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['dealPayTime'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "dealPayTime is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['dealSuccessTime'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "dealSuccessTime is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg;  
			Logger::err(self::$errMsg);
			return  false;
		}    
 
		$data['dealPayTime'] = strtotime($data['dealPayTime']); 		
		$data['dealSuccessTime'] = strtotime($data['dealSuccessTime']); 

		
		//�Ȳ�ѯ״̬�Ƿ��Ѿ�����,���δ����ֱ���˳�
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid] 
					  ,[orderFlow]
					  ,[icsonPaidMoney] 
					  ,[status] FROM ' . self::$tableName . ' WHERE uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';		
		$orders = $orderDb->getRows($sql);		
		
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}

		if (0 >= count($orders)) {
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders"; 
			Logger::err(self::$errMsg);
			return false;
		}
		$order = &$orders[0]; 
				
		if(VP_PAIPAI_STATUS_CHARGE_SUCCESS == $order['status'])
		{
			if($data['dealId'] != $order['orderFlow'])
			{
				self::$errCode = -1009;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���Ķ����Ŵ���"; 
				Logger::err(self::$errMsg);
				return false;					
			}
			else
			{ 
				//״̬�������Ѹ���,�����ٴθ���
				return true;			
			}		
		}
		
		//�����񣬸������ݿ�
		$sql = "begin transaction";
		$ret = $orderDb->execSql($sql);
		if (false === $ret) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg='����virtualPay orderdb����ʧ��'  . $orderDb->errMsg;
			Logger::err(self::$errMsg);
			return  false;
		}
         
        $sql = 'update ' . self::$tableName . ' set 
						status=' . VP_PAIPAI_STATUS_CHARGE_SUCCESS . ', 
						orderFlow=' . $data['dealId'] . ',
						icsonPayTime=' . $data['dealPayTime'] . ',
						successTime=' . $data['dealSuccessTime'] . ',
						icsonPaidMoney=' . $data['payFee'] . '  
						where uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';
		$ret = $orderDb->execSql($sql);						
		if (false === $ret || $orderDb->getAffectedRows() != 1) {
			if (1 != $orderDb->getAffectedRows()) {
				self::$errCode = -2013;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "�û���Ӧ����������(" . $data['order_char_id'] . ") blongs to user" . $data['uid'] . $orderDb->errMsg;   
				Logger::err(self::$errMsg);
			}
			else
			{
				self::$errCode = $orderDb->errCode;
				self::$errMsg = $orderDb->errMsg;
				Logger::err(self::$errMsg);
			} 
			$sql = "rollback"; 
			$orderDb->execSql($sql); 
			return false;
		}  
		
		$order['status'] = VP_PAIPAI_STATUS_CHARGE_SUCCESS; 
		$order['orderFlow'] = $data['dealId'];
		$order['icsonPayTime'] = $data['dealPayTime'];
		$order['successTime'] = $data['dealSuccessTime']; 
		$order['icsonPaidMoney'] = $data['payFee'];
		
		$erpData = array(		
			'SOSysNo' => $order['orderId'],
			'TradeTime' => $data['dealSuccessTime'],
			'TradeAmt' => $data['payFee'],
			'PaiPaiNo' => $data['dealId'],
			'VirtualStatus' => VP_PAIPAI_STATUS_CHARGE_SUCCESS
		);
		
		if(false === self::_updateERP($order,$erpData))
		{ 
			// ITIL�ϱ�
			itil_report(635205);
			$sql = "rollback"; 
			$orderDb->execSql($sql); 
			return false;
		}
	
		$sql = "commit";
		$orderDb->execSql($sql);   
		return true;	
	}	
	/**
	 * ���ĳ�ֵ��Ѹ�˻��ۿ�ʧ��
	 *  
	 */
	public static function setUserOnCharge(&$data)
	{//����������(˵��:֧���ɹ������ڷ���)  
     //��Ӧ VP_STATUS_ONCHARGE ���¶���״̬ 
		// ITIL�ϱ�
		itil_report(635201);
		
		if (!isset($data['order_char_id'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "order_char_id is empty";
			Logger::err(self::$errMsg);
			return false;
		}	
		if (!isset($data['uid'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['mobile'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "mobile is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['dealPayTime'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "dealPayTime is empty";
			Logger::err(self::$errMsg);
			return false;
		} 
		$data['dealPayTime'] = strtotime($data['dealPayTime']);
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg;  
			Logger::err(self::$errMsg);
			return  false;
		}   
		
		//�Ȳ�ѯ״̬�Ƿ��Ѿ�����,���δ����ֱ���˳�
		$sql = 'SELECT [order_char_id]
					  ,[uid] 
					  ,[orderFlow] 
					  ,[status] FROM ' . self::$tableName . ' WHERE uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';		
		$orders = $orderDb->getRows($sql);		
		
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}

		if (0 >= count($orders)) {
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders"; 
			Logger::err(self::$errMsg);
			return false;
		}
		$order = &$orders[0];
				
		if(VP_STATUS_ONCHARGE == $order['status'])
		{
			if($data['dealId'] != $order['orderFlow'])
			{
				self::$errCode = -1009;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���Ķ����Ŵ���"; 
				Logger::err(self::$errMsg);
				return false;					
			}
			else
			{ 
				//״̬�������Ѹ���,�����ٴθ���
				return true;			
			}		
		}

        $sql = 'update ' . self::$tableName . ' set 
						status=' . VP_STATUS_ONCHARGE . ',
						icsonPayTime=' . $data['dealPayTime'] . ', 
						orderFlow=' . $data['dealId'] . ' ,
						icsonPaidMoney=' . $data['payFee'] . '  
						where uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';
        $ret = $orderDb->execSql($sql);
        if (false === $ret) {
                self::$errCode = $orderDb->errCode;
                self::$errMsg = $orderDb->errMsg; 
                return false;
        }

        if (1 != $orderDb->getAffectedRows()) {
                self::$errCode = -2013;
                self::$errMsg = "�û���Ӧ����������(" . $data['order_char_id'] . ") blongs to user" . $data['uid']; 
				Logger::err(self::$errMsg);
                return false;
        }
		return true;		
	}		
	
	/**
	 * �û��˻���ֵʧ�ܣ��˿���
	 *  
	 */
	public static function setUserChargeFail(&$data)
	{	//�����˿���(˵��:֧���ɹ�����ֵʧ��) 
		//��Ӧ VP_STATUS_CHARGE_FAIL VP_STATUS_ICSONPAY_REFUND д��ʧ��ʱ�� ״̬
		// ITIL�ϱ�
		itil_report(635202);
		
		if (!isset($data['order_char_id'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "order_char_id is empty";
			Logger::err(self::$errMsg);
			return false;
		}	
		if (!isset($data['uid'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "uid is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['mobile'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "mobile is empty";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['dealPayTime'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "paipai dealPayTime is null";
			Logger::err(self::$errMsg);
			return false;
		}
		if (!isset($data['payFee'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "paipai payFee is null";
			Logger::err(self::$errMsg);
			return false;
		} 
		if (!isset($data['dealSuccessTime'])) {
			self::$errCode = -2019;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "paipai dealFailTime is null";
			Logger::err(self::$errMsg);
			return false;
		} 
		$data['dealPayTime'] = strtotime($data['dealPayTime']);
		$data['dealSuccessTime'] = strtotime($data['dealSuccessTime']);
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg;  
			Logger::err(self::$errMsg);
			return  false;
		}    

		//�Ȳ�ѯ״̬�Ƿ��Ѿ�����,���δ����ֱ���˳�
		$sql = 'SELECT [orderId]
					  ,[order_char_id]
					  ,[uid] 
					  ,[orderFlow] 
					  ,[status] FROM ' . self::$tableName . ' WHERE uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';		
		$orders = $orderDb->getRows($sql);		
		
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}

		if (0 >= count($orders)) {
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "no such orders"; 
			Logger::err(self::$errMsg);
			return false;
		}
		$order = &$orders[0];
				
		if(VP_STATUS_CHARGE_FAIL == $order['status'])
		{
			if($data['dealId'] != $order['orderFlow'])
			{
				self::$errCode = -1009;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " ���Ķ����Ŵ���"; 
				Logger::err(self::$errMsg);
				return false;					
			} 
			else
			{ 
				//״̬�������Ѹ���,�����ٴθ���
				return true;			
			}		
		}
		
		
		//�����񣬸������ݿ�
		$sql = "begin transaction";
		$ret = $orderDb->execSql($sql);
		if (false === $ret) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg='����virtualPay orderdb����ʧ��'  . $orderDb->errMsg;
			Logger::err(self::$errMsg);
			return  false;
		}
        
        $sql = 'update ' . self::$tableName . ' set 
						status=' . VP_STATUS_CHARGE_FAIL . ',
						icsonPayTime=' . $data['dealPayTime'] . ',
						successTime=' . $data['dealSuccessTime'] . ', 
						orderFlow=' . $data['dealId'] . ' 
						where uid=' . $data['uid'] . ' and order_char_id=\'' . $data['order_char_id'] . '\'';
        $ret = $orderDb->execSql($sql); 
		if (false === $ret || $orderDb->getAffectedRows() != 1) {
			if (1 != $orderDb->getAffectedRows()) {
				self::$errCode = -2013;
				self::$errMsg = "�û���Ӧ����������(" . $data['order_char_id'] . ") blongs to user" . $data['uid']; 
				Logger::err(self::$errMsg); 
			}
			else
			{
				self::$errCode = $orderDb->errCode;
				self::$errMsg = $orderDb->errMsg;
				Logger::err(self::$errMsg);
			}
			$sql = "rollback"; 
			$orderDb->execSql($sql); 
			return false;
		} 
				
		$order['status'] = VP_STATUS_CHARGE_FAIL; 
		$order['orderFlow'] = $data['dealId'];
		$order['icsonPayTime'] = $data['dealPayTime'];
		$order['successTime'] = $data['dealSuccessTime'];  
		
		$erpData = array(		
			'SOSysNo' => $order['orderId'],
			'TradeTime' => time(),
			'TradeAmt' => $data['payFee'],
			'PaiPaiNo' => $data['dealId'],
			'VirtualStatus' => VP_STATUS_CHARGE_FAIL
		);
		
		if(false === self::_updateERP($order,$erpData))
		{ 
			// ITIL�ϱ�
			itil_report(635205);
			$sql = "rollback"; 
			$orderDb->execSql($sql); 
			return false;
		}
	
		$sql = "commit";
		$orderDb->execSql($sql);  
		return true;  
	}	
	/**
	 * �û�֧����ɺ��޸Ķ���״̬
	 *  
	 */
	public static function setOrderCharged($uid, $order_char_id, $card, $payFlow)
	{		
		// ITIL�ϱ�
		itil_report(635203);
		
		if (!isset($order_char_id) || $order_char_id == "") {
			self::$errCode = -2000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "����idΪ��";
			Logger::err(self::$errMsg);
			return false;
		}

		if (!isset($uid) || $uid <= 0) {
			self::$errCode = -2001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "�û�idΪ��";
			Logger::err(self::$errMsg);
			return false;
		}

		if (!isset($cash) || $cash <= 0) {
			self::$errCode = -2011;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "֧�����cashΪ��";
			Logger::err(self::$errMsg);
			return false;
		}
		
		if (!isset($payFlow)) {
			self::$errCode = -2012;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "֧����ˮ��Ϊ��";
			Logger::err(self::$errMsg);
			return false;
		}
		$orderDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($orderDb)) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg;  
			Logger::err(self::$errMsg);
			return  false;
		}   
 
		$sql = 'SELECT [order_char_id]
					  ,[uid]
					  ,[payType] as pay_type
					  ,[type]
					  ,[wh_id] as hw_id
					  ,[chargeMoney]
					  ,[payMoney]
					  ,[hasPaidMoney]
					  ,[payTime]
					  ,[status] FROM ' . self::$tableName . ' WHERE [uid]=' . $uid . ' AND [order_char_id]=' . $order_char_id;
		$orders = $orderDb->getRows($sql);
		if (false === $orders) {
			self::$errCode = $orderDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
			Logger::err(self::$errMsg);
			return false;
		}

		if (0 >= count($orders)) {
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . " �����Ų���ʧ��"; 
			Logger::err(self::$errMsg);
			return false;
		}
		$order = &$orders[0];

        if (bccomp($cash, $order['payMoney'], 0)) {
                self::$errCode = -1008;
                self::$errMsg = "�û�֧�� $cash ������Ӧ֧����� ({$order['payMoney']})"; 
				Logger::err(self::$errMsg);
                return false;
        }

        if ($order['status'] != VP_STATUS_INIT) {
            return true;
        }

		$now = time();

        $sql = 'update ' . self::$tableName . ' set 
						status=' . VP_STATUS_USERPAID . ',
						payTime=' . $now . ',
						payFlow=\'' . $payFlow . '\',
						hasPaidMoney=' . $order['payMoney'] . ',
						synFlag=' . VP_ORDER_SYN_YES . ' 
						where uid=' . $uid . ' and order_char_id=\'' . $order_char_id . '\'';
        $ret = $orderDb->execSql($sql);
        if (false === $ret) {
                self::$errCode = $orderDb->errCode;
                self::$errMsg = $orderDb->errMsg; 
				Logger::err(self::$errMsg);
                return false;
        }

        if (1 != $orderDb->getAffectedRows()) {
                self::$errCode = -2013;
                self::$errMsg = "�û�($uid)��Ӧ����($order_char_id) ������";
				Logger::err(self::$errMsg); 
                return false;
        }
		
		return true;
	}
	
	
	/**
	 * ���¶���ͬ������
	 * 
	 * @param clear    ��falseͬ��������һ��true���ͬ����־��false��һ
	 */
	public static function setOrderSysFlag($uid, $order_char_id,$nowSysNo,$clear = false)
	{	
		// ITIL�ϱ�
		itil_report(635204);
		 
		if($clear && $nowSysNo <= VP_ORDER_SYN_YES)
		{//������ͬ����־λ
			return true;
		}
		else
		{ 
			$orderDb = ToolUtil::getMSDBObj(self::$dbName);
			if (empty($orderDb)) {
				self::$errCode = $orderDb->errCode;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $orderDb->errMsg; 
				Logger::err(self::$errMsg); 
				return  false;
			}   
			if($clear)
			{//���ͬ����־λ
				$sql = 'update ' . self::$tableName . ' set 
							synFlag=' . VP_ORDER_SYN_NO . ' 
							where uid=' . $uid . ' and order_char_id=\'' . $order_char_id . '\''; 
				$ret = $orderDb->execSql($sql);		
				if (false === $ret) {
						self::$errCode = $orderDb->errCode;
						self::$errMsg = $orderDb->errMsg; 
						Logger::err(self::$errMsg);
						return false;
				}
			}
			else
			{//�Ȳ�ѯͬ�������Ƿ񳬹����ޣ���������򱨾�   
				++$nowSysNo;
				if(VP_ORDER_SYN_ALERT_LIMIT <= $nowSysNo)
				{ 
					$message = 'VritualPay orderId:' . $order_char_id . ' uid:' . $uid . ' ' . self::$errMsg;
					$ret = IMessage::sendSMSMessage(VP_DEV_MOBILE,$message);
					if(false === $ret)
					{ 
						$logger = new Logger('sysVirtualPayFlow');
						$logger->err('send message failed: ' . $message); 
					}
					return true;
				}
				else
				{
					$sql = 'update ' . self::$tableName . ' set 
							synFlag=synFlag+1  
							where uid=' . $uid . ' and order_char_id=\'' . $order_char_id . '\''; 
					$ret = $orderDb->execSql($sql);		
					if (false === $ret) {
							self::$errCode = $orderDb->errCode;
							self::$errMsg = $orderDb->errMsg; 
							return false;
					}
				}						
			}
		}
		return true;
	}
	
	/**
	 * ͬ��erp�������ݱ���ͬ����ˮ��
	 *  
	 */
	private static function _updateERP($virtualPayOrder,$flowData=false)
	{	 	
		$erpDb = ToolUtil::getMSDBObj(self::$ERPSoDBName);
		//�����񣬸������ݿ�
		$sql = "begin transaction";
		$ret = $erpDb->execSql($sql);
		if (false === $ret) {
			self::$errCode = $erpDb->errCode;
			self::$errMsg= basename(__FILE__, '.php') . " |" . __LINE__ . '����erpDb����ʧ��'  . $erpDb->errMsg; 
			Logger::err(self::$errMsg);
			return  false;
		}

		$erpFinanceDb = ToolUtil::getMSDBObj(self::$ERPFinanceDBName);
		$ret = $erpFinanceDb->execSql($sql);
		if(false === $ret)
		{
			self::$errCode = $erpFinanceDb->errCode;
			self::$errMsg= basename(__FILE__, '.php') . " |" . __LINE__ . '����erpFinanceDb����ʧ��'  . $erpFinanceDb->errMsg;
			$sql = "rollback";
			$erpDb->execSql($sql);
			Logger::err(self::$errMsg);
			return  false;
		}


        $ret = $erpDb->update(self::$tableName,$virtualPayOrder,' orderId=' . $virtualPayOrder['orderId']); 
		if (false === $ret || $erpDb->getAffectedRows() != 1) {
			if (1 != $erpDb->getAffectedRows()) { 
				self::$errCode = -2013;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "erpDB�û���Ӧ����������(" . $virtualPayOrder['orderId'] . ") blongs to user" . $virtualPayOrder['uid'] . $erpDb->errMsg; 
				Logger::err(self::$errMsg); 
			}
			else
			{
				self::$errCode = $erpDb->errCode;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $erpDb->errMsg;
				Logger::err(self::$errMsg);
			}
			$sql = "rollback"; 
			$erpDb->execSql($sql);
			$erpFinanceDb->execSql($sql);
			return false;
		} 	

		if($flowData != false)
		{						
			$sql = 'INSERT INTO ' . self::$ERPflowTableName . '
			   ([SOSysNo]
			   ,[TradeTime]
			   ,[TradeAmt]
			   ,[PaiPaiNo]
			   ,[VirtualStatus])
		 VALUES
			   (' . $flowData['SOSysNo'] . '
			   ,\'' . date('Y-m-d H:i:s',$flowData['TradeTime']) . '\'
			   ,\'' . $flowData['TradeAmt']/100 . '\'
			   ,\'' . $flowData['PaiPaiNo'] . '\'
			   ,\'' . $flowData['VirtualStatus'] . '\')';  
			if(false === $erpFinanceDb->execSql($sql))
			{
				self::$errCode = -4002;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "insert erpFinanceDb failed" . $erpFinanceDb->errMsg;
				Logger::err(self::$errMsg);
				$sql = "rollback"; 
				$erpDb->execSql($sql);
				$erpFinanceDb->execSql($sql);
				return  false;			
			} 
		}
		$sql = "commit";
		$erpDb->execSql($sql);
		$erpFinanceDb->execSql($sql);
		return true;
	}
	 
	/**
	 * ����erp��ˮ�� 
	 *  
	 */
	private static function _insertERPFlow($data)
	{	 
		$erpDb = ToolUtil::getMSDBObj(self::$ERPFinanceDBName);
		if (empty($erpDb)) {
			// ITIL�ϱ�
			itil_report(635206);
			self::$errCode = $erpDb->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . $erpDb->errMsg; 
			Logger::err(self::$errMsg); 
			return  false;
		}   
				
		$sql = 'INSERT INTO ' . self::$ERPflowTableName . '
           ([SOSysNo]
           ,[TradeTime]
           ,[TradeAmt]
           ,[PaiPaiNo]
           ,[VirtualStatus])
     VALUES
           (' . $data['SOSysNo'] . '
           ,\'' . date('Y-m-d H:i:s',$data['TradeTime']) . '\'
           ,\'' . $data['TradeAmt']/100 . '\'
           ,\'' . $data['PaiPaiNo'] . '\'
           ,\'' . $data['VirtualStatus'] . '\')';  
		if(false === $erpDb->execSql($sql)) 
		{
			// ITIL�ϱ�
			itil_report(635206);
			self::$errCode = -4002;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "insert erpDb failed" . $erpDb->errMsg;   
			Logger::err(self::$errMsg); 
			return  false;			
		}
		return true;
	}
	
	/**
	 * д������֧����ˮ��־�ļ�,���ߺ�ɾ��
	 *  
	 */
	public static function _setVritualPayFlow($data)
	{	/* 
		if(is_array($data))
		{ 
			$log = '';
			foreach($data as $k => $v)
			{
				$log .= ' (' . $k . ' ; ' . $v . ') ';
			}
			Logger::warn($log);		
		}
		else
		{
			Logger::warn($data);			
		}*/
	}
	/**
	 * ��ʼ�����ݿ�����
	 *  
	 */ 
	public static function _initPriceDB()
	{    	 
		$priceDb = ToolUtil::getMSDBObj(self::$dbName);
		if (empty($priceDb)) {
			self::$errCode = -4000;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "get priceDb failed". $priceDb->errMsg; 
			Logger::err(self::$errMsg);  
			return  false;
		}  
		$sql = 'SELECT [productId]
				,[chargeMoney]
				,[payMoney]
				,[wh_id]
				,[operator]
				,[area]
				,[synTime]
				,[price_desc]
				FROM ' . self::$priceTableName . ' WHERE productId!=0 ';
		$prices = $priceDb->getRows($sql); 
		if(false === $prices)
		{
			self::$errCode = -4001;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "select priceDb failed" . $priceDb->errMsg; 
			return  false;			
		}   	
		global $_VP_Card_Price;
		global $_VP_Card_Category;
		$sql = 'INSERT INTO t_virtualpay_price ([productId],[chargeMoney],[payMoney],[wh_id],[operator],[area],[synTime]) VALUES';
		$insertCount = 0;
		foreach($_VP_Card_Price as $ok => $ov)
		{
			foreach($ov as $ak => $av)
			{ 
				foreach($av as $ck => $cv)
				{	 
					$hasExist = false;
					foreach($prices as $k => $v)
					{ 
						if($v['operator'] == $ok && $v['area'] == $ak && $v['chargeMoney'] == ($k * 100))
						{
							$hasExist = true; 
						}
					}
					if(!$hasExist)
					{ 
						$insertCount++;
						if(!isset($_VP_Card_Price[$ok][$ak][$ck]) || $_VP_Card_Price[$ok][$ak][$ck] == '�޻�')
						{
							$tempSql = '( \'' . $_VP_Card_Category[$ck][1] . '\',\'' .  ($ck*100) . '\',\'�޻�\',\'1\',\'' . $ok . '\',\'' . $ak  . '\',\'' . time() . '\'),'; 
						}
						else
						{
							$priceTemp = $_VP_Card_Price[$ok][$ak][$ck]*100;
							if( $priceTemp == '0')
							{
								 $priceTemp = '�޻�';
							}
							$tempSql = '( \'' . $_VP_Card_Category[$ck][1] . '\',\'' .  ($ck*100) . '\',\'' . $priceTemp . '\',\'1\',\'' . $ok . '\',\'' . $ak  . '\',\'' . time() . '\'),'; 
						}
						$sql .= $tempSql;
					}  
				}
			}
		}  
		$sql = preg_replace( "/,$/", "", $sql );
		if($insertCount != 0)
		{
			if(false === $priceDb->execSql($sql))
			{
				self::$errCode = -4002;
				self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "insert priceDB failed". $priceDb->errMsg;
				Logger::err(self::$errMsg);   
				return false;
			}			
		}
		return true;

	}  
} 
// ITIL�ϱ�����
function itil_report($attId, $increase = 1){
    if(function_exists('exd_Attr_API2')){
        $dataTemp = exd_Attr_API2($attId, $increase);
        return ($dataTemp != 0 ) ? false : true;
    }
    return true;
}