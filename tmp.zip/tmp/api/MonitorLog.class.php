<?php
//��ؼ�¼���ݲ�

class MonitorLog {

	private static $dbName = 'icson_event';

	private static $tableName = 't_monitor_log';

	public static $errCode;

	public static $errMsg;

	//������¼
	public static function add($datas) {
		$db = Config::getDB(self::$dbName);
		$rs = $db->insert(self::$tableName, $datas);
		self::$errCode = $db->errCode;
		self::$errMsg = $db->errMsg;
		return $rs;
	}

	//��ȡ��¼
	public static function getInfo($where = '') {
		$db = Config::getDB(self::$dbName);
		$rs = $db->getRows('SELECT * FROM ' . self::$tableName . $where . ' ORDER BY id desc');
		self::$errCode = $db->errCode;
		self::$errMsg = $db->errMsg;
		return $rs;
	}

	//��ȡlastId
	public static function getInsertId() {
		$db = Config::getDB(self::$dbName);
		$insertId = $db->getInsertId();
		return $insertId;
	}
}