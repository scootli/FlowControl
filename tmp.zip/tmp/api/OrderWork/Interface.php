<?php
/**
 * ������ģ��ӿڹ淶
 */
interface EA_OrderWork_Interface {
	/**
	 * init
	 * @return void
	 */
	public function __construct($data);

	/**
	 * ��顢����
	 * @return mixed false|filter data
	 */
	public function filter($base_params);

	/**
	 * ִ��
	 * @return boolean
	 */
	public function execute($base_params, $module_params);

	/**
	 * �ع�
	 * @return boolean
	 */
	public function rollback();
}
