<?php

require_once PHPLIB_ROOT . 'api/appplatform/platform/web_stub_cntl.php';
require_once(PHPLIB_ROOT . 'api/appplatform/contentdao_stub4php.php');
require_once(PHPLIB_ROOT . 'api/appplatform/commoditypoolmanageao_stub4php.php');

/**
 * ��Ʒ��/�زĳ����ݻ�ȡ�ӿ�
 * @author smithhuang
 * @version 1.0 ��ֻ�ṩ�������߶����Ʒ�ص����ݻ�ȡ
 */

class IContentPool {

	const TGO_WITH_OUT_TERM = 0;
	const TGO_CURRENT_TERM = 1;
	const TGO_ALL_TERM = 2;
	const TGO_NTH_TERM = 10000;

	const CA_APPEND = 1;
	const CA_UPDATE = 2;
	const CA_REMOVE = 3;

	const SO_JUST_APPEND = 0;
	const SO_CLEAN_BEFORE_APPEND = 1;
	
	/**
	 * �����ϱ��ĵ�����ID
	 * @var string
	 */
	const CONTENT_POOL_API_CALLER = 'content_pool_api';
	
	public static $errCode = 0;
	public static $errMsg = '';
	
	private static $_PRODUCT_KEY_MAP = array(
		'id' => 'dwId', // ID
		'product_id' => 'strCommodityId', // ��ƷID
		'product_name' => 'strTitle', // ��Ʒ����
		'pic_url' => 'strPicUrl', // ��ƷĬ��ͼƬ
		'pic_url_80' => 'strPicUrl80', // ��Ʒ80����ͼƬ
		'sold_num' => 'dwSoldNum', // ����������
		'category_id' => 'strClassId', // ����ID
		'category_name' => 'strCategoryName', // ��������
		'on_market_date' => 'dwOnMarketDate', // ����ʱ��
		'price' => 'dwPrice', // ��Ʒ�۸�
		'sort_num' => 'dwSortNumber', // ������
		'default_display' => 'dwDefaultDisplay', // �Ƿ���spu�µ�����ʾ��Ʒ
		'primary_product_id' => 'strPrimaryGoods', // ͬspu�µ�����Ʒid
		'url' => 'strUrl', // ��Ʒ����
		'market_price' => 'dwMarketPrice', // �г��۸�
		'class_name' => 'strClassName', // ǰ��չʾ��ʽ��
		'promote_text' => 'strPromoteText', // ��Ʒ������
		'short_promote_text' => 'strShortPromoteText', // ��Ʒ��������
		'inventory' => 'dwInventory', // ���
		'wg_sku_id' => 'strSkuId', // ����SKU ID
		'wg_spu_id' => 'strSpuId', // ����SPU ID
		'sale_tag' => 'strTag', // ��Ӫ��ǩ����Ʒ������ԣ�����������Ʒ
		'rush_start_time' => 'dwStarttime', // ������ʼʱ��
		'rush_end_time' => 'dwEndtime', // ��������ʱ��
		'rush_group_id' => 'strGroupid', // �������κ�
		'rush_token' => 'dwToken', // �������λ���Ƿ��ˢ
		'custorm_data' => 'strCustomData', // �Զ�������
		'state' => 'dwState', // ������Ʒ״̬��0������1�¼�
		'sale_attr' => 'strSaleAttr', // �������Դ�
		'ext_data' => 'strExtData', // ��չ���ݣ��ṹ��json�ַ���
		'score' => 'dwScore', // ��Ʒ���ʵ÷�
		'multiprices' => 'strAreaStockInfo' // �����Ϣ
	);
	
	private static function clearErr() {
		self::$errCode = 0;
		self::$errMsg = '';
	}
	
	/**
	 * ��ȡ������Ʒ��ĳһ�ڵ����ݣ�������������Ϊ��ǰ��
	 * @param int $pool_id ��Ʒ��ID
	 * @param int $term_id ����
	 */
	public static function getProductByPool($pool_id, $term_id = 0) {
		self::clearErr();
		
		$cntl = new WebStubCntl();
		$cntl->setCallerName(self::CONTENT_POOL_API_CALLER);
		
		$req = new GetContentReq();
		$content_param = new ContentParam();
		$content_param->dwPoolId = $pool_id;
		$content_param->cPoolId_u = 1;
		
		if(!empty($term_id)) {
			$content_param->dwTerm = $term_id;
			$content_param->cTerm_u = 1;
		}
		
		$req->contentParam->setValue(array( $content_param ));
		
		$resp = new GetContentResp();
		
		$ret = $cntl->invoke($req, $resp);
		if($ret == 0) {
			if($resp->result == 0) {
				$product_objs = $resp->resultList->getValue();
				$products = array();
				if(isset($product_objs[$pool_id])) {
					foreach ($product_objs[$pool_id] as $obj) {
						$product = ArrayUtil::objToArray($obj, self::$_PRODUCT_KEY_MAP);
						if($product === false) {
							Logger::err(ArrayUtil::$errCode . ' : ' . ArrayUtil::$errMsg);
						} else {
							$product['ext_data'] = json_decode('{' . $product['ext_data'] . '}', true);
							$product['multiprices'] = json_decode($product['multiprices'], true);
							$products[] = ArrayUtil::utf8ToGbk($product);
						}
					}
				} else {
					Logger::warn("Products not found with pool id $pool_id.");
				}
				
				//usort($products, array(self, 'compareProduct'));
				return $products;
			} else {
				self::$errCode = ErrorConfig::getErrorCode('invoke_error');
				self::$errMsg = '[' . $resp->result . ']' . $resp->errMsg;
				Logger::err(self::$errCode . ' : ' . self::$errMsg);
				return false;
			}
		} else {
			self::$errCode = ErrorConfig::getErrorCode('net_error');
			self::$errMsg = "Failed to get products with pool id $pool_id, term $term_id.";
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
	}
	
	public static function getSourceByPoolForThh($pool_id, $term_id = 0) {
		self::clearErr();
	
		$cntl = new WebStubCntl();
		$cntl->setCallerName(self::CONTENT_POOL_API_CALLER);
	
		$req = new GetContentReq();
		$content_param = new ContentParam();
		$content_param->dwPoolId = $pool_id;
		$content_param->cPoolId_u = 1;
	
		if(!empty($term_id)) {
			$content_param->dwTerm = $term_id;
			$content_param->cTerm_u = 1;
		}
	
		$req->contentParam->setValue(array( $content_param ));
	
		$resp = new GetContentResp();
	
		$ret = $cntl->invoke($req, $resp);
		if($ret == 0) {
			if($resp->result == 0) {
				$product_objs = $resp->resultList->getValue();
				$products = array();
				
				if(isset($product_objs[$pool_id])) {
					for ($i = 0; $i < $product_objs[$pool_id]->size; $i++) {
						$pvalue = $product_objs[$pool_id][$i];
						if (isset($pvalue->strExtData)) {
							$item = json_decode($pvalue->strExtData);
							if (isset($item->list) && !empty($item->list)) {
								$product = array();
								$product['img_wide'] = $item->list[0]->picUrl;
								$product['img_narrow'] = $item->list[0]->picUrl2;
								$product['url'] = $item->list[0]->url;
								$product['content'] = $item->list[0]->title;
								$products[] = ArrayUtil::utf8ToGbk($product);
							}
						}
					}
					return $products;
				} else {
					Logger::warn("Source not found with pool id $pool_id.");
				}
				
				return $products;
			} else {
				self::$errCode = ErrorConfig::getErrorCode('invoke_error');
				self::$errMsg = '[' . $resp->result . ']' . $resp->errMsg;
				Logger::err(self::$errCode . ' : ' . self::$errMsg);
				return false;
			}
		} else {
			self::$errCode = ErrorConfig::getErrorCode('net_error');
			self::$errMsg = "Failed to get sources with pool id $pool_id, term $term_id.";
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
	}
	
	/**
	 * ��ȡ�����Ʒ�ص�����
	 * @param array $pools ��Ʒ��ID�����������飬�� array( array( 'pool_id' => 1 ), array( 'pool_id' => 1, 'term_id' => 1 ) )
	 */
	public static function getProductByPools($pools) {
		self::clearErr();
		
		if(!is_array($pools)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 1 should be array.';
		}
		
		$cntl = new WebStubCntl();
		$cntl->setCallerName(self::CONTENT_POOL_API_CALLER);
		
		$req = new GetContentReq();
		$content_params = array();
		foreach ($pools as $pool) {
			if(empty($pool['pool_id'])) {
				continue;
			}
			
			$content_param = new ContentParam();
			$content_param->dwPoolId = $pool['pool_id'];
			$content_param->cPoolId_u = 1;
			
			if(!empty($pool['term_id'])) {
				$content_param->dwTerm = $pool['term_id'];
				$content_param->cTerm_u = 1;
			}
			
			$content_params[] = $content_param;
		}
		$req->contentParam->setValue($content_params);
		
		$resp = new GetContentResp();
		
		$ret = $cntl->invoke($req, $resp);
		if($ret == 0) {
			if($resp->result == 0) {
				$pool_arr = $resp->resultList->getValue();
				$products = array();
				foreach ($pool_arr as $pool_id => $product_objs) {
					$pool_products = array();
					foreach ($product_objs as $obj) {
						$product = ArrayUtil::objToArray($obj, self::$_PRODUCT_KEY_MAP);
						if($product === false) {
							Logger::err(ArrayUtil::$errCode . ' : ' . ArrayUtil::$errMsg);
						} else {
							$product['ext_data'] = json_decode('{' . $product['ext_data'] . '}', true);
							$product['multiprices'] = json_decode($product['multiprices'], true);
							$pool_products[] = ArrayUtil::utf8ToGbk($product);
						}
					}
					//usort($pool_products, array(self, 'compareProduct'));
					$products[$pool_id] = $pool_products;
				}
				
				return $products;
			} else {
				self::$errCode = ErrorConfig::getErrorCode('invoke_error');
				self::$errMsg = '[' . $resp->result . ']' . $resp->errMsg;
				Logger::err(self::$errCode . ' : ' . self::$errMsg);
				return false;
			}
		} else {
			self::$errCode = ErrorConfig::getErrorCode('net_error');
			self::$errMsg = "Failed to get products with pool id $pool_id, term $term_id.";
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
	}

	public static function getPoolInfoById($pool_id, $term_opt = self::TGO_WITH_OUT_TERM, $n = 0) {
		self::clearErr();

		$cntl = new WebStubCntl();
		$cntl->setCallerName(self::CONTENT_POOL_API_CALLER);

		$req = new getPoolByIdReq();
		$req->poolId = $pool_id;
		$req->termGetOption = ($term_opt == self::TGO_NTH_TERM) ? ($term_opt + $n) : $term_opt;

		$resp = new getPoolByIdResp();

		$ret = $cntl->invoke($req, $resp);
		if($ret == 0) {
			if($resp->result == 0) {
				$pool_info = ArrayUtil::array_fetch((array)$resp->poolInfo, array(
					'id' => array( 'name' => 'dwPoolID' ),
					'name' => array( 'name' => 'strPoolName' ),
					'type' => array( 'name' => 'cPoolType' ),
					'folder_id' => array( 'name' => 'dwFolderId' ),
					'current_term' => array( 'name' => 'dwCurrentTerm' ),
					'description' => array( 'name' => 'strDescription' ),
				));

				$pool_info['name'] = iconv('UTF-8', 'GBK', $pool_info['name']);
				$pool_info['description'] = iconv('UTF-8', 'GBK', $pool_info['description']);
				$term_list = (array)$resp->poolInfo->vecTermList;
				foreach ($term_list as $key => $value) {
					$term_list[$key] = ArrayUtil::array_fetch((array)$value, array(
						'number' => array( 'name' => 'dwTermNumber' ),
						'name' => array( 'name' => 'strTermName' ),
						'description' => array( 'name' => 'strDescription' ),
						'start_time' => array( 'name' => 'ddwBeginTime' ),
						'end_time' => array( 'name' => 'ddwEndTime' ),
					));

					$term_list[$key]['start_time'] = strtotime($term_list[$key]['start_time']);
					$term_list[$key]['end_time'] = strtotime($term_list[$key]['end_time']);
				}
				$pool_info['term_list'] = $term_list;
				//var_dump($pool_info);

				return $pool_info;
			} else {
				self::$errCode = ErrorConfig::getErrorCode('invoke_error');
				self::$errMsg = '[' . $resp->result . ']' . $resp->errMsg;
				Logger::err(self::$errCode . ' : ' . self::$errMsg);
				return false;
			}
		} else {
			self::$errCode = ErrorConfig::getErrorCode('net_error');
			self::$errMsg = "Failed to get pool info with pool id $pool_id, term option " . $req->termGetOption . ".";
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
	}

	public static function addProducts($products, $pool_id, $term_id, $channel = '') {
		return self::saveCommodity($products, $pool_id, $term_id, $channel, self::CA_APPEND, self::SO_JUST_APPEND);
	}

	public static function updateProducts($products, $pool_id, $term_id, $channel = '') {
		return self::saveCommodity($products, $pool_id, $term_id, $channel, self::CA_UPDATE, self::SO_JUST_APPEND);
	}

	public static function removeProducts($product_ids, $pool_id, $term_id) {
		$products = array();
		foreach ($product_ids as $id) {
			$products[] = array( 'product_id' => $id );
		}
		return self::saveCommodity($products, $pool_id, $term_id, $channel, self::CA_REMOVE, self::SO_JUST_APPEND);
	}

	private static function saveCommodity($products, $pool_id, $term_id, $channel, $action, $saveOption) {
		self::clearErr();

		$cntl = new WebStubCntl();
		$cntl->setCallerName(self::CONTENT_POOL_API_CALLER);

		$req = new saveCommodityReq();
		$req->poolId = $pool_id;
		$req->termNumber = $term_id;
		$req->action = $action;
		$req->saveOption = $saveOption;

		$commodity_list = array();
		foreach ($products as $p) {
			$p_info = new CommodityInfoBO();

			$p_info->strCommodityId = $p['product_id'];
			$p_info->cCommodityId_u = 1;

			$data = ArrayUtil::array_mask($p, array(
				'title' => true,
				'picUrl' => true,
				'picUrl80' => true,
				'url' => true,
				'promoteText' => true,
				'shortPromoteText' => true,
				'custormData' => true,
				'tag' => true,
				'className' => true
			));

			if(!empty($channel)) {
				$data['channel'] = $channel;
			}

			ArrayUtil::convertCharset($data, array( 'title', 'promoteText', 'shortPromoteText', 'channel' ), 'GBK', 'UTF-8');

			$p_info->mapCommodityData = new stl_map($data);
			$p_info->cCommodityData_u = 1;

			$commodity_list[] = $p_info;
		}
		$req->commodityList = new stl_vector($commodity_list);

		echo "######## request ########\n";
		var_dump($req);
	
		$resp = new saveCommodityResp();

		$ret = $cntl->invoke($req, $resp);
		if($ret == 0) {
			if($resp->result == 0) {
				echo "######## response ########\n";
				var_dump($resp);
				return true;
			} else {
				echo "######## response ########\n";
				var_dump($resp);
				self::$errCode = ErrorConfig::getErrorCode('invoke_error');
				self::$errMsg = '[' . $resp->result . ']' . $resp->errmsg;
				Logger::err(self::$errCode . ' : ' . self::$errMsg);
				return false;
			}
		} else {
			echo "######## return ########\n";
			var_dump($ret);
			self::$errCode = ErrorConfig::getErrorCode('net_error');
			self::$errMsg = "Failed to add products to pool with pool id {$pool_id}, term id {$term_id}, products " . ToolUtil::gbJsonEncode($products) . ".";
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
	}

	public static function getProducts($pool_id, $term_id, $term_offset = 0) {
		self::clearErr();

		$cntl = new WebStubCntl();
		$cntl->setCallerName(self::CONTENT_POOL_API_CALLER);

		$req = new getCommodityByPoolReq();
		$req->poolId = $pool_id;
		$req->termNumber = $term_id;
		$req->termOffset = $term_offset;

		$resp = new getCommodityByPoolResp();

		$ret = $cntl->invoke($req, $resp);
		if($ret == 0) {
			if($resp->result == 0) {
				echo "######## response ########\n";
				$goods_list = (array)$resp->goodsList;
				$products = array();
				foreach ($goods_list as $value) {
					$p= (array)$value;
					$products[$p['strCommodityId']] = (array)$p['mapCommodityData'];
					$products[$p['strCommodityId']]['areaStockInfo'] = json_decode($products[$p['strCommodityId']]['areaStockInfo'], true);
					$products[$p['strCommodityId']]['extData'] = json_decode('{' . $products[$p['strCommodityId']]['extData'] . '}', true);
					ArrayUtil::convertCharset($products[$p['strCommodityId']], array( 'title', 'promoteText', 'shortPromoteText', 'channel' ), 'UTF-8', 'GBK');
				}
				//var_dump($products);
				return $products;
			} else {
				echo "######## response ########\n";
				var_dump($resp);
				self::$errCode = ErrorConfig::getErrorCode('invoke_error');
				self::$errMsg = '[' . $resp->result . ']' . $resp->errmsg;
				Logger::err(self::$errCode . ' : ' . self::$errMsg);
				return false;
			}
		} else {
			echo "######## return ########\n";
			var_dump($ret);
			self::$errCode = ErrorConfig::getErrorCode('net_error');
			self::$errMsg = "Failed to get pool products with pool id {$pool_id}, term id {$term_id}, term offset {$term_offset}.";
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
	}
}