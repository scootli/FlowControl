<?php
if (!defined("PHPLIB_ROOT")) {
	define('PHPLIB_ROOT', '/data/release/PHPLIB/');
}
require_once(PHPLIB_ROOT . 'api/appplatform/platform/web_stub_cntl.php');
require_once(PHPLIB_ROOT . 'api/appplatform/platform/lang_util.php');
require_once(PHPLIB_ROOT . "lib/Config.php");
require_once(PHPLIB_ROOT . "lib/ToolUtil.php");
require_once(PHPLIB_ROOT . 'api/appplatform/sps/promotionrestrictbaseinfo_xxo.php');
require_once(PHPLIB_ROOT . 'api/appplatform/sps/spsbaseinfo_xxo.php');
require_once(PHPLIB_ROOT . 'api/appplatform/sps/spsschedulepromotion_stub4php.php');
require_once(PHPLIB_ROOT . 'api/appplatform/sps/multprice4buyao_stub4php.php');
require_once(PHPLIB_ROOT . 'api/appplatform/sps/promotionrestrictao_stub4php.php');
require_once(PHPLIB_ROOT . 'api/appplatform/sps/spsrule4others_stub4php.php');
require_once(PHPLIB_ROOT . 'api/appplatform/shoppingprocess/shoppingprocess.monitor.inc.php');

//require_once(PHPLIB_ROOT . "api/IProduct.php");
//require_once(PHPLIB_ROOT . "api/IPreOrder.php");
//require_once('inc/IProductCommonInfoTTC.php');
//require_once('inc/IShoppingCartTTC.php');



//����
define('PROMOTION_QUIRE' , 629516);
define('PROMOTION_SUCC' , 629517);
define('PROMOTION_FAILED' , 629518);
//����У��
define('CHECKPROMOTION_QUIRE' , 629838);
define('CHECKPROMOTION_SUCC' , 629839);
define('CHECKPROMOTION_FAILED' , 629840);
//�����޹��ۼ�
define('LIMITSUB_QUIRE' , 629841);
define('LIMITSUB_SUCC' , 629842);
define('LIMITSUB_FAILED' , 629843);
//�����ۼ��ع�
define('LIMITROLL_QUIRE' , 629844);
define('LIMITROLL_SUCC' , 629845);
define('LIMITROLL_FAILED' , 629846);
//��۽ӿ�
define('MULPRICE_QUIRE' , 629847);
define('MULPRICE_SUCC' , 629848);
define('MULPRICE_FAILED' , 629849);


/*
 * ���ܲ������ﳵ�ڽ��scene��2����ͨ��1
 */
Logger::init();
class IPromotionRuleV2
{
	public static $errMsg='';
	public static $errCode=0;	
	public static $promotionType = array(
		'PROMOTION_MULTPRICE' => 1,
		'PROMOTION_FULLDISCOUNT' => 2,
	);
	public static $BenfitTypeNew = array(
		'BENEFIT_TYPE_CASH'  => 1,   //����
		'BENEFIT_TYPE_COUPON' => 2,   //���Ż�ȯ
		'BENEFIT_TYPE_DISCOUNT' => 3, //�ۿ�
		'BENEFIT_TYPE_PRODUCT' => 4,  //����Ʒ
		'BENEFIT_TYPE_POINT' => 5,   //����
		'BENEFIT_TYPE_HUANGOU' => 6,  //������Ʒ
		
	);
	
	public static $RuleType = array(
	'RULE_TYPE_NULL' => 0, //������
	'RULE_TYPE_CASH_AMT'  => 1,  //�����
	'RULE_TYPE_BUY_NUM' =>2, //������
	);

    public static $ERROR_RESTRICT = 109;    //�������򲻿���

	private static $RuleTypeName = array(
		0	=> '�µ�',
		1	=> '��{_cash_amt_}',
		2	=> '��{_buy_num_}��',
	);

	private static $BenfitTypeName = array(
		1	=> '����{_cash_}',
		2	=> '�����Ż�ȯ',
		3	=> '����{_discount_name_}',
		4	=> '������Ʒ',
		5	=> '����{_point_}����',
		6	=> '������Ʒ',
		
	);

	private static $cntl = false;
	private static function _initCntl($uid)
	{
		$_cntl = new WebStubCntl();
		$sPassport = "0123456789";
		$_cntl->setDwOperatorId($uid);
		$_cntl->setSPassport($sPassport);
		$_cntl->setDwSerialNo(10002);
		$_cntl->setDwUin($uid);
		$_cntl->setWVersion(2);
		$_cntl->setCallerName("buy");
		self::$cntl = $_cntl;
	}
	
	private static function _reqConstruct(&$req, $items)
	{
		$spsItemListIn = array();
		foreach($items as $product)
		{
			$spsItem = new SpsItemBo();
			$spsItem->strItemId = $product['product_id'];
			$spsItem->cItemId_u = 1;

			//$product['mulprice'] = "5|8";
			
			
			if(isset($product['chid']) && !empty($product['chid']))
			{
				$sourceScene = explode("@", $product['chid']);
				if(count($sourceScene) > 0)
				{   
					$sourceScene = array_unique($sourceScene);
                    foreach($sourceScene as &$ss)
                    {
                        $ss = intval($ss);
                    }
					$spsItem->setActId = new stl_set();
					$spsItem->setActId->setValue($sourceScene);
					$spsItem->cActId_u = 1;
				}
			}
			//�ײ���Ʒʹ���ײ��Żݺ�۸�
			if($product['package_id'] != 0)
			{
				$spsItem->dwItemPrice = ($product['price'] - $product['pkg_cash_back']) * $product['buy_count'];
			}
            else if($product["match_num"] > 0)
            {
                $spsItem->dwItemPrice = $product['price'] *  $product['buy_count'] - ($product['match_cut']*$product['match_num']);
            }
			else
			{
				$spsItem->dwItemPrice = $product['price'] * $product['buy_count'];
			}
			
			$spsItem->cItemPrice_u = 1;
			$spsItem->dwItemUnitPrice = $product['price'];
			$spsItem->cItemUnitPrice_u = 1;
			$spsItem->dwItemNum = $product['buy_count'];
			$spsItem->cItemNum_u = 1;
			$spsItem->dwPkgId = $product['package_id'];
			$spsItem->cPkgId_u = 1;
			$spsItem->dwItemType = ($product['package_id'] != 0)? 1 : (($product['match_num'] >0)? 2:0);	//����Ҫע��ǰ����Ҫ�����ײ������������߻�������
			$spsItem->cItemType_u = 1;
			$spsItemListIn[] = $spsItem;
		}
		$strSpsItemListIn = ToolUtil::gbJsonEncode($spsItemListIn);
        //Logger::info("Sps Para:{$strSpsItemListIn}");
		$req->SpsItemListIn->setValue($spsItemListIn);
		return;
	}
	
	/**
	 * ���ﳵ��ȡ���������½ӿ�
	 * @param array $items ��Ʒ�ṹ
	 * @param number $whId �ֲ�id
	 * @param number $type ���ﳵ���� 1 ��ͨ���ﳵ 2 ���ܲ������ﳵ
	 * @param number $uid
	 * @return array
	 */
	public static function getRuleForShoppingCart($items, $whId, $type=1, $uid=0, $scene = SCENE_SHOPPING_CART)
	{
		$strItems = ToolUtil::gbJsonEncode($items);
		Logger::info("getRuleForShoppingCart start:[items:{$strItems}][whid:{$whId}][type:{$type}][uid:{$uid}]");
		if (!is_array($items) || count($items) == 0 ) {
			return "";
		}
		//��ȡ�ܼۡ��ܼ������ܿ���
		$totalClassNum = count($items);
		$totalNum = 0;
		foreach($items as $product)
		{
			$totalNum += $product['buy_count'];
		}	
		$uid = intval($uid);
		self::_initCntl($uid);
		$req = new GetPromotionInfoReq();
		$resp = new GetPromotionInfoResp();
		
		$req->uin = $uid;
		$req->source= __FILE__;
		$req->scene = $type;
		$req->itemClassNum = $totalClassNum;
		$req->itemNum = $totalNum;
		$req->whId =$whId;
		$spsItemListIn = array();
		reset($items);
		self::_reqConstruct($req, $items);
        $strReq = ToolUtil::gbJsonEncode($req);
        global $shoppingProcessItil;
        ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['req']);
        $ret = self::$cntl->invoke($req, $resp, 3);
        $strResp = ToolUtil::gbJsonEncode($resp);
		self::$cntl = false;
		if (0 != $ret) {
            ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['failed']);
			self::$errCode = 101;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[getRuleForShoppingCart invoke failed!]";
			Logger::err("GetPromotionInfoReq invoke return:[ret:{$ret}][errCode:{$resp->errCode}][items:{$strItems}][uid:{$uid}][whid:{$whId}]");
			return  false;
		}
		
		if($resp->errCode != 0)
		{
            ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['failed']);
			//��ۼ������6940��۴���
			self::$errCode = 102;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[getRuleForShoppingCart mult price Error!]";
			Logger::err("GetPromotionInfoReq invoke return:[ret:{$ret}][errCode:{$resp->errCode}][items:{$strItems}][uid:{$uid}][whid:{$whId}]");
			return  false;
		}
        ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['succ']);
        //�����۴���ֱ�ӷ��أ��������󲻷��أ����������ÿ�
        if($resp->result == 6940)
        {
            //��ۼ������6940��۴���
            self::$errCode = 103;
            self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[getRuleForShoppingCart mult price Error!]";
            Logger::err("GetPromotionInfoReq return Cal mult price Error![ret:{$ret}][result:{$resp->result}][items:{$strItems}][uid:{$uid}][whid:{$whId}]");
            return  false;
        }
        else
        {
            self::$errCode = 104;
            self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[getRuleForShoppingCart mult price Error!]";
            Logger::info("GetPromotionInfoReq return![ret:{$ret}][result:{$resp->result}][items:{$strItems}][uid:{$uid}][whid:{$whId}]");
        }
		//��������
		$spsItemListOut = $resp->SpsItemListOut;
		reset($items);
		foreach($items as &$product)
		{
			foreach($spsItemListOut as $spsItem)
			{
				if($spsItem->strItemId == $product["product_id"])
				{
					if($product["package_id"] != 0 )
					{
						if($spsItem->dwItemType != 1)
						{
							continue;
						}
					}
                    else if($product["match_num"] > 0)
                    {
                        if($spsItem->dwItemType != 2)
                        {
                            continue;
                        }
                    }
					else
					{
						if($spsItem->dwItemType != 0)
						{
							continue;
						}
					}

					//������ײ���Ʒ�ֶ����
					if($product["package_id"] != 0 || $product["match_num"] > 0)
					{
						$product["total_price_before"] = $product["price"]* $product["buy_count"];
						$product["total_price_after"] = $product["price"]* $product["buy_count"];
						$product["total_price_discount"] = 0;
						$product["price_before"] = $product["price"];
						$product["price"] = $product["price"];
						$product["discount_price"] = 0;
						$product["mult_price_discount"] = 0;
						$product["energy_save_discount"] = 0;
						$product["energy_save_name"] = "";
						$product["energy_save_desc"] = "";
						$product["discount_p_name"] = "";
						$product["discount_p_desc"] = "";
						$product["price_buy_limit_rule"] = "";
						//����޹�
						$product["price_buy_limit_flag"] = 0;
						$product["mult_limit_num"] = 0;
						$product["price_cost_ratio"] = 0;
						$product["price_scene_id"] = 0;
						$product["price_source_id"] = 0;
						$product["mult_price_op_type"] = 0;
						$product["mult_price_op_num"] = 0;
						$product["is_price_rule"] = 0;
						break;
					}
					else 
					{
						//����·��:��ۺʹ�������
						$spsItemOpPathList = $spsItem->vecSpsItemOpPathList;
						//$product["op_path"] = array();
						//get��ʱ���Ƿ��б�Ҫ��¼��۵�����·����
						//����·���������Ϣ
							
						foreach($spsItemOpPathList as $spsItemOpPath)
						{
							$opPath = array();
							$opPath["type"] = $spsItemOpPath->dwRuleType;
							$opPath["before_price"] = $spsItemOpPath->dwBeforePrice;
							$opPath["after_price"] = $spsItemOpPath->dwAfterPrice;
							$opPath["rule_id"] = $spsItemOpPath->dwRuleId;
							//$opPath["rule_desc"] = $spsItemOpPath->strDescInfo;
							$product["op_path"][] = $opPath;
						}
						//���
						$priceInfoList = $spsItem->vecPriceInfoList[0];
						$sourceId = $priceInfoList->ddwPriceSourceId;
						$sceneId = $priceInfoList->ddwPriceSceneId;
						$product["price_scene_id"] = $sceneId;				//��۳���id
						$product["price_source_id"] = $sourceId;			//�����Դid
						//��������� ����ǽ��ݼ۸�����ݽ��ݼ۸����ж�
						$product["total_price_before"] = $priceInfoList->dwPriceBeforeFavor;    //�ÿ���Ʒ���Ż�ǰ�۸���n����Ʒ����Ϊn����ֵ
						$product["total_price_after"] = $priceInfoList->dwPriceAfterFavor;		//�ÿ���Ʒ���Żݺ�۸���n����Ʒ����Ϊn����ֵ
						$product["total_price_discount"] = $priceInfoList->dwPriceDiscount;      //�ÿ���Ʒ����ܵ��Ż�
						$product["price_before"] = $priceInfoList->dwUnitPriceBeforeFavor;		//������Ʒ�Ż�ǰ�۸�
						$product["price"] = $priceInfoList->dwUnitPriceAfterFavor;			   	//������Ʒ����Żݺ�ļۼ۸�
						$product["discount_price"] = $priceInfoList->dwUnitPriceDiscount;  		//������Ʒ����Ż�
						$product["mult_price_discount"] = 0;//$priceInfoList->dwMultPriceDiscount;	//�ÿ���Ʒ�ǽ��ܲ������Żݽ��
						$product["energy_save_discount"] = $priceInfoList->dwEnergySaveDiscount;//�ÿ���Ʒ���ܲ������Żݽ��
						$product["energy_save_name"] = iconv("utf8", "gbk//IGNORE", $priceInfoList->strEnergySaveName);		//���ܲ����Ż�����
						$product["energy_save_desc"] = iconv("utf8", "gbk//IGNORE", $priceInfoList->strEnergySaveDesc);		//���ܲ����Ż�����
						//$discountName = iconv("utf8", "gbk//IGNORE", $priceInfoList->strPriceDesc);
						$product["discount_p_name"] = iconv("utf8", "gbk//IGNORE", $priceInfoList->strPriceName);				//�������
						$product["discount_p_desc"] = iconv("utf8", "gbk//IGNORE", $priceInfoList->strPriceDesc);				//�������
						//$product["price_buy_limit_rule"] = $priceInfoList->strPriceBuyLimitRule;
						//$product["price_cost_ratio"] = $priceInfoList->strPriceCostRatio;
						//����޹�
						$product["price_buy_limit_flag"] = $priceInfoList->dwPriceBuyLimitFlag;	//����޹���־ 0�����޹���1�����޹�
						$product["mult_limit_num"] = $priceInfoList->dwPriceBuyLimitNum;		//�޹�����£����ɹ�������
						$product["mult_price_op_type"] =  isset($priceInfoList->wPriceOpType) ? $priceInfoList->wPriceOpType : 0;                       //1���ۣ�2���ۣ�3�ۿ�
						$product["mult_price_op_num"] = isset($priceInfoList->dwUnitPriceOpNum) ? intval($priceInfoList->dwUnitPriceOpNum) : "";	    //��Ʒ������۵Ĳ�������������Ʒ��������98�۴� 98����10Ԫ�� 10������Ϊ5Ԫ�� 5
						$product["is_price_rule"] = 0;
						if(3 == $sourceId)
						{
							if(1 == $priceInfoList->wPriceOpType)  //�ۿ�
							{
								$product["discount_price"] = 0;
                                $product["mult_price_op_num"] /= 10;
								$product["discount_p_name"] = $product["mult_price_op_num"] . "���Ż�";
								//���ܲ��������⴦��

                                if(!empty($product["energy_save_discount"]) && $product["energy_save_discount"] != 0)
								{
									//$product["price_before"] = $product["price"];
									$product["discount_price"] = 0;
								}

							}
							else if(2 == $priceInfoList->wPriceOpType)		//�µ�����
							{
                                $product["mult_price_op_num"] /= 100;
								$product["discount_p_name"] = "����". $product["mult_price_op_num"] . "Ԫ";
								$product["discount_price"] = 0;
								$product["mult_price_discount"] = 0;
							}
							else
							{
								$product["discount_p_name"] = "";
								$product["discount_price"] = 0;
								$product["mult_price_discount"] = 0;
							}
								
						}
						else if(4 == $sourceId || 5 == $sourceId || 8 == $sourceId)   //���� ���ݼ۸�
						{
							$product["price_before"] = $product["price"];
							$product["total_price_before"] = $product["total_price_after"];
							$product["discount_price"] = 0;
							//$product["total_price_discount"] = 0;
							$product["mult_price_discount"] = 0;
						}
						else if(6 == $sourceId)   //���ݼ�
						{
							/*
							 * ���ݣ�1�ǵ�N����2����N��
							1steptype@2stepnum:3optype:95opnum
							*/
						
							$product["is_price_rule"] = 1;
							//Logger::info("is_price_rule  ===>".print_r($priceInfoList, true));
							$priceRule = explode("@", $priceInfoList->strPriceRule);
							$priceRuleInfo = explode(":", $priceRule[1]);
                            $priceRuleInfo[2] = intval($priceRuleInfo[2]);
							$product["price_rule_type"] = $priceRule[0];
							$product["mult_price_rule_num"] = $priceRuleInfo[0];
							$product["price_op_ype"] =  $priceRuleInfo[1];
							$product["price_op_num"] = $priceRuleInfo[2];
							$product["need_num"] = $priceInfoList->dwNeedNum;
							//���ݼ�����ʾ��Ѹ�۵�
							//$product["price_before"] = $product["price"];
							$product["total_price_before"] = $product["total_price_after"];
						
							$product["discount_price"] = 0;
							if(1 == $priceRule[0])
							{
								if(3 == $product["price_op_ype"])
								{
									$priceRuleInfo[2] /= 100;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}��{$priceRuleInfo[2]}Ԫ";
								}
								else if(2 == $product["price_op_ype"])
								{
									$priceRuleInfo[2] /= 100;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}����{$priceRuleInfo[2]}Ԫ";
								}
								else if(1 == $product["price_op_ype"])
								{
                                    $priceRuleInfo[2] /= 10;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}��{$priceRuleInfo[2]}��";
								}
								else
								{
									$product["discount_p_name"] = "";
								}
							}
							else if(2 == $priceRule[0])
							{
						
								if(3 == $product["price_op_ype"])
								{
									$priceRuleInfo[2] /= 100;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}��{$priceRuleInfo[2]}Ԫ";
								}
								else if(2 == $product["price_op_ype"])
								{
									$priceRuleInfo[2] /= 100;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}����{$priceRuleInfo[2]}Ԫ";
								}
								else if(1 == $product["price_op_ype"])
								{
                                    $priceRuleInfo[2] /= 10;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}��{$priceRuleInfo[2]}��";
								}
								else
								{
									$product["discount_p_name"] = "";
								}
							}
						}
						
						//$product["price_start_time"] = $priceInfoList->dwPriceStartTime;
						//$product["price_end_time"] = $priceInfoList->dwPriceEndTime;
						break;
					}
				}
			}
		}
		$rules = array();
		$rulesBuyMore = array();
        $rulesNoLogin = array();
		//������Ϣ�б�  ���ܲ����������ε���������
        if($resp->result != 0 && $resp->result != 6490 || 2 == $type)
        {
            //�����������ˣ�ֱ�ӷ��ش�������
            $promtionRule = array(
                "items" => $items,
                "rules" => $rules,
                "rules_buy_more" => $rulesBuyMore,
                "rules_if_login" => $rulesNoLogin
            );
            $strPromoRule = ToolUtil::gbJsonEncode($promtionRule);
            Logger::err("getRuleForShoppingCart Finish[promtionRule:{$strPromoRule}]");
            return $promtionRule;
        }
		$spsOpInfoListOut = $resp->SpsOpInfoListOut;
        //Logger::info("spsOpInfoListOut ".print_r($spsOpInfoListOut, true));
		foreach($spsOpInfoListOut as $spsOpInfo)
		{
			if(2 != $spsOpInfo->dwOpType)
			{
				continue;
			}
            $buyMoreConditionValue = 0;
            $buyMoreDiscountValue = 0;
			$rule =  array();
			$rule["rule_id"] = $spsOpInfo->dwRuleId;
			$rule["rule_sum_value"] = $spsOpInfo->dwRuleSumValue;
			$rule["url"] = $spsOpInfo->strUrl;
			$rule["rule_type"] = $spsOpInfo->dwConditionType;
			$rule["benefit_type"] = $spsOpInfo->dwDiscountType;
			$rule["benefit_times"] = $spsOpInfo->dwStagePriceIndex;
			if(1 == $spsOpInfo->dwUseRuleState)
			{
				$index = $spsOpInfo->dwStagePriceIndex;
				if(0 == $spsOpInfo->dwStagePriceType)
				{
					//�Զ��ݶ�
					$conditionValue = $spsOpInfo->vecConditionValue[0] * $index;

                    if(self::$BenfitTypeNew['BENEFIT_TYPE_COUPON'] == $rule["benefit_type"])
                    {
                        $discountValue = $spsOpInfo->vecDiscountValue[0];
                    }
                    else
                    {
                        $discountValue = $spsOpInfo->vecDiscountValue[0] * $index;
                    }

					if($index < $spsOpInfo->dwAutoStageMax)
					{
						$buyMoreConditionValue = $spsOpInfo->vecConditionValue[0] * ($index + 1);
                        if(self::$BenfitTypeNew['BENEFIT_TYPE_COUPON'] == $rule["benefit_type"])
                        {
                            $buyMoreDiscountValue = $spsOpInfo->vecDiscountValue[0];
                        }
                        else
                        {
                            $buyMoreDiscountValue = $spsOpInfo->vecDiscountValue[0] * ($index + 1);
                        }
					}
				}
				else
				{
					//�ֶ��ݶ�
                    $conditionValue = $spsOpInfo->vecConditionValue[$index - 1];
                    $discountValue = $spsOpInfo->vecDiscountValue[$index - 1];
                    if(self::$BenfitTypeNew['BENEFIT_TYPE_COUPON'] == $rule["benefit_type"])
                    {
                        $rule["benefit_times"] = 1;
                    }
					if($index < $spsOpInfo->dwAutoStageMax)
					{
						$buyMoreConditionValue =  $spsOpInfo->vecConditionValue[$index];
						$buyMoreDiscountValue = $spsOpInfo->vecDiscountValue[$index];
					}
				}
				$rule["condition"] = $conditionValue;
				$rule["benefits"] = $discountValue;
				$rule["desc"] = iconv("utf8", "gbk//IGNORE", $spsOpInfo->strOpInfo);
				self::appendNameOfRule($rule);
				$rules[] = $rule;
				//�ж��Ƿ�����ݶ�
				if(0 != $buyMoreConditionValue)
				{
					$rule["buy_more"] = $spsOpInfo->dwUnfillDiffValue;
					$rule["condition"] = $buyMoreConditionValue;
					$rule["benefits"] = $buyMoreDiscountValue;
					$rule["desc"] = iconv("utf8", "gbk//IGNORE", $spsOpInfo->strOpInfo);
					self::appendNameOfRule($rule);
					$rulesBuyMore[] = $rule;
				}
			}
			else if(2 == $spsOpInfo->dwUseRuleState)
			{
				$rule["buy_more"] = $spsOpInfo->dwUnfillDiffValue;
				$rule["condition"] = $spsOpInfo->vecConditionValue[0];
				$rule["benefits"] = $spsOpInfo->vecDiscountValue[0];
				$rule["desc"] = iconv("utf8", "gbk//IGNORE", $spsOpInfo->strOpInfo);
				self::appendNameOfRule($rule);
				$rulesBuyMore[] = $rule;
			}
            else if(3 == $spsOpInfo->dwUseRuleState)
            {
                $rule["buy_more"] = 0;
                $rule["condition"] = $spsOpInfo->vecConditionValue[0];
                $rule["benefits"] = $spsOpInfo->vecDiscountValue[0];
                $rule["desc"] = iconv("utf8", "gbk//IGNORE", $spsOpInfo->strOpInfo);
                self::appendNameOfRule($rule);
                $rulesNoLogin[] = $rule;
            }
		}

		$promtionRule = array(
				"items" => $items,
				"rules" => $rules,
				"rules_buy_more" => $rulesBuyMore,
				"rules_if_login" => $rulesNoLogin,
		);
		$strPromoRule = ToolUtil::gbJsonEncode($promtionRule);
		Logger::info("getRuleForShoppingCart Finish[promtionRule:{$strPromoRule}]");
		return $promtionRule;
	}

	/**
	 * ����ȷ��ҳ�����ɶ�������������֤�ӿ�
	 * @param array $items
	 * @param number $whId
	 * @param number $uid
	 * @param number $ruleId
	 * @param number $type
	 * @return array
	 */
	public static function checkRuleForOrder($items, $whId, $uid, $ruleId, $type=1, $scene = SCENE_SHOPPING_CART)
	{

		if (!is_array($items) || count($items) == 0 || ($type != 1 && $type != 2)) {
			self::$errCode = 105;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkRuleForOrder para Error!]";
			Logger::err("checkRuleForOrder para error!:[uid:{$uid}][whid:{$whId}][rule_id{$ruleId}][type[$type]]");
			return false;
		}

		$strItems = ToolUtil::gbJsonEncode($items);
		Logger::info("checkRuleForOrder start:[items:{$strItems}][whid:{$whId}][ruleid:{$ruleId}][type:{$type}][uid:{$uid}]");
        $uid = intval($uid);
        self::_initCntl($uid);
		$req = new CheckPromotionInfoReq();
		$resp = new CheckPromotionInfoResp();
		//��ȡ�ܼۡ��ܼ������ܿ���
		$totalClassNum = count($items);
		$totalNum = 0;
		foreach($items as $product)
		{
			$totalNum += $product['buy_count'];
		}
		$req->uin = $uid;
		$req->source= __FILE__;
		$req->scene = $type;
		$req->itemClassNum = $totalClassNum;
		$req->itemNum = $totalNum;
		$req->whId = $whId;
		$ruleIds = array();
		if(0 != $ruleId)
		{
			$ruleIds[] = intval($ruleId);
		}
		$req->rulelId->setValue($ruleIds);
		$spsItemListIn = array();
		reset($items);
		self::_reqConstruct($req, $items);
        $strReq = ToolUtil::gbJsonEncode($req);
        global $shoppingProcessItil;
        ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['req']);
        $ret = self::$cntl->invoke($req, $resp, 3);
        
		//����6952����������������Ҫ��
		self::$cntl = false;
		if (0 != $ret)
        {
            ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['failed']);
			self::$errCode = 106;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkRuleForOrderNew invoke failed!]";
			Logger::err("checkRuleForOrder invoke return![ret:{$ret}][errCode:{$resp->errCode}][items:{$strItems}][whid:{$whId}][ruleid:{$ruleId}][type:{$type}][uid:{$uid}]");
			return  false;
		}
        if ($resp->result != 0)
        {
            ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['failed']);
            self::$errCode = 107;
            self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkRuleForOrderNew invoke failed!]";
            Logger::err("checkRuleForOrder  return Error![result:{$resp->result}][items:{$strItems}][whid:{$whId}][ruleid:{$ruleId}][type:{$type}][uid:{$uid}]");
            return  false;
        }
		if($resp->errCode != 0 && $resp->errCode != 6952)
		{
            ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['failed']);
			self::$errCode = 108;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkRuleForOrderNew promotion rule Error!][errCode:{$resp->errCode}]";
			Logger::err("checkRuleForOrder promotion rule Error![ret:{$ret}][errCode:{$resp->errCode}][items:{$strItems}][whid:{$whId}][ruleid:{$ruleId}][type:{$type}][uid:{$uid}]");
			return  false;
		}
		if($resp->errCode == 6952)
		{
            ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['failed']);
			self::$errCode = self::$ERROR_RESTRICT;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkRuleForOrderNew promotion rule restrict!][errCode:{$resp->errCode}]";
			Logger::err("checkRuleForOrder promotion rule restrict![ret:{$ret}][errCode:{$resp->errCode}][items:{$strItems}][whid:{$whId}][ruleid:{$ruleId}][type:{$type}][uid:{$uid}]");
			return  false;
		}
        ItilReport::itil_report($shoppingProcessItil[$scene]['promotion']['succ']);
		if($totalClassNum != count($resp->SpsItemListOut))
		{
			self::$errCode = 110;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkRuleForOrderNew totalClassNum not equal mutl return num!]";
			$tmpCount = count($resp->SpsItemListOut);
			Logger::err("checkRuleForOrderNew totalClassNum not equal mutl return num![totalClassNum:{$totalClassNum}][count<resp->SpsItemListOut>:{$tmpCount}][whid:{$whId}][ruleid:{$ruleId}][type:{$type}][uid:{$uid}]");
			return  false;
		}
		
		//����У����������Ƿ���ȷ
		$spsOpInfoListOut = $resp->SpsOpInfoListOut;
        $promotion = array();
		foreach($spsOpInfoListOut as $spsOpInfo)
		{
			if(2 != $spsOpInfo->dwOpType)
			{
				continue;
			}
            if(1 == $spsOpInfo->dwUseRuleState)
            {
                $promotion["rule_id"] = $spsOpInfo->dwRuleId;
                $promotion["rule_sum_value"] = $spsOpInfo->dwRuleSumValue;
                $promotion["url"] = $spsOpInfo->strUrl;
                $promotion["rule_type"] = $spsOpInfo->dwConditionType;
                $promotion["benefit_type"] = $spsOpInfo->dwDiscountType;
                $promotion["benefit_times"] = $spsOpInfo->dwStagePriceIndex;
                $promotion["is_restrict"] = $resp->errCode == 6952 ? 1 : 0;
                $promotion["stage_price_type"] = $spsOpInfo->dwStagePriceType;

				$index = $spsOpInfo->dwStagePriceIndex;
				if(0 == $spsOpInfo->dwStagePriceType)
				{
					//�Զ��ݶ�
                    $conditionValue = $spsOpInfo->vecConditionValue[0] * $index;
                    if(self::$BenfitTypeNew['BENEFIT_TYPE_COUPON'] == $promotion["benefit_type"])
                    {
                        $discountValue = $spsOpInfo->vecDiscountValue[0];
                    }
                    else
                    {
                        $discountValue = $spsOpInfo->vecDiscountValue[0] * $index;
                    }
				}
				else
				{
					//�ֶ��ݶ�
                    $conditionValue = $spsOpInfo->vecConditionValue[$index-1];
                    if(self::$BenfitTypeNew['BENEFIT_TYPE_COUPON'] == $promotion["benefit_type"])
                    {
                        $promotion["benefit_times"] = 1;
                        $discountValue = $spsOpInfo->vecDiscountValue[$index-1];
                    }
                    else
                    {
                        $discountValue = $spsOpInfo->vecDiscountValue[$index-1];
                    }
				}
				$promotion["condition"] = $conditionValue;
				$promotion["benefits"] = $discountValue;
				$promotion["desc"] = iconv("utf8", "gbk//IGNORE", $spsOpInfo->strOpInfo);
				//��������ֻ������һ��
			}
		}


		if($ruleId != 0)
		{
           if(isset($promotion["rule_id"]) && $promotion["rule_id"] != $ruleId)
           {
               $tmpCount = isset($spsOpInfoListOut) ? count($spsOpInfoListOut) : 0;
               $tmpRuleId = isset($promotion["rule_id"]) ? $promotion["rule_id"] : 0;

               self::$errCode = 111;
               self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[rule id error ][count promotion: {$tmpCount}][sps rule_id:{$tmpRuleId}][rule_id{$ruleId}]";
               Logger::err("checkRuleForOrder rule id error![count promotion :{$tmpCount}][sps rul_id:{$tmpRuleId}][whid:{$whId}][ruleid:{$ruleId}][type:{$type}][uid:{$uid}]");
               return false;
           }
           else if(empty($promotion))
           {
               $promotion = array();
           }
		}
		else
		{
			$promotion = array();
		}
		
		//��������
		$spsItemListOut = $resp->SpsItemListOut;
		$promotionRuleInfo = array();
		reset($items);
		foreach($items as &$product)
		{
			foreach($spsItemListOut as $spsItem)
			{
				if($spsItem->strItemId == $product["product_id"])
				{
					if($product["package_id"] != 0)
					{
						if($spsItem->dwItemType != 1)
						{
							continue;
						}
					}
                    else if($product["match_num"] > 0)
                    {
                        if($spsItem->dwItemType != 2)
                        {
                            continue;
                        }
                    }
					else
					{
						if($spsItem->dwItemType != 0)
						{
							continue;
						}
					}
					
					//�����Ʒ�д��������Ǵ�������
					if($product["package_id"] > 0)
					{
						$product["promotion_price"] = $spsItem->dwItemPromotionPrice + ($product["pkg_cash_back"]*$product["buy_count"]); 				//��Ʒ����������۸� n��
						$product["promotion_discount"] = $spsItem->dwItemPromotionDiscount;			//��Ʒ���������Ż�  n��
					}
                    else if($product["match_num"] > 0)
                    {
                        $product["promotion_price"] = $spsItem->dwItemPromotionPrice + ($product["match_cut"]*$product["match_num"]); 				//��Ʒ����������۸� n��
                        $product["promotion_discount"] = $spsItem->dwItemPromotionDiscount;			//��Ʒ���������Ż�  n��
                    }
					else
					{
						$product["promotion_price"] = $spsItem->dwItemPromotionPrice;				//��Ʒ����������۸� n��
						$product["promotion_discount"] = $spsItem->dwItemPromotionDiscount;			//��Ʒ���������Ż�  n��
					}
                    /*
					$product["promotion_price"] = $spsItem->dwItemPromotionPrice;				//��Ʒ����������۸� n��
					$product["promotion_discount"] = $spsItem->dwItemPromotionDiscount;			//��Ʒ���������Ż�  n��
					*/
					//����·��:��ۺʹ�������
					$spsItemOpPathList = $spsItem->vecSpsItemOpPathList;
					$product["op_path"] = array();
					foreach($spsItemOpPathList as $spsItemOpPath)
					{
						$opPath = array();
						$opPath["type"] = $spsItemOpPath->dwRuleType;
						$opPath["before_price"] = $spsItemOpPath->dwBeforePrice;
						$opPath["after_price"] = $spsItemOpPath->dwAfterPrice;
						$opPath["rule_id"] = $spsItemOpPath->dwRuleId;
						$opPath["rule_desc"] = iconv("utf8", "gbk//IGNORE", $spsItemOpPath->strDescInfo);
						$opPath["rule_discount_info"] = $spsItemOpPath->strDiscountInfo;
						$opPath["rule_discount_type"] = $spsItemOpPath->dwDiscountType;                    //1����2ȯid��3�ۿۣ�4��Ʒid��5���֣�6�ۿ�
						$opPath["rule_condition_Info"] = $spsItemOpPath->strConditionInfo;
						$opPath["rule_condition_type"] = $spsItemOpPath->dwConditionType;
						$opPath["rule_condition_index"] = $spsItemOpPath->dwConditionIndex;
						$opPath["rule_condition_info"] = $spsItemOpPath->strConditionInfo;
						$opPath["rule_condition_type"] = $spsItemOpPath->dwConditionType;
						$opPath["rule_condition_index"] = $spsItemOpPath->dwConditionIndex;
						$opPath["rule_cost_type"] = $spsItemOpPath->dwPriceCoster;
						if(1 == $opPath["type"])
						{
							$product["op_path"]["op_path_mult"][] = $opPath;
						}
						else if(2 == $opPath["type"])
						{
							$promotionRuleInfo[$opPath["rule_id"]]["pids"][] = $product["product_id"];
							$promotionRuleInfo[$opPath["rule_id"]]["account_type"] = $spsItemOpPath->dwPriceCoster;
							$product["op_path"]["op_path_full_discount"][] = $opPath;
						}
					}
					//���
					if($product["package_id"] > 0 || $product["match_num"] > 0)
					{
						$product["total_price_before"] = $product["price"]* $product["buy_count"];
						$product["total_price_after"] = $product["price"]* $product["buy_count"];
						$product["total_price_discount"] = 0;
						$product["price_before"] = $product["price"];
						$product["price"] = $product["price"];
						$product["discount_price"] = 0;
						$product["mult_price_discount"] = 0;
						$product["energy_save_discount"] = 0;
						$product["energy_save_name"] = "";
						$product["energy_save_desc"] = "";
						$product["discount_p_name"] = "";
						$product["discount_p_desc"] = "";
						$product["price_buy_limit_rule"] = "";
						//����޹�
						$product["price_buy_limit_flag"] = 0;
						$product["mult_limit_num"] = 0;
						$product["price_cost_ratio"] = 0;
						$product["price_scene_id"] = 0;
						$product["price_source_id"] = 0;
						$product["mult_price_op_type"] = 0;
						$product["mult_price_op_num"] = 0;
						$product["is_price_rule"] = 0;
						$product["price_start_time"] = 0;
						$product["price_end_time"] = 0;
						break;
					}
					else
					{
						$priceInfoList = $spsItem->vecPriceInfoList[0];
						$product["total_price_before"] = $priceInfoList->dwPriceBeforeFavor;    //�ÿ���Ʒ���Ż�ǰ�۸���n����Ʒ����Ϊn����ֵ
						$product["total_price_after"] = $priceInfoList->dwPriceAfterFavor;		//�ÿ���Ʒ��۵��Żݺ�۸���n����Ʒ����Ϊn����ֵ
						$product["total_price_discount"] = $priceInfoList->dwPriceDiscount;      //�ÿ���Ʒ����ܵ��Ż�
						$product["price_before"] = $priceInfoList->dwUnitPriceBeforeFavor;		//������Ʒ�Ż�ǰ�۸�
						$product["price"] = $priceInfoList->dwUnitPriceAfterFavor;			   	//������Ʒ����Żݺ�ļۼ۸�
						$product["discount_price"] = $priceInfoList->dwUnitPriceDiscount;  		//������Ʒ����Ż�
						$product["mult_price_discount"] = $priceInfoList->dwMultPriceDiscount;	//�ÿ���Ʒ�ǽ��ܲ������Żݽ��
						$product["energy_save_discount"] = $priceInfoList->dwEnergySaveDiscount;//�ÿ���Ʒ���ܲ������Żݽ��
                        $product["promotion_price"] = 2 == $type ? $priceInfoList->dwPriceAfterFavor : $product["promotion_price"];
                        $product["energy_save_name"] = iconv("utf8", "gbk//IGNORE", $priceInfoList->strEnergySaveDesc);
						$product["energy_save_desc"] = iconv("utf8", "gbk//IGNORE", $priceInfoList->strEnergySaveName);
						$product["discount_p_name"] = iconv("utf8", "gbk//IGNORE", $priceInfoList->strPriceName);
						$product["discount_p_desc"] = iconv("utf8", "gbk//IGNORE", $priceInfoList->strPriceDesc);
						$product["price_buy_limit_rule"] = $priceInfoList->strPriceBuyLimitRule;
						//����޹�
						$product["price_buy_limit_flag"] = $priceInfoList->dwPriceBuyLimitFlag;
						$product["mult_limit_num"] = $priceInfoList->dwPriceBuyLimitNum;
						$product["price_cost_ratio"] = $priceInfoList->strPriceCostRatio;
						$product["price_scene_id"] = $priceInfoList->ddwPriceSceneId;
						$product["price_source_id"] = $priceInfoList->ddwPriceSourceId;
                        $sourceId = $priceInfoList->ddwPriceSourceId;
                        $sceneId = $priceInfoList->ddwPriceSceneId;
						$product["mult_price_op_type"] =  isset($priceInfoList->wPriceOpType) ?$priceInfoList->wPriceOpType : 0;                       //1���ۣ�2���ۣ�3�ۿ�
						$product["mult_price_op_num"] = intval($priceInfoList->dwUnitPriceOpNum);	    //��Ʒ������۵Ĳ�������������Ʒ��������98�۴� 98����10Ԫ�� 10������Ϊ5Ԫ�� 5
						$product["is_price_rule"] = 0;
							
						if(3 == $sourceId)
						{
							if(3 == $priceInfoList->wPriceOpType)  //�ۿ�
							{
                                $product["mult_price_op_num"] /= 10;
								$product["discount_p_name"] = $product["mult_price_op_num"] . "���Ż�";
							}
							else if(2 == $priceInfoList->wPriceOpType)		//�µ�����
							{
                                $product["mult_price_op_num"] /= 100;
								$product["discount_p_name"] = "����{$product["mult_price_op_num"]}Ԫ";
							}
							else
							{
								$product["discount_p_name"] = "";
							}
								
						}
						else if(5 == $sourceId || 4 == $sourceId || 8 == $sourceId)   //���� ���ݼ۸�
						{
						
						}
						else if(6 == $sourceId)   //���ݼ�
						{
							/*
							 * ���ݣ�1�ǵ�N����2����N��
							1steptype@2stepnum:3optype:95opnum
							*/
							$product["is_price_rule"] = 1;
							$priceRule = explode("@", $priceInfoList->strPriceRule);
                            $priceRuleInfo = explode(":", $priceRule[1]);
                            $priceRuleInfo[2] = intval($priceRuleInfo[2]);
							$priceRuleInfo = explode(":", $priceRule[1]);
							$product["price_rule_type"] = $priceRule[0];
							$product["mult_price_rule_num"] = $priceRuleInfo[0];
							$product["price_op_ype"] =  $priceRuleInfo[1];
							$product["mult_price_op_num"] = $priceRuleInfo[2];
							$product["need_num"] = $priceInfoList->dwNeedNum;
                            if($product['buy_count'] < $product["mult_price_op_num"])
                            {
                                $product["price_scene_id"] = 2;				//�ݶȹ������� ʹ����Ѹ����id ���ۼ�¼
                                $product["price_source_id"] = 2;			//
                            }
							//���ݼ�����ʾ��Ѹ�۵�
							$product["price_before"] = $product["price"];
							$product["discount_price"] = 0;
							if(1 == $priceRule[0])
							{
								if(1 == $product["price_op_ype"])
								{
									$priceRuleInfo[2] /= 100;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}��{$priceRuleInfo[2]}Ԫ";
								}
								else if(2 == $product["price_op_ype"])
								{
									$priceRuleInfo[2] /= 100;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}����{$priceRuleInfo[2]}Ԫ";
								}
								else if(3 == $product["price_op_ype"])
								{
                                    $priceRuleInfo[2] /= 10;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}��{$priceRuleInfo[2]}��";
								}
								else
								{
									$product["discount_p_name"] = "";
								}
							}
							else if(2 == $priceRule[0])
							{
									
								if(1 == $product["price_op_ype"])
								{
									$priceRuleInfo[2] /= 100;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}��{$priceRuleInfo[2]}Ԫ";
								}
								else if(2 == $product["price_op_ype"])
								{
									$priceRuleInfo[2] /= 100;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}����{$priceRuleInfo[2]}Ԫ";
								}
								else if(3 == $product["price_op_ype"])
								{
                                    $priceRuleInfo[2] /= 10;
									$product["discount_p_name"] = "��{$priceRuleInfo[0]}��{$priceRuleInfo[2]}��";
								}
								else
								{
									$product["discount_p_name"] = "";
								}
							}
						}
						$product["price_start_time"] = $priceInfoList->dwPriceStartTime;
						$product["price_end_time"] = $priceInfoList->dwPriceEndTime;
						break;
					}
				}
			}
		}
		if($ruleId != 0  && isset($promotion["rule_id"]) && $ruleId == $promotion["rule_id"])
		{
			$promotion["pids"] = $promotionRuleInfo[$ruleId]["pids"];
			$promotion["account_type"] = $promotionRuleInfo[$ruleId]["account_type"];
		}
		$restrictParamList = $resp->restrictParamList;
		$restrictOut = array();
		//�������������
		foreach($restrictParamList as $restrict)
		{
			$restrictParam = array();
			$bussinessId = $restrict->dwBussinessId;
			$restrictParam["bussiness_id"] = $restrict->dwBussinessId;
			$restrictParam["edm_1"] = $restrict->dwEdm1;
			$restrictParam["edm_2"] = $restrict->ddwEdm2;
			$restrictParam["edm_3"] = $restrict->strEdm3;
			$restrictParam["num"] = $restrict->dwNum;
			$restrictParam["is_restrict"] = $restrict->cIsRestrict;
			$restrictParam["sur_plus"] = $restrict->dwSurplus;
			$restrictParam["threshold"] = $restrict->dwThreshold;
			$restrictParam["deduct_time"] = $restrict->dwDwDeductTime;
			$restrictParam["desc"] = $restrict->strDesc;
			//100��� 101����
			/*
			if(100 == $bussinessId)
			{
				$restrictOut['mult'][] = $restrictParam;
			}
			else if(101 == $bussinessId)
			{
				$restrictOut['fulldiscount'][] = $restrictParam;
			}
			*/
			$restrictOut[] = $restrictParam;
		}
		//����Դ���У��
		$promtionRule = array(
				"items" => $items,
				"promotion" => $promotion,
				"restrict" => $restrictOut			//���ۼ�ʹ�ã�ǰ��û����
		);
		$strPromoRule = ToolUtil::gbJsonEncode($promtionRule);
		Logger::info("checkRuleForOrder Finish[promtionRule:{$strPromoRule}]");
		return $promtionRule;
	}

	/**
	 * ��ȡ��Ʒ�Ķ����Ϣ
	 * @param array $items
	 * @param number $whId
	 * @param number $type
	 * @param number $uid
	 * @return boolean|unknown
	 */
	public static function checkItmeMultPriceRestrict($items, $whId, $type=1, $uid=0){
		$strItems = ToolUtil::gbJsonEncode($items);
		Logger::info("checkItmeMultPriceRestrict start:[items:{$strItems}][whid:{$whId}][type:{$type}][uid:{$uid}]");
		if (!is_array($items) || count($items) == 0 ) {
			self::$errCode = 112;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkItmeMultPriceRestrict para Error!]";
			Logger::err("checkItmeMultPriceRestrict para error![strItems{$strItems}][whid:{$whId}][type:{$type}][uid:{$uid}]");
			return false;
		}
        $uid = intval($uid);
		self::_initCntl($uid);
		$req = new CalcMultPriceReq();
		$resp = new CalcMultPriceResp();
		$req->machineKey = ToolUtil::getClientIP();
		$req->source = __FILE__;
		$req->sceneId = $type;
		$req->uin = $uid;
		$req->whId = $whId;
		$req->regionId = 0;
		$req->channelId = "";
		
		$spsItemListIn = array();
		reset($items);
		foreach($items as $product)
		{
			if($product['package_id'] > 0)
			{
				continue;
			}
			$spsItem = new SpsItemBo();
			$spsItem->strItemId = $product['product_id'];
			$spsItem->cItemId_u = 1;
			$spsItem->dwMetaId = $product['c3_ids'];
			$spsItem->cMetaId_u = 1;
			$spsItem->dwItemWareHouseid = $product['psystock'];
			$spsItem->cItemWareHouseid_u = 1;
			if(isset($product['chid']) && !empty($product['chid']))
			{
				$sourceScene = explode("@", $product['chid']);
				if(count($sourceScene) > 0)
				{
					$sourceScene = array_unique($sourceScene);
                    foreach($sourceScene as &$ss)
                    {
                        $ss = intval($ss);
                    }
					$spsItem->setActId = new stl_set();
					$spsItem->setActId->setValue($sourceScene);
					$spsItem->cActId_u = 1;
				}
			}
			$spsItem->cEdmCode_u = 0;
			$spsItem->dwItemPrice = $product['price'] * $product['buy_count'];
			$spsItem->cItemPrice_u = 1;
			$spsItem->dwItemUnitPrice = $product['price'];
			$spsItem->cItemUnitPrice_u = 1;
			$spsItem->dwItemNum = $product['buy_count'];
			$spsItem->cItemNum_u = 1;
			$spsItem->dwPkgId = $product['package_id'];
			$spsItem->cPkgId_u = 1;
			$spsItem->dwItemType = ($product['package_id'] != 0)? 1 : (($product['match_num'] >0)? 2:0);	//����Ҫע��ǰ����Ҫ�����ײ������������߻�������
			$spsItem->cItemType_u = 1;
			$spsItemListIn[$product['product_id']] = $spsItem;
		}
		$req->ItemPriceInfoListIn->setType('stl_string', 'SpsItemBo');
		$req->ItemPriceInfoListIn->setValue($spsItemListIn);
        ItilReport::itil_report(MULPRICE_QUIRE);
		$ret = self::$cntl->invoke($req, $resp, 3);
		
		//Logger::info("checkItmeMultPriceRestrict invoke return:[ret:{$ret}][errCode:{$resp->errCode}]");
		if (0 != $ret) {
            ItilReport::itil_report(MULPRICE_FAILED);
			self::$errCode = 113;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkItmeMultPriceRestrict invoke failed!]";
			Logger::err("checkItmeMultPriceRestrict invoke failed![ret:{$ret}][errCode:{$resp->errCode}][strItems{$strItems}][whid:{$whId}][type:{$type}][uid:{$uid}]");
			return  false;
		}
        if ($resp->result != 0)
        {
            ItilReport::itil_report(MULPRICE_FAILED);
            self::$errCode = 114;
            self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkRuleForOrderNew invoke failed!]";
            Logger::err("checkItmeMultPriceRestrict  return Error![result:{$resp->result}][strItems{$strItems}][whid:{$whId}][strItems{$strItems}][type:{$type}][uid:{$uid}]");
            return  false;
        }
        ItilReport::itil_report(MULPRICE_SUCC);
		//Logger::info("resp==>".print_r( $resp->restrictParamList, true));
		//��������
		$restrictParamInfo = $resp->restrictParamList;
		foreach($items as &$product)
		{
			$product["mult_limit"] = 0;
			$product["mult_limit_num"] = 0;
			if($product['package_id'] == 0)
			{
				//��ͨ��Ʒ
				foreach($restrictParamInfo as $restrict)
				{
					$productId = explode("+", $restrict->strEdm3);
					$productId = $productId[0];
					if($productId == $product["product_id"])
					{
						//��Ʒ�ṹ�������޹���Ϣ
						$product["mult_limit"] = $restrict->cIsRestrict;
						$product["mult_limit_num"] = $restrict->dwSurplus;
						break;
					}
				}
			}
			/*
			else
			{
				$product["mult_limit"] = 0;
				$product["mult_limit_num"] = 0;
			}
			*/
		}
		$strItems = ToolUtil::gbJsonEncode($items);
		Logger::info("checkItmeMultPriceRestrict Finish[strItems:{$strItems}]");
		return $items;
	}

	public static function dealPromotionRestrict($restricts, $uid)
	{
		if (!is_array($restricts) || count($restricts) == 0 ) {
			return "";
		}
		$strRestrict = ToolUtil::gbJsonEncode($restricts);
		Logger::info("dealPromotionRestrict Start[restricts:{$strRestrict}][uid:{$uid}]");
        $uid = intval($uid);
        self::_initCntl($uid);
		$req = new GetDealBatchPromotionRestrictReq();
		$resp = new GetDealBatchPromotionRestrictResp();
	
		$req->machineKey = '0';
		$req->source= __FILE__;
		$req->sceneId = 0;
		$req->uin = $uid;
		$restrictParam = array();
		foreach($restricts as $restrict)
		{
				$restrictParam = new PromotionRestrictParamInfo_Bo();
				$restrictParam->dwBussinessId = $restrict['bussiness_id'];
				$restrictParam->dwEdm1 = $restrict['edm_1'];
				$restrictParam->ddwEdm2 = $restrict['edm_2'];
				$restrictParam->strEdm3 = $restrict['edm_3'];
				$restrictParam->dwNum =$restrict['num'];
				$restrictParam->dwDwDeductTime = $restrict['deduct_time'];
				$restrictParamListIn[] = $restrictParam;
		}
	
		$req->restrictParamListIn = new stl_vector();
		$req->restrictParamListIn->setValue($restrictParamListIn);

        ItilReport::itil_report(LIMITSUB_QUIRE);
		$ret = self::$cntl->invoke($req, $resp, 3);
		//Logger::info("dealPromotionRestrict invoke return [ret:{$ret}]");
		self::$cntl = false;
		if (0 != $ret) {
            ItilReport::itil_report(LIMITSUB_FAILED);
			self::$errCode = 115;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[dealPromotionRestrict invoke failed!]";
			Logger::err("dealPromotionRestrict invoke failed![ret:{$ret}][errCode:{$resp->errCode}][strRestrict{$strRestrict}][uid:{$uid}]");
			return  false;
		}

        if ($resp->result != 0)
        {
            ItilReport::itil_report(LIMITSUB_FAILED);
            self::$errCode = 116;
            self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkRuleForOrderNew invoke failed!]";
            Logger::err("checkItmeMultPriceRestrict  return Error![result:{$resp->result}][strRestrict{$strRestrict}][uid:{$uid}]");
            return  false;
        }
        ItilReport::itil_report(LIMITSUB_SUCC);

		$restrictParamListOut = $resp->restrictParamListOut;
		$restrictOut = array();
		foreach($restrictParamListOut as $restrict)
		{
			$restrictParam = array();
			$restrictParam["bussiness_id"] = $restrict->dwBussinessId;
			$restrictParam["edm_1"] = $restrict->dwEdm1;
			$restrictParam["edm_2"] = $restrict->ddwEdm2;
			$restrictParam["edm_3"] = $restrict->strEdm3;
			$restrictParam["num"] = $restrict->dwNum;
			$restrictParam["deduct_time"] = $restrict->dwDwDeductTime;
			$restrictOut[] = $restrictParam;
		}
		
		$strRestrictOut = ToolUtil::gbJsonEncode($restrictOut);
		Logger::info("dealPromotionRestrict Finish[strRestrictOut:{$strRestrictOut}]");
		return array('restrict' => $restrictOut);
	}
	
	public static function rollbackPromotionRestrict($restricts, $uid)
	{
		if (!is_array($restricts) || count($restricts) == 0 ) {
			return "";
		}

		$strRestrict = ToolUtil::gbJsonEncode($restricts);
		Logger::info("rollbackPromotionRestrict Start[restricts:{$restricts}][uid:{$uid}]");
        $uid = intval($uid);
        self::_initCntl($uid);
		$req = new RollbackDealBatchPromotionRestrictReq();
		$resp = new RollbackDealBatchPromotionRestrictResp();
	
		$req->machineKey = '0';
		$req->source= __FILE__;
		$req->sceneId = 0;
		$req->uin = $uid;
		$restrictParam = array();
		foreach($restricts as $restrict)
		{
			$restrictParam = new PromotionRestrictParamInfo_Bo();
			$restrictParam->dwBussinessId = $restrict['bussiness_id'];
			$restrictParam->dwEdm1 = $restrict['edm_1'];
			$restrictParam->ddwEdm2 = $restrict['edm_2'];
			$restrictParam->strEdm3 = $restrict['edm_3'];
			$restrictParam->dwNum =$restrict['num'];
			$restrictParam->dwDwDeductTime = $restrict['deduct_time'];
			$restrictParamListIn[] = $restrictParam;
		}
	
		$req->restrictParamListIn = new stl_vector();
		$req->restrictParamListIn->setValue($restrictParamListIn);
        ItilReport::itil_report(LIMITROLL_QUIRER);
		$ret = self::$cntl->invoke($req, $resp, 3);
		self::$cntl = false;
		//Logger::info("rollbackPromotionRestrict invoke return [ret:{$ret}]");
		if (0 != $ret) {
            ItilReport::itil_report(LIMITROLL_FAILED);
			self::$errCode = 117;
			self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[rollbackPromotionRestrict invoke failed!]";
			Logger::err("rollbackPromotionRestrict invoke failed![ret:{$ret}][errCode:{$resp->errCode}][strRestrict{$strRestrict}][uid:{$uid}]");
			return  false;
		}
        if ($resp->result != 0)
        {
            ItilReport::itil_report(LIMITROLL_FAILED);
            self::$errCode = 118;
            self::$errMsg = basename(__FILE__, '.php') . " |" . __LINE__ . "[checkRuleForOrderNew invoke failed!]";
            Logger::err("rollbackPromotionRestrict  return Error![result:{$resp->result}][strRestrict{$strRestrict}][uid:{$uid}]");
            return  false;
        }

        ItilReport::itil_report(LIMITROLL_SUCC);
		return true;
	}
	
	/**
	 * �����������ƹ���
	 * @param array $ruleInfo
	 */
	public static function appendNameOfRule(&$ruleInfo){
		if(!empty($ruleInfo) && !empty($ruleInfo['rule_type']) && !empty($ruleInfo['benefit_type'])
		&& isset(self::$RuleTypeName[$ruleInfo['rule_type']]) && isset(self::$BenfitTypeName[$ruleInfo['benefit_type']]))
		{
	
			$ruleTypeName = self::$RuleTypeName[$ruleInfo['rule_type']];
			if($ruleInfo['rule_type'] == self::$RuleType["RULE_TYPE_CASH_AMT"])
			{
				$amt = $ruleInfo['condition']/100;
				//if($amt <= 10) $amt .= 'Ԫ';
				$amt .= 'Ԫ';
				$ruleTypeName = str_replace("{_cash_amt_}", $amt, $ruleTypeName);
			}
			else if($ruleInfo['rule_type'] == self::$RuleType["RULE_TYPE_BUY_NUM"])
			{
				$ruleTypeName = str_replace("{_buy_num_}", $ruleInfo['condition'], $ruleTypeName);
			}
	
			$benfitTypeName = self::$BenfitTypeName[$ruleInfo['benefit_type']];
			if($ruleInfo['benefit_type'] == 5)
			{
				$benfitTypeName = str_replace("{_point_}", $ruleInfo['benefits'], $benfitTypeName);
			} else if($ruleInfo['benefit_type'] == 1)
			{
				//$cash = sprintf("%d", $ruleInfo['benefits']/100);
				//if($cash <= 10) $cash .= 'Ԫ';
				$cash = $ruleInfo['benefits']/100;
				$cash .= 'Ԫ';
				$benfitTypeName = str_replace("{_cash_}", $cash, $benfitTypeName);
			}
			else if($ruleInfo['benefit_type'] == 3)
			{
				$discountName = '';
				if($ruleInfo['benefits'] % 10 == 0)
				{
					$discountName = $ruleInfo['benefits'] / 10;
				} else {
					$discountName = $ruleInfo['benefits'];
				}
				$discountName .= '��';
				$benfitTypeName = str_replace("{_discount_name_}", $discountName, $benfitTypeName);
			}
			else if($ruleInfo['benefit_type'] == 2)
			{
				$discountName = '';
				
				$benfitTypeName = $benfitTypeName;//str_replace("{_discount_name_}", $discountName, $benfitTypeName);
			}
	
			$ruleInfo['name'] = $ruleTypeName . $benfitTypeName;
		}
	}
    /**
     * ͬ���ű�ʹ��
     */
    public static function getPromtionRuleInfo($ruleId){
        self::_initCntl(0);
        $req = new GetRuleForGuanguanReq();
        $resp = new GetRuleForGuanguanResp();
        $req->uin = 0;
        $req->source = __FILE__;
        $req->scene = 0;
        $req->ruleId = intval($ruleId);
        $ret = self::$cntl->invoke($req, $resp, 3);
        if (0 != $ret || $resp->result != 0)
        {
            return  false;
        }
        else{
            $ruleInfo = array();
            if(isset($resp->opinfo))
            {
                $ruleInfo['comment'] = $resp->opinfo;
                $ruleInfo['rule_desc'] = $resp->desc;
            }
            return $ruleInfo;
        }
    }
}
