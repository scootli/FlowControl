<?php
require_once PHPLIB_ROOT . 'api/appplatform/platform/web_stub_cntl.php';
require_once PHPLIB_ROOT . 'api/appplatform/ncadao_php5_xxoo.php';
require_once PHPLIB_ROOT . 'api/appplatform/ncadao_php5_stub.php';

class IProductMeta {
	public static $errCode=0;
	public static $errMsg='';
	const API_CALLER='meta_attr_value_api';
	const SEARCH_URL='http://searchex.51buy.com/json';
	public static function searchProducts(array $params){
		if(empty($params)){
			return array();
		}
		$urlParts=http_build_query($params);
		$url=self::SEARCH_URL.'?'.$urlParts;
		// echo $url.'<br/>';
		$rt=NetUtil::cURLHTTPGet($url,3);
		if($rt){
			$rt=iconv('GBK','UTF-8',$rt);
			$rt=json_decode($rt,true);
		}
		return isset($rt['list'])?$rt['list']:array();
	}

	/**
	*@param $metaId 品类ID
	*通过品类ID获取该品类对应的属性
	**/
	public static function getAttrByMetaId($metaId,$isAssoc=True){
		$result=array();
		self::clearErr();
		$req=new b2b2c\nca\dao\GetMeta_ALLReq();
		$req->machineKey=__FILE__;
		$req->source=0;
		$req->metaId=$metaId;
		$req->aPIControl=array('source'=>1,'charset'=>2);
		$req->attrOnly=1;
		$req->needAttrDic=1;

		$rep=new b2b2c\nca\dao\GetMeta_ALLResp();
		$cntl = new WebStubCntl();
		$cntl->setCallerName(self::API_CALLER);
		$ret = $cntl->invoke($req, $rep,2);
		if($ret==0){
			if($rep->result==0){
				$attrTotal=$rep->meta['attrDic']->getSize();
				if($attrTotal){
					foreach($rep->meta['attrDic']->getValue() as $val){
						if($isAssoc){
							$result[]=array('id'=>$val['attrId'],'name'=>$val['name']);
						}
						else{
							$result[$val['attrId']]=$val['name'];
						}
					}
				}
			}
			else{
				self::$errCode=400;
				self::$errMsg=$rep->errmsg;
			}
		}
		else{
			self::$errCode=404;
			self::$errMsg=$rep->errmsg;
		}
		return $result;
	}

	/**
	*@param $metaId 品类ID
	*@param $attrId 属性ID
	*通过品类ID和属性ID获取该属性对应的属性值
	**/
	public static function getAttrVal($metaId,$attrId,$isAssoc=True){
		$result=array();
		self::clearErr();
		$req=new  b2b2c\nca\dao\GetMetaAttr_ALLReq();
		$req->machineKey=__FILE__;
		$req->source=0;
		$req->metaId=$metaId;
		$req->attrId=$attrId;
		$req->aPIControl=array('source'=>1,'charset'=>2);
		$req->attrOnly=0;

		$rep=new b2b2c\nca\dao\GetMetaAttr_ALLResp();

		$cntl = new WebStubCntl();
		$cntl->setCallerName(self::API_CALLER);
		$ret = $cntl->invoke($req, $rep,2);
		if($ret==0){
			if($rep->result==0){
				$attrTotal=$rep->attr['options']->getSize();
				if($attrTotal){
					foreach($rep->attr['options']->getValue() as $val){
						if($isAssoc){
							$result[]=array('id'=>$val['optionId'],'name'=>$val['name']);
						}
						else{
							$result[$val['optionId']]=$val['name'];
						}
					}
				}
			}
			else{
				self::$errCode=$rep->errcode;
				self::$errMsg=$rep->errmsg;
			}
		}
		else{
			self::$errCode=$rep->errcode;
			self::$errMsg=$rep->errmsg;
		}
		return $result;
	}

	private static function clearErr() {
		self::$errCode = 0;
		self::$errMsg = '';
	}

}
