<?php
class CompCoupon
{
	public static function getConfig($id, $aid, $cid) {
		$url = 'http://event.yixun.com/json.php?mod=coupon&act=get&evtno=' . $cid;
		return $url;
	}
}