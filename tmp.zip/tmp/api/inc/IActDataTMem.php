<?php

class IActDataTMem {
	
	const DB_NAME = 'act_data';
	const TABLE_NAME = 't_act_data';
	
	const TMEM_CONFIG_KEY = 'act_data';
	const TMEM_BIZ_ID = TMEM_BID_ACT_DATA;
	
	const DATA_KEY_PREFIX = 'act_data_';
	const LOCK_KEY_PREFIX = 'act_data_lock_';
	
	const DB_COUNT = 100;
	const TABLE_COUNT = 100;
	
	/*const COLUMN_COMPONENT_TYPE = 0;
	const COLUMN_COMPONENT_ID = 1;
	const COLUMN_UID = 2;
	const COLUMN_TYPE = 3;
	const COLUMN_VALUE = 4;
	const COLUMN_CREATE_TIME = 5;*/
	
	// tmem����������
	/** ��ȡkey��Ӧ�������Ҳ��� */
	const ERROR_NO_DATA = -13200; 
	/** ��ȡʱkey��Ӧ�������ѹ��� */
	const ERROR_KEY_EXPIRED = -13106; 
	/** ɾ��ʱkey������ */
	const ERROR_KEY_NO_EXIST = -13105; 
	/** ƫ�Ʋ����������Ϸ� */
	const ERROR_LOCAL_PARSE_ARGS = -13002;
	/** �в����������Ϸ� */
	const ERROR_SO_PARSE_ARGS = -13004;
	
	/*private static $_ID_NAME = array(
		self::COLUMN_ID => 'id',
		self::COLUMN_COMPONENT_TYPE => 'component_type',
		self::COLUMN_COMPONENT_ID => 'component_id',
		self::COLUMN_UID => 'uid',
		self::COLUMN_TYPE => 'type',
		self::COLUMN_VALUE => 'value',
		self::COLUMN_CREATE_TIME => 'create_time'
	);
	
	private static $_NAME_ID = array(
		'id' => self::COLUMN_ID,
		'component_type' => self::COLUMN_COMPONENT_TYPE,
		'component_id' => self::COLUMN_COMPONENT_ID,
		'uid' => self::COLUMN_UID,
		'type' => self::COLUMN_TYPE,
		'value' => self::COLUMN_TYPE,
		'create_time' => self::COLUMN_CREATE_TIME
	);*/
	
	private static $_COLUMNS = array(
		'id' => array( 'type' => 'number', 'auto' => true ),
		'component_type' => array( 'type' => 'number' ),
		'component_id' => array( 'type' => 'number' ),
		'uid' => array( 'type' => 'number' ),
		'type' => array( 'type' => 'number' ),
		'value' => array( 'type' => 'string' ),
		'create_time' => array( 'type' => 'number' ),
		'update_time' => array( 'type' => 'number', 'readonly' => true )
	);
	
	private static $_TMEM_KEY = 'uid';
	private static $_PRIMARY_KEY = 'id';
	
	public static $errCode = 0;
	public static $errMsg = '';
	
	private static function clearErr() {
		self::$errCode = 0;
		self::$errMsg = '';
	}
	
	private static function getDBIndex($key) {
		return $key % self::DB_COUNT;
	}
	
	private static function getTableIndex($key) {
		return ($key / self::DB_COUNT) % self::TABLE_COUNT;
	}
	
	public static function insert($data) {
		self::clearErr();
		
		$params = array();
		foreach (self::$_COLUMNS as $name => $config) {
			if((!isset($config['readonly']) || !$config['readonly']) && (!isset($config['auto']) || !$config['auto'])) {
				if(isset($data[$name])) {
					$params[$name] = $data[$name];
				} else if(isset($config['default'])) {
					$params[$name] = $config['default'];
				} else {
					if($config['type'] == 'number') {
						$params[$name] = 0;
					} else {
						$params[$name] = '';
					}
				}
			}
		}
		
		if(!isset($data[self::$_TMEM_KEY]) || empty($data[self::$_TMEM_KEY])) {
			self::$errCode = ErrorConfig::getErrorCode('key_not_found', 'TMem');
			self::$errMsg = 'Key not found.';
			return false;
		}
		$key = $data[self::$_TMEM_KEY];
		
		$ret = self::checkPrimaryKey($params);
		if($ret === false) {
			self::$errCode = ErrorConfig::getErrorCode('primary_key_not_found', 'TMem');
			self::$errMsg = 'Primary key not found.';
			return false;
		}
		
		if(self::lock($key) === false) {
			self::$errCode = ErrorConfig::getErrorCode('lock_failed', 'TMem');
			self::$errMsg = "Failed to get lock $key.";
			return false;
		}
		
		$db_index = self::getDBIndex($key);
		$db = ToolUtil::getDBObj(self::DB_NAME, $db_index);
		if($db === false) {
			self::$errCode = ToolUtil::$errCode;
			self::$errMsg = ToolUtil::$errMsg;
			return false;
		}
		
		$table_name = self::TABLE_NAME . '_' . self::getTableIndex($key);
		$ret = $db->insert($table_name, $params);
		if($ret === false) {
			self::$errCode = $db->errCode;
			self::$errMsg = $db->errMsg;
			return false;
		}
		
		$tm = Config::getTMem(self::TMEM_CONFIG_KEY);
		if($tm === false) {
			self::$errCode = Config::$errCode;
			self::$errMsg = Config::$errMsg;
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
		
		try {
			$res = $tm->get(self::TMEM_BIZ_ID, self::DATA_KEY_PREFIX . $key);
			if($res === false) {
				$errno = $tm->errno();
				if($errno !== self::ERROR_KEY_EXPIRED && $errno !== self::ERROR_NO_DATA) {
					throw new BaseException($errno, "Failed to get cache data with key $key.");
				}
				$mem_data = array();
			} else {
				$mem_data = unserialize($res);
			}
			
			$mem_data[] = $params;
			$new_data = serialize($mem_data);
			$ret = $tm->set(self::TMEM_BIZ_ID, self::DATA_KEY_PREFIX . $key, $new_data);
			if($ret === false) {
				throw new BaseException($tm->errno(), "Failed to set cache data with key $key, data $new_data.");
			}
			
			if(self::unlock($key) === false) {
				Logger::err("Failed to release lock $key.");
			}
			
			return true;
		} catch(BaseException $e) {
			Logger::err($e->errCode . ' : ' . $e->errMsg);
			self::$errCode = $e->errCode;
			self::$errMsg = $e->errMsg;
			$ret = self::insert_rollback($db, $table_name, $params);
			if($ret === false) {
				Logger::err('Failed to rollback insert.[' . var_export($params, true) . ']');
			}
			
			if(self::unlock($key) === false) {
				Logger::err("Failed to release lock $key.");
			}
			
			return false;
		}
	}
	
	public static function get($key, $filter = array(), $need = array(), $start = 0, $len = 0) {
		
		self::clearErr();
		
		if(empty($key)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Key should not be empty.';
			return false;
		}
		
		if(!empty($filter) && !is_array($filter)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 2 should be array.';
			return false;
		}
		
		if(!empty($need) && !is_array($need)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 3 should be array.';
			return false;
		}
		
		if(!empty($start) && !is_int($start)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 4 should be int.';
			return false;
		}
		
		if(!empty($len) && !is_int($len)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 5 should be int.';
			return false;
		}
		
		$tm = Config::getTMem(self::TMEM_CONFIG_KEY);
		if($tm === false) {
			self::$errCode = Config::$errCode;
			self::$errMsg = Config::$errMsg;
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
		
		$res = $tm->get(self::TMEM_BIZ_ID, self::DATA_KEY_PREFIX . $key);
		if($res === false) {
			$errno = $tm->errno();
			if($errno !== self::ERROR_KEY_EXPIRED && $errno !== self::ERROR_NO_DATA) {
				self::$errCode = $errno;
				self::$errMsg = "Failed to get cache data with key $key.";
				return false;
			}
			$mem_data = array();
		} else {
			$mem_data = unserialize($res);
		}
		
		if(!empty($filter)) {
			foreach ($mem_data as $i => $data) {
				foreach ($filter as $k => $v) {
					if(isset(self::$_COLUMNS[$k]) && $data[$k] != $v) {
						array_splice($mem_data, $i, 1);
						break;
					}
				}
			}
		}
		
		$start = $start ?: 0;
		$len = $len ?: 0;
		$mem_data = array_splice($mem_data, $start, $len);
		
		if(!empty($need)) {
			foreach ($mem_data as &$data) {
				foreach ($data as $k => $v) {
					if(!isset($need[$k])) {
						unset($data[$k]);
					}
				}
			}
		}
		
		return $mem_data;
	}
	
	public static function remove($key, $filter = array()) {
		
		self::clearErr();
		
		if(empty($key)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Key should not be empty.';
			return false;
		}
		
		if(self::lock($key) === false) {
			self::$errCode = ErrorConfig::getErrorCode('lock_failed', 'TMem');
			self::$errMsg = "Failed to get lock $key.";
			return false;
		}
		
		$tm = Config::getTMem(self::TMEM_CONFIG_KEY);
		if($tm === false) {
			self::$errCode = Config::$errCode;
			self::$errMsg = Config::$errMsg;
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
		
		$res = $tm->get(self::TMEM_BIZ_ID, self::DATA_KEY_PREFIX . $key);
		if($res === false) {
			$errno = $tm->errno();
			if($errno !== self::ERROR_KEY_EXPIRED && $errno !== self::ERROR_NO_DATA) {
				self::$errCode = $errno;
				self::$errMsg = "Failed to get cache data with key $key.";
				return false;
			}
			$backup_data = '';
			$mem_data = array();
		} else {
			$backup_data = $res;
			$mem_data = unserialize($res);
		}
		
		if(!empty($filter)) {
			foreach ($mem_data as $i => $data) {
				$match = true;
				foreach ($filter as $k => $v) {
					if(isset(self::$_COLUMNS[$k]) && $data[$k] != $v) {
						$match = false;
						break;
					}
				}
				if($match) {
					array_splice($mem_data, $i, 1);
				}
			}
		} else {
			$mem_data = array();
		}
		
		$new_data = seralize($mem_data);
		$ret = $tm->set(self::TMEM_BIZ_ID, self::DATA_KEY_PREFIX . $key, $new_data);
		if($ret === false) {
			self::$errCode = $tm->errno();
			self::$errMsg = "Failed to set cache data with key $key, data $new_data.";
			return false;
		}
		
		try {
			$db_index = self::getDBIndex($key);
			$db = ToolUtil::getDBObj(self::DB_NAME, $db_index);
			if($db === false) {
				throw new BaseException(ToolUtil::$errCode, ToolUtil::$errMsg);
			}
			
			$table_name = self::TABLE_NAME . '_' . self::getTableIndex($key);
			$cond = array();
			foreach ($filter as $k => $v) {
				if(isset(self::$_COLUMNS[$k])) {
					if(self::$_COLUMNS[$k]['type'] == 'number') {
						$cond[] = $k . " = $v";
					} else {
						$cond[] = $k . " = '$v'";
					}
				}
			}
			$ret = $db->remove($table_name, implode(' AND ', $cond));
			if($ret === false) {
				throw new BaseException($db->errCode, $db->errMsg);
			}
			
			return true;
		} catch(BaseException $e) {
			Logger::err($e->errCode . ' : ' . $e->errMsg);
			self::$errCode = $e->errCode;
			self::$errMsg = $e->errMsg;
			$ret = $tm->set(self::TMEM_BIZ_ID, self::DATA_KEY_PREFIX . $key, $backup_data);
			if($ret === false) {
				Logger::err($tm->errno() . ' : ' . "Failed to set cache data with key $key, data $new_data.");
			}
			return false;
		}
	}
	
	public static function update($data, $filter = array()) {
		
		self::clearErr();
		
		$params = array();
		foreach (self::$_COLUMNS as $name => $config) {
			if((!isset($config['readonly']) || !$config['readonly']) && (!isset($config['auto']) || !$config['auto'])) {
				if(isset($data[$name])) {
					$params[$name] = $data[$name];
				}
			}
		}
		
		if(!isset($data[self::$_TMEM_KEY]) || empty($data[self::$_TMEM_KEY])) {
			self::$errCode = ErrorConfig::getErrorCode('key_not_found', 'TMem');
			self::$errMsg = 'Key not found.';
			return false;
		}
		$key = $data[self::$_TMEM_KEY];
		
		$res = $tm->get(self::TMEM_BIZ_ID, self::DATA_KEY_PREFIX . $key);
		if($res === false) {
			$errno = $tm->errno();
			if($errno !== self::ERROR_KEY_EXPIRED && $errno !== self::ERROR_NO_DATA) {
				self::$errCode = $errno;
				self::$errMsg = "Failed to get cache data with key $key.";
				return false;
			}
			$backup_data = '';
			$mem_data = array();
		} else {
			$backup_data = $res;
			$mem_data = unserialize($res);
		}
		
		if(!empty($filter)) {
			foreach ($mem_data as &$data) {
				$match = true;
				foreach ($filter as $k => $v) {
					if(isset(self::$_COLUMNS[$k]) && $data[$k] != $v) {
						$match = false;
						break;
					}
				}
				if($match) {
					foreach ($params as $k => $v) {
						$data[$k] = $v;
					}
				}
			}
		} else {
			foreach ($mem_data as &$data) {
				foreach ($params as $k => $v) {
					$data[$k] = $v;
				}
			}
		}
		
		$new_data = seralize($mem_data);
		$ret = $tm->set(self::TMEM_BIZ_ID, self::DATA_KEY_PREFIX . $key, $new_data);
		if($ret === false) {
			self::$errCode = $tm->errno();
			self::$errMsg = "Failed to set cache data with key $key, data $new_data.";
			return false;
		}
		
		try {
			$db_index = self::getDBIndex($key);
			$db = ToolUtil::getDBObj(self::DB_NAME, $db_index);
			if($db === false) {
				throw new BaseException(ToolUtil::$errCode, ToolUtil::$errMsg);
			}
			
			$table_name = self::TABLE_NAME . '_' . self::getTableIndex($key);
			$cond = array();
			foreach ($filter as $k => $v) {
				if(isset(self::$_COLUMNS[$k])) {
					if(self::$_COLUMNS[$k]['type'] == 'number') {
						$cond[] = $k . " = $v";
					} else {
						$cond[] = $k . " = '$v'";
					}
				}
			}
			$ret = $db->update($table_name, $params, implode(' AND ', $cond));
			if($ret === false) {
				throw new BaseException($db->errCode, $db->errMsg);
			}
			
			return true;
		} catch(BaseException $e) {
			Logger::err($e->errCode . ' : ' . $e->errMsg);
			self::$errCode = $e->errCode;
			self::$errMsg = $e->errMsg;
			$ret = $tm->set(self::TMEM_BIZ_ID, self::DATA_KEY_PREFIX . $key, $backup_data);
			if($ret === false) {
				Logger::err($tm->errno() . ' : ' . "Failed to set cache data with key $key, data $new_data.");
			}
			return false;
		}
	}
	
	private static function lock($key) {
		$cas = -1;
		$expire_timestamp = 0;
		
		$tm = Config::getTMem(self::TMEM_CONFIG_KEY);
		if($tm === false) {
			self::$errCode = Config::$errCode;
			self::$errMsg = Config::$errMsg;
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
		$ret = $tm->casget(self::TMEM_BIZ_ID, self::LOCK_KEY_PREFIX . $key, $cas, $expire_timestamp);
		if($ret !== false) {
			return false;
		} else {
			$errno = $tm->errno();
			if($errno != self::ERROR_KEY_EXPIRED && $errno != self::ERROR_NO_DATA) {
				self::$errCode = $errno;
				self::$errMsg = 'Failed to get lock status.[' . self::LOCK_KEY_PREFIX . $key . ']';
				Logger::err(self::$errCode . ' : ' . self::$errMsg);
				return false;
			}
		}
		
		$ret = $tm->casset(self::TMEM_BIZ_ID, self::LOCK_KEY_PREFIX . $key, 'LOCKED', $cas, 2);
		if($ret === false) {
			self::$errCode = $tm->errno();
			self::$errMsg = 'Failed to get lock.[' . self::LOCK_KEY_PREFIX . $key . ']';
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		} else if($ret === null) {
			return false;
		}
		
		return true;
	}
	
	private static function unlock($key) {
		$tm = Config::getTMem(self::TMEM_CONFIG_KEY);
		if($tm === false) {
			self::$errCode = Config::$errCode;
			self::$errMsg = Config::$errMsg;
			Logger::err(self::$errCode . ' : ' . self::$errMsg);
			return false;
		}
		
		$ret = $tm->del(self::TMEM_BIZ_ID, self::LOCK_KEY_PREFIX . $key);
		if($ret === false) {
			$errno = $tm->errno();
			if($errno != self::ERROR_KEY_NO_EXIST) {
				self::$errCode = $errno;
				self::$errMsg = 'Failed to release lock.[' . self::LOCK_KEY_PREFIX . $key . ']';
				Logger::err(self::$errCode . ' : ' . self::$errMsg);
				return false;
			}
		}
		
		return true;
	}
	
	private static function getTMem() {
		
	}
}