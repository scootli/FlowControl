<?php
class ILoveCar{
	private $db;
	private $dbName='icson_admin_lovecar';
	public function __construct($initSql='SET NAMES UTF8'){
		$this->db=Config::getDB($this->dbName);
		$this->db->execSql($initSql);
	}

	public function insertRow($row,$tableName){
		if($this->db->insert($tableName,$row)){
			return $this->db->getInsertId();
		}
		else{
			return FALSE;
		}
	}

	public function getRows($sql){
		return $this->db->getRows($sql);
	}

	public function getRow($sql){
		$rows=$this->getRows($sql);
		if($rows){
			return array_pop($rows);
		}
		return array();
	}

	public function update($sql){
		return $this->db->execSql($sql);
	}

	public function exec($sql){
		return $this->db->execSql($sql);
	}

	public function insertOrUpdate($insertRow, $updateRow,$tableName){
		return $this->db->insertOrUpdate($tableName, $insertRow, $updateRow);
	}
}