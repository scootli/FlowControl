<?php
/** 
 * Class RestController
 * Describe a possible Controller to handle a Request
 * @copyright (c) 2012 Tencent
 * @version 1.1 beta
 * @author EdisonTsai
 */

interface RestController extends RestAction {
     /**
       * Execute the Default action of this controller
       * @param RestServer $restServer
       * @return RestAction $restVieworController
       *
     * */
    function execute(RestServer $restServer) ;
}

?>