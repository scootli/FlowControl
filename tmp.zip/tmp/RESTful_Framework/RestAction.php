<?php
/**
 * Class restAction
 * Inteface for a possible action for to be taken
 * @copyright (c) 2012 Tencent
 * @version 1.1 beta
 * @author EdisonTsai
 */

interface RestAction {

}
?>