<?php
/**
 * RestResponse hold the response in a RestServer
 * @copyright (c) 2012 Tencent
 * @version 1.1 beta
 * @author EdisonTsai
 */
require_once 'xml_lib.php';

class RestResponse {

    private $rest ; 

    private $headers ;
    private $response ;
	private $xml;
	private static $_httpVersion = 'HTTP/1.1';
	#Modified by Edison tsai on 17:38 2010/12/07 for add correct headers
	private static $_contentType = 'Content-Type:';
	private static $_contentTypeExt = array(
						'xml'	 =>	'application/xml',
						'json'	 =>	'application/json',
					);
	private static $_supportExt = array('json','xml');
	private static $_defaultCharset = 'UTF-8';
	private static $_defaultResType = 'json';

    /** 
      * Constructor of RestServer
      * @param RestServer $rest
      */
    function __contruct($rest=null) {
        $this->rest = $rest ;
		$this->xml	= new xml_lib();
    }

    /** 
      * get status code message
      * @param status
	  * @return string
      */
    public static function getStatusCodeMsg($status)   
    {   
 
        $codes = Array(   
            100 => 'Continue',   
            101 => 'Switching Protocols',   
            200 => 'OK',   
            201 => 'Created',   
            202 => 'Accepted',   
            203 => 'Non-Authoritative Information',   
            204 => 'No Content',   
            205 => 'Reset Content',   
            206 => 'Partial Content',   
            300 => 'Multiple Choices',   
            301 => 'Moved Permanently',   
            302 => 'Found',   
            303 => 'See Other',   
            304 => 'Not Modified',   
            305 => 'Use Proxy',   
            306 => '(Unused)',   
            307 => 'Temporary Redirect',   
            400 => 'Bad Request',   
            401 => 'Unauthorized',   
            402 => 'Payment Required',   
            403 => 'Forbidden',   
            404 => 'Not Found',   
            405 => 'Method Not Allowed',   
            406 => 'Not Acceptable',   
            407 => 'Proxy Authentication Required',   
            408 => 'Request Timeout',   
            409 => 'Conflict',   
            410 => 'Gone',   
            411 => 'Length Required',   
            412 => 'Precondition Failed',   
            413 => 'Request Entity Too Large',   
            414 => 'Request-URI Too Long',   
            415 => 'Unsupported Media Type',   
            416 => 'Requested Range Not Satisfiable',   
            417 => 'Expectation Failed',   
            500 => 'Internal Server Error',   
            501 => 'Not Implemented',   
            502 => 'Bad Gateway',   
            503 => 'Service Unavailable',   
            504 => 'Gateway Timeout',   
            505 => 'HTTP Version Not Supported'
        );
  
        return (isset($codes[$status])) ? $codes[$status] : '';   
    }  

    /**
      * Set the response to null
      * @return RestResponse
      */
    public function cleanResponse() {
        $this->response = null ;
        return $this ;
    }
	
    /**
      * Adds a header to the response
      * @param string $header
      * @return RestResponse
      */
	public function addHeader($header) {
        $this->headers[] = $header;
        return $this;
	}
	
    /**
      * Clean the headers set on the response
      * @return RestResponse
      */
	public function cleanHeader() {
        $this->headers = Array();
        return $this ;
	}
	
    /**
      * Show the headers
      */
	public function showHeader() {
        if(count($this->headers) >=1) {
            foreach($this->headers as $value) {
                header($value);
            }
        }
        return $this ;
	}
	
    /**
      * Check if headers were sent
      * @return bool
      */
	public function headerSent() {
        return headers_sent();
	}
	
    /**
      * Set the response
      * @param mixed $response
      * @return RestResponse
      */
	public function setResponse($response) {
        $this->response = $response;
        return $this ;
	}
	
    /**
      * Add a string to the response, only work if response is a string
      * @param string $response
      * @return RestResponse
      */
	public function addResponse($response) {
        $this->response .= $response ;
        return $this;
	}

    /**
      * Return the reponse set
      * @return mixed $response
      */
    public function getResponse() {
        return $this->response;
    }

    /**
      * add http header by using code
      * @return RestResponse
      */
	public function addHttpHeader($status){
	    return $this->addHeader(self::$_httpVersion.' '.$status.' '.self::getStatusCodeMsg($status));
	}

    /**
      * add http content header by using content Code
      * @return RestResponse
      */
	public function addHttpContentHeader($code){
	    return $this->addHeader(self::$_contentType.self::$_contentTypeExt[$code]);
	}

    /**
      * integrate response result in one function
	  * @param $status is http header status
	  * @param $msg is return message
	  * @param $code is content type(xml/json/plain)
      * @return RestResponse
	  * @Modified by Edison tsai on 18:24 2011/02/17 for remove charset
	  * @modified by Edison tsai on 16:03 for add json encode parse
	  * @modified by Edison tsai on 15:07 2010/09/24 for set the default response type to json
      */
	public function setResult($status,$msg='',$cType='json'){
		//Remove return charset
	   //$this->headers[] = self::$_httpVersion.' '.$status.' '.self::getStatusCodeMsg($status).'; charset='.self::$_defaultCharset;
	   $this->headers[] = self::$_httpVersion.' '.$status.' '.self::getStatusCodeMsg($status);
	   $this->headers[] = self::$_contentType.(in_array($cType,self::$_supportExt) ? self::$_contentTypeExt[$cType] : self::$_contentTypeExt[self::$_defaultResType]);
	   
	   switch($cType){
	       case 'json':
			   $msg = json_encode($msg);
			   break;
		   case 'xml':
			
		   /*
		    * To fix non-object bug
			* @Modified by Edison tsai on 10:56 2012/02/10
		    */
			if(!is_object($this->xml)){
				$this->xml	= new xml_lib();
			} //end if
			   //Added by Edison tsai on 17:21 2011/08/18 for xml encoding
			   $msg = $this->xml->xml_encode($msg);
			   break;
	   }

       $this->response  = $msg;

	   return $this;
	}

  /**
    * Setting XML Root prefix within xml_lib
	* @param $prefix string
	* @author Edison tsai
	* @created on 17:28 2011/08/18
    * @return void
    */
	public function setXMLRootPrefix($prefix){
		$this->xml->setRootPrefix($prefix);
	}

  /**
    * Setting XML Child prefix within xml_lib
	* @param $prefix string
	* @author Edison tsai
	* @created on 17:28 2011/08/18
    * @return void
    */
	public function setXMLChildPrefix($prefx){
		$this->xml->setChildPrefix($prefix);
	}

}
?>