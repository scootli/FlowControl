<?php
/*
 * XML LIB
 * Including xml_encode,xml_decode(later)
 * 要求最低的PHP版本是5.2.0，并且还要支持以下库：Libxml 2.6.0
 * This class for invoke remote RESTful Webservice
 * The requirement of PHP version is 5.2.0 or above, and support as below:
 * Libxml 2.6.0
 *
 * @Version: 0.0.1 alpha
 * @Created: 15:59:48 2011/08/18
 * @modified: 17:56 2012/09/09 for replace ereg_replace to preg_replace
 * @Author:	Edison tsai<edisontsai@tencent.com/dnsing@gmail.com>
 * @Blog:	http://www.timescode.com
 */

 class xml_lib{
	
	private $xml			= '';
	//Default values
	private $rootPrefix		= 'root';
	private $childPrefix	= 'data';
	private $xmlVersion		= '1.0';
	private $encoding		= 'UTF-8';
	private $_data;
	private static $xmlMapping = array(
			'ROOT_HEADER'	=>	'<?xml version="%s" encoding="%s"?><%s>',
			'NORMAL_FOOTER'	=>	'</%s>',
	);

	public function __construct(){
		$this->_data = new stdClass;
	}

	public function makeXML($array)
	{
		
	 $this->childPrefix = empty($this->childPrefix) ? 'data' : $this->childPrefix;

		foreach($array as $k=>$v)
		{
			if(is_array($v))
			{
				// replace numeric key in array to $this->childPrefix
				$tag = preg_replace('/\d{1,}/',$this->childPrefix,$k); 
				$this->xml .= "<$tag>";
				$this->makeXML($v);
				$this->xml .= "</$tag>";
			}
			else
			{
				$tag = preg_replace('/\d{1,}/',$this->childPrefix,$k);
				$this->xml .= "<$tag>$v</$tag>";
			}
		}
	}

   /**
    * Encoding string or array to XML
    * @param $str mixed
    * @return String
    */
	public function xml_encode($str){
		
		if(is_array($str) && count($str) > 0){
					$this->makeXML($str);
			}
				else{

					$this->xml .= $str;
			} #end else

			return $this->parseXML();
	}

   /**
    * Setting root prefix
    * @param $prefix string
    * @return void
    */
	public function setRootPrefix($prefix){
		$this->rootPrefix = trim($prefix);
	}

   /**
    * Setting child prefix
    * @param $prefix string
    * @return void
    */
	public function setChildPrefix($prefix){
		$this->childPrefix = trim($prefix);
	}

   /**
    * Setting XML version
    * @param $ver string
    * @return void
    */
	public function setVersion($ver){
		$this->xmlVersion = trim($ver);
	}

   /**
    * Setting XML encoding
    * @param $char string
    * @return void
    */
	public function setEncoding($char){
		$this->encoding = trim($char);
	}

   /**
    * Parse XML
    * @return String
    */
	private function parseXML(){
		
		$this->rootPrefix		= empty($this->rootPrefix) ? 'root' : $this->rootPrefix;
		$this->_data->header	= sprintf(self::$xmlMapping['ROOT_HEADER'],$this->xmlVersion,$this->encoding,$this->rootPrefix);
		$this->_data->footer	= sprintf(self::$xmlMapping['NORMAL_FOOTER'],$this->rootPrefix);
		
		return $this->_data->header.$this->xml.$this->_data->footer;
	}
	
 }//END CLASS
?>