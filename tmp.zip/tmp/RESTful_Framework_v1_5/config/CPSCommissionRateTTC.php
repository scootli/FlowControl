<?php
/**
 * CPS SSO Token TTC Config file
 * @auth gangzhao
 * @version 20121203
 */
return array(
				'TTCKEY'				=> 'CPSCommissionRateTTC',
				'TABLE'					=> 't_cps_commission_rate_',
				'TimeOut'				=> 1,
				'KEY'					=> 'cid',
				'IP'					=> '10.180.74.16:9157',
				'FIELDS'	=> array(
									'cid'=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'crmin'=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'crmax'=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'crate'=> array('type' => 2, 'min' => 0, 'max' => 50),
									'is_percent'=> array('type' => 1, 'min' => -128, 'max' => 127),
									'crtag'=> array('type' => 2, 'min' => 0, 'max' => 10),
									'crid'=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
							),
		);

?>