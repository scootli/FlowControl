<?php
return 	array(
	'crm_user_orders'	=>	array(
		'bid'			=>	20120378,
		'show_error'	=>	1,	//是否显示错误
		'timeout'		=>	1000,	//超时设置
		'freetime'		=>	10,		//冻结时间
		'servers'		=>	array('192.168.2.225:53024')
		),
	'crm_cmemkey_config'=>	array(
		'bid'			=>	20120379,
		'show_error'	=>	false,	//是否显示错误
		'timeout'		=>	1000,	//超时设置
		'freetime'		=>	10,		//冻结时间
		'servers'		=>	array('192.168.2.225:53024')
		),
	'crm_test_3'		=>	array(
		'bid'			=>	20120381,
		'show_error'	=>	false,	//是否显示错误
		'timeout'		=>	1000,	//超时设置
		'freetime'		=>	10,		//冻结时间
		'servers'		=>	array('192.168.2.225:53024')
		),
	'OpenProdDB'		=>	array(
		'bid'			=>	102030222,
		'show_error'	=>	false,	//是否显示错误
		'timeout'		=>	1000,	//超时设置
		'freetime'		=>	10,		//冻结时间
		'servers'		=>	array('192.168.2.225:53024')
	),
	'Merchants'		=>	array(
		'bid'			=>	102030268,
		'show_error'	=>	false,	//是否显示错误
		'timeout'		=>	1000,	//超时设置
		'freetime'		=>	10,		//冻结时间
		'servers'		=>	array('192.168.2.225:53024')
	),
	'CPSCookie'		=>	array(
		'bid'			=>	102030229,
		'show_error'	=>	1,	//是否显示错误
		'timeout'		=>	1000,	//超时设置
		'freetime'		=>	10,		//冻结时间
		'servers'		=>	array('192.168.2.225:53024')
	),
);
?>