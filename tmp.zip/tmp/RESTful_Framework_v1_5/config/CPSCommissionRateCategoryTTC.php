<?php
/**
 * CPS SSO Token TTC Config file
 * @auth gangzhao
 * @version 20121203
 */
return array(
				'TTCKEY'				=> 'CPSCommissionRateCategoryTTC',
				'TABLE'					=> 't_cps_commission_rate_category_',
				'TimeOut'				=> 1,
				'KEY'					=> 'rid',
				'IP'					=> '10.180.74.16:9161',
				'FIELDS'	=> array(
									'rid' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'cat_id' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'node' => array('type' => 2, 'min' => 0, 'max' => 50),
									'pid' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'add_time' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'status' => array('type' => 1, 'min' => 0, 'max' => 255),
							),
		);
?>