<?php
/**
 * CPS Order Item TTC Config file
 * by rain on 17:27 2012/11/17
 */
 
return array(
				'TTCKEY'				=> 'CPSOrderItemsTTC',
				'TABLE'					=> 't_order_items_',
				'TimeOut'				=> 1,
				'KEY'					=> 'uid',
				'IP'					=> '10.96.78.106:20006',
				'FIELDS'	=> array(
									'uid' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'order_char_id' 			=> array('type' => 2, 'min' => 0, 'max' => 32),
									'item_id' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'product_id' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'wh_id' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'product_char_id' 			=> array('type' => 2, 'min' => 0, 'max' => 32),
									'name' 			=> array('type' => 2, 'min' => 0, 'max' => 640),
									'flag' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'type' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'type2' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'weight' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'buy_num' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'points' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'points_pay' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'point_type' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'discount' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'price' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'cash_back' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'cost' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'warranty' 			=> array('type' => 2, 'min' => 0, 'max' => 1000),
									'expect_num' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'create_time' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'product_type' 			=> array('type' => 1, 'min' => -128, 'max' => 127),
									'use_virtual_stock' 			=> array('type' => 1, 'min' => -128, 'max' => 127),
									'main_product_id' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'updatetime' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'edm_code' 			=> array('type' => 2, 'min' => 0, 'max' => 100),
									'apportToPm' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'apportToMkt' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'OTag' 			=> array('type' => 2, 'min' => 0, 'max' => 200),
									'shop_guide_cost' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
	
				),
		);
?>