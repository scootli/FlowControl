<?php
/**
 * CPSOrdersTTC Config file
 * by DaopingSun on 15:00 2012/12/2
 */
return array(
				'TTCKEY'				=> 'CPSOrdersOriginalTTC',
				'TABLE'					=> 't_cps_orders_original_',
				'TimeOut'				=> 1,
				'KEY'					=> 'date_id',
				'IP'					=> '10.180.74.16:9164',
				'FIELDS'	=> array(
						'date_id' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
						'order_id' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
						'uid' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
						'sysid' => array('type' => 2, 'min' => 0, 'max' => 20),
						'order_info' => array('type' => 2, 'min' => 0, 'max' => 65535),
						'status' => array('type' => 1, 'min' => 0, 'max' => 255),
						'retry' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
						'update_time' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
						'create_time' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
				),
		);
?>