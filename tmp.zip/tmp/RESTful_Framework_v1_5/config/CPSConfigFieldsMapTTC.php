<?php
/**
 * CPSConfigFieldsMapTTC Config file
 * by DaopingSun on 10:00 2012/12/3
 */
return array(
				'TTCKEY'				=> 'CPSConfigFieldsMapTTC',
				'TABLE'					=> 't_cps_config_fields_map_',
				'TimeOut'				=> 1,
				'KEY'					=> 'mid',
				'IP'					=> '10.12.194.124:9158',
				'FIELDS'	=> array(							
						'mid' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
						'field_name' 	=> array('type' => 2, 'min' => 0, 'max' => 20),
						'field_value'	=> array('type' => 2, 'min' => 0, 'max' => 65535),
						'field_rela' 	=> array('type' => 2, 'min' => 0, 'max' => 20),
						'sort' 			=> array('type' => 1, 'min' => 0, 'max' => 255),
						'remark' 		=> array('type' => 2, 'min' => 0, 'max' => 100),
				),
		);
?>

