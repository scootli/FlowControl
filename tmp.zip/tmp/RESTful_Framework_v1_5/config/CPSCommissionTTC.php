<?php
/**
 * CPS SSO Token TTC Config file
 * @auth gangzhao
 * @version 20121203
 */
return array(
				'TTCKEY'				=> 'CPSCommissionTTC',
				'TABLE'					=> 't_cps_commission',
				'TimeOut'				=> 1,
				'KEY'					=> 'mid',
				'IP'					=> '10.180.74.16:9156',
				'FIELDS'	=> array(
									'mid' => array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'cid' => array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'title' => array('type' => 2, 'min' => 0, 'max' => 30),
									'begin_time' => array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'end_time' => array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
									'status' => array('type' => 1, 'min' => -128, 'max' => 127),
									'addtime' => array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
							),



		);
?>