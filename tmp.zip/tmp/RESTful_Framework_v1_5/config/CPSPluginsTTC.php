<?php
/**
 * CPSPluginsTTC Config file
 * by DaopingSun on 10:00 2012/12/3
 */
return array(
				'TTCKEY'				=> 'CPSPluginsTTC',
				'TABLE'					=> 't_cps_plugins',
				'TimeOut'				=> 1,
				'KEY'					=> 'mid',
				'IP'					=> '10.12.194.124:9823',
				'FIELDS'	=> array(
						'mid' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
						'pid' 			=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
						'name' 			=> array('type' => 2, 'min' => 0, 'max' => 20),
						'remark'		=> array('type' => 2, 'min' => 0, 'max' => 100),
						'version'		=> array('type' => 2, 'min' => 0, 'max' => 10),
						'author' 		=> array('type' => 2, 'min' => 0, 'max' => 50),
						'status' 		=> array('type' => 1, 'min' => -128, 'max' => 127),
						'create_time' 	=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
						'update_time' 	=> array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
				),
		);
?>

