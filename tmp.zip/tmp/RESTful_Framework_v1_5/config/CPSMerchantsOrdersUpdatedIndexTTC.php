<?php
/**
 * CPSMerchantsOrdersUpdatedIndexTTC Config file
 * by DaopingSun on 17:00 2012/12/11
 */
return array(
				'TTCKEY'				=> 'CPSMerchantsOrdersUpdatedIndexTTC',
				'TABLE'					=> 't_cps_merchants_orders_updated_index_',
				'TimeOut'				=> 1,
				'KEY'					=> 'mid_date',
				'IP'					=> '10.180.74.16:9162',
				'FIELDS'	=> array(
						'mid_date' => array('type' => 1, 'min' => 0, 'max' => 1.84467440737E+19),
						'order_id' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
						'wh_id'    => array('type' => 1, 'min' => 0, 'max' => 65535),
				),
		);
?>