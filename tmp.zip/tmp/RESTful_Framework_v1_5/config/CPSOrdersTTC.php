<?php
/**
 * CPSOrdersTTC Config file
 * by DaopingSun on 15:00 2012/12/2
 */
return array(
				'TTCKEY'				=> 'CPSOrdersTTC',
				'TABLE'					=> 't_cps_orders_',
				'TimeOut'				=> 1,
				'KEY'					=> 'order_id',
				'IP'					=> '10.180.74.16:9163',
				'FIELDS'	=> array(
							'order_id'		=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'uid'			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'wh_id' 		=> array('type' => 1, 'min' => 0, 'max' => 65535),
							'mid' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'total_amount' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'pay_amount'	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'payment_type'	=> array('type' => 1, 'min' => 0, 'max' => 255),
							'order_status' 	=> array('type' => 1, 'min' =>-128, 'max' => 127),
							'sync_status' 	=> array('type' => 1, 'min' => 0, 'max' => 255),
						    'sync_erp_status'=> array('type' => 1, 'min' => 0, 'max' => 255),
							'is_invoice' 	=> array('type' => 1, 'min' => 0, 'max' => 255),
							'commission' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'extra' 		=> array('type' => 2, 'min' => 0, 'max' => 65535),
							'sync_time' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'sync_erp_time' => array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'order_time' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'click_time' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'cookie_time' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'create_time' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'update_time' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
				),
		);
?>
