<?php
/**
 * CPSOrdersTimelineTTC Config file
 * by DaopingSun on 17:44 2012/12/22
 */
return array(
				'TTCKEY'				=> 'CPSOrdersTimelineTTC',
				'TABLE'					=> 't_cps_orders_timeline_',
				'TimeOut'				=> 1,
				'KEY'					=> 'order_id',
				'IP'					=> '10.180.74.16:9177',
				'FIELDS'	=> array(							
							'order_id' 		=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'type' 			=> array('type' => 1, 'min' => 0, 'max' => 255),
							'err_code' 		=> array('type' => 2, 'min' => 0, 'max' => 15),
							'err_msg' 		=> array('type' => 2, 'min' => 0, 'max' => 65535),
							'uid'			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'mid' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
							'ip' 			=> array('type' => 2, 'min' => 0, 'max' => 20),
							'add_time' 		=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
				),
		);
?>