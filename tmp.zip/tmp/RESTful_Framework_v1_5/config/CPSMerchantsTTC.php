<?php
/**
 * ICPSMerchantsTTC Config file
 * by DaopingSun on 12:00 2012/12/2
 */
return array(
				'TTCKEY'				=> 'CPSMerchantsTTC',
				'TABLE'					=> 't_cps_merchants',
				'TimeOut'				=> 1,
				'KEY'					=> 'mid',
				'IP'					=> '10.180.74.16:9159',
				'FIELDS'	=> array(
									'mid' 		=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'sysid' 	=> array('type' => 2, 'min' => 0, 'max' => 20),
									'nickname'  => array('type' => 2, 'min' => 0, 'max' => 30),
									'type' 	 	=> array('type' => 2, 'min' => 0, 'max' => 10),
 									'password'  => array('type' => 2, 'min' => 0, 'max' => 32),
									'keycode' 	=> array('type' => 2, 'min' => 0, 'max' => 32),
									'website' 	=> array('type' => 2, 'min' => 0, 'max' => 50),
									'qq' 		=> array('type' => 2, 'min' => 0, 'max' => 15),
									'email' 	=> array('type' => 2, 'min' => 0, 'max' => 30),
									'tel'		=> array('type' => 2, 'min' => 0, 'max' => 20),
									'contact'	=> array('type' => 2, 'min' => 0, 'max' => 20),
									'address' 	=> array('type' => 2, 'min' => 0, 'max' => 100),
									'last_login'=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'last_ip'	=> array('type' => 2, 'min' => 0, 'max' => 15),
									'login_times'=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'status' 	=> array('type' => 1, 'min' => 0, 'max' => 255),
									'is_email'	=> array('type' => 1, 'min' => 0, 'max' => 255),
									'is_url'	=> array('type' => 1, 'min' => 0, 'max' => 255),
									'remark' 	=> array('type' => 2, 'min' => 0, 'max' => 100),
									'addtime' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295)
				),
		);
?>
