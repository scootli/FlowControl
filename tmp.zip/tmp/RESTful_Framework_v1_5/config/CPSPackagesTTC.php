<?php
/**
 * CPSPackagesTTC Config file
 * by DaopingSun on 10:00 2012/12/3
 */
return array(
				'TTCKEY'				=> 'CPSPackagesTTC',
				'TABLE'					=> 't_cps_packages',
				'TimeOut'				=> 1,
				'KEY'					=> 'mid',
				'IP'					=> '10.180.74.16:9165',
				'FIELDS'	=> array(
						'mid' => array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
						'pid' => array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
						'methods' => array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
						'root_tag' => array('type' => 2, 'min' => 0, 'max' => 50),
						'header' => array('type' => 2, 'min' => 0, 'max' => 65535),
						'body' => array('type' => 2, 'min' => 0, 'max' => 65535),
						'footer' => array('type' => 2, 'min' => 0, 'max' => 65535),
						'type' => array('type' => 1, 'min' => -128, 'max' => 127),
						'spl_symbol' => array('type' => 2, 'min' => 0, 'max' => 10),
						'create_time' => array('type' => 1, 'min' => -2147483648, 'max' => 2147483647),
						'status' => array('type' => 1, 'min' => -128, 'max' => 127),
						'title' => array('type' => 2, 'min' => 0, 'max' => 50),
						'actions' => array('type' => 2, 'min' => 0, 'max' => 4),
				),
		);
?>
