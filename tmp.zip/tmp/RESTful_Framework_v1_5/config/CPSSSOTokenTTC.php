<?php
/**
 * CPS SSO Token TTC Config file
 * by EdisonTsai on 16:27 2012/11/17
 */
return array(
				'TTCKEY'				=> 'CPSSSOTokenTTC',
				'TABLE'					=> 't_cps_sso_token_',
				'TimeOut'				=> 1,
				'KEY'					=> 'token',
				'IP'					=> '10.180.74.16:9146',
				'FIELDS'	=> array(
									'token' 		=> array('type' => 2, 'min' => 0, 'max' => 50),
									'mid' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'uid' 			=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'skey' 			=> array('type' => 2, 'min' => 0, 'max' => 255),
									'expire_time' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'create_time' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295),
									'update_time' 	=> array('type' => 1, 'min' => 0, 'max' => 4294967295)
				),
		);
?>