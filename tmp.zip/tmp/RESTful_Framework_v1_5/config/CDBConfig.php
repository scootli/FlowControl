<?php
	return 	array(
/*		'crm_test' 		  => array( 'IP' => '10.12.194.103','PORT' => 3306,'DB' => 'crm_test',		 'USER' => 'user_icson', 'PASSWD' => 'icson'),
		'crm_users_basic' => array( 'IP' => '10.12.194.103','PORT' => 3306,'DB' => 'crm_users_basic','USER' => 'user_icson', 'PASSWD' => 'icson'),
		'crm_users_info'  => array( 'IP' => '10.12.194.103','PORT' => 3306,'DB' => 'crm_users_info', 'USER' => 'user_icson', 'PASSWD' => 'icson'),
		'crm_admin' 	  => array( 'IP' => '10.12.194.103','PORT' => 3306,'DB' => 'crm_admin',		 'USER' => 'user_icson', 'PASSWD' => 'icson'),
		'order_alarm_log' => array( 'IP' => '10.12.194.103','PORT' => 3306,'DB' => 'orders_alarm_log',	 'USER' => 'user_icson', 'PASSWD' => 'icson'),
		'crm'             => array( 'IP' => '10.12.194.103','PORT' => 3306,'DB' => 'crm',       'USER' => 'user_icson', 'PASSWD' => 'icson'),
		'crm_orders'      => array( 'IP' => '10.12.194.103','PORT' => 3306,'DB' => 'crm_orders',       'USER' => 'user_icson', 'PASSWD' => 'icson'),
*/
	//	'cps_db'	  	  => array( 'IP' => '10.12.194.103','PORT' => 3306,'DB' => 'cps_db',      'USER' => 'user_icson', 'PASSWD' => 'icson'),
		'cps_db'	  	  => array( 'IP' => '10.206.30.125','PORT' => 9015,'DB' => 'cps_db',      'USER' => 'user_cps', 'PASSWD' => 'pwd_cps'),
		'OpenProdDB'	  => array( 'IP' => '10.206.30.125','PORT' => 9015,'DB' => 'open_prod_db', 'USER' => 'user_cps', 'PASSWD' => 'pwd_cps'),
		'crm'             => array( 'IP' => '10.206.30.113','PORT' => 3392 ,'DB' => 'crm', 'USER' => 'user_crm', 'PASSWD' => 'pwd_crm'),
	);
?>
