<?php
	Class PSFPackageUtils {
		public static $errCode = 0;
		public static $errMsg = '';
		public static function checkPackEnd($data) {
			$arr = unpack('Ilength',substr($data, 0, 4));
			$len = $arr['length'];
			if(strlen($data) >= $len)
				return true;
			return false;
		}
		public static function packData($data) {
			if(!is_array($data)) {
				return false;
			}
			$signData = self::getDataForSign($data);
			$sign = Tools::genSig($signData, 'k34h&32#');
			$data['sign'] = $sign;
			//$data = self::gbJsonEncode($data);
			$data = json_encode($data);
			$len = pack("I",strlen($data) + 4);
			return $len.$data;
		}
		public static function unPackData($data) {
			$data = substr($data,4);
			//$data = self::gbJsonDecode($data,true);
			$data = json_decode($data, true);
			if(!$data) {
				self::$errMsg = 'decode error';
				return false;
			}
			$signData = self::getDataForSign($data);
			$sign = Tools::genSig($signData, 'k34h&32#');
			if($data['sign'] != $sign) {
				self::$errMsg = 'sign not match,sign:'.$sign.' dataSign:'.$data['sign'];
				return false;
			}
			return $data;
		}
		public static function getDataForSign($data) {
			$ret = array();
			foreach($data as $k => $v) {
				if(is_array($v)) {
					//$ret[$k] = self::gbJsonEncode($v);
					$ret[$key] = json_encode($v);
				}
				else {
					$ret[$k] = $v;
				}
			}
			return $ret;
		}
		public static function gbJsonDecode($data)
		{
			$data = str_replace("\r\n", "", $data);
			$data = str_replace("\t", "", $data);
			$data = mb_convert_encoding($data, 'UTF-8', 'GBK');
			$data = json_decode($data, true);
			return empty($data) ? "" : self::_gbJsonDecode($data);
		}

		private static function _gbJsonDecode($data)
		{
			if (is_array($data)) {
				$res = array();

				foreach ($data as $key => $value)
					$res[$key] = self::_gbJsonDecode($value);
				return $res;
			} else {
				if(is_string($data)) {
					return mb_convert_encoding($data, 'GBK', 'UTF-8');
				}
				else {
					return $data;
				}
			}
		}
		
		public static function gbJsonEncode($data)
		{
			if (is_object($data)) {
				$data = get_object_vars($data);
			}
			if (is_array($data)) {
				$data = self::_gbkToUtf8($data);
				$data = json_encode($data);
			} else if (is_string($data)) {
				$data = json_encode(iconv("GBK", "UTF-8", $data));
			} else {
				return json_encode($data);
			}

			return preg_replace_callback('/\\\\u([0-9a-f]{4})/i',
				create_function(
					'$matches',
					'return iconv("UCS-2BE", "GBK//IGNORE", pack("H*", $matches[1]));'
				),
				$data);
		}

		private static function _gbkToUtf8($data)
		{
			if (is_object($data)) {
				$data = get_object_vars($data);
			}

			if (is_array($data)) {
				$res = array();

				foreach ($data as $key => $val) {
					$key = iconv('GBK', 'UTF-8', $key);
					$res[$key] = self::_gbkToUtf8($val);
				}

				return $res;
			} else if (is_string($data)) {
				return iconv('GBK', 'UTF-8', $data);
			} else {
				return $data;
			}
		}
	}
?>