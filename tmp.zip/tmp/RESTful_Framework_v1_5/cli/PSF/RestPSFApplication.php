<?php
/**
 *	REST PSF Application class file
 *
 *	@copyright (c) Tencent
 *	@created	15:49 2012/11/27
 *	@author		EdisonTsai
 * 	@version 	$Id$
 * 	@package 	system.cli.PSF
 * 	@since 		1.0
 */

 class RestPSFApplication extends RestApplication{

 	public function handler(){

 		PSFFramework::$root_path 			= Rest::getPathOfAlias('app').DIRECTORY_SEPARATOR;

		PSFFramework::$enable_cpu_affinity 	= true;
		PSFFramework::$enable_report 		= false;
		PSFFramework::$enable_set_procname 	= true;
		PSFFramework::$enable_fsmon 		= false;

		//added by EdisonTsai on 18:35 2012/11/30
			if(is_string(Rest::getConf('procName'))){
				PSFFramework::$PROC_NAME	=	Rest::getConf('procName');
			}

		PSFFramework::$param['report_sockfile'] = PSFFramework::$root_path.'rep.sock';

		$fream_obj = new PSFFramework;
		$fream_obj->start();

 	}

 }
?>