<?php
/**
 *	CliController class file
 *
 *	@copyright (c) Tencent
 *	@created	21:44 2012/11/29
 *	@author		EdisonTsai
 * 	@version 	$Id$
 * 	@package 	system.cli
 * 	@since 		1.0
 */

abstract class CliController{
	
}
?>