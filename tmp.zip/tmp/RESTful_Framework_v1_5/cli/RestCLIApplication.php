<?php
/**
 *	REST CLI Application class file
 *
 *	@copyright (c) Tencent
 *	@created	15:15 2012/12/05
 *	@author		EdisonTsai
 * 	@version 	$Id$
 * 	@package 	system.cli
 * 	@since 		1.0
 */

 class RestCLIApplication extends RestApplication{

 	public function handler(){
 		
 		$argv = func_get_args();

 		//@added by EdisonTsai on 15:42 2013/01/23 for accept argv
 		$argv = is_array($argv) && count($argv) >=1 ? array_pop($argv) : array();

 			$mainMod = Rest::getConf('mainModule');

 		if(!is_string($mainMod)){
 			echo "Invalid main module.\n";exit;
 		}
 		
 		if(class_exists('MainController')){

 			$obj 	= new MainController($mainMod, $argv);

 		}else{
 			echo "Invalid Main controller.\n";
 		}

 	}

 }
?>