<?php
/**
*	用户登录调用appplatform接口
* 	daopingsun 2013/06/06 17:00
*/
require_once('usericsonao_php5_stub.php');
require_once('usericsonao_php5_xxoo.php');
require_once('userapiao_php5_stub.php');

if (!defined("AUTHCODE")) {
	define('AUTHCODE', "zxcvbnm");
}

class UserWg{
	public static $errMsg = "";
	public static $errCode = 0;
	
	private static function clearErr(){
		self::$errMsg = "";
		self::$errCode = 0;
	}

	/**
	 * [GetSkey 用于获取wg_skey]
	 * @param  [type] $uid					[description]
	 * @param  [type] $clientIp				[description]
	 * @return [type] false or object		[description]
	 */
	public static function GetSkey($uid,$clientIp){
		self::clearErr();
		//检查参数
		if (!isset($uid) || $uid <= 0) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[uid($uid) is invalid]";
			return false;
		}elseif(empty($clientIp)) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[clientIp($clientIp) is empty]";
			return false;
		}

		$reqSps->source = __FILE__;
		$reqSps->machineKey = $clientIp;
		$reqSps->sceneId = 0;
		$reqSps->authCode = AUTHCODE;
		$reqSps->icsonUid = $uid;
	
		$ret = WebStubCntl2::request(
			'b2b2c\user\ao\GetSkey',
			array(
				'opt' => array(
					'uin' => $uid,
					'operator' => $uid,
					'passport' => "",
					'caller' => 'User'
				),
				'req' => (array)$reqSps
			)
		);
		if($ret && $ret['code'] == 0){
			return (object)$ret['data'];
		}

		self::$errCode = $ret['code'];
		self::$errMsg = $ret['msg'];
		return false;
	}
	
	/**
	 * [IsQQorAccountRegistered 用于检测三种类型的用户是否注册]
	 * [accountType defined in user_comm_define.h(E_ICSON_USER_ACCOUNT_TYPE)]
	 * @param  [type] $accountType      [description]
	 * @param  [type] $loginAccount		[description]
	 * @param  [type] $qq				[description]
	 * @param  [type] $clientIp			[description]
	 * @return [type] false or 0/1		[description]
	 */
	public static function IsQQorAccountRegistered($accountType, $loginAccount="", $qq=0 , $clientIp){
		self::clearErr();

		if(empty($clientIp)) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[clientIp($clientIp) is empty]";
			return false;
		}
		$uid = rand(0,100000);
		$reqSps->source = __FILE__;
		$reqSps->machineKey = $clientIp;
		$reqSps->sceneId = 0;
		if($accountType == 1){//用户QQ号，accountType填1时必填，目前仅支持32位
			$reqSps->loginAccount = $loginAccount;
			$reqSps->qQNumber = $qq;
			$reqSps->accountType = 1;
			$uid = $qq;
		}else if($accountType == 2){//个性登录帐号（如易迅注册帐号、Login_ +Openid等），accountType填2时必填
			$reqSps->loginAccount = $loginAccount;
			$reqSps->accountType = 2;
		}else if($accountType == 3){//联合登录帐号（如Login_SAND_test等），accountType填3时必填
			$reqSps->loginAccount = $loginAccount;
			$reqSps->accountType = 3;
		}else{
			self::$errCode = 129;
			self::$errMsg = "accountType is error, accountType:".$accountType.", loginAccount:".$loginAccount.", qq:".$qq;
			return false;
		}

		$ret = WebStubCntl2::request(
			'b2b2c\user\ao\IsQQorAccountRegistered',
			array(
				'opt' => array(
					'uin' => $uid,
					'operator' => $uid,
					'caller' => 'User'
				),
				'req' => (array)$reqSps
			)
		);
		if($ret && $ret['code'] == 0){
			if($ret['data']['result'] == 0){
				return $ret['data']['retValue'];
			}
			self::$errCode = $ret['data']['result'];
			self::$errMsg = $ret['data']['errmsg'];
			return false;
		}
		self::$errCode = $ret['code'];
		self::$errMsg = $ret['msg'];
		return false;
	}
	
	/**
	 * [IcsonUniformLogin 仅用于$accountType=1的QQ用户登录]
	 * [accountType defined in user_comm_define.h(E_ICSON_USER_ACCOUNT_TYPE)]
	 * @param  [type] $accountType      [description]
	 * @param  [type] $qq(QQ号)			[description]
	 * @param  [type] $ptskey			[description]
	 * @param  [type] $clientIp			[description]
	 * @return [Object]	false or object [description]
	 */
	public static function IcsonUniformLogin($accountType=1, $qq, $ptskey, $clientIp){
		self::clearErr();
	
		if($accountType != 1) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[accountType($accountType) is invalid]";
			return false;
		}elseif(empty($qq) || !is_numeric($qq)) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[qq($qq) is invalid]";
			return false;
		}elseif(empty($ptskey)) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[ptskey($ptskey) is empty]";
			return false;
		}elseif(empty($clientIp)) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[clientIp($clientIp) is empty]";
			return false;
		}
		$reqSps->source = __FILE__;
		$reqSps->machineKey = $clientIp;
		$reqSps->sceneId = 0;
		$reqSps->authCode = AUTHCODE;
		
		$loginInfoPo->accountType = $accountType;
		$loginInfoPo->qQNumber = $qq;
		$loginInfoPo->qQSkey = $ptskey;
		$reqSps->loginInfoPo = (array)$loginInfoPo;
				
		$ret = WebStubCntl2::request(
			'b2b2c\user\ao\IcsonUniformLogin',
			array(
				'opt' => array(
					'uin' => $qq,
					'operator' => $qq,
					'caller' => 'User'
				),
				'req' => (array)$reqSps
			)
		);
		if($ret && $ret['code'] == 0){
			return (object)$ret['data'];
		}

		self::$errCode = $ret['code'];
		self::$errMsg = $ret['msg'];
		return false;
	}

	/**
	 * [IcsonUniformLogin3 仅用于$accountType=3用户登录Login_SAND_abcdefg : accountType=3,openid='abcdefg',openidFrom=2]
	 * [accountType defined in user_comm_define.h(E_ICSON_USER_ACCOUNT_TYPE)]
	 * [openidFrom defined in user_comm_define.h(E_LOGIN_OPENID_FROM)]
	 * @param  [type] $accountType      [description]
	 * @param  [type] $openid			[description]
	 * @param  [type] $openidFrom		[description]
	 * @param  [type] $clientIp			[description]
	 * @return [Object]	false or object [description]
	 */
	public static function IcsonUniformLogin3($accountType=3, $openid, $openidFrom , $clientIp){
		if($accountType != 3) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[accountType($accountType) is invalid]";
			return false;
		}elseif(empty($openid)) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[openid($openid) is empty]";
			return false;
		}elseif(empty($openidFrom)) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[openidFrom($openidFrom) is empty]";
			return false;
		}elseif(empty($clientIp)) {
			self::$errCode = 122;
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . __LINE__ . "[clientIp($clientIp) is empty]";
			return false;
		}
		self::clearErr();
		$reqSps->source = __FILE__;
		$reqSps->machineKey = $clientIp;
		$reqSps->sceneId = 0;
		$reqSps->authCode = AUTHCODE;
		
		$loginInfoPo->accountType = $accountType;
		$loginInfoPo->openid = $openid;
		$loginInfoPo->openidFrom = $openidFrom;		
		$reqSps->loginInfoPo = (array)$loginInfoPo;

		$uid = rand(0,100000);
		$ret = WebStubCntl2::request(
			'b2b2c\user\ao\IcsonUniformLogin',
			array(
				'opt' => array(
					'uin' => $uid,
					'operator' => $uid,
					'caller' => 'User'
				),
				'req' => (array)$reqSps
			)
		);
		if($ret && $ret['code'] == 0){
			return (object)$ret['data'];
		}

		self::$errCode = $ret['code'];
		self::$errMsg = $ret['msg'];
		return false;
	}
}

?>