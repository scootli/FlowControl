<?php 
/**
 * IDistributionProductDao.php
 * ��:t_retailer_product �������顢ɾ���Ĳ���
 * ��:retailer
 */

class IRetailerProductDao
{
	/**
	 * �������
	 */
	public static $errCode = 0;

	/**
	 * ������Ϣ
	 */
	public static $errMsg  = '';
	
	/**
	 * ���ݿ��
	 */
	public static $dbName = 'retailer';
	
	public static $tableName = 't_retailer_product';
	
	/**
	 * ������
	 */
	public static $fileds = array('retailerId','productId','productNo','category1','category2',
					'category3','brandId','addPrice','priceType','shelveState','topState',
					'priceingState','createTime','updateTime','stockState','isDelete');

	/**
	 * ��������ʶ����ÿ����������ǰ����
	 */
	private static function clearErr()
	{
		self::$errCode = 0;
		self::$errMsg  = '';
	}
	
	/**
	 * ���ô����ʶ
	 * @param int $code ������
	 * @param string $msg ������Ϣ
	 * @return null
	 */
	private static function setErr($code, $msg=null) 
	{
		self::$errCode = $code;
		self::$errMsg  = $msg;
	}
	
	/**
	 * ����һ��DB��¼
	 * @param array $data Ҫ��������ݣ���ʽ: array(key=>value)
	 * @return boolean ��ȷ����true�����󷵻�false
	 */
	public static function insert($data) 
	{
		self::clearErr();
		if (empty($data) || !is_array($data))
		{
			self::setErr(111, 'parameter is invalid');
			
			return false;
		}
		
		$v = IBProductTTC::insert($data);
		if (!$v) 
		{
			self::setErr(IBProductTTC::$errCode, IBProductTTC::$errMsg);
			
			return false;
		}
		
		return $v;
	}
	
	/**
	 * ��������
	 * @param array $records
	 * ��ʽ  :array(
	 * 		       array(key1 => 'xx',key2=>'xx',...),
	 * 			   array(key1 => 'xx',key2=>'xx',...),
	 * 				...
	 * 		)
	 * @return boolean �ɹ�?ʧ��
	 */
	public static function batchInsert($records) 
	{
		self::clearErr();
		
		if (!is_array($records) || empty($records))
		{
			self::setErr(111, 'parameter is invalid');
			
			return false;
		}
		
		$v = false;
		foreach ($records AS $record)
		{
			if (!is_array($record))
			{
				self::setErr(-4001,'record to insert is invalid');	
			
				return false;
			}
			$v = IBProductTTC::insert($record);
			if (!$v) 
			{
				self::setErr(IBProductTTC::$errCode, IBProductTTC::$errMsg);
				
				return false;
			}
		}
		
		return $v;
	}
	
	/**
	 * ����DB��¼
	 * @param array $data Ҫ���µ����ݣ�
	 * ��ʽ: array(
	 * 			'retailerId'=>'xx',  //������
	 * 			key=>'xx',
	 * 			...
	 * 			'productIds'=> array(id1,id2,...)
	 * 			,
	 * )
	 * @param array $filter ���ݿ��ѯ��������ʽ��v=1 and v1=2
	 * @param array $pids  
	 * @return boolean ��ȷ����true�����󷵻�false
	 */
	public static function update($data, $filter) 
	{
		self::clearErr();

		if (empty($data) || !is_array($data) || !isset($data['retailerId']))
		{
			self::setErr(111, 'parameter is invalid');
			
			return false;
		}	
		
		$v = false;
		if ((isset($data['productIds'])) &&
		      (is_array($data['productIds'])) && 
				(count($data['productIds']) > 0))
		{
			foreach ($data['productIds'] AS $pid)
			{
				$filter['productId'] = $pid;
				$v = IBProductTTC::update($data, $filter);
				if (!$v) 
				{
					self::setErr(IBProductTTC::$errCode, IBProductTTC::$errMsg);
					
					return false;
				}
			}	
		}
		else 
		{
			$v = IBProductTTC::update($data, $filter);
		}
		if (!$v) 
		{
			self::setErr(IBProductTTC::$errCode, IBProductTTC::$errMsg);
			
			return false;
		}
		
		return $v;
	}
	
	/**
	 * ɾ��һ����¼
	 * @param string $key 
	 * @param array $filter ���ݿ��ѯ��������ʽ����ttc filterһ��
	 * @return boolean ��ȷ����true�����󷵻�false
	 */
	public static function remove($key, $filter) 
	{
		self::clearErr();

		if (!isset($key) || empty($key))
		{
			self::setErr(111, 'parameter is invalid');
			
			return false;
		}
		$v = IBProductTTC::remove($key, $filter);
		if (!$v) 
		{
			self::setErr(IBProductTTC::$errCode, IBProductTTC::$errMsg);
			
			return false;
		}
		
		return $v;
	}
	
	/**
	 * ��ȡ������Ʒ��Ϣ
	 * @param array $data 
	 * ��ʽ��
	 * 	array(
	 * 	 'retailerId' => int
	 * 	 'keys' => array
	 * 	 'pids' =>array
	 * )
	 * @param array $filter 
	 * @return ��ȷ�������ݣ����󷵻�false
	 */
	public static function getRows($condition,$filter = array(),$itemLimit = 0, $start = 0)
	{
		self::clearErr();
		
		if (!is_array($condition))
		{
			self::setErr(111, 'parameter is invalid');
			
			return false;
		}	
		
		/**
		 *key��ʹ��ttc��ѯ 
		 */
		$v = array();
		if (isset($condition['retailerId']))  
		{
			$v = IBProductTTC::get($condition['retailerId'], $filter, array(),$itemLimit, $start);
			if (false === $v) 
			{
				self::$errCode = IBProductTTC::$errCode;
				self::$errMsg  = IBProductTTC::$errMsg;
				
				return false;
			}
			if (isset($condition['pids']) && is_array($condition['pids']))
			{	
				$ret_arr = array();
				foreach ($condition['pids'] AS $pid)
				{
					foreach ($v AS $product)
					{
						if ($pid == $product['productId'])
						{
							array_push($ret_arr,$product);
							break;
						}
					}
				}
				return $ret_arr;
			}
		}
		else  //������keyֵ ʹ��mysql
		{
			if (isset($condition['keys']) && is_array($condition['keys']) && count($condition['keys']) > 0)
			{
				$v = IBProductTTC::gets($condition['keys'], $filter);
			}
			else 
			{
				$mysql = Config::getDB(self::$dbName);
				if (!$mysql) 
				{
					self::setErr( Config::$errCode, Config::$errMsg);
			
					return false;
				}
				$where_sql = self::getFilterString($filter,$mysql);
				$sql = 'SELECT * from t_retailer_product where ' . $where_sql ;
				$v = $mysql->getRows($sql );
				if($v === false) 
				{
					self::$errCode = $mysql->errCode;
					self::$errMsg  = $mysql->errMsg;
					return false;
				}
			}
		}
		
		return $v;
	}
	
	/**
	 *	 ƴ�� and ��ѯ���� 
	 */
	public  static function getFilterString($filter, $db)
	{
		$where_sql = ' isDelete=0 ';   //δɾ����
		if (is_array($filter))
		{
			foreach ($filter AS $field => $field_value)
			{
				if(!in_array($field,self::$fileds))
				{
					self::setErr(-100,'wrong field name of t_retailer_product');
					
					return false;
				}
				if (isset($field_value))
				{
					$where_sql .= sprintf(' AND %s = "%s"',
										$db->filterString($field),
										$db->filterString($field_value));
				}
			}
		}
		
		return $where_sql;
	}

}	
//End Of Script

