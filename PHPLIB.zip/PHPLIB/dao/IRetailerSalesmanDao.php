<?php
/**
 * ���������˺� (����Ա)��
 * @author derongzeng
 * @version 1.0
 * @package distribution
 */
class IRetailerSalesmanDao {
    
    public static $dbName = 'retailer';
    
    public static $tableName = 't_retailer_salesman';
    
    /**
     * ������
     */
    public static $errCode = 0;
    
    /**
     * ������Ϣ
     */
    public static $errMsg = '';
    
    
	/**
     * 
     * ���ݷ�����ID��ͳ��ÿ��������ӵ�ж��ٸ����˺�
     * @param unknown_type $retailerIds
     */
    public static function countSalesmans($retailerIds = array()) {
        $sqlStr = "select count(*) as num, retailerId from " . self::$tableName;
        $sqlStr .= " where status  < 9";
        if ($retailerIds) {
            $sqlStr .= " and retailerId in (" . implode(',', $retailerIds) . ")";
        }
        $sqlStr .= " group by retailerId";
        $db = ToolUtil::getDBObj ( self::$dbName );
        $rows = $db->getRows ( $sqlStr );
        if (FALSE === $rows) {
            self::$errCode = $db->errCode;
            self::$errMsg  = basename ( __FILE__, '.php' ) . " |" . __LINE__ . "get retailer_salesman count failed " . $db->errMsg;
            return FALSE;
        }
        return $rows;
    }
}