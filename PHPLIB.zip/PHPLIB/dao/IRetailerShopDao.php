<?php

/**
 * �������ŵ��
 * @author derongzeng
 * @version 1.0
 * @package distribution
 */
class IRetailerShopDao {
    
    public static $dbName = 'retailer';
    
    public static $tableName = 't_retailer';
    
    /**
     * ������
     */
    public static $errCode = 0;
    
    /**
     * ������Ϣ
     */
    public static $errMsg = '';
    
    public static $operatorId = 0;
    
    public static $operatorName = '';
    
    public static function clearErr(){
    	self::$errCode = 0;
    	self::$errMsg = '';
    }
    
	/**
     * 
     * ��ȡ�����ŵ���Ϣ
     * @param array $conditions
     * @return array
     */
    public static function getAll($conditions = array()) {
        $db = ToolUtil::getDBObj ( self::$dbName );
        $sqlStr = "select * from " . self::$tableName;
        $sqlStr .= " where " . self::_getWhereSql($db, $conditions);
        $sqlStr .= " order by regTime desc";
        $rows = $db->getRows ( $sqlStr );
        if (FALSE === $rows) {
            self::$errCode = $db->errCode;
            self::$errMsg = basename ( __FILE__, '.php' ) . " |" . __LINE__ . " get retailer_shop failed " . $db->errMsg;
            return FALSE;
        }
        
        foreach ($rows AS &$row){
        	$row['shopName'] = $row['conpanyName'];
        	$row['shopId'] = $row['uid'];
        	$row['retailerId'] = $row['pid'];
        	$row['contact'] = $row['name'];
        	$row['phone'] = $row['tel'];
        	$row['checkTime'] = $row['auditTime'];
        	$row['operatorName'] = $row['info'];
        	$row['updateTime'] = $row['editTime'];
        	$row['status'] = $row['level'];
        }
        reset($rows);
        
        return $rows;
    }
    
    /**
     * 
     * ���ݷ�����ID��ͳ��ÿ��������ӵ�ж��ٸ��ŵ�
     * @param unknown_type $retailerIds
     */
    public static function countShops($retailerIds = array()) {
        $sqlStr = "select count(*) as num, pid as retailerId from " . self::$tableName;
        $sqlStr .= " where status  >=0 ";
        if ($retailerIds) {
            $sqlStr .= " and pid in (" . implode(',', $retailerIds) . ")";
        }
        $sqlStr .= " group by pid ";
        $db = ToolUtil::getDBObj ( self::$dbName );
        $rows = $db->getRows ( $sqlStr );
        if (FALSE === $rows) {
            self::$errCode = $db->errCode;
            self::$errMsg  = basename ( __FILE__, '.php' ) . " |" . __LINE__ . "get retailer_shop count failed " . $db->errMsg;
            return FALSE;
        }
        return $rows;
    }
    
    /**
     * 
     * ��������������ƴ���������
     * ���ǰ�治��where�Ϳո񣬺��治���ո񣬻������ֵ����Ҫ����
     * @param array $conditions
     * @return string
     */
    private static function _getWhereSql ($db, $conditions = array()) {
        $whereSql = 'status = 0';
        if (isset ( $conditions ['status'] ) && '' != $conditions ['status']) {
  			 $whereSql .= " and level=" . intval($conditions ['status']) ;
        }
        if (isset ( $conditions ['retailerId'] )) {
            if (is_array($conditions ['retailerId'])) {
                $whereSql .= " and pid in (" . implode(',', $conditions ['retailerId']) . ")";
            }
            else if ('' != $conditions ['retailerId']) {
                $whereSql .= " and pid = " . intval($conditions ['retailerId']);
            }
        }
        if (isset ( $conditions ['shopIds'] )) {
            $whereSql .= " and uid in (" . implode(',', $conditions ['shopIds']) . ")";
        }
        if (isset ( $conditions ['time_start'] ) && '' != $conditions ['time_start']) {
            $whereSql .= " and editTime > " .  intval($conditions ['time_start']);
        }
        if (isset ( $conditions ['time_end'] ) && '' != $conditions ['time_end']) {
            $whereSql .= " and editTime < " . intval($conditions ['time_end']);
        }
        if (isset ( $conditions ['name'] ) && '' != $conditions ['name']) {
            $whereSql .= " and conpanyName like '%" . $db->filterString ( $conditions ['name'] ) . "%'";
        }
        if (isset ( $conditions ['contact'] ) && '' != $conditions ['contact']) {
            $whereSql .= " and name like '%" . $db->filterString ( $conditions ['contact'] ) . "%'";
        }
        return $whereSql;
    }
    
	public static function get($pid, $shopId='', $filter = array(), $need = array(), $itemLimit = 0, $start = 0)
	{
		self::clearErr();
		if (empty($shopId)){
			$retailerDB = ToolUtil::getDBObj ( self::$dbName );
			if (empty($retailerDB)){
				Logger::err('connect to mysql db failed[]');
				self::$errMsg = 'connect to mysql db failed[]';
				return false;
			}
			$condition = ' pid=' . $pid . ' AND stage=2 ';
			/**
			 *
			 */
			if (isset($filter['status'])){
				$condition .= ' AND status=' . $filter['status']; //ɾ��״̬
			}
			if (isset($filter['level'])){
				$condition .= ' AND level=' . $filter['level'];   //���״̬
			}	
			if (isset($filter['conpanyName'])){
				$condition .= " AND conpanyName='" . ToolUtil::filterInput($filter['conpanyName']) . "'";   //�ŵ�����
			}
			$condition .= " order by regTime asc ";
	
$sql = <<<SQL
   SELECT *
   FROM  t_retailer
   WHERE $condition
SQL;
if ($start !== 0 || $itemLimit !== 0){
	$sql .= ' limit ' . $start . ' ,' . $itemLimit;
}
			$shops = $retailerDB->getRows($sql);

			foreach ($shops AS &$shop){
				$shop['shopName'] = $shop['conpanyName'];
				$shop['shopId'] = $shop['uid'];
				$shop['retailerId'] = $shop['pid'];
				$shop['contact'] = $shop['name'];
				$shop['phone'] = $shop['tel'];
				$shop['checkTime'] = $shop['auditTime'];
				$shop['operatorName'] = $shop['info'];
				$shop['emergencyContact'] = '--';
				$shop['emergencyMobile'] = '--';
				$shop['emergencyPhone'] = '--';
				$shop['updateTime'] = $shop['editTime'];
				$shop['status'] = $shop['level'];
			}
			return $shops;
		}
	
		//�ṩ���ŵ��ʺ�����
		if (!empty($pid)){
			$filter['pid'] = $pid;
		}
		$v = IRetailerTTC::get($shopId, $filter, $need, $itemLimit, $start);
		
		if (false == $v){
			Logger::err('IRetailerTTC get failed[]' . IRetailerTTC::$errMsg);
			self::$errMsg = 'IRetailerTTC get failed[]' . IRetailerTTC::$errMsg;
			return false;
		}
		foreach ($v AS &$shop){
			$shop['shopName'] = $shop['conpanyName'];
			$shop['shopId'] = $shop['uid'];
			$shop['retailerId'] = $shop['pid'];
			$shop['contact'] = $shop['name'];
			$shop['phone'] = $shop['tel'];
			$shop['checkTime'] = $shop['auditTime'];
			$shop['operatorName'] = $shop['info'];
			$shop['emergencyContact'] = '--';
			$shop['emergencyMobile'] = '--';
			$shop['emergencyPhone'] = '--';
			$shop['updateTime'] = $shop['editTime'];
			$shop['status'] = $shop['level'];
		}
		
		return $v;
	}
	
	public static function count($pid, $filter = array())
	{
		self::clearErr();
	
		$retailerDB = Resource::getDB(Config_DB::$Retailer);
		if (empty($retailerDB)){
			Logger::err('connect to mysql db failed[]');
			return false;
		}
		$condition = ' pid=' . $pid . ' AND stage=2 ';
		/**
		 *
		 */
		if (isset($filter['status'])){
			$condition .= ' AND status=' . $filter['status']; //ɾ��״̬
		}
		if (isset($filter['level'])){
			$condition .= ' AND level=' . $filter['level'];   //���״̬
		}
		if (isset($filter['conpanyName'])){
			$condition .= " AND conpanyName='" . ToolUtil::filterInput($filter['conpanyName']) . "'";   //�ŵ�����
		}
	
		$sql = <<<SQL
   SELECT count(*) AS total
   FROM  t_retailer
   WHERE $condition
SQL;
	
		$shops = $retailerDB->getRows($sql);
		if (is_array($shops) && isset($shops[0]['total'])){
			return $shops[0]['total'];
		}
		self::$errMsg = var_export($sql,true);
		return false;
	}
	
	/**
	 * ����һ���ŵ꣨�ӷ����̣���¼
	 *
	 * @param	$param ��ʽ:
	 * 	array(
	 * 		'uid' =>  XXX,
	 * 		'icsonid' => 'XXX',
	 * 		'name' => 'XXX',
	 * 		'tel' => 'XXX',
	 * 		'email' => 'XXX',
	 * 		'retailerType' =>  XXX,
	 * 		'level' =>  XXX,
	 * 		'regTime' =>  XXX,
	 * 		'auditUser' => 'XXX',
	 * 		'editTime' =>  XXX,
	 * 		'auditTime' =>  XXX,
	 * 		'status' =>  XXX,
	 * 		'invoiceId' =>  XXX,
	 * 		'regIP' => 'XXX',
	 * 		'info' => 'XXX',
	 * 		'logo' => 'XXX',
	 * 		'conpanyName' => 'XXX',
	 * 		'fax' => 'XXX',
	 * 		'mobile' => 'XXX',
	 * 		'sex' =>  XXX,
	 * 		'district' =>  XXX,
	 * 		'address' => 'XXX',
	 * 		'zipcode' => 'XXX',
	 * 		'bindManager' => 'XXX',
	 * 		'useInvoice' =>  XXX,
	 * 		'pid' => XXX,
	 * 		'stage' => XXX
	 * 		)
	 *
	 * ����ֵ����ȷ����true�����󷵻�false
	 */
	public static function insert($param)
	{
		self::clearErr();
	
		if(empty($param) || !is_array($param))
		{
			self::$errCode = 111;
			self::$errMsg  = 'param is empty';
		}
	
		$v = IRetailerTTC::insert($param);
		if (false == $v){
			self::$errCode = IRetailerTTC::$errCode;
			self::$errMsg = IRetailerTTC::$errMsg;
		}
		return $v;
	}
	
	/**
	 * ����һ��TTC��¼
	 *
	 * @param	$param ��ʽ:
	 * 	array(
	 * 		'uid' =>  XXX,
	 * 		'icsonid' => 'XXX',
	 * 		'name' => 'XXX',
	 * 		'tel' => 'XXX',
	 * 		'email' => 'XXX',
	 * 		'retailerType' =>  XXX,
	 * 		'level' =>  XXX,
	 * 		'regTime' =>  XXX,
	 * 		'auditUser' => 'XXX',
	 * 		'editTime' =>  XXX,
	 * 		'auditTime' =>  XXX,
	 * 		'status' =>  XXX,
	 * 		'invoiceId' =>  XXX,
	 * 		'regIP' => 'XXX',
	 * 		'info' => 'XXX',
	 * 		'logo' => 'XXX',
	 * 		'conpanyName' => 'XXX',
	 * 		'fax' => 'XXX',
	 * 		'mobile' => 'XXX',
	 * 		'sex' =>  XXX,
	 * 		'district' =>  XXX,
	 * 		'address' => 'XXX',
	 * 		'zipcode' => 'XXX',
	 * 		'bindManager' => 'XXX',
	 * 		'useInvoice' =>  XXX,
	 * 		'pid' => XXX,
	 * 		'stage' => XXX
	 * 		)
	 *
	 * ����ֵ����ȷ����true�����󷵻�false
	 */
	public static function update($param, $filter = array())
	{
		self::clearErr();
	
		$v = IRetailerTTC::update($param, $filter);
		if (false == $v){
			self::$errCode = IRetailerTTC::$errCode;
			self::$errMsg = IRetailerTTC::$errMsg;
		}
		return $v;
	}
	
	/**
	 * ɾ��һ��TTC��¼
	 *
	 * @param   string  $key		���ݿ������(�ӷ�����id retailerId)
	 *
	 * ����ֵ����ȷ����true�����󷵻�false
	 */
	public static function remove($key, $filter= array())
	{
		self::clearErr();
	
		if(empty($key))
		{
			self::$errCode = 111;
			self::$errMsg  = 'key is empty';
		}
	
		$v = IRetailerTTC::remove($key, $filter);
		if (false == $v){
			self::$errCode = IRetailerTTC::$errCode;
			self::$errMsg = IRetailerTTC::$errMsg;
		}
		return $v;
	}
}