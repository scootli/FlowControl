<?php
require "_init.php";

use Com\Paipai\Touch;

Touch\API::init();

$mailParam = new Touch\MailParam();

$mailParam->touchParam->businessType = 101;
$mailParam->touchParam->subBusiness = 1;
$mailParam->touchParam->businessInfo = '12220-15151515';
$mailParam->touchParam->templateId = 10961;

$mailParam->qq = 350749960;
$mailParam->mailAddr = '350749960@qq.com';
$mailParam->type = MAIL_NORMAL;

array_push($mailParam->touchParam->contentArray, iconv('gbk', 'utf-8', '������').mt_rand(111,999));
array_push($mailParam->touchParam->contentArray, iconv('gbk', 'utf-8', '<h1>����һ������</h1>'));

var_dump($mailParam->touchParam->contentArray);
//array_push($mailParam->touchParam->contentArray, 'testt', '<h1>qqbusy.com.test</h1>');
//$mailParam->touchParam->contentArray=array("testt", "<h1>qqbusy.com.test</h1>");

echo "SendMail..........\n";
$result = Touch\SendMail($mailParam);
echo "Finish.........";
echo "result Code=[".$result->resultCode.']|msg='.$result->errMsg."\n";




