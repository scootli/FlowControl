<?php
require_once ROOT_PATH . 'include/mobileWebProxy.php';
require_once MODAPI_PATH . 'mobile/include/Adver.php';
if(!empty($json_flag))
 {
    switch ( get_cfg_var('server_type') )
    {
    case 'develop':
        //��������
        define('MOBILE_URL', 'http://fwd.qq.com/');
        break;

    case 'preview':
        //���Ի���
       define('MOBILE_URL', 'http://fwt.qq.com/');
        break;
    case 'formal':
    default:
        //��ʽ����
       define('MOBILE_URL', 'http://fwc.qq.com/');
    }
}
else
{
     switch ( get_cfg_var('server_type') )
    {
    case 'develop':
        //��������
        define('MOBILE_URL', 'http://jt.qq.com/');
		define('MOBILE_MQZONE_URL', 'http://ugc.ft.qq.com/');
        break;

    case 'preview':
        //���Ի���
       define('MOBILE_URL', 'http://ft.qq.com/');
	   define('MOBILE_MQZONE_URL', 'http://ugc.ft.qq.com/');
        break;
    case 'formal':
    default:
        //��ʽ����
       define('MOBILE_URL', 'http://f.qq.com/');
	   define('MOBILE_MQZONE_URL', 'http://ugc.f.qq.com/');
    }
}
//define('LOGIN_3G_URL' , 'http://pt.3g.qq.com/g/s?aid=nLogin&q_from=xiaoyou&loginTitle=' . urlencode('�ֻ�����') . '&go_url=' . urlencode(MOBILE_URL . 'index.php?mod=home&fromlogin=1'));
define('LOGIN_3G_URL' , 'http://pt.3g.qq.com/g/s?aid=cpgamelogin&cpid=700&gameid=7901&go_url=' . urlencode(MOBILE_URL . 'index.php?mod=home&fromlogin=1&flag=9'));
define('LOGIN_3G_URL_NO_RETURN' , 'http://pt.3g.qq.com/g/s?aid=cpgamelogin&cpid=700&gameid=7901');
define('URL_3G', 'http://qzone.z.qq.com');// �ֻ��ռ��url
define('MOBILE_MGROUP_URL', MOBILE_URL);

define('MOBILE_MQZONE_BLOG_URL', MOBILE_MQZONE_URL);
define('MOBILE_MQZONE_GIFT_URL', MOBILE_MQZONE_URL);
define('MOBILE_MQZONE_PHOTO_URL', MOBILE_MQZONE_URL);
define('MOBILE_MQZONE_SHARE_URL', MOBILE_MQZONE_URL);
define('MOBILE_MQZONE_TWITTER_URL', MOBILE_MQZONE_URL);
define('MOBILE_MQZONE_EMOTION_URL', MOBILE_MQZONE_URL);
define('MOBILE_MQZONE_LIKE_URL', MOBILE_MQZONE_URL);
define('MOBILE_MESSAGE_URL', MOBILE_MQZONE_URL);

/**
 * �����ͼ
 *
 * @param array $data
 * @param bool $return ����Ϊtrueʱ�����ض������
 *
 * @return void
 */
function display($data, $return = false)
{
	global $mod_name, $act_name, $login_uin, $SID_KEY, $plat_type;

	$WAP_CSS_VERSION = 41;//��ʶwap�汾�ţ�����css��ʱ���

    $version = get_wap_version();

	//ģ������
	$tpl_name = empty(ViewManager::$options['tpl']) ? $mod_name . '/' . $act_name : ViewManager::$options['tpl'];

	//����  - ���ٴ������ԣ���ʶwap1.0��wap2.0
	//$lang = ViewManager::$options['lang'];
	$lang = (!isset($_REQUEST['json']) && $version == 1) ? 'zh_cn_1' : 'zh_cn';

	//ģ��cache·��
	$tpl_cache_path = ROOT_PATH . 'tpl_cache/';

	$server_type = get_cfg_var('server_type');
	$parse_tpl = get_cfg_var('parse_tpl');
	if ($server_type == 'develop' || $server_type == 'personal' || $server_type == 'test' || $parse_tpl == 1)
	{
		//����ģ��
		parse_tpl($tpl_name, $tpl_cache_path, $lang);
	}

	//����ģ������ʹ�õĺ���
	require_once ROOT_PATH . 'include/TplHelper.php';

	if (ViewManager::$options['need_header'])
	{
		$data['_head_nav'] = prepare_nav_data();
	}

	/*------------------��ȡqbarfoot������----------------*/
	$qbarfoot_arr = array('qbar'=>array(),'foot'=>array());

	//�ض�ҳ�����ʾqbar������Щҳ��ʱȥ��ȡ�ӿ�
	if($version == 1 && ($mod_name == 'home' && $act_name == 'page' || $mod_name == 'home' && $act_name == 'newpage' || $mod_name=='app' && $act_name=='page') )
	{
		//array('host'=>'172.27.31.48','port'=>'9048'),
		require_once SNSLIB_PATH . 'API/QBar_wup/QBarInterface.php';
		$sid = str_replace(' ' , '+' , $SID_KEY);

		//ģ�����
		require_once SNSLIB_PATH.'LIB/ModuleState.php';
		//ȥ��qbar foot
		/*
		$qbarfoot_module_state_id = 108001006;	// �ֻ�������qbar��foot��Ϣ �� ģ��id
		ModuleState::tick($qbarfoot_module_state_id);
		//ȡserver�ӿ�
		$tmp_arr = QBarInterface::getQbarFootData($login_uin , $sid , '');
		if(!$tmp_arr || !isset($tmp_arr['qbar']) || !isset($tmp_arr['foot']))
		{
			ModuleState::report( $qbarfoot_module_state_id , ModuleState::ERR );
		}
		else
		{
			ModuleState::report( $qbarfoot_module_state_id , ModuleState::SUC );
		}
		*/
		$tmp_arr = array();
		//��qbar���ݽ������и�ʽ������
		if(isset($tmp_arr['qbar']) && is_array($tmp_arr['qbar']))
		{
			foreach($tmp_arr['qbar'] as $k=>$v)
			{
				$line = $v['location'];
				//qbarԭ��ֻ��һ�еģ�����qbar��������˼������Э�飬999�Ļ���Ų���ڶ�����ʾ - 20110510
				if($line == 999 )
				{
					$qbarfoot_arr['qbar'][1][0] = $v;
				}
				else
				{
					$qbarfoot_arr['qbar'][0][$line-1] = $v;
				}
			}
		}

		//��foot���ݽ������и�ʽ������
		if(isset($tmp_arr['foot']) && is_array($tmp_arr['foot']))
		{
			foreach($tmp_arr['foot'] as $key=>$value)
			{
				//���˳���������ӣ���Ҫ��������һ�£���Ϊqbar�������˳���������Ѷ��ҳ���ˡ�����
				if($value['title'] == '�˳�')
				{
					$value['url'] = MOBILE_URL . 'index.php?mod=login&amp;act=out&amp;sid='.$SID_KEY;
				}
				$row = $value['type'];
				$line = $value['location'];
				$qbarfoot_arr['foot'][$row][$line-1] = array(
					'type'		=>	empty($value['url']) ? 'word' : 'link',
					'title'		=>	str_replace('&lt;br /&gt;' , ' ' , $value['title']) ,//�������⻻���ַ�
					'url'		=>	isset($value['url']) ? $value['url'] : '',
					'value'		=>	isset($value['value']) ? $value['value'] : '',
				);
				//2011-07-20�¼ӣ�����value������post���ͣ���Ҫ��post����
				if( $qbarfoot_arr['foot'][$row][$line-1]['value'] )
				{
					$qbarfoot_arr['foot'][$row][$line-1]['type'] = 'post_link';
				}
			}
		}
		//�ӿ�ȡֵ�ɹ������footֵ����cache������������qbar��ҳ����ʾfoot
		if(!empty($qbarfoot_arr['qbar']) && !empty($qbarfoot_arr['foot']))
		{
			$cache = SNS_ResourceManager::getStorage('newtemp');
			//дcache�����Դ���
			if($cache)
			{
				$cache->set('wap_qbar_foot_'.$login_uin , $qbarfoot_arr['foot']);
			}
		}
	}
	/*------------------��ȡqbarfoot�����ݽ���----------------*/
	
	$login_from = isset($_GET['login_from']) ? SNS_LIB_String::filterContent($_GET['login_from']) : '';

	//��������
	$gdata = array(
		'env' => $server_type,
		'login_uin' => $login_uin, //��¼���û�QQ
		'domain_map' => SNS_CONF_BASE::$domain_map, //��������
		'lang' => $lang, //����
		'version' => $WAP_CSS_VERSION, //CSS version
		'sid' => 'sid=' . $SID_KEY,
		'pure_sid' => $SID_KEY,
		//'phpsid' => SID,
		'qbarfoot' => $qbarfoot_arr,
		'login_from' => $login_from,
		'helpurl' => "http://kf.3g.qq.com/g/s?sid={$SID_KEY}&amp;aid=kftemplate&amp;tid=dindex&amp;pid=115&amp;from=product",
	);

	$blog_url = parse_url(MOBILE_MQZONE_BLOG_URL);
	$gift_url = parse_url(MOBILE_MQZONE_GIFT_URL);
	$photo_url = parse_url(MOBILE_MQZONE_PHOTO_URL);
	$share_url = parse_url(MOBILE_MQZONE_SHARE_URL);
	$twitter_url = parse_url(MOBILE_MQZONE_TWITTER_URL);
	$emotion_url = parse_url(MOBILE_MQZONE_EMOTION_URL);
	$like_url = parse_url(MOBILE_MQZONE_LIKE_URL);
	$message_url = parse_url(MOBILE_MESSAGE_URL);
	$gdata['domain_map']['blog'] = $blog_url['host'];
	$gdata['domain_map']['gift'] = $gift_url['host'];
	$gdata['domain_map']['photo'] = $photo_url['host'];
	$gdata['domain_map']['share'] = $share_url['host'];
	$gdata['domain_map']['twitter'] = $twitter_url['host'];
	$gdata['domain_map']['emotion'] = $emotion_url['host'];
	$gdata['domain_map']['like'] = $like_url['host'];
	$gdata['domain_map']['message'] = $message_url['host'];
	
	if($mod_name == 'mgroup')
	{
		$gdata['phpsid'] = $SID_KEY;
	}
	//��ǽģ��ʹ�õ������������Ժ���������ֵ
	$gdata['domain_map']['mgroup'] = TplHelper::get_wap_mgroup_domain();

    if ($server_type == 'preview' )
    {
        $gdata['domain_map']['imgcache'] = 'ft.qq.com';
        $gdata['domain_map']['wap'] = 'ft.qq.com';
    }
	elseif( $server_type == 'develop')
	{
		$gdata['domain_map']['imgcache'] = 'ft.qq.com';
		$gdata['domain_map']['wap'] = 'jt.qq.com';
	}
	$gdata['domain_map']['touch'] = 'touch.'.$gdata['domain_map']['wap'];

	$data['gdata'] = $gdata;

	//�����ͼ
	if(!file_exists($tpl_cache_path . $lang . '/' . $tpl_name . '.php'))
	{
		$log = Logger::getLogger('wrong_lose_tpl');
		$log->err($login_uin.' | mod = '.$mod_name.' | act ='. $act_name);
		$log->err($tpl_cache_path . $lang . '/' . $tpl_name . '.php');
		$log->err(var_export($_SERVER, true));
	}
	$output_data = include($tpl_cache_path . $lang . '/' . $tpl_name . '.php');
	if ($output_data === false)
	{
		echo "View ({$tpl_name}) not found.";
		Logger::getLogger()->err("View ({$lang}/{$tpl_name}.php) not found");
		exit;
	}

    //���ط�ʽ
	if ($return)
	{
		return $output_data;
	}

	echo $output_data;
}

/**
 * ���������ʻ�ָ��ģ��
 *
 * @param string $tpl_name
 * @param string $tpl_cache_path
 * @param string $lang
 *
 * @return void
 */
function parse_tpl($tpl_name, $tpl_cache_path, $lang)
{
	require_once SNSLIB_PATH . 'LIB/SimpleTemplate.php';
	require_once SNSLIB_PATH . 'LIB/InternationalEngine.php';

	if($lang == 'zh_cn_1')
	{
		$st = new SNS_LIB_SimpleTemplate(ROOT_PATH . 'tpl_1/', $tpl_cache_path . $lang . '/');
	}
	elseif($lang == 'zh_cn')
	{
		$st = new SNS_LIB_SimpleTemplate(ROOT_PATH . 'tpl/', $tpl_cache_path . $lang . '/');
	}
	$st->trimSpace = true; //����ȥ���ַ�����������β�Ŀո񡢿���

	//���ʻ�����
	$inter_engine = new SNS_LIB_InternationalEngine(ROOT_PATH . 'lang/', $tpl_cache_path . 'tmp/', $tpl_cache_path);
	$inter_engine->setCommonLangModule('common');

	//����ģʽ
	//$st->debugMode = true;
	$inter_engine->debugMode = true;

	$tmp_name_info = explode('/', $tpl_name);
	//����ʹ��common/*��Ϊģ������
	if ($tmp_name_info[0] == 'common')
	{
		throw new Exception('commonĿ¼�µ���ģ�岻�ܱ�ֱ��ʹ��');
	}

	try
	{
		//����ģ��
		$tpl = $st->loadTpl($tpl_name);

		//ת������
		$tpl = $inter_engine->bindLanguage($tpl, $lang, $tmp_name_info[0], $tmp_name_info[1]);

		//����ģ��
		$code = $st->tpl2phpCode($tpl);
		$code = $st->completePHPCode($code);

		//����cache
		$st->saveToCacheByName($tpl_name, $code, 'php');
	}
	catch (Exception $e)
	{
		throw new Exception($e->getMessage());
	}
}

// ׼����������
function prepare_nav_data() {
	global $login_uin;
	require_once SNSLIB_PATH . 'Interface/UserCompany.php';
	$user_info = SI_User::getBaseInfo($login_uin);
	$tpl_data = array();

	// ��ȡ�û���Ϣ
	$tpl_data['name'] = isset($user_info['realname']) ? $user_info['realname'] : '';
	$tpl_data['hash'] = encode_qq($login_uin);

	//$bit_pengyou = $user->check_state_extra( USER_STATEEXTRA_PENGYOU );
	$user_info['bits'] = isset($user_info['bits']) ? $user_info['bits'] : '';
	$bit_pengyou = SI_User::getStateByBits( $user_info['bits'], SI_User::STATE_WORK );
//	$default_company_info = SI_UserCompany::getDefault( $login_uin, false );

	$tpl_data['bit_pengyou'] = $bit_pengyou;
	//$tpl_data['bit_company'] = (!$default_company_info || empty($default_company_info['cid'])) ? false : true;
	$tpl_data['sys_time'] = SNS_LIB_String::get_split_time($_SERVER['REQUEST_TIME']);

	return $tpl_data;
}

/*
* ���ز�����ʾҳ�� javierchen
* 20100719�޸ģ�����json�����ж�Ҫ����html��ʾҳ��wapʹ�ã����Ƿ���json�����widgetʹ��
* @param array data ҳ��չʾ��Ҫ������
*   data = array(
*	   'code' => ���ڴ��ݸ�widget��json��ʾ
*	   'type' => ��ʾ��Ϣ�����࣬����ʹ�ò�ͬ��ɫ��ʾ notice-������ʾ warning-��ʾ success-�ɹ�
*      'content' => ��ʾ����
	   'url' => ������һҳ��url
*      )
* @return array out_data
*   out_data = array(
*      'output' => html
	   'use_notice_template' => ��־λ
*      )
*/
function build_wap_notice($data = false)
{
	global $login_uin , $SID_KEY,$func_name;
	$WAP_CSS_VERSION = 41;//��ʶwap�汾�ţ�����css��ʱ���
	$server_type = get_cfg_var('server_type');
	require_once SNSLIB_PATH . 'Interface/UserCompany.php';

	// �ж���xiaoyou����pengyou
	$user_base_info = SI_User::getBaseInfo( $login_uin );
	$user_base_info['bits'] = isset($user_base_info['bits']) ? $user_base_info['bits'] : '';
	$is_pengyou_user = SI_User::getStateByBits( $user_base_info['bits'], SI_User::STATE_WORK );
	$code = !empty($data['code']) ? $data['code'] : SNS_Errors::$code;
	$data['content'] = $data['content'] . '<!--@' . $code . '@-->';
	if(!empty($code))
	{
		$is_att = 'false';
		if(Common::isATT($login_uin) == true )
		{
			$is_att = 'true';
		}
		SNS_Errors::log('all_err',$code . ' '. $func_name.' ' . $is_att .' '. $login_uin);
	}
	//��ʾ���ص����ݣ�add by jolteon 2011-8
	$url_content = isset($data['url_content'])? $data['url_content'] : '������һҳ';

	//�ж�wap1.0��2.0
	$wap_version = get_wap_version();

	// widget
	if(isset($_REQUEST['json']))
	{
		if(!isset($data['code']) || empty($data['code']) )
		{
			$data['code'] = 0;
		}
		return $data;
	}
	// wap
	else
	{
		if ($wap_version == 2){
		/*----------------------------------����Ϊwap2.0����--------------------------------------------*/
		if(isset($data['type']))
		{
			if($data['type'] === 'success'){$color_class = 'tipsbox3';}
			elseif($data['type'] === 'warning'){$color_class = 'tipsbox2';}
			else{$color_class = 'tipsbox1';}
		}
		$color_class = isset($data['type']) ? $color_class : 'tipsbox1';
		if(!isset($data['url']) || empty($data['url']) )
		{
			$data['url'] = '/index.php?mod=home';
		}
		$data['url'] = TplHelper::url($data['url']);
		$html =<<<FORM
		<div class="content">
			<div><p class="{$color_class}">{$data['content']}</p></div>
			<div class="hg">�Զ�<a href="{$data['url']}">$url_content</a></div>
		</div>

FORM;

  		$title = '�ֻ�����';
		$conf_base = SNS_CONF_BASE::$domain_map;
		$fresh_time = empty($data['fresh_time']) ? 3 : $data['fresh_time'];
		$meta = '<link href="http://' . (($server_type == 'preview' ) ? 'ft.qq.com' :$conf_base['imgcache']) . '/qzonestyle/xiaoyou_wap2/css/style2.css?s=' . $WAP_CSS_VERSION . '" rel="stylesheet" type="text/css"/>' . "\n";
		$meta .= '<meta http-equiv="refresh" content="'.$fresh_time.';url=' . $data['url'] . '" />' . "\n";
		$css = '';

		$output = build_wap_header($title , $css , $meta , $is_pengyou_user , '' , $wap_version);

		$output .= $html;

		$output .= build_wap_bottom( $is_pengyou_user , $wap_version);

		$out_data['output'] = $output;
		$out_data['use_notice_template'] = 1;

		return $out_data;
		}
		else{
		/*----------------------------------����Ϊwap1.0����--------------------------------------------*/
		if(!isset($data['url']) || empty($data['url']) )
		{
			$data['url'] = '/index.php?mod=home';
		}
		$url = TplHelper::url($data['url']);
		$html =<<<FORM
			{$data['content']}
			<br/>�Զ�<a href="$url">$url_content</a>


FORM;

  		$title = '�ֻ�����';

		$meta = "\n";
		$css = '';

		$output = build_wap_header($title , $css , $meta , $is_pengyou_user , $url , $wap_version);

		$output .= $html;

		$output .= build_wap_bottom( $is_pengyou_user , $wap_version);

		$out_data['output'] = $output;
		$out_data['use_notice_template'] = 1;
		return $out_data;
		}
	}
}

/**
 * ����ҳ�� HTML body ��ǩ֮ǰ�����Լ�����ͷ������ javierchen
 *
 * @return	string				���ع����� HTML ����
 */
function build_wap_header($title, $css = '', $meta = '' , $bit_pengyou , $url="" , $wap_version)
{
	global $SID_KEY;
if ($wap_version == 2)
/*---------------wap2.0----------------------------------*/
{
	global $charset;
	$server_type = get_cfg_var('server_type');
	$conf_base = SNS_CONF_BASE::$domain_map;

	$domain = MOBILE_URL;
	$data_sid = 'sid=' . $SID_KEY;

	$logo_display = '<h1><img alt="�ֻ�����" src="http://' . (($server_type == 'preview' ) ? 'ft.qq.com' :$conf_base['imgcache']) . '/qzonestyle/xiaoyou_wap2/img/logo_py.png"></h1>';

	$symbl = '?';

	$html = <<<EOF
<{$symbl}xml version="1.0" encoding="utf-8"{$symbl}>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn" lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset={$charset}" />
<meta http-equiv="Cache-Control" content="no-cache"/>
<meta http-equiv="Content-Language" content="zh-cn" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="Copyright" content="Tencent .Inc" />
<meta name="Author" content="Tencent-ISRD" />
<meta content="width=device-width; initial-scale=1.0; maximum-scale=1.0; minimum-scale=1.0; user-scalable=0;" name="viewport" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link rel="bookmark" href="/favicon.ico" type="image/x-icon" />
{$meta}
<title>{$title}</title>
</head>
<body>
<div class="wrap">
<div class="top">
	{$logo_display}
</div>
EOF;
	return $html;
}
/*---------------wap1.0----------------------------------*/
else
{
	global $charset;
	$server_type = get_cfg_var('server_type');
	$domain = MOBILE_URL;
	$data_sid = 'sid=' . $SID_KEY;

	$symbl = '?';

	$html = <<<EOF
<{$symbl}xml version="1.0" encoding="utf-8"{$symbl}>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
EOF;
	//�Ƿ���Ҫ��ʱ���� -- ���ô˺�������notice��ʾ��ģ���confirmȷ����ģ��
	if($url == "")
	{
		$html .= <<<EOF
<card title="{$title}">
<p>
EOF;
	}
	else
	{
		$html .= <<<EOF

<card title="{$title}" id="timer" ontimer="{$url}">
<timer value="30" />
<p>
EOF;
	}

	return $html;
}
}

/**
 * ����ҳ�� ���õײ����� javierchen
 *
 * @return	string				���ع����� HTML ����
 */
function build_wap_bottom( $bit_pengyou , $wap_version )
{
	global  $DB, $start_time, $enable_gzip , $SID_KEY, $plat_type;

	$sys_time = SNS_LIB_String::get_split_time($_SERVER['REQUEST_TIME']);

	$html = '';

	/*-----------------------wap2.0��ʽ----------------------------------*/
	if($wap_version == 2)
	{
	$domain = MOBILE_URL;
	$data_sid = 'sid=' . $SID_KEY;

	$html = <<<EOF
<div class="foot">
	<div class="nav">
		<p>
			<a href="{$domain}index.php?{$data_sid}&mod=home">��ҳ</a>&nbsp;
			<a href="{$domain}index.php?{$data_sid}&mod=friend&act=recommend&subact=noticeban">����</a>&nbsp;
			<a href="{$domain}index.php?{$data_sid}&mod=pygroup&act=mygroups&subact=noticeban" >Ȧ��</a>&nbsp;
			<a href="{$domain}index.php?{$data_sid}&mod=app">Ӧ��</a>&nbsp;
			<a href="{$domain}index.php?{$data_sid}&mod=profile">�ҵ���ҳ</a>&nbsp;
		</p>
	</div>
	<p>
		<a href="{$domain}index.php?{$data_sid}&mod=search&subact=noticeban">����</a>
		-
		<a href="{$domain}index.php?{$data_sid}&mod=help&amp;act=feedback">����</a>
		-
		<a href="http://kf.3g.qq.com/g/s?{$data_sid}&amp;aid=kftemplate&amp;tid=dindex&amp;pid=115&amp;from=product">����</a>
	</p>
	<p>
		<a href="http://info.3g.qq.com/g/s?aid=index&amp;3g_{$data_sid}">�ֻ���Ѷ��</a>
		-
		<a href="http://info.3g.qq.com/g/s?aid=navigation&amp;3g_{$data_sid}">����</a>
		-
		<a href="http://wap.soso.com/navi.jsp?g_f=2119&amp;g_ut=1&amp;{$data_sid}">����</a>
		-
		<a href="{$domain}index.php?{$data_sid}&mod=login&amp;act=out">�˳�</a>
	</p>
	<p>
		�ҵ�<a href="http://house60.3g.qq.com/g/s?aid=home_self&amp;3g_{$data_sid}">��԰</a>
		.
		<a href="{$domain}index.php?{$data_sid}&mod=login&amp;act=toqzone">�ռ�</a>
		.
		<a href="http://ti2.3g.qq.com/g/s?g_f=2507&amp;aid=h&amp;{$data_sid}">΢��</a>
	</p>
	<p class="clr_wk">СQ��ʱ({$sys_time})</p>
</div>
EOF;

	$html .= <<<EOF
</body>
</html>
EOF;
	}
	/*-----------------------wap1.0��ʽ----------------------------------*/
	else 
	{		
		$domain = MOBILE_URL;
		$data_sid = 'sid=' . $SID_KEY;
	
		$html = <<<EOF
<br/><br/>
		<a href="{$domain}index.php?{$data_sid}&amp;mod=home" >��ҳ</a>|<a href="{$domain}index.php?{$data_sid}&amp;mod=friend&amp;act=recommend&amp;subact=noticeban" >����</a>|<a href="{$domain}index.php?{$data_sid}&amp;mod=pygroup&amp;act=mygroups&amp;subact=noticeban" >Ȧ��</a>|<a href="{$domain}index.php?{$data_sid}&amp;mod=app" >Ӧ��</a>|<a href="http://{$domain}/index.php?{$data_sid}&amp;mod=profile">�ҵ���ҳ</a>

	<br/>
		<a href="{$domain}index.php?{$data_sid}&amp;mod=search&amp;subact=noticeban">����</a>-<a href="{$domain}index.php?{$data_sid}&amp;mod=help&amp;act=feedback">����</a>-<a href="http://kf.3g.qq.com/g/s?{$data_sid}&amp;aid=kftemplate&amp;tid=dindex&amp;pid=115&amp;from=product">����</a>

	<br/>
		<a href="http://info.3g.qq.com/g/s?aid=index">�ֻ���Ѷ��</a>-<a href="http://info.3g.qq.com/g/s?aid=navigation">����</a>-<a href="http://wap.soso.com/navi.jsp?g_f=2119&amp;g_ut=1&amp;{$data_sid}">����</a>-<a href="{$domain}index.php?{$data_sid}&amp;mod=login&amp;act=out">�˳�</a>

	<br/>
		�ҵ�<a href="http://house60.3g.qq.com/g/s?aid=home_self&amp;3g_{$data_sid}&amp;g_ut=1&amp;g_f=595">��԰</a>.<a href="{$domain}index.php?{$data_sid}&amp;mod=login&amp;act=toqzone">�ռ�</a>.<a href="http://ti2.3g.qq.com/g/s?g_f=2507&amp;aid=h&amp;{$data_sid}&amp;g_ut=1">΢��</a>

	<br/>СQ��ʱ({$sys_time})
EOF;

	$html .= <<<EOF
</p>
</card>
</wml>
EOF;
	}
	return $html;
}

/**
 * ���ɷ���hash
 *
 * @param unknown_type $qq1
 * @param unknown_type $qq2
 * @param unknown_type $t
 * @return unknown
 */
function generate_visite_hash($qq1 , $qq2 , $t) {
	$key = $qq1 . '_' . $qq2 . '_' . $t . '!@XIAOYOU@!*';
	return base64_encode(md5($key , true));
}

/**
 * ѹ����Ƭurl����ת��
 *
 *	Ŀǰ֧�ּ��ֹ����Ҫʹ��������������ز�Ʒ�Ϳ���ȷ�ϣ� 308*308/208*208/100*100
 *	2011.3���Ӷ�����΢����ͼƬ��֧��
 * @param string	$url	ԭ��Ƭurl��ַ
 * @param int		$width	ָ����Ƭ����
 * @param int		$height ָ����Ƭ�߶�
 * @return string	url/''		����ͼurl��ַ
 * @author	visli
 */
function photoResize($url, $width, $height)
{
    $width = intval($width);
    $height = intval($height);
    if($width<1 || $height<1)
	{
        return '';
    }

    //΢��ͼƬ����
    if(strpos($url, 'qpic.cn') !== false)
	{
		switch ($width)
		{
			case 208:
				return preg_replace('#(.+?)\/([0-9]{3,4})$#',"$1/160",$url);
				break;
			case 308:
				return preg_replace('#(.+?)\/([0-9]{3,4})$#',"$1/2000",$url);
				break;
			default:
				return preg_replace('#(.+?)\/([0-9]{3,4})$#',"$1/160",$url);
				break;
		}
	}

	if(strpos($url, 'photo.store.qq.com') !== false)
	{
		require_once SNSLIB_PATH.'API/Photo.php';
		//�Ȼ�ȡ��Сͼ
		$small_url = SNSLIB_API_Photo::picResizeGetSmall($url);
		switch ($width)
		{
			//��ҪתΪСͼ
			case  208:
				$new_url =  $small_url;
				break;

			//��ҪתΪ��ͼ
			case 308:
				$new_url =  SNSLIB_API_Photo::picResizeSmall2Big($small_url);
				break;

			//Ĭ����Сͼ
			default:
				$new_url =  $small_url;
				break;
		}
		return str_replace('&', '&amp;', $new_url);
	}

    if(strpos($url, 'imgcache.qq.com') !== false)
    {
    	return $url;
	}
	
	return '';
}

/**
 * session��֤
 *
 * @return qq or false
 */
function check_session($mod='')
{
    require_once(ROOT_PATH . '/include/MemcacheSession.php');

    $qq = isset($_SESSION['qq']) ? intval($_SESSION['qq']) : 0;
    $qq = (!empty($_SESSION['sid'])) ? $qq : 0;
    //��֤���õ�¼
    if(empty($qq)) {
        $fkey = isset($_COOKIE['fkey']) ? SNS_LIB_String::filterText($_COOKIE['fkey']) : '';
        if(empty($fkey))
        {
            if($mod=='home') {
                $fkey = isset($_GET['fkey']) ? SNS_LIB_String::filterText($_GET['fkey']) : '';
            }

            if(empty($fkey))
            {
                return 0;
            }
        }

        $arr = get_forever_key_value($fkey);
        if(empty($arr)) {
            return 0;
        }
        else
        {
            $qq = $arr['qq'];
            $sid = $arr['sid'];
            $_SESSION['qq'] = $qq;
            $_SESSION['sid'] = $sid;
            $_SESSION['time']     = time();
            return $qq;
        }

    }

    return (!empty($_SESSION['sid'])) ? $qq : 0;
}

/**
 * ��ȡҳ����Ϣ
 *javierchen
 * @return count
 */
function get_page_index()
{
	if(isset($_GET['page']))
	{
		$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	}
	elseif (isset($_POST['page'])) // �п����Ǵӹ�����ҳҳ�������������
	{
		$page = intval($_POST['page']) > 0 ? intval($_POST['page']) : 1 ;
		if(isset($_POST['total_page']))
		{
			$page = ($page > intval($_POST['total_page'])) ? intval($_POST['total_page']) : $page;
		}

	}
	else
	{
		$page = 1;
	}

	return $page;
}

/**
 * �ֻ� UBB ֧�ִ���
 * @param	string	$content	��Ҫ�����ĺ� UBB ���ַ���
 * @param	string	$type		��Ҫ���������ͣ�Ŀǰ֧�� wap/widget
 */
function mobile_ubb($content, $type = 'wap')
{
	// Ŀǰ֧�ֱ�׼��һ����ͼƬ�Ĵ���ֻ����־�У�����ͳһ��������
	//=== ֧�ֱ���
	//���鵥�����ˣ�wap1.0��֧��<wbr>
	$content = preg_replace('/\[em\]e(\d{1,4})\[\/em\]/','<img src="http://imgcache.qq.com/qzone/em/e$1.gif" />' , $content);

	//=== ��Ƶ����
//	[flash,456,400]http://player.youku.com/player.php/partnerid/XOTcy/sid/XMTkxMjcyNzM2/v.swf[/flash]
	$content = preg_replace("|\[flash[,=]*[0-9]*,*[0-9]*\](.*)\[/flash\]|Ui", '<br />���˴���Ƶ�޷����š�<br />', $content);
	// ���ֵĴ���
	$content = preg_replace("|\[music[,=]*[0-9]*,*[0-9]*\](.*)\[/music\]|Ui", '<br />���˴������޷����š�<br />', $content);

	//=== �����Ĺ���(ͼƬ��Ҫ����֮ǰ����)
	$content = SNS_LIB_String::cleanUBB($content);

	return $content;
}

/**
 * �������õ�¼��key
 * @param	int	$qq	��¼�ߵ�qq����
 * @return	string	���ܴ�
 */
function gen_forever_key($qq, $sid)
{
    $mem = SNS_ResourceManager::getStorage('foreverkey');
    $qq_key = $mem->get('qq_foreverkey_' . $qq);
    //ɾ��qq����֮ǰ������key
    if(empty($qq_key)) {
           $qq_key = substr(md5($qq . time(). $sid), 0, 8);
    }

    //����qq_key

    $login_arr =  $mem->get('foreverkey_' . $qq_key);
    if(!empty($login_arr) )
    {
        if($login_arr['qq'] !== $qq) {
        //�ظ��ˣ���������һ��
        $qq_key = substr(md5($qq . time(). $sid), 0, 8);
        $login_arr =  $mem->get('foreverkey_' . $qq_key);
        //�ٴ��ظ�������false
        if(!empty($login_arr) && $login_arr['qq'] !== $qq) {
                return false;
            }
        }
        else
        {
            return $qq_key;
        }
    }
    $login_arr = array('qq'=>$qq, 'time'=>time(), 'sid'=>$sid);
    $ret = $mem->set('foreverkey_' . $qq_key, $login_arr);
    if($ret === false) {
        return false;
    }
    else
    {
        $mem->set('qq_foreverkey_' . $qq, $qq_key);
        return $qq_key;
    }
}

/**
 * �������õ�¼key��ȡ��¼��Ϣ
 * @param	string	$key	  ���õ�¼key
 * @return	array('qq','time'=>����key����ʱ��,'sid'=>$sid)
 */
function get_forever_key_value($key)
{
    $mem = SNS_ResourceManager::getStorage('foreverkey');
    $login_arr = $mem->get('foreverkey_' . $key);
    return $login_arr;
}

/**
 * ��֤������
 * @return	true or false
 **/
function check_white_list( $wap_version )
{
    global $login_uin;
    if( SI_User::getStateByUin($login_uin, SI_USER::STATE_ALPHA) === 1)
    {
    	return true;
    }
    $white_list = array(
    	//weiqizhu
    	2625056344,2673625591,2437886616,1923085115,1756826612,
    	1906684920,1397270279,2605863698,760784895,1090734109,
    	2202001895,195613714,1425000577,1425000578,1425000579,
    	1425000580,1425000581,1425000582,1425000583,1425000584,1425000585,
	842169415,1979392156,
    	//jeanfeng
    	1048636106,1983894717,1976982232,1937595892,1935893585,1936441602,1983518365,
    	//qichegongchang
    	133215601,8878825,4843191,490617020,
    	//paopaoyu
    	2211495990,1612654236,1692639497,
    	//yangguangxiaozhen
    	125610036,531065697,854640798,1764224861,303009234,1967191182,
    	//qinglvzhuye
    	450125409,1031914459,1943297149,1654840206,1497483848,1478177646,
    	//motianladou - to be del
    	822991873,822991874,1301856504,
    	2202051011,1553453251,1522197514,1554032893,1293570935,1739170754,
        '53082810','371238171','109875101','1294630193','327775604',
		'14050240','7797777','44863014','10833352',
    	//javier
    	'278868858' ,
    	'1042847797' ,'1036159972' ,
        //willko
        '544844771' ,
        '615631840' ,'615631842' ,
        //bonnie
        '41686823' ,1950958881,
        '2258619' ,'11308306' ,'1485152357' ,
        //haoyu
        417898240,857910976,
        //danny
        '5304515' ,1936193167,
        1002000201,1002000202,1002000203,1002000204,1002000205,1002000206,
        '1200000310' ,'1200000311' ,
        //peru
        '272637398' ,'445161845' ,
        //chris
        '654739353' ,
        //vis
        '290905741' ,
        //cheung
        '973927' ,
        //vincenttao
        '5397071',
        //berthong
        '1871932859',
        '2248708362',
        1597618995,
		//jolteoncao
		356508642,
		27056847,
		//jeanfeng
		'1428350654',
		'1428079132',
		'1002000351',
		'1137953025',
		'1428350654',
		/*С������
		'52222000',
 		'287423476',
 		'18088836',
 		*/
		//bennylin
		76354595,1055797855,
		//rabbithe
		78665009,328682440,
		//williexiao
		390902106,
		461544911,
		//leaner
		89504751,
		//hunk
		1519033170,
		1031101264,
		1835813131,
		1731939882,
		//liangjuanli
		365716458,
		2202051888,
		2202060808,
		154266248,
		181158257,
		767342842,
		//marvinxie
		1457824848,
		1225127591,
		1250049530
    );	
    if(in_array($login_uin , $white_list) == true || $login_uin == 0)
    {
        return true;
    }
	
    if(Common::isATT($login_uin) == true )
    {
        return true;
    }

	$original_location = SNS_CONF_BASE::$SERVER_LOCATION;
	SNS_CONF_BASE::$SERVER_LOCATION = 'sh';
	$key = 'wap_ft_domain_white_list';
	$whitelist_data = SI_Wap_Adver_Cache::getcache($key, true);
	if($whitelist_data == false)
	{
		$whitelist_data = SI_Wap_Adver_Cache::getcache($key, true);
	}
	SNS_CONF_BASE::$SERVER_LOCATION = $original_location;
	if(in_array($login_uin , $whitelist_data) == true)
	{
		return true;
	}
		
	$html = $notice = '�Բ�����û��Ȩ�޷��ʸ���վ�������f.qq.com';
	if($wap_version == 1)
	{
		header("Content-type:text/vnd.wap.wml; charset=utf-8");
		$html=<<<EOF
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml><card title="�ֻ�����">{$notice}</card></wml>
EOF;
	}
	echo $html;
	exit;

}

/**
 * ��֤user agent
 * @return	true or false
 */
function check_user_agent($wap_version,$exit=true)
{
	//return true;
    global $login_uin;
    //�Զ������Եĺ���
    if( ($login_uin >= 2925000281 && $login_uin <=2925000300) || ($login_uin >= 2925000581 && $login_uin <=2925000600) ||
    	($login_uin >= 1725002356 && $login_uin <=1725002500) || ($login_uin >= 2202062072 && $login_uin <=2202062073) ||
    	($login_uin >= 1950001230 && $login_uin <=1950001237) || ($login_uin >= 1875001542 && $login_uin <=1875001551) ||
    	($login_uin >= 2202001800 && $login_uin <=2202001819) || ($login_uin >= 1650000560 && $login_uin <=1650000579) ||
    	($login_uin >= 611966406 && $login_uin <=611966505) ||
    	array_search($login_uin, array(2400000037, 2500000057, 2599999937, 2400000039, 2500000059, 2599999939, 2400000091, 2500000111, 2599999991, 2400000092, 2500000112, 2599999992, 464580144,287299198, 278868858, 842169415)) !== false)
    {
        return true;
    }
    $user_agent  = isset($_SERVER['HTTP_USER_AGENT' ]) ? $_SERVER['HTTP_USER_AGENT' ] : '';
    if(empty($user_agent))
    {
        return true;
    }

	require_once SNSLIB_PATH . 'include/logger.class.php';
	$log = Logger::getLogger('useragent');
	$log->err($login_uin . ' - ' . $user_agent);
	if(strstr($user_agent, 'Windows NT') !== false || strstr($user_agent, 'Windows 2000') !== false || strstr($user_agent, 'Windows XP') !== false || strstr($user_agent, 'Windows ME') !== false )
	{
		if(!$exit) return false;
		$html = $notice = '��PC�������������������<a href="http://www.pengyou.com">www.pengyou.com</a>��';
	    if($wap_version == 1)
		{
			header("Content-type:text/vnd.wap.wml; charset=utf-8");
	        $html=<<<EOF
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml><card title="�ֻ�����">{$notice}</card></wml>
EOF;
		}
		echo $html;
	    exit;
	}

	 return true;
}


/**
 * �ж��Ƿ����ֻ�У�ѵ�url
 * @param	string	$url	  url
 * @return	bool	true/false
 * @auther	vis
 */
function is_mobile_url($url)
{
	/*Ϊ�շ���false*/
	if(empty($url))
	{
		return false;
	}
	$url_data = parse_url($url);

	if(isset($url_data['host']))
	{
		return (bool) (
						('http://' . $url_data['host'] . '/' == MOBILE_URL) 
					||	('http://' . $url_data['host'] . '/' == MOBILE_MQZONE_URL)
					||	('http://' . $url_data['host'] . '/' == MOBILE_MQZONE_BLOG_URL)
					||	('http://' . $url_data['host'] . '/' == MOBILE_MQZONE_GIFT_URL)
					||	('http://' . $url_data['host'] . '/' == MOBILE_MQZONE_PHOTO_URL)
					||	('http://' . $url_data['host'] . '/' == MOBILE_MQZONE_SHARE_URL)
					||	('http://' . $url_data['host'] . '/' == MOBILE_MQZONE_TWITTER_URL)
					||	('http://' . $url_data['host'] . '/' == MOBILE_MQZONE_EMOTION_URL)
					||	('http://' . $url_data['host'] . '/' == MOBILE_MQZONE_LIKE_URL)
					||	('http://' . $url_data['host'] . '/' == MOBILE_MESSAGE_URL)
					);
	}

	return true;
}

/**
 * ȷ�ϲ���
 * @param	string	$msg				��ʾ��Ϣ
 * @param	string	$confirm_url	    ȷ�ϲ�����url
 * @param	string	$cancel_url			ȡ��������url
 * @return	bool	true/false
 * @auther	vis
 */
function wap_confirm($msg, $confirm_url, $cancel_url)
{
	
	//return 2;
	
	global $login_uin , $SID_KEY;
	$wap_version = get_wap_version();
	$WAP_CSS_VERSION = 41;//��ʶwap�汾�ţ�����css��ʱ���
	$server_type = get_cfg_var('server_type');
	require_once SNSLIB_PATH . 'Interface/UserCompany.php';
	// �ж���xiaoyou����pengyou
	$user_base_info = SI_User::getBaseInfo( $login_uin );
	$user_base_info['bits'] = isset($user_base_info['bits']) ? $user_base_info['bits'] : '';
	$is_pengyou_user = SI_User::getStateByBits( $user_base_info['bits'], SI_User::STATE_WORK );

	$color_class = 'tipsbox1';

	$url_data = parse_url($confirm_url);

	$query = isset($url_data['query']) ? $url_data['query'] : '';

	$query = str_replace('&amp;', '&', $query);

	$form_data = array();
	parse_str($query ,$form_data);

	if(isset($form_data['PHPSESSID']))
	{
		unset($form_data['PHPSESSID']);
	}
		
	$mod_name = empty($form_data['mod']) ? 'home' : SNS_LIB_String::filterText(trim($form_data['mod']));
	if(isset(Mobile_Web_Init::$mod_ugc_domain[$mod_name]))
	{
		$domain_url = Mobile_Web_Init::$mod_ugc_domain[$mod_name];
	}
	else
	{
		$domain_url = MOBILE_URL;	
	}

	$action_url = $domain_url . 'index.php?' . 'sid=' . $SID_KEY;
	$cancel_url = TplHelper::url($cancel_url);
	if($wap_version == 2) //------------------wap2.0-------------------------
	{

	$html =<<<FORM
	<div class="content">
		<div><p class="{$color_class}">{$msg}</p></div>
		<form action="{$action_url}" method="post">

FORM;
	foreach($form_data as $name=>$value)
	{
	$html .=<<<FORM
		<input type="hidden" value="{$value}" name="{$name}" />
FORM;
	}
	$html .=<<<FORM
		<input type="submit" value="ȷ��" class="bt_submit">&nbsp;<a href="{$cancel_url}">ȡ��</a>
		</form>
	</div>
FORM;

	$title = '�ֻ�����';
	$conf_base = SNS_CONF_BASE::$domain_map;
	$meta = '<link href="http://' . (($server_type == 'preview' ) ? 'ft.qq.com' :$conf_base['imgcache']) . '/qzonestyle/xiaoyou_wap2/css/style2.css?s=' . $WAP_CSS_VERSION . '" rel="stylesheet" type="text/css"/>' . "\n";
	$css = '';

	$output = build_wap_header($title , $css , $meta , $is_pengyou_user , '' , $wap_version);

	$output .= $html;

	$output .= build_wap_bottom( $is_pengyou_user , $wap_version);

	$out_data['output'] = $output;
	$out_data['use_notice_template'] = 1;

	return $out_data;
	}

	else
	{
	/*----------------------------------����Ϊwap1.0����--------------------------------------------*/

	$html =<<<FORM
		{$msg}
		<br/><anchor><go href="{$action_url}" method="post">

FORM;
	foreach($form_data as $name=>$value)
	{
	$html .=<<<FORM
		<postfield value="{$value}" name="{$name}" />
FORM;
	}
	$html .=<<<FORM
		</go>ȷ��</anchor>.<a href="{$cancel_url}">ȡ��</a>
FORM;

	$title = '�ֻ�����';

	$meta = "\n";
	$css = '';

	$output = build_wap_header($title , $css , $meta , $is_pengyou_user , '' , $wap_version);

	$output .= $html;

	$output .= build_wap_bottom( $is_pengyou_user , $wap_version);

	$out_data['output'] = $output;
	$out_data['use_notice_template'] = 1;

	return $out_data;
	}
}

/*
 * wap url ����
 * @param string $url
 * @return  string
 */
function wap_filter_url($url, $replace = '/index.php?mod=home')
{
    $url = SNS_LIB_String::filterUrl($url);
    return is_mobile_url($url) ? $url : $replace;
}

/*
 * session�ж� -- ��ֹgetд������ʽ������©��
 * @return  bool
 * @author javier
 */
function wap_check_get_session()
{
	global $login_uin;
	if (isset($_GET['wsid']) && is_string($_GET['wsid']) && (($_GET['wsid']) == md5('fq'.$login_uin)))
	{
		return true;
	}
	return false;
}

//��tempcache�л�ȡwap�İ汾
function get_wap_version()
{
	global $wap_version;
	global $login_uin;
	global $domain_name;
	$plat_type = mobile_parse_os_from_string();
	
	//����iphone��android���
	$user_agent  = isset($_SERVER['HTTP_USER_AGENT' ]) ? $_SERVER['HTTP_USER_AGENT' ] : '';
	
	//δ��¼
	if($login_uin == 0)
	{
		if(($plat_type === 'iPhone') || ($plat_type === 'Android') || ($plat_type === 'WinMobile'))
		{
			return 2;
		}		
		return 1;
	}
	//�ѵ�¼
	else
	{
		if(($plat_type === 'Android') || ($plat_type === 'WinMobile'))
	    {
	        return 2;
	    }
	    elseif($plat_type === 'iPhone')
	    {
	    	$cache = SNS_ResourceManager::getStorage( 'newtemp' );
	    	$value = $cache->get( 'wap_version_'.$login_uin, 'udp');

			if( 3 == $value )
			{
				//ֹͣ��½�Զ����ݺ�̨�汾��¼��Ϣ�� widget ��ת�߼�
				//�жϵ��û���¼��̨״̬Ϊ v3(touch)��ʱ����ת��v2
				$value = 2;
			}

	    	return (intval($value) == 3) ? 3 : 2;
	    }
	}
	$mod_name = empty($_REQUEST['mod']) ? 'home' : SNS_LIB_String::filterText($_REQUEST['mod']);
	$act_name = empty($_REQUEST['act']) ? 'page' : strtolower(SNS_LIB_String::filterText($_REQUEST['act']));
	if($mod_name == 'photo' && ($act_name == 'uploadwap' || $act_name == 'select'))
	{
		return 2;
	}
	else if($mod_name == 'pygroup' && $act_name == 'uploadwap')
	{
		return 2;
	}
	//��cookie
	if(isset($_COOKIE['wap_ver']) && (intval($_COOKIE['wap_ver']) == 1 || intval($_COOKIE['wap_ver']) == 2 || intval($_COOKIE['wap_ver']) == 3))
	{
		return intval($_COOKIE['wap_ver']);
	}

	if (($wap_version)) return $wap_version;
	$cache = SNS_ResourceManager::getStorage( 'newtemp' );
	if ( !$cache )
	{
		return 1;
	}
	else
	{
		$value = $cache->get( 'wap_version_'.$login_uin, 'udp');
		$domain_url = (substr($domain_name, 7));
		$wap_version = isset($wap_version) ? intval($wap_version) : 1;
		$domain_url = substr($domain_url, 0, strlen($domain_url)-1);
		if(intval($value) == 1) {setcookie('wap_ver' , 1 , $_SERVER['REQUEST_TIME'] +  3600, '/' , $domain_url);return 1;}
		if(intval($value) == 2) {setcookie('wap_ver' , 2 , $_SERVER['REQUEST_TIME'] +  3600, '/' , $domain_url);return 2;}
		if(intval($value) == 3) {
			if( !empty($user_agent) && (strstr($user_agent, 'Mac') !== false || strstr($user_agent, 'iphone') !== false ))
			{
				setcookie('wap_ver' , 3 , $_SERVER['REQUEST_TIME'] +  3600, '/' , $domain_url);return 3;
			}
			else
			{
				return 1;
			}
		}
		setcookie('wap_ver' , 1 , $_SERVER['REQUEST_TIME'] +  3600, '/' , $domain_url);
		return 1;
	}
}

function encodeWML($str)
{
        if(empty($str))
    {
        return "";
    }

	$str = str_replace("&amp;", "&", $str);
         $len = strlen($str);
    $_str = '';
    for($i=0; $i<$len;$i++) {
        $c = $str[$i];
        $has_mark=false;
        switch ($str[$i])
        {
                case "\u00FF":
            case "\u0024":
                break;
            case "&":
                if($str[$i+1]=='a' && $str[$i+2]=='m' && $str[$i+3]=='p' && $str[$i+4]==';')
                {$_str .="&";}
                else
                {$_str .="&amp;";}

                break;
            case "\t":
                $_str .= "  ";
                break;
            case '<':
                $sub_str = substr($str ,$i);
                if(strpos($sub_str , '<p ')==0 || strpos($sub_str , '<a ')==0 || strpos($sub_str , '<postfield ')==0 || strpos($sub_str , '<strong')==0 || strpos($sub_str , '<br')==0 || strpos($sub_str , '</')==0 || strpos($sub_str , '<span')==0 || strpos($sub_str , '<img ')==0 || strpos($sub_str,'<?')==0 || strpos($sub_str , '<!')==0 || strpos($sub_str , '<card')==0 || strpos($sub_str , '<input')==0 || strpos($sub_str , '<anchor')==0 || strpos($sub_str , '<go')==0 )
                {
                        $_str .='<';$has_mark=true;
                }
                else{
                        $has_mark=false;
                $_str .= "&lt;";
                }
                break;
            case '>':
                if($has_mark == true)
                {$_str .='>';$has_mark=false;}
                else{
                $_str .= "&gt;";}
                break;
            case "\"":
                $_str .= "&quot;";
                break;
            case "\n":
                $_str .= "<br/>";
                break;
            default:
                if($c >= "\u0000" && $c <= "\u001F")
                    break;
                if($c >= "\uE000" && $c <= "\uF8FF")
                    break;
                if($c >= "\uFFF0" && $c <= "\uFFFF")
                    break;

                $_str .= $c;
                break;
        }
    }
    return $_str;
}

function get_newyear_topic($time_str)
{
	$topic_arr = array(
		'20110130'=>'���¶�ʮ�߲����',
		'20110131'=>'������û',
		'20110201'=>'С��Ϧ����û',
		'20110202'=>'��Ϧ�г�',
		'20110203'=>'���³�һ�г�',
		'20110204'=>'���³����г�',
		'20110205'=>'���³����г�',
		'20110206'=>'���³����г�',
		'20110207'=>'���³����г�',
		'20110208'=>'���³����г�',
		'20110209'=>'���³����г�',
		'20110210'=>'���³����г�',
		'20110211'=>'���³����г�',
		'20110212'=>'���³�ʮ�г�',
		'20110213'=>'����ʮһ�г�',
		'20110214'=>'����ʮ���г�',
		'20110215'=>'����ʮ���г�',
		'20110216'=>'����ʮ���г�',
		'20110217'=>'����ʮ���г�',
	);
	return isset($topic_arr[$time_str]) ? $topic_arr[$time_str] : '����ʮ���г�';
}

/**
 * mobile�ϱ�pv��tj2�ĺ���
 *
 * @param int $target_qq uin
 * @param string $mod ģ����
 * @param string $act act��
 * @param int $subact subact������tj2��pv����άͳ��
 * @param int $flag flag�ֶΣ�����ʷԭ�򣬽����ڱ�ʶ��¼��Դ��ע����Դ
 * @param bool $is_reg �Ƿ���ע��
 */
function mobile_report_pv( $target_qq , $mod , $act , $subact = '' , $flag = 0 , $is_reg = true )
{
	global $wap_version, $plat_type;
	$NOT_GOTO_PV = 1;
	$GOTO_PV = 0;
	$plat_type = mobile_parse_os_from_string();

	//��ʽ�������ϱ�
	if(get_cfg_var('server_type') == 'formal'  && (Common::isATT($target_qq) == false))
	{
		$func = $mod . '_' . $act;

		$ip = Common::getClientIp();

		//$is_inpv_tag�ֶ����ڱ�ʶ�Ƿ����pvͳ�ƣ�Ŀǰ�趨Ϊ1ʱ��������pvͳ��
		$is_inpv_tag = (in_array($func , Mobile_Web_Init::$mod_act_not_pv_list , true)) ? $NOT_GOTO_PV : $GOTO_PV;

		$flag = intval($flag);
		//����Ǵ�flag������δע�� ,�򲻴�flag�ϱ������ϱ���noregģ�� -  �����˷�
		if($mod == 'login' || $mod == 'home')
		{
			$act_name_tj2 = ($flag != 0 && !$is_reg) ? $act.'noreg' : $act;
			$flag_value = ($flag != 0 && !$is_reg) ? 0 : $flag;
		}
		else
		{
			$act_name_tj2 = $is_reg ? $act : $act.'noreg';
			$flag_value = 0;
		}

		//�κ������ϱ�4���ֶΣ�wap�汾���ֻ�����ϵͳ���ֻ�Ʒ�ƣ��ֻ������
		$agent_str = '';	
		$mobile_type = mobile_parse_model_from_string();
		$browser_type = mobile_parse_browser_type();		
		$agent_str .= $wap_version.','.$plat_type.','.$mobile_type.','.$browser_type;

		//�ϱ�����
		tmsglog_msgprintf('wappv', 2020000067, $_SERVER['REQUEST_TIME'], '%d%s%s%s%s%d%d%s%s', $target_qq, date('Y-m-d H:i:s', $_SERVER['REQUEST_TIME']), $ip, $mod, $act_name_tj2, $is_inpv_tag, $flag_value, $subact, $agent_str);
	}
}

/**
 * mobile�ϱ�Ӧ�õĻ�Ծ
 *
 * @param unknown_type $appid Ӧ��id
 */
function mobile_report_app_login( $appid )
{
	global $login_uin;

	//��ʽ�������ϱ�
	if(get_cfg_var('server_type') === 'formal')
	{
		$refer = 2; //��Դ: 1-PC 2-mobile
		tmsglog_msgprintf('app_login', 2020000087, $_SERVER['REQUEST_TIME'], '%d%s%d%d%d%d%s', $login_uin, date('Y-m-d H:i:s', $_SERVER['REQUEST_TIME']), $appid, $refer, 0, 0, '');

		//����Ӧ���Ǳ߱�һ�»�Ծ�����ܴ�����
		require_once SNSLIB_PATH . 'API/Application.php';
		Application::reportState( $login_uin , $appid , 1 , 9 );//1��ʾ�ϱ���¼��9��ʾ�ֻ�ƽ̨

	}

}

/**
 * ȡ����get����ȥƴ��ǰurl�����ڷ��� - �˵�sid����ȡpost
 *
 * @param unknown_type $include_sid �Ƿ�Ҫȡsid
 */
function generate_url_with_all_get_params($include_sid)
{
	$params = '';
	$is_mgroup_mod = false;
	$domain_url = MOBILE_URL;
	foreach ($_GET as $key => $value)
	{
		if($include_sid)
		{
			$params .= "$key=$value&";
		}
		elseif(!$include_sid && $key != 'sid')
		{
			$params .= "$key=$value&";
		}
		if($key == 'mod')
		{
			if($value == 'mgroup')
			{
				$domain_url = MOBILE_MGROUP_URL;
			}
			else if(isset(Mobile_Web_Init::$mod_ugc_domain[$value]))
			{
				$domain_url = Mobile_Web_Init::$mod_ugc_domain[$value];
			}
		}
	}

	$params = substr($params , 0 , strlen($params)-1);
	$url = $domain_url . 'index.php?' . $params;
	return $url;
}

//����agent�ִ�����ȡҪ�ϱ�������
function mobile_parse_agent_string($agent_str)
{
	if(strstr($agent_str, 'Android') !== false)
	{
		return 'Android';
	}
	elseif(strstr($agent_str, 'iPhone') !== false)
	{
		return 'iPhone';
	}
	elseif(strstr($agent_str, 'Windows Mobile') !== false)
	{
		return 'WinMobile';
	}
	elseif(strstr($agent_str, 'Smartphone') !== false)
	{
		return 'Smartphone';
	}
	elseif(strstr($agent_str, 'Palm') !== false)
	{
		return 'Palm';
	}
	elseif(strstr($agent_str, 'BlackBerry') !== false)
	{
		return 'BlackBerry';
	}
	elseif(strstr($agent_str, 'Linux') !== false)
	{
		return 'Linux';
	}
	elseif(strstr($agent_str, 'Series60/3.0') !== false)
	{
		return 'S60V3';
	}
	elseif(strstr($agent_str, 'Series60/5.0') !== false)
	{
		return 'S60V5';
	}
	elseif(strstr($agent_str, 'MTK') !== false)
	{
		return 'MTK';
	}
	elseif(strstr($agent_str, 'Java') !== false)
	{
		return 'Java';
	}
	elseif(strstr($agent_str, 'Safari') !== false)
	{
		return 'Safari';
	}
	else
	{
		return 'other';
	}
}

//�����ִ�����ȡOS����
function mobile_parse_os_from_string($agent_str = '')
{
	if(empty($agent_str))
	{
		$user_agent  = empty($_SERVER['HTTP_USER_AGENT' ]) ? '' : $_SERVER['HTTP_USER_AGENT' ];
		$q_ua  = empty($_SERVER['HTTP_Q_UA' ]) ?  '' : $_SERVER['HTTP_Q_UA' ];
		$agent_str = $user_agent.' '.$q_ua;
		if(empty($user_agent) && empty($q_ua))
		{
			return 'None';
		}
	}

	if(stripos($agent_str, 'Android') !== false)
	{
		return 'Android';
	}
	if(stripos($agent_str, 'iPhone') !== false)
	{
		return 'iPhone';
	}
	if((stripos($agent_str, 'Symbian') !== false) || (stripos($agent_str, 'Nokia') !== false) || (stripos($agent_str, 'Series60') !== false))
	{
		return 'Symbian';
	}
	if((stripos($agent_str, 'Windows Mobile') !== false) || (stripos($agent_str, 'Windows CE') !== false) || (stripos($agent_str, 'Windows Phone') !== false))
	{
		return 'WinMobile';
	}
	if(stripos($agent_str, 'BREW') !== false)
	{
		return 'BREW';
	}
	if((stripos($agent_str, 'MTK') !== false) || (stripos($agent_str, 'MAUI') !== false))
	{
		return 'MTK';
	}
	if((strstr($agent_str, 'Adr') !== false) || (strstr($agent_str, 'ADR') !== false))
	{
		return 'Android';
	}
	if((strstr($agent_str, 'Mac') !== false) || (strstr($agent_str, 'iOS') !== false))
	{
		return 'iPhone';
	}
	if((stripos($agent_str, 'SYM') !== false))
	{
		return 'Symbian';
	}	
	if(stripos($agent_str, 'Linux') !== false)
	{
		return 'Linux';
	}
	if(stripos($agent_str, 'Java') !== false)
	{
		return 'Java';
	}
	if(strpos($agent_str, 'MIDP') !== false)
	{
		return 'MIDP';
	}

	return 'Other';

}

//�����ִ�����ȡ�ֻ�����
function mobile_parse_model_from_string($agent_str = '')
{	
	if(empty($agent_str))
	{
		$user_agent  = empty($_SERVER['HTTP_USER_AGENT' ]) ? '' : $_SERVER['HTTP_USER_AGENT' ];
		$q_ua  = empty($_SERVER['HTTP_Q_UA' ]) ?  '' : $_SERVER['HTTP_Q_UA' ];
		$agent_str = $user_agent.' '.$q_ua;
		if(empty($user_agent) && empty($q_ua))
		{
			return 'None';
		}
	}
	
	if((stripos($agent_str, 'iPhone') !== false) || (strstr($agent_str, 'Mac') !== false) || (strstr($agent_str, 'iOS') !== false))
	{
		return 'iPhone';
	}
	if(stripos($agent_str, 'HTC') !== false)
	{
		return 'HTC';
	}
	if(stripos($agent_str, 'Smartphone') !== false)
	{
		return 'Smartphone';
	}
	if(stripos($agent_str, 'Nexus') !== false)
	{
		return 'Google';
	}
	if((stripos($agent_str, 'Palm') !== false) || (stripos($agent_str, 'webOS') !== false))
	{
		return 'Palm';
	}
	if(stripos($agent_str, 'BlackBerry') !== false)
	{
		return 'BlackBerry';
	}
	if((stripos($agent_str, 'Series60/3.0') !== false) || (strpos($agent_str, 'SYM3') !== false))
	{
		return 'S60V3';
	}
	if((stripos($agent_str, 'Series60/5.0') !== false) || (strpos($agent_str, 'SYM5') !== false))
	{
		return 'S60V5';
	}
	if((stripos($agent_str, 'Symbian') !== false) || (stripos($agent_str, 'Nokia') !== false)
					||(stripos($agent_str, 'SYM2') !== false))
	{
		return 'OtherSymbian';
	}
	if((stripos($agent_str, 'MTK') !== false) || (stripos($agent_str, 'MAUI') !== false))
	{
		return 'MTK';
	}
	if(stripos($agent_str, 'SAMSUNG') !== false)
	{
		return 'SAMSUNG';
	}
	if(stripos($agent_str, 'SonyEricsson') !== false)
	{
		return 'SonyEricsson';
	}
	if(strpos($agent_str, 'Motorola') !== false)
	{
		return 'Motorola';
	}
	if(stripos($agent_str, 'NEC') !== false)
	{
		return 'NEC';
	}
	if((stripos($agent_str, 'Lenovo') !== false) || (stripos($agent_str, 'HUAWEI') !== false)
			 || (stripos($agent_str, 'ZTE') !== false) || (stripos($agent_str, 'HAIER') !== false)
			 || (stripos($agent_str, 'OPPO') !== false) || (stripos($agent_str, 'BBK') !== false)
			 || (stripos($agent_str, 'CoolPad') !== false) || (strpos($agent_str, 'HW') !== false)
			 || (stripos($agent_str, 'Bestsonny') !== false) || (stripos($agent_str, 'GIONEE') !== false)
			 || (stripos($agent_str, 'TIANYU') !== false) || (strpos($agent_str, 'TCL') !== false)
			 || (strpos($agent_str, 'HS') !== false) || (strpos($agent_str, 'KONKA') !== false)
			 || (stripos($agent_str, 'C8650') !== false) || (strpos($agent_str, 'C8') !== false)
			 || (stripos($agent_str, 'TIANYU') !== false) || (strpos($agent_str, 'TCL') !== false))
	{
		return 'MadeInChina';
	}
	if((strpos($agent_str, 'GT') !== false) || (strpos($agent_str, 'SCH') !== false) || (strpos($agent_str, 'SGH') !== false)
			 || (strpos($agent_str, 'SPH') !== false) || (strpos($agent_str, 'STH') !== false))

	{
		return 'SAMSUNG';
	}
	if((strpos($agent_str, 'MT1') !== false) || (strpos($agent_str, 'ST') !== false) || (strpos($agent_str, 'LT') !== false)
		|| (strpos($agent_str, 'E15') !== false) || (strpos($agent_str, 'E16') !== false))
	{
		return 'SonyEricsson';
	}
	if(strpos($agent_str, 'LG') !== false)
	{
		return 'LG';
	}
	if(strpos($agent_str, 'j2me') !== false)
	{
		return '_j2me';
	}
	if((strpos($agent_str, 'ME') !== false) || (strpos($agent_str, 'MOT') !== false) || (strpos($agent_str, 'XT') !== false))
	{
		return 'Motorola';
	}
	if(stripos($agent_str, 'Gecko') !== false)
	{
		return '_Gecko';
	}

	return 'Other';
}

//�����ִ�����ȡ���������
function mobile_parse_browser_type($agent_str = '')
{
	if(empty($agent_str))
	{
		$user_agent  = empty($_SERVER['HTTP_USER_AGENT' ]) ? '' : $_SERVER['HTTP_USER_AGENT' ];
		$q_ua  = empty($_SERVER['HTTP_Q_UA' ]) ?  '' : $_SERVER['HTTP_Q_UA' ];
		$agent_str = $user_agent.' '.$q_ua;
		if(empty($user_agent) && empty($q_ua))
		{
			return 'None';
		}
	}
	
	if(stripos($agent_str,'QQBrowser'))
	{
		return 'QQBrowser';
	}
	if(stripos($agent_str,'UCWEB') || stripos($agent_str,'UCBrowser'))
	{
		return 'UCBrowser';
	}
	if(isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'],'UC/') !== false)
	{
		return 'UCBrowser';
	}
	if(stripos($agent_str,'MAUI'))
	{
		return 'MTKBrowser';
	}
	if(stripos($agent_str,'Firefox'))
	{
		return 'Firefox';
	}
	if(stripos($agent_str,'Chrome'))
	{
		return 'Chrome';
	}
	if(stripos($agent_str,'Opera'))
	{
		return 'Opera';
	}
	if(stripos($agent_str,'IEMobile'))
	{
		return 'IEMobile';
	}
	if(stripos($agent_str,'Safari') || stripos($agent_str,'AppleWebKit'))
	{
		return 'Safari';
	}
	if(stripos($agent_str,'Series60'))
	{
		return 'S60Browser';
	}
	if(stripos($agent_str,'Browser') ||stripos($agent_str,'TECHSOFT') ||stripos($agent_str,'OBIGO') ||stripos($agent_str,'NetFront')
		||stripos($agent_str,'Dorado') ||stripos($agent_str,'Teleca') ||stripos($agent_str,'POLARIS') ||stripos($agent_str,'SEMC'))
	{
		return 'OtherBrowser';
	}
	if(stripos($agent_str,'MIDP'))
	{
		return '_MIDP';
	}
	if(stripos($agent_str,'Mozilla'))
	{
		return '_Mozilla';
	}
	else
	{
		return 'Other';
	}
}

function py_visitor($uin)
{
	//�ÿ��ϱ�
	$time = intval($_SERVER['REQUEST_TIME']);
	$mod = empty($_GET['mod'])? '': $_GET['mod'];
	$act = empty($_GET['act'])? '': $_GET['act'];
	switch ( $mod )
	{
	case 'classes':
		if ( $act == 'classportal' && !empty($_GET['class_id']) )
		{
			dispatch('visitor', 'visit', array('qq'=>$uin, 'time'=>$time, 'qq2'=>intval($_GET['class_id']), 'type'=>'class'));
		}
		break;
	
	case 'profile':
		if ( $act == '' && !empty($_GET['u']) )
		{
			$uin2 = decode_qq($_GET['u']);
			if ( $uin != $uin2 && $uin2 > 10000 )
			{
				$vfrom = empty($_GET['vfrom'])? 'profile': $_GET['vfrom'];
				dispatch('visitor', 'visit', array('qq'=>$uin, 'time'=>$time, 'qq2'=>$uin2, 'type'=>'person', 'vfrom'=>$vfrom));
			}
		}
		break;

	default:
		//���ϱ�������
	}
}

/* {{{ ��ȡ�Ƽ������Ϣ
 * @author jackbinwu <jackbinwu@tencent.com>
 * @date 2012/06/19
 */
function get_recommend_adver_html(){

    global $login_uin, $SID_KEY, $wap_version;

    //�������ݳ�ʼ��
    $data_html = '';

    //��ȡ�û���������
    $user_info = SI_User::getBaseInfo($login_uin);
    $_livein = isset($user_info['livein']) ? $user_info['livein'] : '';
    $_arr_livein = explode('|', $_livein);

    //���ڵر������Ϻ������ݡ����ڡ������û�����
    if(isset($_arr_livein[1]) && in_array($_arr_livein[1], array(11, 31)))
        return '';
    if(isset($_arr_livein[1]) && isset($_arr_livein[2])){
		$_city_id = intval($_arr_livein[1])*100 + intval($_arr_livein[2]);
		if(in_array($_city_id, array(4401, 4403)))
			return '';
	}
	if(!isset($_arr_livein[0]) || trim($_arr_livein[0]) != '1')
		return '';

    //���ݲ�ͬ��ƽ̨��ʾ��ͬ��HTML����
    if($wap_version !== 1){
        $data_html .= '<div class="hg"><p class="tipsbox1">';
        $data_html .= '<img src="http://qzonestyle.gtimg.cn/qzonestyle/xiaoyou_wap2/img/renmai.png" alt="ͬ����Ե��" /> ';
        $data_html .= '<a href="'.MOBILE_URL.'index.php?mod=search&act=entry&type=fateperson&sid='.$SID_KEY.'">ͬ����Ե��</a>';
        $data_html .= '</p></div>';
    }else{
        $data_html .= '<br/>';
        $data_html .= '<img src="http://qzonestyle.gtimg.cn/qzonestyle/xiaoyou_wap2/img/renmai.png" alt="ͬ����Ե��" /> ';
        $data_html .= '<a href="'.MOBILE_URL.'index.php?mod=search&amp;act=entry&amp;type=fateperson&amp;sid='.$SID_KEY.'">ͬ����Ե��</a>';
    }

    return $data_html;
}
/* }}} */

//����ҳ���ƽ̨����ȡ��Ӧ�Ĺ��
function get_common_adver_html($pagetype,$plat)
{
	global $SID_KEY,$wap_version, $login_uin;
	$plat = strtolower($plat);
	if(!in_array($plat, array('iphone','android','symbian')))
	{
		$plat = 'other';
	}

	$adver_html = '';
	$key = 'wap_adver'.'_'.$pagetype.'_'.$plat;
	$adver_datas = SI_Wap_Adver_Cache::getcache($key);
	if($adver_datas == false)
	{
		$adver_datas = SI_Wap_Adver_Cache::getcache($key);
	}

	if(!empty($adver_datas))
	{
		//�ع�ͳ��			
		$uin = $login_uin ? $login_uin : 20120815;//QQ��
	    $subplatform = array('iphone' => 1, 'android' => 2, 'symbian' => 3, 'pc' => 4, 'other' => 5);
		if (!empty($subplatform[$plat]))
		{
			$subplatform_value = $subplatform[$plat];//��ƽ̨
		}
		else
		{
			$subplatform_value = 5;
		}
		if ($pagetype === 'homeheader')//���� �ֲ� ֻ����ҳ���Ϲ��Ϊ�ֲ�
    	{
  			$showtype = 2;
  		}
   		else
   		{
  			$showtype = 1;
    	}
		$contentid = array(//λ��ID
				'homeheader' => 10031,
				'homefooter' => 10032,
				'profile'    => 10037,
				'recommend'  => 10033,
				'notice'     => 10034,
				'apppage'    => 10035,
				     	   );
    	$contentid_value = $contentid[$pagetype];
		$time_get = time();
		$time_count = date("Y-m-d H:i:s",$time_get);
		tmsglog_msgprintf('action', 2020001182, $time_get, '%d%d%d%d%d%d%d%d%d%d%d%d%d%s%d%s', $uin, 3, $subplatform_value ,$showtype, 1, 1, 1, 1, 1, 1, $contentid_value, 1, 1, $time_count, 0, '');
	
		//���˵������ߵĹ��
		$cur_time = (int)date("Ymd");
		$currenttime =  $_SERVER['REQUEST_TIME'];
		foreach($adver_datas as $adverid=>$data)
		{
           	$length = strlen($data['endtime']);           
			if ($length == 8 || $length == 0)//�ɹ��
			{
				$start_time = empty($data['starttime']) ? 0 :intval($data['starttime']);
				if(!empty($start_time) && ($start_time > $cur_time))
				{
					unset($adver_datas[$adverid]);
					continue;
				}
				$end_time = empty($data['endtime']) ? 0 :intval($data['endtime']);
				if(!empty($end_time) && ($end_time < $cur_time))
				{
					unset($adver_datas[$adverid]);
					continue;
				}
			}
			else//�¹�� 
			{			
				if ($data['endtime'] > $currenttime && $data['starttime'] < $currenttime && $data['status'] == 'on') //����
    			{   				
 					continue;
    			}
    			else 
    			{
    				unset($adver_datas[$adverid]);
    				continue;
    			}
			}
		}
		
		//��ҳ������ֲ�������ȫ��
		if(!empty($adver_datas) && ($pagetype == 'homeheader'))
		{
			$show_adver_key = array_rand($adver_datas);
			$single_array = array();
			$single_array[$show_adver_key] = $adver_datas[$show_adver_key];
			$adver_datas = $single_array;
		}

		foreach($adver_datas as $adverid=>$data)
		{		
			$linkurl ='/index.php?sid='.$SID_KEY.'&amp;mod=login&amp;act=tocommonadver&amp;adverid='.$adverid.'&amp;pagetype='.$pagetype.'&amp;plat='.$plat;
			//����Ƿ��ǵ�����Ӧ��
			if(!empty($data['appid'])){
				$linkurl .='&amp;appid='.$data['appid'];
			}
			$linkurl.='&amp;subact='.$data['subactstring'];		
			if(!empty($data['advercontent']))
			{		
				//wap�汾1.0����2.0
				if($wap_version !== 1)
				{
					$adver_html .= '
						<div class="hg">
						<p class="tipsbox1">
							';
				}
				else
				{
					if($pagetype != 'homeheader')
					{
						$adver_html .= '
							<br/>
							';
					}
				}
				
				//����Ƿ��ͼƬ
				if(!empty($data['imgurl']))
				{
					$adver_html .= '<img src="'.$data['imgurl'].'" alt="ͼƬ" />';
				}
								
				$adver_html .='<a href="'.$linkurl.'">'; 
				
				//�������ͼƬ��������Ϊ��ɫ
				if(empty($data['imgurl']) && ($wap_version !== 1))
				{
					$adver_html .= '
						<font color="red">
						'.$data['advercontent'].'
						</font>';
				}
				else
				{
					$adver_html .= $data['advercontent'];
				}
				$adver_html .= '</a>';	
				
				if($wap_version !== 1)
				{
					$adver_html .= '
						</p>
						</div>';
				}
			}
			elseif(!empty($data['imgurl']))
			{
				if( 0 && $wap_version !== 1)
				{
					$adver_html .= '
						<div class="hg">
							';
				}
				$adver_html .='<a href="'.$linkurl.'"><img src="'.$data['imgurl'].'" width="100%" /></a>'; 
				if(0 && $wap_version !== 1)
				{
					$adver_html .= '</div>';
				}
			}
		}
	}
	
	return $adver_html;
}

//��PWS������վ�̬����,�Է�ֹ�ڴ�й¶
function clear_static_class_array()
{
	//blog 
	if(class_exists('BlogLoader'))
	{
			BlogLoader::$page_list = NULL;
	}

	//feed
	if(class_exists('UserInfoHandler'))
	{
			UserInfoHandler::$user_info_patch = NULL;
	}
	if(class_exists('IFeedsFormater'))
	{
			IFeedsFormater::$record_set = NULL;
	}
}


function mobile_jump2touch($url_hash = '',$need_url = false)
{
	$server_type = get_cfg_var('server_type');
	$sid = !empty($_REQUEST['sid']) ? $_REQUEST['sid'] : '';
	if(!$sid) $sid = !empty($_COOKIE['sid']) ? $_COOKIE['sid'] : '';
	/*
	if(!$sid)
	{
		//echo '�Ҳ�����ת��sid';
		//exit();
	}
	*/
	$touch_url = "http://touch.".($server_type  == 'preview' ? 'ft':'f').".qq.com/index.php?sid=".$sid.'#'.($url_hash ? $url_hash : 'home.feeds');
	$_user_browser = mobile_parse_browser_type();
	//if($_user_browser == 'UCBrowser') $touch_url='ext:webkit:'.$touch_url;
	if($need_url) return $touch_url;
	header("Location: ".$touch_url);
	die();
}

function mobile_location_redirect($url,$flag=0)
{
	global $login_uin , $SID_KEY,$can_use_touch;
	if( strtolower(substr($url,0,10)) == 'location: '){
		$url = substr($url,10);
	}
	$newurl = $url;
	/*
	if( $can_use_touch && !SI_BitMap::read($login_uin,'touch_nouse')){
		$urlinf = parse_url($url);
		if(!empty($urlinf)){
			if($urlinf['host'] == 'pt.3g.qq.com'){
								
			}elseif($urlinf['host'] == 'f.qq.com'){
				
			}
		}
	}
	*/
	header('Location: ' . $newurl );
	exit();
}
