<?php
namespace Com\Mobile;

class Platform
{
	const TYPE_WML   = 'wml';    //�����ֻ����ڰ��������ֻ�
	const TYPE_WAP2  = 'wap2.0'; //Symbian��
	const TYPE_HTML5 = 'xhtml';  //�߶��ֻ���iphone android�ȣ�����Ļ���߷ֱ��ʣ�3G/WiFi��
	const TYPE_PC    = 'web';    //PC Web
	
	static $keywords = array(
		'Android' => array("android",),
		'IPhone' => array("iphone", "ipod", "ipad"),
		'superBrowser' => array('mqqbrowser',	'ucweb'),//Ĭ��ʹ��QQ������Ķ�����HTML5
		'WindowsPhone' => array( "windows phone"), 
		'MeeGo' => array('meego'),
		'PC'  => array('msie', 'chrome', 'firefox'),
		'WAP2' => array('symbian', 'smartphone', 'opera', 'webos', 'blackberry', '320x320', '240x320', '176x220'),
	);

	static $typeConf = array(
			//�Ͷ��ֻ�
			self::TYPE_WAP2 => array('WAP2'),
			//android, iphoneʹ��xhtml
			self::TYPE_HTML5 => array('IPhone', 'Android', 'WindowsPhone', 'MeeGo', 'PC','superBrowser'),
			//���ֻ�
	);
	
	static function isIPhone5()
	{
		//û��UserAgent
		if(!isset($_SERVER['HTTP_USER_AGENT']))
		{
			return false;
		}
		//��֤$userAgent
		$userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);
		
		if(strpos($userAgent, 'iphone')===false or strpos($userAgent, 'mobile/10a'))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	static function getHtmlType()
	{
		//û��UserAgent��Accept�ֶ�
		if(!isset($_SERVER['HTTP_USER_AGENT']) and !isset($_SERVER['HTTP_ACCEPT']))
		{
			return self::TYPE_WML;
		}
		
		//��֤$userAgent
		$userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);
		foreach(self::$typeConf as $type => $v)
		{
			foreach($v as $plat)
			{
				if(self::keyMatch($userAgent, self::$keywords[$plat]))
				{
					return $type;
				}
			}
		}
		
		//����HTTP Accept�ֶ����жϣ������Ϊ*, */*, ���Ҳ�����html
		if(isset($_SERVER['HTTP_ACCEPT']) and $_SERVER['HTTP_ACCEPT'] != "*/*" and $_SERVER['HTTP_ACCEPT']!="*" and strpos($_SERVER['HTTP_ACCEPT'], 'html')===false)
		{
			return self::TYPE_WML;
		}
		else
		{
			return self::TYPE_WAP2;
		}
	}
	/**
	 * �ؼ���ƥ��
	 * @param unknown $key
	 * @param unknown $keywords
	 * @return boolean
	 */
	static function keyMatch($key, $keywords)
	{
		foreach ($keywords as $search)
		{
			if(strpos($key, $search)!==false)
			{
				return true;
			}
		}
		return false;
	}
}
