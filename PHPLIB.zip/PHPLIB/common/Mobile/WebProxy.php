<?php
class mobileWebProxy{
	public static $error_code=0;
	static function http_request($uri,$type,$params=null)
	{
		self::$error_code  = 0;		
		$curlsess = curl_init();
		// connection timeout
		curl_setopt($curlsess, CURLOPT_CONNECTTIMEOUT, 1);
		// excute timeout
		curl_setopt($curlsess, CURLOPT_TIMEOUT, 4);
		curl_setopt($curlsess, CURLOPT_URL, $uri);
		$HTTPHEADERS=array();
		//$HTTPHEADERS[]='Host: f.qq.com';
		$HTTPHEADERS[]='Host: '.$_SERVER["HTTP_HOST"];
		$HTTPHEADERS[]='From_proxy: 1';
		if ($type == 'POST'){
			$HTTPHEADERS[]='Expect:';
		}
		//����cookie��ֵ�����ڴ��ݵ�¼̬
		if (!empty($_SERVER['HTTP_COOKIE']) ){
			curl_setopt($curlsess, CURLOPT_COOKIE, $_SERVER['HTTP_COOKIE']);
		}
		if (!empty($_SERVER['HTTP_USER_AGENT']) ){
			curl_setopt($curlsess, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		}
		if (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) ){
			$HTTPHEADERS[]='Accept-Language: '.$_SERVER["HTTP_ACCEPT_LANGUAGE"];
		}
		
		curl_setopt($curlsess, CURLOPT_HTTPHEADER, $HTTPHEADERS);
		
		curl_setopt($curlsess, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($curlsess, CURLOPT_FOLLOWLOCATION, false);
		curl_setopt($curlsess, CURLOPT_HEADER, true);
		
		if ($params)
		{	
			$qs = array();
			foreach ($params as $key => $val)
			{
				if ( is_array($val) )
				{
					foreach ( $val as $sval )
					{
						$qs[] = urlencode($key).'='.urlencode($sval);
					}
				} else {
					$qs[] = urlencode($key).'='.urlencode($val);
				}
			}
			$params = implode('&', $qs);
		}
		
		if ($type == 'POST'){
			curl_setopt($curlsess, CURLOPT_POST, TRUE);
			if($params) curl_setopt($curlsess, CURLOPT_POSTFIELDS, $params);
		}

		$response = curl_exec($curlsess);
		curl_close($curlsess);
		if(empty($response)){
			self::$error_code = 1;
			return '';
		}
		$pos = strpos($response,"\r\n\r\n");
		if(!$pos){
			self::$error_code = 2;
			return '';			
		}
		$headers = substr($response,0,$pos);		
		$htmls = substr($response,$pos+4);
		if($htmls ===false) $htmls = '';
		
		//send http headers
		$headers = explode("\r\n",$headers);
		$skip_tags = array(
			'Content-Length'=>1,
			'Connection'=>1,
		);
		foreach ($headers as $h){
			if(strncmp($h,'Content-Length:',15)==0
			|| strncmp($h,'Connection:',11)==0
			|| strncmp($h,'Transfer-Encoding:',18)==0
			){
				continue;
			}
			header($h);
		}
		return $htmls;
	}
	
	public static function proxy($target_host)
	{
		$full_uri = 'http://'.$target_host.'/index.php?'.$_SERVER['QUERY_STRING'];
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$data = mobileWebProxy::http_request($full_uri,'POST',$_POST);
		}else{
			$data = mobileWebProxy::http_request($full_uri,'GET',null);
		}
		$finger_data = $target_host.' '.mobileWebProxy::$error_code;
		header('Tghost-finger: '.bin2hex(oi_symmetry_encrypt2($finger_data, '[&6kllY#X@~g.+F9')));
		echo $data;
		exit();
	}
}

//wap�ӿ� ��д����
class wapRWBreak
{
	public static $CGI_CONF = array(

		
		);
	
	static function is_write_cgi($func_name)
	{
		if(substr($func_name,0,7)=='mgroup_') return true;
		return (isset(self::$CGI_CONF[$func_name]) && self::$CGI_CONF[$func_name]==1) ? true : false ;
	}
		
	//�ж��ǲ�����Ҫ����ת��
	function is_need_proxy($func_name)
	{
		if(!empty($_SERVER['HTTP_FROM_PROXY'])) return false;
		if (SNS_CONF_BASE::$SERVER_LOCATION != 'sz'){
			return false;
		}
		return self::is_write_cgi($func_name);
	}
		
	static function request_send_proxy()
	{
		$ip_conf_key = 'PROXY_WAP';
		$servers = SNS_ConfigManager::get('other', $ip_conf_key);
		mobileWebProxy::proxy($servers[array_rand($servers)]);
		exit();
	}
}
