<?php
namespace Com\Base;
use TP;

class Session
{
	// ����ʱ��
	private $lifeTime;
	private $logger;

	private static $errCode = 0;
	private static $errMsg = '';

	private $key_prefix = 'phpsess_';

	function setERR($code, $msg)
	{
		self::$errCode = $code;
		self::$errMsg = $msg;
		TP\Log::info($msg, 'session');
	}

	function open($savePath, $sessName)
	{
		$this->_cmem = \CMemFactory::singleton('cate_hot_top5');
		$this->lifeTime = @\ini_get("session.gc_maxlifetime");
		return true;
	}
	
	function close()
	{
		return true;
	}
	
	function read($sid)
	{
		$session = $this->_cmem->get($this->key_prefix.$sid);
		if($session === false)
		{
			$this->setERR(9003, "ClientSession CMEM::get failed, code: " . $this->_cmem->errCode.'; msg: '.$this->_cmem->errMsg);
			return false;
		}

		if(count($session) <= 0)
		{
			return "";
		}
		else
		{
			$session = \unserialize($session[0]);
			//���л�ʧ��
			if($session===false or !isset($session['expire']) or !isset($session['data']))
			{
				return false;
			}
			//�ѹ���
			if($session['expire'] < time())
			{
				//���
				$this->destroy($sid);
				return "";
			}
			return $session['data'];
		}
	}
	
	function write($sid, $data)
	{
		if(count($data) <= 0)
		{
			return true;
		}
		$session['data'] = $data;
		$session['expire'] = time() + $this->lifeTime;
		if($this->_cmem->set($this->key_prefix.$sid, \serialize($session)) === false)
		{
			$this->setERR(9004, "ClientSession CMEM::set failed, code: " . $this->_cmem->errCode.'; msg: '.$this->_cmem->errMsg);
			return false;
		}
		return true;
	}
	
	function destroy($sid)
	{
		if($this->_cmem->del($this->key_prefix.$sid) === false)
		{
			$this->setERR(9004, "ClientSession CMEM::del failed, code: " . $this->_cmem->errCode.'; msg: '.$this->_cmem->errMsg);
			return false;
		}
		else
		{
			return true;
		}
	}
	
	function gc($sessMaxLifeTime)
	{
		return true;
	}
}