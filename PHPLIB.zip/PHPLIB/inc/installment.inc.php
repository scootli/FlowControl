<?php

define('INSTALLMENT_CELLPHONE_PRICE_MIN', 60000);
define('INSTALLMENT_CELLPHONE_PRICE_MAX', 830000);
define('INSTALLMENT_NOTCELLPHONE_PRICE_MIN', 60000);
define('INSTALLMENT_NOTCELLPHONE_PRICE_MAX', 2800000);

define('INSTALLMENT_LIMIT_PRICE_MIN', 30000);
define('INSTALLMENT_LIMIT_PRICE_MAX', 5000000);

define('INSTALLMENT_PAY_TYPE', 28);
global $_InstallmentBank,$_InstallmentShipType,$_InstallmentStatus;
$_InstallmentBank = array(
	1 => array('bank'=>"��������",
				'paytype' => 28,			    
				'installments' => array(//���з��ʴ�����
						3 => array('minprice'=>30000, 'maxprice'=>5000000, 'rate'=>1.03000, 'backrate'=>0.97, 'banksysno'=>1),
						6 => array('minprice'=>30000, 'maxprice'=>5000000, 'rate'=>1.04200, 'backrate'=>0.96, 'banksysno'=>2),
						12 => array('minprice'=>30000, 'maxprice'=>5000000, 'rate'=>1.06000, 'backrate'=>0.94, 'banksysno'=>3),
										),
			   ),
	2 => array('bank'=>"ƽ������",
				'paytype' => 63,		//��������ʱ��Ҫ�޸�	    
				'installments' => array(
						3 => array('minprice'=>30000, 'maxprice'=>5000000, 'rate'=>1.041667, 'backrate'=>0.96, 'banksysno'=>1),
						6 => array('minprice'=>30000, 'maxprice'=>5000000, 'rate'=>1.052632, 'backrate'=>0.95, 'banksysno'=>2),
						12 => array('minprice'=>30000, 'maxprice'=>5000000, 'rate'=>1.06383, 'backrate'=>0.94, 'banksysno'=>3),
										),
			   ),
);

$_InstallmentShipType = array (
  SITE_SH => array(ICSON_DELIVERY,ICSON_DELIVERY_QF),
  SITE_SZ => array(ICSON_DELIVERY,ICSON_DELIVERY_QF),
  SITE_BJ => array(ICSON_DELIVERY,ICSON_DELIVERY_QF),
  SITE_WH => array(ICSON_DELIVERY,ICSON_DELIVERY_QF),
  SITE_CQ => array(ICSON_DELIVERY,ICSON_DELIVERY_QF)
 );
  
  
  $_InstallmentStatus = array(
  	'init' => 0,
  	'payed' => 1,
  	'partial_refund' => 2,
  	'refund' => 3,
  );
  
