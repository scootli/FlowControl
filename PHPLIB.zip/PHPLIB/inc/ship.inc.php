<?php
//1:���� 2:���� 3:���� 4:��һ������������
global $_ShipTime,$_ShipLimitTime,$_SelfShipTime,$_SelfShipLimitTime,$_ArrivedLimitTime;
$_ShipTime = array();
$_ShipTime[1] = array(array('00:30:00',1),array('11:00:00',2),array('15:00:00',3),array('23:59:59',4));
$_ShipTime[2] = array(array('00:30:00',1),array('11:00:00',2),array('15:00:00',3),array('23:59:59',4));
$_ShipTime[3] = array(array('00:30:00',1),array('11:00:00',2),array('15:00:00',3),array('23:59:59',4));
$_ShipTime[4] = array(array('00:30:00',1),array('11:00:00',2),array('15:00:00',3),array('23:59:59',4));
$_ShipTime[5] = array(array('00:30:00',1),array('11:00:00',2),array('15:00:00',3),array('23:59:59',4));
$_ShipTime[6] = array(array('00:30:00',1),array('11:00:00',2),array('15:00:00',3),array('23:59:59',4));
$_ShipTime[7] = array(array('00:30:00',1),array('11:00:00',2),array('15:00:00',3),array('23:59:59',4));

$_ShipLimitTime = array();
$_ShipLimitTime[1] = array(array('00:30:00',2),array('11:00:00',3),array('15:00:00',3),array('23:59:59',4));
$_ShipLimitTime[2] = array(array('00:30:00',2),array('11:00:00',3),array('15:00:00',3),array('23:59:59',4));
$_ShipLimitTime[3] = array(array('00:30:00',2),array('11:00:00',3),array('15:00:00',3),array('23:59:59',4));
$_ShipLimitTime[4] = array(array('00:30:00',2),array('11:00:00',3),array('15:00:00',3),array('23:59:59',4));
$_ShipLimitTime[5] = array(array('00:30:00',2),array('11:00:00',3),array('15:00:00',3),array('23:59:59',4));
$_ShipLimitTime[6] = array(array('00:30:00',2),array('11:00:00',3),array('15:00:00',3),array('23:59:59',4));
$_ShipLimitTime[7] = array(array('00:30:00',2),array('11:00:00',3),array('15:00:00',3),array('23:59:59',4));

//������ȡ 1:���� 2:���� 4:��һ������������
$_SelfShipTime = array();
$_SelfShipTime[1] = array(array('00:30:00',1),array('11:00:00',2),array('23:59:59',4));
$_SelfShipTime[2] = array(array('00:30:00',1),array('11:00:00',2),array('23:59:59',4));
$_SelfShipTime[3] = array(array('00:30:00',1),array('11:00:00',2),array('23:59:59',4));
$_SelfShipTime[4] = array(array('00:30:00',1),array('11:00:00',2),array('23:59:59',4));
$_SelfShipTime[5] = array(array('00:30:00',1),array('11:00:00',2),array('23:59:59',4));
$_SelfShipTime[6] = array(array('00:30:00',1),array('11:00:00',2),array('23:59:59',4));
$_SelfShipTime[7] = array(array('00:30:00',1),array('11:00:00',2),array('23:59:59',4));

$_SelfShipLimitTime = array();
$_SelfShipLimitTime[1] = array(array('00:30:00',2),array('11:00:00',4),array('23:59:59',4));
$_SelfShipLimitTime[2] = array(array('00:30:00',2),array('11:00:00',4),array('23:59:59',4));
$_SelfShipLimitTime[3] = array(array('00:30:00',2),array('11:00:00',4),array('23:59:59',4));
$_SelfShipLimitTime[4] = array(array('00:30:00',2),array('11:00:00',4),array('23:59:59',4));
$_SelfShipLimitTime[5] = array(array('00:30:00',2),array('11:00:00',4),array('23:59:59',4));
$_SelfShipLimitTime[6] = array(array('00:30:00',2),array('11:00:00',4),array('23:59:59',4));
$_SelfShipLimitTime[7] = array(array('00:30:00',2),array('11:00:00',4),array('23:59:59',4));


//ixiuzeng����
//��ʱ��ĵ���
$_ArrivedLimitTime = array(
	//������
	//'3229' => '�ϳ���',
	//'3230' => '�³���',
	//'3228' => '������',
	//'3227' => '������',
	//'3231' => '������',
	//'3738' => '��ɽ��(���ᡢ���ɡ���ɽ����������ǰ�����ߡ���Χ���½�)',
	//'3232' => '������'
);


//End of script
