<?php
//DIY��������
define('SORT_IN_MEM_TABLE_IPX',"t_diy_product_list_mem");
define('SORT_IN_TABLE_IPX',"t_diy_product_list");
define('NEW_DIY_DB',"icson_diy");
define('DIY_ITEM',1);
define('DIY_RECOMMEND_TITLE',2);
define('DIY_RECOMMEND_LIST',3);
define('DIY_DEPOT_ID_NULL',0);
define('DIY_DEPOT_ID_SH',1);

define('DIY_ITEM_TO_C3',1);
define('DIY_ITEM_TO_C3_ATTR',2);
define('DIY_ENABLE',1);
define('DIY_ENABLE_NO',0);

define('DIY_PRODUCT_ATTR_SEP',"=");
define('DIY_PRODUCT_ATTR_TYPE_SEP',"|@|");

define('DIY_SYN_DATA_LAST_TIME','LASTSYNTIME');
define('DIY_SYN_DATA_START_ROW','STARTRN');
define('PER_PAGE_NUM',500);
define('DIY_SYN_DATA_END_ROW','ENDRN');
