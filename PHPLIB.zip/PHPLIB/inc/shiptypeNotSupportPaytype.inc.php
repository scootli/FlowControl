<?php


$_LGT_PAY = array (
  1 => 
  array (
    1 => 
    array (
      'SysNo' => 1,
      'ShipTypeSysNo' => 3,
      'PayTypeSysNo' => 1,
    ),
    2 => 
    array (
      'SysNo' => 2,
      'ShipTypeSysNo' => 2,
      'PayTypeSysNo' => 1,
    ),
    3 => 
    array (
      'SysNo' => 3,
      'ShipTypeSysNo' => 4,
      'PayTypeSysNo' => 1,
    ),
    6 => 
    array (
      'SysNo' => 6,
      'ShipTypeSysNo' => 1,
      'PayTypeSysNo' => 4,
    ),
    7 => 
    array (
      'SysNo' => 7,
      'ShipTypeSysNo' => 1,
      'PayTypeSysNo' => 5,
    ),
    8 => 
    array (
      'SysNo' => 8,
      'ShipTypeSysNo' => 5,
      'PayTypeSysNo' => 1,
    ),
    14 => 
    array (
      'SysNo' => 14,
      'ShipTypeSysNo' => 3,
      'PayTypeSysNo' => 7,
    ),
    15 => 
    array (
      'SysNo' => 15,
      'ShipTypeSysNo' => 1,
      'PayTypeSysNo' => 7,
    ),
    16 => 
    array (
      'SysNo' => 16,
      'ShipTypeSysNo' => 7,
      'PayTypeSysNo' => 1,
    ),
    17 => 
    array (
      'SysNo' => 17,
      'ShipTypeSysNo' => 9,
      'PayTypeSysNo' => 7,
    ),
    18 => 
    array (
      'SysNo' => 18,
      'ShipTypeSysNo' => 10,
      'PayTypeSysNo' => 7,
    ),
    19 => 
    array (
      'SysNo' => 19,
      'ShipTypeSysNo' => 11,
      'PayTypeSysNo' => 7,
    ),
    20 => 
    array (
      'SysNo' => 20,
      'ShipTypeSysNo' => 12,
      'PayTypeSysNo' => 1,
    ),
    21 => 
    array (
      'SysNo' => 21,
      'ShipTypeSysNo' => 17,
      'PayTypeSysNo' => 7,
    ),
    22 => 
    array (
      'SysNo' => 22,
      'ShipTypeSysNo' => 7,
      'PayTypeSysNo' => 23,
    ),
    23 => 
    array (
      'SysNo' => 23,
      'ShipTypeSysNo' => 12,
      'PayTypeSysNo' => 23,
    ),
    24 => 
    array (
      'SysNo' => 24,
      'ShipTypeSysNo' => 5,
      'PayTypeSysNo' => 23,
    ),
    25 => 
    array (
      'SysNo' => 25,
      'ShipTypeSysNo' => 2,
      'PayTypeSysNo' => 23,
    ),
    26 => 
    array (
      'SysNo' => 26,
      'ShipTypeSysNo' => 3,
      'PayTypeSysNo' => 23,
    ),
    27 => 
    array (
      'SysNo' => 27,
      'ShipTypeSysNo' => 17,
      'PayTypeSysNo' => 23,
    ),
  ),
  1001 => 
  array (
    28 => 
    array (
      'SysNo' => 28,
      'ShipTypeSysNo' => 23,
      'PayTypeSysNo' => 1,
    ),
    38 => 
    array (
      'SysNo' => 38,
      'ShipTypeSysNo' => 32,
      'PayTypeSysNo' => 1,
    ),
  ),
  2001 => 
  array (
    49 => 
    array (
      'SysNo' => 49,
      'ShipTypeSysNo' => 54,
      'PayTypeSysNo' => 1,
    ),
  ),
);?>