<?php $_CATEGORY_CONFIG = array (
  0 => 
  array (
    'text' => '�ֻ�/���',
    'url' => 'http://3c.buy.qq.com/phones_electronics#1',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '����',
        'url' => 'http://searchex.buy.qq.com/html?Path=2083,435&KeyWord=%E4%B8%89%E6%98%9F&Location=310000&sid=855006089&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
      ),
      1 => 
      array (
        'text' => 'MOTO',
        'url' => 'http://searchex.buy.qq.com/html?Path=0,5000603-0,5000654-0,5000656&KeyWord=%E6%91%A9%E6%89%98%E7%BD%97%E6%8B%89&charset=utf-8&Location=310000&sid=855006089&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
      ),
      2 => 
      array (
        'text' => 'HTC',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=HTC',
      ),
      3 => 
      array (
        'text' => 'iPhone',
        'url' => 'http://searchex.buy.qq.com/html?Path=0,5000603-0,5000654-0,5000656&KeyWord=iphone&charset=utf-8&Location=310000&sid=855006089&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '�ֻ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000656',
          ),
          1 => 
          array (
            'text' => 'ƻ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=ƻ��&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => 'HTC',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=HTC&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => 'ŵ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=ŵ����&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=����&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => 'Ħ������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=Ħ������&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=����&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => 'LG',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=LG&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          8 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=����&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          9 => 
          array (
            'text' => '��Ϊ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=��Ϊ&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          10 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=����&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          11 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=����&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          12 => 
          array (
            'text' => '��ݮ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=��ݮ&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          13 => 
          array (
            'text' => 'С��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654&KeyWord=С��&charset=utf-8&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '&nbsp;',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'CDMA',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654-0,5000656&KeyWord=cdma&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => 'GSM',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654-0,5000656&KeyWord=GSM&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '����3G',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654-0,5000656&KeyWord=%E7%94%B5%E4%BF%A13g&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '�ƶ�3G',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654-0,5000656&KeyWord=%E7%A7%BB%E5%8A%A83g&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '��ͨ3G',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654-0,5000656&KeyWord=%E8%81%94%E9%80%9A3g&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '˫���ֻ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000654-0,5000656&KeyWord=%E5%8F%8C%E5%8D%A1&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '�ֻ����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000642-0,5000647&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000642-0,5000648&Location=410000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000646',
          ),
          3 => 
          array (
            'text' => '3G������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002758',
          ),
          4 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000642-0,5000644&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000642-0,5000652&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '�ƶ���Դ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000653',
          ),
          7 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000642-0,5000643&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          8 => 
          array (
            'text' => '�ֻ���/���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000642-0,5000650&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          9 => 
          array (
            'text' => '��д��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000642-0,5000651&Location=210000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          10 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000642-0,5000645&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          11 => 
          array (
            'text' => 'iPhone���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000612',
          ),
          12 => 
          array (
            'text' => 'ƻ��ԭװ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000610-0,5000625&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '�����������Լ۱��ֻ�',
            'url' => 'http://buy.qq.com/pro/3c/c.html?s=37',
          ),
          1 => 
          array (
            'text' => '�ֻ����˻�ʢ��Ļ',
            'url' => 'http://buy.qq.com/pro/3c/c.html?s=38',
          ),
          2 => 
          array (
            'text' => '�����ĺ��ֻ���Ϯ',
            'url' => 'http://buy.qq.com/pro/3c/c.html?s=32',
          ),
          3 => 
          array (
            'text' => '�ֻ����������',
            'url' => 'http://buy.qq.com/pro/3c/b.html?s=16',
          ),
          4 => 
          array (
            'text' => 'LG4��������ս��',
            'url' => 'http://buy.qq.com/pro/3c/c.html?s=39',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  1 => 
  array (
    'text' => 'ƻ��/Ӱ��/����',
    'url' => 'http://3c.buy.qq.com/phones_electronics#2',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '����',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000638',
      ),
      1 => 
      array (
        'text' => 'iPhone���',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000612',
      ),
      2 => 
      array (
        'text' => '�洢��',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000660',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => 'ƻ��ר��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'iPhone',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=02&KeyWord=Iphone',
          ),
          1 => 
          array (
            'text' => 'iPad',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=02&KeyWord=Ipad',
          ),
          2 => 
          array (
            'text' => 'Mac',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=02&KeyWord=Mac',
          ),
          3 => 
          array (
            'text' => 'iPod',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=02&KeyWord=Ipod',
          ),
          4 => 
          array (
            'text' => 'ԭװ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000625',
          ),
          5 => 
          array (
            'text' => 'iPad���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000611',
          ),
          6 => 
          array (
            'text' => 'iPhone���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000612',
          ),
          7 => 
          array (
            'text' => 'iPod���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000613',
          ),
          8 => 
          array (
            'text' => 'ͨ�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002091&as=0',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '��Ӱ����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000641',
          ),
          1 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000637-0,5000638&Location=320000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '����/΢��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000637-0,5002269&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000637-0,5000640&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '��ͷ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000637-0,5000639&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��Ӱ���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000626-0,5000634&Location=530000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000626-0,5000635&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '�˾�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000626-0,5000635&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '���ż�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000626-0,5000631&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000626-0,5000632&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => 'רҵ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000626-0,5000636&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '�ɵ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000663',
          ),
          7 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000653',
          ),
          8 => 
          array (
            'text' => '�ƶ���Դ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000653',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '����Ӱ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'MP3/MP4',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000673',
          ),
          1 => 
          array (
            'text' => 'MP3����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000672',
          ),
          2 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000675',
          ),
          3 => 
          array (
            'text' => '���岥����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000483',
          ),
          4 => 
          array (
            'text' => '����/��¼��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000486',
          ),
          5 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&KeyWord=��������&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000577',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '����洢',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�洢��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000660',
          ),
          1 => 
          array (
            'text' => 'U��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000658',
          ),
          2 => 
          array (
            'text' => '�ƶ�Ӳ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000506',
          ),
          3 => 
          array (
            'text' => '�ƶ�Ӳ�̰�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002268',
          ),
          4 => 
          array (
            'text' => '��¼��Ƭ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000542',
          ),
        ),
      ),
      5 => 
      array (
        'text' => 'ƽ�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002092',
          ),
          1 => 
          array (
            'text' => 'iPad',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=Ipad',
          ),
          2 => 
          array (
            'text' => '�ƶ���Դ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000653',
          ),
          3 => 
          array (
            'text' => 'iPad���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000611',
          ),
        ),
      ),
      6 => 
      array (
        'text' => 'ѧϰ�Ķ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ֽ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000664-0,5000666&Location=350000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '¼����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000664-0,5000668&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '���Ӵʵ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000664-0,5000667&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000665',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '����600D�����ͼ� holdסȫ��',
            'url' => 'http://buy.qq.com/pro/3c/c.html?s=40',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  2 => 
  array (
    'text' => '��������',
    'url' => 'http://3c.buy.qq.com/computers#1',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '�ʼǱ�',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000526',
      ),
      1 => 
      array (
        'text' => '̨ʽ��',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000527',
      ),
      2 => 
      array (
        'text' => 'ƽ�����',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002092',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '�ʼǱ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000526',
          ),
          1 => 
          array (
            'text' => 'ThinkPad',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000525-0,5000526&KeyWord=Thinkpad&charset=utf-8&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '�곞',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000525-0,5000526&KeyWord=���&charset=utf-8&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000525-0,5000526&KeyWord=����&charset=utf-8&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000525-0,5000526&KeyWord=����&charset=utf-8&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '��˶',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000525-0,5000526&KeyWord=��˶&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000525-0,5000526&KeyWord=����&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => 'ƻ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000525&KeyWord=Mac&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          8 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002133',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '̨ʽ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'Ʒ��̨ʽ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000527',
          ),
          1 => 
          array (
            'text' => 'һ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000529',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '������',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002133',
          ),
          1 => 
          array (
            'text' => 'Acer',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000525-0,5002133&KeyWord=acer&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000525-0,5002133&KeyWord=acer&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      3 => 
      array (
        'text' => 'ƽ�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002092',
          ),
          1 => 
          array (
            'text' => 'iPad',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=Ipad',
          ),
          2 => 
          array (
            'text' => '�ƶ���Դ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000653',
          ),
          3 => 
          array (
            'text' => 'iPad���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000611',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '�������ſ���Ϯ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002133',
          ),
          1 => 
          array (
            'text' => 'Macbook  ���� ���� ���ͼ�',
            'url' => 'http://searchex.buy.qq.com/html?Path=0,5000488-0,5000525-0,5000526-2083,46&Location=310000&sid=855006089&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  3 => 
  array (
    'text' => 'Ӳ��/����',
    'url' => 'http://3c.buy.qq.com/computers#3',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '·����',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000571',
      ),
      1 => 
      array (
        'text' => '����',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000577',
      ),
      2 => 
      array (
        'text' => '�ڴ�',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000516',
      ),
      3 => 
      array (
        'text' => '��̬Ӳ��',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=%E5%9B%BA%E6%80%81%E7%A1%AC%E7%9B%98',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => 'װ�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'CPU',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000510',
          ),
          1 => 
          array (
            'text' => 'Ӳ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000522',
          ),
          2 => 
          array (
            'text' => '�ڴ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000516',
          ),
          3 => 
          array (
            'text' => '��ʾ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000521',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000523',
          ),
          5 => 
          array (
            'text' => '�Կ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000520',
          ),
          6 => 
          array (
            'text' => '��¼��/����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000515',
          ),
          7 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000518',
          ),
          8 => 
          array (
            'text' => '��չ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000519',
          ),
          9 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000514',
          ),
          10 => 
          array (
            'text' => '��Դ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000512',
          ),
          11 => 
          array (
            'text' => 'ɢ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000517',
          ),
          12 => 
          array (
            'text' => 'DIYС����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000511',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000500',
          ),
          1 => 
          array (
            'text' => '���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000503',
          ),
          2 => 
          array (
            'text' => '��д��/��ͼ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000515',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000504',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����ͷ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000501',
          ),
          1 => 
          array (
            'text' => 'USB��չ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000589',
          ),
          2 => 
          array (
            'text' => '��Ϸ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000507',
          ),
          3 => 
          array (
            'text' => '���Ӻ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000499',
          ),
          4 => 
          array (
            'text' => '���ú�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000505',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '�����豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '·����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000571',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002267',
          ),
          2 => 
          array (
            'text' => '3G��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002758',
          ),
          3 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000568-0,5002266&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '����洢',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000568-0,5000572&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '���߹���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000568-0,5000569&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000568-0,5000573&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '����ǽ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000568-0,5000570&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '��Ƶ�豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000581',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000577',
          ),
          2 => 
          array (
            'text' => '��˷�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000578',
          ),
          3 => 
          array (
            'text' => '��Ƶ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000574-0,5000580&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000509-0,5000518&KeyWord=����&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '�칫�豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�����ӡ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000347-0,5000382-0,5000385&Location=450000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '��ī��ӡ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000347-0,5000382-0,5000387&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '��ʽ��ӡ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000347-0,5000382-0,5000389&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '��Ƭ��ӡ��',
            'url' => '',
          ),
          4 => 
          array (
            'text' => '��ǩ��ӡ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000347-0,5000382-0,5000383&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '��īһ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000347-0,5000382-0,5000383&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '����һ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000347-0,5000382-0,5000386&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '��ӡ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000347-0,5000382-0,5000384&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          8 => 
          array (
            'text' => 'ɨ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000380',
          ),
          9 => 
          array (
            'text' => '�����',
            'url' => '',
          ),
          10 => 
          array (
            'text' => 'ͶӰ��',
            'url' => '',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '˶�����ؼ�����',
            'url' => 'http://buy.qq.com/pro/3c/c.html?s=10',
          ),
          1 => 
          array (
            'text' => '��ֵ�Լ۱������ɱȫ��',
            'url' => 'http://item.buy.qq.com/item/10000001888A0002520800077173CF50.html?cp-ptss=461-1-152072-t',
          ),
          2 => 
          array (
            'text' => '����256G��̬Ӳ�̾���999',
            'url' => 'http://3c.buy.qq.com/event/1051456a.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  4 => 
  array (
    'text' => '���Ը���',
    'url' => 'http://3c.buy.qq.com/computers#4',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => 'U��',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000658',
      ),
      1 => 
      array (
        'text' => '�ƶ�Ӳ��',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000506',
      ),
      2 => 
      array (
        'text' => '���԰�',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000591',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���԰�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000588-0,5000591&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '��Դ������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000588-0,5000593&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000588-0,5000590&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '��Ĥ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000588-0,5000596&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => 'ԭװ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000588-0,5000597&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '�����Ʒ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000588-0,5000594&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '��ɫ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000588-0,5000595&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => 'USB��չ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000588-0,5000589&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          8 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000588-0,5000592&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          9 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000540&KeyWord=����&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '����洢',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�洢��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000657-0,5000660&Location=350000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => 'U��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000657-0,5000658&Location=120000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '�ƶ�Ӳ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000498-0,5000506&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '�ƶ�Ӳ�̰�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002268',
          ),
          4 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000657-0,5000662&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '��¼��Ƭ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000542&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '��Ƭ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000543&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ϵͳ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000598-0,5000601&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '�칫����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000598-0,5000599&Location=110000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => 'ɱ������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000598-0,5000601&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '�Ĳ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����/�绰��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000539&KeyWord=����&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => 'Ӱ���߲�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000544&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '�����߲�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000541&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '��¼��Ƭ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000542&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '��Ƭ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000543&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000540&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => 'ī��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000347-0,5000390-0,5000392&KeyWord=ī��&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '���ĺ�ī��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=%E7%A1%92%E9%BC%93%E5%92%8C%E5%A2%A8%E7%B2%89',
          ),
          8 => 
          array (
            'text' => 'ɫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000347-0,5000390-0,5000394&KeyWord=ɫ��&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '�ͼ���ս�����ϵ磡',
            'url' => 'http://item.buy.qq.com/item/1000000188BC00026E000007ED0562AB.html',
          ),
          1 => 
          array (
            'text' => '��Ʒԭװ9100����',
            'url' => 'http://item.buy.qq.com/item/1000000187E40003884B000ACFBB91BA.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  5 => 
  array (
    'text' => '��ҵ�',
    'url' => 'http://3c.buy.qq.com/appliances#1',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '����',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000407',
      ),
      1 => 
      array (
        'text' => '�յ�',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000405',
      ),
      2 => 
      array (
        'text' => '����',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000403',
      ),
      3 => 
      array (
        'text' => 'Ӱ���豸',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000482&as=0',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '����',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000407',
          ),
          1 => 
          array (
            'text' => '��ά',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000407&KeyWord=��ά&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000407&KeyWord=����&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '��֥',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000407&KeyWord=��֥&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000407&KeyWord=����&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      1 => 
      array (
        'text' => 'Ӱ���豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ͥӰԺ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482-0,5000484&Location=220000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482-0,5000487&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '����/DVD',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482-0,5000485&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '���岥����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482-0,5000483&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '����/��¼��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482-0,5000486&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '&nbsp;',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482&KeyWord=����&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482&KeyWord=������&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '�ڸ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482&KeyWord=�ڸ���&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482&KeyWord=��������&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000482&KeyWord=������&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '����/��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000403&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000403-2018,1&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '�յ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000405&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000405&KeyWord=����&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000405&KeyWord=����&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000402-0,5000405&KeyWord=����&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '������',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'HDMI��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000544&KeyWord=hdmi��&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => 'Ӱ���߲�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=%E5%BD%B1%E9%9F%B3%E7%BA%BF%E6%9D%90',
          ),
          2 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=%E7%94%B5%E8%A7%86%E9%85%8D%E4%BB%B6',
          ),
          3 => 
          array (
            'text' => '�ɵ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000657-0,5000663&KeyWord=%E5%B9%B2%E7%94%B5%E6%B1%A0&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000603-0,5000657-0,5000659&KeyWord=�����&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000488-0,5000538-0,5000540&KeyWord=����&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ҵ�ȫ����������',
            'url' => 'http://3c.buy.qq.com/event/103927ed.html',
          ),
          1 => 
          array (
            'text' => '�յ���ˬ��͸����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000405',
          ),
          2 => 
          array (
            'text' => '���������壡�����Ӿ�ʢ��',
            'url' => 'http://item.buy.qq.com/item/10000001885A00033C500009B58DF924.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  6 => 
  array (
    'text' => '�������',
    'url' => 'http://3c.buy.qq.com/appliances#2',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '��������',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000428',
      ),
      1 => 
      array (
        'text' => '������',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000437',
      ),
      2 => 
      array (
        'text' => '�����',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000423',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�յ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000427',
          ),
          1 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000421-0,5000423&Location=330000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '����/����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000421-0,5000423-1482,1&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000421-0,5000423-1482,4&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '�յ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000405',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '�Ҿӵ���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000437',
          ),
          1 => 
          array (
            'text' => '���ٶ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000433-0,5000434&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '���̻�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000433-0,5000435&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '������ϴ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000433-0,5000438&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => 'ë���޼���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000433-0,5000436&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '�ֵ�ͲӦ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000431',
          ),
          6 => 
          array (
            'text' => '̨��/�Ķ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000421-0,5000432&Location=370000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '�绰��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000424',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��װ����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��Ͱ������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000442',
          ),
          1 => 
          array (
            'text' => 'ԡ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000439-0,5000444&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '��ˮ�豸',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000439-0,5000441&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000439-0,5000443&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '�綯����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000439-0,5000440&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000421-0,5000428&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '��ʪ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000421-0,5000422&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '��ʪ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000421-0,5000426&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '�����豸',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000421-0,5000429&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '���˻���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���뵶',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000419',
          ),
          1 => 
          array (
            'text' => '��ë��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000414',
          ),
          2 => 
          array (
            'text' => '�綯��ˢ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000416',
          ),
          3 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=%E5%86%B2%E7%89%99%E5%88%B7',
          ),
          4 => 
          array (
            'text' => '�紵��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000415',
          ),
          5 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000418',
          ),
          6 => 
          array (
            'text' => '��/��ë��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000420',
          ),
          7 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000417',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��Ħ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000446',
          ),
          1 => 
          array (
            'text' => '��ԡ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000453',
          ),
          2 => 
          array (
            'text' => 'Ѫѹ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000451',
          ),
          3 => 
          array (
            'text' => 'Ѫ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000450',
          ),
          4 => 
          array (
            'text' => '���¼�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000448',
          ),
          5 => 
          array (
            'text' => 'ҽ����е',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000452',
          ),
          6 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=%E5%81%A5%E5%BA%B7%E7%A7%A4',
          ),
          7 => 
          array (
            'text' => '������������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000447',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '����ȼ�ĩ���',
            'url' => 'http://3c.buy.qq.com/event/10505055.html',
          ),
          1 => 
          array (
            'text' => 'ե֭��ϯ��ȫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000480',
          ),
          2 => 
          array (
            'text' => '��Ʒ�������ټӰѾ���',
            'url' => 'http://item.buy.qq.com/item/100000018846000184230004B117B621.html',
          ),
          3 => 
          array (
            'text' => '��ע���� Ѫѹ������',
            'url' => 'http://buy.qq.com/pro/3c/c.html?s=25&type=1',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  7 => 
  array (
    'text' => '��������',
    'url' => 'http://3c.buy.qq.com/appliances#4',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '������',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000464-0,5000470&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
      ),
      1 => 
      array (
        'text' => '�緹��',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000457&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
      ),
      2 => 
      array (
        'text' => '΢��¯',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000462&Location=310000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��⿵���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�緹��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000457&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '��ѹ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000460&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '�Ⲩ/΢��¯',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000462&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '���¯',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000455&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '�翾��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000459&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000461&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000458&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000456&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          8 => 
          array (
            'text' => '��ɰ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000454-0,5000463&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          9 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000467',
          ),
          10 => 
          array (
            'text' => '�忾¯',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000473',
          ),
          11 => 
          array (
            'text' => '��ʿ¯',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000471',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '��ʳ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000470',
          ),
          1 => 
          array (
            'text' => '��ˮ��/ƿ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000469',
          ),
          2 => 
          array (
            'text' => '���Ȼ�/��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000475',
          ),
          3 => 
          array (
            'text' => 'ե֭��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000480',
          ),
          4 => 
          array (
            'text' => '����/�ٱ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000476',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000481',
          ),
          6 => 
          array (
            'text' => '���̻�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000478',
          ),
          7 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000465',
          ),
          8 => 
          array (
            'text' => '����ӹ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000477',
          ),
          9 => 
          array (
            'text' => '���߾�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000472',
          ),
          10 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000466',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��ˮ�豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ˮ�豸',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&as=0&KeyWord=%E5%87%80%E6%B0%B4%E8%AE%BE%E5%A4%87',
          ),
          1 => 
          array (
            'text' => '��ˮ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000464-0,5000479&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '��ˮͰ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000464-0,5000474&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=0,5000401-0,5000464&KeyWord=%E5%87%80%E9%A5%AE%E6%9C%BA&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&as=0&OrderStyle=1',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '����ϵ���������',
            'url' => 'http://buy.qq.com/pro/3c/c.html?s=26&type=1',
          ),
          1 => 
          array (
            'text' => '�����ͼ�����',
            'url' => 'http://item.buy.qq.com/item/100000018809000258470007842502BD.html',
          ),
          2 => 
          array (
            'text' => '�������� ��ֵ��ӵ��',
            'url' => 'http://item.buy.qq.com/item/1000000187F600031BE800097EF60AEA.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  8 => 
  array (
    'text' => '�칫���Ĳġ��ľ�',
    'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000347',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '��ӡ��',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000382&as=0',
      ),
      1 => 
      array (
        'text' => 'ͶӰ��',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000399',
      ),
      2 => 
      array (
        'text' => '��ӡֽ',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000391',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��ӡ�豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����һ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000386',
          ),
          1 => 
          array (
            'text' => '��īһ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000388',
          ),
          2 => 
          array (
            'text' => '�����ӡ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000385',
          ),
          3 => 
          array (
            'text' => '��ī��ӡ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000387',
          ),
          4 => 
          array (
            'text' => '��ʽ��ӡ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000389',
          ),
          5 => 
          array (
            'text' => '��ǩ��ӡ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000383',
          ),
          6 => 
          array (
            'text' => '��ӡ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000384',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '����ɨ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ɨ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000380',
          ),
          1 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000379',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '�����豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ͶӰ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000399',
          ),
          1 => 
          array (
            'text' => '���Ӱװ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000398',
          ),
          2 => 
          array (
            'text' => 'ͶӰ������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000400',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '�Ĳ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ӡֽ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000391',
          ),
          1 => 
          array (
            'text' => '��Ƭֽ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000396',
          ),
          2 => 
          array (
            'text' => '���ĺ�ī��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000395',
          ),
          3 => 
          array (
            'text' => 'ī��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000392',
          ),
          4 => 
          array (
            'text' => 'ɫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000394',
          ),
          5 => 
          array (
            'text' => '��������ֽ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000393',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '���������豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ֽ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000370',
          ),
          1 => 
          array (
            'text' => '���ڻ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000368',
          ),
          2 => 
          array (
            'text' => 'UPS����ϵ�Դ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000366',
          ),
          3 => 
          array (
            'text' => '�㳮��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000367',
          ),
          4 => 
          array (
            'text' => 'װ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000371',
          ),
          5 => 
          array (
            'text' => '�ܷ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000369',
          ),
          6 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000375',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '�칫�ľ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�ļ�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000362',
          ),
          1 => 
          array (
            'text' => '�ڷ�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000349',
          ),
          2 => 
          array (
            'text' => '�����ľ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000353',
          ),
          3 => 
          array (
            'text' => 'ѧ���ľ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000364',
          ),
          4 => 
          array (
            'text' => '�ߵ��ʾ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000356',
          ),
          5 => 
          array (
            'text' => '��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000350',
          ),
          6 => 
          array (
            'text' => '�����ܱ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000351',
          ),
          7 => 
          array (
            'text' => 'īˮ�ͱ�о',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000360',
          ),
          8 => 
          array (
            'text' => '���±�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000358',
          ),
          9 => 
          array (
            'text' => '��ǩֽ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000352',
          ),
          10 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000357',
          ),
          11 => 
          array (
            'text' => '���ͳ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000354',
          ),
          12 => 
          array (
            'text' => '������ʹ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000355',
          ),
          13 => 
          array (
            'text' => '�����ͽ�ˮ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000359',
          ),
          14 => 
          array (
            'text' => 'Ϳ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000361',
          ),
          15 => 
          array (
            'text' => '�ŷ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000363',
          ),
        ),
      ),
      6 => 
      array (
        'text' => '����������Ʒ',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ƾ֤�͵���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000374',
          ),
          1 => 
          array (
            'text' => 'ӡ�º͸�дֽ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000376',
          ),
          2 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000373',
          ),
          3 => 
          array (
            'text' => 'װ����Ʒ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000377',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '�����ӡ�豸ר��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5000385',
          ),
          1 => 
          array (
            'text' => 'Double A��ӡֻֽҪ89',
            'url' => 'http://item.buy.qq.com/item/100000018822000041B100000001A5C2.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  9 => 
  array (
    'text' => '������������װ��',
    'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002759&as=0',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '����',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002761',
      ),
      1 => 
      array (
        'text' => '����װ��',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002787&as=0',
      ),
      2 => 
      array (
        'text' => '�������',
        'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002779&as=0',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002761',
          ),
          1 => 
          array (
            'text' => 'ɲ��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002762',
          ),
          2 => 
          array (
            'text' => '����װ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002763',
          ),
          3 => 
          array (
            'text' => '�յ���ϴ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002764',
          ),
          4 => 
          array (
            'text' => '������ȴҺ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002765',
          ),
          5 => 
          array (
            'text' => '�������Ӽ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002766',
          ),
          6 => 
          array (
            'text' => 'ϵͳ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002767',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '���ά��',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002769',
          ),
          1 => 
          array (
            'text' => '����������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002770',
          ),
          2 => 
          array (
            'text' => '����������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002772',
          ),
          3 => 
          array (
            'text' => '�յ�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002771',
          ),
          4 => 
          array (
            'text' => '��ˢ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002773',
          ),
          5 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002774',
          ),
          6 => 
          array (
            'text' => 'ɲ��Ƭ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002775',
          ),
          7 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002776',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '�������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���ݳ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002780',
          ),
          1 => 
          array (
            'text' => '���Զ�Ĥ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002781',
          ),
          2 => 
          array (
            'text' => '�����޸�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002782',
          ),
          3 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002783',
          ),
          4 => 
          array (
            'text' => '�������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002784',
          ),
          5 => 
          array (
            'text' => '��๤��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002785',
          ),
          6 => 
          array (
            'text' => '��ˮ��ζ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002786',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '����װ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002790',
          ),
          1 => 
          array (
            'text' => '�ŵ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002790',
          ),
          2 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002792',
          ),
          3 => 
          array (
            'text' => 'ͷ������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002793',
          ),
          4 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002794',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '������Ʒ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������ֽ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002796',
          ),
          1 => 
          array (
            'text' => '����/����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002797',
          ),
          2 => 
          array (
            'text' => 'ֽ����/CD��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002798',
          ),
          3 => 
          array (
            'text' => '��ȫ��װ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002799',
          ),
          4 => 
          array (
            'text' => '�ŵ���ɲ��װ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002800',
          ),
          5 => 
          array (
            'text' => '�ֻ�/���ϼ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002801',
          ),
          6 => 
          array (
            'text' => '������/ָ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002802',
          ),
          7 => 
          array (
            'text' => '�̻Ҹ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002803',
          ),
          8 => 
          array (
            'text' => '����Ͱ/�����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002804',
          ),
          9 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002805',
          ),
          10 => 
          array (
            'text' => '����������Ʒ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002806',
          ),
        ),
      ),
      5 => 
      array (
        'text' => 'װ���װ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������Ĥ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002808',
          ),
          1 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002809',
          ),
          2 => 
          array (
            'text' => '������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002810',
          ),
          3 => 
          array (
            'text' => '����Ұ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002813',
          ),
          4 => 
          array (
            'text' => '����ϵͳ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002817',
          ),
          5 => 
          array (
            'text' => '���ξ�Ʒ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002818',
          ),
        ),
      ),
      6 => 
      array (
        'text' => '���ӵ���',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'GPS����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002820',
          ),
          1 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002821',
          ),
          2 => 
          array (
            'text' => 'MP3 MP4',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002822',
          ),
          3 => 
          array (
            'text' => '��������',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002823',
          ),
          4 => 
          array (
            'text' => '���ص�Դ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002824',
          ),
          5 => 
          array (
            'text' => '���ص���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002826',
          ),
        ),
      ),
      7 => 
      array (
        'text' => '��ȫ�Լ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ͯ����',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002828',
          ),
          1 => 
          array (
            'text' => '̥ѹ���',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002829',
          ),
          2 => 
          array (
            'text' => '��ȫӦ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002830',
          ),
          3 => 
          array (
            'text' => '�Լ���Ʒ',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002831',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '������� Ϊ��������ʣ�',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002784',
          ),
          1 => 
          array (
            'text' => 'Ʒ�Ƶ�����499Ԫ��',
            'url' => 'http://searchex.buy.qq.com/html?sid=855006089&Path=5002820',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
);