<?php

global $_TMEM_DB_CONFIG;;

$_TMEM_DB_CONFIG = array();

// ����ݱ�
$_TMEM_DB_CONFIG['act_data'] = array(
	'dbName' => 'act_data',
	'tableName' => 't_act_data',
	'tmemConfigKey' => 'event_data',
	'tmemBizId' => TMEM_BID_ACT_DATA,
	'dbCount' => 100,
	'tableCount' => 100,
	'columns' => array(
		'id' => array( 'type' => 'number', 'auto' => true ),
		'component_type' => array( 'type' => 'number' ),
		'component_id' => array( 'type' => 'number' ),
		'uid' => array( 'type' => 'number' ),
		'type' => array( 'type' => 'number' ),
		'value' => array( 'type' => 'string' ),
		'create_time' => array( 'type' => 'string' ),
		'update_time' => array( 'type' => 'string', 'readonly' => true )
	),
	'keyColumn' => 'uid'
);

// ����ݷ����
$_TMEM_DB_CONFIG['act_data_map'] = array(
	'dbName' => 'act_data_map',
	'tableName' => 't_act_data_map',
	'tmemConfigKey' => 'event_data',
	'tmemBizId' => TMEM_BID_ACT_DATA_MAP,
	'dbCount' => 100,
	'tableCount' => 100,
	'columns' => array(
		'component_type' => array( 'type' => 'number' ),
		'component_id' => array( 'type' => 'number' ),
		'uid' => array( 'type' => 'number' ),
		'type' => array( 'type' => 'number' ),
		'value' => array( 'type' => 'string' ),
		'create_time' => array( 'type' => 'string' ),
		'update_time' => array( 'type' => 'string', 'readonly' => true )
	),
	'keyColumn' => 'value',
	'hashType' => TMemHelper::HASH_TYPE_STRING
);