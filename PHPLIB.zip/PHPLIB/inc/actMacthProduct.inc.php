<?php



$_category = array (
  545 => '1',
  590 => '2',
  591 => '2',
  308 => '3',
  508 => '3',
  309 => '3',
  312 => '3',
  179 => '4',
  1080 => '1',
  1267 => '1',
  558 => '1',
  274 => '1',
  245 => '1',
  288 => '1',
  398 => '1',
  615 => '1',
);


$_brand = array (
  2 => 
  array (
    0 => 
    array (
      'name' => '����',
      'id' => 1,
    ),
    1 => 
    array (
      'name' => '����',
      'id' => 2,
    ),
    2 => 
    array (
      'name' => '������',
      'id' => 4,
    ),
    3 => 
    array (
      'name' => '����',
      'id' => 5,
    ),
    4 => 
    array (
      'name' => '�ֵ�',
      'id' => 9,
    ),
    5 => 
    array (
      'name' => '����',
      'id' => 10,
    ),
  ),
  1 => 
  array (
    0 => 
    array (
      'name' => 'thinkpad ����',
      'id' => 3,
    ),
    1 => 
    array (
      'name' => 'HP',
      'id' => 33,
    ),
    2 => 
    array (
      'name' => 'DELL',
      'id' => 34,
    ),
    3 => 
    array (
      'name' => 'ACER',
      'id' => 35,
    ),
    4 => 
    array (
      'name' => 'Toshiba',
      'id' => 36,
    ),
    5 => 
    array (
      'name' => 'SONY',
      'id' => 37,
    ),
    6 => 
    array (
      'name' => 'ASUS',
      'id' => 39,
    ),
    7 => 
    array (
      'name' => 'Samsung',
      'id' => 40,
    ),
    8 => 
    array (
      'name' => '����Lenovo',
      'id' => 41,
    ),
  ),
  3 => 
  array (
    0 => 
    array (
      'name' => 'Nokia ŵ����',
      'id' => 11,
    ),
    1 => 
    array (
      'name' => 'Motorola Ħ������',
      'id' => 12,
    ),
    2 => 
    array (
      'name' => 'Samsung ����',
      'id' => 13,
    ),
    3 => 
    array (
      'name' => 'Sony Ericsson ����',
      'id' => 14,
    ),
    4 => 
    array (
      'name' => 'Dopod ���մ�',
      'id' => 15,
    ),
    5 => 
    array (
      'name' => 'Sharp ����',
      'id' => 16,
    ),
    6 => 
    array (
      'name' => 'lenovo����',
      'id' => 17,
    ),
    7 => 
    array (
      'name' => 'Meizu ����',
      'id' => 18,
    ),
    8 => 
    array (
      'name' => 'LG',
      'id' => 19,
    ),
    9 => 
    array (
      'name' => 'Coolpad ����',
      'id' => 20,
    ),
    10 => 
    array (
      'name' => 'Philips ������',
      'id' => 21,
    ),
    11 => 
    array (
      'name' => 'HTC',
      'id' => 42,
    ),
    12 => 
    array (
      'name' => '��Ϊ',
      'id' => 43,
    ),
    13 => 
    array (
      'name' => '��Ψ',
      'id' => 53,
    ),
    14 => 
    array (
      'name' => '������',
      'id' => 54,
    ),
    15 => 
    array (
      'name' => '����',
      'id' => 55,
    ),
    16 => 
    array (
      'name' => '����',
      'id' => 56,
    ),
  ),
  4 => 
  array (
    0 => 
    array (
      'name' => 'Canon ����',
      'id' => 22,
    ),
    1 => 
    array (
      'name' => 'Sony ����',
      'id' => 23,
    ),
    2 => 
    array (
      'name' => 'Casio ����ŷ',
      'id' => 24,
    ),
    3 => 
    array (
      'name' => 'Kodak �´�',
      'id' => 25,
    ),
    4 => 
    array (
      'name' => 'Olympus���ְ�˹',
      'id' => 26,
    ),
    5 => 
    array (
      'name' => 'Nikon �῵',
      'id' => 27,
    ),
    6 => 
    array (
      'name' => 'Panasonic ����',
      'id' => 28,
    ),
    7 => 
    array (
      'name' => 'Fujifilm��ʿ',
      'id' => 29,
    ),
    8 => 
    array (
      'name' => 'Samsung����',
      'id' => 30,
    ),
    9 => 
    array (
      'name' => 'Pentax ����',
      'id' => 31,
    ),
    10 => 
    array (
      'name' => 'JVC',
      'id' => 32,
    ),
  ),
);


$_catena = array (
  39 => 
  array (
    0 => 
    array (
      'name' => '1001ϵ��',
      'id' => 98,
    ),
    1 => 
    array (
      'name' => '1005ϵ��',
      'id' => 97,
    ),
    2 => 
    array (
      'name' => '1201ϵ��',
      'id' => 99,
    ),
    3 => 
    array (
      'name' => 'A42ϵ��',
      'id' => 89,
    ),
    4 => 
    array (
      'name' => 'F6ϵ��',
      'id' => 95,
    ),
    5 => 
    array (
      'name' => 'K40ϵ��',
      'id' => 86,
    ),
    6 => 
    array (
      'name' => 'K41ϵ��',
      'id' => 87,
    ),
    7 => 
    array (
      'name' => 'K42ϵ��',
      'id' => 88,
    ),
    8 => 
    array (
      'name' => 'k50ϵ��',
      'id' => 92,
    ),
    9 => 
    array (
      'name' => 'k52ϵ��',
      'id' => 91,
    ),
    10 => 
    array (
      'name' => 'N81ϵ��',
      'id' => 90,
    ),
    11 => 
    array (
      'name' => 'U80ϵ��',
      'id' => 280,
    ),
    12 => 
    array (
      'name' => 'U81ϵ��',
      'id' => 281,
    ),
    13 => 
    array (
      'name' => 'UL20ϵ��',
      'id' => 100,
    ),
    14 => 
    array (
      'name' => 'UL30ϵ��',
      'id' => 93,
    ),
    15 => 
    array (
      'name' => 'UL80ϵ��',
      'id' => 94,
    ),
    16 => 
    array (
      'name' => 'X8ϵ��',
      'id' => 96,
    ),
  ),
  34 => 
  array (
    0 => 
    array (
      'name' => '1012ϵ��',
      'id' => 110,
    ),
    1 => 
    array (
      'name' => '1088ϵ��',
      'id' => 107,
    ),
    2 => 
    array (
      'name' => '131Lϵ��',
      'id' => 228,
    ),
    3 => 
    array (
      'name' => '1320ϵ��',
      'id' => 106,
    ),
    4 => 
    array (
      'name' => '13Zϵ��',
      'id' => 111,
    ),
    5 => 
    array (
      'name' => '1440ϵ��',
      'id' => 112,
    ),
    6 => 
    array (
      'name' => '1440ϵ��',
      'id' => 224,
    ),
    7 => 
    array (
      'name' => '1464ϵ��',
      'id' => 109,
    ),
    8 => 
    array (
      'name' => '14Vϵ��',
      'id' => 108,
    ),
    9 => 
    array (
      'name' => '15Rϵ��',
      'id' => 114,
    ),
    10 => 
    array (
      'name' => '6400ϵ��',
      'id' => 225,
    ),
    11 => 
    array (
      'name' => '8500ϵ��',
      'id' => 238,
    ),
    12 => 
    array (
      'name' => 'D410ϵ��',
      'id' => 232,
    ),
    13 => 
    array (
      'name' => 'D531ϵ��',
      'id' => 233,
    ),
    14 => 
    array (
      'name' => 'D620ϵ��',
      'id' => 229,
    ),
    15 => 
    array (
      'name' => 'D630ϵ��',
      'id' => 230,
    ),
    16 => 
    array (
      'name' => 'D800ϵ��',
      'id' => 237,
    ),
    17 => 
    array (
      'name' => 'D820ϵ��',
      'id' => 234,
    ),
    18 => 
    array (
      'name' => 'D830ϵ��',
      'id' => 235,
    ),
    19 => 
    array (
      'name' => 'E1501ϵ��',
      'id' => 226,
    ),
    20 => 
    array (
      'name' => 'E1505ϵ��',
      'id' => 227,
    ),
    21 => 
    array (
      'name' => 'E4300ϵ��',
      'id' => 239,
    ),
    22 => 
    array (
      'name' => 'E6400ϵ��',
      'id' => 240,
    ),
    23 => 
    array (
      'name' => 'M2300ϵ��',
      'id' => 231,
    ),
    24 => 
    array (
      'name' => 'M5010ϵ��',
      'id' => 113,
    ),
    25 => 
    array (
      'name' => 'M65ϵ��',
      'id' => 236,
    ),
    26 => 
    array (
      'name' => 'Vostroϵ��',
      'id' => 223,
    ),
  ),
  11 => 
  array (
    0 => 
    array (
      'name' => '1ϵ��',
      'id' => 135,
    ),
    1 => 
    array (
      'name' => '2ϵ��',
      'id' => 134,
    ),
    2 => 
    array (
      'name' => '3ϵ��',
      'id' => 133,
    ),
    3 => 
    array (
      'name' => '5ϵ��',
      'id' => 132,
    ),
    4 => 
    array (
      'name' => '6ϵ��',
      'id' => 131,
    ),
    5 => 
    array (
      'name' => '7ϵ��',
      'id' => 130,
    ),
    6 => 
    array (
      'name' => '8ϵ��',
      'id' => 129,
    ),
    7 => 
    array (
      'name' => '9ϵ��',
      'id' => 304,
    ),
    8 => 
    array (
      'name' => 'Cϵ��',
      'id' => 125,
    ),
    9 => 
    array (
      'name' => 'Eϵ��',
      'id' => 115,
    ),
    10 => 
    array (
      'name' => 'nϵ��',
      'id' => 116,
    ),
    11 => 
    array (
      'name' => 'Xϵ��',
      'id' => 126,
    ),
    12 => 
    array (
      'name' => '�ֻ�',
      'id' => 27,
    ),
  ),
  16 => 
  array (
    0 => 
    array (
      'name' => '1ϵ��',
      'id' => 145,
    ),
    1 => 
    array (
      'name' => '3Gϵ��',
      'id' => 139,
    ),
    2 => 
    array (
      'name' => '6ϵ��',
      'id' => 142,
    ),
    3 => 
    array (
      'name' => '7ϵ��',
      'id' => 143,
    ),
    4 => 
    array (
      'name' => '8ϵ��',
      'id' => 144,
    ),
    5 => 
    array (
      'name' => '9ϵ��',
      'id' => 141,
    ),
    6 => 
    array (
      'name' => '�ֻ�',
      'id' => 32,
    ),
  ),
  35 => 
  array (
    0 => 
    array (
      'name' => '2400ϵ��',
      'id' => 242,
    ),
    1 => 
    array (
      'name' => '3050ϵ��',
      'id' => 243,
    ),
    2 => 
    array (
      'name' => '3220ϵ��',
      'id' => 244,
    ),
    3 => 
    array (
      'name' => '3820ϵ��',
      'id' => 77,
    ),
    4 => 
    array (
      'name' => '4741ϵ��',
      'id' => 76,
    ),
    5 => 
    array (
      'name' => '500ϵ��',
      'id' => 246,
    ),
    6 => 
    array (
      'name' => '5500ϵ��',
      'id' => 241,
    ),
    7 => 
    array (
      'name' => '5745ϵ��',
      'id' => 78,
    ),
  ),
  33 => 
  array (
    0 => 
    array (
      'name' => '42**ϵ��',
      'id' => 294,
    ),
    1 => 
    array (
      'name' => '44**ϵ�У�������4411��4410��4416',
      'id' => 295,
    ),
    2 => 
    array (
      'name' => 'Bϵ��',
      'id' => 62,
    ),
    3 => 
    array (
      'name' => 'CQ40ϵ��',
      'id' => 66,
    ),
    4 => 
    array (
      'name' => 'CQ45ϵ��',
      'id' => 296,
    ),
    5 => 
    array (
      'name' => 'CQ50ϵ��',
      'id' => 297,
    ),
    6 => 
    array (
      'name' => 'CQ60ϵ��',
      'id' => 298,
    ),
    7 => 
    array (
      'name' => 'DMϵ��',
      'id' => 68,
    ),
    8 => 
    array (
      'name' => 'DV4ϵ��',
      'id' => 67,
    ),
    9 => 
    array (
      'name' => 'DV5ϵ��',
      'id' => 220,
    ),
    10 => 
    array (
      'name' => 'DV6ϵ��',
      'id' => 219,
    ),
    11 => 
    array (
      'name' => 'Envyϵ��',
      'id' => 70,
    ),
    12 => 
    array (
      'name' => 'miniϵ��',
      'id' => 105,
    ),
    13 => 
    array (
      'name' => 'Mϵ��',
      'id' => 64,
    ),
    14 => 
    array (
      'name' => 'Pϵ��',
      'id' => 63,
    ),
    15 => 
    array (
      'name' => 'Sϵ��',
      'id' => 61,
    ),
    16 => 
    array (
      'name' => 'TMϵ��',
      'id' => 69,
    ),
  ),
  17 => 
  array (
    0 => 
    array (
      'name' => 'Aϵ��',
      'id' => 123,
    ),
    1 => 
    array (
      'name' => 'etϵ��',
      'id' => 127,
    ),
    2 => 
    array (
      'name' => 'Eϵ��',
      'id' => 124,
    ),
    3 => 
    array (
      'name' => 'Fϵ��',
      'id' => 136,
    ),
    4 => 
    array (
      'name' => 'iϵ��',
      'id' => 118,
    ),
    5 => 
    array (
      'name' => 'oϵ��',
      'id' => 119,
    ),
    6 => 
    array (
      'name' => 'pϵ��',
      'id' => 122,
    ),
    7 => 
    array (
      'name' => 'sϵ��',
      'id' => 121,
    ),
    8 => 
    array (
      'name' => 'TDϵ��',
      'id' => 120,
    ),
    9 => 
    array (
      'name' => 'vϵ��',
      'id' => 151,
    ),
    10 => 
    array (
      'name' => '��ϵ��',
      'id' => 128,
    ),
    11 => 
    array (
      'name' => '����ϵ��',
      'id' => 137,
    ),
    12 => 
    array (
      'name' => '�ֻ�',
      'id' => 33,
    ),
  ),
  14 => 
  array (
    0 => 
    array (
      'name' => 'aϵ��',
      'id' => 343,
    ),
    1 => 
    array (
      'name' => 'cϵ��',
      'id' => 178,
    ),
    2 => 
    array (
      'name' => 'dϵ��',
      'id' => 342,
    ),
    3 => 
    array (
      'name' => 'eϵ��',
      'id' => 340,
    ),
    4 => 
    array (
      'name' => 'fϵ��',
      'id' => 341,
    ),
    5 => 
    array (
      'name' => 'gϵ��',
      'id' => 181,
    ),
    6 => 
    array (
      'name' => 'jϵ��',
      'id' => 177,
    ),
    7 => 
    array (
      'name' => 'kϵ��',
      'id' => 173,
    ),
    8 => 
    array (
      'name' => 'mϵ��',
      'id' => 182,
    ),
    9 => 
    array (
      'name' => 'pϵ��',
      'id' => 338,
    ),
    10 => 
    array (
      'name' => 'rϵ��',
      'id' => 315,
    ),
    11 => 
    array (
      'name' => 'sϵ��',
      'id' => 196,
    ),
    12 => 
    array (
      'name' => 'tϵ��',
      'id' => 176,
    ),
    13 => 
    array (
      'name' => 'uϵ��',
      'id' => 179,
    ),
    14 => 
    array (
      'name' => 'vϵ��',
      'id' => 314,
    ),
    15 => 
    array (
      'name' => 'wϵ��',
      'id' => 175,
    ),
    16 => 
    array (
      'name' => 'xϵ��',
      'id' => 180,
    ),
    17 => 
    array (
      'name' => 'zϵ��',
      'id' => 339,
    ),
    18 => 
    array (
      'name' => '�ֻ�',
      'id' => 30,
    ),
  ),
  12 => 
  array (
    0 => 
    array (
      'name' => 'Aϵ��',
      'id' => 165,
    ),
    1 => 
    array (
      'name' => 'Cϵ��',
      'id' => 301,
    ),
    2 => 
    array (
      'name' => 'EMϵ��',
      'id' => 332,
    ),
    3 => 
    array (
      'name' => 'EXϵ��',
      'id' => 310,
    ),
    4 => 
    array (
      'name' => 'Eϵ��',
      'id' => 302,
    ),
    5 => 
    array (
      'name' => 'Fϵ��',
      'id' => 337,
    ),
    6 => 
    array (
      'name' => 'Iϵ��',
      'id' => 330,
    ),
    7 => 
    array (
      'name' => 'Kϵ��',
      'id' => 334,
    ),
    8 => 
    array (
      'name' => 'Lϵ��',
      'id' => 166,
    ),
    9 => 
    array (
      'name' => 'MBϵ��',
      'id' => 306,
    ),
    10 => 
    array (
      'name' => 'MEϵ��',
      'id' => 305,
    ),
    11 => 
    array (
      'name' => 'MSϵ��',
      'id' => 335,
    ),
    12 => 
    array (
      'name' => 'MTϵ��',
      'id' => 311,
    ),
    13 => 
    array (
      'name' => 'Qϵ��',
      'id' => 170,
    ),
    14 => 
    array (
      'name' => 'Tϵ��',
      'id' => 336,
    ),
    15 => 
    array (
      'name' => 'Uϵ��',
      'id' => 331,
    ),
    16 => 
    array (
      'name' => 'VEϵ��',
      'id' => 333,
    ),
    17 => 
    array (
      'name' => 'Vϵ��',
      'id' => 167,
    ),
    18 => 
    array (
      'name' => 'WXϵ��',
      'id' => 169,
    ),
    19 => 
    array (
      'name' => 'Wϵ��',
      'id' => 168,
    ),
    20 => 
    array (
      'name' => 'XTϵ��',
      'id' => 117,
    ),
    21 => 
    array (
      'name' => 'Zϵ��',
      'id' => 312,
    ),
  ),
  15 => 
  array (
    0 => 
    array (
      'name' => 'Aϵ��',
      'id' => 146,
    ),
    1 => 
    array (
      'name' => 'Fϵ��',
      'id' => 148,
    ),
    2 => 
    array (
      'name' => 'Sϵ��',
      'id' => 149,
    ),
    3 => 
    array (
      'name' => 'Tϵ��',
      'id' => 147,
    ),
  ),
  13 => 
  array (
    0 => 
    array (
      'name' => 'Bϵ��',
      'id' => 172,
    ),
    1 => 
    array (
      'name' => 'Cϵ��',
      'id' => 171,
    ),
    2 => 
    array (
      'name' => 'Dϵ��',
      'id' => 197,
    ),
    3 => 
    array (
      'name' => 'Eϵ��',
      'id' => 183,
    ),
    4 => 
    array (
      'name' => 'Fϵ��',
      'id' => 184,
    ),
    5 => 
    array (
      'name' => 'Gϵ��',
      'id' => 188,
    ),
    6 => 
    array (
      'name' => 'iϵ��',
      'id' => 186,
    ),
    7 => 
    array (
      'name' => 'Jϵ��',
      'id' => 187,
    ),
    8 => 
    array (
      'name' => 'Lϵ��',
      'id' => 189,
    ),
    9 => 
    array (
      'name' => 'Mϵ��',
      'id' => 185,
    ),
    10 => 
    array (
      'name' => 'Pϵ��',
      'id' => 191,
    ),
    11 => 
    array (
      'name' => 'Sϵ��',
      'id' => 174,
    ),
    12 => 
    array (
      'name' => 'Tϵ��',
      'id' => 313,
    ),
    13 => 
    array (
      'name' => 'Uϵ��',
      'id' => 192,
    ),
    14 => 
    array (
      'name' => 'Wϵ��',
      'id' => 190,
    ),
  ),
  19 => 
  array (
    0 => 
    array (
      'name' => 'bϵ��',
      'id' => 195,
    ),
    1 => 
    array (
      'name' => 'gϵ��',
      'id' => 194,
    ),
    2 => 
    array (
      'name' => 'kϵ��',
      'id' => 193,
    ),
    3 => 
    array (
      'name' => 'Pϵ��',
      'id' => 345,
    ),
  ),
  37 => 
  array (
    0 => 
    array (
      'name' => 'CW2ϵ��',
      'id' => 265,
    ),
    1 => 
    array (
      'name' => 'E2ϵ��',
      'id' => 255,
    ),
    2 => 
    array (
      'name' => 'E2ϵ��',
      'id' => 273,
    ),
    3 => 
    array (
      'name' => 'EAϵ��',
      'id' => 81,
    ),
    4 => 
    array (
      'name' => 'EBϵ��',
      'id' => 82,
    ),
    5 => 
    array (
      'name' => 'EEϵ��',
      'id' => 271,
    ),
    6 => 
    array (
      'name' => 'Eϵ��',
      'id' => 261,
    ),
    7 => 
    array (
      'name' => 'F11ϵ��',
      'id' => 275,
    ),
    8 => 
    array (
      'name' => 'J11ϵ��',
      'id' => 272,
    ),
    9 => 
    array (
      'name' => 'L13ϵ��',
      'id' => 274,
    ),
    10 => 
    array (
      'name' => 'Lϵ��',
      'id' => 277,
    ),
    11 => 
    array (
      'name' => 'M12ϵ��',
      'id' => 257,
    ),
    12 => 
    array (
      'name' => 'Mϵ��',
      'id' => 83,
    ),
    13 => 
    array (
      'name' => 'NW3ϵ��',
      'id' => 276,
    ),
    14 => 
    array (
      'name' => 'P11ϵ��',
      'id' => 256,
    ),
    15 => 
    array (
      'name' => 'P4ϵ��',
      'id' => 266,
    ),
    16 => 
    array (
      'name' => 'S11ϵ��',
      'id' => 263,
    ),
    17 => 
    array (
      'name' => 's12ϵ��',
      'id' => 260,
    ),
    18 => 
    array (
      'name' => 'Sϵ��',
      'id' => 84,
    ),
    19 => 
    array (
      'name' => 'TT4ϵ��',
      'id' => 269,
    ),
    20 => 
    array (
      'name' => 'W21ϵ��',
      'id' => 267,
    ),
    21 => 
    array (
      'name' => 'x13ϵ��',
      'id' => 258,
    ),
    22 => 
    array (
      'name' => 'Xϵ��',
      'id' => 268,
    ),
    23 => 
    array (
      'name' => 'Y11ϵ��',
      'id' => 264,
    ),
    24 => 
    array (
      'name' => 'y21ϵ��',
      'id' => 259,
    ),
    25 => 
    array (
      'name' => 'Z11ϵ��',
      'id' => 262,
    ),
    26 => 
    array (
      'name' => 'Z12ϵ��',
      'id' => 254,
    ),
    27 => 
    array (
      'name' => 'Z5ϵ��',
      'id' => 270,
    ),
  ),
  21 => 
  array (
    0 => 
    array (
      'name' => 'Cϵ��',
      'id' => 157,
    ),
    1 => 
    array (
      'name' => 'dϵ��',
      'id' => 155,
    ),
    2 => 
    array (
      'name' => 'Eϵ��',
      'id' => 156,
    ),
    3 => 
    array (
      'name' => 'fϵ��',
      'id' => 154,
    ),
    4 => 
    array (
      'name' => 'hϵ��',
      'id' => 283,
    ),
    5 => 
    array (
      'name' => 'kϵ��',
      'id' => 158,
    ),
    6 => 
    array (
      'name' => 'vϵ��',
      'id' => 153,
    ),
    7 => 
    array (
      'name' => 'xϵ��',
      'id' => 152,
    ),
    8 => 
    array (
      'name' => '�ֻ�',
      'id' => 36,
    ),
  ),
  43 => 
  array (
    0 => 
    array (
      'name' => 'Cϵ��',
      'id' => 307,
    ),
    1 => 
    array (
      'name' => 'ECϵ��',
      'id' => 326,
    ),
    2 => 
    array (
      'name' => 'Eϵ��',
      'id' => 325,
    ),
    3 => 
    array (
      'name' => 'Tϵ��',
      'id' => 327,
    ),
    4 => 
    array (
      'name' => 'Uϵ��',
      'id' => 324,
    ),
  ),
  20 => 
  array (
    0 => 
    array (
      'name' => 'Dϵ��',
      'id' => 160,
    ),
    1 => 
    array (
      'name' => 'Eϵ��',
      'id' => 159,
    ),
    2 => 
    array (
      'name' => 'Fϵ��',
      'id' => 162,
    ),
    3 => 
    array (
      'name' => 'Nϵ��',
      'id' => 161,
    ),
    4 => 
    array (
      'name' => 'Sϵ��',
      'id' => 164,
    ),
    5 => 
    array (
      'name' => 'Wϵ��',
      'id' => 163,
    ),
    6 => 
    array (
      'name' => '�ֻ�',
      'id' => 35,
    ),
  ),
  3 => 
  array (
    0 => 
    array (
      'name' => 'E30ϵ��',
      'id' => 216,
    ),
    1 => 
    array (
      'name' => 'E40ϵ��',
      'id' => 60,
    ),
    2 => 
    array (
      'name' => 'E50ϵ��',
      'id' => 73,
    ),
    3 => 
    array (
      'name' => 'L410ϵ��',
      'id' => 213,
    ),
    4 => 
    array (
      'name' => 'L412ϵ��',
      'id' => 214,
    ),
    5 => 
    array (
      'name' => 'R400ϵ��',
      'id' => 206,
    ),
    6 => 
    array (
      'name' => 'R500ϵ��',
      'id' => 207,
    ),
    7 => 
    array (
      'name' => 'R50ϵ��',
      'id' => 293,
    ),
    8 => 
    array (
      'name' => 'R60ϵ��',
      'id' => 284,
    ),
    9 => 
    array (
      'name' => 'R61ϵ��',
      'id' => 204,
    ),
    10 => 
    array (
      'name' => 'SL300ϵ��',
      'id' => 287,
    ),
    11 => 
    array (
      'name' => 'SL400ϵ��',
      'id' => 288,
    ),
    12 => 
    array (
      'name' => 'SL410ϵ��',
      'id' => 58,
    ),
    13 => 
    array (
      'name' => 'SL500ϵ��',
      'id' => 289,
    ),
    14 => 
    array (
      'name' => 'SL510ϵ��',
      'id' => 215,
    ),
    15 => 
    array (
      'name' => 'T400Sϵ��',
      'id' => 217,
    ),
    16 => 
    array (
      'name' => 'T400ϵ��',
      'id' => 205,
    ),
    17 => 
    array (
      'name' => 'T40ϵ��',
      'id' => 286,
    ),
    18 => 
    array (
      'name' => 'T410Sϵ��',
      'id' => 218,
    ),
    19 => 
    array (
      'name' => 'T410ϵ��',
      'id' => 209,
    ),
    20 => 
    array (
      'name' => 'T410ϵ��',
      'id' => 59,
    ),
    21 => 
    array (
      'name' => 'T41ϵ��',
      'id' => 290,
    ),
    22 => 
    array (
      'name' => 'T42ϵ��',
      'id' => 291,
    ),
    23 => 
    array (
      'name' => 'T43ϵ��',
      'id' => 292,
    ),
    24 => 
    array (
      'name' => 'T500ϵ��',
      'id' => 208,
    ),
    25 => 
    array (
      'name' => 'T510ϵ��',
      'id' => 210,
    ),
    26 => 
    array (
      'name' => 'T510ϵ��',
      'id' => 72,
    ),
    27 => 
    array (
      'name' => 'T60ϵ��',
      'id' => 202,
    ),
    28 => 
    array (
      'name' => 'T61ϵ��',
      'id' => 203,
    ),
    29 => 
    array (
      'name' => 'W500ϵ��',
      'id' => 212,
    ),
    30 => 
    array (
      'name' => 'X100eϵ��',
      'id' => 211,
    ),
    31 => 
    array (
      'name' => 'X200ϵ��',
      'id' => 201,
    ),
    32 => 
    array (
      'name' => 'X201ϵ��',
      'id' => 9,
    ),
    33 => 
    array (
      'name' => 'x300',
      'id' => 282,
    ),
    34 => 
    array (
      'name' => 'X301ϵ��',
      'id' => 71,
    ),
    35 => 
    array (
      'name' => 'X60ϵ��',
      'id' => 200,
    ),
    36 => 
    array (
      'name' => 'X61ϵ��',
      'id' => 285,
    ),
  ),
  42 => 
  array (
    0 => 
    array (
      'name' => 'Gϵ��',
      'id' => 303,
    ),
    1 => 
    array (
      'name' => 'HDϵ��',
      'id' => 344,
    ),
    2 => 
    array (
      'name' => '����',
      'id' => 316,
    ),
  ),
  38 => 
  array (
    0 => 
    array (
      'name' => 'ipad',
      'id' => 279,
    ),
    1 => 
    array (
      'name' => 'MacBook Pro',
      'id' => 85,
    ),
  ),
  54 => 
  array (
    0 => 
    array (
      'name' => 'iϵ��',
      'id' => 328,
    ),
    1 => 
    array (
      'name' => 'Kϵ��',
      'id' => 309,
    ),
    2 => 
    array (
      'name' => 'Vϵ��',
      'id' => 329,
    ),
  ),
  36 => 
  array (
    0 => 
    array (
      'name' => 'L600ϵ��',
      'id' => 252,
    ),
    1 => 
    array (
      'name' => 'L600ϵ��',
      'id' => 79,
    ),
    2 => 
    array (
      'name' => 'L630ϵ��',
      'id' => 253,
    ),
    3 => 
    array (
      'name' => 'NB255ϵ��',
      'id' => 247,
    ),
    4 => 
    array (
      'name' => 'R700ϵ��',
      'id' => 251,
    ),
    5 => 
    array (
      'name' => 'T130ϵ��',
      'id' => 80,
    ),
    6 => 
    array (
      'name' => 'T210ϵ��',
      'id' => 249,
    ),
    7 => 
    array (
      'name' => 'T230ϵ��',
      'id' => 248,
    ),
    8 => 
    array (
      'name' => 'W100ϵ��',
      'id' => 250,
    ),
  ),
  18 => 
  array (
    0 => 
    array (
      'name' => 'Mϵ��',
      'id' => 138,
    ),
    1 => 
    array (
      'name' => '�ֻ�',
      'id' => 34,
    ),
  ),
  40 => 
  array (
    0 => 
    array (
      'name' => 'Nϵ��',
      'id' => 104,
    ),
    1 => 
    array (
      'name' => 'Pϵ��',
      'id' => 278,
    ),
    2 => 
    array (
      'name' => 'Qϵ��',
      'id' => 103,
    ),
    3 => 
    array (
      'name' => 'Rϵ��',
      'id' => 101,
    ),
    4 => 
    array (
      'name' => 'Xϵ��',
      'id' => 102,
    ),
  ),
  53 => 
  array (
    0 => 
    array (
      'name' => 'Sϵ��',
      'id' => 308,
    ),
  ),
  9 => 
  array (
    0 => 
    array (
      'name' => '��ǩ��ӡ��',
      'id' => 299,
    ),
    1 => 
    array (
      'name' => '���⴫���',
      'id' => 74,
    ),
    2 => 
    array (
      'name' => '����һ���',
      'id' => 18,
    ),
    3 => 
    array (
      'name' => '��īһ���',
      'id' => 19,
    ),
    4 => 
    array (
      'name' => '���������',
      'id' => 24,
    ),
    5 => 
    array (
      'name' => '��תӡ�����',
      'id' => 75,
    ),
  ),
  31 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 52,
    ),
    1 => 
    array (
      'name' => '�������',
      'id' => 57,
    ),
  ),
  26 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 54,
    ),
    1 => 
    array (
      'name' => '�������',
      'id' => 46,
    ),
  ),
  28 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 55,
    ),
    1 => 
    array (
      'name' => '�������',
      'id' => 49,
    ),
  ),
  30 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 56,
    ),
    1 => 
    array (
      'name' => '�������',
      'id' => 51,
    ),
  ),
  22 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 39,
    ),
    1 => 
    array (
      'name' => '���������',
      'id' => 40,
    ),
    2 => 
    array (
      'name' => '�������',
      'id' => 38,
    ),
  ),
  23 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 42,
    ),
    1 => 
    array (
      'name' => '���������',
      'id' => 43,
    ),
    2 => 
    array (
      'name' => '�������',
      'id' => 41,
    ),
  ),
  27 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 48,
    ),
    1 => 
    array (
      'name' => '�������',
      'id' => 47,
    ),
  ),
  10 => 
  array (
    0 => 
    array (
      'name' => '���⴫���',
      'id' => 300,
    ),
    1 => 
    array (
      'name' => '����һ���',
      'id' => 20,
    ),
    2 => 
    array (
      'name' => '���������',
      'id' => 22,
    ),
  ),
  5 => 
  array (
    0 => 
    array (
      'name' => '�����ӡ��',
      'id' => 12,
    ),
    1 => 
    array (
      'name' => '����һ���',
      'id' => 17,
    ),
    2 => 
    array (
      'name' => '��ī�����',
      'id' => 25,
    ),
  ),
  1 => 
  array (
    0 => 
    array (
      'name' => '�����ӡ��',
      'id' => 1,
    ),
    1 => 
    array (
      'name' => '��ī��ӡ��',
      'id' => 2,
    ),
  ),
  2 => 
  array (
    0 => 
    array (
      'name' => '�����ӡ��',
      'id' => 5,
    ),
    1 => 
    array (
      'name' => '����һ���',
      'id' => 7,
    ),
    2 => 
    array (
      'name' => '��ī�����',
      'id' => 26,
    ),
    3 => 
    array (
      'name' => '��ī��ӡ��',
      'id' => 6,
    ),
    4 => 
    array (
      'name' => '��īһ���',
      'id' => 8,
    ),
  ),
  4 => 
  array (
    0 => 
    array (
      'name' => '��ī��ӡ��',
      'id' => 10,
    ),
    1 => 
    array (
      'name' => '��īһ���',
      'id' => 15,
    ),
    2 => 
    array (
      'name' => '��ʽ��ӡ��',
      'id' => 11,
    ),
  ),
  32 => 
  array (
    0 => 
    array (
      'name' => '���������',
      'id' => 53,
    ),
  ),
  24 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 44,
    ),
  ),
  25 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 45,
    ),
  ),
  29 => 
  array (
    0 => 
    array (
      'name' => '�������',
      'id' => 50,
    ),
  ),
);


$_model = array (
  119 => 
  array (
    0 => 
    array (
      'name' => '01',
      'id' => 2168,
    ),
    1 => 
    array (
      'name' => 'O1e',
      'id' => 2114,
    ),
  ),
  1 => 
  array (
    0 => 
    array (
      'name' => '1000/1005/1200/1220/3300/3330/3380MFP',
      'id' => 9,
    ),
    1 => 
    array (
      'name' => '1010/1012/1015/1018/1020/1022/M1319F/M1005 MFP ',
      'id' => 3,
    ),
    2 => 
    array (
      'name' => '1160/1320/3390/3392',
      'id' => 6,
    ),
    3 => 
    array (
      'name' => 'Color LaserJet 1600/2600/2605/CM1015/CM1017 MFP',
      'id' => 23,
    ),
    4 => 
    array (
      'name' => 'Color LaserJet 2550/2820/2840',
      'id' => 25,
    ),
    5 => 
    array (
      'name' => 'Color LaserJet 3500/3550/3700',
      'id' => 24,
    ),
    6 => 
    array (
      'name' => 'Color LaserJet 3600/3800/CP3505',
      'id' => 26,
    ),
    7 => 
    array (
      'name' => 'Color LaserJet 5500/5550',
      'id' => 27,
    ),
    8 => 
    array (
      'name' => 'Color LaserJet CP1025',
      'id' => 21,
    ),
    9 => 
    array (
      'name' => 'CP1215/1515n/1518ni/CM1312/1312nfi MFP ',
      'id' => 19,
    ),
    10 => 
    array (
      'name' => 'HP Color LaserJet CP2025 2320ϵ��',
      'id' => 20,
    ),
    11 => 
    array (
      'name' => 'LaserJet 1100��ӡ��ϵ��/3200һ���ϵ��',
      'id' => 14,
    ),
    12 => 
    array (
      'name' => 'LaserJet 1150��ӡ��',
      'id' => 12,
    ),
    13 => 
    array (
      'name' => 'LaserJet 1300��ӡ��ϵ��',
      'id' => 10,
    ),
    14 => 
    array (
      'name' => 'LaserJet 2300��ӡ��ϵ��',
      'id' => 8,
    ),
    15 => 
    array (
      'name' => 'LaserJet 2400/2410/2420/2430',
      'id' => 11,
    ),
    16 => 
    array (
      'name' => 'LaserJet 5000/5100��ӡ��ϵ��   ',
      'id' => 15,
    ),
    17 => 
    array (
      'name' => 'LaserJet 5200��ӡ��ϵ��',
      'id' => 17,
    ),
    18 => 
    array (
      'name' => 'LaserJet 5L/6L/3100/3150',
      'id' => 13,
    ),
    19 => 
    array (
      'name' => 'LaserJet CM1415fn/fnw',
      'id' => 22,
    ),
    20 => 
    array (
      'name' => 'LaserJet4240/4250/4350',
      'id' => 16,
    ),
    21 => 
    array (
      'name' => 'M1120/M1522n/M1522nf/P1505',
      'id' => 2,
    ),
    22 => 
    array (
      'name' => 'P1007/P1008/M1136/M1213/M1216',
      'id' => 1,
    ),
    23 => 
    array (
      'name' => 'P1505/M1120/M1522MFP',
      'id' => 18,
    ),
    24 => 
    array (
      'name' => 'P1566/P1606dn/M1536dnf',
      'id' => 5,
    ),
    25 => 
    array (
      'name' => 'P2014/2015/M2727',
      'id' => 7,
    ),
    26 => 
    array (
      'name' => 'P2035/2035n/P2055d/2055dn',
      'id' => 4,
    ),
  ),
  39 => 
  array (
    0 => 
    array (
      'name' => '1000D',
      'id' => 236,
    ),
    1 => 
    array (
      'name' => '1D Mark IV',
      'id' => 206,
    ),
    2 => 
    array (
      'name' => '450D',
      'id' => 244,
    ),
    3 => 
    array (
      'name' => '500D',
      'id' => 214,
    ),
    4 => 
    array (
      'name' => '50D',
      'id' => 231,
    ),
    5 => 
    array (
      'name' => '550D',
      'id' => 205,
    ),
    6 => 
    array (
      'name' => '5D Mark II',
      'id' => 230,
    ),
    7 => 
    array (
      'name' => '7D',
      'id' => 207,
    ),
  ),
  135 => 
  array (
    0 => 
    array (
      'name' => '1006',
      'id' => 3057,
    ),
    1 => 
    array (
      'name' => '1100',
      'id' => 3225,
    ),
    2 => 
    array (
      'name' => '1108',
      'id' => 3208,
    ),
    3 => 
    array (
      'name' => '1112',
      'id' => 3209,
    ),
    4 => 
    array (
      'name' => '1116',
      'id' => 3226,
    ),
    5 => 
    array (
      'name' => '1200',
      'id' => 3227,
    ),
    6 => 
    array (
      'name' => '1202',
      'id' => 3041,
    ),
    7 => 
    array (
      'name' => '1203',
      'id' => 3042,
    ),
    8 => 
    array (
      'name' => '1208',
      'id' => 2282,
    ),
    9 => 
    array (
      'name' => '1209',
      'id' => 2281,
    ),
    10 => 
    array (
      'name' => '1255 CDMA',
      'id' => 2280,
    ),
    11 => 
    array (
      'name' => '1265 CDMA',
      'id' => 2279,
    ),
    12 => 
    array (
      'name' => '1280',
      'id' => 2278,
    ),
    13 => 
    array (
      'name' => '1315 CDMA',
      'id' => 2277,
    ),
    14 => 
    array (
      'name' => '1325 CDMA',
      'id' => 2276,
    ),
    15 => 
    array (
      'name' => '1506 CDMA',
      'id' => 2275,
    ),
    16 => 
    array (
      'name' => '1508 CDMA',
      'id' => 2274,
    ),
    17 => 
    array (
      'name' => '1600',
      'id' => 3228,
    ),
    18 => 
    array (
      'name' => '1616',
      'id' => 3001,
    ),
    19 => 
    array (
      'name' => '1650',
      'id' => 2273,
    ),
    20 => 
    array (
      'name' => '1661',
      'id' => 3019,
    ),
    21 => 
    array (
      'name' => '1662',
      'id' => 3020,
    ),
    22 => 
    array (
      'name' => '1680c',
      'id' => 2272,
    ),
    23 => 
    array (
      'name' => '1681c',
      'id' => 3210,
    ),
    24 => 
    array (
      'name' => '1682c',
      'id' => 3229,
    ),
    25 => 
    array (
      'name' => '1800',
      'id' => 2271,
    ),
  ),
  27 => 
  array (
    0 => 
    array (
      'name' => '1006',
      'id' => 726,
    ),
    1 => 
    array (
      'name' => '1116',
      'id' => 853,
    ),
    2 => 
    array (
      'name' => '1200',
      'id' => 838,
    ),
    3 => 
    array (
      'name' => '1202',
      'id' => 782,
    ),
    4 => 
    array (
      'name' => '1208',
      'id' => 863,
    ),
    5 => 
    array (
      'name' => '1209',
      'id' => 823,
    ),
    6 => 
    array (
      'name' => '1265',
      'id' => 876,
    ),
    7 => 
    array (
      'name' => '1280',
      'id' => 711,
    ),
    8 => 
    array (
      'name' => '1315',
      'id' => 869,
    ),
    9 => 
    array (
      'name' => '1325',
      'id' => 852,
    ),
    10 => 
    array (
      'name' => '1506',
      'id' => 781,
    ),
    11 => 
    array (
      'name' => '1508',
      'id' => 790,
    ),
    12 => 
    array (
      'name' => '1616',
      'id' => 710,
    ),
    13 => 
    array (
      'name' => '1650',
      'id' => 862,
    ),
    14 => 
    array (
      'name' => '1661',
      'id' => 780,
    ),
    15 => 
    array (
      'name' => '1662',
      'id' => 779,
    ),
    16 => 
    array (
      'name' => '1680c',
      'id' => 816,
    ),
    17 => 
    array (
      'name' => '1681c',
      'id' => 801,
    ),
    18 => 
    array (
      'name' => '1682c',
      'id' => 778,
    ),
    19 => 
    array (
      'name' => '1706',
      'id' => 200,
    ),
    20 => 
    array (
      'name' => '1800',
      'id' => 709,
    ),
    21 => 
    array (
      'name' => '2135',
      'id' => 843,
    ),
    22 => 
    array (
      'name' => '2220s',
      'id' => 714,
    ),
    23 => 
    array (
      'name' => '2228',
      'id' => 832,
    ),
    24 => 
    array (
      'name' => '2320c',
      'id' => 831,
    ),
    25 => 
    array (
      'name' => '2322c',
      'id' => 777,
    ),
    26 => 
    array (
      'name' => '2323c',
      'id' => 830,
    ),
    27 => 
    array (
      'name' => '2330c',
      'id' => 776,
    ),
    28 => 
    array (
      'name' => '2332c',
      'id' => 775,
    ),
    29 => 
    array (
      'name' => '2360',
      'id' => 861,
    ),
    30 => 
    array (
      'name' => '2505',
      'id' => 847,
    ),
    31 => 
    array (
      'name' => '2600c',
      'id' => 822,
    ),
    32 => 
    array (
      'name' => '2605',
      'id' => 789,
    ),
    33 => 
    array (
      'name' => '2608',
      'id' => 774,
    ),
    34 => 
    array (
      'name' => '2626',
      'id' => 870,
    ),
    35 => 
    array (
      'name' => '2660',
      'id' => 860,
    ),
    36 => 
    array (
      'name' => '2680s',
      'id' => 812,
    ),
    37 => 
    array (
      'name' => '2690',
      'id' => 708,
    ),
    38 => 
    array (
      'name' => '2692',
      'id' => 689,
    ),
    39 => 
    array (
      'name' => '2700c',
      'id' => 773,
    ),
    40 => 
    array (
      'name' => '2705',
      'id' => 772,
    ),
    41 => 
    array (
      'name' => '2710C',
      'id' => 707,
    ),
    42 => 
    array (
      'name' => '2720a',
      'id' => 771,
    ),
    43 => 
    array (
      'name' => '2730c',
      'id' => 719,
    ),
    44 => 
    array (
      'name' => '2760',
      'id' => 883,
    ),
    45 => 
    array (
      'name' => '3109c',
      'id' => 815,
    ),
    46 => 
    array (
      'name' => '3110c',
      'id' => 859,
    ),
    47 => 
    array (
      'name' => '3110E',
      'id' => 837,
    ),
    48 => 
    array (
      'name' => '3120c',
      'id' => 821,
    ),
    49 => 
    array (
      'name' => '3208c',
      'id' => 770,
    ),
    50 => 
    array (
      'name' => '3500c',
      'id' => 836,
    ),
    51 => 
    array (
      'name' => '3555',
      'id' => 829,
    ),
    52 => 
    array (
      'name' => '3600s',
      'id' => 811,
    ),
    53 => 
    array (
      'name' => '3602s',
      'id' => 788,
    ),
    54 => 
    array (
      'name' => '3606',
      'id' => 769,
    ),
    55 => 
    array (
      'name' => '3608',
      'id' => 828,
    ),
    56 => 
    array (
      'name' => '3610a',
      'id' => 800,
    ),
    57 => 
    array (
      'name' => '3710F',
      'id' => 768,
    ),
    58 => 
    array (
      'name' => '3711',
      'id' => 767,
    ),
    59 => 
    array (
      'name' => '3720',
      'id' => 716,
    ),
    60 => 
    array (
      'name' => '3806',
      'id' => 766,
    ),
    61 => 
    array (
      'name' => '5000',
      'id' => 820,
    ),
    62 => 
    array (
      'name' => '5030',
      'id' => 765,
    ),
    63 => 
    array (
      'name' => '5070',
      'id' => 865,
    ),
    64 => 
    array (
      'name' => '5130XM',
      'id' => 764,
    ),
    65 => 
    array (
      'name' => '5208',
      'id' => 799,
    ),
    66 => 
    array (
      'name' => '5220XM',
      'id' => 810,
    ),
    67 => 
    array (
      'name' => '5230(Nuron)',
      'id' => 762,
    ),
    68 => 
    array (
      'name' => '5232',
      'id' => 706,
    ),
    69 => 
    array (
      'name' => '5232XM',
      'id' => 763,
    ),
    70 => 
    array (
      'name' => '5233',
      'id' => 705,
    ),
    71 => 
    array (
      'name' => '5235',
      'id' => 713,
    ),
    72 => 
    array (
      'name' => '5310XM',
      'id' => 840,
    ),
    73 => 
    array (
      'name' => '5320di XM',
      'id' => 761,
    ),
    74 => 
    array (
      'name' => '5320XM',
      'id' => 809,
    ),
    75 => 
    array (
      'name' => '5330XM',
      'id' => 760,
    ),
    76 => 
    array (
      'name' => '5530XM',
      'id' => 759,
    ),
    77 => 
    array (
      'name' => '5610XM',
      'id' => 839,
    ),
    78 => 
    array (
      'name' => '5611XM',
      'id' => 758,
    ),
    79 => 
    array (
      'name' => '5630XM',
      'id' => 757,
    ),
    80 => 
    array (
      'name' => '5700',
      'id' => 854,
    ),
    81 => 
    array (
      'name' => '5710XM',
      'id' => 882,
    ),
    82 => 
    array (
      'name' => '5730XM',
      'id' => 756,
    ),
    83 => 
    array (
      'name' => '5800iXM',
      'id' => 720,
    ),
    84 => 
    array (
      'name' => '5800W',
      'id' => 691,
    ),
    85 => 
    array (
      'name' => '5800XM',
      'id' => 723,
    ),
    86 => 
    array (
      'name' => '5802XM',
      'id' => 721,
    ),
    87 => 
    array (
      'name' => '5900XM',
      'id' => 755,
    ),
    88 => 
    array (
      'name' => '6110N',
      'id' => 846,
    ),
    89 => 
    array (
      'name' => '6120c',
      'id' => 845,
    ),
    90 => 
    array (
      'name' => '6120ci',
      'id' => 722,
    ),
    91 => 
    array (
      'name' => '6122c',
      'id' => 819,
    ),
    92 => 
    array (
      'name' => '6124c',
      'id' => 818,
    ),
    93 => 
    array (
      'name' => '6131i',
      'id' => 851,
    ),
    94 => 
    array (
      'name' => '6202c',
      'id' => 725,
    ),
    95 => 
    array (
      'name' => '6208c',
      'id' => 724,
    ),
    96 => 
    array (
      'name' => '6210s(N)',
      'id' => 808,
    ),
    97 => 
    array (
      'name' => '6210si',
      'id' => 718,
    ),
    98 => 
    array (
      'name' => '6212c',
      'id' => 798,
    ),
    99 => 
    array (
      'name' => '6216c',
      'id' => 783,
    ),
    100 => 
    array (
      'name' => '6220c',
      'id' => 797,
    ),
    101 => 
    array (
      'name' => '6260s',
      'id' => 787,
    ),
    102 => 
    array (
      'name' => '6263',
      'id' => 835,
    ),
    103 => 
    array (
      'name' => '6267',
      'id' => 881,
    ),
    104 => 
    array (
      'name' => '6288',
      'id' => 867,
    ),
    105 => 
    array (
      'name' => '6288',
      'id' => 866,
    ),
    106 => 
    array (
      'name' => '6290',
      'id' => 880,
    ),
    107 => 
    array (
      'name' => '6300',
      'id' => 875,
    ),
    108 => 
    array (
      'name' => '6301',
      'id' => 874,
    ),
    109 => 
    array (
      'name' => '6303c',
      'id' => 754,
    ),
    110 => 
    array (
      'name' => '6303ci',
      'id' => 704,
    ),
    111 => 
    array (
      'name' => '6316s',
      'id' => 753,
    ),
    112 => 
    array (
      'name' => '6350',
      'id' => 752,
    ),
    113 => 
    array (
      'name' => '6500c',
      'id' => 824,
    ),
    114 => 
    array (
      'name' => '6500s',
      'id' => 857,
    ),
    115 => 
    array (
      'name' => '6555',
      'id' => 844,
    ),
    116 => 
    array (
      'name' => '6600i slide',
      'id' => 751,
    ),
    117 => 
    array (
      'name' => '6600s',
      'id' => 806,
    ),
    118 => 
    array (
      'name' => '660f',
      'id' => 807,
    ),
    119 => 
    array (
      'name' => '6650f',
      'id' => 805,
    ),
    120 => 
    array (
      'name' => '6700c',
      'id' => 750,
    ),
    121 => 
    array (
      'name' => '6700s',
      'id' => 703,
    ),
    122 => 
    array (
      'name' => '6702s',
      'id' => 702,
    ),
    123 => 
    array (
      'name' => '6710N',
      'id' => 749,
    ),
    124 => 
    array (
      'name' => '6720c',
      'id' => 748,
    ),
    125 => 
    array (
      'name' => '6730c',
      'id' => 717,
    ),
    126 => 
    array (
      'name' => '6750',
      'id' => 747,
    ),
    127 => 
    array (
      'name' => '6760s',
      'id' => 746,
    ),
    128 => 
    array (
      'name' => '6788',
      'id' => 712,
    ),
    129 => 
    array (
      'name' => '6788i',
      'id' => 201,
    ),
    130 => 
    array (
      'name' => '6790(Mako',
      'id' => 745,
    ),
    131 => 
    array (
      'name' => '7020',
      'id' => 744,
    ),
    132 => 
    array (
      'name' => '7070',
      'id' => 804,
    ),
    133 => 
    array (
      'name' => '7088',
      'id' => 858,
    ),
    134 => 
    array (
      'name' => '7100s',
      'id' => 827,
    ),
    135 => 
    array (
      'name' => '7205',
      'id' => 743,
    ),
    136 => 
    array (
      'name' => '7210c',
      'id' => 795,
    ),
    137 => 
    array (
      'name' => '7212c',
      'id' => 786,
    ),
    138 => 
    array (
      'name' => '7230',
      'id' => 701,
    ),
    139 => 
    array (
      'name' => '7310c',
      'id' => 814,
    ),
    140 => 
    array (
      'name' => '7500P',
      'id' => 850,
    ),
    141 => 
    array (
      'name' => '7510a',
      'id' => 794,
    ),
    142 => 
    array (
      'name' => '7610s(7612s)',
      'id' => 796,
    ),
    143 => 
    array (
      'name' => '7705',
      'id' => 742,
    ),
    144 => 
    array (
      'name' => '7900P',
      'id' => 849,
    ),
    145 => 
    array (
      'name' => '8208i',
      'id' => 740,
    ),
    146 => 
    array (
      'name' => '8208i',
      'id' => 741,
    ),
    147 => 
    array (
      'name' => '8600L',
      'id' => 848,
    ),
    148 => 
    array (
      'name' => '8800A',
      'id' => 834,
    ),
    149 => 
    array (
      'name' => '8800CA',
      'id' => 826,
    ),
    150 => 
    array (
      'name' => '8800DA',
      'id' => 785,
    ),
    151 => 
    array (
      'name' => '8800e',
      'id' => 879,
    ),
    152 => 
    array (
      'name' => '8800GA',
      'id' => 784,
    ),
    153 => 
    array (
      'name' => '8800SA',
      'id' => 825,
    ),
    154 => 
    array (
      'name' => 'Aeon',
      'id' => 884,
    ),
    155 => 
    array (
      'name' => 'C1-00',
      'id' => 700,
    ),
    156 => 
    array (
      'name' => 'C2-00',
      'id' => 699,
    ),
    157 => 
    array (
      'name' => 'C3-00',
      'id' => 698,
    ),
    158 => 
    array (
      'name' => 'C5-00',
      'id' => 194,
    ),
    159 => 
    array (
      'name' => 'C5-01',
      'id' => 191,
    ),
    160 => 
    array (
      'name' => 'E5-00',
      'id' => 190,
    ),
    161 => 
    array (
      'name' => 'E51',
      'id' => 842,
    ),
    162 => 
    array (
      'name' => 'E52',
      'id' => 739,
    ),
    163 => 
    array (
      'name' => 'E55',
      'id' => 738,
    ),
    164 => 
    array (
      'name' => 'E61i',
      'id' => 873,
    ),
    165 => 
    array (
      'name' => 'E62',
      'id' => 872,
    ),
    166 => 
    array (
      'name' => 'E63',
      'id' => 737,
    ),
    167 => 
    array (
      'name' => 'E65',
      'id' => 864,
    ),
    168 => 
    array (
      'name' => 'E66',
      'id' => 803,
    ),
    169 => 
    array (
      'name' => 'E71',
      'id' => 802,
    ),
    170 => 
    array (
      'name' => 'E71x',
      'id' => 736,
    ),
    171 => 
    array (
      'name' => 'E72',
      'id' => 735,
    ),
    172 => 
    array (
      'name' => 'E72i',
      'id' => 690,
    ),
    173 => 
    array (
      'name' => 'E73',
      'id' => 189,
    ),
    174 => 
    array (
      'name' => 'E75',
      'id' => 734,
    ),
    175 => 
    array (
      'name' => 'E90',
      'id' => 868,
    ),
    176 => 
    array (
      'name' => 'E900',
      'id' => 733,
    ),
    177 => 
    array (
      'name' => 'N75',
      'id' => 878,
    ),
    178 => 
    array (
      'name' => 'N76',
      'id' => 856,
    ),
    179 => 
    array (
      'name' => 'N77',
      'id' => 877,
    ),
    180 => 
    array (
      'name' => 'N78',
      'id' => 813,
    ),
    181 => 
    array (
      'name' => 'N79',
      'id' => 791,
    ),
    182 => 
    array (
      'name' => 'N8-00',
      'id' => 697,
    ),
    183 => 
    array (
      'name' => 'N81',
      'id' => 841,
    ),
    184 => 
    array (
      'name' => 'N82',
      'id' => 833,
    ),
    185 => 
    array (
      'name' => 'N85',
      'id' => 793,
    ),
    186 => 
    array (
      'name' => 'N86',
      'id' => 732,
    ),
    187 => 
    array (
      'name' => 'N900',
      'id' => 715,
    ),
    188 => 
    array (
      'name' => 'N93i',
      'id' => 871,
    ),
    189 => 
    array (
      'name' => 'N95',
      'id' => 855,
    ),
    190 => 
    array (
      'name' => 'N95-8GB',
      'id' => 817,
    ),
    191 => 
    array (
      'name' => 'N96',
      'id' => 792,
    ),
    192 => 
    array (
      'name' => 'n97',
      'id' => 731,
    ),
    193 => 
    array (
      'name' => 'N97 Mini',
      'id' => 193,
    ),
    194 => 
    array (
      'name' => 'N97 Mini',
      'id' => 730,
    ),
    195 => 
    array (
      'name' => 'N97i',
      'id' => 729,
    ),
    196 => 
    array (
      'name' => 'X2-00',
      'id' => 696,
    ),
    197 => 
    array (
      'name' => 'X3',
      'id' => 728,
    ),
    198 => 
    array (
      'name' => 'X3-01',
      'id' => 192,
    ),
    199 => 
    array (
      'name' => 'X5-00',
      'id' => 695,
    ),
    200 => 
    array (
      'name' => 'X5-01',
      'id' => 694,
    ),
    201 => 
    array (
      'name' => 'X6-00',
      'id' => 727,
    ),
    202 => 
    array (
      'name' => 'X6M',
      'id' => 692,
    ),
    203 => 
    array (
      'name' => 'X9',
      'id' => 693,
    ),
  ),
  35 => 
  array (
    0 => 
    array (
      'name' => '118',
      'id' => 2521,
    ),
    1 => 
    array (
      'name' => '219',
      'id' => 2504,
    ),
    2 => 
    array (
      'name' => '2318',
      'id' => 2491,
    ),
    3 => 
    array (
      'name' => '238',
      'id' => 2510,
    ),
    4 => 
    array (
      'name' => '239',
      'id' => 2499,
    ),
    5 => 
    array (
      'name' => '268',
      'id' => 2501,
    ),
    6 => 
    array (
      'name' => '269',
      'id' => 2498,
    ),
    7 => 
    array (
      'name' => '2718',
      'id' => 2492,
    ),
    8 => 
    array (
      'name' => '288',
      'id' => 2516,
    ),
    9 => 
    array (
      'name' => '289',
      'id' => 2508,
    ),
    10 => 
    array (
      'name' => '2938',
      'id' => 2503,
    ),
    11 => 
    array (
      'name' => '2938ʱ�а�',
      'id' => 2485,
    ),
    12 => 
    array (
      'name' => '299',
      'id' => 2497,
    ),
    13 => 
    array (
      'name' => '518',
      'id' => 2523,
    ),
    14 => 
    array (
      'name' => '519',
      'id' => 2519,
    ),
    15 => 
    array (
      'name' => '528',
      'id' => 2511,
    ),
    16 => 
    array (
      'name' => '529',
      'id' => 2514,
    ),
    17 => 
    array (
      'name' => '539',
      'id' => 2502,
    ),
    18 => 
    array (
      'name' => '6060',
      'id' => 2476,
    ),
    19 => 
    array (
      'name' => '6168',
      'id' => 1431,
    ),
    20 => 
    array (
      'name' => '6168',
      'id' => 2477,
    ),
    21 => 
    array (
      'name' => '6168H',
      'id' => 2475,
    ),
    22 => 
    array (
      'name' => '6168H',
      'id' => 1359,
    ),
    23 => 
    array (
      'name' => '6268',
      'id' => 2478,
    ),
    24 => 
    array (
      'name' => '6268H',
      'id' => 1429,
    ),
    25 => 
    array (
      'name' => '6268H',
      'id' => 2472,
    ),
    26 => 
    array (
      'name' => '6268U',
      'id' => 1425,
    ),
    27 => 
    array (
      'name' => '688',
      'id' => 2522,
    ),
    28 => 
    array (
      'name' => '728',
      'id' => 2518,
    ),
    29 => 
    array (
      'name' => '728B',
      'id' => 2513,
    ),
    30 => 
    array (
      'name' => '7360',
      'id' => 2500,
    ),
    31 => 
    array (
      'name' => '766',
      'id' => 2496,
    ),
    32 => 
    array (
      'name' => '769',
      'id' => 2506,
    ),
    33 => 
    array (
      'name' => '8166',
      'id' => 2532,
    ),
    34 => 
    array (
      'name' => '8260',
      'id' => 2531,
    ),
    35 => 
    array (
      'name' => '828',
      'id' => 2524,
    ),
    36 => 
    array (
      'name' => '8288',
      'id' => 2527,
    ),
    37 => 
    array (
      'name' => '8310',
      'id' => 2528,
    ),
    38 => 
    array (
      'name' => '8360',
      'id' => 2530,
    ),
    39 => 
    array (
      'name' => '838G2',
      'id' => 2533,
    ),
    40 => 
    array (
      'name' => '858',
      'id' => 2525,
    ),
    41 => 
    array (
      'name' => '858',
      'id' => 2526,
    ),
    42 => 
    array (
      'name' => '8688',
      'id' => 2529,
    ),
    43 => 
    array (
      'name' => '8900',
      'id' => 1346,
    ),
    44 => 
    array (
      'name' => '8900',
      'id' => 2465,
    ),
    45 => 
    array (
      'name' => 'D16',
      'id' => 1422,
    ),
    46 => 
    array (
      'name' => 'D21',
      'id' => 1374,
    ),
    47 => 
    array (
      'name' => 'D28',
      'id' => 1372,
    ),
    48 => 
    array (
      'name' => 'D280',
      'id' => 1419,
    ),
    49 => 
    array (
      'name' => 'D50',
      'id' => 1370,
    ),
    50 => 
    array (
      'name' => 'D500',
      'id' => 1345,
    ),
    51 => 
    array (
      'name' => 'D508',
      'id' => 1354,
    ),
    52 => 
    array (
      'name' => 'D510',
      'id' => 1353,
    ),
    53 => 
    array (
      'name' => 'D520',
      'id' => 1417,
    ),
    54 => 
    array (
      'name' => 'D550',
      'id' => 1344,
    ),
    55 => 
    array (
      'name' => 'E200',
      'id' => 1367,
    ),
    56 => 
    array (
      'name' => 'E210',
      'id' => 1415,
    ),
    57 => 
    array (
      'name' => 'E230',
      'id' => 1350,
    ),
    58 => 
    array (
      'name' => 'E28',
      'id' => 1413,
    ),
    59 => 
    array (
      'name' => 'E570',
      'id' => 1343,
    ),
    60 => 
    array (
      'name' => 'E600',
      'id' => 1410,
    ),
    61 => 
    array (
      'name' => 'F603',
      'id' => 1407,
    ),
    62 => 
    array (
      'name' => 'F608',
      'id' => 1404,
    ),
    63 => 
    array (
      'name' => 'F61',
      'id' => 1349,
    ),
    64 => 
    array (
      'name' => 'F618',
      'id' => 1340,
    ),
    65 => 
    array (
      'name' => 'F620',
      'id' => 1342,
    ),
    66 => 
    array (
      'name' => 'F668',
      'id' => 1352,
    ),
    67 => 
    array (
      'name' => 'F669',
      'id' => 1401,
    ),
    68 => 
    array (
      'name' => 'F69',
      'id' => 1357,
    ),
    69 => 
    array (
      'name' => 'F800',
      'id' => 1398,
    ),
    70 => 
    array (
      'name' => 'F801',
      'id' => 1348,
    ),
    71 => 
    array (
      'name' => 'N16',
      'id' => 1395,
    ),
    72 => 
    array (
      'name' => 'N80',
      'id' => 1366,
    ),
    73 => 
    array (
      'name' => 'N88',
      'id' => 1364,
    ),
    74 => 
    array (
      'name' => 'N900',
      'id' => 1362,
    ),
    75 => 
    array (
      'name' => 'N900 smart',
      'id' => 1341,
    ),
    76 => 
    array (
      'name' => 'N900+',
      'id' => 1393,
    ),
    77 => 
    array (
      'name' => 'N900C',
      'id' => 1355,
    ),
    78 => 
    array (
      'name' => 'N91',
      'id' => 1351,
    ),
    79 => 
    array (
      'name' => 'N92',
      'id' => 1391,
    ),
    80 => 
    array (
      'name' => 'S100',
      'id' => 1388,
    ),
    81 => 
    array (
      'name' => 'S20',
      'id' => 1386,
    ),
    82 => 
    array (
      'name' => 'S50',
      'id' => 1380,
    ),
    83 => 
    array (
      'name' => 'S60',
      'id' => 1378,
    ),
    84 => 
    array (
      'name' => 'S66',
      'id' => 1347,
    ),
    85 => 
    array (
      'name' => 'W700',
      'id' => 1376,
    ),
  ),
  10 => 
  array (
    0 => 
    array (
      'name' => '1270/1280/1290/900/1290S',
      'id' => 2856,
    ),
    1 => 
    array (
      'name' => '790/825/780/785/870/895',
      'id' => 2857,
    ),
    2 => 
    array (
      'name' => 'color 680/680T/685/777',
      'id' => 2855,
    ),
    3 => 
    array (
      'name' => 'COLOR400/440/460',
      'id' => 2921,
    ),
    4 => 
    array (
      'name' => 'CX3900/CX3905/CX4900/CX5900/C79',
      'id' => 2854,
    ),
    5 => 
    array (
      'name' => 'CX5500/CX5900/CX6900F/CX8300/CX9300F/C110',
      'id' => 2878,
    ),
    6 => 
    array (
      'name' => 'EPSON Stylus C63/C65/CX3500',
      'id' => 2879,
    ),
    7 => 
    array (
      'name' => 'ME OFFICE 1100 A3+',
      'id' => 128,
    ),
    8 => 
    array (
      'name' => 'ME Office 70',
      'id' => 125,
    ),
    9 => 
    array (
      'name' => 'ME1+',
      'id' => 2080,
    ),
    10 => 
    array (
      'name' => 'ME30 ',
      'id' => 119,
    ),
    11 => 
    array (
      'name' => 'ME33',
      'id' => 126,
    ),
    12 => 
    array (
      'name' => 'ME330',
      'id' => 2957,
    ),
    13 => 
    array (
      'name' => 'PH700/710/720/750/EX/EX2/EX3',
      'id' => 2920,
    ),
    14 => 
    array (
      'name' => 'Photo RX590',
      'id' => 2959,
    ),
    15 => 
    array (
      'name' => 'R210/R230/R310/RX510/610/630',
      'id' => 2853,
    ),
    16 => 
    array (
      'name' => 'SP810/830/830U/925/935',
      'id' => 2881,
    ),
    17 => 
    array (
      'name' => 'STYLUS C50/C60/C61/CX3100',
      'id' => 2927,
    ),
    18 => 
    array (
      'name' => 'Stylus C63/C65',
      'id' => 2880,
    ),
    19 => 
    array (
      'name' => 'Stylus Photo R230',
      'id' => 120,
    ),
    20 => 
    array (
      'name' => 'Stylus Photo R270',
      'id' => 121,
    ),
    21 => 
    array (
      'name' => 'Stylus Photo R390',
      'id' => 124,
    ),
  ),
  112 => 
  array (
    0 => 
    array (
      'name' => '1440DY',
      'id' => 2041,
    ),
    1 => 
    array (
      'name' => 'E6410',
      'id' => 1863,
    ),
    2 => 
    array (
      'name' => 'I1440R',
      'id' => 2040,
    ),
  ),
  109 => 
  array (
    0 => 
    array (
      'name' => '1464DC',
      'id' => 2035,
    ),
    1 => 
    array (
      'name' => '1464R',
      'id' => 2030,
    ),
  ),
  145 => 
  array (
    0 => 
    array (
      'name' => '1810C',
      'id' => 2310,
    ),
  ),
  36 => 
  array (
    0 => 
    array (
      'name' => '191',
      'id' => 1291,
    ),
    1 => 
    array (
      'name' => '192',
      'id' => 1325,
    ),
    2 => 
    array (
      'name' => '193',
      'id' => 1279,
    ),
    3 => 
    array (
      'name' => '198',
      'id' => 1296,
    ),
    4 => 
    array (
      'name' => '199',
      'id' => 1294,
    ),
    5 => 
    array (
      'name' => '298',
      'id' => 1319,
    ),
    6 => 
    array (
      'name' => '618',
      'id' => 1287,
    ),
    7 => 
    array (
      'name' => '692',
      'id' => 1301,
    ),
    8 => 
    array (
      'name' => '9@9q',
      'id' => 1324,
    ),
    9 => 
    array (
      'name' => '9@9u',
      'id' => 1321,
    ),
    10 => 
    array (
      'name' => '9@9V',
      'id' => 1305,
    ),
    11 => 
    array (
      'name' => 'C600',
      'id' => 1276,
    ),
    12 => 
    array (
      'name' => 'C700',
      'id' => 1246,
    ),
    13 => 
    array (
      'name' => 'C702',
      'id' => 1274,
    ),
    14 => 
    array (
      'name' => 'D900',
      'id' => 1232,
    ),
    15 => 
    array (
      'name' => 'D908',
      'id' => 1245,
    ),
    16 => 
    array (
      'name' => 'E100',
      'id' => 1339,
    ),
    17 => 
    array (
      'name' => 'E102',
      'id' => 1273,
    ),
    18 => 
    array (
      'name' => 'E210',
      'id' => 1338,
    ),
    19 => 
    array (
      'name' => 'F610',
      'id' => 1228,
    ),
    20 => 
    array (
      'name' => 'K600',
      'id' => 1242,
    ),
    21 => 
    array (
      'name' => 'K700',
      'id' => 1271,
    ),
    22 => 
    array (
      'name' => 'M200',
      'id' => 1337,
    ),
    23 => 
    array (
      'name' => 'M600',
      'id' => 1299,
    ),
    24 => 
    array (
      'name' => 'T910',
      'id' => 1220,
    ),
    25 => 
    array (
      'name' => 'TM700',
      'id' => 1336,
    ),
    26 => 
    array (
      'name' => 'V808',
      'id' => 1269,
    ),
    27 => 
    array (
      'name' => 'V900',
      'id' => 1267,
    ),
    28 => 
    array (
      'name' => 'W186',
      'id' => 1265,
    ),
    29 => 
    array (
      'name' => 'X100',
      'id' => 1241,
    ),
    30 => 
    array (
      'name' => 'X300',
      'id' => 1335,
    ),
    31 => 
    array (
      'name' => 'X320',
      'id' => 1263,
    ),
    32 => 
    array (
      'name' => 'X500',
      'id' => 1334,
    ),
    33 => 
    array (
      'name' => 'X501',
      'id' => 1261,
    ),
    34 => 
    array (
      'name' => 'X503',
      'id' => 1239,
    ),
    35 => 
    array (
      'name' => 'X510',
      'id' => 1226,
    ),
    36 => 
    array (
      'name' => 'X520',
      'id' => 1286,
    ),
    37 => 
    array (
      'name' => 'X530',
      'id' => 1259,
    ),
    38 => 
    array (
      'name' => 'X550',
      'id' => 1256,
    ),
    39 => 
    array (
      'name' => 'X600',
      'id' => 1333,
    ),
    40 => 
    array (
      'name' => 'X603',
      'id' => 1255,
    ),
    41 => 
    array (
      'name' => 'X605',
      'id' => 1230,
    ),
    42 => 
    array (
      'name' => 'X606',
      'id' => 1237,
    ),
    43 => 
    array (
      'name' => 'X620',
      'id' => 1328,
    ),
    44 => 
    array (
      'name' => 'X630',
      'id' => 1253,
    ),
    45 => 
    array (
      'name' => 'X650',
      'id' => 1252,
    ),
    46 => 
    array (
      'name' => 'X700',
      'id' => 1327,
    ),
    47 => 
    array (
      'name' => 'X703',
      'id' => 1224,
    ),
    48 => 
    array (
      'name' => 'X710',
      'id' => 1284,
    ),
    49 => 
    array (
      'name' => 'X712',
      'id' => 1235,
    ),
    50 => 
    array (
      'name' => 'X800',
      'id' => 1289,
    ),
    51 => 
    array (
      'name' => 'X806',
      'id' => 1251,
    ),
    52 => 
    array (
      'name' => 'X809',
      'id' => 1222,
    ),
    53 => 
    array (
      'name' => 'X810',
      'id' => 1250,
    ),
    54 => 
    array (
      'name' => 'X830',
      'id' => 1248,
    ),
  ),
  134 => 
  array (
    0 => 
    array (
      'name' => '2110',
      'id' => 3161,
    ),
    1 => 
    array (
      'name' => '2112',
      'id' => 3211,
    ),
    2 => 
    array (
      'name' => '2116',
      'id' => 3141,
    ),
    3 => 
    array (
      'name' => '2125',
      'id' => 3142,
    ),
    4 => 
    array (
      'name' => '2135',
      'id' => 3230,
    ),
    5 => 
    array (
      'name' => '2220S',
      'id' => 3003,
    ),
    6 => 
    array (
      'name' => '2228 CDMA',
      'id' => 2270,
    ),
    7 => 
    array (
      'name' => '2255',
      'id' => 3231,
    ),
    8 => 
    array (
      'name' => '2280',
      'id' => 3232,
    ),
    9 => 
    array (
      'name' => '2300',
      'id' => 3212,
    ),
    10 => 
    array (
      'name' => '2310',
      'id' => 3233,
    ),
    11 => 
    array (
      'name' => '2320c',
      'id' => 2269,
    ),
    12 => 
    array (
      'name' => '2322c',
      'id' => 2268,
    ),
    13 => 
    array (
      'name' => '2323c',
      'id' => 2267,
    ),
    14 => 
    array (
      'name' => '2330c',
      'id' => 2266,
    ),
    15 => 
    array (
      'name' => '2332c',
      'id' => 2265,
    ),
    16 => 
    array (
      'name' => '2355',
      'id' => 3234,
    ),
    17 => 
    array (
      'name' => '2505',
      'id' => 3033,
    ),
    18 => 
    array (
      'name' => '2600',
      'id' => 2264,
    ),
    19 => 
    array (
      'name' => '2600c',
      'id' => 3276,
    ),
    20 => 
    array (
      'name' => '2608',
      'id' => 3253,
    ),
    21 => 
    array (
      'name' => '2610',
      'id' => 2263,
    ),
    22 => 
    array (
      'name' => '2626',
      'id' => 3235,
    ),
    23 => 
    array (
      'name' => '2630',
      'id' => 2262,
    ),
    24 => 
    array (
      'name' => '2650',
      'id' => 3043,
    ),
    25 => 
    array (
      'name' => '2652',
      'id' => 3044,
    ),
    26 => 
    array (
      'name' => '2660',
      'id' => 2261,
    ),
    27 => 
    array (
      'name' => '2680s',
      'id' => 2260,
    ),
    28 => 
    array (
      'name' => '2690',
      'id' => 3004,
    ),
    29 => 
    array (
      'name' => '2692',
      'id' => 2259,
    ),
    30 => 
    array (
      'name' => '2700c',
      'id' => 2980,
    ),
    31 => 
    array (
      'name' => '2710c',
      'id' => 3028,
    ),
    32 => 
    array (
      'name' => '2710N',
      'id' => 3213,
    ),
    33 => 
    array (
      'name' => '2720f',
      'id' => 3054,
    ),
    34 => 
    array (
      'name' => '2730c',
      'id' => 3236,
    ),
    35 => 
    array (
      'name' => '2760',
      'id' => 3034,
    ),
    36 => 
    array (
      'name' => '2855',
      'id' => 3143,
    ),
    37 => 
    array (
      'name' => '2865 CDMA',
      'id' => 2258,
    ),
  ),
  19 => 
  array (
    0 => 
    array (
      'name' => '290C/490CW',
      'id' => 2895,
    ),
    1 => 
    array (
      'name' => '585CW/6690CW/MFC250C',
      'id' => 2894,
    ),
    2 => 
    array (
      'name' => '6490CW/6892CDW',
      'id' => 2897,
    ),
    3 => 
    array (
      'name' => '790CW/5490CN/5890CN',
      'id' => 2896,
    ),
    4 => 
    array (
      'name' => 'DCP-145C/165C/385C',
      'id' => 2893,
    ),
    5 => 
    array (
      'name' => 'MFC-250C',
      'id' => 257,
    ),
    6 => 
    array (
      'name' => 'MFC-490CW',
      'id' => 251,
    ),
  ),
  133 => 
  array (
    0 => 
    array (
      'name' => '3100',
      'id' => 3237,
    ),
    1 => 
    array (
      'name' => '3105',
      'id' => 3214,
    ),
    2 => 
    array (
      'name' => '3108',
      'id' => 3045,
    ),
    3 => 
    array (
      'name' => '3109c',
      'id' => 2254,
    ),
    4 => 
    array (
      'name' => '3110c',
      'id' => 2253,
    ),
    5 => 
    array (
      'name' => '3110e',
      'id' => 3239,
    ),
    6 => 
    array (
      'name' => '3120',
      'id' => 3238,
    ),
    7 => 
    array (
      'name' => '3120C',
      'id' => 3060,
    ),
    8 => 
    array (
      'name' => '3125',
      'id' => 3162,
    ),
    9 => 
    array (
      'name' => '3152',
      'id' => 3163,
    ),
    10 => 
    array (
      'name' => '3155',
      'id' => 3164,
    ),
    11 => 
    array (
      'name' => '3208c',
      'id' => 2251,
    ),
    12 => 
    array (
      'name' => '3220',
      'id' => 3088,
    ),
    13 => 
    array (
      'name' => '3230',
      'id' => 3083,
    ),
    14 => 
    array (
      'name' => '3250',
      'id' => 3109,
    ),
    15 => 
    array (
      'name' => '3500c',
      'id' => 3021,
    ),
    16 => 
    array (
      'name' => '3600s',
      'id' => 2257,
    ),
    17 => 
    array (
      'name' => '3602s',
      'id' => 2248,
    ),
    18 => 
    array (
      'name' => '3606',
      'id' => 3035,
    ),
    19 => 
    array (
      'name' => '3608',
      'id' => 3036,
    ),
    20 => 
    array (
      'name' => '3610a',
      'id' => 3240,
    ),
    21 => 
    array (
      'name' => '3610f',
      'id' => 3215,
    ),
    22 => 
    array (
      'name' => '3650',
      'id' => 3216,
    ),
    23 => 
    array (
      'name' => '3710f',
      'id' => 3058,
    ),
    24 => 
    array (
      'name' => '3720C',
      'id' => 3207,
    ),
    25 => 
    array (
      'name' => '3806 CDMA',
      'id' => 2247,
    ),
  ),
  29 => 
  array (
    0 => 
    array (
      'name' => '3730C',
      'id' => 1826,
    ),
    1 => 
    array (
      'name' => '730SC',
      'id' => 1854,
    ),
    2 => 
    array (
      'name' => '931SC',
      'id' => 1853,
    ),
    3 => 
    array (
      'name' => 'A657',
      'id' => 1852,
    ),
    4 => 
    array (
      'name' => 'A797',
      'id' => 1851,
    ),
    5 => 
    array (
      'name' => 'A867',
      'id' => 1850,
    ),
    6 => 
    array (
      'name' => 'A885',
      'id' => 1849,
    ),
    7 => 
    array (
      'name' => 'A886',
      'id' => 1848,
    ),
    8 => 
    array (
      'name' => 'A887',
      'id' => 1847,
    ),
    9 => 
    array (
      'name' => 'A897',
      'id' => 1846,
    ),
    10 => 
    array (
      'name' => 'B189',
      'id' => 1714,
    ),
    11 => 
    array (
      'name' => 'B2100',
      'id' => 1845,
    ),
    12 => 
    array (
      'name' => 'B309',
      'id' => 1844,
    ),
    13 => 
    array (
      'name' => 'B3210',
      'id' => 1843,
    ),
    14 => 
    array (
      'name' => 'B3310',
      'id' => 1842,
    ),
    15 => 
    array (
      'name' => 'B3410W Ch@t',
      'id' => 1841,
    ),
    16 => 
    array (
      'name' => 'B5100',
      'id' => 1840,
    ),
    17 => 
    array (
      'name' => 'B5310',
      'id' => 1839,
    ),
    18 => 
    array (
      'name' => 'B5702C',
      'id' => 1838,
    ),
    19 => 
    array (
      'name' => 'B5722c',
      'id' => 1573,
    ),
    20 => 
    array (
      'name' => 'B6520',
      'id' => 1580,
    ),
    21 => 
    array (
      'name' => 'B7300c',
      'id' => 1837,
    ),
    22 => 
    array (
      'name' => 'B7320 (i637)',
      'id' => 1707,
    ),
    23 => 
    array (
      'name' => 'B7330',
      'id' => 1706,
    ),
    24 => 
    array (
      'name' => 'B7350',
      'id' => 1586,
    ),
    25 => 
    array (
      'name' => 'B7610',
      'id' => 1836,
    ),
    26 => 
    array (
      'name' => 'B7620u',
      'id' => 1601,
    ),
    27 => 
    array (
      'name' => 'B7620U(Armani3)',
      'id' => 1693,
    ),
    28 => 
    array (
      'name' => 'B900',
      'id' => 1835,
    ),
    29 => 
    array (
      'name' => 'Bigfoot',
      'id' => 1691,
    ),
    30 => 
    array (
      'name' => 'Bigfoot',
      'id' => 1696,
    ),
    31 => 
    array (
      'name' => 'C3010',
      'id' => 1834,
    ),
    32 => 
    array (
      'name' => 'C3050C(C3053)',
      'id' => 1833,
    ),
    33 => 
    array (
      'name' => 'C3060R',
      'id' => 1832,
    ),
    34 => 
    array (
      'name' => 'C3110C',
      'id' => 1831,
    ),
    35 => 
    array (
      'name' => 'c3200',
      'id' => 1590,
    ),
    36 => 
    array (
      'name' => 'C3212',
      'id' => 1830,
    ),
    37 => 
    array (
      'name' => 'C3310C',
      'id' => 1829,
    ),
    38 => 
    array (
      'name' => 'C3510',
      'id' => 1828,
    ),
    39 => 
    array (
      'name' => 'C3518',
      'id' => 1570,
    ),
    40 => 
    array (
      'name' => 'C3600c',
      'id' => 1470,
    ),
    41 => 
    array (
      'name' => 'C3610C',
      'id' => 1827,
    ),
    42 => 
    array (
      'name' => 'C5130U',
      'id' => 1825,
    ),
    43 => 
    array (
      'name' => 'C5212',
      'id' => 1824,
    ),
    44 => 
    array (
      'name' => 'C5220',
      'id' => 1823,
    ),
    45 => 
    array (
      'name' => 'C5510U',
      'id' => 1822,
    ),
    46 => 
    array (
      'name' => 'C6112c',
      'id' => 1821,
    ),
    47 => 
    array (
      'name' => 'C6625',
      'id' => 1820,
    ),
    48 => 
    array (
      'name' => 'E1070C',
      'id' => 1819,
    ),
    49 => 
    array (
      'name' => 'E1080C',
      'id' => 1818,
    ),
    50 => 
    array (
      'name' => 'E1088C',
      'id' => 1817,
    ),
    51 => 
    array (
      'name' => 'E1100c',
      'id' => 1816,
    ),
    52 => 
    array (
      'name' => 'E1107',
      'id' => 1815,
    ),
    53 => 
    array (
      'name' => 'E1117',
      'id' => 1814,
    ),
    54 => 
    array (
      'name' => 'E1120C',
      'id' => 1813,
    ),
    55 => 
    array (
      'name' => 'E1125',
      'id' => 1812,
    ),
    56 => 
    array (
      'name' => 'E1130B',
      'id' => 1811,
    ),
    57 => 
    array (
      'name' => 'E1150c',
      'id' => 1564,
    ),
    58 => 
    array (
      'name' => 'E1310C',
      'id' => 1810,
    ),
    59 => 
    array (
      'name' => 'E1360C',
      'id' => 1809,
    ),
    60 => 
    array (
      'name' => 'E1390',
      'id' => 1808,
    ),
    61 => 
    array (
      'name' => 'E189',
      'id' => 1471,
    ),
    62 => 
    array (
      'name' => 'E2100c',
      'id' => 1807,
    ),
    63 => 
    array (
      'name' => 'E2120C',
      'id' => 1806,
    ),
    64 => 
    array (
      'name' => 'E2130',
      'id' => 1805,
    ),
    65 => 
    array (
      'name' => 'E2210c',
      'id' => 1804,
    ),
    66 => 
    array (
      'name' => 'e2370',
      'id' => 1561,
    ),
    67 => 
    array (
      'name' => 'E2550',
      'id' => 1560,
    ),
    68 => 
    array (
      'name' => 'F299',
      'id' => 1686,
    ),
    69 => 
    array (
      'name' => 'F299',
      'id' => 1695,
    ),
    70 => 
    array (
      'name' => 'F619',
      'id' => 1803,
    ),
    71 => 
    array (
      'name' => 'F809',
      'id' => 1699,
    ),
    72 => 
    array (
      'name' => 'Flight',
      'id' => 1802,
    ),
    73 => 
    array (
      'name' => 'Galaxy 2',
      'id' => 1558,
    ),
    74 => 
    array (
      'name' => 'GT-B5210U',
      'id' => 1801,
    ),
    75 => 
    array (
      'name' => 'GT-B7702C',
      'id' => 1800,
    ),
    76 => 
    array (
      'name' => 'GT-B7732',
      'id' => 1455,
    ),
    77 => 
    array (
      'name' => 'GT-C3230',
      'id' => 1442,
    ),
    78 => 
    array (
      'name' => 'GT-C3300K',
      'id' => 1439,
    ),
    79 => 
    array (
      'name' => 'GT-C3370U',
      'id' => 1701,
    ),
    80 => 
    array (
      'name' => 'GT-C5530',
      'id' => 1556,
    ),
    81 => 
    array (
      'name' => 'GT-E1101C',
      'id' => 1799,
    ),
    82 => 
    array (
      'name' => 'GT-E1178',
      'id' => 1458,
    ),
    83 => 
    array (
      'name' => 'GT-E1220',
      'id' => 1457,
    ),
    84 => 
    array (
      'name' => 'GT-E2558',
      'id' => 1454,
    ),
    85 => 
    array (
      'name' => 'GT-i5801',
      'id' => 1411,
    ),
    86 => 
    array (
      'name' => 'GT-i6320C',
      'id' => 1798,
    ),
    87 => 
    array (
      'name' => 'GT-I9000',
      'id' => 1551,
    ),
    88 => 
    array (
      'name' => 'GT-S3370',
      'id' => 1456,
    ),
    89 => 
    array (
      'name' => 'GT-S3830U',
      'id' => 1855,
    ),
    90 => 
    array (
      'name' => 'GT-S3870U',
      'id' => 1700,
    ),
    91 => 
    array (
      'name' => 'GT-S5230c',
      'id' => 1797,
    ),
    92 => 
    array (
      'name' => 'GT-S5530',
      'id' => 1435,
    ),
    93 => 
    array (
      'name' => 'GT-S5628I',
      'id' => 1473,
    ),
    94 => 
    array (
      'name' => 'GT-S5630C',
      'id' => 1796,
    ),
    95 => 
    array (
      'name' => 'GT-S5680',
      'id' => 1426,
    ),
    96 => 
    array (
      'name' => 'GT-S7120U',
      'id' => 1795,
    ),
    97 => 
    array (
      'name' => 'GT-S7220U',
      'id' => 1794,
    ),
    98 => 
    array (
      'name' => 'GT-S7520U',
      'id' => 1711,
    ),
    99 => 
    array (
      'name' => 'H1 i8305',
      'id' => 1793,
    ),
    100 => 
    array (
      'name' => 'i350',
      'id' => 1792,
    ),
    101 => 
    array (
      'name' => 'i5700(Spica)',
      'id' => 1791,
    ),
    102 => 
    array (
      'name' => 'I6330C',
      'id' => 1790,
    ),
    103 => 
    array (
      'name' => 'i6410',
      'id' => 1405,
    ),
    104 => 
    array (
      'name' => 'I6500u',
      'id' => 1476,
    ),
    105 => 
    array (
      'name' => 'i7410',
      'id' => 1789,
    ),
    106 => 
    array (
      'name' => 'i7500U',
      'id' => 1692,
    ),
    107 => 
    array (
      'name' => 'I7500u',
      'id' => 1597,
    ),
    108 => 
    array (
      'name' => 'I7680',
      'id' => 1453,
    ),
    109 => 
    array (
      'name' => 'i8000U',
      'id' => 1788,
    ),
    110 => 
    array (
      'name' => 'i8180c',
      'id' => 1787,
    ),
    111 => 
    array (
      'name' => 'I8320',
      'id' => 1452,
    ),
    112 => 
    array (
      'name' => 'i8520',
      'id' => 1552,
    ),
    113 => 
    array (
      'name' => 'i8910U',
      'id' => 1786,
    ),
    114 => 
    array (
      'name' => 'i899',
      'id' => 1785,
    ),
    115 => 
    array (
      'name' => 'i920',
      'id' => 1784,
    ),
    116 => 
    array (
      'name' => 'i9200',
      'id' => 1381,
    ),
    117 => 
    array (
      'name' => 'J165',
      'id' => 1783,
    ),
    118 => 
    array (
      'name' => 'Link',
      'id' => 1782,
    ),
    119 => 
    array (
      'name' => 'M1 i8305',
      'id' => 1781,
    ),
    120 => 
    array (
      'name' => 'M100s',
      'id' => 1553,
    ),
    121 => 
    array (
      'name' => 'M2310',
      'id' => 1710,
    ),
    122 => 
    array (
      'name' => 'M2520',
      'id' => 1554,
    ),
    123 => 
    array (
      'name' => 'M2710c',
      'id' => 1705,
    ),
    124 => 
    array (
      'name' => 'M3310',
      'id' => 1780,
    ),
    125 => 
    array (
      'name' => 'M3318C',
      'id' => 1779,
    ),
    126 => 
    array (
      'name' => 'M3710',
      'id' => 1555,
    ),
    127 => 
    array (
      'name' => 'M519',
      'id' => 1778,
    ),
    128 => 
    array (
      'name' => 'M560',
      'id' => 1777,
    ),
    129 => 
    array (
      'name' => 'M5650U',
      'id' => 1776,
    ),
    130 => 
    array (
      'name' => 'M6710',
      'id' => 1775,
    ),
    131 => 
    array (
      'name' => 'M7600(M7603)',
      'id' => 1774,
    ),
    132 => 
    array (
      'name' => 'M8000',
      'id' => 1713,
    ),
    133 => 
    array (
      'name' => 'M8400',
      'id' => 1773,
    ),
    134 => 
    array (
      'name' => 'M8910U',
      'id' => 1772,
    ),
    135 => 
    array (
      'name' => 'M8920',
      'id' => 1550,
    ),
    136 => 
    array (
      'name' => 'Magnet',
      'id' => 1704,
    ),
    137 => 
    array (
      'name' => 'Moment',
      'id' => 1771,
    ),
    138 => 
    array (
      'name' => 'Mythic',
      'id' => 1770,
    ),
    139 => 
    array (
      'name' => 'R560',
      'id' => 1769,
    ),
    140 => 
    array (
      'name' => 'S3100',
      'id' => 1768,
    ),
    141 => 
    array (
      'name' => 'S3110c',
      'id' => 1767,
    ),
    142 => 
    array (
      'name' => 'S3310C',
      'id' => 1766,
    ),
    143 => 
    array (
      'name' => 'S3500',
      'id' => 1765,
    ),
    144 => 
    array (
      'name' => 'S3501C',
      'id' => 1764,
    ),
    145 => 
    array (
      'name' => 'S3550',
      'id' => 1549,
    ),
    146 => 
    array (
      'name' => 'S359',
      'id' => 1763,
    ),
    147 => 
    array (
      'name' => 'S3650C(S3653)',
      'id' => 1762,
    ),
    148 => 
    array (
      'name' => 'S3930C',
      'id' => 1761,
    ),
    149 => 
    array (
      'name' => 'S5050',
      'id' => 1760,
    ),
    150 => 
    array (
      'name' => 'S5150',
      'id' => 1467,
    ),
    151 => 
    array (
      'name' => 'S5200c',
      'id' => 1703,
    ),
    152 => 
    array (
      'name' => 'S5350',
      'id' => 1548,
    ),
    153 => 
    array (
      'name' => 'S5500',
      'id' => 1759,
    ),
    154 => 
    array (
      'name' => 'S5510',
      'id' => 1758,
    ),
    155 => 
    array (
      'name' => 'S5550u',
      'id' => 1547,
    ),
    156 => 
    array (
      'name' => 'S5560',
      'id' => 1757,
    ),
    157 => 
    array (
      'name' => 'S5580',
      'id' => 1400,
    ),
    158 => 
    array (
      'name' => 'S5600(S5603)',
      'id' => 1756,
    ),
    159 => 
    array (
      'name' => 'S5608U',
      'id' => 1755,
    ),
    160 => 
    array (
      'name' => 'S5628',
      'id' => 1464,
    ),
    161 => 
    array (
      'name' => 'S6700C',
      'id' => 1754,
    ),
    162 => 
    array (
      'name' => 'S7070c',
      'id' => 1461,
    ),
    163 => 
    array (
      'name' => 'S7350C',
      'id' => 1753,
    ),
    164 => 
    array (
      'name' => 'S7550',
      'id' => 1752,
    ),
    165 => 
    array (
      'name' => 'S8000c (��)',
      'id' => 1698,
    ),
    166 => 
    array (
      'name' => 'S8000U',
      'id' => 1751,
    ),
    167 => 
    array (
      'name' => 'S8300C',
      'id' => 1750,
    ),
    168 => 
    array (
      'name' => 'S8500',
      'id' => 1546,
    ),
    169 => 
    array (
      'name' => 'S9110',
      'id' => 1749,
    ),
    170 => 
    array (
      'name' => 'SCH_B299',
      'id' => 1450,
    ),
    171 => 
    array (
      'name' => 'SCH-F339',
      'id' => 1748,
    ),
    172 => 
    array (
      'name' => 'SCH-F539',
      'id' => 1709,
    ),
    173 => 
    array (
      'name' => 'SCH-F669',
      'id' => 1719,
    ),
    174 => 
    array (
      'name' => 'SCH-F839',
      'id' => 1747,
    ),
    175 => 
    array (
      'name' => 'SCH-F859',
      'id' => 1544,
    ),
    176 => 
    array (
      'name' => 'SCH-i220',
      'id' => 1746,
    ),
    177 => 
    array (
      'name' => 'SCH-i329',
      'id' => 1745,
    ),
    178 => 
    array (
      'name' => 'SCH-i909',
      'id' => 1394,
    ),
    179 => 
    array (
      'name' => 'SCH-i910',
      'id' => 1744,
    ),
    180 => 
    array (
      'name' => 'SCH-M589',
      'id' => 1743,
    ),
    181 => 
    array (
      'name' => 'SCH-M609',
      'id' => 1712,
    ),
    182 => 
    array (
      'name' => 'SCH-R311 (Axle)',
      'id' => 1742,
    ),
    183 => 
    array (
      'name' => 'SCH-R351',
      'id' => 1543,
    ),
    184 => 
    array (
      'name' => 'SCH-R460',
      'id' => 1741,
    ),
    185 => 
    array (
      'name' => 'SCH-S239',
      'id' => 1420,
    ),
    186 => 
    array (
      'name' => 'SCH-S559',
      'id' => 1390,
    ),
    187 => 
    array (
      'name' => 'SCH-S569',
      'id' => 1447,
    ),
    188 => 
    array (
      'name' => 'SCH-U570',
      'id' => 1740,
    ),
    189 => 
    array (
      'name' => 'SCH-W239',
      'id' => 1708,
    ),
    190 => 
    array (
      'name' => 'SCH-W319',
      'id' => 1416,
    ),
    191 => 
    array (
      'name' => 'SCH-W609',
      'id' => 1385,
    ),
    192 => 
    array (
      'name' => 'SCH-W699',
      'id' => 1718,
    ),
    193 => 
    array (
      'name' => 'SCH-W709',
      'id' => 1702,
    ),
    194 => 
    array (
      'name' => 'SCH-W750',
      'id' => 1739,
    ),
    195 => 
    array (
      'name' => 'SCH-W760',
      'id' => 1738,
    ),
    196 => 
    array (
      'name' => 'SCH-W830',
      'id' => 1737,
    ),
    197 => 
    array (
      'name' => 'SGH-A687',
      'id' => 1542,
    ),
    198 => 
    array (
      'name' => 'SGH-A697',
      'id' => 1483,
    ),
    199 => 
    array (
      'name' => 'SGH-B5712C',
      'id' => 1715,
    ),
    200 => 
    array (
      'name' => 'SGH-C270',
      'id' => 1736,
    ),
    201 => 
    array (
      'name' => 'SGH-i908L',
      'id' => 1735,
    ),
    202 => 
    array (
      'name' => 'SGH-M8800C',
      'id' => 1717,
    ),
    203 => 
    array (
      'name' => 'SGH-P250',
      'id' => 1734,
    ),
    204 => 
    array (
      'name' => 'SGH-S3030C',
      'id' => 1716,
    ),
    205 => 
    array (
      'name' => 'SGH-S3601c',
      'id' => 1472,
    ),
    206 => 
    array (
      'name' => 'SPH-M550',
      'id' => 1733,
    ),
    207 => 
    array (
      'name' => 'SPH-W9600',
      'id' => 1480,
    ),
    208 => 
    array (
      'name' => 'T239',
      'id' => 1732,
    ),
    209 => 
    array (
      'name' => 'T349',
      'id' => 1731,
    ),
    210 => 
    array (
      'name' => 'T401G',
      'id' => 1730,
    ),
    211 => 
    array (
      'name' => 'T469',
      'id' => 1729,
    ),
    212 => 
    array (
      'name' => 'T559',
      'id' => 1697,
    ),
    213 => 
    array (
      'name' => 'T749(Highlight)',
      'id' => 1728,
    ),
    214 => 
    array (
      'name' => 'T929',
      'id' => 1727,
    ),
    215 => 
    array (
      'name' => 'T939',
      'id' => 1726,
    ),
    216 => 
    array (
      'name' => 'U490',
      'id' => 1725,
    ),
    217 => 
    array (
      'name' => 'Vice',
      'id' => 1724,
    ),
    218 => 
    array (
      'name' => 'W589',
      'id' => 1723,
    ),
    219 => 
    array (
      'name' => 'W799',
      'id' => 1722,
    ),
    220 => 
    array (
      'name' => 'W820',
      'id' => 1603,
    ),
    221 => 
    array (
      'name' => 'W820(W8200)',
      'id' => 1694,
    ),
    222 => 
    array (
      'name' => 'W880',
      'id' => 1721,
    ),
    223 => 
    array (
      'name' => 'W920',
      'id' => 1720,
    ),
  ),
  294 => 
  array (
    0 => 
    array (
      'name' => '4255',
      'id' => 2828,
    ),
  ),
  61 => 
  array (
    0 => 
    array (
      'name' => '4310s',
      'id' => 2060,
    ),
    1 => 
    array (
      'name' => '4321s ',
      'id' => 2059,
    ),
    2 => 
    array (
      'name' => '4411S ',
      'id' => 2057,
    ),
    3 => 
    array (
      'name' => '4421s',
      'id' => 2066,
    ),
    4 => 
    array (
      'name' => '4520S ',
      'id' => 2063,
    ),
    5 => 
    array (
      'name' => '4710s',
      'id' => 2058,
    ),
    6 => 
    array (
      'name' => '4720S ',
      'id' => 2067,
    ),
  ),
  132 => 
  array (
    0 => 
    array (
      'name' => '5000',
      'id' => 3037,
    ),
    1 => 
    array (
      'name' => '5030',
      'id' => 3241,
    ),
    2 => 
    array (
      'name' => '5070',
      'id' => 3104,
    ),
    3 => 
    array (
      'name' => '5130',
      'id' => 2240,
    ),
    4 => 
    array (
      'name' => '5130XM',
      'id' => 3217,
    ),
    5 => 
    array (
      'name' => '5140',
      'id' => 3089,
    ),
    6 => 
    array (
      'name' => '5140i',
      'id' => 3090,
    ),
    7 => 
    array (
      'name' => '5200',
      'id' => 2239,
    ),
    8 => 
    array (
      'name' => '5208',
      'id' => 2237,
    ),
    9 => 
    array (
      'name' => '5220XM',
      'id' => 3206,
    ),
    10 => 
    array (
      'name' => '5228',
      'id' => 3177,
    ),
    11 => 
    array (
      'name' => '5230',
      'id' => 2234,
    ),
    12 => 
    array (
      'name' => '5232',
      'id' => 2230,
    ),
    13 => 
    array (
      'name' => '5233',
      'id' => 2228,
    ),
    14 => 
    array (
      'name' => '5235',
      'id' => 2235,
    ),
    15 => 
    array (
      'name' => '5236',
      'id' => 3194,
    ),
    16 => 
    array (
      'name' => '5238',
      'id' => 3027,
    ),
    17 => 
    array (
      'name' => '5250',
      'id' => 3007,
    ),
    18 => 
    array (
      'name' => '5300',
      'id' => 3105,
    ),
    19 => 
    array (
      'name' => '5310XM',
      'id' => 3069,
    ),
    20 => 
    array (
      'name' => '5320',
      'id' => 2226,
    ),
    21 => 
    array (
      'name' => '5320di',
      'id' => 2224,
    ),
    22 => 
    array (
      'name' => '5320XM',
      'id' => 3091,
    ),
    23 => 
    array (
      'name' => '5330',
      'id' => 2222,
    ),
    24 => 
    array (
      'name' => '5330 TV Edition',
      'id' => 3086,
    ),
    25 => 
    array (
      'name' => '5330XM',
      'id' => 3061,
    ),
    26 => 
    array (
      'name' => '5500',
      'id' => 3092,
    ),
    27 => 
    array (
      'name' => '5530',
      'id' => 2221,
    ),
    28 => 
    array (
      'name' => '5530XM',
      'id' => 3062,
    ),
    29 => 
    array (
      'name' => '5610',
      'id' => 2219,
    ),
    30 => 
    array (
      'name' => '5610XM',
      'id' => 3119,
    ),
    31 => 
    array (
      'name' => '5611',
      'id' => 2217,
    ),
    32 => 
    array (
      'name' => '5611XM',
      'id' => 3120,
    ),
    33 => 
    array (
      'name' => '5630XM',
      'id' => 2216,
    ),
    34 => 
    array (
      'name' => '5700XM',
      'id' => 3127,
    ),
    35 => 
    array (
      'name' => '5710XM',
      'id' => 3121,
    ),
    36 => 
    array (
      'name' => '5730XM',
      'id' => 3076,
    ),
    37 => 
    array (
      'name' => '5800',
      'id' => 2213,
    ),
    38 => 
    array (
      'name' => '5800i',
      'id' => 2210,
    ),
    39 => 
    array (
      'name' => '5800w',
      'id' => 2212,
    ),
    40 => 
    array (
      'name' => '5800XM',
      'id' => 3197,
    ),
    41 => 
    array (
      'name' => '5802',
      'id' => 2208,
    ),
    42 => 
    array (
      'name' => '5802XM',
      'id' => 3196,
    ),
    43 => 
    array (
      'name' => '5900XM',
      'id' => 3195,
    ),
  ),
  64 => 
  array (
    0 => 
    array (
      'name' => '5310M',
      'id' => 2069,
    ),
  ),
  2 => 
  array (
    0 => 
    array (
      'name' => '5550/5652/450/9600/9650/9680',
      'id' => 2944,
    ),
    1 => 
    array (
      'name' => 'D1668/2568/2668/5568',
      'id' => 34,
    ),
    2 => 
    array (
      'name' => 'D2468/1368/1468/1558/2368/2238/2288/3538/5168',
      'id' => 35,
    ),
    3 => 
    array (
      'name' => 'D4268/4368/Officejet Pro K8600/Officejet J5788/648',
      'id' => 37,
    ),
    4 => 
    array (
      'name' => 'DjF2128/F2188/2238/2288/4188',
      'id' => 2933,
    ),
    5 => 
    array (
      'name' => 'F735/D730/K109a/K209a',
      'id' => 38,
    ),
    6 => 
    array (
      'name' => 'F735/D730/K109a/K209a',
      'id' => 36,
    ),
    7 => 
    array (
      'name' => 'HP Deskjet 1050,2050/1000,2000',
      'id' => 2852,
    ),
    8 => 
    array (
      'name' => 'HP Deskjet 1200c,1200c/ps HP Designjet 200,400,600',
      'id' => 2905,
    ),
    9 => 
    array (
      'name' => 'HP Deskjet 2060/2010',
      'id' => 2928,
    ),
    10 => 
    array (
      'name' => 'HP Deskjet 710c,810c,830c,880c,890c,895cxi,1120c,1',
      'id' => 2900,
    ),
    11 => 
    array (
      'name' => 'HP Deskjet 810c, 840c, 845c, 920c, 948c,3820��HP PS',
      'id' => 2849,
    ),
    12 => 
    array (
      'name' => 'HP Deskjet F2418,F2488,F4238,F4288,F4488/ D1668,D2',
      'id' => 39,
    ),
    13 => 
    array (
      'name' => 'HP Deskjet F378,F388,F2128,F2188,F2238,F2288/HP PS',
      'id' => 2926,
    ),
    14 => 
    array (
      'name' => 'HP Deskjet F378,F388,F2128,F2188/ HP PSC 1318,1350',
      'id' => 2908,
    ),
    15 => 
    array (
      'name' => 'HP Deskjet F735,K209a/HP Deskjet D730,K109a/HP Pho',
      'id' => 2917,
    ),
    16 => 
    array (
      'name' => 'HP Deskjet710c,830c,850c,870cxi,880c,890c,895cxi,9',
      'id' => 2906,
    ),
    17 => 
    array (
      'name' => 'HP Officejet 4255,4256,5608,5609,5679/HP Deskjet 3',
      'id' => 2904,
    ),
    18 => 
    array (
      'name' => 'HP Officejet 6500,6500�����/ 6500A,6500A���߰�/7500A/60',
      'id' => 42,
    ),
    19 => 
    array (
      'name' => 'HP Officejet J3508,J3608,J5508,J3606',
      'id' => 2916,
    ),
    20 => 
    array (
      'name' => 'HP Officejet J3608,J5508,J3606',
      'id' => 2851,
    ),
    21 => 
    array (
      'name' => 'HP Officejet J4580,J4660,4500��׼��, 4500ȫ�ܰ�',
      'id' => 41,
    ),
    22 => 
    array (
      'name' => 'HP Officejet L7580,L7590/HP Officejet Pro K550,K55',
      'id' => 2915,
    ),
    23 => 
    array (
      'name' => 'HP Officejet Pro 8500, 8500A,8000',
      'id' => 3714,
    ),
    24 => 
    array (
      'name' => 'HP Officejet Pro K5300,K5400dn,K8600/Pro K5300,K54',
      'id' => 2850,
    ),
    25 => 
    array (
      'name' => 'HP Photosmart 3108,3308,C5188,C6188,C6288,C7188,C7',
      'id' => 2932,
    ),
    26 => 
    array (
      'name' => 'HP PSC 1350,2110,2310,2410/HP Officejet 4110,4255,',
      'id' => 2907,
    ),
    27 => 
    array (
      'name' => 'HP PSC 1508��HP Photosmart C3188/HP Officejet 6318/',
      'id' => 40,
    ),
    28 => 
    array (
      'name' => 'HP PSC 750��HP Officejet 5110,v40/HP Deskjet 920c,9',
      'id' => 2913,
    ),
    29 => 
    array (
      'name' => 'Photosmart148/7265/7268/7458',
      'id' => 2935,
    ),
  ),
  20 => 
  array (
    0 => 
    array (
      'name' => '558CN/778/753',
      'id' => 2943,
    ),
    1 => 
    array (
      'name' => 'KX-FL313CN',
      'id' => 2825,
    ),
    2 => 
    array (
      'name' => 'KX-FL313CN',
      'id' => 2826,
    ),
    3 => 
    array (
      'name' => 'KX-FL503CN/523CN',
      'id' => 2945,
    ),
    4 => 
    array (
      'name' => 'KX-FL513/543/613/653CN/668/678',
      'id' => 263,
    ),
    5 => 
    array (
      'name' => 'KX-FLB753CN/758CN',
      'id' => 2947,
    ),
    6 => 
    array (
      'name' => 'KX-FLM553CN/558CN',
      'id' => 2946,
    ),
    7 => 
    array (
      'name' => 'KX-MB228CN/258CN',
      'id' => 266,
    ),
  ),
  142 => 
  array (
    0 => 
    array (
      'name' => '6010C',
      'id' => 2296,
    ),
    1 => 
    array (
      'name' => '6018C',
      'id' => 2295,
    ),
    2 => 
    array (
      'name' => '6110C',
      'id' => 2290,
    ),
    3 => 
    array (
      'name' => '6118C',
      'id' => 2291,
    ),
    4 => 
    array (
      'name' => '6220C',
      'id' => 2293,
    ),
    5 => 
    array (
      'name' => '6228C',
      'id' => 2294,
    ),
    6 => 
    array (
      'name' => '6230C',
      'id' => 2292,
    ),
  ),
  131 => 
  array (
    0 => 
    array (
      'name' => '6012',
      'id' => 3184,
    ),
    1 => 
    array (
      'name' => '6015',
      'id' => 3165,
    ),
    2 => 
    array (
      'name' => '6015i',
      'id' => 3185,
    ),
    3 => 
    array (
      'name' => '6016i',
      'id' => 3166,
    ),
    4 => 
    array (
      'name' => '6019i',
      'id' => 3167,
    ),
    5 => 
    array (
      'name' => '6020',
      'id' => 3106,
    ),
    6 => 
    array (
      'name' => '6021',
      'id' => 3093,
    ),
    7 => 
    array (
      'name' => '6060',
      'id' => 3094,
    ),
    8 => 
    array (
      'name' => '6066 CDMA',
      'id' => 2203,
    ),
    9 => 
    array (
      'name' => '6070',
      'id' => 3095,
    ),
    10 => 
    array (
      'name' => '6080',
      'id' => 3096,
    ),
    11 => 
    array (
      'name' => '6085',
      'id' => 3218,
    ),
    12 => 
    array (
      'name' => '6086',
      'id' => 3242,
    ),
    13 => 
    array (
      'name' => '6088 CDMA',
      'id' => 2202,
    ),
    14 => 
    array (
      'name' => '6100',
      'id' => 3046,
    ),
    15 => 
    array (
      'name' => '6101',
      'id' => 3047,
    ),
    16 => 
    array (
      'name' => '6102',
      'id' => 3048,
    ),
    17 => 
    array (
      'name' => '6103',
      'id' => 3022,
    ),
    18 => 
    array (
      'name' => '6108',
      'id' => 3219,
    ),
    19 => 
    array (
      'name' => '6110c',
      'id' => 3122,
    ),
    20 => 
    array (
      'name' => '6110n',
      'id' => 3131,
    ),
    21 => 
    array (
      'name' => '6111',
      'id' => 3038,
    ),
    22 => 
    array (
      'name' => '6120ci',
      'id' => 2201,
    ),
    23 => 
    array (
      'name' => '6121c',
      'id' => 3107,
    ),
    24 => 
    array (
      'name' => '6122c',
      'id' => 3098,
    ),
    25 => 
    array (
      'name' => '6124c',
      'id' => 3110,
    ),
    26 => 
    array (
      'name' => '6125',
      'id' => 3049,
    ),
    27 => 
    array (
      'name' => '6130',
      'id' => 3220,
    ),
    28 => 
    array (
      'name' => '6130i',
      'id' => 3243,
    ),
    29 => 
    array (
      'name' => '6131',
      'id' => 3050,
    ),
    30 => 
    array (
      'name' => '6136',
      'id' => 3051,
    ),
    31 => 
    array (
      'name' => '6151',
      'id' => 3112,
    ),
    32 => 
    array (
      'name' => '6151',
      'id' => 3111,
    ),
    33 => 
    array (
      'name' => '6152',
      'id' => 3186,
    ),
    34 => 
    array (
      'name' => '6155',
      'id' => 3168,
    ),
    35 => 
    array (
      'name' => '6165',
      'id' => 3187,
    ),
    36 => 
    array (
      'name' => '6170',
      'id' => 3023,
    ),
    37 => 
    array (
      'name' => '6200',
      'id' => 3132,
    ),
    38 => 
    array (
      'name' => '6208c',
      'id' => 3082,
    ),
    39 => 
    array (
      'name' => '6210n',
      'id' => 3203,
    ),
    40 => 
    array (
      'name' => '6210s',
      'id' => 3202,
    ),
    41 => 
    array (
      'name' => '6212c',
      'id' => 3063,
    ),
    42 => 
    array (
      'name' => '6220c',
      'id' => 3123,
    ),
    43 => 
    array (
      'name' => '6225',
      'id' => 3221,
    ),
    44 => 
    array (
      'name' => '6230',
      'id' => 3222,
    ),
    45 => 
    array (
      'name' => '6230i',
      'id' => 3244,
    ),
    46 => 
    array (
      'name' => '6233',
      'id' => 3100,
    ),
    47 => 
    array (
      'name' => '6234',
      'id' => 3102,
    ),
    48 => 
    array (
      'name' => '6235 CDMA',
      'id' => 2200,
    ),
    49 => 
    array (
      'name' => '6255',
      'id' => 3188,
    ),
    50 => 
    array (
      'name' => '6260',
      'id' => 3064,
    ),
    51 => 
    array (
      'name' => '6260s',
      'id' => 3201,
    ),
    52 => 
    array (
      'name' => '6263',
      'id' => 3245,
    ),
    53 => 
    array (
      'name' => '6265',
      'id' => 3189,
    ),
    54 => 
    array (
      'name' => '6267',
      'id' => 3223,
    ),
    55 => 
    array (
      'name' => '6268',
      'id' => 3190,
    ),
    56 => 
    array (
      'name' => '6270',
      'id' => 3264,
    ),
    57 => 
    array (
      'name' => '6275 CDMA',
      'id' => 2199,
    ),
    58 => 
    array (
      'name' => '6280',
      'id' => 3114,
    ),
    59 => 
    array (
      'name' => '6288',
      'id' => 3115,
    ),
    60 => 
    array (
      'name' => '6290',
      'id' => 3200,
    ),
    61 => 
    array (
      'name' => '6300',
      'id' => 3065,
    ),
    62 => 
    array (
      'name' => '6301',
      'id' => 3052,
    ),
    63 => 
    array (
      'name' => '6303C',
      'id' => 3224,
    ),
    64 => 
    array (
      'name' => '6303ci',
      'id' => 2822,
    ),
    65 => 
    array (
      'name' => '6303i',
      'id' => 3205,
    ),
    66 => 
    array (
      'name' => '6313 CDMA',
      'id' => 2197,
    ),
    67 => 
    array (
      'name' => '6316s',
      'id' => 3066,
    ),
    68 => 
    array (
      'name' => '6330',
      'id' => 3246,
    ),
    69 => 
    array (
      'name' => '6500c',
      'id' => 2194,
    ),
    70 => 
    array (
      'name' => '6500s',
      'id' => 2192,
    ),
    71 => 
    array (
      'name' => '6555',
      'id' => 3265,
    ),
    72 => 
    array (
      'name' => '6600',
      'id' => 3247,
    ),
    73 => 
    array (
      'name' => '6600f',
      'id' => 3070,
    ),
    74 => 
    array (
      'name' => '6600i',
      'id' => 3084,
    ),
    75 => 
    array (
      'name' => '6600s',
      'id' => 3085,
    ),
    76 => 
    array (
      'name' => '6618',
      'id' => 3099,
    ),
    77 => 
    array (
      'name' => '6630',
      'id' => 3266,
    ),
    78 => 
    array (
      'name' => '6650',
      'id' => 3150,
    ),
    79 => 
    array (
      'name' => '6670',
      'id' => 3267,
    ),
    80 => 
    array (
      'name' => '6680',
      'id' => 3248,
    ),
    81 => 
    array (
      'name' => '6681',
      'id' => 3268,
    ),
    82 => 
    array (
      'name' => '6682',
      'id' => 3249,
    ),
    83 => 
    array (
      'name' => '6700c',
      'id' => 2191,
    ),
    84 => 
    array (
      'name' => '6700s',
      'id' => 2189,
    ),
    85 => 
    array (
      'name' => '6702s',
      'id' => 2188,
    ),
    86 => 
    array (
      'name' => '6710n',
      'id' => 3183,
    ),
    87 => 
    array (
      'name' => '6720c',
      'id' => 3108,
    ),
    88 => 
    array (
      'name' => '6730C',
      'id' => 3204,
    ),
    89 => 
    array (
      'name' => '6760S',
      'id' => 3151,
    ),
    90 => 
    array (
      'name' => '6788',
      'id' => 2186,
    ),
    91 => 
    array (
      'name' => '6788i',
      'id' => 2185,
    ),
    92 => 
    array (
      'name' => '6790',
      'id' => 3136,
    ),
    93 => 
    array (
      'name' => '6822',
      'id' => 3250,
    ),
  ),
  32 => 
  array (
    0 => 
    array (
      'name' => '6120CT',
      'id' => 1621,
    ),
    1 => 
    array (
      'name' => '931SH',
      'id' => 1626,
    ),
    2 => 
    array (
      'name' => '932SH',
      'id' => 1619,
    ),
    3 => 
    array (
      'name' => '933SH',
      'id' => 1617,
    ),
    4 => 
    array (
      'name' => '934SH',
      'id' => 1615,
    ),
    5 => 
    array (
      'name' => '935SH',
      'id' => 1614,
    ),
    6 => 
    array (
      'name' => '936SH',
      'id' => 1613,
    ),
    7 => 
    array (
      'name' => '940SH',
      'id' => 1611,
    ),
    8 => 
    array (
      'name' => '941SH',
      'id' => 1609,
    ),
    9 => 
    array (
      'name' => 'SH002',
      'id' => 1592,
    ),
    10 => 
    array (
      'name' => 'SH003',
      'id' => 1589,
    ),
    11 => 
    array (
      'name' => 'SH004',
      'id' => 1585,
    ),
    12 => 
    array (
      'name' => 'SH005',
      'id' => 1540,
    ),
    13 => 
    array (
      'name' => 'SH006',
      'id' => 1538,
    ),
    14 => 
    array (
      'name' => 'SH0181C',
      'id' => 1583,
    ),
    15 => 
    array (
      'name' => 'SH-01A',
      'id' => 1624,
    ),
    16 => 
    array (
      'name' => 'SH-01B',
      'id' => 1607,
    ),
    17 => 
    array (
      'name' => 'SH-03A',
      'id' => 1605,
    ),
    18 => 
    array (
      'name' => 'SH-04A',
      'id' => 1602,
    ),
    19 => 
    array (
      'name' => 'SH-04B',
      'id' => 1541,
    ),
    20 => 
    array (
      'name' => 'SH-05A',
      'id' => 1599,
    ),
    21 => 
    array (
      'name' => 'SH-06A',
      'id' => 1596,
    ),
    22 => 
    array (
      'name' => 'SH-07A',
      'id' => 1566,
    ),
    23 => 
    array (
      'name' => 'SH-08A',
      'id' => 1594,
    ),
    24 => 
    array (
      'name' => 'SH0902C',
      'id' => 1562,
    ),
    25 => 
    array (
      'name' => 'SH1810C',
      'id' => 1581,
    ),
    26 => 
    array (
      'name' => 'SH6010C',
      'id' => 1571,
    ),
    27 => 
    array (
      'name' => 'SH6018C',
      'id' => 1568,
    ),
    28 => 
    array (
      'name' => 'SH6110C',
      'id' => 1579,
    ),
    29 => 
    array (
      'name' => 'SH6118C',
      'id' => 1559,
    ),
    30 => 
    array (
      'name' => 'SH6220C',
      'id' => 1531,
    ),
    31 => 
    array (
      'name' => 'SH6228C',
      'id' => 1530,
    ),
    32 => 
    array (
      'name' => 'SH6230C',
      'id' => 1529,
    ),
    33 => 
    array (
      'name' => 'SH6310C',
      'id' => 1528,
    ),
    34 => 
    array (
      'name' => 'SH6318C',
      'id' => 1527,
    ),
    35 => 
    array (
      'name' => 'SH6320C',
      'id' => 1525,
    ),
    36 => 
    array (
      'name' => 'SH7110C',
      'id' => 1522,
    ),
    37 => 
    array (
      'name' => 'SH7118C',
      'id' => 1510,
    ),
    38 => 
    array (
      'name' => 'SH7120C',
      'id' => 1508,
    ),
    39 => 
    array (
      'name' => 'SH7128C',
      'id' => 1520,
    ),
    40 => 
    array (
      'name' => 'SH800M',
      'id' => 1518,
    ),
    41 => 
    array (
      'name' => 'SH8010C',
      'id' => 1627,
    ),
    42 => 
    array (
      'name' => 'SH801UC',
      'id' => 1516,
    ),
    43 => 
    array (
      'name' => 'SH802UC',
      'id' => 1514,
    ),
    44 => 
    array (
      'name' => 'SH805UC',
      'id' => 1512,
    ),
    45 => 
    array (
      'name' => 'SH80iUC',
      'id' => 1500,
    ),
    46 => 
    array (
      'name' => 'SH81iUC',
      'id' => 1499,
    ),
    47 => 
    array (
      'name' => 'SH9010C',
      'id' => 1634,
    ),
    48 => 
    array (
      'name' => 'SH9020C',
      'id' => 1636,
    ),
    49 => 
    array (
      'name' => 'SH906i',
      'id' => 1630,
    ),
    50 => 
    array (
      'name' => 'SH9110C',
      'id' => 1576,
    ),
    51 => 
    array (
      'name' => 'SH9120c',
      'id' => 1574,
    ),
    52 => 
    array (
      'name' => 'SH9130C',
      'id' => 1557,
    ),
    53 => 
    array (
      'name' => 'SH9210C',
      'id' => 1506,
    ),
    54 => 
    array (
      'name' => 'SH9220C',
      'id' => 1504,
    ),
    55 => 
    array (
      'name' => 'SH9230C',
      'id' => 1502,
    ),
    56 => 
    array (
      'name' => 'T923',
      'id' => 1572,
    ),
    57 => 
    array (
      'name' => 'W62SH',
      'id' => 1563,
    ),
  ),
  116 => 
  array (
    0 => 
    array (
      'name' => '6788i',
      'id' => 3160,
    ),
    1 => 
    array (
      'name' => 'N70',
      'id' => 3252,
    ),
    2 => 
    array (
      'name' => 'N71',
      'id' => 3272,
    ),
    3 => 
    array (
      'name' => 'N72',
      'id' => 3273,
    ),
    4 => 
    array (
      'name' => 'N73',
      'id' => 3124,
    ),
    5 => 
    array (
      'name' => 'N75',
      'id' => 3278,
    ),
    6 => 
    array (
      'name' => 'n76',
      'id' => 3040,
    ),
    7 => 
    array (
      'name' => 'N77',
      'id' => 3125,
    ),
    8 => 
    array (
      'name' => 'N78',
      'id' => 3157,
    ),
    9 => 
    array (
      'name' => 'N79',
      'id' => 3158,
    ),
    10 => 
    array (
      'name' => 'N80',
      'id' => 3128,
    ),
    11 => 
    array (
      'name' => 'N800',
      'id' => 3146,
    ),
    12 => 
    array (
      'name' => 'n8-00',
      'id' => 2126,
    ),
    13 => 
    array (
      'name' => 'n81',
      'id' => 2127,
    ),
    14 => 
    array (
      'name' => 'n82',
      'id' => 2128,
    ),
    15 => 
    array (
      'name' => 'N83',
      'id' => 3129,
    ),
    16 => 
    array (
      'name' => 'N85',
      'id' => 3172,
    ),
    17 => 
    array (
      'name' => 'n86',
      'id' => 2129,
    ),
    18 => 
    array (
      'name' => 'N90',
      'id' => 3130,
    ),
    19 => 
    array (
      'name' => 'N900',
      'id' => 3175,
    ),
    20 => 
    array (
      'name' => 'N91',
      'id' => 3274,
    ),
    21 => 
    array (
      'name' => 'N91 8GB',
      'id' => 3275,
    ),
    22 => 
    array (
      'name' => 'N92',
      'id' => 3147,
    ),
    23 => 
    array (
      'name' => 'N93',
      'id' => 3116,
    ),
    24 => 
    array (
      'name' => 'N93i',
      'id' => 3181,
    ),
    25 => 
    array (
      'name' => 'N93s',
      'id' => 3117,
    ),
    26 => 
    array (
      'name' => 'N95',
      'id' => 3180,
    ),
    27 => 
    array (
      'name' => 'N95 8GB',
      'id' => 3159,
    ),
    28 => 
    array (
      'name' => 'N96',
      'id' => 3179,
    ),
    29 => 
    array (
      'name' => 'n97',
      'id' => 2130,
    ),
    30 => 
    array (
      'name' => 'n97i',
      'id' => 2134,
    ),
    31 => 
    array (
      'name' => 'n97mini',
      'id' => 2132,
    ),
    32 => 
    array (
      'name' => 'N99',
      'id' => 3198,
    ),
    33 => 
    array (
      'name' => 'N-Gage QD',
      'id' => 3192,
    ),
  ),
  31 => 
  array (
    0 => 
    array (
      'name' => '700tv',
      'id' => 1446,
    ),
    1 => 
    array (
      'name' => '710+',
      'id' => 1443,
    ),
    2 => 
    array (
      'name' => 'A3288',
      'id' => 1392,
    ),
    3 => 
    array (
      'name' => 'A6188(Magic)',
      'id' => 1389,
    ),
    4 => 
    array (
      'name' => 'A6288(Hero)',
      'id' => 1369,
    ),
    5 => 
    array (
      'name' => 'A6388',
      'id' => 1360,
    ),
    6 => 
    array (
      'name' => 'A8188',
      'id' => 1365,
    ),
    7 => 
    array (
      'name' => 'C730',
      'id' => 1436,
    ),
    8 => 
    array (
      'name' => 'C730w',
      'id' => 1434,
    ),
    9 => 
    array (
      'name' => 'C750',
      'id' => 1412,
    ),
    10 => 
    array (
      'name' => 'D600',
      'id' => 1441,
    ),
    11 => 
    array (
      'name' => 'D802',
      'id' => 1438,
    ),
    12 => 
    array (
      'name' => 'D805',
      'id' => 1424,
    ),
    13 => 
    array (
      'name' => 'D810',
      'id' => 1427,
    ),
    14 => 
    array (
      'name' => 'E616',
      'id' => 1433,
    ),
    15 => 
    array (
      'name' => 'E806c',
      'id' => 1437,
    ),
    16 => 
    array (
      'name' => 'F3188',
      'id' => 1361,
    ),
    17 => 
    array (
      'name' => 'i101C',
      'id' => 1421,
    ),
    18 => 
    array (
      'name' => 'i201C',
      'id' => 1418,
    ),
    19 => 
    array (
      'name' => 'P3450',
      'id' => 1432,
    ),
    20 => 
    array (
      'name' => 'P4550',
      'id' => 1428,
    ),
    21 => 
    array (
      'name' => 'P5500',
      'id' => 1423,
    ),
    22 => 
    array (
      'name' => 'P6500',
      'id' => 1445,
    ),
    23 => 
    array (
      'name' => 'P660',
      'id' => 1408,
    ),
    24 => 
    array (
      'name' => 'P860',
      'id' => 1409,
    ),
    25 => 
    array (
      'name' => 'P863',
      'id' => 1399,
    ),
    26 => 
    array (
      'name' => 'S1',
      'id' => 1430,
    ),
    27 => 
    array (
      'name' => 'S500',
      'id' => 1406,
    ),
    28 => 
    array (
      'name' => 'S505',
      'id' => 1396,
    ),
    29 => 
    array (
      'name' => 'S600',
      'id' => 1403,
    ),
    30 => 
    array (
      'name' => 'S610',
      'id' => 1387,
    ),
    31 => 
    array (
      'name' => 'S700',
      'id' => 1397,
    ),
    32 => 
    array (
      'name' => 'S730',
      'id' => 1444,
    ),
    33 => 
    array (
      'name' => 'S900',
      'id' => 1402,
    ),
    34 => 
    array (
      'name' => 'S900C',
      'id' => 1384,
    ),
    35 => 
    array (
      'name' => 'S910',
      'id' => 1383,
    ),
    36 => 
    array (
      'name' => 'S910W',
      'id' => 1363,
    ),
    37 => 
    array (
      'name' => 'T3238',
      'id' => 1414,
    ),
    38 => 
    array (
      'name' => 'T3333',
      'id' => 1358,
    ),
    39 => 
    array (
      'name' => 'T4288',
      'id' => 1371,
    ),
    40 => 
    array (
      'name' => 'T5388',
      'id' => 1382,
    ),
    41 => 
    array (
      'name' => 'T5388w',
      'id' => 1368,
    ),
    42 => 
    array (
      'name' => 'T5399(Tachi)',
      'id' => 1379,
    ),
    43 => 
    array (
      'name' => 'T8388',
      'id' => 1377,
    ),
    44 => 
    array (
      'name' => 'T8588',
      'id' => 1356,
    ),
    45 => 
    array (
      'name' => 'Touch HD',
      'id' => 1375,
    ),
    46 => 
    array (
      'name' => 'Touch Pro',
      'id' => 1373,
    ),
    47 => 
    array (
      'name' => 'U1000',
      'id' => 1440,
    ),
  ),
  130 => 
  array (
    0 => 
    array (
      'name' => '7020',
      'id' => 3025,
    ),
    1 => 
    array (
      'name' => '7070',
      'id' => 3016,
    ),
    2 => 
    array (
      'name' => '7088 CDMA',
      'id' => 2183,
    ),
    3 => 
    array (
      'name' => '7100s',
      'id' => 3074,
    ),
    4 => 
    array (
      'name' => '7200',
      'id' => 3067,
    ),
    5 => 
    array (
      'name' => '7210c',
      'id' => 3055,
    ),
    6 => 
    array (
      'name' => '7210s',
      'id' => 3071,
    ),
    7 => 
    array (
      'name' => '7212c',
      'id' => 3072,
    ),
    8 => 
    array (
      'name' => '7230',
      'id' => 3008,
    ),
    9 => 
    array (
      'name' => '7260',
      'id' => 3101,
    ),
    10 => 
    array (
      'name' => '7270',
      'id' => 3053,
    ),
    11 => 
    array (
      'name' => '7310c',
      'id' => 3073,
    ),
    12 => 
    array (
      'name' => '7310s',
      'id' => 3056,
    ),
    13 => 
    array (
      'name' => '7360',
      'id' => 3113,
    ),
    14 => 
    array (
      'name' => '7360',
      'id' => 3103,
    ),
    15 => 
    array (
      'name' => '7370',
      'id' => 3039,
    ),
    16 => 
    array (
      'name' => '7373',
      'id' => 3017,
    ),
    17 => 
    array (
      'name' => '7390',
      'id' => 3144,
    ),
    18 => 
    array (
      'name' => '7500Prism',
      'id' => 3018,
    ),
    19 => 
    array (
      'name' => '7510a',
      'id' => 2180,
    ),
    20 => 
    array (
      'name' => '7510s',
      'id' => 3277,
    ),
    21 => 
    array (
      'name' => '7600',
      'id' => 3269,
    ),
    22 => 
    array (
      'name' => '7610',
      'id' => 3270,
    ),
    23 => 
    array (
      'name' => '7610a',
      'id' => 2179,
    ),
    24 => 
    array (
      'name' => '7610c',
      'id' => 3075,
    ),
    25 => 
    array (
      'name' => '7610s',
      'id' => 3059,
    ),
    26 => 
    array (
      'name' => '7612s',
      'id' => 2177,
    ),
    27 => 
    array (
      'name' => '770',
      'id' => 3134,
    ),
    28 => 
    array (
      'name' => '7705',
      'id' => 3068,
    ),
    29 => 
    array (
      'name' => '7710',
      'id' => 3135,
    ),
    30 => 
    array (
      'name' => '7900 Prism',
      'id' => 3156,
    ),
  ),
  143 => 
  array (
    0 => 
    array (
      'name' => '7110C',
      'id' => 2297,
    ),
    1 => 
    array (
      'name' => '7118C',
      'id' => 2298,
    ),
    2 => 
    array (
      'name' => '7120C',
      'id' => 2299,
    ),
    3 => 
    array (
      'name' => '7128C',
      'id' => 2300,
    ),
  ),
  144 => 
  array (
    0 => 
    array (
      'name' => '8010C',
      'id' => 2301,
    ),
  ),
  139 => 
  array (
    0 => 
    array (
      'name' => '805UC',
      'id' => 2286,
    ),
    1 => 
    array (
      'name' => 'SH0902C',
      'id' => 2289,
    ),
    2 => 
    array (
      'name' => 'SH800M',
      'id' => 2285,
    ),
    3 => 
    array (
      'name' => 'SH801UC',
      'id' => 2287,
    ),
    4 => 
    array (
      'name' => 'SH802UC',
      'id' => 2288,
    ),
    5 => 
    array (
      'name' => 'SH80iUC',
      'id' => 2283,
    ),
    6 => 
    array (
      'name' => 'SH81iUC',
      'id' => 2284,
    ),
  ),
  129 => 
  array (
    0 => 
    array (
      'name' => '8208 CDMA',
      'id' => 2175,
    ),
    1 => 
    array (
      'name' => '8600',
      'id' => 3145,
    ),
    2 => 
    array (
      'name' => '8800',
      'id' => 3169,
    ),
    3 => 
    array (
      'name' => '8800 Carbon Arte',
      'id' => 3080,
    ),
    4 => 
    array (
      'name' => '8800 Gold Arte',
      'id' => 3081,
    ),
    5 => 
    array (
      'name' => '8800 Sapphire Arte',
      'id' => 3079,
    ),
    6 => 
    array (
      'name' => '8800 Sirocco',
      'id' => 3171,
    ),
    7 => 
    array (
      'name' => '8800Arte',
      'id' => 3077,
    ),
    8 => 
    array (
      'name' => '8860',
      'id' => 3170,
    ),
    9 => 
    array (
      'name' => '8900',
      'id' => 3078,
    ),
  ),
  6 => 
  array (
    0 => 
    array (
      'name' => '830/950/MP810/MP600/MP510/MP530/ip3300/ix4000',
      'id' => 2860,
    ),
    1 => 
    array (
      'name' => 'BJF850/F860/F870/F870PD/S800/i905D',
      'id' => 2862,
    ),
    2 => 
    array (
      'name' => 'Canon BJC-8200',
      'id' => 2861,
    ),
    3 => 
    array (
      'name' => 'ip1880',
      'id' => 2940,
    ),
    4 => 
    array (
      'name' => 'ip1980',
      'id' => 2942,
    ),
    5 => 
    array (
      'name' => 'ip2580',
      'id' => 2941,
    ),
    6 => 
    array (
      'name' => 'ip4200/4200Refurbished/5200/5200R/ix5000/MP500/800',
      'id' => 2859,
    ),
    7 => 
    array (
      'name' => 'ip5200R/6600D/MP950/Pro9000',
      'id' => 2858,
    ),
    8 => 
    array (
      'name' => 'MP638/iP4680/4760/3680',
      'id' => 2911,
    ),
    9 => 
    array (
      'name' => 'PIXMA iP5000/4000/3000/i6500/i6100',
      'id' => 2929,
    ),
    10 => 
    array (
      'name' => 'PIXMA IX 5000 A3',
      'id' => 94,
    ),
    11 => 
    array (
      'name' => 'PIXMA Pro 9000 A3+',
      'id' => 91,
    ),
    12 => 
    array (
      'name' => 'S800/S820/S820D/S830',
      'id' => 2863,
    ),
    13 => 
    array (
      'name' => '�ڲ� PIXMA iP1180',
      'id' => 87,
    ),
    14 => 
    array (
      'name' => '�ڲ� PIXMA iP3680',
      'id' => 90,
    ),
    15 => 
    array (
      'name' => '�ڲ� PIXMA iP4760',
      'id' => 92,
    ),
    16 => 
    array (
      'name' => '�ڲ� PIXMA IX 4000 A3+',
      'id' => 89,
    ),
    17 => 
    array (
      'name' => '�ڲ�PIXMA iP2780',
      'id' => 88,
    ),
  ),
  141 => 
  array (
    0 => 
    array (
      'name' => '9010C',
      'id' => 2302,
    ),
    1 => 
    array (
      'name' => '9020C',
      'id' => 2303,
    ),
    2 => 
    array (
      'name' => '9110c',
      'id' => 2304,
    ),
    3 => 
    array (
      'name' => '9120C',
      'id' => 2305,
    ),
    4 => 
    array (
      'name' => '9130C',
      'id' => 2306,
    ),
    5 => 
    array (
      'name' => '9210C',
      'id' => 2307,
    ),
    6 => 
    array (
      'name' => '9220C',
      'id' => 2308,
    ),
    7 => 
    array (
      'name' => '9230C',
      'id' => 2309,
    ),
  ),
  304 => 
  array (
    0 => 
    array (
      'name' => '9300',
      'id' => 3126,
    ),
    1 => 
    array (
      'name' => '9300i',
      'id' => 3118,
    ),
    2 => 
    array (
      'name' => '9500',
      'id' => 3133,
    ),
  ),
  50 => 
  array (
    0 => 
    array (
      'name' => 'A100',
      'id' => 560,
    ),
    1 => 
    array (
      'name' => 'AV105',
      'id' => 540,
    ),
    2 => 
    array (
      'name' => 'AX205',
      'id' => 539,
    ),
    3 => 
    array (
      'name' => 'F100fd',
      'id' => 578,
    ),
    4 => 
    array (
      'name' => 'F200EXR',
      'id' => 558,
    ),
    5 => 
    array (
      'name' => 'F60fd',
      'id' => 562,
    ),
    6 => 
    array (
      'name' => 'F75EXR',
      'id' => 548,
    ),
    7 => 
    array (
      'name' => 'F85EXR',
      'id' => 538,
    ),
    8 => 
    array (
      'name' => 'HS11',
      'id' => 532,
    ),
    9 => 
    array (
      'name' => 'J10',
      'id' => 577,
    ),
    10 => 
    array (
      'name' => 'J100',
      'id' => 565,
    ),
    11 => 
    array (
      'name' => 'J110W',
      'id' => 566,
    ),
    12 => 
    array (
      'name' => 'J12',
      'id' => 552,
    ),
    13 => 
    array (
      'name' => 'J120',
      'id' => 563,
    ),
    14 => 
    array (
      'name' => 'J150W',
      'id' => 567,
    ),
    15 => 
    array (
      'name' => 'J15fd',
      'id' => 564,
    ),
    16 => 
    array (
      'name' => 'J25',
      'id' => 556,
    ),
    17 => 
    array (
      'name' => 'J250',
      'id' => 557,
    ),
    18 => 
    array (
      'name' => 'J26',
      'id' => 547,
    ),
    19 => 
    array (
      'name' => 'J30',
      'id' => 541,
    ),
    20 => 
    array (
      'name' => 'J35',
      'id' => 546,
    ),
    21 => 
    array (
      'name' => 'J50',
      'id' => 576,
    ),
    22 => 
    array (
      'name' => 'JV155',
      'id' => 534,
    ),
    23 => 
    array (
      'name' => 'JX255',
      'id' => 533,
    ),
    24 => 
    array (
      'name' => 'JZ305',
      'id' => 530,
    ),
    25 => 
    array (
      'name' => 'JZ505',
      'id' => 531,
    ),
    26 => 
    array (
      'name' => 'S1000fd',
      'id' => 574,
    ),
    27 => 
    array (
      'name' => 'S100FS',
      'id' => 575,
    ),
    28 => 
    array (
      'name' => 'S1500',
      'id' => 553,
    ),
    29 => 
    array (
      'name' => 'S1770',
      'id' => 535,
    ),
    30 => 
    array (
      'name' => 'S1880',
      'id' => 536,
    ),
    31 => 
    array (
      'name' => 'S2000HD',
      'id' => 568,
    ),
    32 => 
    array (
      'name' => 'S205EXR',
      'id' => 545,
    ),
    33 => 
    array (
      'name' => 'S2600HD',
      'id' => 537,
    ),
    34 => 
    array (
      'name' => 'S8100fd',
      'id' => 573,
    ),
    35 => 
    array (
      'name' => 'XP11',
      'id' => 529,
    ),
    36 => 
    array (
      'name' => 'Z200fd',
      'id' => 569,
    ),
    37 => 
    array (
      'name' => 'Z20fd',
      'id' => 572,
    ),
    38 => 
    array (
      'name' => 'Z250fd',
      'id' => 561,
    ),
    39 => 
    array (
      'name' => 'Z30',
      'id' => 555,
    ),
    40 => 
    array (
      'name' => 'Z300',
      'id' => 543,
    ),
    41 => 
    array (
      'name' => 'Z31',
      'id' => 544,
    ),
    42 => 
    array (
      'name' => 'Z33WP',
      'id' => 554,
    ),
    43 => 
    array (
      'name' => 'Z707EXR',
      'id' => 527,
    ),
    44 => 
    array (
      'name' => 'Z71',
      'id' => 528,
    ),
  ),
  38 => 
  array (
    0 => 
    array (
      'name' => 'A1000 IS',
      'id' => 234,
    ),
    1 => 
    array (
      'name' => 'A1100 IS',
      'id' => 219,
    ),
    2 => 
    array (
      'name' => 'A2000 IS',
      'id' => 233,
    ),
    3 => 
    array (
      'name' => 'A2100 IS',
      'id' => 220,
    ),
    4 => 
    array (
      'name' => 'A3000',
      'id' => 203,
    ),
    5 => 
    array (
      'name' => 'A3100',
      'id' => 204,
    ),
    6 => 
    array (
      'name' => 'A470',
      'id' => 240,
    ),
    7 => 
    array (
      'name' => 'A480',
      'id' => 223,
    ),
    8 => 
    array (
      'name' => 'A490',
      'id' => 195,
    ),
    9 => 
    array (
      'name' => 'A495',
      'id' => 197,
    ),
    10 => 
    array (
      'name' => 'A580',
      'id' => 241,
    ),
    11 => 
    array (
      'name' => 'A590 IS',
      'id' => 242,
    ),
    12 => 
    array (
      'name' => 'D10',
      'id' => 221,
    ),
    13 => 
    array (
      'name' => 'E1',
      'id' => 232,
    ),
    14 => 
    array (
      'name' => 'G10',
      'id' => 229,
    ),
    15 => 
    array (
      'name' => 'G11',
      'id' => 210,
    ),
    16 => 
    array (
      'name' => 'IXUS100 IS',
      'id' => 216,
    ),
    17 => 
    array (
      'name' => 'IXUS105 IS',
      'id' => 199,
    ),
    18 => 
    array (
      'name' => 'IXUS110 IS',
      'id' => 217,
    ),
    19 => 
    array (
      'name' => 'IXUS120 IS',
      'id' => 213,
    ),
    20 => 
    array (
      'name' => 'IXUS130 IS',
      'id' => 202,
    ),
    21 => 
    array (
      'name' => 'IXUS200 IS',
      'id' => 212,
    ),
    22 => 
    array (
      'name' => 'IXUS210 IS',
      'id' => 2821,
    ),
    23 => 
    array (
      'name' => 'IXUS300 HS',
      'id' => 196,
    ),
    24 => 
    array (
      'name' => 'IXUS80 IS',
      'id' => 243,
    ),
    25 => 
    array (
      'name' => 'IXUS85 IS',
      'id' => 239,
    ),
    26 => 
    array (
      'name' => 'IXUS870 IS',
      'id' => 224,
    ),
    27 => 
    array (
      'name' => 'IXUS90 IS',
      'id' => 237,
    ),
    28 => 
    array (
      'name' => 'IXUS95 IS',
      'id' => 215,
    ),
    29 => 
    array (
      'name' => 'IXUS970 IS',
      'id' => 238,
    ),
    30 => 
    array (
      'name' => 'IXUS980 IS',
      'id' => 225,
    ),
    31 => 
    array (
      'name' => 'IXUS990 IS',
      'id' => 218,
    ),
    32 => 
    array (
      'name' => 'S90',
      'id' => 209,
    ),
    33 => 
    array (
      'name' => 'SX1 IS',
      'id' => 228,
    ),
    34 => 
    array (
      'name' => 'SX10 IS',
      'id' => 227,
    ),
    35 => 
    array (
      'name' => 'SX110 IS',
      'id' => 235,
    ),
    36 => 
    array (
      'name' => 'SX120 IS',
      'id' => 208,
    ),
    37 => 
    array (
      'name' => 'SX20 IS',
      'id' => 211,
    ),
    38 => 
    array (
      'name' => 'SX200 IS',
      'id' => 222,
    ),
    39 => 
    array (
      'name' => 'SX210 IS',
      'id' => 198,
    ),
  ),
  165 => 
  array (
    0 => 
    array (
      'name' => 'A1200',
      'id' => 3299,
    ),
    1 => 
    array (
      'name' => 'A1200E',
      'id' => 3310,
    ),
    2 => 
    array (
      'name' => 'A1200i',
      'id' => 3311,
    ),
    3 => 
    array (
      'name' => 'A1200R',
      'id' => 3300,
    ),
    4 => 
    array (
      'name' => 'A1208',
      'id' => 3301,
    ),
    5 => 
    array (
      'name' => 'A1210',
      'id' => 3324,
    ),
    6 => 
    array (
      'name' => 'A1260',
      'id' => 3312,
    ),
    7 => 
    array (
      'name' => 'A1600',
      'id' => 3298,
    ),
    8 => 
    array (
      'name' => 'A1680',
      'id' => 3313,
    ),
    9 => 
    array (
      'name' => 'A1800',
      'id' => 3295,
    ),
    10 => 
    array (
      'name' => 'A1890',
      'id' => 3296,
    ),
    11 => 
    array (
      'name' => 'A3000',
      'id' => 3325,
    ),
    12 => 
    array (
      'name' => 'A3100',
      'id' => 3326,
    ),
    13 => 
    array (
      'name' => 'A3300C',
      'id' => 3297,
    ),
    14 => 
    array (
      'name' => 'A732',
      'id' => 3302,
    ),
    15 => 
    array (
      'name' => 'A810',
      'id' => 3303,
    ),
    16 => 
    array (
      'name' => 'A855',
      'id' => 3327,
    ),
    17 => 
    array (
      'name' => 'AURA R1',
      'id' => 3546,
    ),
  ),
  28 => 
  array (
    0 => 
    array (
      'name' => 'A1200e',
      'id' => 1071,
    ),
    1 => 
    array (
      'name' => 'A1208',
      'id' => 1053,
    ),
    2 => 
    array (
      'name' => 'a1210',
      'id' => 999,
    ),
    3 => 
    array (
      'name' => 'A1600',
      'id' => 1019,
    ),
    4 => 
    array (
      'name' => 'a1680',
      'id' => 890,
    ),
    5 => 
    array (
      'name' => 'a1800',
      'id' => 1020,
    ),
    6 => 
    array (
      'name' => 'a1890',
      'id' => 998,
    ),
    7 => 
    array (
      'name' => 'a3000',
      'id' => 996,
    ),
    8 => 
    array (
      'name' => 'a3100',
      'id' => 990,
    ),
    9 => 
    array (
      'name' => 'a3300c',
      'id' => 988,
    ),
    10 => 
    array (
      'name' => 'a45',
      'id' => 987,
    ),
    11 => 
    array (
      'name' => 'a4500',
      'id' => 986,
    ),
    12 => 
    array (
      'name' => 'a810',
      'id' => 1024,
    ),
    13 => 
    array (
      'name' => 'AuRA R1',
      'id' => 1004,
    ),
    14 => 
    array (
      'name' => 'Calgary',
      'id' => 985,
    ),
    15 => 
    array (
      'name' => 'Crash',
      'id' => 984,
    ),
    16 => 
    array (
      'name' => 'Devour',
      'id' => 911,
    ),
    17 => 
    array (
      'name' => 'Droid X',
      'id' => 888,
    ),
    18 => 
    array (
      'name' => 'E11',
      'id' => 982,
    ),
    19 => 
    array (
      'name' => 'E8',
      'id' => 1029,
    ),
    20 => 
    array (
      'name' => 'EM30',
      'id' => 1011,
    ),
    21 => 
    array (
      'name' => 'EM30',
      'id' => 885,
    ),
    22 => 
    array (
      'name' => 'EM325',
      'id' => 1050,
    ),
    23 => 
    array (
      'name' => 'EM326G',
      'id' => 981,
    ),
    24 => 
    array (
      'name' => 'EM330',
      'id' => 1006,
    ),
    25 => 
    array (
      'name' => 'EM35',
      'id' => 920,
    ),
    26 => 
    array (
      'name' => 'I1',
      'id' => 909,
    ),
    27 => 
    array (
      'name' => 'I335',
      'id' => 1044,
    ),
    28 => 
    array (
      'name' => 'I410',
      'id' => 975,
    ),
    29 => 
    array (
      'name' => 'I465',
      'id' => 973,
    ),
    30 => 
    array (
      'name' => 'I580',
      'id' => 971,
    ),
    31 => 
    array (
      'name' => 'I680',
      'id' => 908,
    ),
    32 => 
    array (
      'name' => 'I856',
      'id' => 969,
    ),
    33 => 
    array (
      'name' => 'I9',
      'id' => 965,
    ),
    34 => 
    array (
      'name' => 'Klassic',
      'id' => 964,
    ),
    35 => 
    array (
      'name' => 'KRZR K3',
      'id' => 1027,
    ),
    36 => 
    array (
      'name' => 'l72',
      'id' => 1076,
    ),
    37 => 
    array (
      'name' => 'L9',
      'id' => 1332,
    ),
    38 => 
    array (
      'name' => 'm990',
      'id' => 1017,
    ),
    39 => 
    array (
      'name' => 'Marco',
      'id' => 1067,
    ),
    40 => 
    array (
      'name' => 'MB220',
      'id' => 962,
    ),
    41 => 
    array (
      'name' => 'MB810',
      'id' => 906,
    ),
    42 => 
    array (
      'name' => 'MC3504',
      'id' => 1015,
    ),
    43 => 
    array (
      'name' => 'MC5574',
      'id' => 959,
    ),
    44 => 
    array (
      'name' => 'MC5590',
      'id' => 957,
    ),
    45 => 
    array (
      'name' => 'me501',
      'id' => 894,
    ),
    46 => 
    array (
      'name' => 'me502',
      'id' => 905,
    ),
    47 => 
    array (
      'name' => 'me511',
      'id' => 887,
    ),
    48 => 
    array (
      'name' => 'me600',
      'id' => 897,
    ),
    49 => 
    array (
      'name' => 'MS900',
      'id' => 1085,
    ),
    50 => 
    array (
      'name' => 'MT710',
      'id' => 912,
    ),
    51 => 
    array (
      'name' => 'mt720',
      'id' => 893,
    ),
    52 => 
    array (
      'name' => 'mt810',
      'id' => 903,
    ),
    53 => 
    array (
      'name' => 'Pebl U3',
      'id' => 1331,
    ),
    54 => 
    array (
      'name' => 'Q11',
      'id' => 1042,
    ),
    55 => 
    array (
      'name' => 'Q8',
      'id' => 1052,
    ),
    56 => 
    array (
      'name' => 'Q9c',
      'id' => 1051,
    ),
    57 => 
    array (
      'name' => 'Q9m',
      'id' => 1065,
    ),
    58 => 
    array (
      'name' => 'QA1 Karma',
      'id' => 956,
    ),
    59 => 
    array (
      'name' => 'QA30',
      'id' => 1002,
    ),
    60 => 
    array (
      'name' => 'QA4',
      'id' => 954,
    ),
    61 => 
    array (
      'name' => 'quanti',
      'id' => 952,
    ),
    62 => 
    array (
      'name' => 'ROKR W5',
      'id' => 1040,
    ),
    63 => 
    array (
      'name' => 'sholes',
      'id' => 951,
    ),
    64 => 
    array (
      'name' => 'U9',
      'id' => 1026,
    ),
    65 => 
    array (
      'name' => 'V10',
      'id' => 916,
    ),
    66 => 
    array (
      'name' => 'v1100',
      'id' => 1330,
    ),
    67 => 
    array (
      'name' => 'v3a',
      'id' => 1329,
    ),
    68 => 
    array (
      'name' => 'v3a',
      'id' => 1326,
    ),
    69 => 
    array (
      'name' => 'V6',
      'id' => 1069,
    ),
    70 => 
    array (
      'name' => 'v8',
      'id' => 1062,
    ),
    71 => 
    array (
      'name' => 'v9',
      'id' => 1323,
    ),
    72 => 
    array (
      'name' => 'v9m',
      'id' => 1320,
    ),
    73 => 
    array (
      'name' => 'va76r',
      'id' => 948,
    ),
    74 => 
    array (
      'name' => 'VE20',
      'id' => 1013,
    ),
    75 => 
    array (
      'name' => 'VE240',
      'id' => 1039,
    ),
    76 => 
    array (
      'name' => 've465',
      'id' => 946,
    ),
    77 => 
    array (
      'name' => 'VE538',
      'id' => 1008,
    ),
    78 => 
    array (
      'name' => 'VE66',
      'id' => 919,
    ),
    79 => 
    array (
      'name' => 'VE70',
      'id' => 1037,
    ),
    80 => 
    array (
      'name' => 'VE75',
      'id' => 1014,
    ),
    81 => 
    array (
      'name' => 'vu30',
      'id' => 943,
    ),
    82 => 
    array (
      'name' => 'w156',
      'id' => 1316,
    ),
    83 => 
    array (
      'name' => 'w161',
      'id' => 1313,
    ),
    84 => 
    array (
      'name' => 'w165',
      'id' => 940,
    ),
    85 => 
    array (
      'name' => 'w175',
      'id' => 1308,
    ),
    86 => 
    array (
      'name' => 'w180',
      'id' => 1303,
    ),
    87 => 
    array (
      'name' => 'w181',
      'id' => 1083,
    ),
    88 => 
    array (
      'name' => 'w205',
      'id' => 1081,
    ),
    89 => 
    array (
      'name' => 'w206',
      'id' => 1297,
    ),
    90 => 
    array (
      'name' => 'W212',
      'id' => 1056,
    ),
    91 => 
    array (
      'name' => 'w213',
      'id' => 1292,
    ),
    92 => 
    array (
      'name' => 'w216',
      'id' => 1016,
    ),
    93 => 
    array (
      'name' => 'W218',
      'id' => 1072,
    ),
    94 => 
    array (
      'name' => 'w230',
      'id' => 1025,
    ),
    95 => 
    array (
      'name' => 'w231',
      'id' => 1000,
    ),
    96 => 
    array (
      'name' => 'w355',
      'id' => 1087,
    ),
    97 => 
    array (
      'name' => 'w360',
      'id' => 1079,
    ),
    98 => 
    array (
      'name' => 'W362',
      'id' => 1028,
    ),
    99 => 
    array (
      'name' => 'w371',
      'id' => 1058,
    ),
    100 => 
    array (
      'name' => 'w380',
      'id' => 1088,
    ),
    101 => 
    array (
      'name' => 'w385',
      'id' => 1060,
    ),
    102 => 
    array (
      'name' => 'w388',
      'id' => 1009,
    ),
    103 => 
    array (
      'name' => 'w395',
      'id' => 1089,
    ),
    104 => 
    array (
      'name' => 'w396',
      'id' => 1036,
    ),
    105 => 
    array (
      'name' => 'w490',
      'id' => 1034,
    ),
    106 => 
    array (
      'name' => 'w510',
      'id' => 1078,
    ),
    107 => 
    array (
      'name' => 'w530',
      'id' => 917,
    ),
    108 => 
    array (
      'name' => 'w562',
      'id' => 938,
    ),
    109 => 
    array (
      'name' => 'w6',
      'id' => 1033,
    ),
    110 => 
    array (
      'name' => 'w7',
      'id' => 937,
    ),
    111 => 
    array (
      'name' => 'w766',
      'id' => 935,
    ),
    112 => 
    array (
      'name' => 'wx160',
      'id' => 934,
    ),
    113 => 
    array (
      'name' => 'wx180',
      'id' => 932,
    ),
    114 => 
    array (
      'name' => 'wx260',
      'id' => 891,
    ),
    115 => 
    array (
      'name' => 'wx270',
      'id' => 889,
    ),
    116 => 
    array (
      'name' => 'wx280',
      'id' => 930,
    ),
    117 => 
    array (
      'name' => 'wx390',
      'id' => 928,
    ),
    118 => 
    array (
      'name' => 'wx395',
      'id' => 927,
    ),
    119 => 
    array (
      'name' => 'XT3',
      'id' => 886,
    ),
    120 => 
    array (
      'name' => 'XT701',
      'id' => 925,
    ),
    121 => 
    array (
      'name' => 'xt702',
      'id' => 892,
    ),
    122 => 
    array (
      'name' => 'xt711',
      'id' => 901,
    ),
    123 => 
    array (
      'name' => 'xt720',
      'id' => 900,
    ),
    124 => 
    array (
      'name' => 'XT800',
      'id' => 923,
    ),
    125 => 
    array (
      'name' => 'z10',
      'id' => 1018,
    ),
    126 => 
    array (
      'name' => 'z12',
      'id' => 1032,
    ),
    127 => 
    array (
      'name' => 'z6',
      'id' => 1073,
    ),
    128 => 
    array (
      'name' => 'Z6m',
      'id' => 1090,
    ),
    129 => 
    array (
      'name' => 'Z6w',
      'id' => 922,
    ),
    130 => 
    array (
      'name' => 'Z8',
      'id' => 1055,
    ),
    131 => 
    array (
      'name' => 'Z9',
      'id' => 1031,
    ),
    132 => 
    array (
      'name' => 'Zante',
      'id' => 1288,
    ),
    133 => 
    array (
      'name' => 'ZN200',
      'id' => 1012,
    ),
    134 => 
    array (
      'name' => 'ZN300',
      'id' => 915,
    ),
    135 => 
    array (
      'name' => 'ZN4',
      'id' => 913,
    ),
    136 => 
    array (
      'name' => 'ZN5',
      'id' => 1010,
    ),
    137 => 
    array (
      'name' => 'ZN50',
      'id' => 921,
    ),
  ),
  123 => 
  array (
    0 => 
    array (
      'name' => 'a201',
      'id' => 2140,
    ),
    1 => 
    array (
      'name' => 'a310',
      'id' => 2211,
    ),
    2 => 
    array (
      'name' => 'a312',
      'id' => 2141,
    ),
    3 => 
    array (
      'name' => 'a330',
      'id' => 2214,
    ),
    4 => 
    array (
      'name' => 'a332',
      'id' => 2143,
    ),
    5 => 
    array (
      'name' => 'a350',
      'id' => 2359,
    ),
    6 => 
    array (
      'name' => 'a365',
      'id' => 2368,
    ),
    7 => 
    array (
      'name' => 'a510',
      'id' => 2345,
    ),
    8 => 
    array (
      'name' => 'a550',
      'id' => 2339,
    ),
    9 => 
    array (
      'name' => 'a550',
      'id' => 2340,
    ),
    10 => 
    array (
      'name' => 'a589',
      'id' => 2187,
    ),
    11 => 
    array (
      'name' => 'a600',
      'id' => 2346,
    ),
    12 => 
    array (
      'name' => 'a650',
      'id' => 2209,
    ),
    13 => 
    array (
      'name' => 'a689',
      'id' => 2255,
    ),
    14 => 
    array (
      'name' => 'a720',
      'id' => 2167,
    ),
    15 => 
    array (
      'name' => 'a730',
      'id' => 2144,
    ),
    16 => 
    array (
      'name' => 'a900',
      'id' => 2198,
    ),
    17 => 
    array (
      'name' => 'a910',
      'id' => 2145,
    ),
  ),
  33 => 
  array (
    0 => 
    array (
      'name' => 'A201',
      'id' => 1481,
    ),
    1 => 
    array (
      'name' => 'A310',
      'id' => 1513,
    ),
    2 => 
    array (
      'name' => 'A310c',
      'id' => 1507,
    ),
    3 => 
    array (
      'name' => 'A312',
      'id' => 1479,
    ),
    4 => 
    array (
      'name' => 'A330',
      'id' => 1498,
    ),
    5 => 
    array (
      'name' => 'A332',
      'id' => 1490,
    ),
    6 => 
    array (
      'name' => 'A350',
      'id' => 1690,
    ),
    7 => 
    array (
      'name' => 'A365',
      'id' => 1654,
    ),
    8 => 
    array (
      'name' => 'A510',
      'id' => 1689,
    ),
    9 => 
    array (
      'name' => 'A550',
      'id' => 1688,
    ),
    10 => 
    array (
      'name' => 'A589',
      'id' => 1497,
    ),
    11 => 
    array (
      'name' => 'A600',
      'id' => 1631,
    ),
    12 => 
    array (
      'name' => 'A650',
      'id' => 1612,
    ),
    13 => 
    array (
      'name' => 'A689',
      'id' => 1625,
    ),
    14 => 
    array (
      'name' => 'A710',
      'id' => 1687,
    ),
    15 => 
    array (
      'name' => 'A720',
      'id' => 1610,
    ),
    16 => 
    array (
      'name' => 'A730',
      'id' => 1608,
    ),
    17 => 
    array (
      'name' => 'A900',
      'id' => 1606,
    ),
    18 => 
    array (
      'name' => 'A910',
      'id' => 1489,
    ),
    19 => 
    array (
      'name' => 'Beacon 08',
      'id' => 1685,
    ),
    20 => 
    array (
      'name' => 'E106',
      'id' => 1604,
    ),
    21 => 
    array (
      'name' => 'E118',
      'id' => 1684,
    ),
    22 => 
    array (
      'name' => 'E156',
      'id' => 1478,
    ),
    23 => 
    array (
      'name' => 'E160C',
      'id' => 1477,
    ),
    24 => 
    array (
      'name' => 'E200c',
      'id' => 1505,
    ),
    25 => 
    array (
      'name' => 'E209',
      'id' => 1683,
    ),
    26 => 
    array (
      'name' => 'E210c',
      'id' => 1600,
    ),
    27 => 
    array (
      'name' => 'E212',
      'id' => 1629,
    ),
    28 => 
    array (
      'name' => 'E217',
      'id' => 1661,
    ),
    29 => 
    array (
      'name' => 'E218',
      'id' => 1598,
    ),
    30 => 
    array (
      'name' => 'E228',
      'id' => 1623,
    ),
    31 => 
    array (
      'name' => 'E260c',
      'id' => 1595,
    ),
    32 => 
    array (
      'name' => 'E268',
      'id' => 1593,
    ),
    33 => 
    array (
      'name' => 'E280',
      'id' => 1682,
    ),
    34 => 
    array (
      'name' => 'E300C',
      'id' => 1591,
    ),
    35 => 
    array (
      'name' => 'E520',
      'id' => 1653,
    ),
    36 => 
    array (
      'name' => 'E522��ͨ��',
      'id' => 1588,
    ),
    37 => 
    array (
      'name' => 'ET10',
      'id' => 1485,
    ),
    38 => 
    array (
      'name' => 'ET60',
      'id' => 1495,
    ),
    39 => 
    array (
      'name' => 'ET60C',
      'id' => 1587,
    ),
    40 => 
    array (
      'name' => 'ET660',
      'id' => 1681,
    ),
    41 => 
    array (
      'name' => 'ET700',
      'id' => 1628,
    ),
    42 => 
    array (
      'name' => 'ET80C',
      'id' => 1511,
    ),
    43 => 
    array (
      'name' => 'ET81c',
      'id' => 1584,
    ),
    44 => 
    array (
      'name' => 'ET860',
      'id' => 1659,
    ),
    45 => 
    array (
      'name' => 'ET880',
      'id' => 1640,
    ),
    46 => 
    array (
      'name' => 'i300',
      'id' => 1582,
    ),
    47 => 
    array (
      'name' => 'i307',
      'id' => 1639,
    ),
    48 => 
    array (
      'name' => 'i310e',
      'id' => 1484,
    ),
    49 => 
    array (
      'name' => 'i320',
      'id' => 1488,
    ),
    50 => 
    array (
      'name' => 'i327',
      'id' => 1645,
    ),
    51 => 
    array (
      'name' => 'i328TD',
      'id' => 1475,
    ),
    52 => 
    array (
      'name' => 'i380',
      'id' => 1578,
    ),
    53 => 
    array (
      'name' => 'i50',
      'id' => 1622,
    ),
    54 => 
    array (
      'name' => 'i510',
      'id' => 1652,
    ),
    55 => 
    array (
      'name' => 'i516',
      'id' => 1577,
    ),
    56 => 
    array (
      'name' => 'i55',
      'id' => 1459,
    ),
    57 => 
    array (
      'name' => 'i60',
      'id' => 1680,
    ),
    58 => 
    array (
      'name' => 'i60s',
      'id' => 1575,
    ),
    59 => 
    array (
      'name' => 'i61',
      'id' => 1491,
    ),
    60 => 
    array (
      'name' => 'i758',
      'id' => 1651,
    ),
    61 => 
    array (
      'name' => 'i760',
      'id' => 1638,
    ),
    62 => 
    array (
      'name' => 'i780',
      'id' => 1679,
    ),
    63 => 
    array (
      'name' => 'i800',
      'id' => 1496,
    ),
    64 => 
    array (
      'name' => 'i827',
      'id' => 1667,
    ),
    65 => 
    array (
      'name' => 'i880',
      'id' => 1650,
    ),
    66 => 
    array (
      'name' => 'i909c',
      'id' => 1493,
    ),
    67 => 
    array (
      'name' => 'i910',
      'id' => 1658,
    ),
    68 => 
    array (
      'name' => 'i919',
      'id' => 1666,
    ),
    69 => 
    array (
      'name' => 'LePhone(��Phone)',
      'id' => 1474,
    ),
    70 => 
    array (
      'name' => 'O1',
      'id' => 1492,
    ),
    71 => 
    array (
      'name' => 'P50',
      'id' => 1569,
    ),
    72 => 
    array (
      'name' => 'P580',
      'id' => 1678,
    ),
    73 => 
    array (
      'name' => 'P580c',
      'id' => 1503,
    ),
    74 => 
    array (
      'name' => 'P60',
      'id' => 1567,
    ),
    75 => 
    array (
      'name' => 'P609',
      'id' => 1643,
    ),
    76 => 
    array (
      'name' => 'P609+',
      'id' => 1677,
    ),
    77 => 
    array (
      'name' => 'P609c',
      'id' => 1637,
    ),
    78 => 
    array (
      'name' => 'P612',
      'id' => 1565,
    ),
    79 => 
    array (
      'name' => 'P616',
      'id' => 1545,
    ),
    80 => 
    array (
      'name' => 'P619',
      'id' => 1539,
    ),
    81 => 
    array (
      'name' => 'P620',
      'id' => 1676,
    ),
    82 => 
    array (
      'name' => 'P629',
      'id' => 1469,
    ),
    83 => 
    array (
      'name' => 'P630',
      'id' => 1620,
    ),
    84 => 
    array (
      'name' => 'P636',
      'id' => 1494,
    ),
    85 => 
    array (
      'name' => 'P650wg',
      'id' => 1487,
    ),
    86 => 
    array (
      'name' => 'P668',
      'id' => 1665,
    ),
    87 => 
    array (
      'name' => 'P680',
      'id' => 1675,
    ),
    88 => 
    array (
      'name' => 'P690e',
      'id' => 1468,
    ),
    89 => 
    array (
      'name' => 'P707',
      'id' => 1537,
    ),
    90 => 
    array (
      'name' => 'P719',
      'id' => 1664,
    ),
    91 => 
    array (
      'name' => 'P766',
      'id' => 1618,
    ),
    92 => 
    array (
      'name' => 'P790',
      'id' => 1657,
    ),
    93 => 
    array (
      'name' => 'P80',
      'id' => 1674,
    ),
    94 => 
    array (
      'name' => 'P80+',
      'id' => 1466,
    ),
    95 => 
    array (
      'name' => 'P806',
      'id' => 1642,
    ),
    96 => 
    array (
      'name' => 'P809',
      'id' => 1656,
    ),
    97 => 
    array (
      'name' => 'P82',
      'id' => 1536,
    ),
    98 => 
    array (
      'name' => 'P90W',
      'id' => 1462,
    ),
    99 => 
    array (
      'name' => 'P960',
      'id' => 1635,
    ),
    100 => 
    array (
      'name' => 'P990',
      'id' => 1663,
    ),
    101 => 
    array (
      'name' => 'P992',
      'id' => 1673,
    ),
    102 => 
    array (
      'name' => 'P996',
      'id' => 1535,
    ),
    103 => 
    array (
      'name' => 'S200',
      'id' => 1533,
    ),
    104 => 
    array (
      'name' => 'S301',
      'id' => 1672,
    ),
    105 => 
    array (
      'name' => 'S320',
      'id' => 1671,
    ),
    106 => 
    array (
      'name' => 'S500',
      'id' => 1460,
    ),
    107 => 
    array (
      'name' => 'S520',
      'id' => 1465,
    ),
    108 => 
    array (
      'name' => 'S530',
      'id' => 1649,
    ),
    109 => 
    array (
      'name' => 'S533',
      'id' => 1526,
    ),
    110 => 
    array (
      'name' => 'S533c',
      'id' => 1501,
    ),
    111 => 
    array (
      'name' => 'S60',
      'id' => 1616,
    ),
    112 => 
    array (
      'name' => 'S600',
      'id' => 1633,
    ),
    113 => 
    array (
      'name' => 'S610',
      'id' => 1524,
    ),
    114 => 
    array (
      'name' => 'S62',
      'id' => 1523,
    ),
    115 => 
    array (
      'name' => 'S660',
      'id' => 1670,
    ),
    116 => 
    array (
      'name' => 'S70',
      'id' => 1662,
    ),
    117 => 
    array (
      'name' => 'S700',
      'id' => 1521,
    ),
    118 => 
    array (
      'name' => 'S700+',
      'id' => 1486,
    ),
    119 => 
    array (
      'name' => 'S770',
      'id' => 1669,
    ),
    120 => 
    array (
      'name' => 'S900',
      'id' => 1668,
    ),
    121 => 
    array (
      'name' => 'S90��ͨ��',
      'id' => 1660,
    ),
    122 => 
    array (
      'name' => 'S90�����',
      'id' => 1641,
    ),
    123 => 
    array (
      'name' => 'S96',
      'id' => 1632,
    ),
    124 => 
    array (
      'name' => 'TD115',
      'id' => 1463,
    ),
    125 => 
    array (
      'name' => 'TD30t',
      'id' => 1519,
    ),
    126 => 
    array (
      'name' => 'TD800',
      'id' => 1648,
    ),
    127 => 
    array (
      'name' => 'TD80t',
      'id' => 1482,
    ),
    128 => 
    array (
      'name' => 'TD900',
      'id' => 1644,
    ),
    129 => 
    array (
      'name' => 'TD900T',
      'id' => 1509,
    ),
    130 => 
    array (
      'name' => 'V608',
      'id' => 1655,
    ),
    131 => 
    array (
      'name' => 'V700',
      'id' => 1647,
    ),
    132 => 
    array (
      'name' => 'V80',
      'id' => 1646,
    ),
    133 => 
    array (
      'name' => 'X1',
      'id' => 1517,
    ),
    134 => 
    array (
      'name' => 'X1m',
      'id' => 1515,
    ),
  ),
  146 => 
  array (
    0 => 
    array (
      'name' => 'A3288',
      'id' => 2313,
    ),
    1 => 
    array (
      'name' => 'A6288',
      'id' => 2314,
    ),
    2 => 
    array (
      'name' => 'A6388',
      'id' => 2312,
    ),
    3 => 
    array (
      'name' => 'A8188',
      'id' => 2311,
    ),
  ),
  57 => 
  array (
    0 => 
    array (
      'name' => 'A36',
      'id' => 661,
    ),
    1 => 
    array (
      'name' => 'E50',
      'id' => 663,
    ),
    2 => 
    array (
      'name' => 'E60',
      'id' => 657,
    ),
    3 => 
    array (
      'name' => 'E70',
      'id' => 655,
    ),
    4 => 
    array (
      'name' => 'E70L',
      'id' => 653,
    ),
    5 => 
    array (
      'name' => 'E80',
      'id' => 647,
    ),
    6 => 
    array (
      'name' => 'I-10',
      'id' => 643,
    ),
    7 => 
    array (
      'name' => 'M5O',
      'id' => 665,
    ),
    8 => 
    array (
      'name' => 'M60',
      'id' => 658,
    ),
    9 => 
    array (
      'name' => 'P70',
      'id' => 654,
    ),
    10 => 
    array (
      'name' => 'P80',
      'id' => 649,
    ),
    11 => 
    array (
      'name' => 'S12',
      'id' => 664,
    ),
    12 => 
    array (
      'name' => 'V10',
      'id' => 662,
    ),
    13 => 
    array (
      'name' => 'V20',
      'id' => 659,
    ),
    14 => 
    array (
      'name' => 'W60',
      'id' => 660,
    ),
    15 => 
    array (
      'name' => 'W80',
      'id' => 650,
    ),
    16 => 
    array (
      'name' => 'W90',
      'id' => 644,
    ),
    17 => 
    array (
      'name' => 'WS80',
      'id' => 648,
    ),
    18 => 
    array (
      'name' => 'X70',
      'id' => 652,
    ),
    19 => 
    array (
      'name' => 'X90',
      'id' => 645,
    ),
  ),
  89 => 
  array (
    0 => 
    array (
      'name' => 'A42EI35JC-SL14',
      'id' => 1941,
    ),
    1 => 
    array (
      'name' => 'A42EI52JR-SL',
      'id' => 1942,
    ),
    2 => 
    array (
      'name' => 'A42EI52JR-SL',
      'id' => 1939,
    ),
    3 => 
    array (
      'name' => 'A42EI52JV-SL',
      'id' => 1943,
    ),
  ),
  174 => 
  array (
    0 => 
    array (
      'name' => 'a7350c',
      'id' => 2616,
    ),
    1 => 
    array (
      'name' => 'S189',
      'id' => 2680,
    ),
    2 => 
    array (
      'name' => 's239',
      'id' => 2723,
    ),
    3 => 
    array (
      'name' => 's3030c',
      'id' => 2652,
    ),
    4 => 
    array (
      'name' => 's3110c',
      'id' => 2630,
    ),
    5 => 
    array (
      'name' => 's3310c',
      'id' => 2624,
    ),
    6 => 
    array (
      'name' => 's3370',
      'id' => 2734,
    ),
    7 => 
    array (
      'name' => 's3500c',
      'id' => 2621,
    ),
    8 => 
    array (
      'name' => 's3501c',
      'id' => 2597,
    ),
    9 => 
    array (
      'name' => 's3550',
      'id' => 2581,
    ),
    10 => 
    array (
      'name' => 's359',
      'id' => 2601,
    ),
    11 => 
    array (
      'name' => 's3600c',
      'id' => 2662,
    ),
    12 => 
    array (
      'name' => 's3601c',
      'id' => 2588,
    ),
    13 => 
    array (
      'name' => 's3650c',
      'id' => 2603,
    ),
    14 => 
    array (
      'name' => 's3830u',
      'id' => 2765,
    ),
    15 => 
    array (
      'name' => 's3930c',
      'id' => 2762,
    ),
    16 => 
    array (
      'name' => 's5150',
      'id' => 2589,
    ),
    17 => 
    array (
      'name' => 's5200c',
      'id' => 2610,
    ),
    18 => 
    array (
      'name' => 'S5210',
      'id' => 3550,
    ),
    19 => 
    array (
      'name' => 's5230c',
      'id' => 2571,
    ),
    20 => 
    array (
      'name' => 'S5330',
      'id' => 2973,
    ),
    21 => 
    array (
      'name' => 'S5520',
      'id' => 2971,
    ),
    22 => 
    array (
      'name' => 'S5530',
      'id' => 2995,
    ),
    23 => 
    array (
      'name' => 's5550u',
      'id' => 2739,
    ),
    24 => 
    array (
      'name' => 's5560c',
      'id' => 2594,
    ),
    25 => 
    array (
      'name' => 'S5570',
      'id' => 2991,
    ),
    26 => 
    array (
      'name' => 'S5580',
      'id' => 2972,
    ),
    27 => 
    array (
      'name' => 's5608u',
      'id' => 2759,
    ),
    28 => 
    array (
      'name' => 's5628',
      'id' => 2736,
    ),
    29 => 
    array (
      'name' => 's5628i',
      'id' => 2733,
    ),
    30 => 
    array (
      'name' => 's5630c',
      'id' => 2761,
    ),
    31 => 
    array (
      'name' => 'S5660',
      'id' => 2993,
    ),
    32 => 
    array (
      'name' => 'S5670',
      'id' => 2994,
    ),
    33 => 
    array (
      'name' => 's5680',
      'id' => 2727,
    ),
    34 => 
    array (
      'name' => 's569',
      'id' => 2728,
    ),
    35 => 
    array (
      'name' => 'S579',
      'id' => 2974,
    ),
    36 => 
    array (
      'name' => 'S5830',
      'id' => 2992,
    ),
    37 => 
    array (
      'name' => 's6700c',
      'id' => 2605,
    ),
    38 => 
    array (
      'name' => 's7070c',
      'id' => 2587,
    ),
    39 => 
    array (
      'name' => 's7120u',
      'id' => 2764,
    ),
    40 => 
    array (
      'name' => 's7520u',
      'id' => 2767,
    ),
    41 => 
    array (
      'name' => 's8000c',
      'id' => 2611,
    ),
    42 => 
    array (
      'name' => 's8300c',
      'id' => 2617,
    ),
    43 => 
    array (
      'name' => 's8500',
      'id' => 2730,
    ),
  ),
  343 => 
  array (
    0 => 
    array (
      'name' => 'A8i',
      'id' => 3707,
    ),
  ),
  30 => 
  array (
    0 => 
    array (
      'name' => 'Aino U10(U10i)',
      'id' => 979,
    ),
    1 => 
    array (
      'name' => 'C510',
      'id' => 977,
    ),
    2 => 
    array (
      'name' => 'C702c',
      'id' => 1082,
    ),
    3 => 
    array (
      'name' => 'C901',
      'id' => 976,
    ),
    4 => 
    array (
      'name' => 'C902',
      'id' => 1068,
    ),
    5 => 
    array (
      'name' => 'C903(CS5)',
      'id' => 974,
    ),
    6 => 
    array (
      'name' => 'C905(CS8)',
      'id' => 1045,
    ),
    7 => 
    array (
      'name' => 'E10i(X10 mini)',
      'id' => 926,
    ),
    8 => 
    array (
      'name' => 'Elm J10',
      'id' => 972,
    ),
    9 => 
    array (
      'name' => 'F305',
      'id' => 1049,
    ),
    10 => 
    array (
      'name' => 'G502',
      'id' => 1080,
    ),
    11 => 
    array (
      'name' => 'G700c',
      'id' => 1074,
    ),
    12 => 
    array (
      'name' => 'G702',
      'id' => 1057,
    ),
    13 => 
    array (
      'name' => 'G705',
      'id' => 1249,
    ),
    14 => 
    array (
      'name' => 'G819',
      'id' => 924,
    ),
    15 => 
    array (
      'name' => 'G900',
      'id' => 1077,
    ),
    16 => 
    array (
      'name' => 'G902',
      'id' => 970,
    ),
    17 => 
    array (
      'name' => 'IIDA G9',
      'id' => 968,
    ),
    18 => 
    array (
      'name' => 'J105i',
      'id' => 967,
    ),
    19 => 
    array (
      'name' => 'J110c',
      'id' => 1295,
    ),
    20 => 
    array (
      'name' => 'J120c',
      'id' => 1282,
    ),
    21 => 
    array (
      'name' => 'J132',
      'id' => 1066,
    ),
    22 => 
    array (
      'name' => 'J20',
      'id' => 918,
    ),
    23 => 
    array (
      'name' => 'Jalou',
      'id' => 966,
    ),
    24 => 
    array (
      'name' => 'K200c',
      'id' => 1278,
    ),
    25 => 
    array (
      'name' => 'K220c',
      'id' => 1281,
    ),
    26 => 
    array (
      'name' => 'K250i',
      'id' => 1322,
    ),
    27 => 
    array (
      'name' => 'k330',
      'id' => 1064,
    ),
    28 => 
    array (
      'name' => 'K530c',
      'id' => 1266,
    ),
    29 => 
    array (
      'name' => 'K530i',
      'id' => 1264,
    ),
    30 => 
    array (
      'name' => 'K550c',
      'id' => 1306,
    ),
    31 => 
    array (
      'name' => 'K630c',
      'id' => 1270,
    ),
    32 => 
    array (
      'name' => 'K660i',
      'id' => 1210,
    ),
    33 => 
    array (
      'name' => 'K770i',
      'id' => 1277,
    ),
    34 => 
    array (
      'name' => 'K818c',
      'id' => 1304,
    ),
    35 => 
    array (
      'name' => 'K850i',
      'id' => 1262,
    ),
    36 => 
    array (
      'name' => 'K858c',
      'id' => 1260,
    ),
    37 => 
    array (
      'name' => 'K880i',
      'id' => 1318,
    ),
    38 => 
    array (
      'name' => 'K900i',
      'id' => 1317,
    ),
    39 => 
    array (
      'name' => 'M1i(Aspen)',
      'id' => 914,
    ),
    40 => 
    array (
      'name' => 'P1c',
      'id' => 1293,
    ),
    41 => 
    array (
      'name' => 'P3i',
      'id' => 1247,
    ),
    42 => 
    array (
      'name' => 'P5i',
      'id' => 1244,
    ),
    43 => 
    array (
      'name' => 'R300i',
      'id' => 1225,
    ),
    44 => 
    array (
      'name' => 'R300i',
      'id' => 1234,
    ),
    45 => 
    array (
      'name' => 'R306',
      'id' => 1043,
    ),
    46 => 
    array (
      'name' => 'S001',
      'id' => 963,
    ),
    47 => 
    array (
      'name' => 'S002',
      'id' => 961,
    ),
    48 => 
    array (
      'name' => 'S302c',
      'id' => 1063,
    ),
    49 => 
    array (
      'name' => 'S312',
      'id' => 933,
    ),
    50 => 
    array (
      'name' => 'S500',
      'id' => 1280,
    ),
    51 => 
    array (
      'name' => 'S800i',
      'id' => 1315,
    ),
    52 => 
    array (
      'name' => 'SO903i',
      'id' => 1314,
    ),
    53 => 
    array (
      'name' => 'T258c',
      'id' => 1268,
    ),
    54 => 
    array (
      'name' => 'T270i',
      'id' => 1233,
    ),
    55 => 
    array (
      'name' => 'T270i',
      'id' => 1223,
    ),
    56 => 
    array (
      'name' => 'T280i',
      'id' => 1221,
    ),
    57 => 
    array (
      'name' => 'T303c',
      'id' => 1061,
    ),
    58 => 
    array (
      'name' => 'T658c',
      'id' => 1275,
    ),
    59 => 
    array (
      'name' => 'T700',
      'id' => 1048,
    ),
    60 => 
    array (
      'name' => 'T707',
      'id' => 931,
    ),
    61 => 
    array (
      'name' => 'T715',
      'id' => 960,
    ),
    62 => 
    array (
      'name' => 'U100i ����(Yari)',
      'id' => 958,
    ),
    63 => 
    array (
      'name' => 'U1i',
      'id' => 955,
    ),
    64 => 
    array (
      'name' => 'U5i',
      'id' => 910,
    ),
    65 => 
    array (
      'name' => 'U8i(Vivaz Pro)',
      'id' => 907,
    ),
    66 => 
    array (
      'name' => 'Urbano barone',
      'id' => 953,
    ),
    67 => 
    array (
      'name' => 'W100i',
      'id' => 896,
    ),
    68 => 
    array (
      'name' => 'W20(Zylo)',
      'id' => 895,
    ),
    69 => 
    array (
      'name' => 'W200c',
      'id' => 1302,
    ),
    70 => 
    array (
      'name' => 'W205',
      'id' => 929,
    ),
    71 => 
    array (
      'name' => 'W302',
      'id' => 1059,
    ),
    72 => 
    array (
      'name' => 'W350c',
      'id' => 1243,
    ),
    73 => 
    array (
      'name' => 'W350i',
      'id' => 1240,
    ),
    74 => 
    array (
      'name' => 'W350i',
      'id' => 1231,
    ),
    75 => 
    array (
      'name' => 'W380c',
      'id' => 1207,
    ),
    76 => 
    array (
      'name' => 'W380i',
      'id' => 1204,
    ),
    77 => 
    array (
      'name' => 'W390',
      'id' => 1238,
    ),
    78 => 
    array (
      'name' => 'W390',
      'id' => 1229,
    ),
    79 => 
    array (
      'name' => 'W395c',
      'id' => 950,
    ),
    80 => 
    array (
      'name' => 'W43S',
      'id' => 1312,
    ),
    81 => 
    array (
      'name' => 'W508',
      'id' => 949,
    ),
    82 => 
    array (
      'name' => 'W518a',
      'id' => 947,
    ),
    83 => 
    array (
      'name' => 'W580',
      'id' => 1290,
    ),
    84 => 
    array (
      'name' => 'W595c',
      'id' => 1047,
    ),
    85 => 
    array (
      'name' => 'W610c',
      'id' => 1285,
    ),
    86 => 
    array (
      'name' => 'W61s',
      'id' => 945,
    ),
    87 => 
    array (
      'name' => 'W63s',
      'id' => 944,
    ),
    88 => 
    array (
      'name' => 'W660i',
      'id' => 1300,
    ),
    89 => 
    array (
      'name' => 'W705',
      'id' => 942,
    ),
    90 => 
    array (
      'name' => 'W707',
      'id' => 1041,
    ),
    91 => 
    array (
      'name' => 'W715',
      'id' => 941,
    ),
    92 => 
    array (
      'name' => 'W760c',
      'id' => 1070,
    ),
    93 => 
    array (
      'name' => 'W888c',
      'id' => 1298,
    ),
    94 => 
    array (
      'name' => 'W890i',
      'id' => 1201,
    ),
    95 => 
    array (
      'name' => 'W898c',
      'id' => 1086,
    ),
    96 => 
    array (
      'name' => 'W902',
      'id' => 1046,
    ),
    97 => 
    array (
      'name' => 'W908c',
      'id' => 1258,
    ),
    98 => 
    array (
      'name' => 'W910i',
      'id' => 1257,
    ),
    99 => 
    array (
      'name' => 'W960i',
      'id' => 1254,
    ),
    100 => 
    array (
      'name' => 'W995',
      'id' => 939,
    ),
    101 => 
    array (
      'name' => 'X1',
      'id' => 1054,
    ),
    102 => 
    array (
      'name' => 'X10 mini',
      'id' => 904,
    ),
    103 => 
    array (
      'name' => 'X10i',
      'id' => 899,
    ),
    104 => 
    array (
      'name' => 'X2i',
      'id' => 898,
    ),
    105 => 
    array (
      'name' => 'X5(Xperia Pureness)',
      'id' => 936,
    ),
    106 => 
    array (
      'name' => 'Xmini',
      'id' => 1038,
    ),
    107 => 
    array (
      'name' => 'Z258c',
      'id' => 1311,
    ),
    108 => 
    array (
      'name' => 'Z310c',
      'id' => 1283,
    ),
    109 => 
    array (
      'name' => 'Z320i',
      'id' => 1310,
    ),
    110 => 
    array (
      'name' => 'Z350',
      'id' => 1309,
    ),
    111 => 
    array (
      'name' => 'Z555i',
      'id' => 1227,
    ),
    112 => 
    array (
      'name' => 'Z555i',
      'id' => 1236,
    ),
    113 => 
    array (
      'name' => 'Z750i',
      'id' => 1272,
    ),
    114 => 
    array (
      'name' => 'Z770i',
      'id' => 1084,
    ),
    115 => 
    array (
      'name' => 'z780',
      'id' => 1075,
    ),
    116 => 
    array (
      'name' => 'Z810i',
      'id' => 1307,
    ),
    117 => 
    array (
      'name' => '����U_1',
      'id' => 902,
    ),
  ),
  37 => 
  array (
    0 => 
    array (
      'name' => 'Ally(������)',
      'id' => 1096,
    ),
    1 => 
    array (
      'name' => 'BL20e',
      'id' => 1217,
    ),
    2 => 
    array (
      'name' => 'BL40e',
      'id' => 1216,
    ),
    3 => 
    array (
      'name' => 'GB101',
      'id' => 1215,
    ),
    4 => 
    array (
      'name' => 'GB102',
      'id' => 1214,
    ),
    5 => 
    array (
      'name' => 'GB106',
      'id' => 1213,
    ),
    6 => 
    array (
      'name' => 'GB110',
      'id' => 1212,
    ),
    7 => 
    array (
      'name' => 'GB130',
      'id' => 1209,
    ),
    8 => 
    array (
      'name' => 'GB170',
      'id' => 1208,
    ),
    9 => 
    array (
      'name' => 'GB220',
      'id' => 1206,
    ),
    10 => 
    array (
      'name' => 'GB230',
      'id' => 1205,
    ),
    11 => 
    array (
      'name' => 'GB250',
      'id' => 1203,
    ),
    12 => 
    array (
      'name' => 'GB258',
      'id' => 1219,
    ),
    13 => 
    array (
      'name' => 'GB270',
      'id' => 1143,
    ),
    14 => 
    array (
      'name' => 'GC900e',
      'id' => 1148,
    ),
    15 => 
    array (
      'name' => 'GC990 Louvre',
      'id' => 1202,
    ),
    16 => 
    array (
      'name' => 'GD300s',
      'id' => 1200,
    ),
    17 => 
    array (
      'name' => 'GD310',
      'id' => 1199,
    ),
    18 => 
    array (
      'name' => 'GD330',
      'id' => 1151,
    ),
    19 => 
    array (
      'name' => 'GD350',
      'id' => 1099,
    ),
    20 => 
    array (
      'name' => 'GD510',
      'id' => 1198,
    ),
    21 => 
    array (
      'name' => 'GD550e',
      'id' => 1098,
    ),
    22 => 
    array (
      'name' => 'GD580e',
      'id' => 1139,
    ),
    23 => 
    array (
      'name' => 'GD710',
      'id' => 1138,
    ),
    24 => 
    array (
      'name' => 'GD880 Mini',
      'id' => 1137,
    ),
    25 => 
    array (
      'name' => 'GD900e',
      'id' => 1147,
    ),
    26 => 
    array (
      'name' => 'GD910',
      'id' => 1197,
    ),
    27 => 
    array (
      'name' => 'GM200(GM205)',
      'id' => 1196,
    ),
    28 => 
    array (
      'name' => 'GM210',
      'id' => 1195,
    ),
    29 => 
    array (
      'name' => 'GM310',
      'id' => 1194,
    ),
    30 => 
    array (
      'name' => 'GM360',
      'id' => 1007,
    ),
    31 => 
    array (
      'name' => 'GM630',
      'id' => 1193,
    ),
    32 => 
    array (
      'name' => 'GM650s',
      'id' => 1003,
    ),
    33 => 
    array (
      'name' => 'GM730e',
      'id' => 1192,
    ),
    34 => 
    array (
      'name' => 'GM750',
      'id' => 1191,
    ),
    35 => 
    array (
      'name' => 'GR500',
      'id' => 1190,
    ),
    36 => 
    array (
      'name' => 'GS100',
      'id' => 1095,
    ),
    37 => 
    array (
      'name' => 'GS101',
      'id' => 1035,
    ),
    38 => 
    array (
      'name' => 'GS107',
      'id' => 1030,
    ),
    39 => 
    array (
      'name' => 'GS200',
      'id' => 1189,
    ),
    40 => 
    array (
      'name' => 'GS290',
      'id' => 1136,
    ),
    41 => 
    array (
      'name' => 'GS500v(Cookie',
      'id' => 1134,
    ),
    42 => 
    array (
      'name' => 'GT350',
      'id' => 1133,
    ),
    43 => 
    array (
      'name' => 'GT400',
      'id' => 1132,
    ),
    44 => 
    array (
      'name' => 'GT405',
      'id' => 1131,
    ),
    45 => 
    array (
      'name' => 'GT500s',
      'id' => 1126,
    ),
    46 => 
    array (
      'name' => 'GT505e',
      'id' => 1188,
    ),
    47 => 
    array (
      'name' => 'GT540',
      'id' => 1125,
    ),
    48 => 
    array (
      'name' => 'GT810H',
      'id' => 1218,
    ),
    49 => 
    array (
      'name' => 'GU230',
      'id' => 1187,
    ),
    50 => 
    array (
      'name' => 'GU280(GU285)',
      'id' => 1186,
    ),
    51 => 
    array (
      'name' => 'GW300',
      'id' => 1185,
    ),
    52 => 
    array (
      'name' => 'GW370',
      'id' => 1123,
    ),
    53 => 
    array (
      'name' => 'GW525(GW520)',
      'id' => 1184,
    ),
    54 => 
    array (
      'name' => 'GW550',
      'id' => 1183,
    ),
    55 => 
    array (
      'name' => 'GW600',
      'id' => 1182,
    ),
    56 => 
    array (
      'name' => 'GW620',
      'id' => 1141,
    ),
    57 => 
    array (
      'name' => 'GW820(eXpo)',
      'id' => 1181,
    ),
    58 => 
    array (
      'name' => 'GW880',
      'id' => 1180,
    ),
    59 => 
    array (
      'name' => 'GW990',
      'id' => 1121,
    ),
    60 => 
    array (
      'name' => 'GX200',
      'id' => 1119,
    ),
    61 => 
    array (
      'name' => 'GX300',
      'id' => 1023,
    ),
    62 => 
    array (
      'name' => 'GX500',
      'id' => 1117,
    ),
    63 => 
    array (
      'name' => 'HQ',
      'id' => 1179,
    ),
    64 => 
    array (
      'name' => 'Jacquar5',
      'id' => 1116,
    ),
    65 => 
    array (
      'name' => 'KD877',
      'id' => 1142,
    ),
    66 => 
    array (
      'name' => 'KF305',
      'id' => 1114,
    ),
    67 => 
    array (
      'name' => 'KG376',
      'id' => 1178,
    ),
    68 => 
    array (
      'name' => 'KH5200',
      'id' => 1100,
    ),
    69 => 
    array (
      'name' => 'KH8000',
      'id' => 1177,
    ),
    70 => 
    array (
      'name' => 'KM330',
      'id' => 1176,
    ),
    71 => 
    array (
      'name' => 'KM555e',
      'id' => 1175,
    ),
    72 => 
    array (
      'name' => 'KM570',
      'id' => 1112,
    ),
    73 => 
    array (
      'name' => 'KM900e��Arena��',
      'id' => 1174,
    ),
    74 => 
    array (
      'name' => 'KP105',
      'id' => 1173,
    ),
    75 => 
    array (
      'name' => 'KP108',
      'id' => 1153,
    ),
    76 => 
    array (
      'name' => 'KP168',
      'id' => 1172,
    ),
    77 => 
    array (
      'name' => 'KP275',
      'id' => 1145,
    ),
    78 => 
    array (
      'name' => 'KP501',
      'id' => 1171,
    ),
    79 => 
    array (
      'name' => 'KP502',
      'id' => 1111,
    ),
    80 => 
    array (
      'name' => 'KS365',
      'id' => 1110,
    ),
    81 => 
    array (
      'name' => 'KS660',
      'id' => 1170,
    ),
    82 => 
    array (
      'name' => 'KT615',
      'id' => 1169,
    ),
    83 => 
    array (
      'name' => 'KT770',
      'id' => 1168,
    ),
    84 => 
    array (
      'name' => 'KT878',
      'id' => 1167,
    ),
    85 => 
    array (
      'name' => 'KU2100',
      'id' => 1102,
    ),
    86 => 
    array (
      'name' => 'KV220',
      'id' => 1022,
    ),
    87 => 
    array (
      'name' => 'KV230',
      'id' => 1109,
    ),
    88 => 
    array (
      'name' => 'KV500',
      'id' => 1150,
    ),
    89 => 
    array (
      'name' => 'KV510',
      'id' => 1140,
    ),
    90 => 
    array (
      'name' => 'KV600',
      'id' => 1166,
    ),
    91 => 
    array (
      'name' => 'KV700',
      'id' => 1097,
    ),
    92 => 
    array (
      'name' => 'KV7500',
      'id' => 1165,
    ),
    93 => 
    array (
      'name' => 'KV755',
      'id' => 1149,
    ),
    94 => 
    array (
      'name' => 'KV800',
      'id' => 1144,
    ),
    95 => 
    array (
      'name' => 'KV920',
      'id' => 1146,
    ),
    96 => 
    array (
      'name' => 'KX190',
      'id' => 1164,
    ),
    97 => 
    array (
      'name' => 'KX191',
      'id' => 1163,
    ),
    98 => 
    array (
      'name' => 'KX195',
      'id' => 1162,
    ),
    99 => 
    array (
      'name' => 'KX196',
      'id' => 1101,
    ),
    100 => 
    array (
      'name' => 'KX197',
      'id' => 1005,
    ),
    101 => 
    array (
      'name' => 'KX218',
      'id' => 1161,
    ),
    102 => 
    array (
      'name' => 'KX300',
      'id' => 1160,
    ),
    103 => 
    array (
      'name' => 'KX500',
      'id' => 1152,
    ),
    104 => 
    array (
      'name' => 'LG GB125',
      'id' => 1211,
    ),
    105 => 
    array (
      'name' => 'LH8000',
      'id' => 1159,
    ),
    106 => 
    array (
      'name' => 'Lotus',
      'id' => 1154,
    ),
    107 => 
    array (
      'name' => 'Lotus Elite',
      'id' => 1108,
    ),
    108 => 
    array (
      'name' => 'LU2300',
      'id' => 1107,
    ),
    109 => 
    array (
      'name' => 'LU9400',
      'id' => 1106,
    ),
    110 => 
    array (
      'name' => 'Pure',
      'id' => 1105,
    ),
    111 => 
    array (
      'name' => 'Remarq',
      'id' => 1104,
    ),
    112 => 
    array (
      'name' => 'SB210',
      'id' => 1158,
    ),
    113 => 
    array (
      'name' => 'SV770',
      'id' => 1103,
    ),
    114 => 
    array (
      'name' => 'SV800',
      'id' => 1157,
    ),
    115 => 
    array (
      'name' => 'TB200',
      'id' => 1156,
    ),
    116 => 
    array (
      'name' => 'TB260',
      'id' => 1001,
    ),
    117 => 
    array (
      'name' => 'TM300',
      'id' => 1021,
    ),
    118 => 
    array (
      'name' => 'VX8575',
      'id' => 1155,
    ),
  ),
  77 => 
  array (
    0 => 
    array (
      'name' => 'AS3820',
      'id' => 1992,
    ),
  ),
  76 => 
  array (
    0 => 
    array (
      'name' => 'AS4741',
      'id' => 1983,
    ),
  ),
  78 => 
  array (
    0 => 
    array (
      'name' => 'AS5745',
      'id' => 1996,
    ),
  ),
  172 => 
  array (
    0 => 
    array (
      'name' => 'b108',
      'id' => 2718,
    ),
    1 => 
    array (
      'name' => 'B189',
      'id' => 2641,
    ),
    2 => 
    array (
      'name' => 'b289',
      'id' => 2671,
    ),
    3 => 
    array (
      'name' => 'B299',
      'id' => 2568,
    ),
    4 => 
    array (
      'name' => 'B308',
      'id' => 2696,
    ),
    5 => 
    array (
      'name' => 'b309',
      'id' => 2612,
    ),
    6 => 
    array (
      'name' => 'B3210',
      'id' => 2582,
    ),
    7 => 
    array (
      'name' => 'B3410',
      'id' => 2578,
    ),
    8 => 
    array (
      'name' => 'b508',
      'id' => 2721,
    ),
    9 => 
    array (
      'name' => 'B518',
      'id' => 2692,
    ),
    10 => 
    array (
      'name' => 'B5210u',
      'id' => 2768,
    ),
    11 => 
    array (
      'name' => 'b528',
      'id' => 2676,
    ),
    12 => 
    array (
      'name' => 'b5310u',
      'id' => 2740,
    ),
    13 => 
    array (
      'name' => 'b5702c',
      'id' => 2777,
    ),
    14 => 
    array (
      'name' => 'b5702c',
      'id' => 2609,
    ),
    15 => 
    array (
      'name' => 'b5712c',
      'id' => 2779,
    ),
    16 => 
    array (
      'name' => 'B5712c',
      'id' => 2639,
    ),
    17 => 
    array (
      'name' => 'B5722c',
      'id' => 2775,
    ),
    18 => 
    array (
      'name' => 'b7300c',
      'id' => 2608,
    ),
    19 => 
    array (
      'name' => 'b7620u',
      'id' => 2742,
    ),
    20 => 
    array (
      'name' => 'b7702',
      'id' => 2726,
    ),
    21 => 
    array (
      'name' => 'B7732',
      'id' => 2732,
    ),
    22 => 
    array (
      'name' => 'B7732',
      'id' => 2774,
    ),
    23 => 
    array (
      'name' => 'BC01',
      'id' => 2697,
    ),
  ),
  195 => 
  array (
    0 => 
    array (
      'name' => 'bl20e',
      'id' => 2675,
    ),
    1 => 
    array (
      'name' => 'bl40e',
      'id' => 2677,
    ),
  ),
  125 => 
  array (
    0 => 
    array (
      'name' => 'C1-00',
      'id' => 2142,
    ),
    1 => 
    array (
      'name' => 'C1-01',
      'id' => 3002,
    ),
    2 => 
    array (
      'name' => 'C1-02',
      'id' => 2978,
    ),
    3 => 
    array (
      'name' => 'C1-03',
      'id' => 3024,
    ),
    4 => 
    array (
      'name' => 'C2-00',
      'id' => 2147,
    ),
    5 => 
    array (
      'name' => 'C2-01',
      'id' => 2982,
    ),
    6 => 
    array (
      'name' => 'C3-00',
      'id' => 3174,
    ),
    7 => 
    array (
      'name' => 'C3-00',
      'id' => 2146,
    ),
    8 => 
    array (
      'name' => 'C3-01',
      'id' => 2983,
    ),
    9 => 
    array (
      'name' => 'C5-00',
      'id' => 2151,
    ),
    10 => 
    array (
      'name' => 'C5-01',
      'id' => 3178,
    ),
    11 => 
    array (
      'name' => 'C5-03',
      'id' => 3000,
    ),
    12 => 
    array (
      'name' => 'C6-00',
      'id' => 2149,
    ),
    13 => 
    array (
      'name' => 'C6-01',
      'id' => 3005,
    ),
    14 => 
    array (
      'name' => 'C7-00',
      'id' => 3006,
    ),
  ),
  45 => 
  array (
    0 => 
    array (
      'name' => 'C140',
      'id' => 361,
    ),
    1 => 
    array (
      'name' => 'C180',
      'id' => 364,
    ),
    2 => 
    array (
      'name' => 'M320',
      'id' => 365,
    ),
    3 => 
    array (
      'name' => 'M340',
      'id' => 366,
    ),
    4 => 
    array (
      'name' => 'M341',
      'id' => 358,
    ),
    5 => 
    array (
      'name' => 'M380',
      'id' => 367,
    ),
    6 => 
    array (
      'name' => 'M381',
      'id' => 359,
    ),
    7 => 
    array (
      'name' => 'M420',
      'id' => 363,
    ),
    8 => 
    array (
      'name' => 'M530',
      'id' => 353,
    ),
    9 => 
    array (
      'name' => 'M550',
      'id' => 354,
    ),
    10 => 
    array (
      'name' => 'M575',
      'id' => 355,
    ),
    11 => 
    array (
      'name' => 'M580',
      'id' => 357,
    ),
    12 => 
    array (
      'name' => 'SLICE',
      'id' => 356,
    ),
    13 => 
    array (
      'name' => 'Z915',
      'id' => 362,
    ),
    14 => 
    array (
      'name' => 'Z950',
      'id' => 360,
    ),
    15 => 
    array (
      'name' => 'Z980',
      'id' => 368,
    ),
    16 => 
    array (
      'name' => 'Z981',
      'id' => 352,
    ),
  ),
  301 => 
  array (
    0 => 
    array (
      'name' => 'C168',
      'id' => 3456,
    ),
    1 => 
    array (
      'name' => 'C257',
      'id' => 3454,
    ),
    2 => 
    array (
      'name' => 'C261',
      'id' => 3442,
    ),
    3 => 
    array (
      'name' => 'C290',
      'id' => 3458,
    ),
    4 => 
    array (
      'name' => 'C305',
      'id' => 3459,
    ),
    5 => 
    array (
      'name' => 'C364',
      'id' => 3466,
    ),
  ),
  307 => 
  array (
    0 => 
    array (
      'name' => 'C2600',
      'id' => 3392,
    ),
    1 => 
    array (
      'name' => 'C2601',
      'id' => 3395,
    ),
    2 => 
    array (
      'name' => 'C2800',
      'id' => 3383,
    ),
    3 => 
    array (
      'name' => 'C2801',
      'id' => 3410,
    ),
    4 => 
    array (
      'name' => 'C2807',
      'id' => 3411,
    ),
    5 => 
    array (
      'name' => 'C2808',
      'id' => 3405,
    ),
    6 => 
    array (
      'name' => 'C2823',
      'id' => 3388,
    ),
    7 => 
    array (
      'name' => 'C2827',
      'id' => 3380,
    ),
    8 => 
    array (
      'name' => 'C2828',
      'id' => 3406,
    ),
    9 => 
    array (
      'name' => 'C2829',
      'id' => 3389,
    ),
    10 => 
    array (
      'name' => 'C2900',
      'id' => 3407,
    ),
    11 => 
    array (
      'name' => 'C3105',
      'id' => 3396,
    ),
    12 => 
    array (
      'name' => 'C3308',
      'id' => 3412,
    ),
    13 => 
    array (
      'name' => 'C5588',
      'id' => 3409,
    ),
    14 => 
    array (
      'name' => 'C5900',
      'id' => 3377,
    ),
    15 => 
    array (
      'name' => 'C7100',
      'id' => 3393,
    ),
    16 => 
    array (
      'name' => 'C7189',
      'id' => 3381,
    ),
    17 => 
    array (
      'name' => 'C7199',
      'id' => 3394,
    ),
    18 => 
    array (
      'name' => 'C7260',
      'id' => 3382,
    ),
    19 => 
    array (
      'name' => 'C7300',
      'id' => 3391,
    ),
    20 => 
    array (
      'name' => 'C7600',
      'id' => 3378,
    ),
    21 => 
    array (
      'name' => 'C8000',
      'id' => 3375,
    ),
    22 => 
    array (
      'name' => 'C8100',
      'id' => 3374,
    ),
    23 => 
    array (
      'name' => 'c8600',
      'id' => 3373,
    ),
  ),
  171 => 
  array (
    0 => 
    array (
      'name' => 'C288',
      'id' => 2693,
    ),
    1 => 
    array (
      'name' => 'c3050c',
      'id' => 2613,
    ),
    2 => 
    array (
      'name' => 'c3110c',
      'id' => 2645,
    ),
    3 => 
    array (
      'name' => 'C3222',
      'id' => 3014,
    ),
    4 => 
    array (
      'name' => 'c3230',
      'id' => 2725,
    ),
    5 => 
    array (
      'name' => 'c3300k',
      'id' => 2567,
    ),
    6 => 
    array (
      'name' => 'c3310c',
      'id' => 2632,
    ),
    7 => 
    array (
      'name' => 'C3500',
      'id' => 3013,
    ),
    8 => 
    array (
      'name' => 'c3518',
      'id' => 2584,
    ),
    9 => 
    array (
      'name' => 'c3610c',
      'id' => 2648,
    ),
    10 => 
    array (
      'name' => 'c3630c',
      'id' => 2738,
    ),
    11 => 
    array (
      'name' => 'c3730c',
      'id' => 2744,
    ),
    12 => 
    array (
      'name' => 'c5130u',
      'id' => 2749,
    ),
    13 => 
    array (
      'name' => 'C5180',
      'id' => 3015,
    ),
    14 => 
    array (
      'name' => 'c5510u',
      'id' => 2755,
    ),
    15 => 
    array (
      'name' => 'c5530',
      'id' => 2724,
    ),
    16 => 
    array (
      'name' => 'c6112c',
      'id' => 2776,
    ),
    17 => 
    array (
      'name' => 'cc01',
      'id' => 2719,
    ),
    18 => 
    array (
      'name' => 'cc01i',
      'id' => 2644,
    ),
    19 => 
    array (
      'name' => 'cc03',
      'id' => 2720,
    ),
  ),
  178 => 
  array (
    0 => 
    array (
      'name' => 'C510',
      'id' => 3616,
    ),
    1 => 
    array (
      'name' => 'C702',
      'id' => 2580,
    ),
    2 => 
    array (
      'name' => 'C901',
      'id' => 3635,
    ),
    3 => 
    array (
      'name' => 'C902',
      'id' => 3636,
    ),
    4 => 
    array (
      'name' => 'C903',
      'id' => 3615,
    ),
    5 => 
    array (
      'name' => 'C905',
      'id' => 3617,
    ),
  ),
  4 => 
  array (
    0 => 
    array (
      'name' => 'C5188/6188/7188/7288/8188',
      'id' => 2910,
    ),
    1 => 
    array (
      'name' => 'Deskjet F2188',
      'id' => 2882,
    ),
    2 => 
    array (
      'name' => 'Deskjet F2418',
      'id' => 55,
    ),
    3 => 
    array (
      'name' => 'Deskjet F2488',
      'id' => 61,
    ),
    4 => 
    array (
      'name' => 'Deskjet F388',
      'id' => 2883,
    ),
    5 => 
    array (
      'name' => 'Deskjet K209a',
      'id' => 57,
    ),
    6 => 
    array (
      'name' => 'Officejet 4255',
      'id' => 2884,
    ),
    7 => 
    array (
      'name' => 'OfficeJet 4308',
      'id' => 54,
    ),
    8 => 
    array (
      'name' => 'Officejet 4500',
      'id' => 70,
    ),
    9 => 
    array (
      'name' => 'Officejet 5608',
      'id' => 2885,
    ),
    10 => 
    array (
      'name' => 'Officejet 5679',
      'id' => 2886,
    ),
    11 => 
    array (
      'name' => 'Officejet 6318',
      'id' => 2903,
    ),
    12 => 
    array (
      'name' => 'Officejet J4580',
      'id' => 56,
    ),
    13 => 
    array (
      'name' => 'OfficeJet J4660',
      'id' => 58,
    ),
    14 => 
    array (
      'name' => 'Officejet4500/J4580/J4660',
      'id' => 2931,
    ),
    15 => 
    array (
      'name' => 'OfficejetJ3606/J3608/J5508',
      'id' => 2891,
    ),
    16 => 
    array (
      'name' => 'OfficejetJ3606/J3608/J5508',
      'id' => 2892,
    ),
    17 => 
    array (
      'name' => 'Photosmart 2578/C4188',
      'id' => 2902,
    ),
    18 => 
    array (
      'name' => 'Photosmart 3108/3308',
      'id' => 2909,
    ),
    19 => 
    array (
      'name' => 'Photosmart 7760',
      'id' => 2887,
    ),
    20 => 
    array (
      'name' => 'Photosmart C309a',
      'id' => 60,
    ),
    21 => 
    array (
      'name' => 'Photosmart C4688',
      'id' => 63,
    ),
    22 => 
    array (
      'name' => 'Photosmart C4788',
      'id' => 64,
    ),
    23 => 
    array (
      'name' => 'Photosmart C5388',
      'id' => 59,
    ),
    24 => 
    array (
      'name' => 'Photosmart Plus B209a',
      'id' => 2901,
    ),
    25 => 
    array (
      'name' => 'PSC 2310',
      'id' => 2888,
    ),
    26 => 
    array (
      'name' => 'PSC1118/1218/1318/1406/1408',
      'id' => 2934,
    ),
  ),
  157 => 
  array (
    0 => 
    array (
      'name' => 'c700',
      'id' => 2440,
    ),
    1 => 
    array (
      'name' => 'c702',
      'id' => 2439,
    ),
  ),
  198 => 
  array (
    0 => 
    array (
      'name' => 'Canon ���� EOS 1000D KIT (��18-55 IS ������ͷ) ��������׻�',
      'id' => 2800,
    ),
    1 => 
    array (
      'name' => 'Canon ���� EOS 1000D ����',
      'id' => 2792,
    ),
    2 => 
    array (
      'name' => 'Canon ���� EOS 450D ���������EF-S18-200/3.5-5.6IS���׻�',
      'id' => 2801,
    ),
    3 => 
    array (
      'name' => 'Canon ���� EOS 450D �׻���EF-S18-55 IS��ͷ���������',
      'id' => 2789,
    ),
    4 => 
    array (
      'name' => 'Canon ���� EOS 500D ������� 18-200IS �׻�',
      'id' => 2803,
    ),
    5 => 
    array (
      'name' => 'Canon ���� EOS 500D ������� ����',
      'id' => 2797,
    ),
    6 => 
    array (
      'name' => 'Canon ���� EOS 500D �������EF-S 18-55IS�׻�',
      'id' => 2787,
    ),
    7 => 
    array (
      'name' => 'Canon ���� EOS 50D �����׻�EFS 18-200/3.5-5.6IS',
      'id' => 2790,
    ),
    8 => 
    array (
      'name' => 'Canon ���� EOS 50D ����������׻�����EFS 18-135mm/3.5-5.6IS',
      'id' => 2796,
    ),
    9 => 
    array (
      'name' => 'Canon ���� EOS 50D ���ص������ (����)',
      'id' => 2802,
    ),
    10 => 
    array (
      'name' => 'Canon ���� EOS 550D ��������� �����׻�(EF-S 18-135 IS)',
      'id' => 2808,
    ),
    11 => 
    array (
      'name' => 'Canon ���� EOS 550D ��������',
      'id' => 2793,
    ),
    12 => 
    array (
      'name' => 'Canon ���� EOS 550D �����׻���EF-S 18-135 IS��',
      'id' => 2791,
    ),
    13 => 
    array (
      'name' => 'Canon ���� EOS 550D �����׻���EF-S 18-55 IS��',
      'id' => 2788,
    ),
    14 => 
    array (
      'name' => 'Canon ���� EOS 5D Mark II (EF 24-105mm f/4L IS USM)',
      'id' => 2798,
    ),
    15 => 
    array (
      'name' => 'Canon ���� EOS 5D Mark II ��������',
      'id' => 2794,
    ),
    16 => 
    array (
      'name' => 'Canon ���� EOS 7D �����������',
      'id' => 2799,
    ),
    17 => 
    array (
      'name' => 'Canon ���� EOS 7D ��������׻�����15-85mm f/3.5-5.6 IS USM��ͷ',
      'id' => 2804,
    ),
    18 => 
    array (
      'name' => 'Canon ���� EOS 7D ��������׻�����18-135mm f/3.5-5.6 IS ��ͷ��',
      'id' => 2795,
    ),
    19 => 
    array (
      'name' => 'Canon ���� EOS-1D Mark III 1010�������������(����)',
      'id' => 2806,
    ),
    20 => 
    array (
      'name' => 'Canon ���� EOS-1D Mark IV �������',
      'id' => 2805,
    ),
    21 => 
    array (
      'name' => 'Canon ���� EOS-1Ds MARK III 2110�������������(����)',
      'id' => 2807,
    ),
  ),
  3 => 
  array (
    0 => 
    array (
      'name' => 'CM1015/1017mfp',
      'id' => 2925,
    ),
    1 => 
    array (
      'name' => 'Color LaserJet CM1312',
      'id' => 51,
    ),
    2 => 
    array (
      'name' => 'Color LaserJet CM1312nfi',
      'id' => 49,
    ),
    3 => 
    array (
      'name' => 'LaserJet M1005',
      'id' => 43,
    ),
    4 => 
    array (
      'name' => 'LaserJet M1319F',
      'id' => 47,
    ),
    5 => 
    array (
      'name' => 'LaserJet M1522nf',
      'id' => 46,
    ),
    6 => 
    array (
      'name' => 'LaserJet M2727nf',
      'id' => 45,
    ),
    7 => 
    array (
      'name' => 'LaserJet M2727nfs',
      'id' => 50,
    ),
    8 => 
    array (
      'name' => 'LaserJet Pro 1536',
      'id' => 2961,
    ),
    9 => 
    array (
      'name' => 'LaserJet Pro M1136',
      'id' => 53,
    ),
  ),
  66 => 
  array (
    0 => 
    array (
      'name' => 'CQ20',
      'id' => 2079,
    ),
    1 => 
    array (
      'name' => 'CQ32',
      'id' => 2096,
    ),
    2 => 
    array (
      'name' => 'CQ321',
      'id' => 2088,
    ),
    3 => 
    array (
      'name' => 'CQ36',
      'id' => 2082,
    ),
    4 => 
    array (
      'name' => 'CQ40',
      'id' => 2075,
    ),
    5 => 
    array (
      'name' => 'CQ41',
      'id' => 2087,
    ),
    6 => 
    array (
      'name' => 'CQ42',
      'id' => 2073,
    ),
    7 => 
    array (
      'name' => 'CQ510',
      'id' => 2083,
    ),
    8 => 
    array (
      'name' => 'CQ511',
      'id' => 2078,
    ),
    9 => 
    array (
      'name' => 'CQ515',
      'id' => 2072,
    ),
    10 => 
    array (
      'name' => 'CQ516',
      'id' => 2089,
    ),
    11 => 
    array (
      'name' => 'CQ61',
      'id' => 2076,
    ),
    12 => 
    array (
      'name' => 'CQ621',
      'id' => 2092,
    ),
  ),
  160 => 
  array (
    0 => 
    array (
      'name' => 'D08',
      'id' => 2493,
    ),
    1 => 
    array (
      'name' => 'd16',
      'id' => 2483,
    ),
    2 => 
    array (
      'name' => 'D18',
      'id' => 2495,
    ),
    3 => 
    array (
      'name' => 'D21',
      'id' => 2486,
    ),
    4 => 
    array (
      'name' => 'D280',
      'id' => 2456,
    ),
    5 => 
    array (
      'name' => 'D508',
      'id' => 2454,
    ),
    6 => 
    array (
      'name' => 'D510',
      'id' => 2453,
    ),
    7 => 
    array (
      'name' => 'D520',
      'id' => 2455,
    ),
    8 => 
    array (
      'name' => 'D550',
      'id' => 2451,
    ),
    9 => 
    array (
      'name' => 'D60',
      'id' => 2490,
    ),
  ),
  48 => 
  array (
    0 => 
    array (
      'name' => 'D3000',
      'id' => 444,
    ),
    1 => 
    array (
      'name' => 'D300S',
      'id' => 443,
    ),
    2 => 
    array (
      'name' => 'D3S',
      'id' => 438,
    ),
    3 => 
    array (
      'name' => 'D3X',
      'id' => 454,
    ),
    4 => 
    array (
      'name' => 'D5000',
      'id' => 445,
    ),
    5 => 
    array (
      'name' => 'D60',
      'id' => 471,
    ),
    6 => 
    array (
      'name' => 'D700',
      'id' => 461,
    ),
    7 => 
    array (
      'name' => 'D90',
      'id' => 455,
    ),
  ),
  342 => 
  array (
    0 => 
    array (
      'name' => 'D750',
      'id' => 3706,
    ),
  ),
  197 => 
  array (
    0 => 
    array (
      'name' => 'd788',
      'id' => 2783,
    ),
    1 => 
    array (
      'name' => 'D788',
      'id' => 2694,
    ),
    2 => 
    array (
      'name' => 'd988',
      'id' => 2688,
    ),
    3 => 
    array (
      'name' => 'd988',
      'id' => 2782,
    ),
    4 => 
    array (
      'name' => 'f278',
      'id' => 2689,
    ),
  ),
  155 => 
  array (
    0 => 
    array (
      'name' => 'd900',
      'id' => 2432,
    ),
    1 => 
    array (
      'name' => 'd908',
      'id' => 2431,
    ),
  ),
  18 => 
  array (
    0 => 
    array (
      'name' => 'DCP7010/DCP7025',
      'id' => 2955,
    ),
    1 => 
    array (
      'name' => 'DCP-7030',
      'id' => 246,
    ),
    2 => 
    array (
      'name' => 'HL2040/HL2070N/HL2045/HL2075N',
      'id' => 2954,
    ),
    3 => 
    array (
      'name' => 'MFC-7220',
      'id' => 247,
    ),
    4 => 
    array (
      'name' => 'MFC-7340',
      'id' => 245,
    ),
    5 => 
    array (
      'name' => 'MFC7420/7220',
      'id' => 2956,
    ),
    6 => 
    array (
      'name' => 'MFC-7450',
      'id' => 226,
    ),
  ),
  68 => 
  array (
    0 => 
    array (
      'name' => 'dm1',
      'id' => 1128,
    ),
    1 => 
    array (
      'name' => 'dm3',
      'id' => 2106,
    ),
    2 => 
    array (
      'name' => 'dm4',
      'id' => 2105,
    ),
  ),
  67 => 
  array (
    0 => 
    array (
      'name' => 'dv3',
      'id' => 2097,
    ),
    1 => 
    array (
      'name' => 'dv6',
      'id' => 2098,
    ),
  ),
  302 => 
  array (
    0 => 
    array (
      'name' => 'E1000',
      'id' => 3330,
    ),
    1 => 
    array (
      'name' => 'E1070',
      'id' => 3332,
    ),
    2 => 
    array (
      'name' => 'E11',
      'id' => 3329,
    ),
    3 => 
    array (
      'name' => 'E2',
      'id' => 3315,
    ),
    4 => 
    array (
      'name' => 'E6',
      'id' => 3314,
    ),
    5 => 
    array (
      'name' => 'E6e',
      'id' => 3328,
    ),
    6 => 
    array (
      'name' => 'E770',
      'id' => 3331,
    ),
    7 => 
    array (
      'name' => 'E8',
      'id' => 3316,
    ),
  ),
  156 => 
  array (
    0 => 
    array (
      'name' => 'e102',
      'id' => 2437,
    ),
  ),
  183 => 
  array (
    0 => 
    array (
      'name' => 'E1050',
      'id' => 3376,
    ),
    1 => 
    array (
      'name' => 'e1070c',
      'id' => 2635,
    ),
    2 => 
    array (
      'name' => 'E1080C',
      'id' => 3390,
    ),
    3 => 
    array (
      'name' => 'E1088c',
      'id' => 2593,
    ),
    4 => 
    array (
      'name' => 'E1100c',
      'id' => 2637,
    ),
    5 => 
    array (
      'name' => 'e1101c',
      'id' => 2607,
    ),
    6 => 
    array (
      'name' => 'e1110c',
      'id' => 2665,
    ),
    7 => 
    array (
      'name' => 'e1113c',
      'id' => 2666,
    ),
    8 => 
    array (
      'name' => 'e1120c',
      'id' => 2623,
    ),
    9 => 
    array (
      'name' => 'E1150c',
      'id' => 2591,
    ),
    10 => 
    array (
      'name' => 'E1178',
      'id' => 2579,
    ),
    11 => 
    array (
      'name' => 'e1220',
      'id' => 2572,
    ),
    12 => 
    array (
      'name' => 'e1310c',
      'id' => 2619,
    ),
    13 => 
    array (
      'name' => 'e1360c',
      'id' => 2618,
    ),
    14 => 
    array (
      'name' => 'E189',
      'id' => 2590,
    ),
    15 => 
    array (
      'name' => 'e2100c',
      'id' => 2633,
    ),
    16 => 
    array (
      'name' => 'e2120c',
      'id' => 2602,
    ),
    17 => 
    array (
      'name' => 'e2210c',
      'id' => 2620,
    ),
    18 => 
    array (
      'name' => 'E251C',
      'id' => 2699,
    ),
    19 => 
    array (
      'name' => 'E2558',
      'id' => 3404,
    ),
    20 => 
    array (
      'name' => 'E2652',
      'id' => 3379,
    ),
    21 => 
    array (
      'name' => 'E3210',
      'id' => 3408,
    ),
    22 => 
    array (
      'name' => 'e848i',
      'id' => 2683,
    ),
  ),
  124 => 
  array (
    0 => 
    array (
      'name' => 'e106',
      'id' => 2184,
    ),
    1 => 
    array (
      'name' => 'e118',
      'id' => 2242,
    ),
    2 => 
    array (
      'name' => 'e156',
      'id' => 2150,
    ),
    3 => 
    array (
      'name' => 'e160c',
      'id' => 2148,
    ),
    4 => 
    array (
      'name' => 'e206',
      'id' => 2408,
    ),
    5 => 
    array (
      'name' => 'e210',
      'id' => 2397,
    ),
    6 => 
    array (
      'name' => 'e212',
      'id' => 2355,
    ),
    7 => 
    array (
      'name' => 'e216',
      'id' => 2415,
    ),
    8 => 
    array (
      'name' => 'e217',
      'id' => 2393,
    ),
    9 => 
    array (
      'name' => 'e218',
      'id' => 2166,
    ),
    10 => 
    array (
      'name' => 'e228',
      'id' => 2241,
    ),
    11 => 
    array (
      'name' => 'e260c',
      'id' => 2165,
    ),
    12 => 
    array (
      'name' => 'e268',
      'id' => 2152,
    ),
    13 => 
    array (
      'name' => 'e280',
      'id' => 2347,
    ),
    14 => 
    array (
      'name' => 'e300c',
      'id' => 2256,
    ),
    15 => 
    array (
      'name' => 'e369',
      'id' => 2398,
    ),
    16 => 
    array (
      'name' => 'e520',
      'id' => 2365,
    ),
    17 => 
    array (
      'name' => 'e55��ͨ��',
      'id' => 2205,
    ),
  ),
  340 => 
  array (
    0 => 
    array (
      'name' => 'E15i',
      'id' => 3662,
    ),
    1 => 
    array (
      'name' => 'E16i',
      'id' => 3663,
    ),
  ),
  159 => 
  array (
    0 => 
    array (
      'name' => 'E200',
      'id' => 2461,
    ),
    1 => 
    array (
      'name' => 'E210',
      'id' => 2459,
    ),
    2 => 
    array (
      'name' => 'E230',
      'id' => 2450,
    ),
    3 => 
    array (
      'name' => 'E270',
      'id' => 2448,
    ),
    4 => 
    array (
      'name' => 'E28',
      'id' => 2482,
    ),
    5 => 
    array (
      'name' => 'E570',
      'id' => 2449,
    ),
    6 => 
    array (
      'name' => 'E600',
      'id' => 2460,
    ),
  ),
  54 => 
  array (
    0 => 
    array (
      'name' => 'E30',
      'id' => 405,
    ),
    1 => 
    array (
      'name' => 'E420',
      'id' => 416,
    ),
    2 => 
    array (
      'name' => 'E430',
      'id' => 418,
    ),
    3 => 
    array (
      'name' => 'E450',
      'id' => 380,
    ),
    4 => 
    array (
      'name' => 'E520',
      'id' => 414,
    ),
    5 => 
    array (
      'name' => 'E600',
      'id' => 379,
    ),
    6 => 
    array (
      'name' => 'E620',
      'id' => 393,
    ),
    7 => 
    array (
      'name' => 'E-P1',
      'id' => 390,
    ),
    8 => 
    array (
      'name' => 'E-P2',
      'id' => 378,
    ),
  ),
  46 => 
  array (
    0 => 
    array (
      'name' => 'E3010',
      'id' => 401,
    ),
    1 => 
    array (
      'name' => 'E-PL1',
      'id' => 372,
    ),
    2 => 
    array (
      'name' => 'FE20',
      'id' => 406,
    ),
    3 => 
    array (
      'name' => 'FE220',
      'id' => 415,
    ),
    4 => 
    array (
      'name' => 'FE26',
      'id' => 388,
    ),
    5 => 
    array (
      'name' => 'FE3000',
      'id' => 402,
    ),
    6 => 
    array (
      'name' => 'FE310',
      'id' => 429,
    ),
    7 => 
    array (
      'name' => 'FE320',
      'id' => 428,
    ),
    8 => 
    array (
      'name' => 'FE330',
      'id' => 427,
    ),
    9 => 
    array (
      'name' => 'FE340',
      'id' => 426,
    ),
    10 => 
    array (
      'name' => 'FE350',
      'id' => 425,
    ),
    11 => 
    array (
      'name' => 'FE360',
      'id' => 412,
    ),
    12 => 
    array (
      'name' => 'FE370',
      'id' => 411,
    ),
    13 => 
    array (
      'name' => 'FE4000',
      'id' => 385,
    ),
    14 => 
    array (
      'name' => 'FE4010',
      'id' => 386,
    ),
    15 => 
    array (
      'name' => 'FE45',
      'id' => 394,
    ),
    16 => 
    array (
      'name' => 'FE46',
      'id' => 389,
    ),
    17 => 
    array (
      'name' => 'FE5000',
      'id' => 391,
    ),
    18 => 
    array (
      'name' => 'FE5010',
      'id' => 403,
    ),
    19 => 
    array (
      'name' => 'FE5020',
      'id' => 387,
    ),
    20 => 
    array (
      'name' => 'SP565 UZ',
      'id' => 409,
    ),
    21 => 
    array (
      'name' => 'SP570 UZ',
      'id' => 419,
    ),
    22 => 
    array (
      'name' => 'SP590 UZ',
      'id' => 404,
    ),
    23 => 
    array (
      'name' => 'SP600 UZ',
      'id' => 369,
    ),
    24 => 
    array (
      'name' => 'SP800 UZ',
      'id' => 371,
    ),
    25 => 
    array (
      'name' => 'X775',
      'id' => 413,
    ),
    26 => 
    array (
      'name' => 'X-775',
      'id' => 417,
    ),
    27 => 
    array (
      'name' => 'X935',
      'id' => 381,
    ),
    28 => 
    array (
      'name' => '��1010',
      'id' => 423,
    ),
    29 => 
    array (
      'name' => '��1020',
      'id' => 422,
    ),
    30 => 
    array (
      'name' => '��1030SW',
      'id' => 420,
    ),
    31 => 
    array (
      'name' => '��1040',
      'id' => 407,
    ),
    32 => 
    array (
      'name' => '��1050SW',
      'id' => 408,
    ),
    33 => 
    array (
      'name' => '��1060',
      'id' => 410,
    ),
    34 => 
    array (
      'name' => '��1070',
      'id' => 392,
    ),
    35 => 
    array (
      'name' => '��3000',
      'id' => 376,
    ),
    36 => 
    array (
      'name' => '��5000',
      'id' => 395,
    ),
    37 => 
    array (
      'name' => '��5010',
      'id' => 373,
    ),
    38 => 
    array (
      'name' => '��550WP',
      'id' => 398,
    ),
    39 => 
    array (
      'name' => '��6000',
      'id' => 399,
    ),
    40 => 
    array (
      'name' => '��6010',
      'id' => 382,
    ),
    41 => 
    array (
      'name' => '��7000',
      'id' => 396,
    ),
    42 => 
    array (
      'name' => '��7010',
      'id' => 383,
    ),
    43 => 
    array (
      'name' => '��7020',
      'id' => 384,
    ),
    44 => 
    array (
      'name' => '��7030',
      'id' => 374,
    ),
    45 => 
    array (
      'name' => '��7040',
      'id' => 375,
    ),
    46 => 
    array (
      'name' => '��8000',
      'id' => 400,
    ),
    47 => 
    array (
      'name' => '��8010',
      'id' => 370,
    ),
    48 => 
    array (
      'name' => '��840',
      'id' => 424,
    ),
    49 => 
    array (
      'name' => '��850SW',
      'id' => 421,
    ),
    50 => 
    array (
      'name' => '��9000',
      'id' => 397,
    ),
    51 => 
    array (
      'name' => '��9010',
      'id' => 377,
    ),
  ),
  60 => 
  array (
    0 => 
    array (
      'name' => 'E40 05788MC',
      'id' => 683,
    ),
  ),
  115 => 
  array (
    0 => 
    array (
      'name' => 'E50',
      'id' => 3251,
    ),
    1 => 
    array (
      'name' => 'E5-00',
      'id' => 2977,
    ),
    2 => 
    array (
      'name' => 'E5-00',
      'id' => 2996,
    ),
    3 => 
    array (
      'name' => 'E51',
      'id' => 3097,
    ),
    4 => 
    array (
      'name' => 'e52',
      'id' => 2113,
    ),
    5 => 
    array (
      'name' => 'E55',
      'id' => 3137,
    ),
    6 => 
    array (
      'name' => 'E60',
      'id' => 3271,
    ),
    7 => 
    array (
      'name' => 'E6-00',
      'id' => 3155,
    ),
    8 => 
    array (
      'name' => 'E61',
      'id' => 3148,
    ),
    9 => 
    array (
      'name' => 'E61i',
      'id' => 3152,
    ),
    10 => 
    array (
      'name' => 'E62',
      'id' => 3149,
    ),
    11 => 
    array (
      'name' => 'e63',
      'id' => 2115,
    ),
    12 => 
    array (
      'name' => 'E65',
      'id' => 3199,
    ),
    13 => 
    array (
      'name' => 'e66',
      'id' => 2116,
    ),
    14 => 
    array (
      'name' => 'E70',
      'id' => 3191,
    ),
    15 => 
    array (
      'name' => 'E7-00',
      'id' => 2999,
    ),
    16 => 
    array (
      'name' => 'e71',
      'id' => 2117,
    ),
    17 => 
    array (
      'name' => 'E71X',
      'id' => 3138,
    ),
    18 => 
    array (
      'name' => 'e72',
      'id' => 2121,
    ),
    19 => 
    array (
      'name' => 'e72i',
      'id' => 2118,
    ),
    20 => 
    array (
      'name' => 'E73',
      'id' => 3153,
    ),
    21 => 
    array (
      'name' => 'E75',
      'id' => 3087,
    ),
    22 => 
    array (
      'name' => 'E90',
      'id' => 3139,
    ),
    23 => 
    array (
      'name' => 'E95',
      'id' => 3140,
    ),
    24 => 
    array (
      'name' => 'N97',
      'id' => 3154,
    ),
  ),
  325 => 
  array (
    0 => 
    array (
      'name' => 'E5805',
      'id' => 3421,
    ),
  ),
  81 => 
  array (
    0 => 
    array (
      'name' => 'EA200C(P54027249)',
      'id' => 1960,
    ),
    1 => 
    array (
      'name' => 'EA25EC/BI',
      'id' => 1963,
    ),
    2 => 
    array (
      'name' => 'EA25EC/PI',
      'id' => 1962,
    ),
    3 => 
    array (
      'name' => 'EA25EC/T',
      'id' => 1964,
    ),
    4 => 
    array (
      'name' => 'EA25EC/WI',
      'id' => 1959,
    ),
    5 => 
    array (
      'name' => 'EA28EC/B',
      'id' => 1956,
    ),
    6 => 
    array (
      'name' => 'EA28EC/P',
      'id' => 1958,
    ),
    7 => 
    array (
      'name' => 'EA28EC/W',
      'id' => 1957,
    ),
    8 => 
    array (
      'name' => 'VPCEA27EC/B',
      'id' => 1961,
    ),
  ),
  82 => 
  array (
    0 => 
    array (
      'name' => 'EB25EC/T',
      'id' => 1969,
    ),
    1 => 
    array (
      'name' => 'EB25EC/WI',
      'id' => 1968,
    ),
    2 => 
    array (
      'name' => 'EB27EC/PI',
      'id' => 1966,
    ),
    3 => 
    array (
      'name' => 'EB27EC/T',
      'id' => 1967,
    ),
    4 => 
    array (
      'name' => 'EB27EC/WI',
      'id' => 1965,
    ),
  ),
  326 => 
  array (
    0 => 
    array (
      'name' => 'EC5805',
      'id' => 3399,
    ),
  ),
  332 => 
  array (
    0 => 
    array (
      'name' => 'EM25',
      'id' => 3518,
    ),
    1 => 
    array (
      'name' => 'EM30',
      'id' => 3519,
    ),
    2 => 
    array (
      'name' => 'EM325',
      'id' => 3517,
    ),
    3 => 
    array (
      'name' => 'EM330',
      'id' => 3529,
    ),
    4 => 
    array (
      'name' => 'EM35',
      'id' => 3528,
    ),
  ),
  11 => 
  array (
    0 => 
    array (
      'name' => 'Epson LQ-2680K',
      'id' => 2865,
    ),
    1 => 
    array (
      'name' => 'LQ-1600KIIIH',
      'id' => 131,
    ),
    2 => 
    array (
      'name' => 'LQ-630K',
      'id' => 129,
    ),
    3 => 
    array (
      'name' => 'LQ-635K',
      'id' => 130,
    ),
    4 => 
    array (
      'name' => 'LQ-670K+T',
      'id' => 133,
    ),
    5 => 
    array (
      'name' => 'LQ-680K II/2680',
      'id' => 136,
    ),
    6 => 
    array (
      'name' => 'LQ-730K',
      'id' => 132,
    ),
  ),
  51 => 
  array (
    0 => 
    array (
      'name' => 'ES10',
      'id' => 605,
    ),
    1 => 
    array (
      'name' => 'ES17',
      'id' => 592,
    ),
    2 => 
    array (
      'name' => 'ES55',
      'id' => 617,
    ),
    3 => 
    array (
      'name' => 'ES60',
      'id' => 593,
    ),
    4 => 
    array (
      'name' => 'ES70',
      'id' => 583,
    ),
    5 => 
    array (
      'name' => 'EX1',
      'id' => 584,
    ),
    6 => 
    array (
      'name' => 'HZ1',
      'id' => 622,
    ),
    7 => 
    array (
      'name' => 'HZ10W',
      'id' => 620,
    ),
    8 => 
    array (
      'name' => 'i100',
      'id' => 632,
    ),
    9 => 
    array (
      'name' => 'i8',
      'id' => 642,
    ),
    10 => 
    array (
      'name' => 'i80',
      'id' => 631,
    ),
    11 => 
    array (
      'name' => 'IT100',
      'id' => 603,
    ),
    12 => 
    array (
      'name' => 'L100',
      'id' => 641,
    ),
    13 => 
    array (
      'name' => 'L110',
      'id' => 640,
    ),
    14 => 
    array (
      'name' => 'L201',
      'id' => 624,
    ),
    15 => 
    array (
      'name' => 'L210',
      'id' => 639,
    ),
    16 => 
    array (
      'name' => 'L310W',
      'id' => 625,
    ),
    17 => 
    array (
      'name' => 'LS102',
      'id' => 621,
    ),
    18 => 
    array (
      'name' => 'M110',
      'id' => 604,
    ),
    19 => 
    array (
      'name' => 'M310W',
      'id' => 601,
    ),
    20 => 
    array (
      'name' => 'NV100HD',
      'id' => 627,
    ),
    21 => 
    array (
      'name' => 'NV103',
      'id' => 636,
    ),
    22 => 
    array (
      'name' => 'NV106HD',
      'id' => 635,
    ),
    23 => 
    array (
      'name' => 'NV24HD',
      'id' => 628,
    ),
    24 => 
    array (
      'name' => 'NV30',
      'id' => 638,
    ),
    25 => 
    array (
      'name' => 'NV33',
      'id' => 637,
    ),
    26 => 
    array (
      'name' => 'NV9',
      'id' => 626,
    ),
    27 => 
    array (
      'name' => 'PL10',
      'id' => 607,
    ),
    28 => 
    array (
      'name' => 'PL150',
      'id' => 585,
    ),
    29 => 
    array (
      'name' => 'PL50',
      'id' => 609,
    ),
    30 => 
    array (
      'name' => 'PL51',
      'id' => 591,
    ),
    31 => 
    array (
      'name' => 'PL55',
      'id' => 599,
    ),
    32 => 
    array (
      'name' => 'PL60',
      'id' => 616,
    ),
    33 => 
    array (
      'name' => 'PL65',
      'id' => 602,
    ),
    34 => 
    array (
      'name' => 'PL70',
      'id' => 598,
    ),
    35 => 
    array (
      'name' => 'S1060',
      'id' => 629,
    ),
    36 => 
    array (
      'name' => 'S1070',
      'id' => 623,
    ),
    37 => 
    array (
      'name' => 'S760',
      'id' => 633,
    ),
    38 => 
    array (
      'name' => 'S860',
      'id' => 634,
    ),
    39 => 
    array (
      'name' => 'SL202',
      'id' => 613,
    ),
    40 => 
    array (
      'name' => 'SL30',
      'id' => 612,
    ),
    41 => 
    array (
      'name' => 'SL620',
      'id' => 614,
    ),
    42 => 
    array (
      'name' => 'SL820',
      'id' => 615,
    ),
    43 => 
    array (
      'name' => 'ST10',
      'id' => 608,
    ),
    44 => 
    array (
      'name' => 'ST1000',
      'id' => 595,
    ),
    45 => 
    array (
      'name' => 'ST50',
      'id' => 618,
    ),
    46 => 
    array (
      'name' => 'ST500',
      'id' => 596,
    ),
    47 => 
    array (
      'name' => 'ST5000',
      'id' => 586,
    ),
    48 => 
    array (
      'name' => 'ST550',
      'id' => 597,
    ),
    49 => 
    array (
      'name' => 'ST5500',
      'id' => 589,
    ),
    50 => 
    array (
      'name' => 'ST60',
      'id' => 580,
    ),
    51 => 
    array (
      'name' => 'ST70',
      'id' => 579,
    ),
    52 => 
    array (
      'name' => 'TL320',
      'id' => 610,
    ),
    53 => 
    array (
      'name' => 'WB100',
      'id' => 611,
    ),
    54 => 
    array (
      'name' => 'WB1000',
      'id' => 600,
    ),
    55 => 
    array (
      'name' => 'WB2000',
      'id' => 588,
    ),
    56 => 
    array (
      'name' => 'WB500',
      'id' => 619,
    ),
    57 => 
    array (
      'name' => 'WB5000',
      'id' => 594,
    ),
    58 => 
    array (
      'name' => 'WB550',
      'id' => 606,
    ),
    59 => 
    array (
      'name' => 'WB600',
      'id' => 582,
    ),
    60 => 
    array (
      'name' => 'WB650',
      'id' => 581,
    ),
    61 => 
    array (
      'name' => 'WP10',
      'id' => 587,
    ),
  ),
  127 => 
  array (
    0 => 
    array (
      'name' => 'et10',
      'id' => 2153,
    ),
    1 => 
    array (
      'name' => 'et600',
      'id' => 2407,
    ),
    2 => 
    array (
      'name' => 'et60c',
      'id' => 2159,
    ),
    3 => 
    array (
      'name' => 'et60������',
      'id' => 2190,
    ),
    4 => 
    array (
      'name' => 'et60��Ӣ��',
      'id' => 2193,
    ),
    5 => 
    array (
      'name' => 'et660',
      'id' => 2341,
    ),
    6 => 
    array (
      'name' => 'et660��Լ��',
      'id' => 2236,
    ),
    7 => 
    array (
      'name' => 'et700',
      'id' => 2338,
    ),
    8 => 
    array (
      'name' => 'et860',
      'id' => 2373,
    ),
    9 => 
    array (
      'name' => 'et880���Ӱ�',
      'id' => 2356,
    ),
    10 => 
    array (
      'name' => 'et880���ư�',
      'id' => 2357,
    ),
    11 => 
    array (
      'name' => 'et980',
      'id' => 2348,
    ),
  ),
  310 => 
  array (
    0 => 
    array (
      'name' => 'EX112',
      'id' => 3480,
    ),
    1 => 
    array (
      'name' => 'EX115',
      'id' => 3492,
    ),
    2 => 
    array (
      'name' => 'EX128',
      'id' => 3481,
    ),
    3 => 
    array (
      'name' => 'EX200',
      'id' => 3482,
    ),
    4 => 
    array (
      'name' => 'EX201',
      'id' => 3493,
    ),
    5 => 
    array (
      'name' => 'EX210',
      'id' => 3504,
    ),
    6 => 
    array (
      'name' => 'EX211',
      'id' => 3505,
    ),
    7 => 
    array (
      'name' => 'EX245',
      'id' => 3483,
    ),
    8 => 
    array (
      'name' => 'EX300',
      'id' => 3506,
    ),
  ),
  44 => 
  array (
    0 => 
    array (
      'name' => 'F1',
      'id' => 349,
    ),
    1 => 
    array (
      'name' => 'FC100',
      'id' => 337,
    ),
    2 => 
    array (
      'name' => 'FH100',
      'id' => 323,
    ),
    3 => 
    array (
      'name' => 'FH20',
      'id' => 338,
    ),
    4 => 
    array (
      'name' => 'FH25',
      'id' => 325,
    ),
    5 => 
    array (
      'name' => 'FS10',
      'id' => 336,
    ),
    6 => 
    array (
      'name' => 'G1',
      'id' => 324,
    ),
    7 => 
    array (
      'name' => 'H10',
      'id' => 329,
    ),
    8 => 
    array (
      'name' => 'H15',
      'id' => 322,
    ),
    9 => 
    array (
      'name' => 'S10',
      'id' => 350,
    ),
    10 => 
    array (
      'name' => 'S12',
      'id' => 333,
    ),
    11 => 
    array (
      'name' => 'S5',
      'id' => 332,
    ),
    12 => 
    array (
      'name' => 'S7',
      'id' => 318,
    ),
    13 => 
    array (
      'name' => 'S8',
      'id' => 317,
    ),
    14 => 
    array (
      'name' => 'Z100',
      'id' => 346,
    ),
    15 => 
    array (
      'name' => 'Z11',
      'id' => 345,
    ),
    16 => 
    array (
      'name' => 'Z150',
      'id' => 340,
    ),
    17 => 
    array (
      'name' => 'Z2',
      'id' => 330,
    ),
    18 => 
    array (
      'name' => 'Z20',
      'id' => 339,
    ),
    19 => 
    array (
      'name' => 'Z200',
      'id' => 348,
    ),
    20 => 
    array (
      'name' => 'Z2000',
      'id' => 321,
    ),
    21 => 
    array (
      'name' => 'Z250',
      'id' => 342,
    ),
    22 => 
    array (
      'name' => 'Z270',
      'id' => 334,
    ),
    23 => 
    array (
      'name' => 'Z280',
      'id' => 328,
    ),
    24 => 
    array (
      'name' => 'Z29',
      'id' => 331,
    ),
    25 => 
    array (
      'name' => 'Z300',
      'id' => 343,
    ),
    26 => 
    array (
      'name' => 'Z33',
      'id' => 319,
    ),
    27 => 
    array (
      'name' => 'Z330',
      'id' => 316,
    ),
    28 => 
    array (
      'name' => 'Z400',
      'id' => 335,
    ),
    29 => 
    array (
      'name' => 'Z450',
      'id' => 327,
    ),
    30 => 
    array (
      'name' => 'Z550',
      'id' => 320,
    ),
    31 => 
    array (
      'name' => 'Z8',
      'id' => 351,
    ),
    32 => 
    array (
      'name' => 'Z80',
      'id' => 347,
    ),
    33 => 
    array (
      'name' => 'Z85',
      'id' => 341,
    ),
    34 => 
    array (
      'name' => 'Z9',
      'id' => 344,
    ),
    35 => 
    array (
      'name' => 'Z90',
      'id' => 326,
    ),
  ),
  341 => 
  array (
    0 => 
    array (
      'name' => 'F100',
      'id' => 3689,
    ),
    1 => 
    array (
      'name' => 'F305',
      'id' => 3688,
    ),
    2 => 
    array (
      'name' => 'F500',
      'id' => 3687,
    ),
  ),
  184 => 
  array (
    0 => 
    array (
      'name' => 'f268',
      'id' => 2701,
    ),
    1 => 
    array (
      'name' => 'f299',
      'id' => 2596,
    ),
    2 => 
    array (
      'name' => 'f309',
      'id' => 2664,
    ),
    3 => 
    array (
      'name' => 'f339',
      'id' => 2757,
    ),
    4 => 
    array (
      'name' => 'F488e',
      'id' => 2698,
    ),
    5 => 
    array (
      'name' => 'F488E',
      'id' => 3538,
    ),
    6 => 
    array (
      'name' => 'f539',
      'id' => 2769,
    ),
    7 => 
    array (
      'name' => 'f619',
      'id' => 2756,
    ),
    8 => 
    array (
      'name' => 'f669',
      'id' => 2651,
    ),
    9 => 
    array (
      'name' => 'F689',
      'id' => 2659,
    ),
    10 => 
    array (
      'name' => 'f809',
      'id' => 2735,
    ),
    11 => 
    array (
      'name' => 'f839',
      'id' => 2760,
    ),
    12 => 
    array (
      'name' => 'f859',
      'id' => 2729,
    ),
    13 => 
    array (
      'name' => 'g258',
      'id' => 2717,
    ),
  ),
  337 => 
  array (
    0 => 
    array (
      'name' => 'F3',
      'id' => 3545,
    ),
  ),
  136 => 
  array (
    0 => 
    array (
      'name' => 'f310',
      'id' => 2204,
    ),
  ),
  148 => 
  array (
    0 => 
    array (
      'name' => 'F3188',
      'id' => 2321,
    ),
  ),
  162 => 
  array (
    0 => 
    array (
      'name' => 'F603',
      'id' => 2470,
    ),
    1 => 
    array (
      'name' => 'F608',
      'id' => 2471,
    ),
    2 => 
    array (
      'name' => 'F61',
      'id' => 2468,
    ),
    3 => 
    array (
      'name' => 'F620',
      'id' => 2466,
    ),
    4 => 
    array (
      'name' => 'F668',
      'id' => 2469,
    ),
    5 => 
    array (
      'name' => 'F69',
      'id' => 2474,
    ),
    6 => 
    array (
      'name' => 'F800',
      'id' => 2479,
    ),
    7 => 
    array (
      'name' => 'F801',
      'id' => 2467,
    ),
  ),
  154 => 
  array (
    0 => 
    array (
      'name' => 'f610',
      'id' => 2423,
    ),
  ),
  95 => 
  array (
    0 => 
    array (
      'name' => 'F6K44Ve-SL',
      'id' => 1925,
    ),
    1 => 
    array (
      'name' => 'F6K66Ve-SL/32NRYFXW',
      'id' => 1924,
    ),
  ),
  24 => 
  array (
    0 => 
    array (
      'name' => 'FAX-358',
      'id' => 991,
    ),
    1 => 
    array (
      'name' => 'FAX-418',
      'id' => 989,
    ),
    2 => 
    array (
      'name' => 'FAX428MC',
      'id' => 993,
    ),
    3 => 
    array (
      'name' => 'FAX-888',
      'id' => 992,
    ),
  ),
  75 => 
  array (
    0 => 
    array (
      'name' => 'FAX-829',
      'id' => 1532,
    ),
    1 => 
    array (
      'name' => 'FAX-878',
      'id' => 1534,
    ),
  ),
  26 => 
  array (
    0 => 
    array (
      'name' => 'FAX-JX210P',
      'id' => 978,
    ),
    1 => 
    array (
      'name' => 'FAX-JX510P',
      'id' => 980,
    ),
  ),
  49 => 
  array (
    0 => 
    array (
      'name' => 'FH1',
      'id' => 477,
    ),
    1 => 
    array (
      'name' => 'FH22',
      'id' => 474,
    ),
    2 => 
    array (
      'name' => 'FH3',
      'id' => 473,
    ),
    3 => 
    array (
      'name' => 'FP1',
      'id' => 480,
    ),
    4 => 
    array (
      'name' => 'FP2',
      'id' => 481,
    ),
    5 => 
    array (
      'name' => 'FP3',
      'id' => 482,
    ),
    6 => 
    array (
      'name' => 'FP8',
      'id' => 485,
    ),
    7 => 
    array (
      'name' => 'FS15',
      'id' => 505,
    ),
    8 => 
    array (
      'name' => 'FS20',
      'id' => 525,
    ),
    9 => 
    array (
      'name' => 'FS25',
      'id' => 498,
    ),
    10 => 
    array (
      'name' => 'FS3',
      'id' => 526,
    ),
    11 => 
    array (
      'name' => 'FS33',
      'id' => 483,
    ),
    12 => 
    array (
      'name' => 'FS5',
      'id' => 524,
    ),
    13 => 
    array (
      'name' => 'FS6',
      'id' => 504,
    ),
    14 => 
    array (
      'name' => 'FS7',
      'id' => 503,
    ),
    15 => 
    array (
      'name' => 'FT1',
      'id' => 500,
    ),
    16 => 
    array (
      'name' => 'FT2',
      'id' => 475,
    ),
    17 => 
    array (
      'name' => 'FX150',
      'id' => 510,
    ),
    18 => 
    array (
      'name' => 'FX180',
      'id' => 507,
    ),
    19 => 
    array (
      'name' => 'FX35',
      'id' => 523,
    ),
    20 => 
    array (
      'name' => 'FX36',
      'id' => 513,
    ),
    21 => 
    array (
      'name' => 'FX38',
      'id' => 508,
    ),
    22 => 
    array (
      'name' => 'FX40',
      'id' => 496,
    ),
    23 => 
    array (
      'name' => 'FX48',
      'id' => 499,
    ),
    24 => 
    array (
      'name' => 'FX500',
      'id' => 516,
    ),
    25 => 
    array (
      'name' => 'FX520',
      'id' => 518,
    ),
    26 => 
    array (
      'name' => 'FX550',
      'id' => 497,
    ),
    27 => 
    array (
      'name' => 'FX580',
      'id' => 502,
    ),
    28 => 
    array (
      'name' => 'FX65',
      'id' => 486,
    ),
    29 => 
    array (
      'name' => 'FX66',
      'id' => 479,
    ),
    30 => 
    array (
      'name' => 'FZ28',
      'id' => 511,
    ),
    31 => 
    array (
      'name' => 'FZ35',
      'id' => 484,
    ),
    32 => 
    array (
      'name' => 'FZ38',
      'id' => 488,
    ),
    33 => 
    array (
      'name' => 'GF1',
      'id' => 487,
    ),
    34 => 
    array (
      'name' => 'LS80',
      'id' => 517,
    ),
    35 => 
    array (
      'name' => 'LS85',
      'id' => 492,
    ),
    36 => 
    array (
      'name' => 'LX3',
      'id' => 509,
    ),
    37 => 
    array (
      'name' => 'LZ10',
      'id' => 520,
    ),
    38 => 
    array (
      'name' => 'LZ8',
      'id' => 519,
    ),
    39 => 
    array (
      'name' => 'TS1',
      'id' => 491,
    ),
    40 => 
    array (
      'name' => 'TS2',
      'id' => 472,
    ),
    41 => 
    array (
      'name' => 'TZ11',
      'id' => 514,
    ),
    42 => 
    array (
      'name' => 'TZ15',
      'id' => 515,
    ),
    43 => 
    array (
      'name' => 'TZ4',
      'id' => 521,
    ),
    44 => 
    array (
      'name' => 'TZ5',
      'id' => 522,
    ),
    45 => 
    array (
      'name' => 'TZ50',
      'id' => 512,
    ),
    46 => 
    array (
      'name' => 'TZ6',
      'id' => 494,
    ),
    47 => 
    array (
      'name' => 'TZ7',
      'id' => 501,
    ),
    48 => 
    array (
      'name' => 'ZR1',
      'id' => 489,
    ),
    49 => 
    array (
      'name' => 'ZS1',
      'id' => 493,
    ),
    50 => 
    array (
      'name' => 'ZS3',
      'id' => 490,
    ),
    51 => 
    array (
      'name' => 'ZS7',
      'id' => 476,
    ),
    52 => 
    array (
      'name' => 'ZX3',
      'id' => 478,
    ),
  ),
  55 => 
  array (
    0 => 
    array (
      'name' => 'G1',
      'id' => 506,
    ),
    1 => 
    array (
      'name' => 'GH1',
      'id' => 495,
    ),
  ),
  303 => 
  array (
    0 => 
    array (
      'name' => 'G1(Dream)',
      'id' => 2962,
    ),
    1 => 
    array (
      'name' => 'G10(A9191)',
      'id' => 2988,
    ),
    2 => 
    array (
      'name' => 'G11(S710e)',
      'id' => 2963,
    ),
    3 => 
    array (
      'name' => 'G12(Desire S510e)',
      'id' => 2970,
    ),
    4 => 
    array (
      'name' => 'G13(A510E)',
      'id' => 2990,
    ),
    5 => 
    array (
      'name' => 'G14��Z710e��',
      'id' => 2989,
    ),
    6 => 
    array (
      'name' => 'G15(C510E)',
      'id' => 3708,
    ),
    7 => 
    array (
      'name' => 'G16(A810E)',
      'id' => 3715,
    ),
    8 => 
    array (
      'name' => 'G2(A6161/A6188)',
      'id' => 2964,
    ),
    9 => 
    array (
      'name' => 'G3(A6288)',
      'id' => 2965,
    ),
    10 => 
    array (
      'name' => 'G4(A3288)',
      'id' => 2984,
    ),
    11 => 
    array (
      'name' => 'G5(Nexus one)',
      'id' => 2985,
    ),
    12 => 
    array (
      'name' => 'G6(A6363)',
      'id' => 2966,
    ),
    13 => 
    array (
      'name' => 'G7(A8180/A8181)',
      'id' => 2967,
    ),
    14 => 
    array (
      'name' => 'G8(A3366/A3333/A3360)',
      'id' => 2968,
    ),
    15 => 
    array (
      'name' => 'G8(A3380)',
      'id' => 2987,
    ),
    16 => 
    array (
      'name' => 'G9(A6380)',
      'id' => 2969,
    ),
  ),
  41 => 
  array (
    0 => 
    array (
      'name' => 'G3',
      'id' => 294,
    ),
    1 => 
    array (
      'name' => 'H10',
      'id' => 313,
    ),
    2 => 
    array (
      'name' => 'H20',
      'id' => 289,
    ),
    3 => 
    array (
      'name' => 'H50',
      'id' => 303,
    ),
    4 => 
    array (
      'name' => 'H55',
      'id' => 252,
    ),
    5 => 
    array (
      'name' => 'HX1',
      'id' => 288,
    ),
    6 => 
    array (
      'name' => 'HX5C',
      'id' => 264,
    ),
    7 => 
    array (
      'name' => 'NEX3',
      'id' => 250,
    ),
    8 => 
    array (
      'name' => 'NEX5',
      'id' => 249,
    ),
    9 => 
    array (
      'name' => 'S2100',
      'id' => 255,
    ),
    10 => 
    array (
      'name' => 'S730',
      'id' => 315,
    ),
    11 => 
    array (
      'name' => 'S750',
      'id' => 311,
    ),
    12 => 
    array (
      'name' => 'S780',
      'id' => 312,
    ),
    13 => 
    array (
      'name' => 'S930',
      'id' => 284,
    ),
    14 => 
    array (
      'name' => 'S950',
      'id' => 295,
    ),
    15 => 
    array (
      'name' => 'S980',
      'id' => 286,
    ),
    16 => 
    array (
      'name' => 'T300',
      'id' => 306,
    ),
    17 => 
    array (
      'name' => 'T700',
      'id' => 300,
    ),
    18 => 
    array (
      'name' => 'T90',
      'id' => 292,
    ),
    19 => 
    array (
      'name' => 'T900',
      'id' => 293,
    ),
    20 => 
    array (
      'name' => 'TX1',
      'id' => 276,
    ),
    21 => 
    array (
      'name' => 'TX5',
      'id' => 254,
    ),
    22 => 
    array (
      'name' => 'TX7',
      'id' => 262,
    ),
    23 => 
    array (
      'name' => 'W110',
      'id' => 302,
    ),
    24 => 
    array (
      'name' => 'W120',
      'id' => 310,
    ),
    25 => 
    array (
      'name' => 'W130',
      'id' => 309,
    ),
    26 => 
    array (
      'name' => 'W150',
      'id' => 308,
    ),
    27 => 
    array (
      'name' => 'W170',
      'id' => 307,
    ),
    28 => 
    array (
      'name' => 'W190',
      'id' => 279,
    ),
    29 => 
    array (
      'name' => 'W210',
      'id' => 287,
    ),
    30 => 
    array (
      'name' => 'W220',
      'id' => 296,
    ),
    31 => 
    array (
      'name' => 'W230',
      'id' => 291,
    ),
    32 => 
    array (
      'name' => 'W290',
      'id' => 290,
    ),
    33 => 
    array (
      'name' => 'W300',
      'id' => 301,
    ),
    34 => 
    array (
      'name' => 'W310',
      'id' => 256,
    ),
    35 => 
    array (
      'name' => 'W320',
      'id' => 258,
    ),
    36 => 
    array (
      'name' => 'W350',
      'id' => 259,
    ),
    37 => 
    array (
      'name' => 'W350D',
      'id' => 248,
    ),
    38 => 
    array (
      'name' => 'W380',
      'id' => 261,
    ),
    39 => 
    array (
      'name' => 'W390',
      'id' => 260,
    ),
    40 => 
    array (
      'name' => 'WX1',
      'id' => 278,
    ),
  ),
  181 => 
  array (
    0 => 
    array (
      'name' => 'G502',
      'id' => 2600,
    ),
    1 => 
    array (
      'name' => 'G700',
      'id' => 3645,
    ),
    2 => 
    array (
      'name' => 'G702',
      'id' => 3643,
    ),
    3 => 
    array (
      'name' => 'G705',
      'id' => 3642,
    ),
    4 => 
    array (
      'name' => 'G900',
      'id' => 3646,
    ),
  ),
  188 => 
  array (
    0 => 
    array (
      'name' => 'G508e',
      'id' => 2679,
    ),
    1 => 
    array (
      'name' => 'g618',
      'id' => 2702,
    ),
    2 => 
    array (
      'name' => 'G800',
      'id' => 3539,
    ),
    3 => 
    array (
      'name' => 'G808',
      'id' => 3537,
    ),
    4 => 
    array (
      'name' => 'g818e',
      'id' => 2690,
    ),
  ),
  194 => 
  array (
    0 => 
    array (
      'name' => 'gc900e',
      'id' => 2650,
    ),
    1 => 
    array (
      'name' => 'gd310',
      'id' => 2653,
    ),
    2 => 
    array (
      'name' => 'gd330',
      'id' => 2670,
    ),
    3 => 
    array (
      'name' => 'gd350',
      'id' => 2663,
    ),
    4 => 
    array (
      'name' => 'gd510',
      'id' => 2668,
    ),
    5 => 
    array (
      'name' => 'gd550e',
      'id' => 2667,
    ),
    6 => 
    array (
      'name' => 'gd580',
      'id' => 2655,
    ),
    7 => 
    array (
      'name' => 'gm730',
      'id' => 2661,
    ),
    8 => 
    array (
      'name' => 'gs290',
      'id' => 2658,
    ),
    9 => 
    array (
      'name' => 'gs500v',
      'id' => 2672,
    ),
  ),
  56 => 
  array (
    0 => 
    array (
      'name' => 'GX20',
      'id' => 630,
    ),
    1 => 
    array (
      'name' => 'NX10',
      'id' => 590,
    ),
  ),
  344 => 
  array (
    0 => 
    array (
      'name' => 'HD',
      'id' => 3711,
    ),
    1 => 
    array (
      'name' => 'HD mini(T5555)',
      'id' => 3712,
    ),
    2 => 
    array (
      'name' => 'HD2(T8585/T8588)',
      'id' => 3710,
    ),
    3 => 
    array (
      'name' => 'HD7(T9292)',
      'id' => 3709,
    ),
  ),
  106 => 
  array (
    0 => 
    array (
      'name' => 'I1320R-118',
      'id' => 2026,
    ),
  ),
  328 => 
  array (
    0 => 
    array (
      'name' => 'i18',
      'id' => 3445,
    ),
    1 => 
    array (
      'name' => 'i188',
      'id' => 3448,
    ),
    2 => 
    array (
      'name' => 'i266',
      'id' => 3457,
    ),
    3 => 
    array (
      'name' => 'i268',
      'id' => 3439,
    ),
    4 => 
    array (
      'name' => 'i268+',
      'id' => 3452,
    ),
    5 => 
    array (
      'name' => 'i269',
      'id' => 3433,
    ),
    6 => 
    array (
      'name' => 'i270',
      'id' => 3432,
    ),
    7 => 
    array (
      'name' => 'i288',
      'id' => 3434,
    ),
    8 => 
    array (
      'name' => 'i288+',
      'id' => 3435,
    ),
    9 => 
    array (
      'name' => 'i288b',
      'id' => 3437,
    ),
    10 => 
    array (
      'name' => 'i289',
      'id' => 3449,
    ),
    11 => 
    array (
      'name' => 'i289c',
      'id' => 3443,
    ),
    12 => 
    array (
      'name' => 'i308',
      'id' => 3455,
    ),
    13 => 
    array (
      'name' => 'i328',
      'id' => 3450,
    ),
    14 => 
    array (
      'name' => 'i358',
      'id' => 3451,
    ),
    15 => 
    array (
      'name' => 'i399',
      'id' => 3438,
    ),
    16 => 
    array (
      'name' => 'i508',
      'id' => 3464,
    ),
    17 => 
    array (
      'name' => 'i518',
      'id' => 3465,
    ),
    18 => 
    array (
      'name' => 'i528',
      'id' => 3440,
    ),
    19 => 
    array (
      'name' => 'i528b',
      'id' => 3441,
    ),
    20 => 
    array (
      'name' => 'i530',
      'id' => 3446,
    ),
    21 => 
    array (
      'name' => 'i531',
      'id' => 3467,
    ),
    22 => 
    array (
      'name' => 'i589',
      'id' => 3447,
    ),
    23 => 
    array (
      'name' => 'i6',
      'id' => 3444,
    ),
    24 => 
    array (
      'name' => 'i606',
      'id' => 3460,
    ),
    25 => 
    array (
      'name' => 'i628',
      'id' => 3453,
    ),
    26 => 
    array (
      'name' => 'i8',
      'id' => 3436,
    ),
  ),
  186 => 
  array (
    0 => 
    array (
      'name' => 'i200',
      'id' => 3551,
    ),
    1 => 
    array (
      'name' => 'i329',
      'id' => 2763,
    ),
    2 => 
    array (
      'name' => 'i458',
      'id' => 2713,
    ),
    3 => 
    array (
      'name' => 'i5508',
      'id' => 2722,
    ),
    4 => 
    array (
      'name' => 'i579',
      'id' => 2997,
    ),
    5 => 
    array (
      'name' => 'i6320c',
      'id' => 2766,
    ),
    6 => 
    array (
      'name' => 'I6330c',
      'id' => 2746,
    ),
    7 => 
    array (
      'name' => 'I6500u',
      'id' => 2737,
    ),
    8 => 
    array (
      'name' => 'i688',
      'id' => 2772,
    ),
    9 => 
    array (
      'name' => 'i728',
      'id' => 2708,
    ),
    10 => 
    array (
      'name' => 'i7500',
      'id' => 3030,
    ),
    11 => 
    array (
      'name' => 'i7500u',
      'id' => 2750,
    ),
    12 => 
    array (
      'name' => 'i7680',
      'id' => 2731,
    ),
    13 => 
    array (
      'name' => 'i788',
      'id' => 2703,
    ),
    14 => 
    array (
      'name' => 'i8000',
      'id' => 3029,
    ),
    15 => 
    array (
      'name' => 'i8000u',
      'id' => 2747,
    ),
    16 => 
    array (
      'name' => 'i8180c',
      'id' => 2743,
    ),
    17 => 
    array (
      'name' => 'i8510c',
      'id' => 2673,
    ),
    18 => 
    array (
      'name' => 'i859',
      'id' => 2705,
    ),
    19 => 
    array (
      'name' => 'i859',
      'id' => 2784,
    ),
    20 => 
    array (
      'name' => 'i8910u',
      'id' => 2758,
    ),
    21 => 
    array (
      'name' => 'i897',
      'id' => 3547,
    ),
    22 => 
    array (
      'name' => 'i899',
      'id' => 2745,
    ),
    23 => 
    array (
      'name' => 'i900',
      'id' => 3011,
    ),
    24 => 
    array (
      'name' => 'i9000',
      'id' => 3012,
    ),
    25 => 
    array (
      'name' => 'I9003',
      'id' => 2975,
    ),
    26 => 
    array (
      'name' => 'I9008',
      'id' => 2976,
    ),
    27 => 
    array (
      'name' => 'i9020',
      'id' => 3010,
    ),
    28 => 
    array (
      'name' => 'i9088',
      'id' => 3032,
    ),
    29 => 
    array (
      'name' => 'i908e',
      'id' => 2678,
    ),
    30 => 
    array (
      'name' => 'I909',
      'id' => 2998,
    ),
    31 => 
    array (
      'name' => 'i9100',
      'id' => 3716,
    ),
  ),
  118 => 
  array (
    0 => 
    array (
      'name' => 'i300',
      'id' => 2195,
    ),
    1 => 
    array (
      'name' => 'i307',
      'id' => 2358,
    ),
    2 => 
    array (
      'name' => 'i323',
      'id' => 2413,
    ),
    3 => 
    array (
      'name' => 'i325wg',
      'id' => 2112,
    ),
    4 => 
    array (
      'name' => 'i327',
      'id' => 2364,
    ),
    5 => 
    array (
      'name' => 'i370',
      'id' => 2401,
    ),
    6 => 
    array (
      'name' => 'i380',
      'id' => 2176,
    ),
    7 => 
    array (
      'name' => 'i389',
      'id' => 2396,
    ),
    8 => 
    array (
      'name' => 'i399',
      'id' => 2394,
    ),
    9 => 
    array (
      'name' => 'i50',
      'id' => 2244,
    ),
    10 => 
    array (
      'name' => 'i510',
      'id' => 2367,
    ),
    11 => 
    array (
      'name' => 'i515',
      'id' => 2412,
    ),
    12 => 
    array (
      'name' => 'i516',
      'id' => 2169,
    ),
    13 => 
    array (
      'name' => 'i55�ǹ�',
      'id' => 2111,
    ),
    14 => 
    array (
      'name' => 'i60',
      'id' => 2243,
    ),
    15 => 
    array (
      'name' => 'i60s Game��ˬ��ǿ��',
      'id' => 2178,
    ),
    16 => 
    array (
      'name' => 'i60s������',
      'id' => 2245,
    ),
    17 => 
    array (
      'name' => 'i60s���ʰ�',
      'id' => 2223,
    ),
    18 => 
    array (
      'name' => 'i60��ˬ��ǿ��',
      'id' => 2182,
    ),
    19 => 
    array (
      'name' => 'i61',
      'id' => 2164,
    ),
    20 => 
    array (
      'name' => 'i716',
      'id' => 2406,
    ),
    21 => 
    array (
      'name' => 'i726',
      'id' => 2416,
    ),
    22 => 
    array (
      'name' => 'i758',
      'id' => 2372,
    ),
    23 => 
    array (
      'name' => 'i760',
      'id' => 2352,
    ),
    24 => 
    array (
      'name' => 'i780',
      'id' => 2342,
    ),
    25 => 
    array (
      'name' => 'i807',
      'id' => 2417,
    ),
    26 => 
    array (
      'name' => 'i817',
      'id' => 2403,
    ),
    27 => 
    array (
      'name' => 'i827',
      'id' => 2386,
    ),
    28 => 
    array (
      'name' => 'i880',
      'id' => 2366,
    ),
    29 => 
    array (
      'name' => 'i906',
      'id' => 2399,
    ),
    30 => 
    array (
      'name' => 'i907',
      'id' => 2387,
    ),
    31 => 
    array (
      'name' => 'i909',
      'id' => 2402,
    ),
    32 => 
    array (
      'name' => 'i909c',
      'id' => 2206,
    ),
    33 => 
    array (
      'name' => 'i910',
      'id' => 2381,
    ),
    34 => 
    array (
      'name' => 'i919',
      'id' => 2382,
    ),
    35 => 
    array (
      'name' => 'i966',
      'id' => 2392,
    ),
    36 => 
    array (
      'name' => 'i968',
      'id' => 2400,
    ),
  ),
  330 => 
  array (
    0 => 
    array (
      'name' => 'i468',
      'id' => 3510,
    ),
    1 => 
    array (
      'name' => 'i580',
      'id' => 3501,
    ),
    2 => 
    array (
      'name' => 'i880',
      'id' => 3509,
    ),
  ),
  7 => 
  array (
    0 => 
    array (
      'name' => 'iC MF4012G',
      'id' => 106,
    ),
    1 => 
    array (
      'name' => 'IC MF4320D',
      'id' => 99,
    ),
    2 => 
    array (
      'name' => 'IC MF4330d',
      'id' => 104,
    ),
    3 => 
    array (
      'name' => 'IC MF4350d',
      'id' => 101,
    ),
    4 => 
    array (
      'name' => 'iC MF4350dG',
      'id' => 107,
    ),
    5 => 
    array (
      'name' => 'MF4322D',
      'id' => 103,
    ),
    6 => 
    array (
      'name' => 'MF4370DN',
      'id' => 100,
    ),
    7 => 
    array (
      'name' => '� iC MF8030Cn',
      'id' => 102,
    ),
  ),
  108 => 
  array (
    0 => 
    array (
      'name' => 'Ins14VR',
      'id' => 2029,
    ),
  ),
  111 => 
  array (
    0 => 
    array (
      'name' => 'INSI13ZR',
      'id' => 1862,
    ),
  ),
  177 => 
  array (
    0 => 
    array (
      'name' => 'J10',
      'id' => 3613,
    ),
    1 => 
    array (
      'name' => 'J100',
      'id' => 3610,
    ),
    2 => 
    array (
      'name' => 'J105',
      'id' => 2576,
    ),
    3 => 
    array (
      'name' => 'J108i',
      'id' => 3633,
    ),
    4 => 
    array (
      'name' => 'J110',
      'id' => 3631,
    ),
    5 => 
    array (
      'name' => 'J120',
      'id' => 3611,
    ),
    6 => 
    array (
      'name' => 'J20',
      'id' => 3614,
    ),
    7 => 
    array (
      'name' => 'J200',
      'id' => 2574,
    ),
    8 => 
    array (
      'name' => 'J210',
      'id' => 2575,
    ),
    9 => 
    array (
      'name' => 'J220',
      'id' => 3632,
    ),
    10 => 
    array (
      'name' => 'J230',
      'id' => 3612,
    ),
    11 => 
    array (
      'name' => 'J300',
      'id' => 2577,
    ),
  ),
  187 => 
  array (
    0 => 
    array (
      'name' => 'j218',
      'id' => 2714,
    ),
    1 => 
    array (
      'name' => 'j708',
      'id' => 2709,
    ),
    2 => 
    array (
      'name' => 'J708i',
      'id' => 2622,
    ),
    3 => 
    array (
      'name' => 'J808e',
      'id' => 2674,
    ),
  ),
  334 => 
  array (
    0 => 
    array (
      'name' => 'K1',
      'id' => 3530,
    ),
    1 => 
    array (
      'name' => 'K1m',
      'id' => 3531,
    ),
    2 => 
    array (
      'name' => 'K2',
      'id' => 3520,
    ),
  ),
  309 => 
  array (
    0 => 
    array (
      'name' => 'K10',
      'id' => 3468,
    ),
    1 => 
    array (
      'name' => 'K112',
      'id' => 3462,
    ),
    2 => 
    array (
      'name' => 'K118',
      'id' => 3463,
    ),
    3 => 
    array (
      'name' => 'K119',
      'id' => 3470,
    ),
    4 => 
    array (
      'name' => 'K13',
      'id' => 3471,
    ),
    5 => 
    array (
      'name' => 'K19',
      'id' => 3469,
    ),
    6 => 
    array (
      'name' => 'K201',
      'id' => 3461,
    ),
    7 => 
    array (
      'name' => 'K202',
      'id' => 3484,
    ),
    8 => 
    array (
      'name' => 'K203M',
      'id' => 3473,
    ),
    9 => 
    array (
      'name' => 'K27',
      'id' => 3485,
    ),
    10 => 
    array (
      'name' => 'K302',
      'id' => 3472,
    ),
    11 => 
    array (
      'name' => 'K302+',
      'id' => 3486,
    ),
  ),
  173 => 
  array (
    0 => 
    array (
      'name' => 'K200',
      'id' => 3562,
    ),
    1 => 
    array (
      'name' => 'K220',
      'id' => 3566,
    ),
    2 => 
    array (
      'name' => 'K300',
      'id' => 2555,
    ),
    3 => 
    array (
      'name' => 'K310',
      'id' => 3561,
    ),
    4 => 
    array (
      'name' => 'K500',
      'id' => 2556,
    ),
    5 => 
    array (
      'name' => 'K506',
      'id' => 3554,
    ),
    6 => 
    array (
      'name' => 'K508',
      'id' => 3555,
    ),
    7 => 
    array (
      'name' => 'K510',
      'id' => 3560,
    ),
    8 => 
    array (
      'name' => 'K530',
      'id' => 3556,
    ),
    9 => 
    array (
      'name' => 'K550',
      'id' => 3541,
    ),
    10 => 
    array (
      'name' => 'K600',
      'id' => 3568,
    ),
    11 => 
    array (
      'name' => 'K608',
      'id' => 3567,
    ),
    12 => 
    array (
      'name' => 'K610',
      'id' => 3569,
    ),
    13 => 
    array (
      'name' => 'K618',
      'id' => 3542,
    ),
    14 => 
    array (
      'name' => 'K630',
      'id' => 3557,
    ),
    15 => 
    array (
      'name' => 'K660',
      'id' => 3543,
    ),
    16 => 
    array (
      'name' => 'K700',
      'id' => 3540,
    ),
    17 => 
    array (
      'name' => 'K750',
      'id' => 3563,
    ),
    18 => 
    array (
      'name' => 'K758',
      'id' => 3570,
    ),
    19 => 
    array (
      'name' => 'K770',
      'id' => 3571,
    ),
    20 => 
    array (
      'name' => 'K790',
      'id' => 3558,
    ),
    21 => 
    array (
      'name' => 'K800',
      'id' => 3559,
    ),
    22 => 
    array (
      'name' => 'K810',
      'id' => 3564,
    ),
    23 => 
    array (
      'name' => 'K818',
      'id' => 3565,
    ),
    24 => 
    array (
      'name' => 'K850',
      'id' => 3585,
    ),
    25 => 
    array (
      'name' => 'K858',
      'id' => 3584,
    ),
  ),
  52 => 
  array (
    0 => 
    array (
      'name' => 'K200D',
      'id' => 666,
    ),
    1 => 
    array (
      'name' => 'K20D',
      'id' => 667,
    ),
    2 => 
    array (
      'name' => 'K7',
      'id' => 651,
    ),
    3 => 
    array (
      'name' => 'K-m(K2000)',
      'id' => 656,
    ),
    4 => 
    array (
      'name' => 'K-x',
      'id' => 646,
    ),
  ),
  86 => 
  array (
    0 => 
    array (
      'name' => 'K40E45IE-SL',
      'id' => 1919,
    ),
    1 => 
    array (
      'name' => 'K40E667ID-SL',
      'id' => 1918,
    ),
    2 => 
    array (
      'name' => 'K40E667IE-SL',
      'id' => 1920,
    ),
  ),
  87 => 
  array (
    0 => 
    array (
      'name' => 'K41E33VD-SL',
      'id' => 1933,
    ),
    1 => 
    array (
      'name' => 'K41E667VD-SL',
      'id' => 1932,
    ),
  ),
  88 => 
  array (
    0 => 
    array (
      'name' => 'K42EI33JB-SL',
      'id' => 1937,
    ),
    1 => 
    array (
      'name' => 'K42EI35JC-SL',
      'id' => 1936,
    ),
    2 => 
    array (
      'name' => 'K42EI43JV-SL',
      'id' => 1938,
    ),
  ),
  92 => 
  array (
    0 => 
    array (
      'name' => 'K50X44IE-SL',
      'id' => 1947,
    ),
    1 => 
    array (
      'name' => 'K50X667ID-SL',
      'id' => 1946,
    ),
  ),
  91 => 
  array (
    0 => 
    array (
      'name' => 'K52XI43JK-SL',
      'id' => 1954,
    ),
  ),
  158 => 
  array (
    0 => 
    array (
      'name' => 'k700',
      'id' => 2447,
    ),
  ),
  193 => 
  array (
    0 => 
    array (
      'name' => 'kf305',
      'id' => 2646,
    ),
    1 => 
    array (
      'name' => 'kf350',
      'id' => 2627,
    ),
    2 => 
    array (
      'name' => 'kf510',
      'id' => 2647,
    ),
    3 => 
    array (
      'name' => 'KM900',
      'id' => 3717,
    ),
    4 => 
    array (
      'name' => 'KP500',
      'id' => 3697,
    ),
    5 => 
    array (
      'name' => 'kp500',
      'id' => 2625,
    ),
    6 => 
    array (
      'name' => 'kp502',
      'id' => 2626,
    ),
    7 => 
    array (
      'name' => 'KS360',
      'id' => 3696,
    ),
    8 => 
    array (
      'name' => 'ks360',
      'id' => 2634,
    ),
    9 => 
    array (
      'name' => 'kv500',
      'id' => 2638,
    ),
    10 => 
    array (
      'name' => 'kv510',
      'id' => 2643,
    ),
    11 => 
    array (
      'name' => 'kv755',
      'id' => 2642,
    ),
    12 => 
    array (
      'name' => 'kv800',
      'id' => 2640,
    ),
    13 => 
    array (
      'name' => 'kv920',
      'id' => 2636,
    ),
    14 => 
    array (
      'name' => 'kx196',
      'id' => 2629,
    ),
    15 => 
    array (
      'name' => 'kx500',
      'id' => 2628,
    ),
    16 => 
    array (
      'name' => 'kx755',
      'id' => 2631,
    ),
  ),
  23 => 
  array (
    0 => 
    array (
      'name' => 'KX-FL503CN',
      'id' => 2872,
    ),
    1 => 
    array (
      'name' => 'KX-FL523CN',
      'id' => 2873,
    ),
    2 => 
    array (
      'name' => 'KX-FLB753CN',
      'id' => 2876,
    ),
    3 => 
    array (
      'name' => 'KX-FLB758CN',
      'id' => 2877,
    ),
    4 => 
    array (
      'name' => 'KX-FLM553CN',
      'id' => 2874,
    ),
    5 => 
    array (
      'name' => 'KX-FLM558CN',
      'id' => 2875,
    ),
    6 => 
    array (
      'name' => 'KX-FP706CN',
      'id' => 281,
    ),
    7 => 
    array (
      'name' => 'KX-FP709CN',
      'id' => 283,
    ),
    8 => 
    array (
      'name' => 'KX-FP719CN',
      'id' => 285,
    ),
  ),
  22 => 
  array (
    0 => 
    array (
      'name' => 'KX-FM388CN',
      'id' => 273,
    ),
    1 => 
    array (
      'name' => 'KX-FT982CN',
      'id' => 268,
    ),
    2 => 
    array (
      'name' => 'KX-FT986CN',
      'id' => 271,
    ),
    3 => 
    array (
      'name' => 'KX-FT992CN',
      'id' => 275,
    ),
    4 => 
    array (
      'name' => 'KX-FT992CN',
      'id' => 277,
    ),
    5 => 
    array (
      'name' => 'KX-FT992CN',
      'id' => 269,
    ),
    6 => 
    array (
      'name' => 'KX-FT996CN',
      'id' => 270,
    ),
  ),
  5 => 
  array (
    0 => 
    array (
      'name' => 'L100/120/IC MF4122/4120/4150/L140/L160',
      'id' => 76,
    ),
    1 => 
    array (
      'name' => 'L240/250/360/380',
      'id' => 75,
    ),
    2 => 
    array (
      'name' => 'L250/L280/L380/L388/L350/L200',
      'id' => 2922,
    ),
    3 => 
    array (
      'name' => 'LBP-1120/800/810',
      'id' => 2889,
    ),
    4 => 
    array (
      'name' => 'LBP2900/3000',
      'id' => 72,
    ),
    5 => 
    array (
      'name' => 'LBP3018/3108/3050/3100/3150/3010',
      'id' => 71,
    ),
    6 => 
    array (
      'name' => 'LBP5050/5050N',
      'id' => 74,
    ),
    7 => 
    array (
      'name' => 'LBP6300dn/6650dn',
      'id' => 73,
    ),
    8 => 
    array (
      'name' => 'LBP810/1120',
      'id' => 79,
    ),
    9 => 
    array (
      'name' => 'MF4370dn/MF4320d/MF4322d/MF4330d/MF4350d',
      'id' => 78,
    ),
  ),
  47 => 
  array (
    0 => 
    array (
      'name' => 'L110',
      'id' => 432,
    ),
    1 => 
    array (
      'name' => 'L21',
      'id' => 430,
    ),
    2 => 
    array (
      'name' => 'L22',
      'id' => 431,
    ),
    3 => 
    array (
      'name' => 'P100',
      'id' => 433,
    ),
    4 => 
    array (
      'name' => 'P6000',
      'id' => 460,
    ),
    5 => 
    array (
      'name' => 'P80',
      'id' => 463,
    ),
    6 => 
    array (
      'name' => 'P90',
      'id' => 446,
    ),
    7 => 
    array (
      'name' => 'S1000pj',
      'id' => 442,
    ),
    8 => 
    array (
      'name' => 'S210',
      'id' => 464,
    ),
    9 => 
    array (
      'name' => 'S220',
      'id' => 450,
    ),
    10 => 
    array (
      'name' => 'S230',
      'id' => 449,
    ),
    11 => 
    array (
      'name' => 'S3000',
      'id' => 434,
    ),
    12 => 
    array (
      'name' => 'S52',
      'id' => 462,
    ),
    13 => 
    array (
      'name' => 'S550',
      'id' => 466,
    ),
    14 => 
    array (
      'name' => 'S560',
      'id' => 457,
    ),
    15 => 
    array (
      'name' => 'S570',
      'id' => 439,
    ),
    16 => 
    array (
      'name' => 'S600',
      'id' => 467,
    ),
    17 => 
    array (
      'name' => 'S610',
      'id' => 458,
    ),
    18 => 
    array (
      'name' => 'S620',
      'id' => 448,
    ),
    19 => 
    array (
      'name' => 'S630',
      'id' => 447,
    ),
    20 => 
    array (
      'name' => 'S640',
      'id' => 441,
    ),
    21 => 
    array (
      'name' => 'S70',
      'id' => 440,
    ),
    22 => 
    array (
      'name' => 'S710',
      'id' => 459,
    ),
    23 => 
    array (
      'name' => 'S8000',
      'id' => 437,
    ),
  ),
  189 => 
  array (
    0 => 
    array (
      'name' => 'L168',
      'id' => 2707,
    ),
    1 => 
    array (
      'name' => 'l258',
      'id' => 2716,
    ),
    2 => 
    array (
      'name' => 'L288',
      'id' => 2773,
    ),
    3 => 
    array (
      'name' => 'L708e',
      'id' => 2682,
    ),
    4 => 
    array (
      'name' => 'l878e',
      'id' => 2669,
    ),
  ),
  166 => 
  array (
    0 => 
    array (
      'name' => 'L2',
      'id' => 2534,
    ),
    1 => 
    array (
      'name' => 'L6',
      'id' => 2535,
    ),
    2 => 
    array (
      'name' => 'L6g',
      'id' => 3477,
    ),
    3 => 
    array (
      'name' => 'L6i',
      'id' => 3476,
    ),
    4 => 
    array (
      'name' => 'L7',
      'id' => 3487,
    ),
    5 => 
    array (
      'name' => 'L71',
      'id' => 3478,
    ),
    6 => 
    array (
      'name' => 'L72',
      'id' => 3490,
    ),
    7 => 
    array (
      'name' => 'L7c',
      'id' => 3489,
    ),
    8 => 
    array (
      'name' => 'L7e',
      'id' => 3488,
    ),
    9 => 
    array (
      'name' => 'L800T',
      'id' => 3491,
    ),
    10 => 
    array (
      'name' => 'L9',
      'id' => 3479,
    ),
  ),
  79 => 
  array (
    0 => 
    array (
      'name' => 'L600',
      'id' => 1971,
    ),
  ),
  185 => 
  array (
    0 => 
    array (
      'name' => 'M110S',
      'id' => 3548,
    ),
    1 => 
    array (
      'name' => 'm128',
      'id' => 2710,
    ),
    2 => 
    array (
      'name' => 'm2710c',
      'id' => 2614,
    ),
    3 => 
    array (
      'name' => 'M318',
      'id' => 2695,
    ),
    4 => 
    array (
      'name' => 'm3318c',
      'id' => 2599,
    ),
    5 => 
    array (
      'name' => 'm3510c',
      'id' => 2656,
    ),
    6 => 
    array (
      'name' => 'm519',
      'id' => 2754,
    ),
    7 => 
    array (
      'name' => 'M5650u',
      'id' => 2741,
    ),
    8 => 
    array (
      'name' => 'm609',
      'id' => 2771,
    ),
    9 => 
    array (
      'name' => 'M628',
      'id' => 2691,
    ),
    10 => 
    array (
      'name' => 'M8800c',
      'id' => 2654,
    ),
    11 => 
    array (
      'name' => 'm8910u',
      'id' => 2751,
    ),
  ),
  182 => 
  array (
    0 => 
    array (
      'name' => 'M1i',
      'id' => 3647,
    ),
    1 => 
    array (
      'name' => 'M600',
      'id' => 2604,
    ),
    2 => 
    array (
      'name' => 'M608',
      'id' => 3664,
    ),
  ),
  113 => 
  array (
    0 => 
    array (
      'name' => 'M5010R',
      'id' => 2045,
    ),
  ),
  138 => 
  array (
    0 => 
    array (
      'name' => 'M8',
      'id' => 1451,
    ),
    1 => 
    array (
      'name' => 'M9',
      'id' => 1448,
    ),
  ),
  85 => 
  array (
    0 => 
    array (
      'name' => 'MacBook  MC207CH/A ',
      'id' => 1884,
    ),
    1 => 
    array (
      'name' => 'MacBook Air MC233CH/A ',
      'id' => 1888,
    ),
    2 => 
    array (
      'name' => 'MacBook Air MC234CH/A',
      'id' => 1889,
    ),
    3 => 
    array (
      'name' => 'MacBook MC233CH/A',
      'id' => 1887,
    ),
    4 => 
    array (
      'name' => 'MacBook MC233CH/A',
      'id' => 1885,
    ),
    5 => 
    array (
      'name' => 'MacBook MC516CH/A',
      'id' => 1893,
    ),
    6 => 
    array (
      'name' => 'MacBook Pro MC024CH/A',
      'id' => 1883,
    ),
    7 => 
    array (
      'name' => 'MacBook Pro MC371CH/A',
      'id' => 1890,
    ),
    8 => 
    array (
      'name' => 'MacBook Pro MC372CH/A',
      'id' => 1891,
    ),
    9 => 
    array (
      'name' => 'MacBook Pro MC373CH/A',
      'id' => 1892,
    ),
    10 => 
    array (
      'name' => 'MacBook Pro MC374CH/A ',
      'id' => 1882,
    ),
    11 => 
    array (
      'name' => 'MC374CH/A ',
      'id' => 1886,
    ),
  ),
  306 => 
  array (
    0 => 
    array (
      'name' => 'MB200',
      'id' => 3260,
    ),
    1 => 
    array (
      'name' => 'MB220',
      'id' => 3283,
    ),
    2 => 
    array (
      'name' => 'MB300',
      'id' => 3282,
    ),
    3 => 
    array (
      'name' => 'MB501',
      'id' => 3284,
    ),
    4 => 
    array (
      'name' => 'MB502',
      'id' => 3259,
    ),
    5 => 
    array (
      'name' => 'MB511',
      'id' => 3258,
    ),
    6 => 
    array (
      'name' => 'MB525',
      'id' => 3262,
    ),
    7 => 
    array (
      'name' => 'MB611',
      'id' => 3261,
    ),
    8 => 
    array (
      'name' => 'MB810',
      'id' => 3285,
    ),
    9 => 
    array (
      'name' => 'MB860',
      'id' => 3286,
    ),
  ),
  15 => 
  array (
    0 => 
    array (
      'name' => 'ME OFFICE 360',
      'id' => 140,
    ),
    1 => 
    array (
      'name' => 'ME OFFICE 520',
      'id' => 142,
    ),
    2 => 
    array (
      'name' => 'ME OFFICE 600F',
      'id' => 139,
    ),
    3 => 
    array (
      'name' => 'ME Office 650FN',
      'id' => 141,
    ),
    4 => 
    array (
      'name' => 'ME Office 700FW',
      'id' => 143,
    ),
    5 => 
    array (
      'name' => 'ME300',
      'id' => 137,
    ),
    6 => 
    array (
      'name' => 'ME330',
      'id' => 138,
    ),
    7 => 
    array (
      'name' => 'Stylus Photo TX800FW',
      'id' => 144,
    ),
  ),
  305 => 
  array (
    0 => 
    array (
      'name' => 'ME501',
      'id' => 3281,
    ),
    1 => 
    array (
      'name' => 'ME511',
      'id' => 3255,
    ),
    2 => 
    array (
      'name' => 'ME525',
      'id' => 3279,
    ),
    3 => 
    array (
      'name' => 'ME600',
      'id' => 3280,
    ),
    4 => 
    array (
      'name' => 'ME722',
      'id' => 3254,
    ),
    5 => 
    array (
      'name' => 'ME811',
      'id' => 3256,
    ),
    6 => 
    array (
      'name' => 'ME860',
      'id' => 3257,
    ),
  ),
  105 => 
  array (
    0 => 
    array (
      'name' => 'mini 5101/5102',
      'id' => 1091,
    ),
  ),
  25 => 
  array (
    0 => 
    array (
      'name' => 'MJC-4000/5000/6000/SCX-1220',
      'id' => 2847,
    ),
    1 => 
    array (
      'name' => 'SF-330/331P/335T/332/333P/340/341P',
      'id' => 2848,
    ),
  ),
  12 => 
  array (
    0 => 
    array (
      'name' => 'ML-1210/1220M/1430',
      'id' => 155,
    ),
    1 => 
    array (
      'name' => 'ML-1510/1710/1710P',
      'id' => 156,
    ),
    2 => 
    array (
      'name' => 'ML-1666/SCX-3201/3218',
      'id' => 145,
    ),
    3 => 
    array (
      'name' => 'ML-2010/2510/2570/2571N',
      'id' => 154,
    ),
    4 => 
    array (
      'name' => 'ML-808/SF-5100/5100P/530/550',
      'id' => 147,
    ),
    5 => 
    array (
      'name' => 'SCX-4200',
      'id' => 149,
    ),
    6 => 
    array (
      'name' => 'SCX-4321/4521F',
      'id' => 146,
    ),
    7 => 
    array (
      'name' => 'SCX-4520/4720F',
      'id' => 151,
    ),
    8 => 
    array (
      'name' => 'SCX-4725F/4725FN',
      'id' => 153,
    ),
    9 => 
    array (
      'name' => 'SCX-5112/5312F/5115/5315F/ML-912',
      'id' => 152,
    ),
    10 => 
    array (
      'name' => 'SF-5100/530/550',
      'id' => 157,
    ),
    11 => 
    array (
      'name' => 'SF-555P ',
      'id' => 148,
    ),
    12 => 
    array (
      'name' => 'SF-560/565P ',
      'id' => 150,
    ),
  ),
  8 => 
  array (
    0 => 
    array (
      'name' => 'MP145',
      'id' => 2948,
    ),
    1 => 
    array (
      'name' => 'MP198',
      'id' => 2949,
    ),
    2 => 
    array (
      'name' => 'mp228',
      'id' => 2950,
    ),
    3 => 
    array (
      'name' => 'MP245/268/486',
      'id' => 2914,
    ),
    4 => 
    array (
      'name' => 'MP276',
      'id' => 110,
    ),
    5 => 
    array (
      'name' => 'mp308',
      'id' => 2952,
    ),
    6 => 
    array (
      'name' => 'mp318',
      'id' => 2953,
    ),
    7 => 
    array (
      'name' => 'mp476',
      'id' => 2951,
    ),
    8 => 
    array (
      'name' => 'MP545',
      'id' => 2936,
    ),
    9 => 
    array (
      'name' => 'MP558',
      'id' => 2937,
    ),
    10 => 
    array (
      'name' => 'MP638',
      'id' => 2938,
    ),
    11 => 
    array (
      'name' => 'MX868',
      'id' => 2939,
    ),
    12 => 
    array (
      'name' => 'MX876',
      'id' => 2958,
    ),
    13 => 
    array (
      'name' => 'PIXMA MP780/MP730',
      'id' => 2930,
    ),
    14 => 
    array (
      'name' => '�ڲ� PIXMA MP258',
      'id' => 111,
    ),
    15 => 
    array (
      'name' => '�ڲ� PIXMA MP558',
      'id' => 114,
    ),
    16 => 
    array (
      'name' => '�ڲ� PIXMA MP568',
      'id' => 113,
    ),
    17 => 
    array (
      'name' => '�ڲ� PIXMA MP648',
      'id' => 112,
    ),
    18 => 
    array (
      'name' => '�ڲ�PIXMA MX348/358',
      'id' => 118,
    ),
    19 => 
    array (
      'name' => '�ڲ�PIXMA MX876',
      'id' => 117,
    ),
  ),
  335 => 
  array (
    0 => 
    array (
      'name' => 'MS500',
      'id' => 3523,
    ),
    1 => 
    array (
      'name' => 'MS900',
      'id' => 3544,
    ),
  ),
  311 => 
  array (
    0 => 
    array (
      'name' => 'MT620',
      'id' => 3499,
    ),
    1 => 
    array (
      'name' => 'MT710',
      'id' => 3507,
    ),
    2 => 
    array (
      'name' => 'MT716',
      'id' => 3496,
    ),
    3 => 
    array (
      'name' => 'MT720',
      'id' => 3497,
    ),
    4 => 
    array (
      'name' => 'MT810',
      'id' => 3494,
    ),
    5 => 
    array (
      'name' => 'MT810lx',
      'id' => 3498,
    ),
    6 => 
    array (
      'name' => 'MT820',
      'id' => 3495,
    ),
  ),
  161 => 
  array (
    0 => 
    array (
      'name' => 'N16',
      'id' => 2489,
    ),
    1 => 
    array (
      'name' => 'n68',
      'id' => 2494,
    ),
    2 => 
    array (
      'name' => 'N900',
      'id' => 2463,
    ),
    3 => 
    array (
      'name' => 'N900+',
      'id' => 2464,
    ),
    4 => 
    array (
      'name' => 'N92',
      'id' => 2458,
    ),
  ),
  90 => 
  array (
    0 => 
    array (
      'name' => 'N81E667VF-SL',
      'id' => 1944,
    ),
  ),
  199 => 
  array (
    0 => 
    array (
      'name' => 'Nikon �῵ D3000 ���뵥����� ����',
      'id' => 2817,
    ),
    1 => 
    array (
      'name' => 'Nikon �῵ D3000 ���뵥������׻� ����18-55/3.5-5.6VR��',
      'id' => 2810,
    ),
    2 => 
    array (
      'name' => 'Nikon �῵ D300S ���뵥����� ����',
      'id' => 2816,
    ),
    3 => 
    array (
      'name' => 'Nikon �῵ D3S ���뵥����� ����',
      'id' => 2819,
    ),
    4 => 
    array (
      'name' => 'Nikon �῵ D3X 2450�����ص����������',
      'id' => 2818,
    ),
    5 => 
    array (
      'name' => 'Nikon �῵ D5000 �������(����)',
      'id' => 2815,
    ),
    6 => 
    array (
      'name' => 'Nikon �῵ D5000 �������(����)+18-105/3.5-5.6VR ������ͷ',
      'id' => 2812,
    ),
    7 => 
    array (
      'name' => 'Nikon �῵ D5000 ��������׻���18-55)VR',
      'id' => 2811,
    ),
    8 => 
    array (
      'name' => 'Nikon �῵ D700�������(����',
      'id' => 2813,
    ),
    9 => 
    array (
      'name' => 'Nikon �῵ D90 ������� (������',
      'id' => 2814,
    ),
    10 => 
    array (
      'name' => 'Nikon �῵ D90 ������� (�׻�������18-105/3.5-5.6VR��������ͷ',
      'id' => 2809,
    ),
  ),
  338 => 
  array (
    0 => 
    array (
      'name' => 'P1',
      'id' => 3672,
    ),
    1 => 
    array (
      'name' => 'P700',
      'id' => 3674,
    ),
    2 => 
    array (
      'name' => 'P800',
      'id' => 3650,
    ),
    3 => 
    array (
      'name' => 'P802',
      'id' => 3668,
    ),
    4 => 
    array (
      'name' => 'P900',
      'id' => 3669,
    ),
    5 => 
    array (
      'name' => 'P908',
      'id' => 3671,
    ),
    6 => 
    array (
      'name' => 'P910',
      'id' => 3670,
    ),
    7 => 
    array (
      'name' => 'P990',
      'id' => 3673,
    ),
  ),
  122 => 
  array (
    0 => 
    array (
      'name' => 'p50',
      'id' => 2160,
    ),
    1 => 
    array (
      'name' => 'p50�Ųʰ�',
      'id' => 2161,
    ),
    2 => 
    array (
      'name' => 'p580',
      'id' => 2250,
    ),
    3 => 
    array (
      'name' => 'p580c',
      'id' => 2174,
    ),
    4 => 
    array (
      'name' => 'p60',
      'id' => 2172,
    ),
    5 => 
    array (
      'name' => 'p609',
      'id' => 2363,
    ),
    6 => 
    array (
      'name' => 'p609+',
      'id' => 2350,
    ),
    7 => 
    array (
      'name' => 'p609c',
      'id' => 2349,
    ),
    8 => 
    array (
      'name' => 'p612',
      'id' => 2196,
    ),
    9 => 
    array (
      'name' => 'p618',
      'id' => 2389,
    ),
    10 => 
    array (
      'name' => 'p618',
      'id' => 2385,
    ),
    11 => 
    array (
      'name' => 'p619',
      'id' => 2207,
    ),
    12 => 
    array (
      'name' => 'p620',
      'id' => 2336,
    ),
    13 => 
    array (
      'name' => 'p629',
      'id' => 2139,
    ),
    14 => 
    array (
      'name' => 'p630',
      'id' => 2252,
    ),
    15 => 
    array (
      'name' => 'p636',
      'id' => 2181,
    ),
    16 => 
    array (
      'name' => 'p650wg',
      'id' => 2136,
    ),
    17 => 
    array (
      'name' => 'p668',
      'id' => 2383,
    ),
    18 => 
    array (
      'name' => 'p680',
      'id' => 2246,
    ),
    19 => 
    array (
      'name' => 'p690e',
      'id' => 2138,
    ),
    20 => 
    array (
      'name' => 'p705',
      'id' => 2391,
    ),
    21 => 
    array (
      'name' => 'p706',
      'id' => 2419,
    ),
    22 => 
    array (
      'name' => 'p707',
      'id' => 2162,
    ),
    23 => 
    array (
      'name' => 'p709',
      'id' => 2409,
    ),
    24 => 
    array (
      'name' => 'p719',
      'id' => 2384,
    ),
    25 => 
    array (
      'name' => 'p766',
      'id' => 2249,
    ),
    26 => 
    array (
      'name' => 'p780',
      'id' => 2418,
    ),
    27 => 
    array (
      'name' => 'p790',
      'id' => 2374,
    ),
    28 => 
    array (
      'name' => 'p80',
      'id' => 2335,
    ),
    29 => 
    array (
      'name' => 'p80+',
      'id' => 2137,
    ),
    30 => 
    array (
      'name' => 'p806',
      'id' => 2369,
    ),
    31 => 
    array (
      'name' => 'p809',
      'id' => 2380,
    ),
    32 => 
    array (
      'name' => 'p82',
      'id' => 2173,
    ),
    33 => 
    array (
      'name' => 'p90w',
      'id' => 2135,
    ),
    34 => 
    array (
      'name' => 'p960',
      'id' => 2351,
    ),
    35 => 
    array (
      'name' => 'p990',
      'id' => 2390,
    ),
    36 => 
    array (
      'name' => 'p992��ǿ��',
      'id' => 2171,
    ),
    37 => 
    array (
      'name' => 'p996',
      'id' => 2163,
    ),
  ),
  191 => 
  array (
    0 => 
    array (
      'name' => 'p528',
      'id' => 2706,
    ),
  ),
  345 => 
  array (
    0 => 
    array (
      'name' => 'P920',
      'id' => 3693,
    ),
    1 => 
    array (
      'name' => 'P990',
      'id' => 3694,
    ),
    2 => 
    array (
      'name' => 'P993',
      'id' => 3695,
    ),
  ),
  16 => 
  array (
    0 => 
    array (
      'name' => 'Phaser3117/3124/3125',
      'id' => 2924,
    ),
  ),
  299 => 
  array (
    0 => 
    array (
      'name' => 'PT-1010',
      'id' => 2844,
    ),
    1 => 
    array (
      'name' => 'PT-1280',
      'id' => 2834,
    ),
    2 => 
    array (
      'name' => 'PT-1650',
      'id' => 2842,
    ),
    3 => 
    array (
      'name' => 'PT-18R',
      'id' => 2843,
    ),
    4 => 
    array (
      'name' => 'PT-2100',
      'id' => 2839,
    ),
    5 => 
    array (
      'name' => 'PT-2430PC',
      'id' => 2838,
    ),
    6 => 
    array (
      'name' => 'PT-3600',
      'id' => 2841,
    ),
    7 => 
    array (
      'name' => 'PT-9700PC',
      'id' => 2837,
    ),
    8 => 
    array (
      'name' => 'PT-9800PCN',
      'id' => 2836,
    ),
    9 => 
    array (
      'name' => 'QL-570',
      'id' => 2845,
    ),
    10 => 
    array (
      'name' => 'QL-580N',
      'id' => 2840,
    ),
  ),
  170 => 
  array (
    0 => 
    array (
      'name' => 'Q11',
      'id' => 2554,
    ),
    1 => 
    array (
      'name' => 'Q8',
      'id' => 2553,
    ),
    2 => 
    array (
      'name' => 'Q9',
      'id' => 3387,
    ),
    3 => 
    array (
      'name' => 'QA1',
      'id' => 3500,
    ),
  ),
  103 => 
  array (
    0 => 
    array (
      'name' => 'Q318-DS07',
      'id' => 1907,
    ),
  ),
  315 => 
  array (
    0 => 
    array (
      'name' => 'R300',
      'id' => 3704,
    ),
    1 => 
    array (
      'name' => 'R306',
      'id' => 3705,
    ),
  ),
  101 => 
  array (
    0 => 
    array (
      'name' => 'R428-DS0L',
      'id' => 1906,
    ),
    1 => 
    array (
      'name' => 'R428-DS0M',
      'id' => 1895,
    ),
    2 => 
    array (
      'name' => 'R428-DS0N',
      'id' => 1896,
    ),
    3 => 
    array (
      'name' => 'R428-DS0P',
      'id' => 1910,
    ),
    4 => 
    array (
      'name' => 'R429-DS01',
      'id' => 1905,
    ),
    5 => 
    array (
      'name' => 'R429-DS02',
      'id' => 1909,
    ),
    6 => 
    array (
      'name' => 'R429-DS07',
      'id' => 1911,
    ),
    7 => 
    array (
      'name' => 'R430-JS01',
      'id' => 1904,
    ),
    8 => 
    array (
      'name' => 'R439-DS02',
      'id' => 1912,
    ),
    9 => 
    array (
      'name' => 'R440-JS01',
      'id' => 1913,
    ),
    10 => 
    array (
      'name' => 'R478-DT04',
      'id' => 1894,
    ),
    11 => 
    array (
      'name' => 'R480-JT03',
      'id' => 1900,
    ),
    12 => 
    array (
      'name' => 'R480-JT05',
      'id' => 1898,
    ),
    13 => 
    array (
      'name' => 'R480-JT07',
      'id' => 1899,
    ),
    14 => 
    array (
      'name' => 'R528-DS05',
      'id' => 1917,
    ),
    15 => 
    array (
      'name' => 'R528-DT01',
      'id' => 1916,
    ),
    16 => 
    array (
      'name' => 'R580-JS01',
      'id' => 1902,
    ),
    17 => 
    array (
      'name' => 'R580-JS03',
      'id' => 1903,
    ),
    18 => 
    array (
      'name' => 'R728-DS05',
      'id' => 1901,
    ),
    19 => 
    array (
      'name' => 'R728-DS06',
      'id' => 1908,
    ),
    20 => 
    array (
      'name' => 'R780-JS01',
      'id' => 1897,
    ),
    21 => 
    array (
      'name' => 'R780-JS02',
      'id' => 1915,
    ),
  ),
  149 => 
  array (
    0 => 
    array (
      'name' => 'S1',
      'id' => 2329,
    ),
    1 => 
    array (
      'name' => 'S500',
      'id' => 2327,
    ),
    2 => 
    array (
      'name' => 'S505',
      'id' => 2326,
    ),
    3 => 
    array (
      'name' => 'S600',
      'id' => 2328,
    ),
    4 => 
    array (
      'name' => 'S610',
      'id' => 2323,
    ),
    5 => 
    array (
      'name' => 'S700',
      'id' => 2325,
    ),
    6 => 
    array (
      'name' => 'S900C',
      'id' => 2324,
    ),
    7 => 
    array (
      'name' => 'S910',
      'id' => 2322,
    ),
  ),
  164 => 
  array (
    0 => 
    array (
      'name' => 'S100',
      'id' => 2487,
    ),
    1 => 
    array (
      'name' => 'S20',
      'id' => 2488,
    ),
    2 => 
    array (
      'name' => 's60',
      'id' => 2484,
    ),
  ),
  84 => 
  array (
    0 => 
    array (
      'name' => 'S1100C',
      'id' => 1970,
    ),
  ),
  121 => 
  array (
    0 => 
    array (
      'name' => 's301',
      'id' => 2238,
    ),
    1 => 
    array (
      'name' => 's320',
      'id' => 2344,
    ),
    2 => 
    array (
      'name' => 's5',
      'id' => 2404,
    ),
    3 => 
    array (
      'name' => 's50',
      'id' => 2375,
    ),
    4 => 
    array (
      'name' => 's500',
      'id' => 2131,
    ),
    5 => 
    array (
      'name' => 's520',
      'id' => 2133,
    ),
    6 => 
    array (
      'name' => 's530',
      'id' => 2362,
    ),
    7 => 
    array (
      'name' => 's533',
      'id' => 2227,
    ),
    8 => 
    array (
      'name' => 's533c',
      'id' => 2229,
    ),
    9 => 
    array (
      'name' => 's6',
      'id' => 2410,
    ),
    10 => 
    array (
      'name' => 's60',
      'id' => 2232,
    ),
    11 => 
    array (
      'name' => 's600',
      'id' => 2361,
    ),
    12 => 
    array (
      'name' => 's610',
      'id' => 2225,
    ),
    13 => 
    array (
      'name' => 's62',
      'id' => 2170,
    ),
    14 => 
    array (
      'name' => 's660',
      'id' => 2343,
    ),
    15 => 
    array (
      'name' => 's7',
      'id' => 2405,
    ),
    16 => 
    array (
      'name' => 's70',
      'id' => 2388,
    ),
    17 => 
    array (
      'name' => 's700',
      'id' => 2231,
    ),
    18 => 
    array (
      'name' => 's770',
      'id' => 2233,
    ),
    19 => 
    array (
      'name' => 's9',
      'id' => 2414,
    ),
    20 => 
    array (
      'name' => 's90',
      'id' => 2376,
    ),
    21 => 
    array (
      'name' => 's900',
      'id' => 2337,
    ),
    22 => 
    array (
      'name' => 's90��ͨ��',
      'id' => 2354,
    ),
    23 => 
    array (
      'name' => 's90�����',
      'id' => 2353,
    ),
    24 => 
    array (
      'name' => 's96',
      'id' => 2360,
    ),
  ),
  196 => 
  array (
    0 => 
    array (
      'name' => 'S302',
      'id' => 2687,
    ),
    1 => 
    array (
      'name' => 'S302',
      'id' => 3648,
    ),
    2 => 
    array (
      'name' => 'S312',
      'id' => 3665,
    ),
    3 => 
    array (
      'name' => 'S500',
      'id' => 3666,
    ),
    4 => 
    array (
      'name' => 'S550',
      'id' => 3667,
    ),
    5 => 
    array (
      'name' => 'S600',
      'id' => 2686,
    ),
    6 => 
    array (
      'name' => 'S700',
      'id' => 2685,
    ),
    7 => 
    array (
      'name' => 'SK17i',
      'id' => 3649,
    ),
  ),
  308 => 
  array (
    0 => 
    array (
      'name' => 'S500',
      'id' => 3424,
    ),
    1 => 
    array (
      'name' => 'S520',
      'id' => 3427,
    ),
    2 => 
    array (
      'name' => 'S600',
      'id' => 3431,
    ),
    3 => 
    array (
      'name' => 'S660',
      'id' => 3401,
    ),
    4 => 
    array (
      'name' => 'S668',
      'id' => 3425,
    ),
    5 => 
    array (
      'name' => 'S680',
      'id' => 3402,
    ),
    6 => 
    array (
      'name' => 'S728',
      'id' => 3428,
    ),
    7 => 
    array (
      'name' => 'S8',
      'id' => 3426,
    ),
    8 => 
    array (
      'name' => 'S800',
      'id' => 3423,
    ),
    9 => 
    array (
      'name' => 'S818',
      'id' => 3403,
    ),
    10 => 
    array (
      'name' => 'S828',
      'id' => 3429,
    ),
    11 => 
    array (
      'name' => 'S920',
      'id' => 3430,
    ),
  ),
  17 => 
  array (
    0 => 
    array (
      'name' => 'SCX-4200',
      'id' => 163,
    ),
    1 => 
    array (
      'name' => 'SCX-4521F',
      'id' => 161,
    ),
    2 => 
    array (
      'name' => 'SF-560R',
      'id' => 165,
    ),
    3 => 
    array (
      'name' => 'SF-565PR',
      'id' => 164,
    ),
  ),
  58 => 
  array (
    0 => 
    array (
      'name' => 'SL410 2842-A63',
      'id' => 2005,
    ),
    1 => 
    array (
      'name' => 'SL410 2842-A63',
      'id' => 2006,
    ),
    2 => 
    array (
      'name' => 'SL410 2842-ERC',
      'id' => 677,
    ),
    3 => 
    array (
      'name' => 'SL410 2842-EVC',
      'id' => 678,
    ),
    4 => 
    array (
      'name' => 'SL410 28748EC',
      'id' => 676,
    ),
    5 => 
    array (
      'name' => 'SL410 2874-8KC',
      'id' => 2007,
    ),
    6 => 
    array (
      'name' => 'SL410K 2842 A62',
      'id' => 2008,
    ),
    7 => 
    array (
      'name' => 'SL410K 2842ESC',
      'id' => 2009,
    ),
    8 => 
    array (
      'name' => 'SL410K 2874-7GC',
      'id' => 2004,
    ),
    9 => 
    array (
      'name' => 'SL410K 2874-7LC',
      'id' => 675,
    ),
    10 => 
    array (
      'name' => 'SL410K 2874-7MC',
      'id' => 679,
    ),
  ),
  114 => 
  array (
    0 => 
    array (
      'name' => 'Studio15R',
      'id' => 2054,
    ),
  ),
  80 => 
  array (
    0 => 
    array (
      'name' => 'T131',
      'id' => 1982,
    ),
    1 => 
    array (
      'name' => 'T132',
      'id' => 1981,
    ),
  ),
  336 => 
  array (
    0 => 
    array (
      'name' => 'T180',
      'id' => 3536,
    ),
  ),
  176 => 
  array (
    0 => 
    array (
      'name' => 'T220',
      'id' => 3606,
    ),
    1 => 
    array (
      'name' => 'T230',
      'id' => 3624,
    ),
    2 => 
    array (
      'name' => 'T238',
      'id' => 3607,
    ),
    3 => 
    array (
      'name' => 'T258',
      'id' => 3634,
    ),
    4 => 
    array (
      'name' => 'T290',
      'id' => 3625,
    ),
    5 => 
    array (
      'name' => 'T303',
      'id' => 3609,
    ),
    6 => 
    array (
      'name' => 'T600',
      'id' => 2569,
    ),
    7 => 
    array (
      'name' => 'T608',
      'id' => 3582,
    ),
    8 => 
    array (
      'name' => 'T610',
      'id' => 2573,
    ),
    9 => 
    array (
      'name' => 'T618',
      'id' => 3604,
    ),
    10 => 
    array (
      'name' => 'T620',
      'id' => 2570,
    ),
    11 => 
    array (
      'name' => 'T628',
      'id' => 3605,
    ),
    12 => 
    array (
      'name' => 'T630',
      'id' => 3581,
    ),
    13 => 
    array (
      'name' => 'T638',
      'id' => 3583,
    ),
    14 => 
    array (
      'name' => 'T650',
      'id' => 3627,
    ),
    15 => 
    array (
      'name' => 'T658',
      'id' => 3628,
    ),
    16 => 
    array (
      'name' => 'T700',
      'id' => 3626,
    ),
    17 => 
    array (
      'name' => 'T707',
      'id' => 3629,
    ),
    18 => 
    array (
      'name' => 'T707a',
      'id' => 3630,
    ),
    19 => 
    array (
      'name' => 'T715',
      'id' => 3608,
    ),
  ),
  147 => 
  array (
    0 => 
    array (
      'name' => 'T3333',
      'id' => 2316,
    ),
    1 => 
    array (
      'name' => 'T5388',
      'id' => 2319,
    ),
    2 => 
    array (
      'name' => 'T5388W',
      'id' => 2318,
    ),
    3 => 
    array (
      'name' => 'T5399',
      'id' => 2315,
    ),
    4 => 
    array (
      'name' => 'T8388',
      'id' => 2320,
    ),
    5 => 
    array (
      'name' => 'T8588',
      'id' => 2317,
    ),
    6 => 
    array (
      'name' => 'Touch Cruise',
      'id' => 2330,
    ),
    7 => 
    array (
      'name' => 'Touch Diamond',
      'id' => 2333,
    ),
    8 => 
    array (
      'name' => 'Touch HD',
      'id' => 2331,
    ),
    9 => 
    array (
      'name' => 'Touch Pro',
      'id' => 2332,
    ),
    10 => 
    array (
      'name' => 'Touch Viva',
      'id' => 2334,
    ),
  ),
  59 => 
  array (
    0 => 
    array (
      'name' => 'T400 2767-MZ1',
      'id' => 2015,
    ),
    1 => 
    array (
      'name' => 'T410i 2516A21',
      'id' => 2011,
    ),
    2 => 
    array (
      'name' => 'T410i 2516A24',
      'id' => 2010,
    ),
    3 => 
    array (
      'name' => 'T410i 2518-G4C',
      'id' => 2013,
    ),
    4 => 
    array (
      'name' => 'T410i 2518-G5C',
      'id' => 2012,
    ),
    5 => 
    array (
      'name' => 'T410i 2518-JKC',
      'id' => 2014,
    ),
  ),
  72 => 
  array (
    0 => 
    array (
      'name' => 'T510 2055DC1',
      'id' => 2025,
    ),
    1 => 
    array (
      'name' => 'T510 43145VC',
      'id' => 2023,
    ),
    2 => 
    array (
      'name' => 'T510 4349A54',
      'id' => 2020,
    ),
    3 => 
    array (
      'name' => 'T510 4349AH1',
      'id' => 2022,
    ),
    4 => 
    array (
      'name' => 'T510i-43148ZC',
      'id' => 2019,
    ),
  ),
  327 => 
  array (
    0 => 
    array (
      'name' => 'T550',
      'id' => 3400,
    ),
    1 => 
    array (
      'name' => 'T552',
      'id' => 3422,
    ),
  ),
  313 => 
  array (
    0 => 
    array (
      'name' => 'T959',
      'id' => 3549,
    ),
  ),
  120 => 
  array (
    0 => 
    array (
      'name' => 'td10',
      'id' => 2120,
    ),
    1 => 
    array (
      'name' => 'td105',
      'id' => 2215,
    ),
    2 => 
    array (
      'name' => 'td115',
      'id' => 2125,
    ),
    3 => 
    array (
      'name' => 'td165',
      'id' => 2122,
    ),
    4 => 
    array (
      'name' => 'td30t',
      'id' => 2124,
    ),
    5 => 
    array (
      'name' => 'TD60t',
      'id' => 2119,
    ),
    6 => 
    array (
      'name' => 'td800',
      'id' => 2371,
    ),
    7 => 
    array (
      'name' => 'td80t',
      'id' => 2123,
    ),
    8 => 
    array (
      'name' => 'td900',
      'id' => 2370,
    ),
  ),
  179 => 
  array (
    0 => 
    array (
      'name' => 'U100i',
      'id' => 2592,
    ),
    1 => 
    array (
      'name' => 'U10i',
      'id' => 2585,
    ),
    2 => 
    array (
      'name' => 'U1i',
      'id' => 2583,
    ),
    3 => 
    array (
      'name' => 'U20i',
      'id' => 2586,
    ),
    4 => 
    array (
      'name' => 'U5i',
      'id' => 3637,
    ),
    5 => 
    array (
      'name' => 'U8i',
      'id' => 3619,
    ),
  ),
  331 => 
  array (
    0 => 
    array (
      'name' => 'U6',
      'id' => 3534,
    ),
    1 => 
    array (
      'name' => 'U6c',
      'id' => 3535,
    ),
    2 => 
    array (
      'name' => 'U8',
      'id' => 3533,
    ),
    3 => 
    array (
      'name' => 'U9',
      'id' => 3522,
    ),
  ),
  192 => 
  array (
    0 => 
    array (
      'name' => 'U708E',
      'id' => 2700,
    ),
    1 => 
    array (
      'name' => 'U808e',
      'id' => 2684,
    ),
    2 => 
    array (
      'name' => 'u908e',
      'id' => 2704,
    ),
    3 => 
    array (
      'name' => 'U940',
      'id' => 3552,
    ),
    4 => 
    array (
      'name' => 'U948',
      'id' => 3553,
    ),
  ),
  324 => 
  array (
    0 => 
    array (
      'name' => 'U7510',
      'id' => 3416,
    ),
    1 => 
    array (
      'name' => 'U7519',
      'id' => 3397,
    ),
    2 => 
    array (
      'name' => 'U8110',
      'id' => 3414,
    ),
    3 => 
    array (
      'name' => 'U8150',
      'id' => 3420,
    ),
    4 => 
    array (
      'name' => 'U8220',
      'id' => 3417,
    ),
    5 => 
    array (
      'name' => 'U8320',
      'id' => 3418,
    ),
    6 => 
    array (
      'name' => 'U8500',
      'id' => 3413,
    ),
    7 => 
    array (
      'name' => 'U8500',
      'id' => 3415,
    ),
    8 => 
    array (
      'name' => 'U8800',
      'id' => 3398,
    ),
    9 => 
    array (
      'name' => 'U9120',
      'id' => 3419,
    ),
  ),
  100 => 
  array (
    0 => 
    array (
      'name' => 'UL20G23A',
      'id' => 1931,
    ),
    1 => 
    array (
      'name' => 'UL20G73A',
      'id' => 1930,
    ),
    2 => 
    array (
      'name' => 'UL20G743A',
      'id' => 1929,
    ),
  ),
  93 => 
  array (
    0 => 
    array (
      'name' => 'UL30K23Vt',
      'id' => 1948,
    ),
    1 => 
    array (
      'name' => 'UL30K23Vt',
      'id' => 1951,
    ),
    2 => 
    array (
      'name' => 'UL30K73Vt',
      'id' => 1949,
    ),
    3 => 
    array (
      'name' => 'UL30K73Vt',
      'id' => 1950,
    ),
    4 => 
    array (
      'name' => 'UL30KU35A',
      'id' => 1952,
    ),
  ),
  94 => 
  array (
    0 => 
    array (
      'name' => 'UL80E73Vt',
      'id' => 1953,
    ),
  ),
  167 => 
  array (
    0 => 
    array (
      'name' => 'V10',
      'id' => 3319,
    ),
    1 => 
    array (
      'name' => 'V1050',
      'id' => 3346,
    ),
    2 => 
    array (
      'name' => 'V190',
      'id' => 3334,
    ),
    3 => 
    array (
      'name' => 'V191',
      'id' => 3347,
    ),
    4 => 
    array (
      'name' => 'V195',
      'id' => 3348,
    ),
    5 => 
    array (
      'name' => 'V196',
      'id' => 3338,
    ),
    6 => 
    array (
      'name' => 'V235',
      'id' => 3335,
    ),
    7 => 
    array (
      'name' => 'V235',
      'id' => 3339,
    ),
    8 => 
    array (
      'name' => 'V237',
      'id' => 3336,
    ),
    9 => 
    array (
      'name' => 'V237',
      'id' => 3349,
    ),
    10 => 
    array (
      'name' => 'V3',
      'id' => 3320,
    ),
    11 => 
    array (
      'name' => 'V323',
      'id' => 3345,
    ),
    12 => 
    array (
      'name' => 'V360',
      'id' => 3337,
    ),
    13 => 
    array (
      'name' => 'V365',
      'id' => 3340,
    ),
    14 => 
    array (
      'name' => 'V367',
      'id' => 3341,
    ),
    15 => 
    array (
      'name' => 'V3c',
      'id' => 3321,
    ),
    16 => 
    array (
      'name' => 'V3e',
      'id' => 3323,
    ),
    17 => 
    array (
      'name' => 'V3i',
      'id' => 3322,
    ),
    18 => 
    array (
      'name' => 'V3m',
      'id' => 3344,
    ),
    19 => 
    array (
      'name' => 'V3x',
      'id' => 3342,
    ),
    20 => 
    array (
      'name' => 'V750',
      'id' => 3508,
    ),
    21 => 
    array (
      'name' => 'V8',
      'id' => 3317,
    ),
    22 => 
    array (
      'name' => 'V9',
      'id' => 3333,
    ),
    23 => 
    array (
      'name' => 'V9m',
      'id' => 3318,
    ),
  ),
  107 => 
  array (
    0 => 
    array (
      'name' => 'V1088',
      'id' => 1858,
    ),
    1 => 
    array (
      'name' => 'V1088R',
      'id' => 2028,
    ),
  ),
  329 => 
  array (
    0 => 
    array (
      'name' => 'V205',
      'id' => 3474,
    ),
    1 => 
    array (
      'name' => 'V206',
      'id' => 3475,
    ),
  ),
  314 => 
  array (
    0 => 
    array (
      'name' => 'V600',
      'id' => 3686,
    ),
    1 => 
    array (
      'name' => 'V800',
      'id' => 3685,
    ),
    2 => 
    array (
      'name' => 'V802',
      'id' => 3660,
    ),
    3 => 
    array (
      'name' => 'Vivaz Pro',
      'id' => 3661,
    ),
  ),
  151 => 
  array (
    0 => 
    array (
      'name' => 'v600',
      'id' => 2395,
    ),
    1 => 
    array (
      'name' => 'v608',
      'id' => 2377,
    ),
    2 => 
    array (
      'name' => 'v700',
      'id' => 2378,
    ),
    3 => 
    array (
      'name' => 'v770',
      'id' => 2411,
    ),
    4 => 
    array (
      'name' => 'v80',
      'id' => 2379,
    ),
  ),
  153 => 
  array (
    0 => 
    array (
      'name' => 'v808',
      'id' => 2445,
    ),
    1 => 
    array (
      'name' => 'v900',
      'id' => 2422,
    ),
  ),
  333 => 
  array (
    0 => 
    array (
      'name' => 'VE538',
      'id' => 3521,
    ),
    1 => 
    array (
      'name' => 'VE66',
      'id' => 3532,
    ),
  ),
  175 => 
  array (
    0 => 
    array (
      'name' => 'W100i',
      'id' => 2557,
    ),
    1 => 
    array (
      'name' => 'W150',
      'id' => 3599,
    ),
    2 => 
    array (
      'name' => 'W200',
      'id' => 3573,
    ),
    3 => 
    array (
      'name' => 'W205',
      'id' => 3594,
    ),
    4 => 
    array (
      'name' => 'W20i',
      'id' => 3618,
    ),
    5 => 
    array (
      'name' => 'W300',
      'id' => 2558,
    ),
    6 => 
    array (
      'name' => 'W302',
      'id' => 2559,
    ),
    7 => 
    array (
      'name' => 'W350',
      'id' => 3593,
    ),
    8 => 
    array (
      'name' => 'W380',
      'id' => 3602,
    ),
    9 => 
    array (
      'name' => 'W395',
      'id' => 2560,
    ),
    10 => 
    array (
      'name' => 'W508',
      'id' => 3579,
    ),
    11 => 
    array (
      'name' => 'W550',
      'id' => 3595,
    ),
    12 => 
    array (
      'name' => 'W580',
      'id' => 3576,
    ),
    13 => 
    array (
      'name' => 'W595',
      'id' => 2561,
    ),
    14 => 
    array (
      'name' => 'W600',
      'id' => 3596,
    ),
    15 => 
    array (
      'name' => 'W610',
      'id' => 2562,
    ),
    16 => 
    array (
      'name' => 'W660',
      'id' => 2563,
    ),
    17 => 
    array (
      'name' => 'W700',
      'id' => 3574,
    ),
    18 => 
    array (
      'name' => 'W705',
      'id' => 2564,
    ),
    19 => 
    array (
      'name' => 'W710',
      'id' => 3597,
    ),
    20 => 
    array (
      'name' => 'W715',
      'id' => 2565,
    ),
    21 => 
    array (
      'name' => 'W760',
      'id' => 3600,
    ),
    22 => 
    array (
      'name' => 'W800',
      'id' => 3575,
    ),
    23 => 
    array (
      'name' => 'W810',
      'id' => 3598,
    ),
    24 => 
    array (
      'name' => 'W830',
      'id' => 2566,
    ),
    25 => 
    array (
      'name' => 'W850',
      'id' => 2681,
    ),
    26 => 
    array (
      'name' => 'W880',
      'id' => 3586,
    ),
    27 => 
    array (
      'name' => 'W888',
      'id' => 3587,
    ),
    28 => 
    array (
      'name' => 'W890',
      'id' => 3588,
    ),
    29 => 
    array (
      'name' => 'W898',
      'id' => 3589,
    ),
    30 => 
    array (
      'name' => 'W900',
      'id' => 3590,
    ),
    31 => 
    array (
      'name' => 'W902',
      'id' => 3577,
    ),
    32 => 
    array (
      'name' => 'W908',
      'id' => 3603,
    ),
    33 => 
    array (
      'name' => 'W910',
      'id' => 3580,
    ),
    34 => 
    array (
      'name' => 'W950',
      'id' => 3591,
    ),
    35 => 
    array (
      'name' => 'W958',
      'id' => 3592,
    ),
    36 => 
    array (
      'name' => 'W960',
      'id' => 3572,
    ),
    37 => 
    array (
      'name' => 'W980',
      'id' => 3601,
    ),
    38 => 
    array (
      'name' => 'W995',
      'id' => 3578,
    ),
  ),
  168 => 
  array (
    0 => 
    array (
      'name' => 'W156',
      'id' => 3357,
    ),
    1 => 
    array (
      'name' => 'W170',
      'id' => 3358,
    ),
    2 => 
    array (
      'name' => 'W175',
      'id' => 3369,
    ),
    3 => 
    array (
      'name' => 'W175',
      'id' => 3350,
    ),
    4 => 
    array (
      'name' => 'W177',
      'id' => 3343,
    ),
    5 => 
    array (
      'name' => 'W205',
      'id' => 3359,
    ),
    6 => 
    array (
      'name' => 'W206',
      'id' => 3364,
    ),
    7 => 
    array (
      'name' => 'w208',
      'id' => 2543,
    ),
    8 => 
    array (
      'name' => 'W210',
      'id' => 3360,
    ),
    9 => 
    array (
      'name' => 'W215',
      'id' => 3351,
    ),
    10 => 
    array (
      'name' => 'W215',
      'id' => 3361,
    ),
    11 => 
    array (
      'name' => 'W216',
      'id' => 3370,
    ),
    12 => 
    array (
      'name' => 'W218',
      'id' => 3365,
    ),
    13 => 
    array (
      'name' => 'W220',
      'id' => 3352,
    ),
    14 => 
    array (
      'name' => 'W230',
      'id' => 3353,
    ),
    15 => 
    array (
      'name' => 'W231',
      'id' => 3366,
    ),
    16 => 
    array (
      'name' => 'W233',
      'id' => 3354,
    ),
    17 => 
    array (
      'name' => 'W265',
      'id' => 3355,
    ),
    18 => 
    array (
      'name' => 'W270',
      'id' => 3367,
    ),
    19 => 
    array (
      'name' => 'W315',
      'id' => 3362,
    ),
    20 => 
    array (
      'name' => 'w355',
      'id' => 2541,
    ),
    21 => 
    array (
      'name' => 'w360',
      'id' => 2545,
    ),
    22 => 
    array (
      'name' => 'w362',
      'id' => 2544,
    ),
    23 => 
    array (
      'name' => 'W371',
      'id' => 3356,
    ),
    24 => 
    array (
      'name' => 'w375',
      'id' => 2547,
    ),
    25 => 
    array (
      'name' => 'W385',
      'id' => 3363,
    ),
    26 => 
    array (
      'name' => 'w388',
      'id' => 2542,
    ),
    27 => 
    array (
      'name' => 'w396',
      'id' => 2540,
    ),
    28 => 
    array (
      'name' => 'W490',
      'id' => 3384,
    ),
    29 => 
    array (
      'name' => 'W5',
      'id' => 3371,
    ),
    30 => 
    array (
      'name' => 'W510',
      'id' => 3385,
    ),
    31 => 
    array (
      'name' => 'W562',
      'id' => 3368,
    ),
    32 => 
    array (
      'name' => 'W6',
      'id' => 3372,
    ),
    33 => 
    array (
      'name' => 'w7',
      'id' => 2539,
    ),
  ),
  190 => 
  array (
    0 => 
    array (
      'name' => 'w159',
      'id' => 2785,
    ),
    1 => 
    array (
      'name' => 'w159',
      'id' => 2711,
    ),
    2 => 
    array (
      'name' => 'w239',
      'id' => 2770,
    ),
    3 => 
    array (
      'name' => 'w299',
      'id' => 2781,
    ),
    4 => 
    array (
      'name' => 'w299',
      'id' => 2660,
    ),
    5 => 
    array (
      'name' => 'w589',
      'id' => 2748,
    ),
    6 => 
    array (
      'name' => 'w599',
      'id' => 2786,
    ),
    7 => 
    array (
      'name' => 'w599',
      'id' => 2712,
    ),
    8 => 
    array (
      'name' => 'w699',
      'id' => 2780,
    ),
    9 => 
    array (
      'name' => 'w699',
      'id' => 2657,
    ),
    10 => 
    array (
      'name' => 'w709',
      'id' => 2753,
    ),
    11 => 
    array (
      'name' => 'w709',
      'id' => 2778,
    ),
    12 => 
    array (
      'name' => 'w799',
      'id' => 2752,
    ),
  ),
  163 => 
  array (
    0 => 
    array (
      'name' => 'w700',
      'id' => 2480,
    ),
  ),
  169 => 
  array (
    0 => 
    array (
      'name' => 'wx160',
      'id' => 2552,
    ),
    1 => 
    array (
      'name' => 'wx180',
      'id' => 2549,
    ),
    2 => 
    array (
      'name' => 'wx260',
      'id' => 2548,
    ),
    3 => 
    array (
      'name' => 'WX270',
      'id' => 3386,
    ),
    4 => 
    array (
      'name' => 'wx390',
      'id' => 2551,
    ),
    5 => 
    array (
      'name' => 'wx395',
      'id' => 2550,
    ),
  ),
  180 => 
  array (
    0 => 
    array (
      'name' => 'X1',
      'id' => 2598,
    ),
    1 => 
    array (
      'name' => 'X10',
      'id' => 3639,
    ),
    2 => 
    array (
      'name' => 'X10mini pro',
      'id' => 2595,
    ),
    3 => 
    array (
      'name' => 'X2',
      'id' => 3638,
    ),
    4 => 
    array (
      'name' => 'X8',
      'id' => 3621,
    ),
    5 => 
    array (
      'name' => 'Xperia arc LT15i',
      'id' => 3644,
    ),
    6 => 
    array (
      'name' => 'Xperia mini',
      'id' => 3622,
    ),
    7 => 
    array (
      'name' => 'Xperia mini pro',
      'id' => 3640,
    ),
    8 => 
    array (
      'name' => 'Xperia Neo MT15i',
      'id' => 3641,
    ),
    9 => 
    array (
      'name' => 'Xperia Play R800i',
      'id' => 3620,
    ),
    10 => 
    array (
      'name' => 'Xperia pro MK16i',
      'id' => 3623,
    ),
  ),
  152 => 
  array (
    0 => 
    array (
      'name' => 'x100',
      'id' => 2428,
    ),
    1 => 
    array (
      'name' => 'x100',
      'id' => 2434,
    ),
    2 => 
    array (
      'name' => 'x320',
      'id' => 2441,
    ),
    3 => 
    array (
      'name' => 'x501',
      'id' => 2442,
    ),
    4 => 
    array (
      'name' => 'x503',
      'id' => 2421,
    ),
    5 => 
    array (
      'name' => 'x510',
      'id' => 2425,
    ),
    6 => 
    array (
      'name' => 'x530',
      'id' => 2446,
    ),
    7 => 
    array (
      'name' => 'x603',
      'id' => 2433,
    ),
    8 => 
    array (
      'name' => 'x603',
      'id' => 2438,
    ),
    9 => 
    array (
      'name' => 'x605',
      'id' => 2435,
    ),
    10 => 
    array (
      'name' => 'x605',
      'id' => 2429,
    ),
    11 => 
    array (
      'name' => 'x606',
      'id' => 2420,
    ),
    12 => 
    array (
      'name' => 'x703',
      'id' => 2430,
    ),
    13 => 
    array (
      'name' => 'x712',
      'id' => 2424,
    ),
    14 => 
    array (
      'name' => 'x712',
      'id' => 2436,
    ),
    15 => 
    array (
      'name' => 'x806',
      'id' => 2427,
    ),
    16 => 
    array (
      'name' => 'x806',
      'id' => 2444,
    ),
    17 => 
    array (
      'name' => 'x809',
      'id' => 2426,
    ),
    18 => 
    array (
      'name' => 'x830',
      'id' => 2443,
    ),
  ),
  126 => 
  array (
    0 => 
    array (
      'name' => 'X1-00',
      'id' => 3193,
    ),
    1 => 
    array (
      'name' => 'X2-00',
      'id' => 2154,
    ),
    2 => 
    array (
      'name' => 'X2-01',
      'id' => 2979,
    ),
    3 => 
    array (
      'name' => 'X3-00',
      'id' => 2155,
    ),
    4 => 
    array (
      'name' => 'x3-02',
      'id' => 3026,
    ),
    5 => 
    array (
      'name' => 'X5-00',
      'id' => 2156,
    ),
    6 => 
    array (
      'name' => 'x5-01',
      'id' => 3009,
    ),
    7 => 
    array (
      'name' => 'X6-00',
      'id' => 2158,
    ),
    8 => 
    array (
      'name' => 'X6M',
      'id' => 3176,
    ),
    9 => 
    array (
      'name' => 'X7',
      'id' => 2981,
    ),
  ),
  9 => 
  array (
    0 => 
    array (
      'name' => 'X201i 324939C',
      'id' => 668,
    ),
    1 => 
    array (
      'name' => 'X201i 324939C',
      'id' => 1878,
    ),
    2 => 
    array (
      'name' => 'X201i 324939C',
      'id' => 1879,
    ),
    3 => 
    array (
      'name' => 'X201i 32493DC',
      'id' => 669,
    ),
    4 => 
    array (
      'name' => 'X201i 32493DC',
      'id' => 670,
    ),
    5 => 
    array (
      'name' => 'X201i 32493DC',
      'id' => 671,
    ),
    6 => 
    array (
      'name' => 'X201i 32493HC',
      'id' => 674,
    ),
    7 => 
    array (
      'name' => 'X201i 3249-3JC',
      'id' => 2003,
    ),
    8 => 
    array (
      'name' => 'X201i 3249-J3C',
      'id' => 672,
    ),
    9 => 
    array (
      'name' => 'X201i 3249-J4C',
      'id' => 1881,
    ),
    10 => 
    array (
      'name' => 'X201i 3249JFC',
      'id' => 1880,
    ),
    11 => 
    array (
      'name' => 'X201i 3249JNC',
      'id' => 673,
    ),
    12 => 
    array (
      'name' => 'X201i 3249-MUC',
      'id' => 2002,
    ),
    13 => 
    array (
      'name' => 'X201i 3323 JVC',
      'id' => 1999,
    ),
    14 => 
    array (
      'name' => 'X201i 3323 K6C',
      'id' => 2000,
    ),
    15 => 
    array (
      'name' => 'X201i 3323 K8C',
      'id' => 1998,
    ),
    16 => 
    array (
      'name' => 'X201i 3323 K9C',
      'id' => 2001,
    ),
  ),
  71 => 
  array (
    0 => 
    array (
      'name' => 'X301 2774-AV6',
      'id' => 2016,
    ),
    1 => 
    array (
      'name' => 'X301 2774-HF2',
      'id' => 684,
    ),
    2 => 
    array (
      'name' => 'X301 2774-HF3',
      'id' => 2018,
    ),
    3 => 
    array (
      'name' => 'X301 2774-HF4',
      'id' => 686,
    ),
    4 => 
    array (
      'name' => 'X301 2774-HF5',
      'id' => 687,
    ),
    5 => 
    array (
      'name' => 'X301 2774-HG1',
      'id' => 685,
    ),
    6 => 
    array (
      'name' => 'X301 2774-HH1',
      'id' => 2017,
    ),
  ),
  102 => 
  array (
    0 => 
    array (
      'name' => 'X418-DA02',
      'id' => 1914,
    ),
  ),
  200 => 
  array (
    0 => 
    array (
      'name' => 'X60',
      'id' => 2823,
    ),
    1 => 
    array (
      'name' => 'X60s',
      'id' => 2824,
    ),
    2 => 
    array (
      'name' => 'X61',
      'id' => 2827,
    ),
    3 => 
    array (
      'name' => 'X61',
      'id' => 2021,
    ),
  ),
  96 => 
  array (
    0 => 
    array (
      'name' => 'X88E667VD-SL',
      'id' => 1928,
    ),
    1 => 
    array (
      'name' => 'X8AES12AF-SL',
      'id' => 1955,
    ),
    2 => 
    array (
      'name' => 'X8E22DAc-SL',
      'id' => 1927,
    ),
  ),
  117 => 
  array (
    0 => 
    array (
      'name' => 'XT3',
      'id' => 3294,
    ),
    1 => 
    array (
      'name' => 'XT300',
      'id' => 3287,
    ),
    2 => 
    array (
      'name' => 'XT301',
      'id' => 3288,
    ),
    3 => 
    array (
      'name' => 'XT316',
      'id' => 3691,
    ),
    4 => 
    array (
      'name' => 'XT5',
      'id' => 3307,
    ),
    5 => 
    array (
      'name' => 'XT500',
      'id' => 3308,
    ),
    6 => 
    array (
      'name' => 'XT502',
      'id' => 3309,
    ),
    7 => 
    array (
      'name' => 'XT610',
      'id' => 3292,
    ),
    8 => 
    array (
      'name' => 'XT701',
      'id' => 3263,
    ),
    9 => 
    array (
      'name' => 'XT702',
      'id' => 3304,
    ),
    10 => 
    array (
      'name' => 'XT711',
      'id' => 3305,
    ),
    11 => 
    array (
      'name' => 'XT720',
      'id' => 3291,
    ),
    12 => 
    array (
      'name' => 'XT800',
      'id' => 3293,
    ),
    13 => 
    array (
      'name' => 'XT800+',
      'id' => 3306,
    ),
    14 => 
    array (
      'name' => 'XT806',
      'id' => 3289,
    ),
    15 => 
    array (
      'name' => 'XT806lx',
      'id' => 3290,
    ),
    16 => 
    array (
      'name' => 'XT882',
      'id' => 3692,
    ),
    17 => 
    array (
      'name' => 'XT883',
      'id' => 3690,
    ),
  ),
  312 => 
  array (
    0 => 
    array (
      'name' => 'Z1',
      'id' => 3502,
    ),
    1 => 
    array (
      'name' => 'Z10',
      'id' => 3525,
    ),
    2 => 
    array (
      'name' => 'Z3',
      'id' => 3511,
    ),
    3 => 
    array (
      'name' => 'Z6',
      'id' => 3512,
    ),
    4 => 
    array (
      'name' => 'Z6m',
      'id' => 3514,
    ),
    5 => 
    array (
      'name' => 'Z6w',
      'id' => 3513,
    ),
    6 => 
    array (
      'name' => 'Z8',
      'id' => 3516,
    ),
    7 => 
    array (
      'name' => 'Z9',
      'id' => 3524,
    ),
    8 => 
    array (
      'name' => 'ZN200',
      'id' => 3526,
    ),
    9 => 
    array (
      'name' => 'ZN300',
      'id' => 3527,
    ),
    10 => 
    array (
      'name' => 'ZN5',
      'id' => 3503,
    ),
    11 => 
    array (
      'name' => 'ZN50',
      'id' => 3515,
    ),
  ),
  339 => 
  array (
    0 => 
    array (
      'name' => 'Z1010',
      'id' => 3651,
    ),
    1 => 
    array (
      'name' => 'Z1i',
      'id' => 3684,
    ),
    2 => 
    array (
      'name' => 'Z208',
      'id' => 3676,
    ),
    3 => 
    array (
      'name' => 'Z300',
      'id' => 3681,
    ),
    4 => 
    array (
      'name' => 'Z310',
      'id' => 3657,
    ),
    5 => 
    array (
      'name' => 'Z320',
      'id' => 3679,
    ),
    6 => 
    array (
      'name' => 'Z500',
      'id' => 3677,
    ),
    7 => 
    array (
      'name' => 'Z520',
      'id' => 3682,
    ),
    8 => 
    array (
      'name' => 'Z530',
      'id' => 3653,
    ),
    9 => 
    array (
      'name' => 'Z550',
      'id' => 3680,
    ),
    10 => 
    array (
      'name' => 'Z558',
      'id' => 3658,
    ),
    11 => 
    array (
      'name' => 'Z600',
      'id' => 3675,
    ),
    12 => 
    array (
      'name' => 'Z608',
      'id' => 3652,
    ),
    13 => 
    array (
      'name' => 'Z610',
      'id' => 3678,
    ),
    14 => 
    array (
      'name' => 'Z710',
      'id' => 3659,
    ),
    15 => 
    array (
      'name' => 'Z750',
      'id' => 3654,
    ),
    16 => 
    array (
      'name' => 'Z770',
      'id' => 3683,
    ),
    17 => 
    array (
      'name' => 'Z780',
      'id' => 3655,
    ),
    18 => 
    array (
      'name' => 'Z800',
      'id' => 3656,
    ),
  ),
  42 => 
  array (
    0 => 
    array (
      'name' => '��200',
      'id' => 314,
    ),
    1 => 
    array (
      'name' => '��230',
      'id' => 280,
    ),
    2 => 
    array (
      'name' => '��300',
      'id' => 304,
    ),
    3 => 
    array (
      'name' => '��330',
      'id' => 282,
    ),
    4 => 
    array (
      'name' => '��350',
      'id' => 305,
    ),
    5 => 
    array (
      'name' => '��450',
      'id' => 265,
    ),
    6 => 
    array (
      'name' => '��500',
      'id' => 274,
    ),
    7 => 
    array (
      'name' => '��550',
      'id' => 272,
    ),
    8 => 
    array (
      'name' => '��850',
      'id' => 267,
    ),
    9 => 
    array (
      'name' => '��900',
      'id' => 297,
    ),
  ),
  128 => 
  array (
    0 => 
    array (
      'name' => '��phone',
      'id' => 2157,
    ),
  ),
  137 => 
  array (
    0 => 
    array (
      'name' => '���롮�����ֻ�',
      'id' => 2218,
    ),
    1 => 
    array (
      'name' => '���롮���ֻ�',
      'id' => 2220,
    ),
  ),
  316 => 
  array (
    0 => 
    array (
      'name' => '����(T9188)',
      'id' => 3713,
    ),
  ),
);?>