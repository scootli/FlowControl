<?php
class ConfigVersion {
	public static $Javascript = array(
		'CART'				=> '2013061802',
		'GLOBAL'			=> '2013061801',
		'CART'				=> '2013061802',
		'ORDER'				=> '2013062501',
		'FORM_CTRL'			=> '2012103014',
		'AREA'				=> '2012103014',
		'LIST' 				=> '2012103014',
		'ITEMDETAIL'		=> '2013013101',
		'CP_ORDER'			=> '2013062004',
		'FCATEGORY_COMMON'  => '2012103014',
		'MORNING'  			=> '2012103014',
		'INDEX'				=> '2013031101',
	);
	public static $CSS = array(
		"HEADER_FULL" 		=> '2012103014',
		"HEADER_MIN" 		=> '2012103014',
		"LIST" 				=> '2013010811',
		"GB" 				=> '2013050201',
		"INDEX" 			=> '2013050301',
		'MORNING'  			=> '2012120701',
		'ACT_HELP'			=> '2012103014',
		'M_PAGE'			=> '2012103014', //����ҳ
		'PAGE'				=> '2012103014', //����ҳ
	);

	public static function getJsVer($mark){
		if (isset(self::$Javascript[$mark])) {
			return self::$Javascript[$mark];
		}else {
			return '2012103014';
		}
	}

	public static function getCssVer($mark){
		if (isset(self::$CSS[$mark])) {
			return self::$CSS[$mark];
		}else {
			return '2012103014';
		}
	}
}
