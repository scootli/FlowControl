<?php
class ConfigMobileAccessory {
	static $quickSelect = array(
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/apple.jpg',
				'alt' => 'ƻ��',
				'title' => 'ƻ��',
				'bid' => 11
			),
			'list' => array(
				array(
					'name' => 'iPhone 5',
					'mid' => 0,
					'url' => 'http://list.51buy.com/1533-0-6-11-40-0-1-6887e43127-.html'
				),
				array(
					'name' => 'iPhone 4S',
					'mid' => 0,
					'url' => 'http://list.51buy.com/1533-0-6-11-40-0-1-6887e38697o39500-.html'
				),
				array(
					'name' => 'iPhone 4',
					'mid' => 0,
					'url' => 'http://list.51buy.com/1533-0-6-11-40-0-1-6887e30902-.html'
				)
			)
		),
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/samsung.jpg',
				'alt' => '����',
				'title' => '����',
				'bid' => 13
			),
			'list' => array(
				array(
					'name' => 'I9220',
					'mid' => 3814
				),
				array(
					'name' => 'I9300',
					'mid' => 3798
				),
//				array(
//					'name' => 'S7562I',
//					'mid' => 4204
//				),
				array(
					'name' => 'I9100',
					'mid' => 3716
				),
				array(
					'name' => 'I8160',
					'mid' => 4258
				),
				array(
					'name' => '5830I',
					'mid' => 3860
				)
			)
		),
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/nokia.jpg',
				'alt' => 'ŵ����',
				'title' => 'ŵ����',
				'bid' => 11
			),
			'list' => array(
				array(
					'name' => 'lumia800',
					'mid' => 4264
				),
				array(
					'name' => 'lumia900',
					'mid' => 4273
				),
				array(
					'name' => 'lumia610',
					'mid' => 4280
				),
				array(
					'name' => 'lumia510',
					'mid' => 4276
				),
				array(
					'name' => 'lumia920',
					'mid' => 4274
				)
			)
		),
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/motorola.jpg',
				'alt' => 'Ħ������',
				'title' => 'Ħ������',
				'bid' => 12
			),
			'list' => array(
				array(
					'name' => 'XT928',
					'mid' => 3787
				),
				array(
					'name' => 'XT882',
					'mid' => 3692
				),
				array(
					'name' => 'MT917',
					'mid' => 3836
				),
				array(
					'name' => 'XT550',
					'mid' => 3811
				),
				array(
					'name' => 'XT615',
					'mid' => 3790
				),
				array(
					'name' => 'ME811',
					'mid' => 3256
				),
				array(
					'name' => 'XT910',
					'mid' => 3807
				)
			)
		),
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/htc.jpg',
				'alt' => 'HTC',
				'title' => 'HTC',
				'bid' => 42
			),
			'list' => array(
				array(
					'name' => 'T528w',
					'mid' => 4287
				),
				array(
					'name' => 'T528t',
					'mid' => 4288
				),
				array(
					'name' => 'T528d',
					'mid' => 4307
				),
				array(
					'name' => 'T328d',
					'mid' => 4308
				),
//				array(
//					'name' => 'T9188',
//					'mid' => 10001
//				),
				array(
					'name' => 'Z710e(G14)',
					'mid' => 2989
				)
			)
		),
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/huawei.jpg',
				'alt' => '��Ϊ',
				'title' => '��Ϊ',
				'bid' => 43
			),
			'list' => array(
				array(
					'name' => 'C8950D',
					'mid' => 4269
				),
				array(
					'name' => 'U8860',
					'mid' => 3764
				),
				array(
					'name' => 'S8600',
					'mid' => 3909
				)
			)
		),
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/zte.jpg',
				'alt' => '����',
				'title' => '����',
				'bid' => 63
			),
			'list' => array(
				array(
					'name' => 'V985',
					'mid' => 4271
				),
				array(
					'name' => 'V961',
					'mid' => 3947
				),
//				array(
//					'name' => 'V889M',
//					'mid' => 4309 
//				),
//				array(
//					'name' => 'U930',
//					'mid' => 4195
//				),
				array(
					'name' => 'U880E',
					'mid' => 3922
				),
				array(
					'name' => 'N880E',
					'mid' => 3919
				)
			)
		),
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/lenovo.jpg',
				'alt' => '����',
				'title' => '����',
				'bid' => 17
			),
			'list' => array(
				array(
					'name' => 'A580',
					'mid' => 4310
				),
				array(
					'name' => 'A789',
					'mid' => 4283
				),
//				array(
//					'name' => 'A690',
//					'mid' => 4263
//				),
				array(
					'name' => 'A520',
					'mid' => 4284
				)//,
//				array(
//					'name' => 'P700I',
//					'mid' => 4311
//				)
			)
		),
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/sony.jpg',
				'alt' => '����',
				'title' => '����',
				'bid' => 84
			),
			'list' => array(
				array(
					'name' => 'LT22i',
					'mid' => 4114
				),
				array(
					'name' => 'MT27i',
					'mid' => 4117
				),
				array(
					'name' => 'LT26i',
					'mid' => 4113
				),
				array(
					'name' => 'LT29i',
					'mid' => 4115
				),
				array(
					'name' => 'MT25i',
					'mid' => 4096
				),
				array(
					'name' => 'LT28h',
					'mid' => 4095
				)
			)
		)
		/*,
		array(
			'img' => array(
				'src' => 'http://st.icson.com/static_v1/act/51buy_1105_mobileaccessory/img/xiaomi.jpg',
				'alt' => 'С��',
				'title' => 'С��',
				'bid' => 85
			),
			'list' => array(
				array(
					'name' => 'С��2',
					'mid' => 2970
				),
				array(
					'name' => 'С��1S',
					'mid' => 4229
				),
				array(
					'name' => 'С��1',
					'mid' => 2985
				)
			)
		)*/
	);
	
//	static $hotSaleProducts = array(
//		'49',
//		'15532',
//		'58785',
//		'75910',
//		'58795',
//		'173944'
//	);
	
	static $mobileAccessoryCategory = array(
		'312' => array(
			'name' => '������/��',
			'class' => 'icon icon_baohuke',
			'display_attr' => 0
		),
		'508' => array(
			'name' => '��Ĥ ',
			'class' => 'icon icon_tiemo',
			'display_attr' => 0
		),
		'1288' => array(
			'name' => '�ƶ���Դ',
			'class' => 'icon icon_yidongdianyuan',
			'display_attr' => 1
		),
		'214' => array(
			'name' => '��������',
			'class' => 'icon icon_lanyaerji',
			'display_attr' => 1
		),
		'308' => array(
			'name' => '���',
			'class' => 'icon icon_dianchi',
			'display_attr' => 0
		),
		'309' => array(
			'name' => '�����',
			'class' => 'icon icon_chongdianqi',
			'display_attr' => 0
		),
		'642' => array(
			'name' => '����',
			'class' => 'icon icon_erji',
			'display_attr' => 1
		),
		'496' => array(
			'name' => '������ ',
			'class' => 'icon icon_shujuxian',
			'display_attr' => 1
		),
		'47' => array(
			'name' => '���濨',
			'class' => 'icon icon_chucunka',
			'display_attr' => 1
		),
		'733' => array(
			'name' => '�������',
			'class' => 'icon icon_chezaipeijian',
			'display_attr' => 1
		),
		'476' => array(
			'name' => '�������',
			'class' => 'icon icon_chuangyipeijian',
			'display_attr' => 1
		)/*,
		'191' => array(
			'name' => 'С����',
			'class' => 'icon icon_xiaoyinxiang',
			'display_attr' => 0
		),
		'310' => array(
			'name' => '����',
			'class' => 'icon icon_guashi',
			'display_attr' => 1
		),
		'1278' => array(
			'name' => '��д��',
			'class' => 'icon icon_shouxiebi',
			'display_attr' => 1
		),
		'48' => array(
			'name' => '������ ',
			'class' => 'icon icon_dukaqi',
			'display_attr' => 0
		)*/
	);
	
	static $mobileAccessoryRecommend = array(
		'1288' => '�ƶ���Դ',
		'308' => '���',
		'309' => '�����',
		'312' => '������',
		'508' => '��Ĥ '
	);
	
}