<?php
//��ؽű�url��ip����
//����ip
define('IIP35', '192.168.2.35');
define('IIP37', '192.168.2.37');
define('IIP106', '10.96.78.106');

//����ip
define('OIP63', '101.226.62.63');


//url��ַ��Ӧip
$urlToIps = array(
			'http://www.51buy.com' => 
				array(
					'inner' => array(IIP35, IIP37, IIP106),
					'outer' => array(OIP63)
				),
			'http://tuan.51buy.com' =>
				array(
					'inner' => array(IIP35, IIP37),
					'outer' => array(OIP63)
				),
			'http://act.51buy.com' =>
				array(
					'inner' => array(IIP35, IIP37),
					'outer' => array(OIP63)
				),
			'/usr/local/service/ttc_page_cache/bin/ttcd_test -t  /usr/local/service/ttc_page_cache/conf/table.conf -o get -i 127.0.0.1 -p9065 -k tuan_hottuans_20120509_1_1' => 
				array(
					'inner' => array(IIP35, IIP37),
					'outer' => array(OIP63)
				),
);


//�����Աmobile
$userMobiles = array(
				'rongxu' => '13524253301',
);

//���
$monitorType = array(
				'curl', 'ttctest'
);

//����
$domains = array('www.51buy.com', 'tuan.51buy.com', 'act.51buy.com');