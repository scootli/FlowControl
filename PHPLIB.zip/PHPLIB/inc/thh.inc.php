<?php

global $_SITE_THH_CFG, $_WAREHOUSE_THH_CFG, $_SITE_WAREHOUSE_MAP_CFG, $_DEFAULT_SITE_THH_CFG, $_DEFAULT_WAREHOUSE_THH_CFG, $_STATIC_FILE_PATH;

$_DEFAULT_SITE_THH_CFG = 'S0001';
$_DEFAULT_WAREHOUSE_THH_CFG = 1;
#$_STATIC_FILE_PATH = "/data/release/webapp/sale_51buy_com";
$_STATIC_FILE_PATH = "/data/eos/src/sale_51buy_com";

//��վ��Ϣ
$_SITE_THH_CFG = array(
	'1' => array(
		'name'			=> 'shanghaiqu',
		'label'			=> '�Ϻ���',
		'site_id'		=> '1'
	),
	'1001' => array(
		'name'			=> 'guangdongqu',
		'label'			=> '�㶫��',
		'site_id'		=> '1001'
	),
	'2001' => array(
		'name'			=> 'beijingqu',
		'label'			=> '������',
		'site_id'		=> '2001'
	),
	'3001' => array(
		'name'			=> 'wuhan',
		'label'			=> '�人',
		'site_id'		=> '3001'
	),
	'4001' => array(
		'name'			=> 'chongqing',
		'label'			=> '����',
		'site_id'		=> '4001'
	),
	'5001' => array(
		'name'			=> 'xian',
		'label'			=> '����',
		'site_id'		=> '5001'
	)
);

//�ֿ���Ϣ
$_WAREHOUSE_THH_CFG = array(
	'1' => array(
		'name'			=> 'shanghai',
		'label'			=> '�Ϻ�',
		"ws_id"			=> 1
	),
	'1001' => array(
		'name'			=> 'huanan',
		'label'			=> '�㶫',
		"ws_id"			=> 1001
	),
	'2001' => array(
		'name'			=> 'beijing',
		'label'			=> '����',
		"ws_id"			=> 2001
	),
	'3001' => array(
		'name'			=> 'wuhan',
		'label'			=> '����',
		'ws_id'			=> 3001
	),
	'4001' => array(
		'name'			=> 'chongqing',
		'label'			=> '����',
		'ws_id'			=> 4001
	),
	'5001' => array(
		'name'			=> 'xian',
		'label'			=> '����',
		'ws_id'			=> 5001
	),
);

$_SITE_WAREHOUSE_MAP_CFG = array(
		'1' => array('1'),
		'1001' => array('1001'),
		'2001' => array('2001'),
		'3001' => array('3001'),
		'4001' => array('4001'),
		'5001' => array('5001')
);

//End of script
