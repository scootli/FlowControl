<?php



$_category = array (
  0 => 
  array (
    'id' => 2,
    'name' => '����',
    'gid' => 2000,
  ),
  1 => 
  array (
    'id' => 3,
    'name' => '�͸�˭',
    'gid' => 3000,
  ),
);


$_sCategory = array (
  2 => 
  array (
    0 => 
    array (
      'id' => 100,
      'name' => '�����',
      'gid' => 2,
    ),
    1 => 
    array (
      'id' => 26,
      'name' => '���',
      'gid' => 2002,
    ),
    2 => 
    array (
      'id' => 28,
      'name' => '����',
      'gid' => 2004,
    ),
    3 => 
    array (
      'id' => 86,
      'name' => '����',
      'gid' => 2010,
    ),
    4 => 
    array (
      'id' => 29,
      'name' => 'Լ��/������',
      'gid' => 2005,
    ),
  ),
  3 => 
  array (
    0 => 
    array (
      'id' => 36,
      'name' => '�͸�ĸ/����',
      'gid' => 3003,
    ),
    1 => 
    array (
      'id' => 39,
      'name' => '������/ͬ��/ͬѧ',
      'gid' => 3006,
    ),
    2 => 
    array (
      'id' => 42,
      'name' => '���쵼',
      'gid' => 3009,
    ),
    3 => 
    array (
      'id' => 43,
      'name' => '�Ϳͻ�',
      'gid' => 3010,
    ),
    4 => 
    array (
      'id' => 35,
      'name' => '��Ů��/����',
      'gid' => 3002,
    ),
    5 => 
    array (
      'id' => 34,
      'name' => '������/�Ϲ�',
      'gid' => 3001,
    ),
    6 => 
    array (
      'id' => 37,
      'name' => '�ͺ���',
      'gid' => 3004,
    ),
    7 => 
    array (
      'id' => 38,
      'name' => '�ͱ���',
      'gid' => 3005,
    ),
  ),
);


$_hotCategory = array (
  0 => 100,
  1 => 102,
);?>