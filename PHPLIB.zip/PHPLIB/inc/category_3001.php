<?php $_CATEGORY_CONFIG = array (
  0 => 
  array (
    'text' => '�ֻ�/���',
    'url' => 'http://www.51buy.com/mobile_accessories.html',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '����',
        'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e12194-.html',
      ),
      1 => 
      array (
        'text' => 'MOTO',
        'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e12193-.html',
      ),
      2 => 
      array (
        'text' => 'HTC',
        'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e20964-.html',
      ),
      3 => 
      array (
        'text' => '��Լ����',
        'url' => 'http://s.51buy.com/--------.html?q=%BA%CF%D4%BC%B9%BA%BB%FA',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '�ֻ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ���ֻ�',
            'url' => 'http://list.51buy.com/311--------.html',
          ),
          1 => 
          array (
            'text' => 'ƻ��',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e14574-.html',
          ),
          2 => 
          array (
            'text' => 'HTC',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e20964-.html',
          ),
          3 => 
          array (
            'text' => 'ŵ����',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e12192-.html',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e12194-.html',
          ),
          5 => 
          array (
            'text' => 'Ħ������',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e12193-.html',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e13780-.html',
          ),
          7 => 
          array (
            'text' => 'LG',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e12609-.html',
          ),
          8 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e12196-.html',
          ),
          9 => 
          array (
            'text' => '��Ϊ',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e20894-.html',
          ),
          10 => 
          array (
            'text' => '��ݮ',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3590e19845-.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '&nbsp;',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'Android',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3593e15442o28627o29298-.html',
          ),
          1 => 
          array (
            'text' => 'iOS',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3593e19828-.html',
          ),
          2 => 
          array (
            'text' => '��ݮ',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3593e19846-.html',
          ),
          3 => 
          array (
            'text' => 'Symbian',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3593e19758o12210o12687o37610o37867-.html',
          ),
          4 => 
          array (
            'text' => 'Windows Phone',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3593e40490-.html',
          ),
          5 => 
          array (
            'text' => '�������ֻ�',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3593e12214-.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '&nbsp;',
        'list' => 
        array (
          0 => 
          array (
            'text' => '˫��',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3602e12404-.html',
          ),
          1 => 
          array (
            'text' => '˫ģ',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3602e16740-.html',
          ),
          2 => 
          array (
            'text' => '����Ļ',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-8394e38058o38059o-.html',
          ),
          3 => 
          array (
            'text' => '���˻�',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-8417e38148-.html',
          ),
          4 => 
          array (
            'text' => 'ѧ����',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-8417e39195-.html',
          ),
          5 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-8417e38152-.html',
          ),
          6 => 
          array (
            'text' => '��Ϸ��',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-8417e38151-.html',
          ),
          7 => 
          array (
            'text' => '1000-2000',
            'url' => 'http://list.51buy.com/311-1000t2000-6-11-24-0-1--.html',
          ),
          8 => 
          array (
            'text' => '2000-3000',
            'url' => 'http://list.51buy.com/311-2000t3000-6-11-24-0-1--.html',
          ),
          9 => 
          array (
            'text' => '3000����',
            'url' => 'http://list.51buy.com/311-3000t-6-11-24-0-1--.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '��Ӫ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => '3G������',
            'url' => 'http://list.51buy.com/379--------.html',
          ),
          1 => 
          array (
            'text' => '��Լ����',
            'url' => 'http://s.51buy.com/--------.html?q=%BA%CF%D4%BC%B9%BA%BB%FA',
          ),
          2 => 
          array (
            'text' => 'ѡ������',
            'url' => 'http://buy.51buy.com/stepone.html',
          ),
          3 => 
          array (
            'text' => '��ֵ',
            'url' => 'http://buy.51buy.com/virtualpay.html',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '�ֻ����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���',
            'url' => 'http://list.51buy.com/308--------.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/642--------.html',
          ),
          2 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/214--------.html',
          ),
          3 => 
          array (
            'text' => '��Ĥ',
            'url' => 'http://list.51buy.com/508--------.html',
          ),
          4 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/309--------.html',
          ),
          5 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/496--------.html',
          ),
          6 => 
          array (
            'text' => '�ƶ���Դ',
            'url' => 'http://list.51buy.com/1288--------.html',
          ),
          7 => 
          array (
            'text' => '��ظ���',
            'url' => 'http://list.51buy.com/1379--------.html',
          ),
          8 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/733--------.html',
          ),
          9 => 
          array (
            'text' => '�ֻ���/���',
            'url' => 'http://list.51buy.com/312--------.html',
          ),
          10 => 
          array (
            'text' => '��д��',
            'url' => 'http://list.51buy.com/1278--------.html',
          ),
          11 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/310--------.html',
          ),
          12 => 
          array (
            'text' => 'iPhone���',
            'url' => 'http://list.51buy.com/1533--------.html',
          ),
          13 => 
          array (
            'text' => 'ƻ������',
            'url' => 'http://list.51buy.com/67-0-6-11-20-0-1-4113e35375-.html',
          ),
          14 => 
          array (
            'text' => 'ƻ��ԭװ���',
            'url' => 'http://list.51buy.com/1531--------.html',
          ),
          15 => 
          array (
            'text' => 'ƻ��ͨ�����',
            'url' => 'http://list.51buy.com/1357--------.html',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '�Խ���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/741-0-6-11-24-0-1-5527e22575-.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/741-0-6-11-24-0-1-5527e22573-.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '�����ֻ�phone��168Сʱ',
            'url' => 'http://act.51buy.com/promo-4056.html',
          ),
          1 => 
          array (
            'text' => 'ŵ����lumia�������͵�Դ',
            'url' => 'http://item.51buy.com/item-310195.html',
          ),
          2 => 
          array (
            'text' => 'SONY����Ԥ����JBL����',
            'url' => 'http://item.51buy.com/item-310523.html',
          ),
          3 => 
          array (
            'text' => '4.2������ֻ�����2000',
            'url' => 'http://item.51buy.com/item-1-223057.html',
          ),
          4 => 
          array (
            'text' => 'ǧ�����������ֻ�',
            'url' => 'http://list.51buy.com/311-0-6-11-24-0-1-3629e19759o38761-.html',
          ),
          5 => 
          array (
            'text' => '�������ƶ���Դ�Ƽ�',
            'url' => 'http://list.51buy.com/1288-0-6-11-24-0-1-5820e24131o24669-.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  1 => 
  array (
    'text' => 'ƻ��/Ӱ��/����',
    'url' => 'http://www.51buy.com/photography_digital.html',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '����',
        'url' => 'http://list.51buy.com/339--6-11-24-0-1--.html',
      ),
      1 => 
      array (
        'text' => '��ͷ',
        'url' => 'http://list.51buy.com/204--6-11-24-0-1--.html?YTAG=3.1711007001',
      ),
      2 => 
      array (
        'text' => 'iPhone��',
        'url' => 'http://list.51buy.com/1533-0-6-11-24-0-1-6888e30904-.html',
      ),
      3 => 
      array (
        'text' => 'TF��',
        'url' => 'http://list.51buy.com/47--------.html',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => 'ƻ��ר��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'iPhone',
            'url' => 'http://list.51buy.com/311-0-5-11-20-0-1-3590e14574-.html',
          ),
          1 => 
          array (
            'text' => 'iPad',
            'url' => 'http://list.51buy.com/998-0-5-11-20-0-1-5191e20841-.html',
          ),
          2 => 
          array (
            'text' => 'Mac',
            'url' => 'http://list.51buy.com/234-0-6-10-20-0-1-1360e3703-.html',
          ),
          3 => 
          array (
            'text' => 'iPod',
            'url' => 'http://list.51buy.com/49-0-5-11-20-0-1-948e14010-.html',
          ),
          4 => 
          array (
            'text' => 'ԭװ���',
            'url' => 'http://list.51buy.com/1531--------.html',
          ),
          5 => 
          array (
            'text' => 'iPad���',
            'url' => 'http://list.51buy.com/1532--------.html',
          ),
          6 => 
          array (
            'text' => 'iPhone���',
            'url' => 'http://list.51buy.com/1533--------.html',
          ),
          7 => 
          array (
            'text' => 'iPod���',
            'url' => 'http://list.51buy.com/1534--------.html',
          ),
          8 => 
          array (
            'text' => 'Mac���',
            'url' => 'http://list.51buy.com/1535--------.html',
          ),
          9 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/191-0-6-11-20-0-1-4112e15893-.html',
          ),
          10 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/67-0-6-11-20-0-1-4113e35375-.html',
          ),
          11 => 
          array (
            'text' => 'ͨ�����',
            'url' => 'http://list.51buy.com/1357--------.html',
          ),
          12 => 
          array (
            'text' => 'iPhone��',
            'url' => 'http://list.51buy.com/1533-0-6-11-24-0-1-6888e30904-.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '�������',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://list.51buy.com/129--------.html',
          ),
          1 => 
          array (
            'text' => '��Ƭ��',
            'url' => 'http://list.51buy.com/129-0-6-11-24-0-1-8731e39696-.html',
          ),
          2 => 
          array (
            'text' => '�г���',
            'url' => 'http://list.51buy.com/129-0-6-11-24-0-1-8731e39698-.html',
          ),
          3 => 
          array (
            'text' => 'רҵ��Я',
            'url' => 'http://list.51buy.com/129-0-6-11-24-0-1-8731e39697-.html',
          ),
          4 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/129-0-6-11-24-0-1-8731e39743-.html',
          ),
          5 => 
          array (
            'text' => 'һ�γ���',
            'url' => 'http://list.51buy.com/1701--6-11-24-0-1--.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '΢��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://list.51buy.com/1123--------.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/1123-0-6-11-24-0-1-8198e36605-.html',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/1123-0-6-11-24-0-1-8198e36608-.html',
          ),
          3 => 
          array (
            'text' => '�῵',
            'url' => 'http://list.51buy.com/1123-0-6-11-24-0-1-8198e36601-.html',
          ),
          4 => 
          array (
            'text' => '��ʿ',
            'url' => 'http://list.51buy.com/1123-0-6-11-24-0-1-8198e36612-.html',
          ),
          5 => 
          array (
            'text' => '���ְ�˹',
            'url' => 'http://list.51buy.com/1123-0-6-11-24-0-1-8198e36610-.html',
          ),
          6 => 
          array (
            'text' => '΢����ͷ',
            'url' => 'http://list.51buy.com/204-0-6-11-24-0-1-8838e40449-.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '����',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://list.51buy.com/339--------.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/339-0-6-11-24-0-1-1474e4645-.html',
          ),
          2 => 
          array (
            'text' => '�῵',
            'url' => 'http://list.51buy.com/339-0-6-11-24-0-1-1474e4589-.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/339-0-6-11-24-0-1-1474e6782-.html',
          ),
          4 => 
          array (
            'text' => '��ʿ',
            'url' => 'http://list.51buy.com/339-0-6-11-24-0-1-1474e7546-.html',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/339-0-6-11-24-0-1-1474e38623-.html',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '��ͷ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������ͷ',
            'url' => 'http://list.51buy.com/204-0-6-11-24-0-1-8838e40448-.html',
          ),
          1 => 
          array (
            'text' => '΢����ͷ',
            'url' => 'http://list.51buy.com/204-0-6-11-24-0-1-8838e40449-.html',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://list.51buy.com/130--------.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/130-0-6-11-24-0-1-1727e5652-.html',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/130-0-6-11-24-0-1-1727e5653-.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/130-0-6-11-24-0-1-1727e5651-.html',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/130-0-6-11-24-0-1-1727e23991-.html',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/130-0-6-11-24-0-1-1727e26273-.html',
          ),
        ),
      ),
      6 => 
      array (
        'text' => '��Ӱ���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/177--------.html',
          ),
          1 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/175--------.html',
          ),
          2 => 
          array (
            'text' => '��Ĥ',
            'url' => 'http://list.51buy.com/179--------.html',
          ),
          3 => 
          array (
            'text' => '�˾�',
            'url' => 'http://list.51buy.com/279--------.html',
          ),
          4 => 
          array (
            'text' => '���ż�',
            'url' => 'http://list.51buy.com/178--------.html',
          ),
          5 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/1122--------.html',
          ),
          6 => 
          array (
            'text' => '�ڹ���',
            'url' => 'http://list.51buy.com/176-0-6-11-24-0-1-4055e18457-.html',
          ),
          7 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/176-0-6-11-24-0-1-4055e15305-.html',
          ),
          8 => 
          array (
            'text' => 'ң����',
            'url' => 'http://list.51buy.com/176-0-6-11-24-0-1-4055e15306-.html',
          ),
          9 => 
          array (
            'text' => 'רҵ���',
            'url' => 'http://list.51buy.com/176--------.html',
          ),
          10 => 
          array (
            'text' => '�����Ʒ',
            'url' => 'http://list.51buy.com/323--------.html',
          ),
          11 => 
          array (
            'text' => '��Զ��',
            'url' => 'http://list.51buy.com/753--------.html',
          ),
        ),
      ),
      7 => 
      array (
        'text' => '����洢',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�洢��',
            'url' => 'http://list.51buy.com/47--------.html',
          ),
          1 => 
          array (
            'text' => 'U��',
            'url' => 'http://list.51buy.com/46--------.html',
          ),
          2 => 
          array (
            'text' => '�ƶ�Ӳ��',
            'url' => 'http://list.51buy.com/128--------.html',
          ),
          3 => 
          array (
            'text' => '�ƶ���Դ',
            'url' => 'http://list.51buy.com/1288--------.html',
          ),
          4 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/48--------.html',
          ),
          5 => 
          array (
            'text' => '�ɵ��',
            'url' => 'http://list.51buy.com/230--------.html',
          ),
          6 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/69--------.html',
          ),
        ),
      ),
      8 => 
      array (
        'text' => 'ƽ�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://list.51buy.com/998--------.html',
          ),
          1 => 
          array (
            'text' => 'iPad',
            'url' => 'http://list.51buy.com/998-0-6-11-24-0-1-5191e20841-.html',
          ),
          2 => 
          array (
            'text' => 'iPad���',
            'url' => 'http://list.51buy.com/1532--------.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/998-0-6-11-24-0-1-5191e26223-.html',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/998-0-1-11-24-0-1-5191e29553-.html',
          ),
          5 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/998-0-6-11-24-0-1-5191e20843-.html',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/998-0-1-11-24-0-1-5191e20842-.html',
          ),
        ),
      ),
      9 => 
      array (
        'text' => '����Ӱ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'MP3��MP4',
            'url' => 'http://list.51buy.com/49--------.html',
          ),
          1 => 
          array (
            'text' => 'MP3����',
            'url' => 'http://list.51buy.com/194--------.html',
          ),
          2 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/313--------.html',
          ),
          3 => 
          array (
            'text' => '����/��¼��',
            'url' => 'http://list.51buy.com/747--------.html',
          ),
          4 => 
          array (
            'text' => '���岥����',
            'url' => 'http://list.51buy.com/347--------.html',
          ),
          5 => 
          array (
            'text' => '�ֳֵ���',
            'url' => 'http://list.51buy.com/1128--------.html',
          ),
          6 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/499--------.html',
          ),
          7 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/67--------.html',
          ),
        ),
      ),
      10 => 
      array (
        'text' => 'ѧϰ�Ķ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ֽ��',
            'url' => 'http://list.51buy.com/51--------.html',
          ),
          1 => 
          array (
            'text' => '¼����',
            'url' => 'http://list.51buy.com/373--------.html',
          ),
          2 => 
          array (
            'text' => '���Ӵʵ�',
            'url' => 'http://list.51buy.com/851--------.html',
          ),
          3 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/850--------.html',
          ),
        ),
      ),
      11 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'GPS����',
            'url' => 'http://list.51buy.com/710--------.html',
          ),
          1 => 
          array (
            'text' => '�г���¼��',
            'url' => 'http://list.51buy.com/1762--6-11-24-0-1--.html',
          ),
          2 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/1453--------.html',
          ),
          3 => 
          array (
            'text' => '����MP3',
            'url' => 'http://list.51buy.com/709--------.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '[����]����5D MarkIII ͬ���׷�',
            'url' => 'http://s.51buy.com/--------.html?q=EOS+5D+Mark+III',
          ),
          1 => 
          array (
            'text' => '�῵D90 ���ò�˥������',
            'url' => 'http://item.51buy.com/item-1-17324.html',
          ),
          2 => 
          array (
            'text' => '�������ȫ���������',
            'url' => 'http://list.51buy.com/129-0-6-11-24-0-1-1e2-.html',
          ),
          3 => 
          array (
            'text' => '[�߽�]���ܺ�Ȧ��������',
            'url' => 'http://s.51buy.com/204--6-11-24-0-1--.html?q=f1.2',
          ),
          4 => 
          array (
            'text' => '����������iPad���¿�',
            'url' => 'http://act.51buy.com/promo-4046.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  2 => 
  array (
    'text' => '��������',
    'url' => 'http://www.51buy.com/computer_accessories.html',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '�ʼǱ�',
        'url' => 'http://list.51buy.com/234--------.html',
      ),
      1 => 
      array (
        'text' => '̨ʽ��',
        'url' => 'http://list.51buy.com/597--------.html',
      ),
      2 => 
      array (
        'text' => 'ƽ�����',
        'url' => 'http://list.51buy.com/998--------.html',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '�ʼǱ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://list.51buy.com/234--------.html',
          ),
          1 => 
          array (
            'text' => 'ThinkPad',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-1360e3694-.html',
          ),
          2 => 
          array (
            'text' => '�곞',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-1360e3687-.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-1360e3692-.html',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-1360e3695-.html',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-1360e3693-.html',
          ),
          6 => 
          array (
            'text' => '��˶',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-1360e3686-.html',
          ),
          7 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-1360e3688-.html',
          ),
          8 => 
          array (
            'text' => 'ƻ��',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-1360e3703-.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '&nbsp;',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������Ϸ',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-2034e6449o12866-.html',
          ),
          1 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/562--6-11-24-0-1--.html',
          ),
          2 => 
          array (
            'text' => '��Я��',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-5372e21783o21784o21785-.html',
          ),
          3 => 
          array (
            'text' => 'i3',
            'url' => 'http://s.51buy.com/234--6-11-24-0-1--.html?q=i3',
          ),
          4 => 
          array (
            'text' => 'i5',
            'url' => 'http://s.51buy.com/234--6-11-24-0-1--.html?q=i5',
          ),
          5 => 
          array (
            'text' => 'i7',
            'url' => 'http://s.51buy.com/234--6-11-24-0-1--.html?q=i7',
          ),
          6 => 
          array (
            'text' => '3000Ԫ����',
            'url' => 'http://list.51buy.com/234-t3000-6-11-24-0-1--.html',
          ),
          7 => 
          array (
            'text' => '3000-4000',
            'url' => 'http://list.51buy.com/234-3000t4000-6-11-24-0-1--.html',
          ),
          8 => 
          array (
            'text' => '4000-6000',
            'url' => 'http://list.51buy.com/234-4000t6000-6-11-24-0-1--.html',
          ),
          9 => 
          array (
            'text' => '6000����',
            'url' => 'http://list.51buy.com/234-6000t-6-11-24-0-1--.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '������',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://list.51buy.com/72--6-11-24-0-1--.html',
          ),
          1 => 
          array (
            'text' => 'Acer',
            'url' => 'http://list.51buy.com/72-0-6-11-24-0-1-1177e3023-.html',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/72-0-6-11-24-0-1-1177e4717-.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/72-0-6-11-24-0-1-1177e3025-.html',
          ),
          4 => 
          array (
            'text' => '��֥',
            'url' => 'http://list.51buy.com/72-0-6-11-24-0-1-1177e3026-.html',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/72-0-6-11-24-0-1-1177e3930-.html',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/72-0-6-11-24-0-1-1177e40202-.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => 'ƽ�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ȫ��',
            'url' => 'http://list.51buy.com/998--------.html',
          ),
          1 => 
          array (
            'text' => 'iPad',
            'url' => 'http://list.51buy.com/998-0-6-11-24-0-1-5191e20841-.html',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/998-0-6-11-24-0-1-5191e26223-.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/998-0-1-11-24-0-1-5191e29553-.html',
          ),
          4 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/998-0-6-11-24-0-1-5191e20843-.html',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/998-0-1-11-24-0-1-5191e20842-.html',
          ),
          6 => 
          array (
            'text' => '̨��',
            'url' => 'http://list.51buy.com/998-0-1-11-24-0-1-5191e26688-.html',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '&nbsp;',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ƽ���',
            'url' => 'http://list.51buy.com/194-0-6-11-24-0-1-1116e12069-.html',
          ),
          1 => 
          array (
            'text' => '�ƶ���Դ',
            'url' => 'http://list.51buy.com/1288--------.html',
          ),
          2 => 
          array (
            'text' => '�����Ʒ',
            'url' => 'http://list.51buy.com/615--6-11-24-0-1--.html',
          ),
          3 => 
          array (
            'text' => 'iPad���',
            'url' => 'http://list.51buy.com/1532--------.html',
          ),
          4 => 
          array (
            'text' => 'iPad������',
            'url' => 'http://list.51buy.com/1532-0-6-11-24-0-1-6885e30864-.html',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '̨ʽ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'Ʒ��̨ʽ��',
            'url' => 'http://list.51buy.com/597--6-11-24-0-1--.html',
          ),
          1 => 
          array (
            'text' => 'һ���',
            'url' => 'http://list.51buy.com/599--6-11-24-0-1--.html',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/597-0-6-11-24-0-1-5266e21091-.html',
          ),
          3 => 
          array (
            'text' => 'Mac',
            'url' => 'http://list.51buy.com/597-0-6-11-24-0-1-2972e23198-.html',
          ),
          4 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/597-0-6-11-24-0-1-2974e9392-.html',
          ),
          5 => 
          array (
            'text' => '��Ϸ',
            'url' => 'http://list.51buy.com/597-0-6-11-24-0-1-2988e9416-.html',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/597-0-6-11-24-0-1-2974e9747-.html',
          ),
          7 => 
          array (
            'text' => '3000Ԫ����',
            'url' => 'http://list.51buy.com/597-t3000-6-11-24-0-1--.html',
          ),
          8 => 
          array (
            'text' => '3000-5000',
            'url' => 'http://list.51buy.com/597-3000t5000-6-11-24-0-1--.html',
          ),
          9 => 
          array (
            'text' => '5000����',
            'url' => 'http://list.51buy.com/597-5000t-6-11-24-0-1--.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '�뺷��СY ǿ�����ֱ�',
            'url' => 'http://s.51buy.com/234--6-11-24-0-1--.html?q=y470',
          ),
          1 => 
          array (
            'text' => '13������ ����Ч',
            'url' => 'http://list.51buy.com/234-0-6-11-24-0-1-5372e21785-.html',
          ),
          2 => 
          array (
            'text' => 'Macbook Air ���� ���ͼ�',
            'url' => 'http://s.51buy.com/234--6-11-24-0-1--.html?q=macbook+air',
          ),
          3 => 
          array (
            'text' => '[�׷�]���� T20˫��ƽ��',
            'url' => 'http://item.51buy.com/item-310746.html',
          ),
          4 => 
          array (
            'text' => 'iPad2 ��ҵ�ͼ� ���޽���',
            'url' => 'http://item.51buy.com/item-171043.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  3 => 
  array (
    'text' => 'Ӳ��/����',
    'url' => 'http://www.51buy.com/hardware_peripherals.html',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => 'Ӳ��',
        'url' => 'http://list.51buy.com/138--------.html',
      ),
      1 => 
      array (
        'text' => '�ڴ�',
        'url' => 'http://list.51buy.com/146--6-11-24-0-1--.html',
      ),
      2 => 
      array (
        'text' => '����',
        'url' => 'http://list.51buy.com/67--------.html',
      ),
      3 => 
      array (
        'text' => '·����',
        'url' => 'http://list.51buy.com/270--------.html',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => 'װ�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'CPU',
            'url' => 'http://list.51buy.com/148--------.html',
          ),
          1 => 
          array (
            'text' => 'Ӳ��',
            'url' => 'http://list.51buy.com/138--------.html',
          ),
          2 => 
          array (
            'text' => '�ڴ�',
            'url' => 'http://list.51buy.com/146--------.html',
          ),
          3 => 
          array (
            'text' => '��ʾ��',
            'url' => 'http://list.51buy.com/111--------.html',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/152--------.html',
          ),
          5 => 
          array (
            'text' => '�Կ�',
            'url' => 'http://list.51buy.com/166--------.html',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/149--------.html',
          ),
          7 => 
          array (
            'text' => '��Դ',
            'url' => 'http://list.51buy.com/132--------.html',
          ),
          8 => 
          array (
            'text' => 'ɢ����',
            'url' => 'http://list.51buy.com/159--------.html',
          ),
          9 => 
          array (
            'text' => '��¼��/����',
            'url' => 'http://list.51buy.com/100--------.html',
          ),
          10 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/212--------.html',
          ),
          11 => 
          array (
            'text' => '��չ��',
            'url' => 'http://list.51buy.com/337--------.html',
          ),
          12 => 
          array (
            'text' => '���������',
            'url' => 'http://list.51buy.com/180--------.html',
          ),
          13 => 
          array (
            'text' => 'DIYС����',
            'url' => 'http://list.51buy.com/162--------.html',
          ),
          14 => 
          array (
            'text' => 'װ��/�����װ',
            'url' => 'http://list.51buy.com/806--------.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����ͷ',
            'url' => 'http://list.51buy.com/53--------.html',
          ),
          1 => 
          array (
            'text' => 'USB��չ',
            'url' => 'http://list.51buy.com/245--------.html',
          ),
          2 => 
          array (
            'text' => '��Ϸ����',
            'url' => 'http://list.51buy.com/93--------.html',
          ),
          3 => 
          array (
            'text' => '���Ӻ�',
            'url' => 'http://list.51buy.com/189--------.html',
          ),
          4 => 
          array (
            'text' => '���ú�',
            'url' => 'http://list.51buy.com/133--------.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/56--------.html',
          ),
          1 => 
          array (
            'text' => '���',
            'url' => 'http://list.51buy.com/55--------.html',
          ),
          2 => 
          array (
            'text' => '������װ',
            'url' => 'http://list.51buy.com/56-0-6-11-24-0-1-6243e27052o27051-.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/658--6-11-24-0-1--.html',
          ),
          4 => 
          array (
            'text' => '��д��/��ͼ��',
            'url' => 'http://list.51buy.com/217--6-11-24-0-1--.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '�����豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '·����',
            'url' => 'http://list.51buy.com/270--------.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/92--------.html',
          ),
          2 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/92-0-6-11-24-0-1-3472e11378-.html',
          ),
          3 => 
          array (
            'text' => '3G��������',
            'url' => 'http://list.51buy.com/379--------.html',
          ),
          4 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/88--------.html',
          ),
          5 => 
          array (
            'text' => '����洢',
            'url' => 'http://list.51buy.com/223--------.html',
          ),
          6 => 
          array (
            'text' => '���߹���',
            'url' => 'http://list.51buy.com/406--------.html',
          ),
          7 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/258--------.html',
          ),
          8 => 
          array (
            'text' => '����ǽ',
            'url' => 'http://list.51buy.com/286--------.html',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '��Ƶ�豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/191--------.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/67--------.html',
          ),
          2 => 
          array (
            'text' => '��˷�',
            'url' => 'http://list.51buy.com/287--------.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/212--------.html',
          ),
          4 => 
          array (
            'text' => '��Ƶ����',
            'url' => 'http://list.51buy.com/382--------.html',
          ),
          5 => 
          array (
            'text' => '¼����',
            'url' => 'http://list.51buy.com/373-0-6-11-24-0-1--.html',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '�칫�豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�����ӡ��',
            'url' => 'http://list.51buy.com/608--------.html',
          ),
          1 => 
          array (
            'text' => '��ī��ӡ��',
            'url' => 'http://list.51buy.com/824--------.html',
          ),
          2 => 
          array (
            'text' => '��ʽ��ӡ��',
            'url' => 'http://list.51buy.com/825--------.html',
          ),
          3 => 
          array (
            'text' => '��Ƭ��ӡ��',
            'url' => 'http://list.51buy.com/1104--------.html',
          ),
          4 => 
          array (
            'text' => '��ǩ��ӡ��',
            'url' => 'http://list.51buy.com/831--------.html',
          ),
          5 => 
          array (
            'text' => '��īһ��',
            'url' => 'http://list.51buy.com/609--------.html',
          ),
          6 => 
          array (
            'text' => '����һ��',
            'url' => 'http://list.51buy.com/826--------.html',
          ),
          7 => 
          array (
            'text' => '��ӡ��',
            'url' => 'http://list.51buy.com/814--------.html',
          ),
          8 => 
          array (
            'text' => 'ɨ����',
            'url' => 'http://list.51buy.com/613--------.html',
          ),
          9 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/611--------.html',
          ),
          10 => 
          array (
            'text' => 'ͶӰ��',
            'url' => 'http://list.51buy.com/665--------.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '[����]Ӣ�ض� ���i7�����',
            'url' => 'http://item.51buy.com/item-275809.html',
          ),
          1 => 
          array (
            'text' => '��Ѹ��Ϸר��',
            'url' => 'http://act.51buy.com/promo-3371.html',
          ),
          2 => 
          array (
            'text' => '[����]����19Ӣ�������ʾ��',
            'url' => 'http://item.51buy.com/item-299946.html',
          ),
          3 => 
          array (
            'text' => '�����ڴ� �׼۴���',
            'url' => 'http://list.51buy.com/146-0-6-11-24-0-1-3385e27308-.html',
          ),
          4 => 
          array (
            'text' => '2TBӲ�� �ͼۻع�',
            'url' => 'http://list.51buy.com/138-0-6-11-24-0-1-47e9799-.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  4 => 
  array (
    'text' => '���Ը���',
    'url' => 'http://www.51buy.com/accessories.html',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => 'U��',
        'url' => 'http://list.51buy.com/46--------.html',
      ),
      1 => 
      array (
        'text' => '�ƶ�Ӳ��',
        'url' => 'http://list.51buy.com/128--------.html',
      ),
      2 => 
      array (
        'text' => '���԰�',
        'url' => 'http://list.51buy.com/398--------.html',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���԰�',
            'url' => 'http://list.51buy.com/398--------.html',
          ),
          1 => 
          array (
            'text' => '��Դ������',
            'url' => 'http://list.51buy.com/288--------.html',
          ),
          2 => 
          array (
            'text' => '�ʼǱ�ɢ�ȵ���',
            'url' => 'http://list.51buy.com/159-0-6-11-20-0-1-3435e16210-.html',
          ),
          3 => 
          array (
            'text' => '���',
            'url' => 'http://list.51buy.com/558--------.html',
          ),
          4 => 
          array (
            'text' => '��Ĥ',
            'url' => 'http://list.51buy.com/545--------.html',
          ),
          5 => 
          array (
            'text' => 'ԭװ���',
            'url' => 'http://list.51buy.com/274--------.html',
          ),
          6 => 
          array (
            'text' => '�����Ʒ',
            'url' => 'http://list.51buy.com/615--------.html',
          ),
          7 => 
          array (
            'text' => '��ɫ���',
            'url' => 'http://list.51buy.com/1080--------.html',
          ),
          8 => 
          array (
            'text' => 'USB��չ',
            'url' => 'http://list.51buy.com/245--------.html',
          ),
          9 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/1267--------.html',
          ),
          10 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/135--6-11-24-0-1--.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '����洢',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�洢��',
            'url' => 'http://list.51buy.com/47--------.html',
          ),
          1 => 
          array (
            'text' => 'U��',
            'url' => 'http://list.51buy.com/46--------.html',
          ),
          2 => 
          array (
            'text' => '�ƶ�Ӳ��',
            'url' => 'http://list.51buy.com/128--------.html',
          ),
          3 => 
          array (
            'text' => '�ƶ�Ӳ�̰�',
            'url' => 'http://list.51buy.com/407--------.html',
          ),
          4 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/48--------.html',
          ),
          5 => 
          array (
            'text' => '��¼��Ƭ',
            'url' => 'http://list.51buy.com/606--------.html',
          ),
          6 => 
          array (
            'text' => '��Ƭ����',
            'url' => 'http://list.51buy.com/607--------.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ϵͳ����',
            'url' => 'http://list.51buy.com/297--------.html',
          ),
          1 => 
          array (
            'text' => '�칫����',
            'url' => 'http://list.51buy.com/299--------.html',
          ),
          2 => 
          array (
            'text' => '��Ϸ����',
            'url' => 'http://list.51buy.com/533--------.html',
          ),
          3 => 
          array (
            'text' => 'ɱ������',
            'url' => 'http://list.51buy.com/303--------.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '�Ĳ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����/�绰��',
            'url' => 'http://list.51buy.com/1262--------.html',
          ),
          1 => 
          array (
            'text' => 'Ӱ���߲�',
            'url' => 'http://list.51buy.com/1263--6-11-24-0-1--.html',
          ),
          2 => 
          array (
            'text' => '�����߲�',
            'url' => 'http://list.51buy.com/1265--6-11-24-0-1--.html',
          ),
          3 => 
          array (
            'text' => '��¼��Ƭ',
            'url' => 'http://list.51buy.com/606--6-11-24-0-1--.html',
          ),
          4 => 
          array (
            'text' => '��Ƭ����',
            'url' => 'http://list.51buy.com/607--6-11-24-0-1--.html',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/135--6-11-24-0-1--.html',
          ),
          6 => 
          array (
            'text' => 'ī��',
            'url' => 'http://list.51buy.com/590--6-11-24-0-1--.html',
          ),
          7 => 
          array (
            'text' => '���ĺ�ī��',
            'url' => 'http://list.51buy.com/591--6-11-24-0-1--.html',
          ),
          8 => 
          array (
            'text' => 'ɫ��',
            'url' => 'http://list.51buy.com/593--6-11-24-0-1--.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => 'USB3.0 ������U���Ƽ�',
            'url' => 'http://list.51buy.com/46-0-6-11-24-0-1-5740e37838-.html',
          ),
          1 => 
          array (
            'text' => '����16G U������',
            'url' => 'http://list.51buy.com/46-0-1-11-24-0-1-135e324-.html',
          ),
          2 => 
          array (
            'text' => '�ͷ����ƶ�Ӳ�� �Լ۱�NO1',
            'url' => 'http://list.51buy.com/128-0-6-11-24-0-1-84e6518-.html',
          ),
          3 => 
          array (
            'text' => 'Ů������԰��Ƽ�',
            'url' => 'http://list.51buy.com/398-0-6-11-24-0-1-4176e16258-.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  5 => 
  array (
    'text' => '�������',
    'url' => 'http://www.51buy.com/household_electric.html',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '��������',
        'url' => 'http://list.51buy.com/466--------.html',
      ),
      1 => 
      array (
        'text' => '������',
        'url' => 'http://list.51buy.com/463--------.html',
      ),
      2 => 
      array (
        'text' => '�����',
        'url' => 'http://list.51buy.com/444--------.html',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�յ���',
            'url' => 'http://list.51buy.com/1181--------.html',
          ),
          1 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/444--------.html',
          ),
          2 => 
          array (
            'text' => '����/����',
            'url' => 'http://list.51buy.com/444-0-6-11-24-0-1-3328e10875-.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/444-0-6-11-24-0-1-2827e9365-.html',
          ),
          4 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/444-0-6-11-24-0-1-3328e10872-.html',
          ),
          5 => 
          array (
            'text' => '�յ�',
            'url' => 'http://list.51buy.com/736--------.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '�Ҿӵ���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/463--------.html',
          ),
          1 => 
          array (
            'text' => '���ٶ�',
            'url' => 'http://list.51buy.com/435--------.html',
          ),
          2 => 
          array (
            'text' => '���̻�',
            'url' => 'http://list.51buy.com/1186--------.html',
          ),
          3 => 
          array (
            'text' => '������ϴ��',
            'url' => 'http://list.51buy.com/1187--------.html',
          ),
          4 => 
          array (
            'text' => 'ë���޼���',
            'url' => 'http://list.51buy.com/1188--------.html',
          ),
          5 => 
          array (
            'text' => '�ֵ�ͲӦ����',
            'url' => 'http://list.51buy.com/534--------.html',
          ),
          6 => 
          array (
            'text' => '̨��/�Ķ���',
            'url' => 'http://list.51buy.com/475--------.html',
          ),
          7 => 
          array (
            'text' => '�绰��',
            'url' => 'http://list.51buy.com/438--------.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��װ����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��Ͱ������',
            'url' => 'http://list.51buy.com/1378--------.html',
          ),
          1 => 
          array (
            'text' => 'ԡ��',
            'url' => 'http://list.51buy.com/779--------.html',
          ),
          2 => 
          array (
            'text' => '��ˮ�豸',
            'url' => 'http://list.51buy.com/739--------.html',
          ),
          3 => 
          array (
            'text' => '���߻�',
            'url' => 'http://list.51buy.com/739-0-6-11-24-0-1-4788e18073-.html',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/744--------.html',
          ),
          5 => 
          array (
            'text' => '�綯����',
            'url' => 'http://list.51buy.com/464--------.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����������',
            'url' => 'http://list.51buy.com/466--------.html',
          ),
          1 => 
          array (
            'text' => '��ʪ��',
            'url' => 'http://list.51buy.com/1183--------.html',
          ),
          2 => 
          array (
            'text' => '��ʪ��',
            'url' => 'http://list.51buy.com/465--------.html',
          ),
          3 => 
          array (
            'text' => '�����豸',
            'url' => 'http://list.51buy.com/441--------.html',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '���˻���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���뵶',
            'url' => 'http://list.51buy.com/420--------.html',
          ),
          1 => 
          array (
            'text' => '��ë��',
            'url' => 'http://list.51buy.com/1195--------.html',
          ),
          2 => 
          array (
            'text' => '�綯��ˢ',
            'url' => 'http://list.51buy.com/421--------.html',
          ),
          3 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/421-0-6-11-24-0-1-3679e27159-.html',
          ),
          4 => 
          array (
            'text' => '�紵��',
            'url' => 'http://list.51buy.com/430--------.html',
          ),
          5 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/431--------.html',
          ),
          6 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/1231--------.html',
          ),
          7 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/1232--------.html',
          ),
          8 => 
          array (
            'text' => '��/��ë��',
            'url' => 'http://list.51buy.com/432--------.html',
          ),
          9 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/1194--------.html',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��Ħ��',
            'url' => 'http://list.51buy.com/1681--------.html',
          ),
          1 => 
          array (
            'text' => '��Ħ����',
            'url' => 'http://list.51buy.com/531--------.html',
          ),
          2 => 
          array (
            'text' => '��ԡ��',
            'url' => 'http://list.51buy.com/535--------.html',
          ),
          3 => 
          array (
            'text' => 'Ѫѹ��',
            'url' => 'http://list.51buy.com/482--------.html',
          ),
          4 => 
          array (
            'text' => 'Ѫ����',
            'url' => 'http://list.51buy.com/1567--------.html',
          ),
          5 => 
          array (
            'text' => '���¼�',
            'url' => 'http://list.51buy.com/1198--------.html',
          ),
          6 => 
          array (
            'text' => 'ҽ����е',
            'url' => 'http://list.51buy.com/1201--------.html',
          ),
          7 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/754--------.html',
          ),
          8 => 
          array (
            'text' => '������������',
            'url' => 'http://list.51buy.com/878--------.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '��������С�ҵ�29Ԫ��',
            'url' => 'http://act.51buy.com/promo-4054.html',
          ),
          1 => 
          array (
            'text' => 'װ������ʱ ȫ������',
            'url' => 'http://act.51buy.com/promo-4051.html',
          ),
          2 => 
          array (
            'text' => '���뵶���ͻ�79Ԫ��',
            'url' => 'http://act.51buy.com/promo-4029.html',
          ),
          3 => 
          array (
            'text' => 'ɨ�ػ����� ������˫��',
            'url' => 'http://list.51buy.com/463-0-6-11-24-0-1-7599e33370-.html',
          ),
          4 => 
          array (
            'text' => '90ƽ���ݿ���������',
            'url' => 'http://list.51buy.com/466-0-6-11-24-0-1-6260e27196-.html',
          ),
          5 => 
          array (
            'text' => '�����ӵ紵�� �㷢��˳����',
            'url' => 'http://list.51buy.com/430-0-6-11-24-0-1-7726e33578-.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  6 => 
  array (
    'text' => '��������',
    'url' => 'http://www.51buy.com/kitchen_electric.html',
    'highlight' => '1',
    'keyword' => 
    array (
      0 => 
      array (
        'text' => '������',
        'url' => 'http://list.51buy.com/460--------.html',
      ),
      1 => 
      array (
        'text' => '�緹��',
        'url' => 'http://list.51buy.com/449--------.html',
      ),
      2 => 
      array (
        'text' => '΢��¯',
        'url' => 'http://list.51buy.com/661--------.html',
      ),
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '�������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���̻�',
            'url' => 'http://list.51buy.com/799--------.html',
          ),
          1 => 
          array (
            'text' => 'ȼ����',
            'url' => 'http://list.51buy.com/799-0-6-11-24-0-1-5809e23936-.html',
          ),
          2 => 
          array (
            'text' => '�����ײ�',
            'url' => 'http://list.51buy.com/799-0-6-11-24-0-1-5809e23937o39984-.html',
          ),
          3 => 
          array (
            'text' => 'ϴ���',
            'url' => 'http://list.51buy.com/1564--------.html',
          ),
          4 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/800--------.html',
          ),
          5 => 
          array (
            'text' => '��ˮ��',
            'url' => 'http://list.51buy.com/838--------.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '��⿵���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�緹��',
            'url' => 'http://list.51buy.com/449--------.html',
          ),
          1 => 
          array (
            'text' => '��ѹ����',
            'url' => 'http://list.51buy.com/542--------.html',
          ),
          2 => 
          array (
            'text' => '�Ⲩ/΢��¯',
            'url' => 'http://list.51buy.com/661--------.html',
          ),
          3 => 
          array (
            'text' => '���¯',
            'url' => 'http://list.51buy.com/455--------.html',
          ),
          4 => 
          array (
            'text' => '�翾��',
            'url' => 'http://list.51buy.com/451--------.html',
          ),
          5 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/743--------.html',
          ),
          6 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/1168--------.html',
          ),
          7 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/453--------.html',
          ),
          8 => 
          array (
            'text' => '��ɰ��',
            'url' => 'http://list.51buy.com/1547--------.html',
          ),
          9 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/1175--------.html',
          ),
          10 => 
          array (
            'text' => '�忾¯',
            'url' => 'http://list.51buy.com/1566--------.html',
          ),
          11 => 
          array (
            'text' => '��ʿ¯',
            'url' => 'http://list.51buy.com/742--------.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��ʳ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/460--------.html',
          ),
          1 => 
          array (
            'text' => '��ˮ��/ƿ',
            'url' => 'http://list.51buy.com/459--------.html',
          ),
          2 => 
          array (
            'text' => '���Ȼ�/��',
            'url' => 'http://list.51buy.com/462--------.html',
          ),
          3 => 
          array (
            'text' => 'ե֭��',
            'url' => 'http://list.51buy.com/836--------.html',
          ),
          4 => 
          array (
            'text' => '����/�ٱ���',
            'url' => 'http://list.51buy.com/457--------.html',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/461--------.html',
          ),
          6 => 
          array (
            'text' => '���̻�',
            'url' => 'http://list.51buy.com/670--------.html',
          ),
          7 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/1178--------.html',
          ),
          8 => 
          array (
            'text' => '����ӹ���',
            'url' => 'http://list.51buy.com/1179--------.html',
          ),
          9 => 
          array (
            'text' => '���߾�����',
            'url' => 'http://list.51buy.com/807--------.html',
          ),
          10 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/1176--------.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '��ˮ�豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ˮ�豸',
            'url' => 'http://list.51buy.com/739--------.html',
          ),
          1 => 
          array (
            'text' => '��ˮ��',
            'url' => 'http://list.51buy.com/662--------.html',
          ),
          2 => 
          array (
            'text' => '��ˮͰ',
            'url' => 'http://list.51buy.com/1173--------.html',
          ),
          3 => 
          array (
            'text' => '���߻�',
            'url' => 'http://list.51buy.com/739-0-6-11-24-0-1-4788e18073-.html',
          ),
          4 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/662-0-6-11-24-0-1-3784e17713-.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '���ĳ���  �ؼ������ڴ�ʱ',
            'url' => 'http://act.51buy.com/promo-3464.html',
          ),
          1 => 
          array (
            'text' => 'С�ʱر��������',
            'url' => 'http://list.51buy.com/1176--6-11-24-0-1--.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  7 => 
  array (
    'text' => '�칫���Ĳġ��ľ�',
    'url' => 'http://www.51buy.com/office_equipment.html',
    'highlight' => '',
    'keyword' => 
    array (
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��ӡ�豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�����ӡ��',
            'url' => 'http://list.51buy.com/608--------.html',
          ),
          1 => 
          array (
            'text' => '��ī��ӡ��',
            'url' => 'http://list.51buy.com/824--------.html',
          ),
          2 => 
          array (
            'text' => '��ʽ��ӡ��',
            'url' => 'http://list.51buy.com/825--------.html',
          ),
          3 => 
          array (
            'text' => '��Ƭ��ӡ��',
            'url' => 'http://list.51buy.com/1104--------.html',
          ),
          4 => 
          array (
            'text' => '��ǩ��ӡ��',
            'url' => 'http://list.51buy.com/831--------.html',
          ),
          5 => 
          array (
            'text' => '��īһ��',
            'url' => 'http://list.51buy.com/609--------.html',
          ),
          6 => 
          array (
            'text' => '����һ��',
            'url' => 'http://list.51buy.com/826--------.html',
          ),
          7 => 
          array (
            'text' => '��ӡ��',
            'url' => 'http://list.51buy.com/814--------.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '����ɨ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ɨ����',
            'url' => 'http://list.51buy.com/613--------.html',
          ),
          1 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/611--------.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '�����豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ͶӰ��',
            'url' => 'http://list.51buy.com/665--------.html',
          ),
          1 => 
          array (
            'text' => '���Ӱװ�',
            'url' => 'http://list.51buy.com/815--------.html',
          ),
          2 => 
          array (
            'text' => 'ͶӰ������',
            'url' => 'http://list.51buy.com/830--------.html',
          ),
          3 => 
          array (
            'text' => '�绰��',
            'url' => 'http://list.51buy.com/438--------.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '�Ĳ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ī��',
            'url' => 'http://list.51buy.com/590--------.html',
          ),
          1 => 
          array (
            'text' => '���ĺ�ī��',
            'url' => 'http://list.51buy.com/591--------.html',
          ),
          2 => 
          array (
            'text' => 'ɫ��',
            'url' => 'http://list.51buy.com/593--------.html',
          ),
          3 => 
          array (
            'text' => '��ӡֽ',
            'url' => 'http://list.51buy.com/592--------.html',
          ),
          4 => 
          array (
            'text' => '��Ƭֽ',
            'url' => 'http://list.51buy.com/1108--------.html',
          ),
          5 => 
          array (
            'text' => '��ӡֽ',
            'url' => 'http://list.51buy.com/1664--------.html',
          ),
          6 => 
          array (
            'text' => '����ֽ',
            'url' => 'http://list.51buy.com/1107--------.html',
          ),
          7 => 
          array (
            'text' => '����ֽ',
            'url' => 'http://list.51buy.com/1663--------.html',
          ),
          8 => 
          array (
            'text' => '����ֽ��',
            'url' => 'http://list.51buy.com/1109--------.html',
          ),
          9 => 
          array (
            'text' => '��ֵ����',
            'url' => 'http://list.51buy.com/1354--------.html',
          ),
          10 => 
          array (
            'text' => '��¼��Ƭ',
            'url' => 'http://list.51buy.com/606--------.html',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '���������豸',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ֽ��',
            'url' => 'http://list.51buy.com/612--------.html',
          ),
          1 => 
          array (
            'text' => '�㳮��',
            'url' => 'http://list.51buy.com/614--------.html',
          ),
          2 => 
          array (
            'text' => '���ڻ�',
            'url' => 'http://list.51buy.com/610--------.html',
          ),
          3 => 
          array (
            'text' => 'װ����',
            'url' => 'http://list.51buy.com/832--------.html',
          ),
          4 => 
          array (
            'text' => '�ܷ��',
            'url' => 'http://list.51buy.com/1110--------.html',
          ),
          5 => 
          array (
            'text' => 'UPS����ϵ�Դ',
            'url' => 'http://list.51buy.com/1303--------.html',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '�칫�ľ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�ߵ��ʾ�',
            'url' => 'http://list.51buy.com/555--------.html',
          ),
          1 => 
          array (
            'text' => '��',
            'url' => 'http://list.51buy.com/860--------.html',
          ),
          2 => 
          array (
            'text' => 'Ϳ��',
            'url' => 'http://list.51buy.com/861--------.html',
          ),
          3 => 
          array (
            'text' => 'īˮ�ͱ�о',
            'url' => 'http://list.51buy.com/862--------.html',
          ),
          4 => 
          array (
            'text' => '�����ܱ�',
            'url' => 'http://list.51buy.com/1300--------.html',
          ),
          5 => 
          array (
            'text' => '���±�',
            'url' => 'http://list.51buy.com/868--------.html',
          ),
          6 => 
          array (
            'text' => '�ŷ�',
            'url' => 'http://list.51buy.com/869--------.html',
          ),
          7 => 
          array (
            'text' => '��ǩֽ',
            'url' => 'http://list.51buy.com/870--------.html',
          ),
          8 => 
          array (
            'text' => '�ڷ�����',
            'url' => 'http://list.51buy.com/1301--------.html',
          ),
          9 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/863--------.html',
          ),
          10 => 
          array (
            'text' => '������ʹ����',
            'url' => 'http://list.51buy.com/864--------.html',
          ),
          11 => 
          array (
            'text' => '�����ͽ�ˮ',
            'url' => 'http://list.51buy.com/865--------.html',
          ),
          12 => 
          array (
            'text' => '�ļ�����',
            'url' => 'http://list.51buy.com/866--------.html',
          ),
          13 => 
          array (
            'text' => '���ͳ�',
            'url' => 'http://list.51buy.com/867--------.html',
          ),
          14 => 
          array (
            'text' => '�����ľ�',
            'url' => 'http://list.51buy.com/1540--------.html',
          ),
          15 => 
          array (
            'text' => 'ѧ���ľ�',
            'url' => 'http://list.51buy.com/1641--------.html',
          ),
        ),
      ),
      6 => 
      array (
        'text' => '����������Ʒ',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ӡ�º͸�дֽ',
            'url' => 'http://list.51buy.com/872--------.html',
          ),
          1 => 
          array (
            'text' => 'ƾ֤�͵���',
            'url' => 'http://list.51buy.com/873--------.html',
          ),
          2 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/1304--------.html',
          ),
          3 => 
          array (
            'text' => 'װ����Ʒ',
            'url' => 'http://list.51buy.com/874--------.html',
          ),
          4 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://list.51buy.com/1317--------.html',
          ),
          5 => 
          array (
            'text' => '�ͷ���Ʒ',
            'url' => 'http://list.51buy.com/1643--------.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '�ؼ�˫�渴ӡֽ',
            'url' => 'http://item.51buy.com/item-221325.html',
          ),
          1 => 
          array (
            'text' => '���ܰ칫�豸7����',
            'url' => 'http://act.51buy.com/promo-3616.html',
          ),
          2 => 
          array (
            'text' => '����Ʒ�ƴ���ר��',
            'url' => 'http://act.51buy.com/promo-3295.html',
          ),
          3 => 
          array (
            'text' => 'ͶӰ����� ��1Ԫ�ͺ���',
            'url' => 'http://act.51buy.com/promo-3013.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  8 => 
  array (
    'text' => '������������װ��',
    'url' => 'http://www.51buy.com/automobile_maintenance.html',
    'highlight' => '',
    'keyword' => 
    array (
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/704--------.html',
          ),
          1 => 
          array (
            'text' => 'ɲ��������',
            'url' => 'http://list.51buy.com/1431--------.html',
          ),
          2 => 
          array (
            'text' => '����װ��',
            'url' => 'http://list.51buy.com/1445--------.html',
          ),
          3 => 
          array (
            'text' => '�յ���ϴ',
            'url' => 'http://list.51buy.com/1442--------.html',
          ),
          4 => 
          array (
            'text' => '������ȴҺ',
            'url' => 'http://list.51buy.com/1423--------.html',
          ),
          5 => 
          array (
            'text' => '�������Ӽ�',
            'url' => 'http://list.51buy.com/1415--------.html',
          ),
          6 => 
          array (
            'text' => 'ϵͳ����',
            'url' => 'http://list.51buy.com/1416--------.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '���ά��',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����������',
            'url' => 'http://list.51buy.com/705--------.html',
          ),
          1 => 
          array (
            'text' => '����������',
            'url' => 'http://list.51buy.com/706--------.html',
          ),
          2 => 
          array (
            'text' => '����������',
            'url' => 'http://list.51buy.com/707--------.html',
          ),
          3 => 
          array (
            'text' => '�յ�������',
            'url' => 'http://list.51buy.com/708--------.html',
          ),
          4 => 
          array (
            'text' => '��ˢ���',
            'url' => 'http://list.51buy.com/1154--------.html',
          ),
          5 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/1451--------.html',
          ),
          6 => 
          array (
            'text' => 'ɲ��Ƭ',
            'url' => 'http://list.51buy.com/1450--------.html',
          ),
          7 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/1449--------.html',
          ),
          8 => 
          array (
            'text' => 'ά�޹���',
            'url' => 'http://list.51buy.com/1134--------.html',
          ),
          9 => 
          array (
            'text' => '���±���',
            'url' => 'http://list.51buy.com/716--------.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '�������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���ݳ���',
            'url' => 'http://list.51buy.com/673--------.html',
          ),
          1 => 
          array (
            'text' => '���Զ�Ĥ',
            'url' => 'http://list.51buy.com/1135--------.html',
          ),
          2 => 
          array (
            'text' => '�����޸�',
            'url' => 'http://list.51buy.com/1137--------.html',
          ),
          3 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/1489--------.html',
          ),
          4 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/1140--------.html',
          ),
          5 => 
          array (
            'text' => '��๤��',
            'url' => 'http://list.51buy.com/1497--------.html',
          ),
          6 => 
          array (
            'text' => '��ˮ��ζ',
            'url' => 'http://list.51buy.com/703--------.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '����װ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/690--------.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/689--------.html',
          ),
          2 => 
          array (
            'text' => '�ŵ�',
            'url' => 'http://list.51buy.com/691--------.html',
          ),
          3 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/692--------.html',
          ),
          4 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/1464--------.html',
          ),
          5 => 
          array (
            'text' => 'ͷ������',
            'url' => 'http://list.51buy.com/1146--------.html',
          ),
          6 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/721--------.html',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '������Ʒ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������ֽ',
            'url' => 'http://list.51buy.com/1147--------.html',
          ),
          1 => 
          array (
            'text' => '����/����',
            'url' => 'http://list.51buy.com/1458--------.html',
          ),
          2 => 
          array (
            'text' => 'ֽ����/CD��',
            'url' => 'http://list.51buy.com/1466--------.html',
          ),
          3 => 
          array (
            'text' => '��ȫ��װ��',
            'url' => 'http://list.51buy.com/1460--------.html',
          ),
          4 => 
          array (
            'text' => '�ŵ���ɲ��װ��',
            'url' => 'http://list.51buy.com/1462--------.html',
          ),
          5 => 
          array (
            'text' => '�ֻ�/���ϼ�',
            'url' => 'http://list.51buy.com/1457--------.html',
          ),
          6 => 
          array (
            'text' => '������/ָ����',
            'url' => 'http://list.51buy.com/1465--------.html',
          ),
          7 => 
          array (
            'text' => '�̻Ҹ�',
            'url' => 'http://list.51buy.com/1459--------.html',
          ),
          8 => 
          array (
            'text' => '����Ͱ/�����',
            'url' => 'http://list.51buy.com/1455--------.html',
          ),
          9 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://list.51buy.com/1461--------.html',
          ),
          10 => 
          array (
            'text' => '����������Ʒ',
            'url' => 'http://list.51buy.com/693--------.html',
          ),
        ),
      ),
      5 => 
      array (
        'text' => 'װ���װ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������Ĥ',
            'url' => 'http://list.51buy.com/1389--------.html',
          ),
          1 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/1469--------.html',
          ),
          2 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/685--------.html',
          ),
          3 => 
          array (
            'text' => '�����տ�',
            'url' => 'http://list.51buy.com/1153--------.html',
          ),
          4 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/1157--------.html',
          ),
          5 => 
          array (
            'text' => '����Ұ',
            'url' => 'http://list.51buy.com/1160--------.html',
          ),
          6 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/1502--------.html',
          ),
          7 => 
          array (
            'text' => '�����',
            'url' => 'http://list.51buy.com/1152--------.html',
          ),
          8 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/1151--------.html',
          ),
          9 => 
          array (
            'text' => '����ϵͳ',
            'url' => 'http://list.51buy.com/1364--------.html',
          ),
          10 => 
          array (
            'text' => '���ξ�Ʒ',
            'url' => 'http://list.51buy.com/1474--------.html',
          ),
        ),
      ),
      6 => 
      array (
        'text' => '���ӵ���',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'GPS����',
            'url' => 'http://list.51buy.com/710--------.html',
          ),
          1 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/1453--------.html',
          ),
          2 => 
          array (
            'text' => 'MP3 MP4',
            'url' => 'http://list.51buy.com/709--------.html',
          ),
          3 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/711--------.html',
          ),
          4 => 
          array (
            'text' => '���ص�Դ',
            'url' => 'http://list.51buy.com/713--------.html',
          ),
          5 => 
          array (
            'text' => '�� ů ��',
            'url' => 'http://list.51buy.com/712--------.html',
          ),
          6 => 
          array (
            'text' => '���ص���',
            'url' => 'http://list.51buy.com/1245--------.html',
          ),
        ),
      ),
      7 => 
      array (
        'text' => '��ȫ�Լ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ͯ����',
            'url' => 'http://list.51buy.com/1158--------.html',
          ),
          1 => 
          array (
            'text' => '̥ѹ���',
            'url' => 'http://list.51buy.com/1454--------.html',
          ),
          2 => 
          array (
            'text' => '��ȫӦ��',
            'url' => 'http://list.51buy.com/701--------.html',
          ),
          3 => 
          array (
            'text' => '�Լ���Ʒ',
            'url' => 'http://list.51buy.com/1161--------.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '������ƷQ�ռ�  ÿ���о�ϲ',
            'url' => 'http://act.51buy.com/promo-1041.html',
          ),
          1 => 
          array (
            'text' => 'ÿ��һ��  �ͼ�����',
            'url' => 'http://www.51buy.com/automobile_maintenance.html',
          ),
          2 => 
          array (
            'text' => '���䡢�����������ػ�ר��',
            'url' => 'http://act.51buy.com/promo-3840.html',
          ),
          3 => 
          array (
            'text' => '������Ʒÿ��5��������Ӧ',
            'url' => 'http://act.51buy.com/promo-3005.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  9 => 
  array (
    'text' => '��������ࡢֽƷ',
    'url' => 'http://www.51buy.com/personal_beauty.html',
    'highlight' => '',
    'keyword' => 
    array (
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��ʿ����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/1371--------.html',
          ),
          1 => 
          array (
            'text' => '�۲�����',
            'url' => 'http://list.51buy.com/402--------.html',
          ),
          2 => 
          array (
            'text' => '���廤��',
            'url' => 'http://list.51buy.com/403--------.html',
          ),
          3 => 
          array (
            'text' => '���뻤��',
            'url' => 'http://list.51buy.com/1097--------.html',
          ),
          4 => 
          array (
            'text' => '��ʿ����',
            'url' => 'http://list.51buy.com/401--------.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '�沿����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/1365--------.html',
          ),
          1 => 
          array (
            'text' => 'ˬ��ˮ/��ױˮ',
            'url' => 'http://list.51buy.com/1366--------.html',
          ),
          2 => 
          array (
            'text' => '��Һ/��˪',
            'url' => 'http://list.51buy.com/1367--------.html',
          ),
          3 => 
          array (
            'text' => '�۲�����',
            'url' => 'http://list.51buy.com/241--------.html',
          ),
          4 => 
          array (
            'text' => 'T������',
            'url' => 'http://list.51buy.com/1091--------.html',
          ),
          5 => 
          array (
            'text' => '��Ĥ/����',
            'url' => 'http://list.51buy.com/105--------.html',
          ),
          6 => 
          array (
            'text' => '���ഽ��',
            'url' => 'http://list.51buy.com/1117--------.html',
          ),
          7 => 
          array (
            'text' => '��ʿ����',
            'url' => 'http://list.51buy.com/401--------.html',
          ),
          8 => 
          array (
            'text' => '��ɹ����',
            'url' => 'http://list.51buy.com/1375--------.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��ǻ����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/580--------.html',
          ),
          1 => 
          array (
            'text' => '��ˢ',
            'url' => 'http://list.51buy.com/931--------.html',
          ),
          2 => 
          array (
            'text' => '����ˮ/��ǻ���¼�',
            'url' => 'http://list.51buy.com/694--------.html',
          ),
          3 => 
          array (
            'text' => '��ǩ/��',
            'url' => 'http://list.51buy.com/727--------.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => 'ϴ������',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ϴ��¶',
            'url' => 'http://list.51buy.com/192--------.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/473--------.html',
          ),
          2 => 
          array (
            'text' => 'Ⱦ��',
            'url' => 'http://list.51buy.com/1387--------.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/920--------.html',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '���廤��',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ԡ¶',
            'url' => 'http://list.51buy.com/653--------.html',
          ),
          1 => 
          array (
            'text' => '���¶',
            'url' => 'http://list.51buy.com/1206--------.html',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/1309--------.html',
          ),
          3 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/780--------.html',
          ),
          4 => 
          array (
            'text' => '���㻤��',
            'url' => 'http://list.51buy.com/1261--------.html',
          ),
          5 => 
          array (
            'text' => 'ů����',
            'url' => 'http://list.51buy.com/1219--------.html',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '�����Ʒ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://list.51buy.com/1523--------.html',
          ),
          1 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/854--------.html',
          ),
          2 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/1575--------.html',
          ),
          3 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/1273--------.html',
          ),
          4 => 
          array (
            'text' => '��ԡ���',
            'url' => 'http://list.51buy.com/787--------.html',
          ),
          5 => 
          array (
            'text' => '��๤��',
            'url' => 'http://list.51buy.com/888--------.html',
          ),
          6 => 
          array (
            'text' => '������/Ͱ',
            'url' => 'http://list.51buy.com/991--------.html',
          ),
        ),
      ),
      6 => 
      array (
        'text' => '������ֽ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����ֽ',
            'url' => 'http://list.51buy.com/881--------.html',
          ),
          1 => 
          array (
            'text' => '��ֽ',
            'url' => 'http://list.51buy.com/883--------.html',
          ),
          2 => 
          array (
            'text' => 'ʪ��ֽ',
            'url' => 'http://list.51buy.com/882--------.html',
          ),
          3 => 
          array (
            'text' => '��ֽ',
            'url' => 'http://list.51buy.com/884--------.html',
          ),
          4 => 
          array (
            'text' => 'ƽ��ֽ',
            'url' => 'http://list.51buy.com/885--------.html',
          ),
          5 => 
          array (
            'text' => '������ֽ',
            'url' => 'http://list.51buy.com/932--------.html',
          ),
          6 => 
          array (
            'text' => '������ֽ',
            'url' => 'http://list.51buy.com/1207--------.html',
          ),
          7 => 
          array (
            'text' => 'ֽ���',
            'url' => 'http://list.51buy.com/886--------.html',
          ),
        ),
      ),
      7 => 
      array (
        'text' => '������Ʒ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ȫ����',
            'url' => 'http://list.51buy.com/400--------.html',
          ),
          1 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/469--------.html',
          ),
          2 => 
          array (
            'text' => '����ϵ��',
            'url' => 'http://list.51buy.com/472--------.html',
          ),
          3 => 
          array (
            'text' => '�鰮���',
            'url' => 'http://list.51buy.com/470--------.html',
          ),
        ),
      ),
      8 => 
      array (
        'text' => 'Ů�Ի���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/990--------.html',
          ),
          1 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/474--------.html',
          ),
          2 => 
          array (
            'text' => 'ϴҺ',
            'url' => 'http://list.51buy.com/393--------.html',
          ),
        ),
      ),
      9 => 
      array (
        'text' => '��ױ����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������ױ',
            'url' => 'http://list.51buy.com/1089--------.html',
          ),
          1 => 
          array (
            'text' => '��ɹ����',
            'url' => 'http://list.51buy.com/1375--------.html',
          ),
          2 => 
          array (
            'text' => 'жױ',
            'url' => 'http://list.51buy.com/351--------.html',
          ),
          3 => 
          array (
            'text' => '��޹����',
            'url' => 'http://list.51buy.com/1527--------.html',
          ),
          4 => 
          array (
            'text' => '��������/����',
            'url' => 'http://list.51buy.com/1374--------.html',
          ),
          5 => 
          array (
            'text' => '���ݹ���',
            'url' => 'http://list.51buy.com/1103--------.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ӭ�������ȫ��3����',
            'url' => 'http://act.51buy.com/promo-3368.html',
          ),
          1 => 
          array (
            'text' => 'ŷ������ʿ��Ʒ�����ؼ�',
            'url' => 'http://item.51buy.com/item-289824.html',
          ),
          2 => 
          array (
            'text' => '�������ȫ����200-30',
            'url' => 'http://act.51buy.com/promo-4025.html',
          ),
          3 => 
          array (
            'text' => '����ȫ����98-20',
            'url' => 'http://act.51buy.com/promo-3873.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  10 => 
  array (
    'text' => '������Ʒ������˶�',
    'url' => 'http://www.51buy.com/household_kitchen.html',
    'highlight' => '',
    'keyword' => 
    array (
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���ʺ�',
            'url' => 'http://list.51buy.com/1277--------.html',
          ),
          1 => 
          array (
            'text' => '����ˮ��',
            'url' => 'http://list.51buy.com/749--------.html',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/750--------.html',
          ),
          3 => 
          array (
            'text' => '�;�',
            'url' => 'http://list.51buy.com/751--------.html',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/765--------.html',
          ),
          5 => 
          array (
            'text' => '����С��',
            'url' => 'http://list.51buy.com/812--------.html',
          ),
          6 => 
          array (
            'text' => 'һ������Ʒ',
            'url' => 'http://list.51buy.com/786--------.html',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '��Ʒ�ҷ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��Ʒ����',
            'url' => 'http://list.51buy.com/808--------.html',
          ),
          1 => 
          array (
            'text' => '����/ë����',
            'url' => 'http://list.51buy.com/781--------.html',
          ),
          2 => 
          array (
            'text' => '��о����',
            'url' => 'http://list.51buy.com/767--------.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/772--------.html',
          ),
          4 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/766--------.html',
          ),
          5 => 
          array (
            'text' => 'ë���ҷ�',
            'url' => 'http://list.51buy.com/890--------.html',
          ),
          6 => 
          array (
            'text' => '��ϯ/����',
            'url' => 'http://list.51buy.com/809--------.html',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�ڿ�',
            'url' => 'http://list.51buy.com/967--------.html',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/1397--------.html',
          ),
          2 => 
          array (
            'text' => '��ů����/��ë����',
            'url' => 'http://list.51buy.com/777--------.html',
          ),
          3 => 
          array (
            'text' => '�Ҿӷ�',
            'url' => 'http://list.51buy.com/1661--------.html',
          ),
          4 => 
          array (
            'text' => '����/����/�������',
            'url' => 'http://list.51buy.com/971--------.html',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '�Ӽ�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����ϴɹ',
            'url' => 'http://list.51buy.com/752--------.html',
          ),
          1 => 
          array (
            'text' => '���',
            'url' => 'http://list.51buy.com/797--------.html',
          ),
          2 => 
          array (
            'text' => '��ζ����',
            'url' => 'http://list.51buy.com/889--------.html',
          ),
          3 => 
          array (
            'text' => '�Ӽ���Ь',
            'url' => 'http://list.51buy.com/1577--------.html',
          ),
          4 => 
          array (
            'text' => '��ԡ��Ʒ',
            'url' => 'http://list.51buy.com/774--------.html',
          ),
          5 => 
          array (
            'text' => '�ص�',
            'url' => 'http://list.51buy.com/810--------.html',
          ),
          6 => 
          array (
            'text' => '������',
            'url' => 'http://list.51buy.com/754--------.html',
          ),
          7 => 
          array (
            'text' => '���ù���',
            'url' => 'http://list.51buy.com/1554--------.html',
          ),
          8 => 
          array (
            'text' => '�Ҿ�����',
            'url' => 'http://list.51buy.com/995--------.html',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '��Ʒ����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����̾�',
            'url' => 'http://list.51buy.com/934--------.html',
          ),
          1 => 
          array (
            'text' => '��ʿ����',
            'url' => 'http://list.51buy.com/436--------.html',
          ),
          2 => 
          array (
            'text' => '�ֱ�',
            'url' => 'http://list.51buy.com/783--------.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/1205--------.html',
          ),
          4 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://list.51buy.com/759--------.html',
          ),
          5 => 
          array (
            'text' => '��ȯ',
            'url' => 'http://list.51buy.com/1002--------.html',
          ),
          6 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://list.51buy.com/554--------.html',
          ),
          7 => 
          array (
            'text' => '�ߵ��ʾ�',
            'url' => 'http://list.51buy.com/555--------.html',
          ),
          8 => 
          array (
            'text' => '�۾�',
            'url' => 'http://list.51buy.com/951--------.html',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '���',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'Ǯ��/�ְ�',
            'url' => 'http://list.51buy.com/568--------.html',
          ),
          1 => 
          array (
            'text' => '˫���/����',
            'url' => 'http://list.51buy.com/746--------.html',
          ),
          2 => 
          array (
            'text' => '�����/�����',
            'url' => 'http://list.51buy.com/571--------.html',
          ),
          3 => 
          array (
            'text' => '������/���д�',
            'url' => 'http://list.51buy.com/572--------.html',
          ),
          4 => 
          array (
            'text' => '���ⱳ��/�˶���',
            'url' => 'http://list.51buy.com/979--------.html',
          ),
          5 => 
          array (
            'text' => '���',
            'url' => 'http://list.51buy.com/773--------.html',
          ),
          6 => 
          array (
            'text' => 'Ů��',
            'url' => 'http://list.51buy.com/1507--------.html',
          ),
        ),
      ),
      6 => 
      array (
        'text' => '���',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ң�����',
            'url' => 'http://list.51buy.com/758--------.html',
          ),
          1 => 
          array (
            'text' => 'ģ�����',
            'url' => 'http://list.51buy.com/760--------.html',
          ),
          2 => 
          array (
            'text' => '�������',
            'url' => 'http://list.51buy.com/757--------.html',
          ),
          3 => 
          array (
            'text' => 'ë�޹���',
            'url' => 'http://list.51buy.com/1204--------.html',
          ),
          4 => 
          array (
            'text' => 'Ӥ�����',
            'url' => 'http://list.51buy.com/1004--------.html',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/877--------.html',
          ),
        ),
      ),
      7 => 
      array (
        'text' => '�����˶�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ë��',
            'url' => 'http://list.51buy.com/975--------.html',
          ),
          1 => 
          array (
            'text' => 'ƹ����',
            'url' => 'http://list.51buy.com/974--------.html',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/973--------.html',
          ),
          3 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/993--------.html',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/977--------.html',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://list.51buy.com/976--------.html',
          ),
          6 => 
          array (
            'text' => '��Ӿ��Ʒ',
            'url' => 'http://list.51buy.com/654--------.html',
          ),
          7 => 
          array (
            'text' => '�٤��Ʒ',
            'url' => 'http://list.51buy.com/985--------.html',
          ),
        ),
      ),
      8 => 
      array (
        'text' => '���ı���',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�˶�����',
            'url' => 'http://list.51buy.com/448--------.html',
          ),
          1 => 
          array (
            'text' => '������е',
            'url' => 'http://list.51buy.com/1209--------.html',
          ),
          2 => 
          array (
            'text' => '�˶�����',
            'url' => 'http://list.51buy.com/992--------.html',
          ),
          3 => 
          array (
            'text' => '��������',
            'url' => 'http://list.51buy.com/442--------.html',
          ),
        ),
      ),
      9 => 
      array (
        'text' => '����װ��',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���ⱳ��/�˶���',
            'url' => 'http://list.51buy.com/979--------.html',
          ),
          1 => 
          array (
            'text' => '�˶�����',
            'url' => 'http://list.51buy.com/972--------.html',
          ),
          2 => 
          array (
            'text' => '�˶�ˮ��',
            'url' => 'http://list.51buy.com/566--------.html',
          ),
          3 => 
          array (
            'text' => '¶Ӫ��Ʒ',
            'url' => 'http://list.51buy.com/981--------.html',
          ),
          4 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://list.51buy.com/982--------.html',
          ),
          5 => 
          array (
            'text' => '���⹤��',
            'url' => 'http://list.51buy.com/984--------.html',
          ),
          6 => 
          array (
            'text' => '��ʿ����',
            'url' => 'http://list.51buy.com/436--------.html',
          ),
          7 => 
          array (
            'text' => '��Զ��',
            'url' => 'http://list.51buy.com/753--------.html',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '�ٻ�����ͼ�����ѡ',
            'url' => 'http://www.51buy.com/household_kitchen.html',
          ),
          1 => 
          array (
            'text' => '�ֿ���װ0����˦��',
            'url' => 'http://s.51buy.com/1277--6-11-24-0-1--.html?q=%C0%D6%BF%DB',
          ),
          2 => 
          array (
            'text' => '[С�׽���] ��ʡ����ռ�',
            'url' => 'http://act.51buy.com/promo-3841.html',
          ),
          3 => 
          array (
            'text' => '���αر�װ��  ��ֵ�ü�',
            'url' => 'http://act.51buy.com/promo-4008.html',
          ),
          4 => 
          array (
            'text' => 'С�װ���Զ���ȩΣ��',
            'url' => 'http://act.51buy.com/promo-3650.html',
          ),
          5 => 
          array (
            'text' => 'Banisi�ҷ�ȫ���ػ�',
            'url' => 'http://act.51buy.com/promo-4058.html',
          ),
          6 => 
          array (
            'text' => '������Ʒ����  ����2��',
            'url' => 'http://list.51buy.com/808--------.html',
          ),
          7 => 
          array (
            'text' => 'ZIPPOȫ��2.8����',
            'url' => 'http://list.51buy.com/934--------.html',
          ),
          8 => 
          array (
            'text' => 'ң��ģ�ͳ�ȫ��59Ԫ��',
            'url' => 'http://list.51buy.com/758--------.html',
          ),
        ),
        'name' => '����',
      ),
    ),
  ),
  11 => 
  array (
    'text' => '�鱦��Ʒ',
    'url' => 'http://buy.qq.com/jewelry',
    'highlight' => '',
    'keyword' => 
    array (
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��ʯ�鱦',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ʯ��Ʒ',
            'url' => 'http://searchex.buy.qq.com/html?Path=0,5000692-0,5002083&KeyWord=%E9%92%BB%E7%9F%B3%E9%A5%B0%E5%93%81&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '��ʯ',
            'url' => 'http://searchex.buy.qq.com/html?Path=0,5000692-0,5000696&KeyWord=%E7%8E%89&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E7%8F%8D%E7%8F%A0',
          ),
          3 => 
          array (
            'text' => '�ƽ�/K��',
            'url' => 'http://searchex.buy.qq.com/html?Path=0,5000692-0,5000703&KeyWord=%E9%BB%84%E9%87%91&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://searchex.buy.qq.com/html?Path=0,5000692-0,5000707&KeyWord=%E9%93%82%E9%87%91&charset=utf-8&Location=440000&PageSize=40&PageNum=1&cluster=1&ShowClass=1&ShowPath=1&OrderStyle=1',
          ),
        ),
      ),
      1 => 
      array (
        'text' => 'ʱ����Ʒ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��׹',
            'url' => 'http://buy.qq.com/search.html?Path=5000711&as=0',
          ),
          1 => 
          array (
            'text' => '����',
            'url' => 'http://buy.qq.com/search.html?Path=5000712&as=0',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://buy.qq.com/search.html?Path=5000713&as=0',
          ),
          3 => 
          array (
            'text' => '��ָ',
            'url' => 'http://buy.qq.com/search.html?Path=5000714&as=0',
          ),
          4 => 
          array (
            'text' => '����',
            'url' => 'http://buy.qq.com/search.html?Path=5000715&as=0',
          ),
          5 => 
          array (
            'text' => '����',
            'url' => 'http://buy.qq.com/search.html?Path=5000717&as=0',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��ʯ�ƽ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ʯ��׹',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%90%8A%E5%9D%A0&Path=0,5000692-2757,2-0,5002083&KeyWord=%E5%90%8A%E5%9D%A0&Path=0,5000692-2757,2-0,5002083&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '���¶Խ�',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%83%85%E4%BE%A3%E5%AF%B9%E6%88%92&Path=0,5000692-2757,3-0,5002083&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '��ʯŮ��',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%A5%B3%E6%88%92%C2%A0&Path=0,5000692&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => 'Ⱥ���',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E7%BE%A4%20%E5%9B%B4%20%E9%95%B6&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => 'ǧ���',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%8D%83%E8%B6%B3%E9%87%91&Path=0,5000692-0,5000703&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => 'Ͷ�ʽ���',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E9%87%91%E6%9D%A1&KeyWord=%E9%87%91%E6%9D%A1&Path=0,5000692&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => 'ǧ����׹',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%8D%83%E8%B6%B3%E9%87%91%20%E5%90%8A%E5%9D%A0&Path=0,5000692-0,5000703&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '������',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E9%87%91%20%E9%A1%B9%E9%93%BE&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
        ),
      ),
      3 => 
      array (
        'text' => '�������',
        'list' => 
        array (
          0 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://buy.qq.com/search.html?__Path=5002083&KeyWord=&Path=0,5000692-0,5000699&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '�����׹',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%90%8A%E5%9D%A0%C2%A0%20%C2%A0%20&Path=0,5000692-0,5000699-0,5000700&KeyWord=%E5%90%8A%E5%9D%A0%C2%A0%20%C2%A0%20&Path=0,5000692-0,5000699-0,5000700&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '��������',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E9%A1%B9%E9%93%BE%C2%A0%20&Path=0,5000692-0,5000699-0,5000700&KeyWord=%E9%A1%B9%E9%93%BE%C2%A0%20&Path=0,5000692-0,5000699-0,5000700&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '�������',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E8%80%B3&Path=0,5000692-0,5000699-0,5000700&KeyWord=%E8%80%B3&Path=0,5000692-0,5000699-0,5000700&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '��Ȼ����',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%A4%A9%E7%84%B6%E7%8F%8D%E7%8F%A0&Path=0,5000692-0,5000699-0,5000700&KeyWord=%E5%A4%A9%E7%84%B6%E7%8F%8D%E7%8F%A0&Path=0,5000692-0,5000699-0,5000700&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '��Ϫ�غ�����',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%A4%A7%E6%BA%AA%E5%9C%B0%E9%BB%91%E7%8F%8D%E7%8F%A0&Path=0,5000692-0,5000699-0,5000700&KeyWord=%E5%A4%A7%E6%BA%AA%E5%9C%B0%E9%BB%91%E7%8F%8D%E7%8F%A0&Path=0,5000692-0,5000699-0,5000700&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '��ʯ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E7%8E%89&KeyWord=%E7%8E%89&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '���',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E7%BF%A0&KeyWord=%E7%BF%A0&Path=0,5000692&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
        ),
      ),
      4 => 
      array (
        'text' => '��Ȼ��ʯ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E7%A0%97%E7%A3%B2%20%20&Path=0,5000709&KeyWord=%E7%A0%97%E7%A3%B2%20%20&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '���',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E7%8E%9B%E7%91%99&Path=0,5000709&KeyWord=%E7%8E%9B%E7%91%99&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '����ʯ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E9%BB%91%E6%9B%9C%E7%9F%B3&Path=0,5000709&KeyWord=%E9%BB%91%E6%9B%9C%E7%9F%B3&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '�¹�ʯ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%9C%88%E5%85%89%E7%9F%B3&KeyWord=%E6%9C%88%E5%85%89%E7%9F%B3&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '��ʯ��׹',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%90%8A%E5%9D%A0%20&Path=0,5000709&KeyWord=%E5%90%8A%E5%9D%A0%20&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=2',
          ),
          5 => 
          array (
            'text' => '��ʯ����',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%89%8B%E9%93%BE&Path=0,5000709&KeyWord=%E6%89%8B%E9%93%BE&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '��ʯ����',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E7%9F%B3%E8%80%B3&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '��ʯ��׹',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E8%BD%A6%E6%8C%82&Path=0,5000709&KeyWord=%E8%BD%A6%E6%8C%82&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
        ),
      ),
      5 => 
      array (
        'text' => '������Ʒ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '925����Ʒ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=925%20%E9%93%B6&KeyWord=925%20%E9%93%B6&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '925����׹',
            'url' => 'http://buy.qq.com/search.html?KeyWord=925%20%E9%93%B6%20%E5%90%8A%E5%9D%A0&KeyWord=925%20%E9%93%B6%20%E5%90%8A%E5%9D%A0&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => '925������',
            'url' => 'http://buy.qq.com/search.html?KeyWord=925%20%E9%93%B6%20%E8%80%B3&KeyWord=925%20%E9%93%B6%20%E8%80%B3&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '925����ָ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=925%20%E9%93%B6%20%E6%88%92%E6%8C%87&KeyWord=925%20%E9%93%B6%20%E6%88%92%E6%8C%87&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '���α���',
            'url' => 'http://buy.qq.com/search.html?KeyWord=925%20%E9%93%B6&KeyWord=925%20%E9%93%B6&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=4',
          ),
          5 => 
          array (
            'text' => 'Ů���',
            'url' => 'http://buy.qq.com/search.html?KeyWord=925%20%E9%93%B6%20%E5%A5%B3&KeyWord=925%20%E9%93%B6%20%E5%A5%B3&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=4',
          ),
          6 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=925%20%E9%93%B6%E6%83%85%E4%BE%A3&KeyWord=925%20%E9%93%B6%E6%83%85%E4%BE%A3&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '������Ϯ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=925%20%E9%93%B6%20%E9%9F%A9&KeyWord=925%20%E9%93%B6%20%E9%9F%A9&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
        ),
      ),
      6 => 
      array (
        'text' => 'ˮ������',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ˮ����׹',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%96%BD%E5%8D%8E%E6%B4%9B%E4%B8%96%E5%A5%87%E5%85%83%E7%B4%A0%E6%B0%B4%E6%99%B6%20%E5%90%8A%E5%9D%A0%C2%A0%20%C2%A0%20&Path=&KeyWord=%E6%96%BD%E5%8D%8E%E6%B4%9B%E4%B8%96%E5%A5%87%E5%85%83%E7%B4%A0%E6%B0%B4%E6%99%B6%20%E5%90%8A%E5%9D%A0%C2%A0%20%C2%A0%20&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=3',
          ),
          1 => 
          array (
            'text' => 'ˮ������',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%89%8B%E9%93%BE&Path=&KeyWord=%E6%89%8B%E9%93%BE&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          2 => 
          array (
            'text' => 'ˮ����ָ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%B0%B4%E6%99%B6%20%E6%88%92%E6%8C%87&KeyWord=%E6%B0%B4%E6%99%B6%20%E6%88%92%E6%8C%87&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => 'ˮ������',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%96%BD%E5%8D%8E%E6%B4%9B%E4%B8%96%E5%A5%87%E5%85%83%E7%B4%A0%E6%B0%B4%E6%99%B6%20%E8%80%B3%E9%92%89%C2%A0%20%C2%A0%20&Path=&KeyWord=%E6%96%BD%E5%8D%8E%E6%B4%9B%E4%B8%96%E5%A5%87%E5%85%83%E7%B4%A0%E6%B0%B4%E6%99%B6%20%E8%80%B3%E9%92%89%C2%A0%20%C2%A0%20&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => 'ˮ������',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%B0%B4%E6%99%B6%E9%A1%B9%E9%93%BE%C2%A0&KeyWord=%E6%B0%B4%E6%99%B6%E9%A1%B9%E9%93%BE%C2%A0&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          5 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%B0%B4%E6%99%B6%20%E5%BA%A7&KeyWord=%E6%B0%B4%E6%99%B6%20%E5%BA%A7&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          6 => 
          array (
            'text' => '��Ҷ����Ʒ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%9B%9B%E5%8F%B6%E8%8D%89%C2%A0%20&Path=&KeyWord=%E5%9B%9B%E5%8F%B6%E8%8D%89%C2%A0%20&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          7 => 
          array (
            'text' => '������Ʒ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%B0%B4%E6%99%B6%20%E5%BF%83&KeyWord=%E6%B0%B4%E6%99%B6%20%E5%BF%83&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=3',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '������ʯ',
            'url' => 'http://buy.qq.com/opr/acts/cuxiao/kelan.html?s=09',
          ),
          1 => 
          array (
            'text' => 'ŷ����',
            'url' => 'http://buy.qq.com/opr/acts/cuxiao/kelan.html?s=11',
          ),
          2 => 
          array (
            'text' => '����',
            'url' => 'http://buy.qq.com/opr/acts/cuxiao/kelan.html?s=14',
          ),
          3 => 
          array (
            'text' => '�ð�',
            'url' => 'http://buy.qq.com/pro/jewelry/b.html?s=01',
          ),
          4 => 
          array (
            'text' => 'T400',
            'url' => 'http://buy.qq.com/pro/jewelry/b.html?s=04',
          ),
          5 => 
          array (
            'text' => 'Mbox',
            'url' => 'http://buy.qq.com/pro/jewelry/b.html?s=02',
          ),
          6 => 
          array (
            'text' => '����Ȧ',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E9%93%B6%E5%B0%9A%E5%9C%88&KeyWord=%E9%93%B6%E5%B0%9A%E5%9C%88&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=3',
          ),
          7 => 
          array (
            'text' => 'KaiLa',
            'url' => 'http://buy.qq.com/search.html?KeyWord=Kaila&KeyWord=Kaila&Path=0,5000709&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
        ),
        'name' => 'Ʒ�Ʒ���',
      ),
    ),
  ),
  12 => 
  array (
    'text' => 'Ьѥ�˶�',
    'url' => 'http://buy.qq.com/sports/',
    'highlight' => '',
    'keyword' => 
    array (
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '�˶�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�˶�Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002472',
          ),
          1 => 
          array (
            'text' => '�˶�����',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002492',
          ),
          2 => 
          array (
            'text' => '�˶���',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002514',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '�˶�����',
        'list' => 
        array (
          0 => 
          array (
            'text' => '����Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002537',
          ),
          1 => 
          array (
            'text' => '�����',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002574',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '��Ь',
        'list' => 
        array (
          0 => 
          array (
            'text' => 'ƤЬ',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002614',
          ),
          1 => 
          array (
            'text' => '����Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002616',
          ),
          2 => 
          array (
            'text' => '��Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002618',
          ),
          3 => 
          array (
            'text' => '��Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002617',
          ),
        ),
      ),
      3 => 
      array (
        'text' => 'ŮЬ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002625',
          ),
          1 => 
          array (
            'text' => '����Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002622',
          ),
          2 => 
          array (
            'text' => 'ѥ��',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002620',
          ),
          3 => 
          array (
            'text' => '��Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002623',
          ),
          4 => 
          array (
            'text' => '��Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002621',
          ),
        ),
      ),
      4 => 
      array (
        'text' => 'ͯЬ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�˶�Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002631',
          ),
          1 => 
          array (
            'text' => '��Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002633',
          ),
          2 => 
          array (
            'text' => 'ѥ��',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002629',
          ),
          3 => 
          array (
            'text' => '��Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002637',
          ),
          4 => 
          array (
            'text' => '��Ь',
            'url' => 'http://searchex.buy.qq.com/html?Path=5002630',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '���ϴ�˹/adidas',
            'url' => 'http://buy.qq.com/search.html?KeyWord=adidas&KeyWord=adidas&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          1 => 
          array (
            'text' => '�Ϳ�/nike',
            'url' => 'http://buy.qq.com/search.html?KeyWord=nike',
          ),
          2 => 
          array (
            'text' => '��̤/anta',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%AE%89%E8%B8%8F&KeyWord=%E5%AE%89%E8%B8%8F&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          3 => 
          array (
            'text' => '����/converse',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E5%8C%A1%E5%A8%81&KeyWord=%E5%8C%A1%E5%A8%81&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
          4 => 
          array (
            'text' => '����/lining',
            'url' => 'http://buy.qq.com/search.html?KeyWord=%E6%9D%8E%E5%AE%81&KeyWord=%E6%9D%8E%E5%AE%81&Path=&Location=440000&BeginPrice=&EndPrice=&PageSize=40&OrderStyle=1',
          ),
        ),
        'name' => '����Ʒ��',
      ),
    ),
  ),
  13 => 
  array (
    'text' => '��Ʊ�Ƶ�',
    'url' => 'http://buy.go.qq.com/',
    'highlight' => '',
    'keyword' => 
    array (
    ),
    'list' => 
    array (
      0 => 
      array (
        'text' => '��ѡ�Ź�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '��ѡ���Լ۱��Ź�',
            'url' => 'http://buy.go.qq.com/tuan/?order=salelower&page=1&attach=qqlvyou_50_13_0',
          ),
          1 => 
          array (
            'text' => '��ѡ�ݻ��Ź�',
            'url' => 'http://buy.go.qq.com/tuan/?order=pricelower&page=1&attach=qqlvyou_50_13_0',
          ),
          2 => 
          array (
            'text' => '��ѡ���ͼ��Ź�',
            'url' => 'http://buy.go.qq.com/tuan/?order=priceupper&page=1&attach=qqlvyou_50_13_0',
          ),
        ),
      ),
      1 => 
      array (
        'text' => '��ɫ�Ƶ�',
        'list' => 
        array (
          0 => 
          array (
            'text' => '�����Ƶ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/beijing_0101.html?attach=qqlvyou_50_13_0',
          ),
          1 => 
          array (
            'text' => '�Ϻ��Ƶ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/shanghai_0201.html?attach=qqlvyou_50_13_0',
          ),
          2 => 
          array (
            'text' => '���ݾƵ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/guangzhou_2001.html?attach=qqlvyou_50_13_0',
          ),
          3 => 
          array (
            'text' => '���ھƵ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/shenzhen_2003.html?attach=qqlvyou_50_13_0',
          ),
          4 => 
          array (
            'text' => '���ݾƵ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/hangzhou_1201.html?attach=qqlvyou_50_13_0',
          ),
          5 => 
          array (
            'text' => '���ݾƵ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/suzhou_1102.html?attach=qqlvyou_50_13_0',
          ),
          6 => 
          array (
            'text' => '�Ͼ��Ƶ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/nanjing_1101.html?attach=qqlvyou_50_13_0',
          ),
          7 => 
          array (
            'text' => '���žƵ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/xiamen_1401.html?attach=qqlvyou_50_13_0',
          ),
          8 => 
          array (
            'text' => '�ɶ��Ƶ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/chengdu_2301.html?attach=qqlvyou_50_13_0',
          ),
          9 => 
          array (
            'text' => '�����Ƶ�',
            'url' => 'http://buy.go.qq.com/static/hotel/list/xian_2701.html?attach=qqlvyou_50_13_0',
          ),
        ),
      ),
      2 => 
      array (
        'text' => '���Ż�Ʊ',
        'list' => 
        array (
          0 => 
          array (
            'text' => '���ڵ��Ϻ�',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=SZX&to=SHA&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
          1 => 
          array (
            'text' => '���ڵ�����',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=SZX&to=CKG&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
          2 => 
          array (
            'text' => '���ڵ��ɶ�',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=SZX&to=CTU&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
          3 => 
          array (
            'text' => '���ڵ�����',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=SZX&to=PEK&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
          4 => 
          array (
            'text' => '���ݵ��ɶ�',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=CAN&to=CTU&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
          5 => 
          array (
            'text' => '���ݵ��Ϻ�',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=CAN&to=SHA&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
          6 => 
          array (
            'text' => '���ݵ�����',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=CAN&to=HAK&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
          7 => 
          array (
            'text' => '���ݵ�����',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=CAN&to=CKG&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
          8 => 
          array (
            'text' => '�Ϻ�������',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=SHA&to=SZX&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
          9 => 
          array (
            'text' => '���ڵ�����',
            'url' => 'http://buy.go.qq.com/v2/flight/query_jump.html?from=HAK&to=SZX&attach=qqlvyou_50_13_0&qf=wanggou_query',
          ),
        ),
      ),
    ),
    'recommend' => 
    array (
      0 => 
      array (
        'list' => 
        array (
          0 => 
          array (
            'text' => '�������ֺ�̩',
            'url' => 'http://buy.go.qq.com/static/hotel/detail/0010/00101251.html?attach=qqlvyou_50_13_0',
          ),
          1 => 
          array (
            'text' => '�Ϻ�������Ƶ�',
            'url' => 'http://buy.go.qq.com/static/hotel/detail/0020/00201249.html?attach=qqlvyou_50_13_0',
          ),
          2 => 
          array (
            'text' => '���ݰظ߾Ƶ�',
            'url' => 'http://buy.go.qq.com/static/hotel/detail/4200/42001272.html?attach=qqlvyou_50_13_0',
          ),
          3 => 
          array (
            'text' => '����άҲ�ɾƵ�',
            'url' => 'http://buy.go.qq.com/static/hotel/detail/4200/42003056.html?attach=qqlvyou_50_13_0',
          ),
        ),
        'name' => '��ѡ�Ƶ�',
      ),
    ),
  ),
);