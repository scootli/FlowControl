<?php



$_ColorList = array (
  1 => '��ɫ',
  2 => '��ɫ',
  3 => '��ɫ',
  4 => '��ɫ',
  5 => '��ɫ',
  6 => '��ɫ',
  7 => '��ɫ',
  8 => '��ɫ',
  9 => '��ɫ',
  10 => '��ɫ',
  11 => '����ɫ',
  12 => '��ɫ',
  13 => '��ɫ',
  14 => '��ɫ',
  15 => '��ɫ',
  16 => '��ɫ',
  17 => '����ɫ',
  18 => '��ɫ',
  19 => '�ڻ�ɫ',
  20 => '����ɫ',
  21 => '����ɫ',
  22 => '����ɫ',
  23 => '����ɫ',
  24 => '����ɫ',
  25 => '�ױ���',
  26 => '����ɫ',
  35 => '��ɫ',
  36 => '�ۺ�',
  27 => 'ǳ��',
  28 => '�׺�ɫ',
  29 => '���',
  38 => '����',
  39 => '���',
  31 => '�л�',
  41 => '�ϸ�',
  42 => '����ɫ',
  45 => '����ɫ',
  43 => '������',
  44 => '����ɫ',
  55 => '��ɫ�̱�',
  57 => '����ɫ',
  58 => '�׽�Ҷ��',
  48 => 'ˮ����',
  61 => '����ȸ',
  49 => '���Һ�',
  64 => '����ɫ',
  68 => '��ɫ',
  37 => '���',
  30 => '����',
  40 => '�׺ڸ�',
  32 => '�ٱ���',
  34 => '������',
  47 => '��ɫ���',
  59 => '���ʯ',
  63 => '�¹��',
  65 => 'ӯ���',
  66 => '�ſ���',
  67 => '�׻�',
  50 => '�׺�',
  51 => '�̸�',
  52 => '����',
  33 => '����',
  46 => '����',
  56 => '��ɫ�̱�',
  60 => '�ƻò���',
  62 => 'ѩ����',
);


$_PROD_SIZE_1 = array (
  1 => 
  array (
    'SysNo' => 1,
    'Size1ID' => '01',
    'Size1Name' => 'Ь������',
    'Status' => 0,
  ),
  2 => 
  array (
    'SysNo' => 2,
    'Size1ID' => '02',
    'Size1Name' => '��Ь��',
    'Status' => 0,
  ),
  3 => 
  array (
    'SysNo' => 3,
    'Size1ID' => '03',
    'Size1Name' => '������',
    'Status' => 0,
  ),
  4 => 
  array (
    'SysNo' => 4,
    'Size1ID' => '04',
    'Size1Name' => '����Ů',
    'Status' => 0,
  ),
  5 => 
  array (
    'SysNo' => 5,
    'Size1ID' => '05',
    'Size1Name' => '�Ϳ���',
    'Status' => 0,
  ),
  6 => 
  array (
    'SysNo' => 6,
    'Size1ID' => '06',
    'Size1Name' => '�Ϳ�Ů',
    'Status' => 0,
  ),
  7 => 
  array (
    'SysNo' => 7,
    'Size1ID' => '07',
    'Size1Name' => '����',
    'Status' => 0,
  ),
  8 => 
  array (
    'SysNo' => 8,
    'Size1ID' => '08',
    'Size1Name' => '�°�����',
    'Status' => 0,
  ),
  9 => 
  array (
    'SysNo' => 9,
    'Size1ID' => '09',
    'Size1Name' => '�°���Ů',
    'Status' => 0,
  ),
  10 => 
  array (
    'SysNo' => 10,
    'Size1ID' => '10',
    'Size1Name' => '����1',
    'Status' => 0,
  ),
  11 => 
  array (
    'SysNo' => 11,
    'Size1ID' => '11',
    'Size1Name' => '����2',
    'Status' => 0,
  ),
  12 => 
  array (
    'SysNo' => 12,
    'Size1ID' => '12',
    'Size1Name' => '��������',
    'Status' => 0,
  ),
  13 => 
  array (
    'SysNo' => 13,
    'Size1ID' => '13',
    'Size1Name' => 'Esprit ��װ�����',
    'Status' => 0,
  ),
  14 => 
  array (
    'SysNo' => 14,
    'Size1ID' => '14',
    'Size1Name' => 'Esprit ��װ�����',
    'Status' => 0,
  ),
  15 => 
  array (
    'SysNo' => 15,
    'Size1ID' => '15',
    'Size1Name' => '����������',
    'Status' => 0,
  ),
  16 => 
  array (
    'SysNo' => 16,
    'Size1ID' => '16',
    'Size1Name' => '����������',
    'Status' => 0,
  ),
  17 => 
  array (
    'SysNo' => 17,
    'Size1ID' => '1',
    'Size1Name' => 'Ӿ��',
    'Status' => 0,
  ),
  19 => 
  array (
    'SysNo' => 19,
    'Size1ID' => '18',
    'Size1Name' => 'cartelo ��װ����',
    'Status' => 0,
  ),
  20 => 
  array (
    'SysNo' => 20,
    'Size1ID' => '19',
    'Size1Name' => 'Ƥ������',
    'Status' => 0,
  ),
  21 => 
  array (
    'SysNo' => 21,
    'Size1ID' => '20',
    'Size1Name' => '�ܿ���˹����',
    'Status' => 0,
  ),
  22 => 
  array (
    'SysNo' => 22,
    'Size1ID' => '21',
    'Size1Name' => 'tongjeans����',
    'Status' => 0,
  ),
  23 => 
  array (
    'SysNo' => 23,
    'Size1ID' => '22',
    'Size1Name' => '��ͯ����',
    'Status' => 0,
  ),
  24 => 
  array (
    'SysNo' => 24,
    'Size1ID' => '23',
    'Size1Name' => '��ͯ����',
    'Status' => 0,
  ),
  25 => 
  array (
    'SysNo' => 25,
    'Size1ID' => '25',
    'Size1Name' => '������',
    'Status' => 0,
  ),
  292 => 
  array (
    'SysNo' => 292,
    'Size1ID' => '26',
    'Size1Name' => '���ӻ�',
    'Status' => 0,
  ),
);


$_PROD_SIZE_2 = array (
  3 => 
  array (
    'SysNo' => 3,
    'Size1SysNo' => 1,
    'Size2ID' => '01',
    'Size2Name' => '35��',
    'Status' => 0,
  ),
  4 => 
  array (
    'SysNo' => 4,
    'Size1SysNo' => 1,
    'Size2ID' => '02',
    'Size2Name' => '35.5��',
    'Status' => 0,
  ),
  5 => 
  array (
    'SysNo' => 5,
    'Size1SysNo' => 1,
    'Size2ID' => '03',
    'Size2Name' => '36��',
    'Status' => 0,
  ),
  6 => 
  array (
    'SysNo' => 6,
    'Size1SysNo' => 1,
    'Size2ID' => '04',
    'Size2Name' => '36.5��',
    'Status' => 0,
  ),
  7 => 
  array (
    'SysNo' => 7,
    'Size1SysNo' => 1,
    'Size2ID' => '05',
    'Size2Name' => '37��',
    'Status' => 0,
  ),
  8 => 
  array (
    'SysNo' => 8,
    'Size1SysNo' => 1,
    'Size2ID' => '06',
    'Size2Name' => '37.5��',
    'Status' => 0,
  ),
  9 => 
  array (
    'SysNo' => 9,
    'Size1SysNo' => 1,
    'Size2ID' => '07',
    'Size2Name' => '38��',
    'Status' => 0,
  ),
  10 => 
  array (
    'SysNo' => 10,
    'Size1SysNo' => 1,
    'Size2ID' => '08',
    'Size2Name' => '38.5��',
    'Status' => 0,
  ),
  11 => 
  array (
    'SysNo' => 11,
    'Size1SysNo' => 1,
    'Size2ID' => '09',
    'Size2Name' => '39��',
    'Status' => 0,
  ),
  12 => 
  array (
    'SysNo' => 12,
    'Size1SysNo' => 1,
    'Size2ID' => '10',
    'Size2Name' => '39.5��',
    'Status' => 0,
  ),
  13 => 
  array (
    'SysNo' => 13,
    'Size1SysNo' => 1,
    'Size2ID' => '11',
    'Size2Name' => '40��',
    'Status' => 0,
  ),
  14 => 
  array (
    'SysNo' => 14,
    'Size1SysNo' => 1,
    'Size2ID' => '12',
    'Size2Name' => '40.5��',
    'Status' => 0,
  ),
  15 => 
  array (
    'SysNo' => 15,
    'Size1SysNo' => 1,
    'Size2ID' => '13',
    'Size2Name' => '41��',
    'Status' => 0,
  ),
  16 => 
  array (
    'SysNo' => 16,
    'Size1SysNo' => 1,
    'Size2ID' => '14',
    'Size2Name' => '41.5��',
    'Status' => 0,
  ),
  17 => 
  array (
    'SysNo' => 17,
    'Size1SysNo' => 1,
    'Size2ID' => '15',
    'Size2Name' => '42��',
    'Status' => 0,
  ),
  18 => 
  array (
    'SysNo' => 18,
    'Size1SysNo' => 1,
    'Size2ID' => '16',
    'Size2Name' => '42.5��',
    'Status' => 0,
  ),
  19 => 
  array (
    'SysNo' => 19,
    'Size1SysNo' => 1,
    'Size2ID' => '17',
    'Size2Name' => '43��',
    'Status' => 0,
  ),
  20 => 
  array (
    'SysNo' => 20,
    'Size1SysNo' => 1,
    'Size2ID' => '18',
    'Size2Name' => '43.5��',
    'Status' => 0,
  ),
  21 => 
  array (
    'SysNo' => 21,
    'Size1SysNo' => 1,
    'Size2ID' => '19',
    'Size2Name' => '44��',
    'Status' => 0,
  ),
  22 => 
  array (
    'SysNo' => 22,
    'Size1SysNo' => 2,
    'Size2ID' => '51',
    'Size2Name' => '36/37��',
    'Status' => 0,
  ),
  23 => 
  array (
    'SysNo' => 23,
    'Size1SysNo' => 2,
    'Size2ID' => '52',
    'Size2Name' => '37/38��',
    'Status' => 0,
  ),
  24 => 
  array (
    'SysNo' => 24,
    'Size1SysNo' => 2,
    'Size2ID' => '53',
    'Size2Name' => '38/39��',
    'Status' => 0,
  ),
  25 => 
  array (
    'SysNo' => 25,
    'Size1SysNo' => 2,
    'Size2ID' => '54',
    'Size2Name' => '39/40��',
    'Status' => 0,
  ),
  26 => 
  array (
    'SysNo' => 26,
    'Size1SysNo' => 2,
    'Size2ID' => '55',
    'Size2Name' => '40/41��',
    'Status' => 0,
  ),
  27 => 
  array (
    'SysNo' => 27,
    'Size1SysNo' => 2,
    'Size2ID' => '56',
    'Size2Name' => '41/42��',
    'Status' => 0,
  ),
  28 => 
  array (
    'SysNo' => 28,
    'Size1SysNo' => 2,
    'Size2ID' => '57',
    'Size2Name' => '42/43��',
    'Status' => 0,
  ),
  29 => 
  array (
    'SysNo' => 29,
    'Size1SysNo' => 2,
    'Size2ID' => '58',
    'Size2Name' => '43/44��',
    'Status' => 0,
  ),
  30 => 
  array (
    'SysNo' => 30,
    'Size1SysNo' => 2,
    'Size2ID' => '59',
    'Size2Name' => '44/45��',
    'Status' => 0,
  ),
  31 => 
  array (
    'SysNo' => 31,
    'Size1SysNo' => 2,
    'Size2ID' => '60',
    'Size2Name' => '45/46��',
    'Status' => 0,
  ),
  32 => 
  array (
    'SysNo' => 32,
    'Size1SysNo' => 2,
    'Size2ID' => '61',
    'Size2Name' => '35/36��',
    'Status' => 0,
  ),
  33 => 
  array (
    'SysNo' => 33,
    'Size1SysNo' => 1,
    'Size2ID' => '00',
    'Size2Name' => '34��',
    'Status' => 0,
  ),
  34 => 
  array (
    'SysNo' => 34,
    'Size1SysNo' => 1,
    'Size2ID' => '21',
    'Size2Name' => '34.5��',
    'Status' => 0,
  ),
  35 => 
  array (
    'SysNo' => 35,
    'Size1SysNo' => 1,
    'Size2ID' => '22',
    'Size2Name' => '44.5��',
    'Status' => 0,
  ),
  36 => 
  array (
    'SysNo' => 36,
    'Size1SysNo' => 1,
    'Size2ID' => '23',
    'Size2Name' => '45��',
    'Status' => 0,
  ),
  37 => 
  array (
    'SysNo' => 37,
    'Size1SysNo' => 3,
    'Size2ID' => '101',
    'Size2Name' => '38 2/3��/UK5.5',
    'Status' => 0,
  ),
  38 => 
  array (
    'SysNo' => 38,
    'Size1SysNo' => 3,
    'Size2ID' => '102',
    'Size2Name' => '39 1/3��/UK6',
    'Status' => 0,
  ),
  39 => 
  array (
    'SysNo' => 39,
    'Size1SysNo' => 3,
    'Size2ID' => '103',
    'Size2Name' => '40��/UK6.5',
    'Status' => 0,
  ),
  40 => 
  array (
    'SysNo' => 40,
    'Size1SysNo' => 3,
    'Size2ID' => '104',
    'Size2Name' => '40 2/3��/UK7',
    'Status' => 0,
  ),
  41 => 
  array (
    'SysNo' => 41,
    'Size1SysNo' => 3,
    'Size2ID' => '105',
    'Size2Name' => '41 1/3��/UK7.5',
    'Status' => 0,
  ),
  42 => 
  array (
    'SysNo' => 42,
    'Size1SysNo' => 3,
    'Size2ID' => '106',
    'Size2Name' => '42��/UK8',
    'Status' => 0,
  ),
  43 => 
  array (
    'SysNo' => 43,
    'Size1SysNo' => 3,
    'Size2ID' => '107',
    'Size2Name' => '42 2/3��/UK8.5',
    'Status' => 0,
  ),
  44 => 
  array (
    'SysNo' => 44,
    'Size1SysNo' => 3,
    'Size2ID' => '108',
    'Size2Name' => '43 1/3��/UK9',
    'Status' => 0,
  ),
  45 => 
  array (
    'SysNo' => 45,
    'Size1SysNo' => 3,
    'Size2ID' => '109',
    'Size2Name' => '44��/UK9.5',
    'Status' => 0,
  ),
  46 => 
  array (
    'SysNo' => 46,
    'Size1SysNo' => 3,
    'Size2ID' => '110',
    'Size2Name' => '44 2/3��/UK10',
    'Status' => 0,
  ),
  47 => 
  array (
    'SysNo' => 47,
    'Size1SysNo' => 3,
    'Size2ID' => '111',
    'Size2Name' => '45 1/3��/UK10.5',
    'Status' => 0,
  ),
  48 => 
  array (
    'SysNo' => 48,
    'Size1SysNo' => 3,
    'Size2ID' => '112',
    'Size2Name' => '46��/UK11',
    'Status' => 0,
  ),
  49 => 
  array (
    'SysNo' => 49,
    'Size1SysNo' => 5,
    'Size2ID' => '201',
    'Size2Name' => '38.5��/US6',
    'Status' => 0,
  ),
  50 => 
  array (
    'SysNo' => 50,
    'Size1SysNo' => 5,
    'Size2ID' => '202',
    'Size2Name' => '39��/US6.5',
    'Status' => 0,
  ),
  51 => 
  array (
    'SysNo' => 51,
    'Size1SysNo' => 5,
    'Size2ID' => '203',
    'Size2Name' => '40��/US7',
    'Status' => 0,
  ),
  52 => 
  array (
    'SysNo' => 52,
    'Size1SysNo' => 5,
    'Size2ID' => '204',
    'Size2Name' => '40.5��/US7.5',
    'Status' => 0,
  ),
  53 => 
  array (
    'SysNo' => 53,
    'Size1SysNo' => 5,
    'Size2ID' => '205',
    'Size2Name' => '41��/US8',
    'Status' => 0,
  ),
  54 => 
  array (
    'SysNo' => 54,
    'Size1SysNo' => 5,
    'Size2ID' => '206',
    'Size2Name' => '42��/US8.5',
    'Status' => 0,
  ),
  55 => 
  array (
    'SysNo' => 55,
    'Size1SysNo' => 5,
    'Size2ID' => '207',
    'Size2Name' => '42.5��/US9',
    'Status' => 0,
  ),
  56 => 
  array (
    'SysNo' => 56,
    'Size1SysNo' => 5,
    'Size2ID' => '208',
    'Size2Name' => '43��/US9.5',
    'Status' => 0,
  ),
  57 => 
  array (
    'SysNo' => 57,
    'Size1SysNo' => 5,
    'Size2ID' => '209',
    'Size2Name' => '44��/US10',
    'Status' => 0,
  ),
  58 => 
  array (
    'SysNo' => 58,
    'Size1SysNo' => 5,
    'Size2ID' => '210',
    'Size2Name' => '44.5��/US10.5',
    'Status' => 0,
  ),
  59 => 
  array (
    'SysNo' => 59,
    'Size1SysNo' => 5,
    'Size2ID' => '211',
    'Size2Name' => '45��/US11',
    'Status' => 0,
  ),
  60 => 
  array (
    'SysNo' => 60,
    'Size1SysNo' => 5,
    'Size2ID' => '212',
    'Size2Name' => '45.5��/US11.5',
    'Status' => 0,
  ),
  61 => 
  array (
    'SysNo' => 61,
    'Size1SysNo' => 5,
    'Size2ID' => '213',
    'Size2Name' => '46��/US12',
    'Status' => 0,
  ),
  62 => 
  array (
    'SysNo' => 62,
    'Size1SysNo' => 5,
    'Size2ID' => '214',
    'Size2Name' => '47��/US12.5',
    'Status' => 0,
  ),
  63 => 
  array (
    'SysNo' => 63,
    'Size1SysNo' => 5,
    'Size2ID' => '215',
    'Size2Name' => '47.5��/US13',
    'Status' => 0,
  ),
  64 => 
  array (
    'SysNo' => 64,
    'Size1SysNo' => 6,
    'Size2ID' => '231',
    'Size2Name' => '35��/US4.5',
    'Status' => 0,
  ),
  65 => 
  array (
    'SysNo' => 65,
    'Size1SysNo' => 6,
    'Size2ID' => '232',
    'Size2Name' => '35.5��/US5',
    'Status' => 0,
  ),
  66 => 
  array (
    'SysNo' => 66,
    'Size1SysNo' => 6,
    'Size2ID' => '233',
    'Size2Name' => '36��/US5.5',
    'Status' => 0,
  ),
  67 => 
  array (
    'SysNo' => 67,
    'Size1SysNo' => 6,
    'Size2ID' => '234',
    'Size2Name' => '36.5��/US6',
    'Status' => 0,
  ),
  68 => 
  array (
    'SysNo' => 68,
    'Size1SysNo' => 6,
    'Size2ID' => '235',
    'Size2Name' => '37.5��/US6.5',
    'Status' => 0,
  ),
  69 => 
  array (
    'SysNo' => 69,
    'Size1SysNo' => 6,
    'Size2ID' => '236',
    'Size2Name' => '38��/US7',
    'Status' => 0,
  ),
  70 => 
  array (
    'SysNo' => 70,
    'Size1SysNo' => 6,
    'Size2ID' => '237',
    'Size2Name' => '38.5��/US7.5',
    'Status' => 0,
  ),
  71 => 
  array (
    'SysNo' => 71,
    'Size1SysNo' => 6,
    'Size2ID' => '238',
    'Size2Name' => '39��/US8',
    'Status' => 0,
  ),
  72 => 
  array (
    'SysNo' => 72,
    'Size1SysNo' => 6,
    'Size2ID' => '239',
    'Size2Name' => '40��/US8.5',
    'Status' => 0,
  ),
  73 => 
  array (
    'SysNo' => 73,
    'Size1SysNo' => 6,
    'Size2ID' => '240',
    'Size2Name' => '40.5��/US9',
    'Status' => 0,
  ),
  74 => 
  array (
    'SysNo' => 74,
    'Size1SysNo' => 6,
    'Size2ID' => '241',
    'Size2Name' => '41��/US9.5',
    'Status' => 0,
  ),
  75 => 
  array (
    'SysNo' => 75,
    'Size1SysNo' => 6,
    'Size2ID' => '242',
    'Size2Name' => '42��/US10',
    'Status' => 0,
  ),
  76 => 
  array (
    'SysNo' => 76,
    'Size1SysNo' => 6,
    'Size2ID' => '243',
    'Size2Name' => '42.5��/US10.5',
    'Status' => 0,
  ),
  77 => 
  array (
    'SysNo' => 77,
    'Size1SysNo' => 6,
    'Size2ID' => '244',
    'Size2Name' => '43��/US11',
    'Status' => 0,
  ),
  78 => 
  array (
    'SysNo' => 78,
    'Size1SysNo' => 6,
    'Size2ID' => '245',
    'Size2Name' => '44��/US11.5',
    'Status' => 0,
  ),
  79 => 
  array (
    'SysNo' => 79,
    'Size1SysNo' => 6,
    'Size2ID' => '246',
    'Size2Name' => '44.5��/US12',
    'Status' => 0,
  ),
  80 => 
  array (
    'SysNo' => 80,
    'Size1SysNo' => 6,
    'Size2ID' => '247',
    'Size2Name' => '45.5��/US13',
    'Status' => 0,
  ),
  81 => 
  array (
    'SysNo' => 81,
    'Size1SysNo' => 6,
    'Size2ID' => '248',
    'Size2Name' => '46��/US13.5',
    'Status' => 0,
  ),
  82 => 
  array (
    'SysNo' => 82,
    'Size1SysNo' => 4,
    'Size2ID' => '131',
    'Size2Name' => '36��/UK3.5',
    'Status' => 0,
  ),
  83 => 
  array (
    'SysNo' => 83,
    'Size1SysNo' => 4,
    'Size2ID' => '132',
    'Size2Name' => '36 2/3��/UK4',
    'Status' => 0,
  ),
  84 => 
  array (
    'SysNo' => 84,
    'Size1SysNo' => 4,
    'Size2ID' => '133',
    'Size2Name' => '37 1/3��/UK4.5',
    'Status' => 0,
  ),
  85 => 
  array (
    'SysNo' => 85,
    'Size1SysNo' => 4,
    'Size2ID' => '134',
    'Size2Name' => '38��/UK5',
    'Status' => 0,
  ),
  86 => 
  array (
    'SysNo' => 86,
    'Size1SysNo' => 4,
    'Size2ID' => '135',
    'Size2Name' => '38 2/3��/UK5.5',
    'Status' => 0,
  ),
  261 => 
  array (
    'SysNo' => 261,
    'Size1SysNo' => 8,
    'Size2ID' => '100',
    'Size2Name' => '39.5��/US6.5',
    'Status' => 0,
  ),
  262 => 
  array (
    'SysNo' => 262,
    'Size1SysNo' => 2,
    'Size2ID' => '162',
    'Size2Name' => 'M4',
    'Status' => 0,
  ),
  263 => 
  array (
    'SysNo' => 263,
    'Size1SysNo' => 2,
    'Size2ID' => '163',
    'Size2Name' => 'M5',
    'Status' => 0,
  ),
  269 => 
  array (
    'SysNo' => 269,
    'Size1SysNo' => 2,
    'Size2ID' => '169',
    'Size2Name' => 'M11',
    'Status' => 0,
  ),
  270 => 
  array (
    'SysNo' => 270,
    'Size1SysNo' => 2,
    'Size2ID' => '170',
    'Size2Name' => 'M12',
    'Status' => 0,
  ),
  293 => 
  array (
    'SysNo' => 293,
    'Size1SysNo' => 12,
    'Size2ID' => '1209',
    'Size2Name' => '175/100',
    'Status' => 0,
  ),
  264 => 
  array (
    'SysNo' => 264,
    'Size1SysNo' => 2,
    'Size2ID' => '164',
    'Size2Name' => 'M6',
    'Status' => 0,
  ),
  267 => 
  array (
    'SysNo' => 267,
    'Size1SysNo' => 2,
    'Size2ID' => '167',
    'Size2Name' => 'M9',
    'Status' => 0,
  ),
  271 => 
  array (
    'SysNo' => 271,
    'Size1SysNo' => 2,
    'Size2ID' => '171',
    'Size2Name' => 'M13',
    'Status' => 0,
  ),
  294 => 
  array (
    'SysNo' => 294,
    'Size1SysNo' => 12,
    'Size2ID' => '1210',
    'Size2Name' => '180/105',
    'Status' => 0,
  ),
  312 => 
  array (
    'SysNo' => 312,
    'Size1SysNo' => 12,
    'Size2ID' => '1211',
    'Size2Name' => '185/110',
    'Status' => 0,
  ),
  295 => 
  array (
    'SysNo' => 295,
    'Size1SysNo' => 12,
    'Size2ID' => '1212',
    'Size2Name' => '170/95',
    'Status' => 0,
  ),
  177 => 
  array (
    'SysNo' => 177,
    'Size1SysNo' => 22,
    'Size2ID' => '50',
    'Size2Name' => '180/86A',
    'Status' => 0,
  ),
  178 => 
  array (
    'SysNo' => 178,
    'Size1SysNo' => 22,
    'Size2ID' => '62',
    'Size2Name' => '180/90B',
    'Status' => 0,
  ),
  179 => 
  array (
    'SysNo' => 179,
    'Size1SysNo' => 22,
    'Size2ID' => '63',
    'Size2Name' => '180/82A',
    'Status' => 0,
  ),
  180 => 
  array (
    'SysNo' => 180,
    'Size1SysNo' => 22,
    'Size2ID' => '64',
    'Size2Name' => '185/90A',
    'Status' => 0,
  ),
  181 => 
  array (
    'SysNo' => 181,
    'Size1SysNo' => 21,
    'Size2ID' => '68',
    'Size2Name' => '185/88A',
    'Status' => 0,
  ),
  182 => 
  array (
    'SysNo' => 182,
    'Size1SysNo' => 22,
    'Size2ID' => '65',
    'Size2Name' => '185/94B',
    'Status' => 0,
  ),
  183 => 
  array (
    'SysNo' => 183,
    'Size1SysNo' => 20,
    'Size2ID' => '66',
    'Size2Name' => '115cm����',
    'Status' => 0,
  ),
  184 => 
  array (
    'SysNo' => 184,
    'Size1SysNo' => 1,
    'Size2ID' => '24',
    'Size2Name' => '45.5��',
    'Status' => 0,
  ),
  185 => 
  array (
    'SysNo' => 185,
    'Size1SysNo' => 22,
    'Size2ID' => '666',
    'Size2Name' => '70',
    'Status' => 0,
  ),
  186 => 
  array (
    'SysNo' => 186,
    'Size1SysNo' => 22,
    'Size2ID' => '667',
    'Size2Name' => '74',
    'Status' => 0,
  ),
  187 => 
  array (
    'SysNo' => 187,
    'Size1SysNo' => 22,
    'Size2ID' => '668',
    'Size2Name' => '78',
    'Status' => 0,
  ),
  188 => 
  array (
    'SysNo' => 188,
    'Size1SysNo' => 22,
    'Size2ID' => '669',
    'Size2Name' => '82',
    'Status' => 0,
  ),
  189 => 
  array (
    'SysNo' => 189,
    'Size1SysNo' => 22,
    'Size2ID' => '670',
    'Size2Name' => '86',
    'Status' => 0,
  ),
  190 => 
  array (
    'SysNo' => 190,
    'Size1SysNo' => 22,
    'Size2ID' => '671',
    'Size2Name' => '90',
    'Status' => 0,
  ),
  191 => 
  array (
    'SysNo' => 191,
    'Size1SysNo' => 22,
    'Size2ID' => '672',
    'Size2Name' => '94',
    'Status' => 0,
  ),
  192 => 
  array (
    'SysNo' => 192,
    'Size1SysNo' => 22,
    'Size2ID' => '700',
    'Size2Name' => '����',
    'Status' => 0,
  ),
  193 => 
  array (
    'SysNo' => 193,
    'Size1SysNo' => 15,
    'Size2ID' => '1509',
    'Size2Name' => '36��',
    'Status' => 0,
  ),
  194 => 
  array (
    'SysNo' => 194,
    'Size1SysNo' => 15,
    'Size2ID' => '999',
    'Size2Name' => '35��',
    'Status' => 0,
  ),
  195 => 
  array (
    'SysNo' => 195,
    'Size1SysNo' => 14,
    'Size2ID' => '1407',
    'Size2Name' => '170/88A',
    'Status' => 0,
  ),
  196 => 
  array (
    'SysNo' => 196,
    'Size1SysNo' => 14,
    'Size2ID' => '1408',
    'Size2Name' => '170/92A',
    'Status' => 0,
  ),
  197 => 
  array (
    'SysNo' => 197,
    'Size1SysNo' => 14,
    'Size2ID' => '1409',
    'Size2Name' => '175/92A',
    'Status' => 0,
  ),
  198 => 
  array (
    'SysNo' => 198,
    'Size1SysNo' => 14,
    'Size2ID' => '1410',
    'Size2Name' => '180/100A',
    'Status' => 0,
  ),
  199 => 
  array (
    'SysNo' => 199,
    'Size1SysNo' => 14,
    'Size2ID' => '1411',
    'Size2Name' => '185/100A',
    'Status' => 0,
  ),
  200 => 
  array (
    'SysNo' => 200,
    'Size1SysNo' => 14,
    'Size2ID' => '1412',
    'Size2Name' => '185/104A',
    'Status' => 0,
  ),
  201 => 
  array (
    'SysNo' => 201,
    'Size1SysNo' => 14,
    'Size2ID' => '1413',
    'Size2Name' => '160/84A',
    'Status' => 0,
  ),
  202 => 
  array (
    'SysNo' => 202,
    'Size1SysNo' => 14,
    'Size2ID' => '1414',
    'Size2Name' => '165/84A',
    'Status' => 0,
  ),
  203 => 
  array (
    'SysNo' => 203,
    'Size1SysNo' => 15,
    'Size2ID' => '1510',
    'Size2Name' => '24��',
    'Status' => 0,
  ),
  204 => 
  array (
    'SysNo' => 204,
    'Size1SysNo' => 15,
    'Size2ID' => '1511',
    'Size2Name' => '25��',
    'Status' => 0,
  ),
  205 => 
  array (
    'SysNo' => 205,
    'Size1SysNo' => 15,
    'Size2ID' => '1512',
    'Size2Name' => '26��',
    'Status' => 0,
  ),
  206 => 
  array (
    'SysNo' => 206,
    'Size1SysNo' => 15,
    'Size2ID' => '1513',
    'Size2Name' => '36��',
    'Status' => 0,
  ),
  207 => 
  array (
    'SysNo' => 207,
    'Size1SysNo' => 15,
    'Size2ID' => '1514',
    'Size2Name' => '38��',
    'Status' => 0,
  ),
  208 => 
  array (
    'SysNo' => 208,
    'Size1SysNo' => 15,
    'Size2ID' => '1515',
    'Size2Name' => '35��',
    'Status' => 0,
  ),
  209 => 
  array (
    'SysNo' => 209,
    'Size1SysNo' => 15,
    'Size2ID' => '1516',
    'Size2Name' => '37��',
    'Status' => 0,
  ),
  210 => 
  array (
    'SysNo' => 210,
    'Size1SysNo' => 15,
    'Size2ID' => '1517',
    'Size2Name' => '39��',
    'Status' => 0,
  ),
  211 => 
  array (
    'SysNo' => 211,
    'Size1SysNo' => 15,
    'Size2ID' => '1518',
    'Size2Name' => '40��',
    'Status' => 0,
  ),
  212 => 
  array (
    'SysNo' => 212,
    'Size1SysNo' => 15,
    'Size2ID' => '1519',
    'Size2Name' => '42��',
    'Status' => 0,
  ),
  213 => 
  array (
    'SysNo' => 213,
    'Size1SysNo' => 14,
    'Size2ID' => '1415',
    'Size2Name' => '190/104A',
    'Status' => 0,
  ),
  214 => 
  array (
    'SysNo' => 214,
    'Size1SysNo' => 23,
    'Size2ID' => '1',
    'Size2Name' => '110',
    'Status' => 0,
  ),
  215 => 
  array (
    'SysNo' => 215,
    'Size1SysNo' => 24,
    'Size2ID' => '0101',
    'Size2Name' => '110',
    'Status' => 0,
  ),
  216 => 
  array (
    'SysNo' => 216,
    'Size1SysNo' => 24,
    'Size2ID' => '0102',
    'Size2Name' => '120',
    'Status' => 0,
  ),
  217 => 
  array (
    'SysNo' => 217,
    'Size1SysNo' => 24,
    'Size2ID' => '0103',
    'Size2Name' => '130',
    'Status' => 0,
  ),
  218 => 
  array (
    'SysNo' => 218,
    'Size1SysNo' => 24,
    'Size2ID' => '0104',
    'Size2Name' => '140',
    'Status' => 0,
  ),
  219 => 
  array (
    'SysNo' => 219,
    'Size1SysNo' => 24,
    'Size2ID' => '0105',
    'Size2Name' => '150',
    'Status' => 0,
  ),
  220 => 
  array (
    'SysNo' => 220,
    'Size1SysNo' => 25,
    'Size2ID' => '2501',
    'Size2Name' => '12��',
    'Status' => 0,
  ),
  221 => 
  array (
    'SysNo' => 221,
    'Size1SysNo' => 25,
    'Size2ID' => '2502',
    'Size2Name' => '13��',
    'Status' => 0,
  ),
  222 => 
  array (
    'SysNo' => 222,
    'Size1SysNo' => 25,
    'Size2ID' => '2503',
    'Size2Name' => '14��',
    'Status' => 0,
  ),
  223 => 
  array (
    'SysNo' => 223,
    'Size1SysNo' => 25,
    'Size2ID' => '2504',
    'Size2Name' => '15��',
    'Status' => 0,
  ),
  224 => 
  array (
    'SysNo' => 224,
    'Size1SysNo' => 25,
    'Size2ID' => '2505',
    'Size2Name' => '16��',
    'Status' => 0,
  ),
  225 => 
  array (
    'SysNo' => 225,
    'Size1SysNo' => 25,
    'Size2ID' => '2506',
    'Size2Name' => '17��',
    'Status' => 0,
  ),
  226 => 
  array (
    'SysNo' => 226,
    'Size1SysNo' => 25,
    'Size2ID' => '2507',
    'Size2Name' => '18��',
    'Status' => 0,
  ),
  227 => 
  array (
    'SysNo' => 227,
    'Size1SysNo' => 25,
    'Size2ID' => '2508',
    'Size2Name' => '19��',
    'Status' => 0,
  ),
  228 => 
  array (
    'SysNo' => 228,
    'Size1SysNo' => 25,
    'Size2ID' => '2509',
    'Size2Name' => '20��',
    'Status' => 0,
  ),
  229 => 
  array (
    'SysNo' => 229,
    'Size1SysNo' => 25,
    'Size2ID' => '2510',
    'Size2Name' => '21��',
    'Status' => 0,
  ),
  230 => 
  array (
    'SysNo' => 230,
    'Size1SysNo' => 25,
    'Size2ID' => '2511',
    'Size2Name' => '22��',
    'Status' => 0,
  ),
  231 => 
  array (
    'SysNo' => 231,
    'Size1SysNo' => 25,
    'Size2ID' => '2512',
    'Size2Name' => '23��',
    'Status' => 0,
  ),
  232 => 
  array (
    'SysNo' => 232,
    'Size1SysNo' => 25,
    'Size2ID' => '2513',
    'Size2Name' => '24��',
    'Status' => 0,
  ),
  233 => 
  array (
    'SysNo' => 233,
    'Size1SysNo' => 25,
    'Size2ID' => '2514',
    'Size2Name' => '26��',
    'Status' => 0,
  ),
  234 => 
  array (
    'SysNo' => 234,
    'Size1SysNo' => 25,
    'Size2ID' => '2515',
    'Size2Name' => '28��',
    'Status' => 0,
  ),
  235 => 
  array (
    'SysNo' => 235,
    'Size1SysNo' => 25,
    'Size2ID' => '2516',
    'Size2Name' => '���ŷ���',
    'Status' => 0,
  ),
  236 => 
  array (
    'SysNo' => 236,
    'Size1SysNo' => 25,
    'Size2ID' => '2517',
    'Size2Name' => '��������',
    'Status' => 0,
  ),
  237 => 
  array (
    'SysNo' => 237,
    'Size1SysNo' => 25,
    'Size2ID' => '2518',
    'Size2Name' => '24"+19"',
    'Status' => 0,
  ),
  238 => 
  array (
    'SysNo' => 238,
    'Size1SysNo' => 25,
    'Size2ID' => '2519',
    'Size2Name' => '28"+26"',
    'Status' => 0,
  ),
  239 => 
  array (
    'SysNo' => 239,
    'Size1SysNo' => 25,
    'Size2ID' => '2520',
    'Size2Name' => '26"+16"',
    'Status' => 0,
  ),
  240 => 
  array (
    'SysNo' => 240,
    'Size1SysNo' => 25,
    'Size2ID' => '2521',
    'Size2Name' => '24"+23"',
    'Status' => 0,
  ),
  241 => 
  array (
    'SysNo' => 241,
    'Size1SysNo' => 25,
    'Size2ID' => '2522',
    'Size2Name' => '26"+19"',
    'Status' => 0,
  ),
  242 => 
  array (
    'SysNo' => 242,
    'Size1SysNo' => 25,
    'Size2ID' => '2523',
    'Size2Name' => '28"+28"',
    'Status' => 0,
  ),
  243 => 
  array (
    'SysNo' => 243,
    'Size1SysNo' => 25,
    'Size2ID' => '2524',
    'Size2Name' => '21"+19"',
    'Status' => 0,
  ),
  244 => 
  array (
    'SysNo' => 244,
    'Size1SysNo' => 25,
    'Size2ID' => '2525',
    'Size2Name' => '22"+16"',
    'Status' => 0,
  ),
  245 => 
  array (
    'SysNo' => 245,
    'Size1SysNo' => 25,
    'Size2ID' => '2526',
    'Size2Name' => '26"+26"',
    'Status' => 0,
  ),
  246 => 
  array (
    'SysNo' => 246,
    'Size1SysNo' => 25,
    'Size2ID' => '2527',
    'Size2Name' => '26"+15"',
    'Status' => 0,
  ),
  247 => 
  array (
    'SysNo' => 247,
    'Size1SysNo' => 25,
    'Size2ID' => '2528',
    'Size2Name' => '22"+22"',
    'Status' => 0,
  ),
  248 => 
  array (
    'SysNo' => 248,
    'Size1SysNo' => 25,
    'Size2ID' => '2529',
    'Size2Name' => 'ר��ר��',
    'Status' => 0,
  ),
  249 => 
  array (
    'SysNo' => 249,
    'Size1SysNo' => 25,
    'Size2ID' => '2530',
    'Size2Name' => 'ͨ����',
    'Status' => 0,
  ),
  250 => 
  array (
    'SysNo' => 250,
    'Size1SysNo' => 25,
    'Size2ID' => '2531',
    'Size2Name' => 'Сǯ',
    'Status' => 0,
  ),
  251 => 
  array (
    'SysNo' => 251,
    'Size1SysNo' => 25,
    'Size2ID' => '2532',
    'Size2Name' => '��ǯ',
    'Status' => 0,
  ),
  252 => 
  array (
    'SysNo' => 252,
    'Size1SysNo' => 15,
    'Size2ID' => '1520',
    'Size2Name' => '38��',
    'Status' => 0,
  ),
  253 => 
  array (
    'SysNo' => 253,
    'Size1SysNo' => 25,
    'Size2ID' => '2533',
    'Size2Name' => '�����з���',
    'Status' => 0,
  ),
  254 => 
  array (
    'SysNo' => 254,
    'Size1SysNo' => 25,
    'Size2ID' => '2534',
    'Size2Name' => '�����޷���',
    'Status' => 0,
  ),
  255 => 
  array (
    'SysNo' => 255,
    'Size1SysNo' => 25,
    'Size2ID' => '2535',
    'Size2Name' => 'DXL58A',
    'Status' => 0,
  ),
  256 => 
  array (
    'SysNo' => 256,
    'Size1SysNo' => 25,
    'Size2ID' => '2536',
    'Size2Name' => 'DXL50A',
    'Status' => 0,
  ),
  257 => 
  array (
    'SysNo' => 257,
    'Size1SysNo' => 25,
    'Size2ID' => '2537',
    'Size2Name' => 'DXL40',
    'Status' => 0,
  ),
  258 => 
  array (
    'SysNo' => 258,
    'Size1SysNo' => 25,
    'Size2ID' => '2538',
    'Size2Name' => 'DXR65',
    'Status' => 0,
  ),
  259 => 
  array (
    'SysNo' => 259,
    'Size1SysNo' => 25,
    'Size2ID' => '2539',
    'Size2Name' => 'DXL70',
    'Status' => 0,
  ),
  260 => 
  array (
    'SysNo' => 260,
    'Size1SysNo' => 12,
    'Size2ID' => '1208',
    'Size2Name' => 'XXS',
    'Status' => 0,
  ),
  87 => 
  array (
    'SysNo' => 87,
    'Size1SysNo' => 4,
    'Size2ID' => '136',
    'Size2Name' => '39 1/3��/UK6',
    'Status' => 0,
  ),
  88 => 
  array (
    'SysNo' => 88,
    'Size1SysNo' => 4,
    'Size2ID' => '137',
    'Size2Name' => '40��/UK6.5',
    'Status' => 0,
  ),
  89 => 
  array (
    'SysNo' => 89,
    'Size1SysNo' => 4,
    'Size2ID' => '138',
    'Size2Name' => '40 2/3��/UK7',
    'Status' => 0,
  ),
  90 => 
  array (
    'SysNo' => 90,
    'Size1SysNo' => 4,
    'Size2ID' => '139',
    'Size2Name' => '41 1/3��/UK7.5',
    'Status' => 0,
  ),
  91 => 
  array (
    'SysNo' => 91,
    'Size1SysNo' => 4,
    'Size2ID' => '140',
    'Size2Name' => '42��/UK8',
    'Status' => 0,
  ),
  92 => 
  array (
    'SysNo' => 92,
    'Size1SysNo' => 8,
    'Size2ID' => '301',
    'Size2Name' => '40��/US7',
    'Status' => 0,
  ),
  93 => 
  array (
    'SysNo' => 93,
    'Size1SysNo' => 8,
    'Size2ID' => '302',
    'Size2Name' => '40.5��/US7.5',
    'Status' => 0,
  ),
  94 => 
  array (
    'SysNo' => 94,
    'Size1SysNo' => 8,
    'Size2ID' => '303',
    'Size2Name' => '41.5��/US8',
    'Status' => 0,
  ),
  95 => 
  array (
    'SysNo' => 95,
    'Size1SysNo' => 8,
    'Size2ID' => '304',
    'Size2Name' => '42��/US8.5',
    'Status' => 0,
  ),
  96 => 
  array (
    'SysNo' => 96,
    'Size1SysNo' => 8,
    'Size2ID' => '305',
    'Size2Name' => '42.5��/US9',
    'Status' => 0,
  ),
  97 => 
  array (
    'SysNo' => 97,
    'Size1SysNo' => 8,
    'Size2ID' => '306',
    'Size2Name' => '43��/US9.5',
    'Status' => 0,
  ),
  98 => 
  array (
    'SysNo' => 98,
    'Size1SysNo' => 8,
    'Size2ID' => '307',
    'Size2Name' => '44��/US10',
    'Status' => 0,
  ),
  99 => 
  array (
    'SysNo' => 99,
    'Size1SysNo' => 8,
    'Size2ID' => '308',
    'Size2Name' => '44.5��/US10.5',
    'Status' => 0,
  ),
  100 => 
  array (
    'SysNo' => 100,
    'Size1SysNo' => 8,
    'Size2ID' => '309',
    'Size2Name' => '45��/US11',
    'Status' => 0,
  ),
  101 => 
  array (
    'SysNo' => 101,
    'Size1SysNo' => 9,
    'Size2ID' => '331',
    'Size2Name' => '35��/US5',
    'Status' => 0,
  ),
  102 => 
  array (
    'SysNo' => 102,
    'Size1SysNo' => 9,
    'Size2ID' => '332',
    'Size2Name' => '36��/US5.5',
    'Status' => 0,
  ),
  103 => 
  array (
    'SysNo' => 103,
    'Size1SysNo' => 9,
    'Size2ID' => '333',
    'Size2Name' => '36.5��/US6',
    'Status' => 0,
  ),
  104 => 
  array (
    'SysNo' => 104,
    'Size1SysNo' => 9,
    'Size2ID' => '334',
    'Size2Name' => '37��/US6.5',
    'Status' => 0,
  ),
  105 => 
  array (
    'SysNo' => 105,
    'Size1SysNo' => 9,
    'Size2ID' => '335',
    'Size2Name' => '37.5��/US7',
    'Status' => 0,
  ),
  106 => 
  array (
    'SysNo' => 106,
    'Size1SysNo' => 9,
    'Size2ID' => '336',
    'Size2Name' => '38��/US7.5',
    'Status' => 0,
  ),
  107 => 
  array (
    'SysNo' => 107,
    'Size1SysNo' => 9,
    'Size2ID' => '337',
    'Size2Name' => '39��/US8',
    'Status' => 0,
  ),
  108 => 
  array (
    'SysNo' => 108,
    'Size1SysNo' => 9,
    'Size2ID' => '338',
    'Size2Name' => '40��/US8.5',
    'Status' => 0,
  ),
  109 => 
  array (
    'SysNo' => 109,
    'Size1SysNo' => 12,
    'Size2ID' => '1201',
    'Size2Name' => 'XS',
    'Status' => 0,
  ),
  110 => 
  array (
    'SysNo' => 110,
    'Size1SysNo' => 12,
    'Size2ID' => '1202',
    'Size2Name' => 'S',
    'Status' => 0,
  ),
  111 => 
  array (
    'SysNo' => 111,
    'Size1SysNo' => 12,
    'Size2ID' => '1203',
    'Size2Name' => 'M',
    'Status' => 0,
  ),
  112 => 
  array (
    'SysNo' => 112,
    'Size1SysNo' => 12,
    'Size2ID' => '1204',
    'Size2Name' => 'L',
    'Status' => 0,
  ),
  113 => 
  array (
    'SysNo' => 113,
    'Size1SysNo' => 12,
    'Size2ID' => '1205',
    'Size2Name' => 'XL',
    'Status' => 0,
  ),
  114 => 
  array (
    'SysNo' => 114,
    'Size1SysNo' => 12,
    'Size2ID' => '1206',
    'Size2Name' => 'XXL',
    'Status' => 0,
  ),
  115 => 
  array (
    'SysNo' => 115,
    'Size1SysNo' => 12,
    'Size2ID' => '1207',
    'Size2Name' => 'XXXL',
    'Status' => 0,
  ),
  116 => 
  array (
    'SysNo' => 116,
    'Size1SysNo' => 13,
    'Size2ID' => '1301',
    'Size2Name' => '165/74A',
    'Status' => 0,
  ),
  117 => 
  array (
    'SysNo' => 117,
    'Size1SysNo' => 13,
    'Size2ID' => '1302',
    'Size2Name' => '170/78A',
    'Status' => 0,
  ),
  118 => 
  array (
    'SysNo' => 118,
    'Size1SysNo' => 13,
    'Size2ID' => '1303',
    'Size2Name' => '170/80A',
    'Status' => 0,
  ),
  119 => 
  array (
    'SysNo' => 119,
    'Size1SysNo' => 13,
    'Size2ID' => '1304',
    'Size2Name' => '175/82A',
    'Status' => 0,
  ),
  120 => 
  array (
    'SysNo' => 120,
    'Size1SysNo' => 13,
    'Size2ID' => '1305',
    'Size2Name' => '160/70A',
    'Status' => 0,
  ),
  121 => 
  array (
    'SysNo' => 121,
    'Size1SysNo' => 13,
    'Size2ID' => '1306',
    'Size2Name' => '175/84A',
    'Status' => 0,
  ),
  122 => 
  array (
    'SysNo' => 122,
    'Size1SysNo' => 13,
    'Size2ID' => '1307',
    'Size2Name' => '180/86A',
    'Status' => 0,
  ),
  123 => 
  array (
    'SysNo' => 123,
    'Size1SysNo' => 14,
    'Size2ID' => '1401',
    'Size2Name' => '165/84A',
    'Status' => 0,
  ),
  124 => 
  array (
    'SysNo' => 124,
    'Size1SysNo' => 14,
    'Size2ID' => '1402',
    'Size2Name' => '170/88A',
    'Status' => 0,
  ),
  125 => 
  array (
    'SysNo' => 125,
    'Size1SysNo' => 14,
    'Size2ID' => '1403',
    'Size2Name' => '175/92A',
    'Status' => 0,
  ),
  126 => 
  array (
    'SysNo' => 126,
    'Size1SysNo' => 14,
    'Size2ID' => '1404',
    'Size2Name' => '180/96A',
    'Status' => 0,
  ),
  127 => 
  array (
    'SysNo' => 127,
    'Size1SysNo' => 14,
    'Size2ID' => '1405',
    'Size2Name' => '185/100A',
    'Status' => 0,
  ),
  128 => 
  array (
    'SysNo' => 128,
    'Size1SysNo' => 14,
    'Size2ID' => '1406',
    'Size2Name' => '160/80A',
    'Status' => 0,
  ),
  129 => 
  array (
    'SysNo' => 129,
    'Size1SysNo' => 15,
    'Size2ID' => '1501',
    'Size2Name' => '27��',
    'Status' => 0,
  ),
  130 => 
  array (
    'SysNo' => 130,
    'Size1SysNo' => 15,
    'Size2ID' => '1502',
    'Size2Name' => '28��',
    'Status' => 0,
  ),
  131 => 
  array (
    'SysNo' => 131,
    'Size1SysNo' => 15,
    'Size2ID' => '1503',
    'Size2Name' => '29��',
    'Status' => 0,
  ),
  132 => 
  array (
    'SysNo' => 132,
    'Size1SysNo' => 15,
    'Size2ID' => '1504',
    'Size2Name' => '30��',
    'Status' => 0,
  ),
  133 => 
  array (
    'SysNo' => 133,
    'Size1SysNo' => 15,
    'Size2ID' => '1505',
    'Size2Name' => '31��',
    'Status' => 0,
  ),
  134 => 
  array (
    'SysNo' => 134,
    'Size1SysNo' => 15,
    'Size2ID' => '1506',
    'Size2Name' => '32��',
    'Status' => 0,
  ),
  135 => 
  array (
    'SysNo' => 135,
    'Size1SysNo' => 15,
    'Size2ID' => '1507',
    'Size2Name' => '33��',
    'Status' => 0,
  ),
  136 => 
  array (
    'SysNo' => 136,
    'Size1SysNo' => 15,
    'Size2ID' => '1508',
    'Size2Name' => '34��',
    'Status' => 0,
  ),
  137 => 
  array (
    'SysNo' => 137,
    'Size1SysNo' => 16,
    'Size2ID' => '1601',
    'Size2Name' => '38',
    'Status' => 0,
  ),
  138 => 
  array (
    'SysNo' => 138,
    'Size1SysNo' => 16,
    'Size2ID' => '1602',
    'Size2Name' => '39',
    'Status' => 0,
  ),
  139 => 
  array (
    'SysNo' => 139,
    'Size1SysNo' => 16,
    'Size2ID' => '1603',
    'Size2Name' => '40',
    'Status' => 0,
  ),
  140 => 
  array (
    'SysNo' => 140,
    'Size1SysNo' => 16,
    'Size2ID' => '1604',
    'Size2Name' => '41',
    'Status' => 0,
  ),
  141 => 
  array (
    'SysNo' => 141,
    'Size1SysNo' => 16,
    'Size2ID' => '1605',
    'Size2Name' => '42',
    'Status' => 0,
  ),
  142 => 
  array (
    'SysNo' => 142,
    'Size1SysNo' => 16,
    'Size2ID' => '1606',
    'Size2Name' => '43',
    'Status' => 0,
  ),
  143 => 
  array (
    'SysNo' => 143,
    'Size1SysNo' => 16,
    'Size2ID' => '1607',
    'Size2Name' => '44',
    'Status' => 0,
  ),
  144 => 
  array (
    'SysNo' => 144,
    'Size1SysNo' => 16,
    'Size2ID' => '1608',
    'Size2Name' => '45',
    'Status' => 0,
  ),
  145 => 
  array (
    'SysNo' => 145,
    'Size1SysNo' => 19,
    'Size2ID' => '1801',
    'Size2Name' => '165/72A',
    'Status' => 0,
  ),
  146 => 
  array (
    'SysNo' => 146,
    'Size1SysNo' => 19,
    'Size2ID' => '1802',
    'Size2Name' => '170/76A',
    'Status' => 0,
  ),
  147 => 
  array (
    'SysNo' => 147,
    'Size1SysNo' => 19,
    'Size2ID' => '1803',
    'Size2Name' => '175/80A',
    'Status' => 0,
  ),
  148 => 
  array (
    'SysNo' => 148,
    'Size1SysNo' => 19,
    'Size2ID' => '1804',
    'Size2Name' => '180/88A',
    'Status' => 0,
  ),
  149 => 
  array (
    'SysNo' => 149,
    'Size1SysNo' => 19,
    'Size2ID' => '1805',
    'Size2Name' => '180/90A',
    'Status' => 0,
  ),
  150 => 
  array (
    'SysNo' => 150,
    'Size1SysNo' => 19,
    'Size2ID' => '1806',
    'Size2Name' => '175/86A',
    'Status' => 0,
  ),
  151 => 
  array (
    'SysNo' => 151,
    'Size1SysNo' => 16,
    'Size2ID' => '1609',
    'Size2Name' => '165/88A',
    'Status' => 0,
  ),
  152 => 
  array (
    'SysNo' => 152,
    'Size1SysNo' => 16,
    'Size2ID' => '1610',
    'Size2Name' => '170/92A',
    'Status' => 0,
  ),
  153 => 
  array (
    'SysNo' => 153,
    'Size1SysNo' => 16,
    'Size2ID' => '1611',
    'Size2Name' => '175/96A',
    'Status' => 0,
  ),
  154 => 
  array (
    'SysNo' => 154,
    'Size1SysNo' => 16,
    'Size2ID' => '1612',
    'Size2Name' => '180/100A',
    'Status' => 0,
  ),
  155 => 
  array (
    'SysNo' => 155,
    'Size1SysNo' => 16,
    'Size2ID' => '1613',
    'Size2Name' => '185/104A',
    'Status' => 0,
  ),
  156 => 
  array (
    'SysNo' => 156,
    'Size1SysNo' => 16,
    'Size2ID' => '1614',
    'Size2Name' => '190/108A',
    'Status' => 0,
  ),
  157 => 
  array (
    'SysNo' => 157,
    'Size1SysNo' => 20,
    'Size2ID' => '30',
    'Size2Name' => '105cm',
    'Status' => 0,
  ),
  158 => 
  array (
    'SysNo' => 158,
    'Size1SysNo' => 20,
    'Size2ID' => '31',
    'Size2Name' => '110cm',
    'Status' => 0,
  ),
  159 => 
  array (
    'SysNo' => 159,
    'Size1SysNo' => 20,
    'Size2ID' => '32',
    'Size2Name' => '115cm',
    'Status' => 0,
  ),
  160 => 
  array (
    'SysNo' => 160,
    'Size1SysNo' => 20,
    'Size2ID' => '33',
    'Size2Name' => '120cm',
    'Status' => 0,
  ),
  161 => 
  array (
    'SysNo' => 161,
    'Size1SysNo' => 20,
    'Size2ID' => '34',
    'Size2Name' => '125cm',
    'Status' => 0,
  ),
  162 => 
  array (
    'SysNo' => 162,
    'Size1SysNo' => 20,
    'Size2ID' => '35',
    'Size2Name' => '130cm',
    'Status' => 0,
  ),
  163 => 
  array (
    'SysNo' => 163,
    'Size1SysNo' => 20,
    'Size2ID' => '36',
    'Size2Name' => '97cm',
    'Status' => 0,
  ),
  164 => 
  array (
    'SysNo' => 164,
    'Size1SysNo' => 20,
    'Size2ID' => '37',
    'Size2Name' => '102cm',
    'Status' => 0,
  ),
  165 => 
  array (
    'SysNo' => 165,
    'Size1SysNo' => 20,
    'Size2ID' => '38',
    'Size2Name' => '112cm',
    'Status' => 0,
  ),
  166 => 
  array (
    'SysNo' => 166,
    'Size1SysNo' => 20,
    'Size2ID' => '39',
    'Size2Name' => '104cm',
    'Status' => 0,
  ),
  167 => 
  array (
    'SysNo' => 167,
    'Size1SysNo' => 20,
    'Size2ID' => '40',
    'Size2Name' => '117cm',
    'Status' => 0,
  ),
  168 => 
  array (
    'SysNo' => 168,
    'Size1SysNo' => 20,
    'Size2ID' => '41',
    'Size2Name' => '122cm',
    'Status' => 0,
  ),
  169 => 
  array (
    'SysNo' => 169,
    'Size1SysNo' => 21,
    'Size2ID' => '42',
    'Size2Name' => '165/72A',
    'Status' => 0,
  ),
  170 => 
  array (
    'SysNo' => 170,
    'Size1SysNo' => 21,
    'Size2ID' => '43',
    'Size2Name' => '170/76A',
    'Status' => 0,
  ),
  171 => 
  array (
    'SysNo' => 171,
    'Size1SysNo' => 21,
    'Size2ID' => '44',
    'Size2Name' => '175/80A',
    'Status' => 0,
  ),
  172 => 
  array (
    'SysNo' => 172,
    'Size1SysNo' => 21,
    'Size2ID' => '45',
    'Size2Name' => '180/84A',
    'Status' => 0,
  ),
  173 => 
  array (
    'SysNo' => 173,
    'Size1SysNo' => 22,
    'Size2ID' => '46',
    'Size2Name' => '170/70A',
    'Status' => 0,
  ),
  174 => 
  array (
    'SysNo' => 174,
    'Size1SysNo' => 22,
    'Size2ID' => '47',
    'Size2Name' => '175/74A',
    'Status' => 0,
  ),
  175 => 
  array (
    'SysNo' => 175,
    'Size1SysNo' => 22,
    'Size2ID' => '48',
    'Size2Name' => '175/78A',
    'Status' => 0,
  ),
  176 => 
  array (
    'SysNo' => 176,
    'Size1SysNo' => 22,
    'Size2ID' => '49',
    'Size2Name' => '175/82A',
    'Status' => 0,
  ),
  296 => 
  array (
    'SysNo' => 296,
    'Size1SysNo' => 12,
    'Size2ID' => '1213',
    'Size2Name' => '160/85',
    'Status' => 0,
  ),
  313 => 
  array (
    'SysNo' => 313,
    'Size1SysNo' => 12,
    'Size2ID' => '1214',
    'Size2Name' => '165/90',
    'Status' => 0,
  ),
  265 => 
  array (
    'SysNo' => 265,
    'Size1SysNo' => 2,
    'Size2ID' => '165',
    'Size2Name' => 'M7',
    'Status' => 0,
  ),
  266 => 
  array (
    'SysNo' => 266,
    'Size1SysNo' => 2,
    'Size2ID' => '166',
    'Size2Name' => 'M8',
    'Status' => 0,
  ),
  268 => 
  array (
    'SysNo' => 268,
    'Size1SysNo' => 2,
    'Size2ID' => '168',
    'Size2Name' => 'M10',
    'Status' => 0,
  ),
);?>