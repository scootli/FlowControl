<?php

define('BIZ_TYPE_PRIZE_COUNTER', 3);
define('BIZ_TYPE_PRIZE_TOTAL_COUNTER', 4);
define('BIZ_TYPE_PRIZE_DAY_COUNTER', 5);
define('BIZ_TYPE_USER_TOTAL_COUNTER', 6);
define('BIZ_TYPE_USER_DAY_COUNTER', 7);
define('BIZ_TYPE_ZSTHH_TEMPLATE', 8);
define('BIZ_TYPE_ACTIVITY_CHARGE', 9);
//define('BIZ_TYPE_ACTIVITY_STATUS', 10);
//define('BIZ_TYPE_ACTIVITY_DAILY_STATUS', 11);
define('BIZ_TYPE_APPOINT_COUNTER', 12);

IDataCache::$prefixs = array(
	IDataCache::BIZ_TYPE_COMP_CONFIG => 'component_config_',
	IDataCache::BIZ_TYPE_FREQ_LIMIT => 'freq_limit_',
	BIZ_TYPE_PRIZE_COUNTER => Config::getEnvName() . 'prize_count_',
	BIZ_TYPE_PRIZE_TOTAL_COUNTER => Config::getEnvName() . 'prize_total_count_',
	BIZ_TYPE_PRIZE_DAY_COUNTER => Config::getEnvName() . 'prize_day_count_',
	BIZ_TYPE_USER_TOTAL_COUNTER => Config::getEnvName() . 'user_total_count_',
	BIZ_TYPE_USER_DAY_COUNTER => Config::getEnvName() . 'user_day_count_',
	BIZ_TYPE_ZSTHH_TEMPLATE => 'zaoshi_tianheihei_template_',
	BIZ_TYPE_ACTIVITY_CHARGE => Config::getEnvName() . 'activity_charge_',
	//BIZ_TYPE_ACTIVITY_STATUS => Config::getEnvName() . 'activity_status_',
	//BIZ_TYPE_ACTIVITY_DAILY_STATUS => Config::getEnvName() . 'activity_daily_status_',
	BIZ_TYPE_APPOINT_COUNTER => 'appoint_count_'
);