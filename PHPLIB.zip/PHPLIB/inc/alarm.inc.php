<?php

define('ALARM_GEN_ACT_FAILED', 631853);