<?php

if ( !defined('PHPLIB_ROOT') ) {
    define('PHPLIB_ROOT', '/data/release/PHPLIB/');
}

if ( !defined('WEB_ROOT') ) {
    define('WEB_ROOT', '/data/release/webapp/');
}

if ( !defined('LOG_ROOT') ) {
    define('LOG_ROOT', '/data/logs/');
}

if (!defined('SERVER_ROOT')) {
    define('SERVER_ROOT', '/data/release/server/');
}

###################### �ڲ� Server ���� ########################
$_IP_CFG = array();
$_IP_CFG['IDGenerator']   = "10.180.76.18:10100";
$_IP_CFG['sessiond']      = "10.180.76.18:10120";
$_IP_CFG['promotion']     = "10.180.76.18:10101";
$_IP_CFG['traderPromotion']  = "10.180.76.18:10201";
$_IP_CFG['reviewSystem']  = "10.180.76.19:10606";
$_IP_CFG['reviewFilter']  = "10.180.76.20:12338";
$_IP_CFG['freqlimit']     = "10.180.76.19:10102";
$_IP_CFG['asytask']       = "10.180.76.19:10121";
$_IP_CFG['asytask2']       = "10.180.76.18:10121";
$_IP_CFG['sessiond_0']    = "10.180.76.18:10120";
$_IP_CFG['sessiond_1']    = "10.180.76.19:10120";
$_IP_CFG['IDGenerator_0']   = "10.180.76.18:10100";
$_IP_CFG['IDGenerator_1']   = "10.180.76.19:10100";

$_IP_CFG['OrderManagerCheck'] = '10.180.76.18:10301';
$_IP_CFG['OrderManager'] = '10.180.76.18:10300';

$_IP_CFG['RetailerMultiPrice'] = "10.180.76.19:10132"; // ���SPP����
$_IP_CFG['RetailerCluster'] = "10.180.76.19:10133"; // ��۾ۺ�SPP����
$_IP_CFG['ADVERTISE_PRE'] = array(
    'ERP_1' => 'http://img2.icson.com',
    'ERP_1001' => 'http://img2.icson.com',
    'ERP_2001' => 'http://img2.icson.com',
    'ERP_3001' => 'http://img2.icson.com',
    'ERP_4001' => 'http://img2.icson.com',
    'ERP_5001' => 'http://img2.icson.com'
);

$_IP_CFG['ORDERFLOW'] = array(
    '1'    => 'http://ias.icson.com', // ias.51buy.com
    '5'    => 'http://ias.icson.com', // ias.51buy.com
    '1001' => 'http://ias.icson.com',
    '1004' => 'http://ias.icson.com',
    '2001' => 'http://ias.icson.com',
    '3001' => 'http://ias.icson.com',
    '4001' => 'http://ias.icson.com',
    '5001' => 'http://ias.icson.com'
);

$_IP_CFG['SEARCH_PAIPAI'] = array('10.191.7.215', '10.191.8.161');
$_IP_CFG['SEARCH_SHOP'] = array('10.191.31.11', '10.191.31.12', '10.191.31.13');
$_IP_CFG['FLUSH_CACHE_SERVER'] = '10.180.74.148';
$_IP_CFG['SEARCH_BUY'] = 'searchex.buy.qq.com';
$_IP_CFG['SEARCH_PAIPAI_URL'] = 'searchex.paipai.com';

$_IP_CFG['QQ_OPENID'] = '10.180.74.124';//ת��openid�Ľӿ�
$_IP_CFG['QQ_OPENIDS'] = array('10.180.74.124', '10.180.74.113');//ת��openid�Ľӿ�
//�жϻ�ԱVIP�Ľӿ�
$_IP_CFG['QQ_VIP'] = array(
    '10.189.32.96',
    '10.189.48.143',
    '10.189.48.87',
    '10.189.48.91',
    '10.189.42.77',
    '10.189.42.78',
    '10.189.42.80',
    '10.189.42.81',
    '10.189.42.82',
    '10.189.40.65',
    '10.189.40.94',
    '10.189.40.95'
);
$_IP_CFG['QQ_GREEN'] = '10.129.133.144';//�ж������Ա�Ľӿ�
$_IP_CFG['QQ_YEAR_VIP'] = '183.60.3.133';//�ж���ѻ�ԱVIP�Ľ�
$_IP_CFG['QQ_BLUE'] = '10.179.2.163';//�ж������Ա�ӿ�
$_IP_CFG['QQ_YELLOW'] = '10.129.136.83';//�жϻ����Ա�ӿ�
$_IP_CFG['QQ_TOKEN'] = array('10.129.136.83', '10.129.136.94'); //QQ_TOKEN��֤
$_IP_CFG['STAT_51BUY'] = array('101.226.49.43');//stat_51buy��ip

$_IP_CFG['ip2city'][0]	  = array('IP' => '10.180.76.18', 'PORT' => 7000);
$_IP_CFG['ip2city'][1]	  = array('IP' => '10.180.76.18', 'PORT' => 7000);
$_IP_CFG['ip2city'][2]	  = array('IP' => '10.180.76.18', 'PORT' => 7000);
$_IP_CFG['ip2city'][3]	  = array('IP' => '10.180.76.18', 'PORT' => 7000);

$_IP_CFG['ipagent'] = array(
    array('IP' => '10.180.76.18', 'PORT' => 11239),
    array('IP' => '10.180.76.19', 'PORT' => 11239)
);

$_IP_CFG['verify_code'] = array(
    'code_server' => array(
        array( 'IP' => '172.17.148.38', 'PORT' => 31110 ),
        array( 'IP' => '172.17.148.39', 'PORT' => 31110 )
    ),
    'check_server' => array(
        array( 'IP' => '172.17.148.38', 'PORT' => 18888 ),
        array( 'IP' => '172.17.148.39', 'PORT' => 18888 )
    )
);

$_IP_CFG['PERSONAL_SERVER'] = array(
    array('IP' => '10.180.76.18', 'PORT' => 40223),
);
$_IP_CFG['PERSONAL_GETDATA'] = array(
    array('IP' => '10.191.8.235', 'PORT' => 50010),
    array('IP' => '10.191.8.236', 'PORT' => 50010),
    array('IP' => '10.191.8.235', 'PORT' => 50011),
    array('IP' => '10.191.8.236', 'PORT' => 50011),
);//���Ի��Ƽ��ӿ�
$_IP_CFG['PERSONAL_PV'] = array(
    array('IP' => '10.149.31.217', 'PORT' => 31305),
);//���Ի��Ƽ�pv�ϱ�
$_IP_CFG['PERSONAL_CLICK'] =array(
    array('IP' => '10.149.31.217', 'PORT' => 31305),
);//��
$_IP_CFG['PERSONAL_LIKEGETDATA'] = array(
    array('IP' => '10.191.8.235', 'PORT' => 60010),
    array('IP' => '10.191.8.235', 'PORT' => 60011),
    array('IP' => '10.191.8.236', 'PORT' => 60010),
    array('IP' => '10.191.8.236', 'PORT' => 60011),
);

$_IP_CFG['PERSONAL_LIKEGETDATA_EVENT'] = array(
    array('IP' => '10.191.8.235', 'PORT' => 24010),
    array('IP' => '10.191.8.235', 'PORT' => 24011),
    array('IP' => '10.191.8.236', 'PORT' => 24010),
    array('IP' => '10.191.8.236', 'PORT' => 24011),
);

$_IP_CFG['ITEMRECOMMEND_GETDATA'] = array(
    array('IP' => '10.191.8.235', 'PORT' => 21010),
    array('IP' => '10.191.8.236', 'PORT' => 21010),
); // ����ҳ��Ʒ�Ƽ��ӿڷ���
$_IP_CFG['ITEMRECOMMEND_SERVER'] = array(
    array('IP' => '10.180.76.18', 'PORT' => 40223),
);// ����ҳ��Ʒ�Ƽ���ת����
$_IP_CFG['ITEMRECOMMEND_PV'] = array(
    array('IP' => '10.191.136.205', 'PORT' => 41300),
    array('IP' => '10.191.136.205', 'PORT' => 41300),
);// ����ҳ��Ʒ�Ƽ��ӿ�pv�ϱ�
$_IP_CFG['ITEMRECOMMEND_CLICK'] = array(
    array('IP' => '10.191.136.205', 'PORT' => 41300),
    array('IP' => '10.191.136.205', 'PORT' => 41300),
);// ����ҳ��Ʒ�Ƽ��ӿ�click�ϱ�

// ���ﳵ���Ի��Ƽ�
$_IP_CFG['CART_GETDATA'] = array(
    array('IP' => '10.191.8.235', 'PORT' => 22010),
    array('IP' => '10.191.8.235', 'PORT' => 22011),
    array('IP' => '10.191.8.236', 'PORT' => 22010),
    array('IP' => '10.191.8.236', 'PORT' => 22011),
); // �ӿڷ���
$_IP_CFG['CART_SERVER'] = array(
    array('IP' => '10.180.76.18', 'PORT' => 40223),
);// ��ת����
$_IP_CFG['CART_PV'] = array(
    array('IP' => '10.191.136.205', 'PORT' => 41400),
);// pv�ϱ�

$_IP_CFG['PAYFOREXPENSIVENESS'] = 'http://10.180.17.25:55127'; //�����
$_IP_CFG['INFORM_ORDER_CANCEL'] = 'http://10.180.17.25:55127'; //ȡ������֪ͨERP
$_IP_CFG['AUTOPAYBACK'] = 'http://10.180.17.25:55127'; //�Զ��۱�

$_IP_CFG['VERIFY_IDENTITY'] =  array(
            array('IP' => '10.191.6.112', 'PORT' => 25500),
            array('IP' => '10.191.8.44', 'PORT' => 25500)
);

$_IP_CFG['VERIFY_IDENTITY_CHANGEPWD_HINT'] =  array(
                array('IP' => '10.191.6.112', 'PORT' => 26500),
                array('IP' => '10.191.8.44', 'PORT' => 26500)
);

$_IP_CFG['USER_CHANGE_PWD_REPORT'] =  array(
                array('IP' => '10.149.20.209', 'PORT' => 50010),
                array('IP' => '10.149.20.209', 'PORT' => 50010)
);

$_IP_CFG['USER_REGISTER_REPORT'] =  array(
        array('IP' => '10.191.8.44', 'PORT' => 59891),
        array('IP' => '10.191.8.44', 'PORT' => 59891)
);

###################### �ڲ� TTC ���� ########################
###################### �û�ģ�� ########################

$_TTC_CFG['IUserPassTTC']['IP']            = "10.206.2.15:9050";
$_TTC_CFG['IEmailLoginTTC']['IP']          = "10.206.2.15:9051";
$_TTC_CFG['IIcsonLoginTTC']['IP']          = "10.206.2.15:9052";
$_TTC_CFG['ITelLoginTTC']['IP']            = "10.206.2.15:9053";
$_TTC_CFG['IQQLoginTTC']['IP']             = "10.180.74.14:9054";
$_TTC_CFG['IUsersTTC']['IP']               = "10.206.2.15:9055";
$_TTC_CFG['IUserAddressBookTTC']['IP']     = "10.180.74.14:9056";
$_TTC_CFG['IUserInvoiceBookTTC']['IP']     = "10.180.74.14:9057";
$_TTC_CFG['ICouponTTC']['IP']              = "10.180.74.14:9058";
$_TTC_CFG['ICouponResourceTTC']['IP']      = "10.180.74.14:9116";
$_TTC_CFG['IUserCouponIndexTTC']['IP']     = "10.180.74.14:9059";
$_TTC_CFG['IShoppingCartTTC']['IP']        = "10.180.74.14:9060";
$_TTC_CFG['IShoppingCartTTCNew']['IP']     = "10.180.74.14:9140";
$_TTC_CFG['IProductCommonInfoTTC']['IP']   = "10.206.8.86:9061";//Ǩ���»���watson
$_TTC_CFG['IProductInfoTTC']['IP']         = "10.206.8.86:9062";//Ǩ���»���watson
$_TTC_CFG['IProductIDMapTTC']['IP']        = "10.180.74.16:9063";//Ǩ�Ƶ�55
$_TTC_CFG['IProductRelativityTTC']['IP']   = "10.180.74.14:9064";
$_TTC_CFG['IPageCacheTTC']['IP']           = "10.180.74.16:9065";//Ǩ�Ƶ�55
$_TTC_CFG['ICategoryTTC']['IP']            = "10.180.74.16:9066";//Ǩ�Ƶ�55
$_TTC_CFG['IGiftTTC']['IP']                = "10.180.74.14:9067";
$_TTC_CFG['ILimitTTC']['IP']               = "10.180.74.14:9072";
$_TTC_CFG['IShippingPriceTTC']['IP']       = "10.180.74.14:9068";
$_TTC_CFG['IShippingRegionTTC']['IP']      = "10.180.74.14:9069";
$_TTC_CFG['IUserExtensionTTC']['IP']       = "10.180.74.14:9080";
$_TTC_CFG['IEntrySourceTTC']['IP']         = "10.180.74.14:9081";
$_TTC_CFG['IMasterIdMapTTC']['IP']         = "10.180.74.14:9084";
$_TTC_CFG['IModeProductMapTTC']['IP']      = "10.180.74.14:9085";
$_TTC_CFG['IOrderInvoiceTTC']['IP']        = "10.180.74.14:9092";
$_TTC_CFG['IOrdersTTC']['IP']              = "10.180.74.14:9089";
$_TTC_CFG['IOrderItemsTTC']['IP']          = "10.180.74.14:9091";
$_TTC_CFG['IMultiPriceTTC']['IP']          = "10.180.74.16:9094";//Ǩ�Ƶ�55
$_TTC_CFG['ISearchWordTTC']['IP']          = "10.180.74.15:9096";
$_TTC_CFG['IAdItemDetailTTC']['IP']        = "10.180.74.15:9097";
$_TTC_CFG['IKeyWordHotClassNewTTC']['IP']  = "10.180.74.15:9110";
$_TTC_CFG['IShortUrlTTC']['IP']  		   = "10.180.74.15:9122";
$_TTC_CFG['IPromotionRuleValidTTC']['IP']  = "10.180.74.14:9112";
$_TTC_CFG['IPromotionProductRuleMapTTC']['IP']= "10.180.74.14:9113";
$_TTC_CFG['IPromotionUserRuleMapTTC']['IP']= "10.180.74.14:9114";
$_TTC_CFG['IPromotionSendCouponTTC']['IP'] = "10.180.74.14:9115";
$_TTC_CFG['IAdGroupTTC']['IP']             = "10.180.74.15:9121";
$_TTC_CFG['IAdPositionTTC']['IP']          = "10.180.74.15:9118";
$_TTC_CFG['IAdInfoTTC']['IP']              = "10.180.74.15:9119";
$_TTC_CFG['IAdMapTTC']['IP']               = "10.180.74.15:9120";
$_TTC_CFG['IEventDetailTTC']['IP']         = "10.180.74.15:9087";
$_TTC_CFG['IEventStatistcsTTC']['IP']      = "10.180.74.15:9088";

$_TTC_CFG['IDiyInfoTTC']['IP']             = "10.180.74.15:9072";
$_TTC_CFG['IDiyPowerTTC']['IP']            = "10.180.74.15:9074";
$_TTC_CFG['IDiyMatchTTC']['IP']            = "10.180.74.15:9075";
$_TTC_CFG['IDiyFilterTTC']['IP']           = "10.180.74.15:9073";
$_TTC_CFG['IDiyRecommednDetailTTC']['IP']  = "10.180.74.15:9076";
$_TTC_CFG['IDiyUserMasterTTC']['IP']       = "10.180.74.15:9077";
$_TTC_CFG['IDiyUserItemTTC']['IP']         = "10.180.74.15:9078";
$_TTC_CFG['IDiyCacheTTC']['IP']            = "10.180.74.15:9079";
$_TTC_CFG['IActCountDownTTC']['IP']        = "10.180.74.15:9082";
$_TTC_CFG['IListRecommendTTC']['IP']       = "10.180.74.15:9086";
$_TTC_CFG['IClientSessionTTC']['IP']       = "10.180.74.15:9098";
$_TTC_CFG['IProductServiceTTC']['IP']      = "10.180.74.15:9017";

$_TTC_CFG['IProductStockTTC']['IP']        = "10.206.8.86:9221";//Ǩ��5.13
$_TTC_CFG['IInventoryStockTTC']['IP']      = "10.206.2.141:9108";
$_TTC_CFG['IGiftNewTTC']['IP']         	   = "10.206.2.143:9109";
$_TTC_CFG['IUserTypeTTC']['IP']             = "10.180.74.15:9141";

$_TTC_CFG['IOrderProcessFlowTTC']['IP']     = "10.180.74.15:9000";
$_TTC_CFG['IProductDetailTTC']['IP']        = "10.180.74.15:9001";
$_TTC_CFG['IScoreFlowTTC']['IP']            = "10.180.74.15:9002";
$_TTC_CFG['IProductCommentTTC']['IP']       = "10.180.74.15:9003"; //TODO Not use
$_TTC_CFG['IProductReviewTTC']['IP']        = "10.180.74.15:9004"; //TODO c server
$_TTC_CFG['IProductReviewStatisticsTTC']['IP']= "10.180.74.15:9005"; //TODO c server
$_TTC_CFG['IUserProductsTTC']['IP']         = "10.180.74.15:9006";
$_TTC_CFG['IUserReviewTTC']['IP']           = "10.180.74.15:9007"; //TODO c server
$_TTC_CFG['IUserReviewStatisticsTTC']['IP'] = "10.180.74.15:9008"; //TODO c server
$_TTC_CFG['IReplyTTC']['IP']                = "10.180.74.15:9009"; //TODO c server
$_TTC_CFG['IReviewTTC']['IP']               = "10.180.74.15:9010"; //TODO c server
$_TTC_CFG['IVoteTTC']['IP']                 = "10.180.74.15:9011";
$_TTC_CFG['ISearchNavAttrTTC']['IP']        = "10.180.74.15:9012";
$_TTC_CFG['ISearchNavOptionTTC']['IP']      = "10.180.74.15:9013";
$_TTC_CFG['IVoteOptionTTC']['IP']           = "10.180.74.15:9014";
$_TTC_CFG['IManufacturerTTC']['IP']         = "10.180.74.15:9015";
$_TTC_CFG['IKeyWordHotClassTTC']['IP']      = "10.180.74.15:9016";
$_TTC_CFG['IUsersQqMapTTC']['IP']           = "10.206.2.15:9098";
$_TTC_CFG['IOrdersNeedScoreBackTTC']['IP']  = "10.180.74.16:9172";
//�����
$_TTC_CFG['IGuiJiuPeiTTC']['IP']           = "10.180.74.14:9139";
//��Ʒ��
$_TTC_CFG['IGiftCardTTC']['IP']         = "10.180.74.14:9167";
$_TTC_CFG['IGiftCardBatchTTC']['IP']         = "10.180.74.14:9168";
$_TTC_CFG['IGiftCardUserTTC']['IP']         = "10.180.74.14:9173";
//�ӻ�����
$_TTC_CFG['IDelayOrderTTC']['IP']         = "10.180.74.16:9174";
#��ԴTTC
$_TTC_CFG['ISessionTTC']['IP']              = "10.180.74.14:9071";
$_TTC_CFG['IVerifyCodeTTC']['IP']           = "10.180.74.14:9070";
$_TTC_CFG['IUserReviewLimitTTC']['IP']      = "10.180.74.15:9083";
$_TTC_CFG['ICpContractTTC']['IP']			= "10.180.74.14:9095";
$_TTC_CFG['IBShoppingCartTTC']['IP']         = "10.180.74.15:9135";

########################��������ģ��##########################
$_TTC_CFG['IBSessionTTC']['IP']         = "10.180.74.14:31001";
$_TTC_CFG['IRetailerShopTTC']['IP']     = "10.180.74.14:31002";
$_TTC_CFG['IRetailerSalesmanTTC']['IP'] = "10.180.74.14:31003";
$_TTC_CFG['IRetailerShopLogTTC']['IP']  = "10.180.74.14:31004";
$_TTC_CFG['IRetailerConfigTTC']['IP']   = "10.180.74.14:31005";
$_TTC_CFG['IBProductTTC']['IP']         = "10.180.74.14:31006";
$_TTC_CFG['IBOrdersTTC']['IP']          = "10.180.74.15:9130";
$_TTC_CFG['IBOrderItemsTTC']['IP']      = "10.180.74.15:9131";
$_TTC_CFG['IRetailerCustomerTTC']['IP'] = "10.180.74.15:9132";
$_TTC_CFG['IRetailerCustomerMapTTC']['IP']         = "10.180.74.15:9133";
$_TTC_CFG['IRetailerShopguidTTC']['IP'] = "10.180.74.15:9134";
$_TTC_CFG['IRetailerLoginTTC']['IP']     = "10.180.74.16:9152";
$_TTC_CFG['IRetailerPasswdTTC']['IP']    = "10.180.74.16:9153";
$_TTC_CFG['IRetailerTTC']['IP']    = "10.180.74.16:9154";
$_TTC_CFG['IEventApiImgTTC']['IP']  	= "10.180.74.16:9169";
$_TTC_CFG['IRetailerOrderItemsTTC']['IP'] = "10.180.74.16:9148";
$_TTC_CFG['IRetailerOrderProcessFlowTTC']['IP'] = "10.180.74.16:9149";
$_TTC_CFG['IRetailerOrdersTTC']['IP'] = "10.180.74.16:9151";
$_TTC_CFG['IRetailerParamTTC']['IP'] = "10.180.74.15:9198";
$_TTC_CFG['IBannerTTC']['IP'] = "10.180.74.14:9192";
$_TTC_CFG['IRetailerAddressBookTTC']['IP'] = "10.180.74.15:9220";
$_TTC_CFG['IRetailerAccountTTC']['IP'] = "10.180.74.16:9155";
$_TTC_CFG['IBCategoryTTC']['IP'] = "10.180.74.14:9193";
$_TTC_CFG['IRetailerCategoryTTC']['IP'] = "10.180.74.15:9209";
####################��ĩ�ع˻###########
$_TTC_CFG['IUserHistoryTTC']['IP'] = "10.180.74.14:9186";
$_TTC_CFG['IUserPrizeInfoTTC']['IP'] = "10.180.74.14:9187";

########################���ƻ�TTC##########################
$_TTC_CFG['ICpContractFeeTTC']['IP'] = "10.180.74.15:9129";
$_TTC_CFG['ICpFeeItemTTC']['IP']     = "10.180.74.15:9128";

########################## ��ǰ�ۺ��˿�ģ��TTC #############################
$_TTC_CFG['IBASBankSubBranchTTC']['IP'] = "10.180.74.15:9106";
$_TTC_CFG['IRMARequestTTC']['IP'] = "10.180.74.15:9104";
$_TTC_CFG['IRMARequestItemTTC']['IP'] = "10.180.74.15:9105";
$_TTC_CFG['IRMARegisterTTC']['IP'] = "10.180.74.15:9102";
$_TTC_CFG['IRMARegisterLogTTC']['IP'] = "10.180.74.15:9103";
$_TTC_CFG['IRMACustomerRequestNoteTTC']['IP'] = "10.180.74.15:9101";
$_TTC_CFG['IProductInstallMentBookTTC']['IP'] = "10.180.74.15:9111";
$_TTC_CFG['IRMACusLogTTC']['IP'] = "10.180.74.15:9143";
$_TTC_CFG['ISatisfactionSurveyTTC']['IP'] = "10.180.74.14:9144";

########################## �����Ż�ȯģ��TTC #############################
$_TTC_CFG['IMerchantsTTC']['IP'] = "10.180.74.15:9123";
$_TTC_CFG['IMerchantsCouponTypeTTC']['IP'] = "10.180.74.15:9124";
$_TTC_CFG['IMerchantsCouponIndexTTC']['IP'] = "10.180.74.15:9125";
$_TTC_CFG['IMerchantsCouponLogTTC']['IP'] = "10.180.74.15:9126";
$_TTC_CFG['IMerchantsCouponBatchIndexTTC']['IP'] = "10.180.74.15:9127";

#####���߹���ƽ̨TTC#####
$_TTC_CFG['IUserDeviceTTC']['IP'] = "10.180.74.15:9137";
$_TTC_CFG['IDeviceInfoTTC']['IP'] = "10.180.74.15:9136";
$_TTC_CFG['IPushMsgTTC']['IP'] = "10.180.74.15:9138";

###CPS2.0###
$_TTC_CFG['ICPSCommissionTTC']['IP']			 = "10.180.74.16:9156";
$_TTC_CFG['ICPSCommissionRateTTC']['IP']		 = "10.180.74.16:9157";
$_TTC_CFG['ICPSCommissionRateCategoryTTC']['IP'] = "10.180.74.16:9161";
$_TTC_CFG['ICPSMerchantsTTC']['IP']				 = "10.180.74.16:9159";
$_TTC_CFG['ICPSTmpDataTTC']['IP']				 = "10.180.74.16:9176";
$_TTC_CFG['ICPSOrdersTimelineTTC']['IP']		 = "10.180.74.16:9177";
$_TTC_CFG['ICPSSysLogTTC']['IP']				 = "10.180.74.16:9170";
$_TTC_CFG['ICPSOrdersTTC']['IP']				 = "10.180.74.16:9163";
$_TTC_CFG['ICPSPackagesTTC']['IP']                               = "10.180.74.16:9165";

########################## �ƽ̨TTC #############################
$_TTC_CFG['IVerifyObjectMapTTC']['IP'] = '10.180.74.16:9178';
$_TTC_CFG['IActAppointTTC']['IP'] = '10.180.74.14:9188';
$_TTC_CFG['IActAppointValueTTC']['IP'] = '10.180.74.14:9189';

######�û���ȫ########
$_TTC_CFG['IVerifyUserIdentityTTC']['IP'] = "10.180.74.14:9182";

#################��������TTC###################
$_TTC_CFG['IServiceReplyTTC']['IP'] = "10.180.74.14:9190";
$_TTC_CFG['IServiceApplyTTC']['IP'] = "10.180.74.14:9191";

########################## TMem IP ���� #############################
$_TMEM_CFG = array();

$_TMEM_CFG['verify_config'] = array(
    'IP' => array(
        '10.180.7.47:9101',
        '10.191.131.26:9101',
        '10.156.35.30:9101'
    )
);

$_TMEM_CFG['data_cache'] = array(
    'IP' => array(
        '10.180.7.47:9101',
        '10.191.131.26:9101',
        '10.156.35.30:9101'
    )
);

$_TMEM_CFG['event_data'] = array(
    'IP' => array(
        '10.191.131.162:9101',
        '10.191.131.146:9101',
        '10.191.131.147:9101'
    )
);
$_TMEM_CFG['service_statistic'] = array(
    'IP' => array(
        '10.191.131.146:9101', 
        '10.191.132.12:9101', 
        '10.191.131.162:9101',
        '10.191.131.147:9101', 
        '10.191.132.11:9101'
    )
);
$_TMEM_CFG['service_center_unread_message'] = array(
    'IP' => array(
        '10.191.131.146:9101',
        '10.191.131.162:9101',
        '10.191.131.147:9101'
    )
);

//�������̼�¼������ϸ
$_TMEM_CFG['order_price_detail_config'] = array(
    'IP' => array(
        '10.191.131.147:9101',
        '10.191.131.162:9101',
        '10.191.131.146:9101',
        '10.191.132.11:9101'
    )
);

########################## TMem BID ���� #############################
define('TMEM_BID_VERIFY_CONFIG', 102030162);
define('TMEM_BID_DATA_CACHE', 102030162);
define('TMEM_BID_ACT_DATA', 102030203);
define('TMEM_BID_ACT_DATA_MAP', 102030203);
define('TMEM_BID_SERVICE_STATISTIC', 102030219);
define('TMEM_BID_SERVICE_CENTER_UNREAD_MESSAGE', 102030233);
define('TMEM_BID_ORDER_PRICE_DETAIL', 102030235);

########################## DB ���� #############################
$_DB_CFG = array();
$_DB_CFG['db_privilege']   = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'icson_admin_management', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_core']     = array( 'IP' => '10.180.92.30', 'PORT' => 3306, 'DB' => 'icson_core','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_admin']    = array( 'IP' => '10.180.92.31', 'PORT' => 3306, 'DB' => 'icson_admin','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['product_list']   = array( 'IP' => '10.180.92.31', 'PORT' => 3306, 'DB' => 'product_list', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_diy']   = array( 'IP' => '10.180.92.31', 'PORT' => 3306, 'DB' => 'icson_diy', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
//��Ʒ�����Ż�ȯ
$_DB_CFG['promotion'] 		= array('IP'=>'10.180.92.30' ,'PORT' => 3306 ,'DB'=>'promotion','USER'=>'user_icson','PASSWD'=>'icson');
//�����
$_DB_CFG['guijiupei'] 		= array('IP'=>'10.180.92.31' ,'PORT' => 3306,'DB'=>'guijiupei','USER'=>'user_icson','PASSWD'=>'icson');
$_DB_CFG['card_info']             = array('IP' => '10.180.92.37', 'PORT' => 3306, 'DB' => 'card_info', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
//CPS������
$_DB_CFG['icson_cps']    = array( 'IP' => '10.180.92.35', 'PORT' => 3306, 'DB' => 'icson_cps','USER' => 'user_icson', 'PASSWD' => 'icson' );
//CPS2.0
$_DB_CFG['cps_merchants']     = array( 'IP' => '10.206.30.125', 'PORT' => 9001, 'DB' => 'cps_merchants','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['cps_sys_log']		  = array( 'IP' => '10.206.30.125', 'PORT' => 9001, 'DB' => 'cps_sys_log_', 'USER' => 'user_icson', 'PASSWD' => 'icson');

//�������ע���е�������
$_DB_CFG['icson_admin_lovecar'] = array('IP' => '10.206.30.125', 'PORT' => 9012, 'DB' => 'icson_lovecar', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['product_info']   = array( 'IP' => '10.191.21.39', 'PORT' => 3306, 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_core_ttc']     = array( 'IP' => '10.180.92.30', 'PORT' => 3306, 'DB' => 'icson_core_ttc','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_other_ttc']     = array( 'IP' => '10.180.92.31', 'PORT' => 3306, 'DB' => 'icson_other_ttc','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_event']   = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'icson_event', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_event_slave']   = array( 'IP' => '10.180.92.28', 'PORT' => 3306, 'DB' => 'icson_event', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['product_pool']    = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'product_pool','USER' => 'user_icson', 'PASSWD' => 'icson' ); //��Ʒ��
$_DB_CFG['icson_admin_event']   = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'icson_admin_event', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_event_component']   = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'icson_event_component', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_admin_store']   = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'icson_admin_store', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_admin_stpage']   = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'icson_admin_stpage', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['retailer']   = array( 'IP' => '10.180.92.31', 'PORT' => 3306, 'DB' => 'retailer', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['orders']   = array( 'IP' => '10.191.21.39', 'PORT' => 3306, 'DB' => 'orders', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['retailer_orders']      = array('IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'borders', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['retailer_order_items']      = array('IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'border_items', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['retailer_customer']      = array('IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'retailer_customer', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['retailerProduct']  = array( 'IP' => '10.191.21.39', 'PORT' => 3306, 'DB' => 'retailer_product', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['retailer_product'] = array( 'IP' => '10.191.21.39', 'PORT' => 3306, 'DB' => 'retailer_product', 'USER' => 'user_icson', 'PASSWD' => 'icson' );

########################## �ҵ�ƽ̨DB #############################
$_DB_CFG['jiadian_db'] = array('IP' => '10.191.21.39', 'PORT' => 3306, 'DB' => 'jiadian_db', 'USER' => 'user_icson', 'PASSWD' => 'icson');

########################## �Ż�ȯ��ˮDB #############################
$_DB_CFG['coupon_flow'] = array('IP' => '10.156.36.51', 'PORT' => 9013, 'DB' => 'coupon_flow', 'USER' => 'user_coupon', 'PASSWD' => 'coupon');
########################## �Ż�ȯ�ձ�DB #############################
$_DB_CFG['coupon_stat'] = array('IP' => '10.156.36.51', 'PORT' => 9013, 'DB' => 'coupon_staticstics', 'USER' => 'user_coupon', 'PASSWD' => 'coupon');
$_DB_CFG['coupon_task'] = array('IP' => '10.156.36.51', 'PORT' => 9013, 'DB' => 'coupon_task', 'USER' => 'user_coupon', 'PASSWD' => 'coupon');


$_DB_TABLE_CFG = array();
$_DB_TABLE_CFG['orders']                = array('DB' => 'orders', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0 );
$_DB_TABLE_CFG['order_invoice']         = array('DB' => 'order_invoice', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['order_items']           = array('DB' => 'order_items', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['order_match']           = array('DB' => 'order_match', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['order_virtual_stock']   = array('DB' => 'order_virtual_stock', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['order_process_flow']    = array('DB' => 'order_process_flow', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>1);
$_DB_TABLE_CFG['users']                 = array('DB' => 'users', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>3);
$_DB_TABLE_CFG['user_pass']             = array('DB' => 'user_pass', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>3);
$_DB_TABLE_CFG['email_login']           = array('DB' => 'email_login', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>3);
$_DB_TABLE_CFG['tel_login']             = array('DB' => 'tel_login', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>3);
$_DB_TABLE_CFG['icson_login']           = array('DB' => 'icson_login', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>3);
$_DB_TABLE_CFG['user_addressbook']      = array('DB' => 'user_addressbook', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['user_invoicebook']      = array('DB' => 'user_invoicebook', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['coupon']      = array('DB' => 'coupon', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['coupon_cdb']  = array('DB' => 'coupon', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>6);
$_DB_TABLE_CFG['user_coupon_index']      = array('DB' => 'user_coupon_index', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['cp_information']     	= array('DB' =>'cp_information', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>1);
$_DB_TABLE_CFG['icson']                 = array('DB' => 'icson', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['icson_rma'] 			= array('DB' => 'ICSON_RMA', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>1);
$_DB_TABLE_CFG['retailer']     			= array('DB' => 'retailer', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>4);
$_DB_TABLE_CFG['retailer_orders']       = array('DB' => 'borders', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=>2);
$_DB_TABLE_CFG['retailer_order_items']       = array('DB' => 'border_items', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>2);
$_DB_TABLE_CFG['retailer_customer']       = array('DB' => 'retailer_customer', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>2);
$_DB_TABLE_CFG['icson_core_ttc']     	= array('DB' => 'icson_core_ttc', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['promotion']                 = array('DB' => 'promotion', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['promotion_user_rule_map']   = array('DB' => 'promotion_user_rule_map', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=>0);
//������
$_DB_TABLE_CFG['task_list'] = array('DB' => 'task_list', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
//CMSǰ��ҳ��Ƭ��ص�
$_DB_TABLE_CFG['51buy_cms_db'] = array('DB' => '51buy_cms_db', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_DB_SERVER_CFG = array();
$_DB_SERVER_CFG['online'][0] = array( 'IP' => '10.180.92.30','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['online'][1] = array( 'IP' => '10.180.92.31','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['online'][2] = array( 'IP' => '10.180.92.36','PORT' => 3306,'DB' => 'borders','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['online'][3] = array( 'IP' => '10.180.92.37','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['online'][4] = array( 'IP' => '10.180.92.31','PORT' => 3306,'DB' => 'retailer','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['online'][6] = array( 'IP' => '10.206.30.125','PORT' => 9008,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['bakup'][0]  = array( 'IP' => '10.180.92.26','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['bakup'][1]  = array( 'IP' => '10.180.92.27','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['bakup'][3] = array( 'IP' => '10.180.76.22','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );

########################## �����Ż�ȯģ��DB #############################
$_DB_CFG['merchants']				= array( 'IP' => '10.180.92.31', 'PORT' => 3306, 'DB' => 'merchants',			  'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['merchants_coupon_type']   = array( 'IP' => '10.180.92.31', 'PORT' => 3306, 'DB' => 'merchants_coupon_type', 'USER' => 'user_icson', 'PASSWD' => 'icson' );

########################## ���߹���ƽ̨db #############################
$_DB_CFG['db_app_userdevice']   = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'app_userdevice_', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['db_app_deviceinfo']   = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'app_deviceinfo_', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['db_app_pushmsg']   = array( 'IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'app_pushmsg_', 'USER' => 'user_icson', 'PASSWD' => 'icson' );

########################## ���ƽ̨DB #############################
$_DB_CFG['act_data'] = array('IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'act_data', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['act_data_map'] = array('IP' => '10.180.92.36', 'PORT' => 3306, 'DB' => 'act_data_map', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['prize_record'] = array('IP' => '10.206.30.125', 'PORT' => 9003, 'DB' => 'prize_record', 'USER' => 'user_icson', 'PASSWD' => 'icson');

########################## MSDB ���� #############################
$_MSDB_CFG = array();

//�¿ͷ�ϵͳ192.168.2.14
$_MSDB_CFG['SO']		 = array( 'IP' => '10.156.9.31' ,'PORT' => 53054,'DB' => 'ICSON_CS','USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
$_MSDB_CFG['SO_BAK']	= array( 'IP' => '10.180.17.25' ,'PORT' => 55123,'DB' => 'ICSON_CS','USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );

//�Ϻ�88
$_MSDB_CFG['ERP_1'] 	 = array( 'IP' => '10.180.17.25','PORT' => 55100,'DB' => 'ICSONDB','USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
$_MSDB_CFG['Customer'] 	 = array( 'IP' => '10.180.17.25','PORT' => 55100,'DB' => 'Customer','USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
//bak76
$_MSDB_CFG['ERP_BAK_1'] = $_MSDB_CFG['ERP_1']; //array( 'IP' => '10.180.17.25','PORT' => 55113,'DB' => 'SH_IAS','USER' => '51buyclickflow', 'PASSWD' => '!QAZXSW@' );

//���� 28
$_MSDB_CFG['ERP_1001'] 	 = array( 'IP' => '10.180.17.25','PORT' => 55101,'DB' => 'ICSONDB','USER' => 'qqsz', 'PASSWD' => 'qqsz2012' );
//bak75
$_MSDB_CFG['ERP_BAK_1001'] = $_MSDB_CFG['ERP_1001'];//array( 'IP' => '10.180.17.25','PORT' => 55112,'DB' => 'SZ_IAS','USER' => '51buyclickflow', 'PASSWD' => '!QAZXSW@');

//����63
$_MSDB_CFG['ERP_2001']   = array( 'IP' => '10.180.17.25','PORT' => 55102,'DB' => 'BJ_IAS','USER' => 'qq_bj', 'PASSWD' => 'qqbj2012' );
//bak75
//$_MSDB_CFG['ERP_BAK_2001'] = array( 'IP' => '10.180.17.25','PORT' => 55112,'DB' => 'BJ_IAS','USER' => '51buyclickflow', 'PASSWD' => '!QAZXSW@');
$_MSDB_CFG['ERP_BAK_2001'] = $_MSDB_CFG['ERP_2001'] ;

//�人22
$_MSDB_CFG['ERP_3001'] 	 = array( 'IP' => '10.180.17.25','PORT' => 55107,'DB' => 'WH_IAS','USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
//75
//$_MSDB_CFG['ERP_BAK_3001'] = array( 'IP' => '10.180.17.25','PORT' => 55112,'DB' => 'WH_IAS','USER' => '51buyclickflow', 'PASSWD' => '!QAZXSW@' );
$_MSDB_CFG['ERP_BAK_3001'] = $_MSDB_CFG['ERP_3001'];

//����62
$_MSDB_CFG['ERP_4001']   = array( 'IP' => '10.180.17.25','PORT' => 55106,'DB' => 'CQ_IAS','USER' => 'qq_ics', 'PASSWD' => 'qq_ics@2012..' );
//bak82
//$_MSDB_CFG['ERP_BAK_4001'] = array( 'IP' => '10.180.17.25','PORT' => 55114,'DB' => 'CQ_IAS','USER' => 'qq_sh', 'PASSWD' => 'qqsh2012');
$_MSDB_CFG['ERP_BAK_4001'] = $_MSDB_CFG['ERP_4001'];

//����58
$_MSDB_CFG['ERP_5001']   = array( 'IP' => '10.180.17.25','PORT' => 55117,'DB' => 'XA_IAS','USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
//����58
$_MSDB_CFG['ERP_BAK_5001'] = $_MSDB_CFG['ERP_5001'];

$_MSDB_CFG['ICSON_Product'] = array( 'IP' => '10.180.17.25','PORT' => 55129,'DB' => 'ICSON_Product','USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );

// �����74 85 86
$_MSDB_CFG['ICSON_STATISTICS_CLICKFLOW'] = array( 'IP' => '10.180.17.25','PORT' => 55111,'DB' => 'ICSON_STATISTICS_CLICKFLOW','USER' => '51buyclickflow', 'PASSWD' => '!QAZXSW@');
$_MSDB_CFG['Inventory_Manager'] = array( 'IP' => '10.180.17.25','PORT' => 55105,'DB' => 'Inventory_Manager','USER' => 'sh_ics', 'PASSWD' => 'icson@20061102');
$_MSDB_CFG['DMSDB'] = array( 'IP' => '10.156.36.14','PORT' => 53076,'DB' => 'DMSDB','USER' => 'sh_ics', 'PASSWD' => 'icson@20061102');
//�ӻ�����
$_MSDB_CFG['real_statistic'] = array( 'IP' => '10.180.17.25','PORT' => 55122,'DB' => 'ICSON_STATISTICS_REAL','USER' => 'sh_ics', 'PASSWD' => 'icson@20061102');

//��������24 63
$_MSDB_CFG['QQSHOP_ORDER_CORE'] = array( 'IP' => '10.180.17.25','PORT' => 55099,'DB' => 'QQSHOP_ORDER_CORE','USER' => 'qq_order', 'PASSWD' => 'qq2012');
$_MSDB_CFG['HQ_QQShop']			= array( 'IP' => '10.180.17.25','PORT' => 55118,'DB' => 'HQ_QQShop','USER' => 'qq_bj', 'PASSWD' => 'qqbj2012' );

// ����ͳ�Ʊ��� 75
$_MSDB_CFG['ICSON_STATISTICS_SALES']       = array( 'IP' => '10.180.17.25','PORT' => 55113,'DB' => 'ICSON_STATISTICS_SALES','USER' => '51buyclickflow', 'PASSWD' => '!QAZXSW@');
$_MSDB_CFG['ICSON_STATISTIC_DISTRIBUTOR']  = array( 'IP' => '10.180.17.25','PORT' => 55113,'DB' => 'ICSON_STATISTICS_SALES','USER' => '51buyclickflow', 'PASSWD' => '!QAZXSW@');

######################## Cache ���� ############################
$_CACHE_CFG = array();

//���������µ�
$_MSDB_TABLE_CFG['QQSHOP_ORDER_CORE'] = array('DB' => 'QQSHOP_ORDER_CORE', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_MSDB_TABLE_CFG['HQ_QQShop']         = array('DB' => 'HQ_QQShop', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>10 );

//�µ����Ŀ�����
$_MSDB_TABLE_CFG['Stock'] = array('DB' => 'ICSON_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 12);
$_MSDB_TABLE_CFG['Product'] = array('DB' => 'ICSON_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 12);
$_MSDB_TABLE_CFG['Category'] = array('DB' => 'ICSON_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 12);
$_MSDB_TABLE_CFG['Product_Gift'] = array('DB' => 'ICSON_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 12);
$_MSDB_TABLE_CFG['CustomPhone'] = array('DB' => 'ICSON_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 12);

$_MSDB_TABLE_CFG['ERP_1']      = array('DB' => 'ICSONDB', 'DB_NUM' => 1,  'IP'=>1);
$_MSDB_TABLE_CFG['Customer']      = array('DB' => 'Customer', 'DB_NUM' => 1,  'IP'=>1);
$_MSDB_TABLE_CFG['ERP_1001']      = array('DB' => 'ICSONDB', 'DB_NUM' => 1,  'IP'=>2);
$_MSDB_TABLE_CFG['ERP_2001']      = array('DB' => 'BJ_IAS', 'DB_NUM' => 1,  'IP'=>3);
$_MSDB_TABLE_CFG['ERP_3001']      = array('DB' => 'WH_IAS', 'DB_NUM' => 1,  'IP'=>8);
$_MSDB_TABLE_CFG['ERP_4001']      = array('DB' => 'CQ_IAS', 'DB_NUM' => 1,  'IP'=>7);
$_MSDB_TABLE_CFG['ERP_5001']      = array('DB' => 'XA_IAS', 'DB_NUM' => 1,  'IP'=>9);
$_MSDB_TABLE_CFG['ICSON_ORDER_CORE']      = array('DB' => 'ICSON_ORDER_CORE', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=>0);
$_MSDB_TABLE_CFG['ICSON_CORE']      = array('DB' => 'ICSON_CORE', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>0);
$_MSDB_TABLE_CFG['ORDER_PROCESS_FLOW']      = array('DB' => 'HQ_SO', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>2);
$_MSDB_TABLE_CFG['ICSON_STATISTICS_CLICKFLOW']   = array('DB' => 'ICSON_STATISTICS_CLICKFLOW', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>4);
$_MSDB_TABLE_CFG['DMSDB']   = array('DB' => 'DMSDB', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>5);
$_MSDB_TABLE_CFG['Inventory_Manager']   = array('DB' => 'Inventory_Manager', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>6);
$_MSDB_TABLE_CFG['Icson_Finance']   = array('DB' => 'Icson_Finance', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>11);
$_MSDB_TABLE_CFG['SO']              = array('DB' => 'ICSON_CS', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>13);
$_MSDB_TABLE_CFG['Pm_Department'] = array('DB' => 'ICSON_STATISTICS_PURCHASE', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 4);
$_MSDB_SERVER_CFG['online'][0] = array( 'IP' => '10.180.17.25','PORT' => 55099,'USER' => 'qq_order', 'PASSWD' => 'qq2012' );
$_MSDB_SERVER_CFG['online'][1] = array( 'IP' => '10.180.17.25','PORT' => 55100,'USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
$_MSDB_SERVER_CFG['online'][2] = array( 'IP' => '10.180.17.25','PORT' => 55101,'USER' => 'qqsz', 'PASSWD' => 'qqsz2012' );
$_MSDB_SERVER_CFG['online'][3] = array( 'IP' => '10.180.17.25','PORT' => 55102,'USER' => 'qq_bj', 'PASSWD' => 'qqbj2012' );
$_MSDB_SERVER_CFG['online'][4] = array( 'IP' => '10.180.17.25','PORT' => 55103,'USER' => '51buyclickflow', 'PASSWD' => '!QAZXSW@' );
$_MSDB_SERVER_CFG['online'][5] = array( 'IP' => '10.156.36.14','PORT' => 53076,'USER' => 'sh_ics', 'PASSWD' => 'icson@20061102' );
$_MSDB_SERVER_CFG['online'][6] = array( 'IP' => '10.180.17.25','PORT' => 55105,'USER' => 'sh_ics', 'PASSWD' => 'icson@20061102' );
$_MSDB_SERVER_CFG['online'][7] = array( 'IP' => '10.180.17.25','PORT' => 55106,'USER' => 'qq_ics', 'PASSWD' => 'qq_ics@2012..' );
$_MSDB_SERVER_CFG['online'][8] = array( 'IP' => '10.180.17.25','PORT' => 55107,'USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
$_MSDB_SERVER_CFG['online'][9] = array( 'IP' => '10.180.17.25','PORT' => 55117,'USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
$_MSDB_SERVER_CFG['online'][10] = array( 'IP' => '10.180.17.25','PORT' => 55118,'USER' => 'qq_bj', 'PASSWD' => 'qqbj2012' );
$_MSDB_SERVER_CFG['online'][11] = array( 'IP' => '10.180.17.25','PORT' => 55120,'USER' => 'sh_ics', 'PASSWD' => 'icson@20061102' );
$_MSDB_SERVER_CFG['online'][12] = array( 'IP' => '10.180.17.25','PORT' => 55129,'USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
$_MSDB_SERVER_CFG['online'][13] = array( 'IP' => '10.156.9.31' ,'PORT' => 53054,'USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );

$_MSDB_SERVER_CFG['bakup'][0] = array( 'IP' => '10.180.17.25','PORT' => 55108,'USER' => 'qq_order', 'PASSWD' => 'qq2012' );
$_MSDB_SERVER_CFG['bakup'][1] = array( 'IP' => '10.180.17.25','PORT' => 55100,'USER' => 'qq_sh', 'PASSWD' => 'qqsh2012' );
$_MSDB_SERVER_CFG['bakup'][2] = array( 'IP' => '10.180.17.25','PORT' => 55109,'USER' => 'qqsz', 'PASSWD' => 'qqsz2012' );
$_MSDB_SERVER_CFG['bakup'][3] = array( 'IP' => '10.180.17.25','PORT' => 55110,'USER' => 'qq_bj', 'PASSWD' => 'qqbj2012' );
$_MSDB_SERVER_CFG['bakup'][4] = array('IP' => '10.156.10.37', 'PORT' => 53079, 'USER' => 'app_query', 'PASSWD' => 'icson74!#qu');
########################CPS2.0��������############################
$_CPS_SERVER_CONFIG['PSFOrderPusher'] = array('IP' => '10.152.15.203', 'PORT' => 10003);
$_CPS_SERVER_CONFIG['PSFOrderComputing'] = array('IP' => '10.152.15.203', 'PORT' => 10002);
$_CPS_SERVER_CONFIG['PSFService'] = array('IP' => '10.152.15.203', 'PORT' => 10004);
$_CPS_SERVER_CONFIG['PSFOrderReceiver'] = array('IP' => '10.152.15.203', 'PORT' => 10001);
$_CPS_SERVER_CONFIG['PSFOrderToERP'] = array('IP' => '10.152.15.203', 'PORT' => 10005);

$_CPS_L5_MOD_CONFIG = array(
        'PSFOrderReceiver'  =>  array( 'modid' => 90945, 'cmdid' => 65536),
        'PSFOrderComputing' =>  array( 'modid' => 90945, 'cmdid' => 131072),
);

######################## ��Ϣ�������� ############################
//define('ASYNC_PROF_KEY', 0x100001); // �첽�����û�������Ϣ����

$_MCQ_CFG = array();
$_MCQ_CFG['send_prize'] = array(
    array(
        'ip' => '10.179.2.29',
        'port' => 22201
    ),
    array(
        'ip' => '10.179.24.148',
        'port' => 22201
    )
);

######################## �˺Ű�ȫ������ ############################
$_IP_CFG['safeService'] = array('ip' => '10.191.8.44', 'port' => 25500);

######################## CMEM ���� ############################
$_CMEM_CFG	=	array();
$_CMEM_CFG['smsCode']	=	array(
    'bid'			=>	102030152,
    'show_error'	=>	false,	//�Ƿ���ʾ����
    'timeout'		=>	1000,	//��ʱ����
    'freetime'		=>	10,		//����ʱ��
    'servers'		=>	array('10.191.132.11:9101', '10.191.132.12:9101')
);

$_CMEM_CFG['cate_hot_top5']	=	array(
    'bid'			=>	102030152,
    'show_error'	=>	false,	//�Ƿ���ʾ����
    'timeout'		=>	1000,	//��ʱ����
    'freetime'		=>	10,		//����ʱ��
    'servers'		=>	array('10.191.132.11:9101', '10.191.132.12:9101')
);

######################## ������������ ############################



// End of script
