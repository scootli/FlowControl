<?php
/**
 * CMEM配置 http://l5.oa.com 查询相关信息
 * @author bennylin
 * 2011/10/11
 */

$EC_CONF_CMEM = array();

//接入机组0
$EC_CONF_CMEM['ACCESS_0'] = array(
	'10.191.131.146:9101',
	'10.191.131.147:9101',
	'10.191.131.162:9101',
);

//下面是SimpleCmem的配置

//配置示例
$EC_CONF_CMEM['autopayback'] = array(
	'access_id' => 0,
	'bid' => 102030209,
	'prefix' => '',
	'pack' => 'serialize', //打包函数
	'unpack' => 'unserialize', //解包函数
	//'include' => '', //打、解包需要依赖的PHP文件路径
);

//礼品卡PN码
$EC_CONF_CMEM['giftcard_pncode'] = array(
	'access_id' => 0,
	'bid' => 102030225, //礼品卡pn码bid
	'prefix' => '', //线上bid不同，不需要前锥分辨
	'pack' => 'serialize', //打包函数
	'unpack' => 'unserialize', //解包函数
	//'include' => '', //打、解包需要依赖的PHP文件路径
);

//这里返回，要放在最后
return $EC_CONF_CMEM;
//end of script
