<?php

if (!defined('PHPLIB_ROOT')) {
	define('PHPLIB_ROOT', '/data/dev/PHPLIB/');
}

if (!defined('WEB_ROOT')) {
	define('WEB_ROOT', '/data/dev/webapp/');
}

if (!defined('LOG_ROOT')) {
	define('LOG_ROOT', '/data/devlogs/');
}

if (!defined('SERVER_ROOT')) {
	define('SERVER_ROOT', '/data/dev/server/');
}

###################### �ڲ� Server ���� ########################
$_IP_CFG = array();
$_IP_CFG['IDGenerator'] = "10.12.194.106:10100";
$_IP_CFG['sessiond'] = "10.12.194.106:10120";
$_IP_CFG['asytask'] = "10.6.222.47:10121";
$_IP_CFG['asytask2'] = "10.6.222.47:10121";
$_IP_CFG['reviewSystem'] = "10.12.194.106:10606";
$_IP_CFG['reviewFilter'] = "114.80.170.197:12338";
$_IP_CFG['promotion'] = "10.12.194.106:10101";
$_IP_CFG['traderPromotion'] = "10.12.194.106:10201";
$_IP_CFG['freqlimit'] = "10.12.194.106:10102";
$_IP_CFG['RetailerMultiPrice'] = "10.12.194.117:10132"; // ���SPP����
$_IP_CFG['RetailerCluster'] = "10.12.194.117:10133"; // ���SPP����
$_IP_CFG['ADVERTISE_PRE'] = array(
	'ERP_1'    => 'http://180.168.108.42:8062',
	'ERP_1001' => 'http://180.168.108.42:8062',
	'ERP_2001' => 'http://180.168.108.42:8060',
	'ERP_4001' => 'http://180.168.108.42:8034',
);

$_IP_CFG['USER_REGISTER_REPORT'] =  array(
		array('IP' => '10.191.8.44', 'PORT' => 59891),
		array('IP' => '10.191.8.44', 'PORT' => 59891)
);

// session �ֲ�ʽ��������
$_IP_CFG['sessiond_0'] = "10.12.194.106:10120";
$_IP_CFG['sessiond_1'] = "10.12.194.106:10120";
$_IP_CFG['IDGenerator_0'] = "10.12.194.106:10100";
$_IP_CFG['IDGenerator_1'] = "10.12.194.106:10100";
$_IP_CFG['OrderManagerCheck'] = '10.12.194.106:10607';
$_IP_CFG['OrderManager'] = '10.12.194.106:11616';
$_IP_CFG['ORDERFLOW'] = array();

$_IP_CFG['ORDERFLOW'] = array(
	'1'    => 'http://192.168.17.254:8020',
	'1001' => 'http://192.168.17.254:8022',
	'2001' => 'http://192.168.17.254:8024'
);

$_IP_CFG['safeService'] = array('ip' => '172.25.36.46', 'port' => 25500);

$_IP_CFG['SEARCH_PAIPAI'] = array('10.191.7.215', '10.191.8.161');
$_IP_CFG['SEARCH_SHOP'] = array('10.191.31.11', '10.191.31.12', '10.191.31.13');
$_IP_CFG['FLUSH_CACHE_SERVER'] = '10.12.194.106';

$_IP_CFG['QQ_OPENID'] = '10.12.194.115'; //ת��openid�Ľӿ� (101.226.52.124 ��������ַ)
$_IP_CFG['QQ_OPENIDS'] = array('10.12.194.115', '10.12.194.115'); //ת��openid�Ľӿ�
//�жϻ�ԱVIP�Ľӿ�
$_IP_CFG['QQ_VIP'] = array(
	'10.189.32.96',
	'10.189.48.143',
	'10.189.48.87',
	'10.189.48.91',
	'10.189.42.77',
	'10.189.42.78',
	'10.189.42.80',
	'10.189.42.81',
	'10.189.42.82',
	'10.189.40.65',
	'10.189.40.94',
	'10.189.40.95'
);
$_IP_CFG['QQ_GREEN'] = '172.25.32.105'; //�ж������Ա�Ľӿ� 113.108.7.179
$_IP_CFG['QQ_YEAR_VIP'] = '113.108.86.102'; //�ж���ѻ�ԱVIP�Ľӿ�
$_IP_CFG['QQ_BLUE'] = '10.179.2.163'; //�ж������Ա�ӿ�
$_IP_CFG['QQ_YELLOW'] = '113.108.7.167'; //�жϻ����Ա�ӿ�
$_IP_CFG['QQ_TOKEN'] = array('113.108.7.167', '10.129.136.83', '10.129.136.94'); //QQ_TOKEN��֤
$_IP_CFG['STAT_51BUY'] = array('101.226.49.43'); //stat_51buy��ip

$_IP_CFG['PERSONAL_SERVER'] = array(
	array('IP' => '10.12.194.115', 'PORT' => 40223),
);
$_IP_CFG['PERSONAL_GETDATA'] = array(
	array('IP' => '10.191.8.236', 'PORT' => 20010),
	array('IP' => '10.191.8.236', 'PORT' => 20010),
);
//���Ի��Ƽ��ӿ�
$_IP_CFG['PERSONAL_PV'] = array(
	array('IP' => '10.149.31.217', 'PORT' => 31305),
	array('IP' => '10.149.31.217', 'PORT' => 31305),
);
//���Ի��Ƽ�pv�ϱ�
$_IP_CFG['PERSONAL_CLICK'] = array(
	array('IP' => '10.149.31.217', 'PORT' => 31305),
	array('IP' => '10.149.31.217', 'PORT' => 31305),
);

$_IP_CFG['PERSONAL_LIKEGETDATA'] = array(
	array('IP' => '10.191.8.235', 'PORT' => 60010),
	array('IP' => '10.191.8.235', 'PORT' => 60011),
	array('IP' => '10.191.8.236', 'PORT' => 60010),
	array('IP' => '10.191.8.236', 'PORT' => 60011),
);

$_IP_CFG['PERSONAL_LIKEGETDATA_EVENT'] = array(
	array('IP' => '10.191.8.235', 'PORT' => 24010),
	array('IP' => '10.191.8.235', 'PORT' => 24011),
	array('IP' => '10.191.8.236', 'PORT' => 24010),
	array('IP' => '10.191.8.236', 'PORT' => 24011),
);

//���Ի��Ƽ�click�ϱ�

$_IP_CFG['ITEMRECOMMEND_GETDATA'] = array(
	array('IP' => '10.191.8.235', 'PORT' => 21010),
); // ����ҳ��Ʒ�Ƽ��ӿڷ���
$_IP_CFG['ITEMRECOMMEND_SERVER'] = array(
	array('IP' => '10.6.222.47', 'PORT' => 40223),
);
// ����ҳ��Ʒ�Ƽ���ת����
$_IP_CFG['ITEMRECOMMEND_PV'] = array(
	array('IP' => '10.191.136.205', 'PORT' => 41300),
);
// ����ҳ��Ʒ�Ƽ��ӿ�pv�ϱ�
$_IP_CFG['ITEMRECOMMEND_CLICK'] = array(
	array('IP' => '10.191.136.205', 'PORT' => 41300),
);
// ����ҳ��Ʒ�Ƽ��ӿ�click�ϱ�

// ���ﳵ���Ի��Ƽ�
$_IP_CFG['CART_GETDATA'] = array(
	array('IP' => '10.191.8.235', 'PORT' => 22010),
); // �ӿڷ���
$_IP_CFG['CART_SERVER'] = array(
	array('IP' => '10.6.222.47', 'PORT' => 40223),
);// ��ת����
$_IP_CFG['CART_PV'] = array(
	array('IP' => '10.149.31.217', 'PORT' => 31305),
);// pv�ϱ�
$_IP_CFG['AUTOPAYBACK'] = 'http://10.24.68.7:710'; //�Զ��۱�
$_IP_CFG['ip2city'][0] = array('IP' => '10.12.194.106', 'PORT' => 7000);
$_IP_CFG['ip2city'][1] = array('IP' => '10.12.194.106', 'PORT' => 7000);
$_IP_CFG['ip2city'][2] = array('IP' => '10.12.194.106', 'PORT' => 7000);
$_IP_CFG['ip2city'][3] = array('IP' => '10.12.194.106', 'PORT' => 7000);

$_IP_CFG['ipagent'] = array(
	array('IP' => '10.12.194.106', 'PORT' => 11239),
	array('IP' => '10.12.194.106', 'PORT' => 11239)
);

$_IP_CFG['verify_code'] = array(
	'code_server'  => array(
		array('IP' => '172.25.38.62', 'PORT' => 58032),
		array('IP' => '172.25.38.62', 'PORT' => 58032)
	),
	'check_server' => array(
		array('IP' => '172.25.38.62', 'PORT' => 58017),
		array('IP' => '172.25.38.62', 'PORT' => 58017)
	)
);


$_IP_CFG['priceSchemeMap'] = "10.12.194.106:21000";
###################### �ڲ� TTC ���� ########################
###################### �û�ģ�� ########################
$_TTC_CFG['ILimitTTC']['IP'] = "10.12.194.106:29071";
$_TTC_CFG['IUserPassTTC']['IP'] = "10.12.194.106:9050";
$_TTC_CFG['IEmailLoginTTC']['IP'] = "10.12.194.106:9051";
$_TTC_CFG['IIcsonLoginTTC']['IP'] = "10.12.194.106:9052";
$_TTC_CFG['ITelLoginTTC']['IP'] = "10.12.194.106:9053";
$_TTC_CFG['IQQLoginTTC']['IP'] = "10.12.194.106:9054";
$_TTC_CFG['IUsersTTC']['IP'] = "10.12.194.106:9055";
$_TTC_CFG['IUserAddressBookTTC']['IP'] = "10.12.194.106:9056";
$_TTC_CFG['IUserInvoiceBookTTC']['IP'] = "10.12.194.106:9057";
$_TTC_CFG['ICouponResourceTTC']['IP'] = "10.12.194.106:10958";
$_TTC_CFG['ICouponTTC']['IP'] = "10.12.194.106:9058";
$_TTC_CFG['IUserCouponIndexTTC']['IP'] = "10.12.194.106:9059";
$_TTC_CFG['IShoppingCartTTCNew']['IP'] = "10.12.194.106:9800";
$_TTC_CFG['IShoppingCartTTC']['IP'] = "10.12.194.106:9060";
$_TTC_CFG['IProductCommonInfoTTC']['IP'] = "10.12.194.106:9061";
$_TTC_CFG['IProductInfoTTC']['IP'] = "10.12.194.106:9062";
$_TTC_CFG['IProductIDMapTTC']['IP'] = "10.12.194.106:9063";
$_TTC_CFG['IProductRelativityTTC']['IP'] = "10.12.194.106:9064";
$_TTC_CFG['IPageCacheTTC']['IP'] = "10.12.194.106:9065";
$_TTC_CFG['ICategoryTTC']['IP'] = "10.12.194.106:9066";
$_TTC_CFG['IGiftTTC']['IP'] = "10.12.194.106:9067";
$_TTC_CFG['IShippingPriceTTC']['IP'] = "10.12.194.106:9068";
$_TTC_CFG['IShippingRegionTTC']['IP'] = "10.12.194.106:9069";
$_TTC_CFG['IClientSessionTTC']['IP'] = "10.12.194.106:9091";

$_TTC_CFG['IOrderProcessFlowTTC']['IP'] = "10.12.194.106:9555";
$_TTC_CFG['IProductDetailTTC']['IP'] = "10.12.194.106:9001";
$_TTC_CFG['IScoreFlowTTC']['IP'] = "10.12.194.106:9002";
$_TTC_CFG['IProductCommentTTC']['IP'] = "10.12.194.106:9003"; //TODO Not use
$_TTC_CFG['IProductReviewTTC']['IP'] = "10.12.194.106:9004"; //TODO c server
$_TTC_CFG['IProductReviewStatisticsTTC']['IP'] = "10.12.194.106:9005"; //TODO c server
$_TTC_CFG['IUserProductsTTC']['IP'] = "10.12.194.106:9006";
$_TTC_CFG['IUserReviewTTC']['IP'] = "10.12.194.106:9007"; //TODO c server
$_TTC_CFG['IUserReviewStatisticsTTC']['IP'] = "10.12.194.106:9008"; //TODO c server
$_TTC_CFG['IReplyTTC']['IP'] = "10.12.194.106:9009"; //TODO c server
$_TTC_CFG['IReviewTTC']['IP'] = "10.12.194.106:9010"; //TODO c server
$_TTC_CFG['IVoteTTC']['IP'] = "10.12.194.106:9011";
$_TTC_CFG['ISearchNavAttrTTC']['IP'] = "10.12.194.106:9012";
$_TTC_CFG['ISearchNavOptionTTC']['IP'] = "10.12.194.106:9013";
$_TTC_CFG['IKeyWordHotClassTTC']['IP'] = "10.12.194.106:9166";
$_TTC_CFG['IEventDetailTTC']['IP'] = "10.12.194.106:9167";
$_TTC_CFG['IEventStatistcsTTC']['IP'] = "10.12.194.106:9168";
$_TTC_CFG['IListRecommendTTC']['IP'] = "10.12.194.106:9169";
$_TTC_CFG['IVoteOptionTTC']['IP'] = "10.12.194.106:9014";
$_TTC_CFG['IManufacturerTTC']['IP'] = "10.12.194.106:9015";
$_TTC_CFG['ICPSCommissionTTC']['IP'] = "10.12.194.106:9820";
$_TTC_CFG['ICPSCommissionRateTTC']['IP'] = "10.12.194.106:9821";
$_TTC_CFG['ICPSPackagesTTC']['IP'] = "10.12.194.106:9822";
$_TTC_CFG['ICPSPluginsTTC']['IP'] = "10.12.194.106:9823";

$_TTC_CFG['IProductServiceTTC']['IP'] = "10.12.194.106:9088";

$_TTC_CFG['IPointFlowTTC']['IP'] = "10.12.194.106:20001";
$_TTC_CFG['IMultiPriceTTC']['IP'] = "10.12.194.106:9094";
$_TTC_CFG['IProductStockTTC']['IP'] = "10.12.194.106:9107";
$_TTC_CFG['IInventoryStockTTC']['IP'] = "10.12.194.106:9108";
$_TTC_CFG['IGiftNewTTC']['IP'] = "10.12.194.106:9109";
$_TTC_CFG['IPromotionRuleValidTTC']['IP'] = "10.12.194.106:9112";
$_TTC_CFG['IPromotionProductRuleMapTTC']['IP'] = "10.12.194.106:9113";
$_TTC_CFG['IPromotionUserRuleMapTTC']['IP'] = "10.12.194.106:9114";
$_TTC_CFG['IPromotionSendCouponTTC']['IP'] = "10.12.194.106:9115";
$_TTC_CFG['IGuiJiuPeiTTC']['IP'] = "10.12.194.106:10670";
$_TTC_CFG['IInvoiceSeparateTTC']['IP'] = "10.12.194.106:10671";
$_TTC_CFG['IUserTypeTTC']['IP'] = "10.12.194.106:19141";
$_TTC_CFG['IGiftCardTTC']['IP'] = "10.12.194.106:10672";
$_TTC_CFG['IGiftCardBatchTTC']['IP'] = "10.12.194.106:10674";
$_TTC_CFG['IGiftCardUserTTC']['IP'] = "10.12.194.106:10673";


#��ԴTTC
$_TTC_CFG['ISessionTTC']['IP'] = "10.12.194.106:9071";
$_TTC_CFG['IVerifyCodeTTC']['IP'] = "10.12.194.106:9070";
$_TTC_CFG['IUserReviewLimitTTC']['IP'] = "10.12.194.106:9099";
$_TTC_CFG['IBShoppingCartTTC']['IP'] = "10.12.194.106:31011";
$_TTC_CFG['IShoppingCartTTCtest']['IP'] = "10.12.194.106:10700"; //���ﳵ���ݽṹ�ı������
########################��������ģ��##########################
$_TTC_CFG['IBSessionTTC']['IP'] = "10.12.194.106:31001";
$_TTC_CFG['IRetailerShopTTC']['IP'] = "10.12.194.106:31002";
$_TTC_CFG['IRetailerSalesmanTTC']['IP'] = "10.12.194.106:31003";
$_TTC_CFG['IRetailerShopLogTTC']['IP'] = "10.12.194.106:31004";
$_TTC_CFG['IRetailerConfigTTC']['IP'] = "10.12.194.106:31005";
$_TTC_CFG['IBProductTTC']['IP'] = "10.12.194.106:31006";
$_TTC_CFG['IRetailerTTC']['IP'] = "10.12.194.106:31008";
$_TTC_CFG['IRetailerLoginTTC']['IP'] = "10.12.194.106:31029";
$_TTC_CFG['IRetailerPasswdTTC']['IP'] = "10.12.194.106:31028";
$_TTC_CFG['IRetailerNoticeTTC']['IP'] = "10.12.194.106:50112";
$_TTC_CFG['IRetailerShopguidTTC']['IP'] = "10.12.194.106:31009";
$_TTC_CFG['IBOrdersTTC']['IP'] = "10.12.194.106:31010";
$_TTC_CFG['IBOrderItemsTTC']['IP'] = "10.12.194.106:31012";
$_TTC_CFG['IRetailerCustomerTTC']['IP'] = "10.12.194.106:31013";
$_TTC_CFG['IRetailerCustomerMapTTC']['IP'] = "10.12.194.106:31014";

$_TTC_CFG['IDiyInfoTTC']['IP'] = "10.12.194.106:10900";
$_TTC_CFG['IDiyPowerTTC']['IP'] = "10.12.194.106:10901";
$_TTC_CFG['IDiyMatchTTC']['IP'] = "10.12.194.106:10902";
$_TTC_CFG['IDiyItemInfoTTC']['IP'] = "10.12.194.106:10903";
$_TTC_CFG['IDiyFilterTTC']['IP'] = "10.12.194.106:10904";
$_TTC_CFG['IDiyRecommednDetailTTC']['IP'] = "10.12.194.106:10905";
$_TTC_CFG['IDiyCacheTTC']['IP'] = "10.12.194.106:10906";
$_TTC_CFG['IDiyProductSortTTC']['IP'] = "10.12.194.106:10907";
$_TTC_CFG['IDiyUserMasterTTC']['IP'] = "10.12.194.106:10908";
$_TTC_CFG['IDiyUserItemTTC']['IP'] = "10.12.194.106:10909";
$_TTC_CFG['IActCountDownTTC']['IP'] = "10.12.194.106:10910";
$_TTC_CFG['ISearchWordTTC']['IP'] = "10.12.194.106:9096";
$_TTC_CFG['IAdItemDetailTTC']['IP'] = "10.12.194.106:9097";
$_TTC_CFG['IAdGroupTTC']['IP'] = "10.12.194.106:9121";
$_TTC_CFG['IAdPositionTTC']['IP'] = "10.12.194.106:9118";
$_TTC_CFG['IAdInfoTTC']['IP'] = "10.12.194.106:9119";
$_TTC_CFG['IAdMapTTC']['IP'] = "10.12.194.106:9120";

$_TTC_CFG['IEventApiImgTTC']['IP'] = "10.12.194.106:9899";

$_TTC_CFG['IKeyWordHotClassNewTTC']['IP'] = "10.12.194.106:9110";
$_TTC_CFG['IShortUrlTTC']['IP'] = "10.12.194.106:9122";
$_TTC_CFG['IUserExtensionTTC']['IP'] = "10.12.194.106:10111";
$_TTC_CFG['IEntrySourceTTC']['IP'] = "10.12.194.106:9081";

$_TTC_CFG['IOrderInvoiceTTC']['IP'] = "10.12.194.106:20002";
$_TTC_CFG['IOrdersTTC']['IP'] = "10.12.194.106:20003";
$_TTC_CFG['IOrderItemsTTC']['IP'] = "10.12.194.106:20006";
$_TTC_CFG['IModeProductMapTTC']['IP'] = "10.12.194.106:20004";
$_TTC_CFG['IMasterIdMapTTC']['IP'] = "10.12.194.106:20005";

$_TTC_CFG['IUsersQqMapTTC']['IP'] = "10.12.194.106:5050";
$_TTC_CFG['IOrdersNeedScoreBackTTC']['IP'] = "10.12.194.106:10099";

#####���ƻ�TTC#####
$_TTC_CFG['ICpBrandTTC']['IP'] = "10.12.194.106:24132";
$_TTC_CFG['ICpContractTTC']['IP'] = "10.12.194.106:24133";
$_TTC_CFG['ICpFeeTTC']['IP'] = "10.12.194.106:24137";
$_TTC_CFG['ICpNumTTC']['IP'] = "10.12.194.106:24135";
$_TTC_CFG['ICpSpNumTTC']['IP'] = "10.12.194.106:24136";
$_TTC_CFG['ICpPackageTTC']['IP'] = "10.12.194.106:24134";
$_TTC_CFG['ICpServiceProviderTTC']['IP'] = "10.12.194.106:24131";
$_TTC_CFG['ICpContractFeeTTC']['IP'] = "10.12.194.106:9129";
$_TTC_CFG['ICpFeeItemTTC']['IP'] = "10.12.194.106:9128";

#####���߹���ƽ̨TTC#####
$_TTC_CFG['IUserDeviceTTC']['IP'] = "10.12.194.106:9543";
$_TTC_CFG['IDeviceInfoTTC']['IP'] = "10.12.194.106:9544";
$_TTC_CFG['IPushMsgTTC']['IP'] = "10.12.194.106:9545";

########################## ��ǰ�ۺ��˿�ģ��TTC #############################
$_TTC_CFG['IBASBankSubBranchTTC']['IP'] = "10.12.194.106:9106";
$_TTC_CFG['IRMARequestTTC']['IP'] = "10.12.194.106:9104";
$_TTC_CFG['IRMARequestItemTTC']['IP'] = "10.12.194.106:9105";
$_TTC_CFG['IRMARegisterTTC']['IP'] = "10.12.194.106:9102";
$_TTC_CFG['IRMARegisterLogTTC']['IP'] = "10.12.194.106:9103";
$_TTC_CFG['IRMACustomerRequestNoteTTC']['IP'] = "10.12.194.106:9101";
$_TTC_CFG['IProductInstallMentBookTTC']['IP'] = "10.12.194.106:9111";
$_TTC_CFG['IRMACusLogTTC']['IP'] = "10.12.194.106:9143";
$_TTC_CFG['ISatisfactionSurveyTTC']['IP'] = "10.12.194.106:9144";

########################## �����Ż�ȯģ��TTC #############################
$_TTC_CFG['IMerchantsTTC']['IP'] = "10.12.194.106:9140";
$_TTC_CFG['IMerchantsCouponTypeTTC']['IP'] = "10.12.194.106:9141";
$_TTC_CFG['IMerchantsCouponIndexTTC']['IP'] = "10.12.194.106:9142";
$_TTC_CFG['IMerchantsCouponLogTTC']['IP'] = "10.12.194.106:9143";
$_TTC_CFG['IMerchantsCouponBatchIndexTTC']['IP'] = "10.12.194.106:9144";

########################## CPSƽ̨��ģ��TTC #############################

$_TTC_CFG['ICPSMerchantsTTC']['IP'] = "10.12.194.106:9145";
$_TTC_CFG['ICPSSysLogTTC']['IP'] = "10.12.194.106:9146";
$_TTC_CFG['ICPSConfigFeildsMapTTC']['IP'] = "10.12.194.106:9147";
$_TTC_CFG['ICPSOrderYiqifaTTC']['IP'] = "10.12.194.106:9150";
$_TTC_CFG['ICPSOrdersTTC']['IP'] = "10.12.194.106:9151";

########################## �ƽ̨TTC #############################
$_TTC_CFG['IVerifyObjectMapTTC']['IP'] = '10.12.194.106:9178';
$_TTC_CFG['IActAppointTTC']['IP'] = '10.12.194.106:9188';
$_TTC_CFG['IActAppointValueTTC']['IP'] = '10.12.194.106:9189';

########################## TMem ���� #############################
$_TMEM_CFG = array();

$_TMEM_CFG['verify_config'] = array(
	'IP' => '10.136.9.77:9101'
);
$_TMEM_CFG['data_cache'] = array(
	'IP' => '10.136.9.77:9101'
);
$_TMEM_CFG['event_data'] = array(
	'IP' => '10.136.9.77:9101'
);
$_TMEM_CFG['service_statistic'] = array(
	'IP' => '10.136.9.77:9101'
);
$_TMEM_CFG['service_center_unread_message'] = array(
		'IP' => '10.136.9.77:9101'
);

#################��������TTC###################
$_TTC_CFG['IServiceReplyTTC']['IP'] = "10.180.74.14:9190";
$_TTC_CFG['IServiceApplyTTC']['IP'] = "10.180.74.14:9191";
########################## TMem BID ���� #############################
define('TMEM_BID_VERIFY_CONFIG', 20120381);
define('TMEM_BID_DATA_CACHE', 20120381);
define('TMEM_BID_ACT_DATA', 20120381);
define('TMEM_BID_ACT_DATA_MAP', 20120381);
define('TMEM_BID_SERVICE_STATISTIC', 102030219);
define('TMEM_BID_SERVICE_CENTER_UNREAD_MESSAGE', 20120381);
########################## DB ���� #############################
$_DB_CFG = array();
$_DB_CFG['icson_admin_lovecar'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_lovecar', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_core'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_core', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_admin'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_admin', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['product_list'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'product_list', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_admin_event'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_admin_event', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_event_component'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_event_component', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_admin_store'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_admin_store', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_admin_stpage'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_admin_stpage', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_admin_log'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_admin_log', 'USER' => 'user_icson', 'PASSWD' => 'icson');

$_DB_CFG['cps_merchants'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'cps_merchants', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['cps_commission'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'cps_commission', 'USER' => 'user_icson', 'PASSWD' => 'icson');

//�������ע���е�������
$_DB_CFG['product_info'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_diy'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_diy', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_cps'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_cps', 'USER' => 'user_icson', 'PASSWD' => 'icson'); //CPS������
$_DB_CFG['icson_event'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_event', 'USER' => 'user_icson', 'PASSWD' => 'icson'); //icson event db
$_DB_CFG['icson_event_slave'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_event', 'USER' => 'user_icson', 'PASSWD' => 'icson'); //icson event db
$_DB_CFG['product_pool'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'product_pool', 'USER' => 'user_icson', 'PASSWD' => 'icson'); //��Ʒ��

$_DB_CFG['db_privilege'] = array('IP' => '10.152.23.179', 'PORT' => 9013, 'DB' => 'icson_admin_management', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['icson_data_management'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_data_management', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['cost_analysis'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_cost_analysis', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['icson_statistics'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_statistics', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['icson_core_ttc'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_core_ttc', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['icson_other_ttc'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_other_ttc', 'USER' => 'user_icson', 'PASSWD' => 'icson');

$_DB_CFG['retailer'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'retailer', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['orders'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'orders', 'USER' => 'user', 'PASSWD' => 'pass');

$_DB_CFG['retailer_orders'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'borders', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['retailer_order_items'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'border_items', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['retailer_customer'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'retailer_customer', 'USER' => 'user', 'PASSWD' => 'pass');

$_DB_CFG['loginfo'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'loginfo', 'USER' => 'user_icson', 'PASSWD' => 'icson'); // added by daopingsun  09:46 2012/8/17
$_DB_CFG['promotion'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'promotion', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['guijiupei'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'guijiupei', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_CFG['card_info'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'card_info', 'USER' => 'user', 'PASSWD' => 'pass');
########################## �����Ż�ȯģ��DB #############################
$_DB_CFG['merchants'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'merchants', 'USER' => 'user_icson', 'PASSWD' => 'icson'); // added by daopingsun  17:05 2012/9/4
$_DB_CFG['merchants_coupon_type'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'merchants_coupon_type', 'USER' => 'user_icson', 'PASSWD' => 'icson'); // added by daopingsun  17:05 2012/9/4


########################## ���߹���ƽ̨db #############################
$_DB_CFG['db_app_userdevice'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'app_userdevice_', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['db_app_deviceinfo'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'app_deviceinfo_', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['db_app_pushmsg'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'app_pushmsg_', 'USER' => 'user_icson', 'PASSWD' => 'icson');


########################## CPSƽ̨��ģ��DB #############################
$_DB_CFG['cps_merchants'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'cps_merchants', 'USER' => 'user_icson', 'PASSWD' => 'icson'); // added by daopingsun  11:05 2012/10/30
$_DB_CFG['cps_operate_log'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'cps_operate_log', 'USER' => 'user_icson', 'PASSWD' => 'icson'); // added by daopingsun  11:05 2012/12/21

########################## ���ƽ̨DB #############################
$_DB_CFG['act_data'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'act_data', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['act_data_map'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'act_data_map', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['prize_record'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'prize_record', 'USER' => 'user_icson', 'PASSWD' => 'icson');
########################## �ҵ�ƽ̨DB #############################
$_DB_CFG['jiadian_db'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'jiadian_db', 'USER' => 'user_icson', 'PASSWD' => 'icson');

########################## �Ż�ȯ��ˮDB #############################
$_DB_CFG['coupon_flow'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'coupon_flow', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['coupon_stat'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'coupon_staticstics', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['coupon_task'] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'coupon_task', 'USER' => 'user_icson', 'PASSWD' => 'icson');

$_DB_TABLE_CFG = array();
$_DB_TABLE_CFG['users'] = array('DB' => 'users', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['icson'] = array('DB' => 'icson', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 0);
$_DB_TABLE_CFG['icson_core'] = array('DB' => 'icson_core', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 0);
$_DB_TABLE_CFG['icson_core_ttc'] = array('DB' => 'icson_core_ttc', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 3);
$_DB_TABLE_CFG['user_pass'] = array('DB' => 'user_pass', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['email_login'] = array('DB' => 'email_login', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['tel_login'] = array('DB' => 'tel_login', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['icson_login'] = array('DB' => 'icson_login', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['coupon'] = array('DB' => 'coupon', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['coupon_cdb']  = array('DB' => 'coupon', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['user_coupon_index'] = array('DB' => 'user_coupon_index', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['cp_num'] = array('DB' => 'cp_num', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['cp_information'] = array('DB' => 'cp_information', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 0);
$_DB_TABLE_CFG['retailer'] = array('DB' => 'retailer', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 0);
$_DB_TABLE_CFG['orders'] = array('DB' => 'orders', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 0);
$_DB_TABLE_CFG['retailer_orders'] = array('DB' => 'borders', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['retailer_order_items'] = array('DB' => 'border_items', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['retailer_customer'] = array('DB' => 'retailer_customer', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=> 0);
$_DB_TABLE_CFG['icson_rma'] = array('DB' => 'ICSON_RMA', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 0);
$_DB_TABLE_CFG['card_info'] = array('DB' => 'card_info', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=> 0);
//��Ʒ��ȯ
$_DB_TABLE_CFG['promotion'] = array('DB' => 'promotion', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 0);
$_DB_TABLE_CFG['promotion_user_rule_map'] = array('DB' => 'promotion_user_rule_map', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=> 0);
//������
$_DB_TABLE_CFG['task_list'] = array('DB' => 'task_list', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 0);

$_DB_SERVER_CFG = array();
$_DB_SERVER_CFG['online'][0] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'IAS', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_SERVER_CFG['online'][1] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'IAS', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_SERVER_CFG['online'][2] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'cp_num', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_SERVER_CFG['online'][3] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'icson_core_ttc', 'USER' => 'user', 'PASSWD' => 'pass');
$_DB_SERVER_CFG['bakup'][0] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'IAS', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_SERVER_CFG['bakup'][1] = array('IP' => '10.12.194.106', 'PORT' => 3306, 'DB' => 'IAS', 'USER' => 'user_icson', 'PASSWD' => 'icson');

########################## MSDB ���� #############################
$_MSDB_CFG = array();

//�Ϻ�
#$_MSDB_CFG['ERP_1'] 	 = array( 'IP' => '10.12.194.113','PORT' => 1433,'DB' => 'IAS','USER' => 'sa', 'PASSWD' => '1' );
//����
#$_MSDB_CFG['ERP_1001'] 	 = array( 'IP' => '10.12.194.113','PORT' => 1433,'DB' => 'SZ_IAS','USER' => 'sa', 'PASSWD' => 'Icson2012' );


#$_MSDB_CFG['ERP_1']         = array( 'IP' => '10.12.194.113','PORT' => 1433,'DB' => 'SH_IAS','USER' => 'sa', 'PASSWD' => 'qatest');
$_MSDB_CFG['DMSDB'] = array('IP' => '10.12.194.114', 'PORT' => 1433, 'DB' => 'DMSDB', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_1'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'SH_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
#$_MSDB_CFG['ERP_1']         = array( 'IP' => '10.96.78.175','PORT' => 1433,'DB' => 'SH_IAS','USER' => 'sa', 'PASSWD' => 'rewq');
$_MSDB_CFG['Inventory_Manager'] = array('IP' => '10.12.194.114', 'PORT' => 1433, 'DB' => 'Inventory_Manager', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['Customer'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'Customer', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_1001'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'SZ_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_2001'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'BJ_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_3001'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'WH_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_4001'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'CQ_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_1002'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'SZ_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');

//����
$_MSDB_CFG['ERP_BAK_1'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'SH_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_BAK_1001'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'SZ_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_BAK_2001'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'BJ_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_BAK_3001'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'WH_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_BAK_4001'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'CQ_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ERP_BAK_1002'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'SZ_IAS', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');

$_MSDB_CFG['ICSON_Product'] =  array('IP' => '10.24.177.134', 'PORT' => 1433, 'DB' => 'ETL_Product', 'USER' => 'qq', 'PASSWD' => 'QQ123456!!');

//ͳ�Ʊ������ݿ�
$_MSDB_CFG['ICSON_STATISTIC'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'ICSON_STATISTICS_SALES', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ICSON_STATISTICS_SALES'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'ICSON_STATISTICS_SALES', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ICSON_STATISTIC_REAL'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'ICSON_STATISTICS_SALES', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ICSON_STATISTICS_CLICKFLOW'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'ICSON_STATISTICS_CLICKFLOW', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ICSON_STATISTIC_DISTRIBUTOR'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'ICSON_STATISTICS_SALES', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_CFG['ICSON_STATISTICS_WEB'] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'DB' => 'ICSON_STATISTICS_WEB', 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');


// railszhu�޸ģ�����������ϵ
$_MSDB_TABLE_CFG['Stock'] = array('DB' => 'ETL_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 8);
$_MSDB_TABLE_CFG['Product'] = array('DB' => 'ETL_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 8);
$_MSDB_TABLE_CFG['Category'] = array('DB' => 'ETL_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 8);
$_MSDB_TABLE_CFG['Product_Gift'] = array('DB' => 'ETL_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 8);

//�µ����Ŀ�����
$_MSDB_TABLE_CFG['ICSON_ORDER_CORE'] = array('DB' => 'ICSON_ORDER_CORE', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=> 0);
$_MSDB_TABLE_CFG['ICSON_CORE'] = array('DB' => 'ICSON_CORE', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 0);
$_MSDB_TABLE_CFG['ICSON_DATA_REPORT_BIJIA'] = array('DB' => 'ICSON_DATA_REPORT_BIJIA', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['ORDER_PROCESS_FLOW'] = array('DB' => 'HQ_SO', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['ERP_1'] = array('DB' => 'SH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 2);
$_MSDB_TABLE_CFG['Customer'] = array('DB' => 'Customer', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['ERP_1001'] = array('DB' => 'SZ_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 2);
$_MSDB_TABLE_CFG['ERP_2001'] = array('DB' => 'BJ_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 7);
$_MSDB_TABLE_CFG['ERP_3001'] = array('DB' => 'WH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['ERP_4001'] = array('DB' => 'SH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 4);
//$_MSDB_TABLE_CFG['ICSON_WORKFLOW']      = array('DB' => 'ICSON_WORKFLOW', 'DB_NUM' => 1,  'IP'=>0);
//$_MSDB_TABLE_CFG['ICSON_USERS']   = array('DB' => 'ICSON_USERS', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=>0);
$_MSDB_TABLE_CFG['SH_IAS'] = array('DB' => 'SH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['ICSON_STATISTICS_SALES'] = array('DB' => 'ICSON_STATISTICS_SALES', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['ICSON_STATISTICS_CLICKFLOW'] = array('DB' => 'ICSON_STATISTICS_CLICKFLOW', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 4);
$_MSDB_TABLE_CFG['ICSON_STATISTICS_WEB'] = array('DB' => 'ICSON_STATISTICS_WEB', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 7);
$_MSDB_TABLE_CFG['DMSDB'] = array('DB' => 'DMSDB', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 6);
$_MSDB_TABLE_CFG['Inventory_Manager'] = array('DB' => 'Inventory_Manager', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 6);
$_MSDB_TABLE_CFG['Icson_Finance'] = array('DB' => 'Icson_Finance', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 5);
//$_MSDB_TABLE_CFG['Product'] = array('DB' => 'ETL_Product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 8);
//PM��Ӧ������Ϣ
$_MSDB_TABLE_CFG['Pm_Department'] = array('DB' => 'ICSON_STATISTICS_PURCHASE', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 4);

$_MSDB_SERVER_CFG['online'][0] = array('IP' => '10.12.194.114', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
#$_MSDB_SERVER_CFG['online'][0] = array( 'IP' => '10.96.78.110','PORT' => 1433,'USER' => 'qq_sh', 'PASSWD' => 'qq2012' );
#$_MSDB_SERVER_CFG['online'][1] = array( 'IP' => '10.12.194.113','PORT' => 1433,'USER' => 'qq_sh', 'PASSWD' => 'qq2012' );
#$_MSDB_SERVER_CFG['online'][1] = array( 'IP' => '10.96.78.175','PORT' => 1433,'USER' => 'qq_sh', 'PASSWD' => 'rewq' );
$_MSDB_SERVER_CFG['online'][1] = array('IP' => '10.12.194.114', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['online'][2] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['online'][3] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['online'][4] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['online'][5] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['online'][6] = array('IP' => '10.12.194.114', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['online'][7] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['online'][8] = array('IP' => '10.24.177.134', 'PORT' => 1433, 'USER' => 'qq', 'PASSWD' => 'QQ123456!!');
$_MSDB_SERVER_CFG['bakup'][0] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['bakup'][1] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['bakup'][2] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['bakup'][3] = array('IP' => '10.12.194.113', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
$_MSDB_SERVER_CFG['bakup'][4] = array('IP' => '10.12.194.114', 'PORT' => 1433, 'USER' => 'qq_sh', 'PASSWD' => 'qq2012');
######################## Cache ���� ############################
$_CACHE_CFG = array();

######################## CMEM ���� ############################
$_CMEM_CFG	=	array();
$_CMEM_CFG['smsCode']	=	array(
	'bid'			=>	102030152,
	'show_error'	=>	false,	//�Ƿ���ʾ����
	'timeout'		=>	1000,	//��ʱ����
	'freetime'		=>	10,		//����ʱ��
	'servers'		=>	array('10.191.132.11:9101', '10.191.132.12:9101')
);

$_CMEM_CFG['cate_hot_top5']	=	array(
	'showError'	=>	true,
	'timeout'	=>	1,
	'freeTime'	=>	20,
	'bid'		=>	20120409,
	'servers'	=>	array('10.136.9.77:9101')
);

######################## ��Ϣ�������� ############################
//define('ASYNC_PROF_KEY', 0x100001); // �첽�����û�������Ϣ����
$_MCQ_CFG = array();
$_MCQ_CFG['send_prize'] = array(
	array(
		'ip' => '10.12.194.115',
		'port' => 22203
	),
	array(
		'ip' => '10.12.194.115',
		'port' => 22204
	),
);


######################## ������������ ############################

$_CPS_SERVER_CONFIG['PSFOrderPusher'] = array('IP' => '10.12.194.124', 'PORT' => 10003);
$_CPS_SERVER_CONFIG['PSFOrderComputing'] = array('IP' => '10.12.194.124', 'PORT' => 10002);
$_CPS_SERVER_CONFIG['PSFService'] = array('IP' => '10.12.194.124', 'PORT' => 10004);
$_CPS_SERVER_CONFIG['PSFOrderReceiver'] = array('IP' => '10.12.194.124', 'PORT' => 10001);
$_CPS_SERVER_CONFIG['PSFOrderToERP'] = array('IP' => '10.12.194.124', 'PORT' => 10005);
// End of script

