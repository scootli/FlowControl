<?php
/**
 * DB����
 * @author bennylin
 * 2009-9-17
 */

define('DB_TYPE_MYSQL', 1);
define('DB_TYPE_MSSQL', 2);

$EC_CONF_DB = array();

//����ʾ��
//$EC_CONF_DB['example'] = array(
	//'host' => '127.0.0.1',
	//'port' => '3306',
	//'user' => 'work',
	//'password' => 'work',
	//'database' => 'test',
	//'charset' => 'utf8',
	//'type' => DB_TYPE_MYSQL,
//);

$EC_CONF_DB['Test1'] = array(
	'host' => '10.12.194.113',
	'port' => '1433',
	'user' => 'qq_sh',
	'password' => 'qq2012',
	'database' => 'Test1',
	//'charset' => 'utf8',
	'type' => DB_TYPE_MSSQL,
);

$EC_CONF_DB['ICSON_ORDER_CORE'] = array(
	'host' => '10.96.78.110',
	'port' => '1433',
	'user' => 'sa',
	'password' => '1',
	'database' => 'ICSON_ORDER_CORE',
	//'charset' => '',
	'type' => DB_TYPE_MSSQL,
	'db_num' => 10,
	'table_num' => 100,
);

$EC_CONF_DB['ICSON_CORE'] = array(
	'host' => '10.96.78.110',
	'port' => '1433',
	'user' => 'sa',
	'password' => '1',
	'database' => 'ICSON_CORE',
	//'charset' => '',
	'type' => DB_TYPE_MSSQL,
);

$EC_CONF_DB['Inventory_Manager'] = array(
	'host' => '10.24.177.134',
	'port' => '1433',
	'user' => 'qq',
	'password' => 'QQ123456!!',
	'database' => 'Inventory_Manager',
	//'charset' => '',
	'type' => DB_TYPE_MSSQL,
);

//�����践�ط����
return $EC_CONF_DB;