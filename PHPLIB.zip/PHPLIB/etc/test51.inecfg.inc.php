<?php

if ( !defined('PHPLIB_ROOT') ) {
    define('PHPLIB_ROOT', '/data/dev/PHPLIB/');
}

if ( !defined('WEB_ROOT') ) {
    define('WEB_ROOT', '/data/dev/webapp/');
}

if ( !defined('LOG_ROOT') ) {
    define('LOG_ROOT', '/data/devlogs/');
}

if (!defined('SERVER_ROOT')) {
	define('SERVER_ROOT', '/data/dev/server/');
}

###################### �ڲ� Server ���� ########################
$_IP_CFG = array();
$_IP_CFG['IDGenerator']   = "10.24.177.53:10100";
$_IP_CFG['sessiond']      = "10.24.177.53:10120";
$_IP_CFG['asytask']       = "10.24.177.53:10121";
$_IP_CFG['reviewSystem']  = "10.24.177.53:10606";
$_IP_CFG['reviewFilter']  = "192.168.2.34:12338";
$_IP_CFG['traderPromotion']  = "10.24.177.53:10201";
$_IP_CFG['promotion']  = "10.24.177.53:10101";
$_IP_CFG['freqlimit']  = "10.24.177.53:10102";
$_IP_CFG['RetailerMultiPrice'] = "10.24.177.53:10132"; // ���SPP����
$_IP_CFG['RetailerCluster'] = "10.24.177.53:10133"; // �����ۺ�SPP����
$_IP_CFG['ADVERTISE_PRE'] = array(
	'ERP_1' => 'http://180.168.108.42:8021',
	'ERP_1001' => 'http://180.168.108.42:8023',
	'ERP_2001' => 'http://180.168.108.42:8025',
	'ERP_4001' => 'http://180.168.108.42:8029',
);

// session �ֲ�ʽ��������
$_IP_CFG['sessiond_0']    = "10.24.177.53:10120";
$_IP_CFG['sessiond_1']    = "10.24.177.58:10120";
$_IP_CFG['IDGenerator_0']   = "10.24.177.53:10100";
//$_IP_CFG['IDGenerator_1']   = "10.96.78.108:10100";
$_IP_CFG['IDGenerator_1']   = "10.24.177.58:10100";
$_IP_CFG['OrderManagerCheck'] = '10.24.177.53:11616';
$_IP_CFG['OrderManager'] = '10.24.177.53:10607';
$_IP_CFG['ORDERFLOW'] = array();

$_IP_CFG['ORDERFLOW'] = array(
	'1' => 'http://10.24.68.7:810',
	'1001' => 'http://10.24.68.7:810',
	'2001' => 'http://10.24.68.7:810'
);

$_IP_CFG['SEARCH_PAIPAI'] = array('10.12.194.101');
$_IP_CFG['SEARCH_SHOP'] = array('121.14.76.225', '121.14.76.225');
$_IP_CFG['FLUSH_CACHE_SERVER'] = '10.96.78.101';

$_IP_CFG['QQ_OPENID'] = '101.226.52.124';//ת��openid�Ľӿ�
$_IP_CFG['QQ_OPENIDS'] = array('101.226.52.124', '101.226.52.124');//ת��openid�Ľӿ�
//�жϻ�ԱVIP�Ľӿ�
$_IP_CFG['QQ_VIP'] = array(
	'10.189.32.96',
	'10.189.48.143',
	'10.189.48.87',
	'10.189.48.91',
	'10.189.42.77',
	'10.189.42.78',
	'10.189.42.80',
	'10.189.42.81',
	'10.189.42.82',
	'10.189.40.65',
	'10.189.40.94',
	'10.189.40.95'
);
$_IP_CFG['QQ_GREEN'] = '113.108.7.179';//�ж������Ա�Ľӿ�
$_IP_CFG['QQ_YEAR_VIP'] = '113.108.86.102';//�ж���ѻ�ԱVIP�Ľ�
$_IP_CFG['QQ_BLUE'] = '10.179.2.163';//�ж������Ա�ӿ�
$_IP_CFG['QQ_YELLOW'] = '113.108.7.167';//�жϻ����Ա�ӿ�
$_IP_CFG['QQ_TOKEN'] = array('113.108.7.167', '10.129.136.83', '10.129.136.94');//QQ_TOKEN��֤

$_IP_CFG['ip2city'][0]	  = array('IP' => '10.24.177.53', 'PORT' => 7000);
$_IP_CFG['ip2city'][1]	  = array('IP' => '10.24.177.53', 'PORT' => 7000);
$_IP_CFG['ip2city'][2]	  = array('IP' => '10.24.177.53', 'PORT' => 7000);
$_IP_CFG['ip2city'][3]	  = array('IP' => '10.24.177.53', 'PORT' => 7000);

$_IP_CFG['ipagent'] = array(
	array('IP' => '10.24.177.53', 'PORT' => 11239),
	array('IP' => '10.24.177.53', 'PORT' => 11239)
);

$_IP_CFG['verify_code'] = array(
	'code_server' => array(
		array( 'IP' => '172.25.38.62', 'PORT' => 58032 ),
		array( 'IP' => '172.25.38.62', 'PORT' => 58032 )
	),
	'check_server' => array(
		array( 'IP' => '172.25.38.62', 'PORT' => 58017 ),
		array( 'IP' => '172.25.38.62', 'PORT' => 58017 )
	)
);

$_IP_CFG['PERSONAL_SERVER'] = array(
	array('IP' => '10.180.76.18', 'PORT' => 40223),
);
$_IP_CFG['PERSONAL_GETDATA'] = array(
	array('IP' => '10.191.8.235', 'PORT' => 50010),
	array('IP' => '10.191.8.236', 'PORT' => 50010),
	array('IP' => '10.191.8.235', 'PORT' => 50011),
	array('IP' => '10.191.8.236', 'PORT' => 50011),
);//���Ի��Ƽ��ӿ�
$_IP_CFG['PERSONAL_PV'] = array(
	array('IP' => '10.149.31.217', 'PORT' => 31305),
);//���Ի��Ƽ�pv�ϱ�
$_IP_CFG['PERSONAL_CLICK'] =array(
	array('IP' => '10.149.31.217', 'PORT' => 31305),
);//��
$_IP_CFG['PERSONAL_LIKEGETDATA'] = array(
	array('IP' => '10.191.8.235', 'PORT' => 60010),
	array('IP' => '10.191.8.235', 'PORT' => 60011),
	array('IP' => '10.191.8.236', 'PORT' => 60010),
	array('IP' => '10.191.8.236', 'PORT' => 60011),
);

$_IP_CFG['ITEMRECOMMEND_GETDATA'] = array(
	array('IP' => '10.191.8.235', 'PORT' => 21010),
	array('IP' => '10.191.8.236', 'PORT' => 21010),
); // ����ҳ��Ʒ�Ƽ��ӿڷ���
$_IP_CFG['ITEMRECOMMEND_SERVER'] = array(
	array('IP' => '10.180.76.18', 'PORT' => 40223),
);// ����ҳ��Ʒ�Ƽ���ת����
$_IP_CFG['ITEMRECOMMEND_PV'] = array(
	array('IP' => '10.191.136.205', 'PORT' => 41300),
	array('IP' => '10.191.136.205', 'PORT' => 41300),
);// ����ҳ��Ʒ�Ƽ��ӿ�pv�ϱ�
$_IP_CFG['ITEMRECOMMEND_CLICK'] = array(
	array('IP' => '10.191.136.205', 'PORT' => 41300),
	array('IP' => '10.191.136.205', 'PORT' => 41300),
);// ����ҳ��Ʒ�Ƽ��ӿ�click�ϱ�

// ���ﳵ���Ի��Ƽ�
$_IP_CFG['CART_GETDATA'] = array(
	array('IP' => '10.191.8.235', 'PORT' => 22010),
	array('IP' => '10.191.8.235', 'PORT' => 22011),
	array('IP' => '10.191.8.236', 'PORT' => 22010),
	array('IP' => '10.191.8.236', 'PORT' => 22011),
); // �ӿڷ���
$_IP_CFG['CART_SERVER'] = array(
	array('IP' => '10.180.76.18', 'PORT' => 40223),
);// ��ת����
$_IP_CFG['CART_PV'] = array(
	array('IP' => '10.191.136.205', 'PORT' => 41400),
);// pv�ϱ�

$_IP_CFG['PAYFOREXPENSIVENESS'] = 'http://10.24.68.7:810'; //�����
$_IP_CFG['AUTOPAYBACK'] = 'http://10.24.68.5:804'; //�Զ��۱�

$_IP_CFG['VERIFY_IDENTITY'] =  array(
	array('IP' => '172.25.36.46', 'PORT' => 25500),
	array('IP' => '172.25.36.46', 'PORT' => 25500)
);
$_IP_CFG['VERIFY_IDENTITY_CHANGEPWD_HINT'] =  array(
		array('IP' => '172.25.36.46', 'PORT' => 26500),
		array('IP' => '172.25.36.46', 'PORT' => 26500)
);

$_IP_CFG['USER_CHANGE_PWD_REPORT'] =  array(
		array('IP' => '172.25.36.46', 'PORT' => 50010),
		array('IP' => '172.25.36.46', 'PORT' => 50010)
);
###################### �ڲ� TTC ���� ########################
###################### �û�ģ�� ########################
$_TTC_CFG['ILimitTTC']['IP']            = "10.24.177.53:29071";
$_TTC_CFG['IUserPassTTC']['IP']            = "10.24.177.53:9050";
$_TTC_CFG['IEmailLoginTTC']['IP']          = "10.24.177.53:9051";
$_TTC_CFG['IIcsonLoginTTC']['IP']          = "10.24.177.53:9052";
$_TTC_CFG['ITelLoginTTC']['IP']            = "10.24.177.53:9053";
$_TTC_CFG['IQQLoginTTC']['IP']             = "10.24.177.53:9054";
$_TTC_CFG['IUsersTTC']['IP']               = "10.24.177.53:9055";
$_TTC_CFG['IUserAddressBookTTC']['IP']     = "10.24.177.53:9056";
$_TTC_CFG['IUserInvoiceBookTTC']['IP']     = "10.24.177.53:9057";
$_TTC_CFG['ICouponTTC']['IP']              = "10.24.177.53:9058";
$_TTC_CFG['ICouponResourceTTC']['IP']      = "10.24.177.53:9116";
$_TTC_CFG['IUserCouponIndexTTC']['IP']     = "10.24.177.53:9059";
$_TTC_CFG['IShoppingCartTTC']['IP']        = "10.24.177.53:9060";
$_TTC_CFG['IShoppingCartTTCNew']['IP']     = "10.24.177.53:9800";
$_TTC_CFG['IProductCommonInfoTTC']['IP']   = "10.24.177.53:9061";
$_TTC_CFG['IProductInfoTTC']['IP']         = "10.24.177.53:9062";
$_TTC_CFG['IProductIDMapTTC']['IP']        = "10.24.177.53:9063";
$_TTC_CFG['IProductRelativityTTC']['IP']   = "10.24.177.53:9064";
$_TTC_CFG['IPageCacheTTC']['IP']           = "10.24.177.53:9065";
$_TTC_CFG['ICategoryTTC']['IP']            = "10.24.177.53:9066";
$_TTC_CFG['IGiftTTC']['IP']                = "10.24.177.53:9067";
$_TTC_CFG['IShippingPriceTTC']['IP']       = "10.24.177.53:9068";
$_TTC_CFG['IShippingRegionTTC']['IP']      = "10.24.177.53:9069";
$_TTC_CFG['IClientSessionTTC']['IP']      	= "10.24.177.53:9091";
$_TTC_CFG['IGiftNewTTC']['IP']         		= "10.24.177.53:9109";
$_TTC_CFG['IOrderProcessFlowTTC']['IP']     = "10.24.177.53:9555";
$_TTC_CFG['IProductDetailTTC']['IP']        = "10.24.177.53:9001";
$_TTC_CFG['IScoreFlowTTC']['IP']            = "10.24.177.53:9002";
$_TTC_CFG['IProductCommentTTC']['IP']       = "10.24.177.53:9003"; //TODO Not use
$_TTC_CFG['IProductReviewTTC']['IP']        = "10.24.177.53:9004"; //TODO c server
$_TTC_CFG['IProductReviewStatisticsTTC']['IP']= "10.24.177.53:9005"; //TODO c server
$_TTC_CFG['IUserProductsTTC']['IP']         = "10.24.177.53:9006";
$_TTC_CFG['IUserReviewTTC']['IP']           = "10.24.177.53:9007"; //TODO c server
$_TTC_CFG['IUserReviewStatisticsTTC']['IP'] = "10.24.177.53:9008"; //TODO c server
$_TTC_CFG['IReplyTTC']['IP']                = "10.24.177.53:9009"; //TODO c server
$_TTC_CFG['IReviewTTC']['IP']               = "10.24.177.53:9010"; //TODO c server
$_TTC_CFG['IVoteTTC']['IP']                 = "10.24.177.53:9011";
$_TTC_CFG['ISearchNavAttrTTC']['IP']        = "10.24.177.53:9012";
$_TTC_CFG['ISearchNavOptionTTC']['IP']      = "10.24.177.53:9013";
$_TTC_CFG['IKeyWordHotClassTTC']['IP']      = "10.24.177.53:9166";
$_TTC_CFG['IEventDetailTTC']['IP']      = "10.24.177.53:9167";
$_TTC_CFG['IEventStatistcsTTC']['IP']      = "10.24.177.53:9168";
$_TTC_CFG['IListRecommendTTC']['IP']      = "10.24.177.53:9169";
$_TTC_CFG['IVoteOptionTTC']['IP']           = "10.24.177.53:9014";
$_TTC_CFG['IManufacturerTTC']['IP']         = "10.24.177.53:9015";
$_TTC_CFG['IProductServiceTTC']['IP']      = "10.24.177.53:9017";
$_TTC_CFG['ISearchWordTTC']['IP']          = "10.24.177.53:9096";
$_TTC_CFG['IAdItemDetailTTC']['IP']        = "10.24.177.53:9097";
$_TTC_CFG['IAdGroupTTC']['IP']             = "10.24.177.53:9121";
$_TTC_CFG['IAdPositionTTC']['IP']          = "10.24.177.53:9118";
$_TTC_CFG['IAdInfoTTC']['IP']              = "10.24.177.53:9119";
$_TTC_CFG['IAdMapTTC']['IP']               = "10.24.177.53:9120";
$_TTC_CFG['IKeyWordHotClassNewTTC']['IP']  = "10.24.177.53:9110";
$_TTC_CFG['IShortUrlTTC']['IP']  		   = "10.24.177.53:9122";
$_TTC_CFG['IProductStockTTC']['IP'] = "10.24.177.53:9107";
$_TTC_CFG['IInventoryStockTTC']['IP'] = "10.24.177.53:9108";
$_TTC_CFG['IPromotionRuleValidTTC']['IP']= "10.24.177.53:9112";
$_TTC_CFG['IPromotionProductRuleMapTTC']['IP']= "10.24.177.53:9113";
$_TTC_CFG['IPromotionUserRuleMapTTC']['IP']= "10.24.177.53:9114";
$_TTC_CFG['IPromotionSendCouponTTC']['IP']= "10.24.177.53:9115";
$_TTC_CFG['IPointFlowTTC']['IP']         = "10.24.177.53:20001";
$_TTC_CFG['IGuiJiuPeiTTC']['IP']         = "10.24.177.53:9139";
$_TTC_CFG['IGiftCardTTC']['IP']         = "10.24.177.53:10672";
$_TTC_CFG['IGiftCardBatchTTC']['IP']         = "10.24.177.53:10674";
$_TTC_CFG['IGiftCardUserTTC']['IP']         = "10.24.177.53:10673";
$_TTC_CFG['IDelayOrderTTC']['IP'] = "10.24.177.53:9174";
$_TTC_CFG['IVerifyUserIdentityTTC']['IP'] = "10.24.177.53:11128";

#��ԴTTC
$_TTC_CFG['ISessionTTC']['IP']              = "10.24.177.53:9071";
$_TTC_CFG['IVerifyCodeTTC']['IP']           = "10.24.177.53:9070";
$_TTC_CFG['IUserReviewLimitTTC']['IP']         = "10.24.177.53:9099";
$_TTC_CFG['IBShoppingCartTTC']['IP']         = "10.24.177.53:9135";

#################��������TTC###################
$_TTC_CFG['IServiceReplyTTC']['IP'] = "10.24.177.53:12162";
$_TTC_CFG['IServiceApplyTTC']['IP'] = "10.24.177.53:12161";


########################��������ģ��##########################
$_TTC_CFG['IBSessionTTC']['IP']         = "10.24.177.53:31001";
$_TTC_CFG['IRetailerShopTTC']['IP']     = "10.24.177.53:31002";
$_TTC_CFG['IRetailerSalesmanTTC']['IP'] = "10.24.177.53:31003";
$_TTC_CFG['IRetailerShopLogTTC']['IP']  = "10.24.177.53:31004";
$_TTC_CFG['IRetailerConfigTTC']['IP']   = "10.24.177.53:31005";
$_TTC_CFG['IBProductTTC']['IP']         = "10.24.177.53:31006";
$_TTC_CFG['IRetailerTTC']['IP']         = "10.24.177.53:31008";
$_TTC_CFG['IRetailerShopguidTTC']['IP']         = "10.24.177.53:9134";
$_TTC_CFG['IBOrdersTTC']['IP']         = "10.24.177.53:9130";
$_TTC_CFG['IBOrderItemsTTC']['IP']         = "10.24.177.53:9131";
$_TTC_CFG['IRetailerCustomerTTC']['IP']         = "10.24.177.53:9132";
$_TTC_CFG['IRetailerCustomerMapTTC']['IP']         = "10.24.177.53:9133";
$_TTC_CFG['IRetailerLoginTTC']['IP']         = "10.24.177.53:9152";
$_TTC_CFG['IRetailerPasswdTTC']['IP']         = "10.24.177.53:9153";
$_TTC_CFG['IRetailerOrderItemsTTC']['IP'] = "10.24.177.53:9148";
$_TTC_CFG['IRetailerOrderProcessFlowTTC']['IP'] = "10.24.177.53:9149";
$_TTC_CFG['IRetailerOrdersTTC']['IP'] = "10.24.177.53:9151";
$_TTC_CFG['IRetailerParamTTC']['IP'] = "10.24.177.53:9198";
$_TTC_CFG['IBannerTTC']['IP'] = "10.96.78.106:9192";


$_TTC_CFG['IDiyInfoTTC']['IP']   = "10.24.177.53:10900";
$_TTC_CFG['IDiyPowerTTC']['IP']     = "10.24.177.53:10901";
$_TTC_CFG['IDiyMatchTTC']['IP']   = "10.24.177.53:10902";
$_TTC_CFG['IDiyItemInfoTTC']['IP']  = "10.24.177.53:10903";
$_TTC_CFG['IDiyFilterTTC']['IP']   = "10.24.177.53:10904";
$_TTC_CFG['IDiyRecommednDetailTTC']['IP']  = "10.24.177.53:10905";
$_TTC_CFG['IDiyCacheTTC']['IP']  = "10.24.177.53:10906";
$_TTC_CFG['IDiyProductSortTTC']['IP']  = "10.24.177.53:10907";
$_TTC_CFG['IDiyUserMasterTTC']['IP']  = "10.24.177.53:10908";
$_TTC_CFG['IDiyUserItemTTC']['IP']  = "10.24.177.53:10909";
$_TTC_CFG['IActCountDownTTC']['IP']  = "10.24.177.53:10910";

$_TTC_CFG['IUserExtensionTTC']['IP']  = "10.24.177.53:10111";
$_TTC_CFG['IEntrySourceTTC']['IP']    = "10.24.177.53:9081";
$_TTC_CFG['IUserTypeTTC']['IP']       = "10.24.177.53:9141";

$_TTC_CFG['IOrderInvoiceTTC']['IP']  = "10.24.177.53:20002";
$_TTC_CFG['IOrdersTTC']['IP']    = "10.24.177.53:20003";
$_TTC_CFG['IOrderItemsTTC']['IP']    = "10.24.177.53:20006";
$_TTC_CFG['IModeProductMapTTC']['IP']  = "10.24.177.53:20004";
$_TTC_CFG['IMasterIdMapTTC']['IP']    = "10.24.177.53:20005";
$_TTC_CFG['IMultiPriceTTC']['IP']          = "10.24.177.53:10200";
$_TTC_CFG['ICpContractTTC']['IP'] = "10.24.177.53:24133";
$_TTC_CFG['IOrdersNeedScoreBackTTC']['IP']        = "10.24.177.53:10099";
$_TTC_CFG['IUsersQqMapTTC']['IP'] = "10.24.177.53:9098";

$_TTC_CFG['IEventApiImgTTC']['IP']  = "10.24.177.53:9899";
####################��ĩ�ع˻###########
$_TTC_CFG['IUserHistoryTTC']['IP'] = "10.24.177.53:20041";
$_TTC_CFG['IUserPrizeInfoTTC']['IP'] = "10.24.177.53:20042";
########################���ƻ�TTC##########################
$_TTC_CFG['ICpContractFeeTTC']['IP'] = "10.24.177.53:9129";
$_TTC_CFG['ICpFeeItemTTC']['IP']     = "10.24.177.53:9128";
########################## DB ���� #############################
$_DB_CFG = array();
$_DB_CFG['icson_core']     = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_core','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_admin']    = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_admin','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['product_list']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'product_list', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['promotion'] 		= array('IP'=>'10.24.177.53' ,'PORT' => 3306 ,'DB'=>'promotion','USER'=>'user_icson','PASSWD'=>'icson');
$_DB_CFG['icson_admin_data']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_admin_data', 'USER' => 'user_icson', 'PASSWD' => 'icson' );

########################## ��ǰ�ۺ��˿�ģ��TTC #############################
$_TTC_CFG['IBASBankSubBranchTTC']['IP'] = "10.24.177.53:9073";
$_TTC_CFG['IRMARequestTTC']['IP'] = "10.24.177.53:9077";
$_TTC_CFG['IRMARequestItemTTC']['IP'] = "10.24.177.53:9078";
$_TTC_CFG['IRMARegisterTTC']['IP'] = "10.24.177.53:9079";
$_TTC_CFG['IRMARegisterLogTTC']['IP'] = "10.24.177.53:9080";
$_TTC_CFG['IRMACustomerRequestNoteTTC']['IP'] = "10.24.177.53:9082";
$_TTC_CFG['IProductInstallMentBookTTC']['IP'] = "10.24.177.53:9083";
$_TTC_CFG['IRMACusLogTTC']['IP'] = "10.24.177.53:9089";
$_TTC_CFG['ISatisfactionSurveyTTC']['IP'] = "10.24.177.53:9090";

########################## �����Ż�ȯģ��TTC #############################
$_TTC_CFG['IMerchantsTTC']['IP'] = "10.24.177.53:9123";
$_TTC_CFG['IMerchantsCouponTypeTTC']['IP'] = "10.24.177.53:9124";
$_TTC_CFG['IMerchantsCouponIndexTTC']['IP'] = "10.24.177.53:9125";
$_TTC_CFG['IMerchantsCouponLogTTC']['IP'] = "10.24.177.53:9126";
$_TTC_CFG['IMerchantsCouponBatchIndexTTC']['IP'] = "10.24.177.53:9127";

#####���߹���ƽ̨TTC#####
$_TTC_CFG['IUserDeviceTTC']['IP'] = "10.96.78.106:9543";
$_TTC_CFG['IDeviceInfoTTC']['IP'] = "10.96.78.106:9544";
$_TTC_CFG['IPushMsgTTC']['IP'] = "10.96.78.106:9545";

###CPS2.0###
$_TTC_CFG['ICPSCommissionTTC']['IP']			 = "10.24.177.53:9156";
$_TTC_CFG['ICPSCommissionRateTTC']['IP']		 = "10.24.177.53:9157";
$_TTC_CFG['ICPSCommissionRateCategoryTTC']['IP'] = "10.24.177.53:9161";
$_TTC_CFG['ICPSMerchantsTTC']['IP']				 = "10.24.177.53:9159";
$_TTC_CFG['ICPSTmpDataTTC']['IP']				 = "10.24.177.53:9176";
$_TTC_CFG['ICPSOrdersTimelineTTC']['IP']		 = "10.24.177.53:9177";
$_TTC_CFG['ICPSSysLogTTC']['IP']				 = "10.24.177.53:9170";
$_TTC_CFG['ICPSOrdersTTC']['IP']				 = "10.24.177.53:9163";
$_TTC_CFG['ICPSPackagesTTC']['IP']				 = "10.24.177.53:9165";
########################## �ƽ̨TTC #############################
$_TTC_CFG['IVerifyObjectMapTTC']['IP'] = '10.24.177.53:9178';
$_TTC_CFG['IActAppointTTC']['IP'] = '10.24.177.53:9188';
$_TTC_CFG['IActAppointValueTTC']['IP'] = '10.24.177.53:9189';

########################## TMem IP ���� #############################
$_TMEM_CFG = array();

$_TMEM_CFG['verify_config'] = array(
	'IP' => '10.136.9.77:9101'
);

########################## TMem BID ���� #############################
define('TMEM_BID_VERIFY_CONFIG', 20120381);

//�������ע���е�������
$_DB_CFG['cps_sys_log'] = array('IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'cps_sys_log_', 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['cps_merchants']     = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'cps_merchants','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['product_info']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'USER' => 'user_icson', 'PASSWD' => 'icson');
$_DB_CFG['icson_diy']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_diy', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_cps']    = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_cps','USER' => 'user_icson', 'PASSWD' => 'icson' ); //CPS������
$_DB_CFG['icson_event']    = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_event','USER' => 'user_icson', 'PASSWD' => 'icson' ); //icson event db
$_DB_CFG['icson_admin_event']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_admin_event', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_event_component']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_event_component', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_admin_store']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_admin_store', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_admin_stpage']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_admin_stpage', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['product_pool']    = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'product_pool','USER' => 'user_icson', 'PASSWD' => 'icson' ); //��Ʒ��

$_DB_CFG['db_privilege']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_admin_management', 'USER' => 'user', 'PASSWD' => 'pass' );
$_DB_CFG['icson_statistics']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_statistics', 'USER' => 'user', 'PASSWD' => 'pass' );
$_DB_CFG['icson_core_ttc']     = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_core_ttc','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['icson_other_ttc']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'icson_other_ttc', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['retailer']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'retailer', 'USER' => 'user', 'PASSWD' => 'pass' );
$_DB_CFG['orders']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'orders', 'USER' => 'user', 'PASSWD' => 'pass' );
$_DB_CFG['retailer_orders']      = array('IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'borders', 'USER' => 'user', 'PASSWD' => 'pass' );
$_DB_CFG['retailer_order_items']      = array('IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'border_items', 'USER' => 'user', 'PASSWD' => 'pass' );
$_DB_CFG['retailer_customer']      = array('IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'retailer_customer', 'USER' => 'user', 'PASSWD' => 'pass' );

$_DB_CFG['guijiupei']             = array('IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'guijiupei', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['card_info']             = array('IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'card_info', 'USER' => 'user_icson', 'PASSWD' => 'icson' );

$_DB_TABLE_CFG = array();


$_DB_TABLE_CFG['orders']                = array('DB' => 'orders', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0 );
$_DB_TABLE_CFG['order_invoice']         = array('DB' => 'order_invoice', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['order_items']           = array('DB' => 'order_items', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['order_match']           = array('DB' => 'order_match', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['order_virtual_stock']   = array('DB' => 'order_virtual_stock', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['order_process_flow']    = array('DB' => 'order_process_flow', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>1);
$_DB_TABLE_CFG['users']                 = array('DB' => 'users', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['user_pass']             = array('DB' => 'user_pass', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['email_login']           = array('DB' => 'email_login', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['tel_login']             = array('DB' => 'tel_login', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['icson_login']           = array('DB' => 'icson_login', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['user_addressbook']      = array('DB' => 'user_addressbook', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['user_invoicebook']      = array('DB' => 'user_invoicebook', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['coupon']                = array('DB' => 'coupon', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['user_coupon_index']     = array('DB' => 'user_coupon_index', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['cp_information']     	= array('DB' =>'cp_information', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>1);
$_DB_TABLE_CFG['icson']                 = array('DB' => 'icson', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['icson_core']            = array('DB' => 'icson_core', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['icson_core_ttc']        = array('DB' => 'icson_core_ttc', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['icson_rma'] 			= array('DB' => 'ICSON_RMA', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['icson_rma_test'] 		= array('DB' => 'icson_rma_test', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['retailer']     			= array('DB' => 'retailer', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['orders']             	 = array('DB' => 'orders', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['retailer_orders']       = array('DB' => 'borders', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['retailer_order_items']       = array('DB' => 'border_items', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['retailer_customer']       = array('DB' => 'retailer_customer', 'DB_NUM' => 100, 'TABLE_NUM' => 100, 'IP'=>0);
$_DB_TABLE_CFG['promotion']                 = array('DB' => 'promotion', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_DB_TABLE_CFG['promotion_user_rule_map']   = array('DB' => 'promotion_user_rule_map', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=>0);
//CMSǰ��ҳ��Ƭ��ص�
$_DB_TABLE_CFG['51buy_cms_db'] = array('DB' => '51buy_cms_db', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_DB_SERVER_CFG = array();
$_DB_SERVER_CFG['online'][0] = array( 'IP' => '10.24.177.53','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['online'][1] = array( 'IP' => '10.24.177.53','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['bakup'][0]  = array( 'IP' => '10.24.177.53','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_SERVER_CFG['bakup'][1]  = array( 'IP' => '10.24.177.53','PORT' => 3306,'DB' => 'IAS','USER' => 'user_icson', 'PASSWD' => 'icson' );

########################## �����Ż�ȯģ��DB #############################
$_DB_CFG['merchants']				= array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'merchants',			  'USER' => 'user_icson', 'PASSWD' => 'icson' );// added by daopingsun  17:05 2012/9/4
$_DB_CFG['merchants_coupon_type']   = array( 'IP' => '10.24.177.53', 'PORT' => 3306, 'DB' => 'merchants_coupon_type', 'USER' => 'user_icson', 'PASSWD' => 'icson' );// added by daopingsun  17:05 2012/9/4

########################## ���߹���ƽ̨db #############################
$_DB_CFG['db_app_userdevice']   = array( 'IP' => '10.96.78.106', 'PORT' => 3306, 'DB' => 'app_userdevice_', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['db_app_deviceinfo']   = array( 'IP' => '10.96.78.106', 'PORT' => 3306, 'DB' => 'app_deviceinfo_', 'USER' => 'user_icson', 'PASSWD' => 'icson' );
$_DB_CFG['db_app_pushmsg']   = array( 'IP' => '10.96.78.106', 'PORT' => 3306, 'DB' => 'app_pushmsg_', 'USER' => 'user_icson', 'PASSWD' => 'icson' );

########################## MSDB ���� #############################
$_MSDB_CFG = array();

//�Ϻ�
#$_MSDB_CFG['ERP_1'] 	 = array( 'IP' => '10.96.78.171','PORT' => 1433,'DB' => 'IAS','USER' => 'sa', 'PASSWD' => '1' );
//����
#$_MSDB_CFG['ERP_1001'] 	 = array( 'IP' => '192.168.17.54','PORT' => 1433,'DB' => 'SZ_IAS','USER' => 'sa', 'PASSWD' => 'Icson2012' );


$_MSDB_CFG['ERP_1']         = array( 'IP' => '10.24.177.135','PORT' => 1433,'DB' => 'SH_IAS','USER' => 'qq', 'PASSWD' => '1qazXSW@');
$_MSDB_CFG['ERP_1001']         = array( 'IP' => '10.24.177.135','PORT' => 1433,'DB' => 'SH_IAS','USER' => 'qq', 'PASSWD' => '1qazXSW@');
$_MSDB_CFG['ERP_2001']         = array( 'IP' => '10.24.177.135','PORT' => 1433,'DB' => 'SH_IAS','USER' => 'qq', 'PASSWD' => '1qazXSW@');
$_MSDB_CFG['ERP_3001']   = array( 'IP' => '10.24.177.135','PORT' => 1433,'DB' => 'SH_IAS','USER' => 'qq', 'PASSWD' => '1qazXSW@');
$_MSDB_CFG['ERP_4001']         = array( 'IP' => '10.24.177.135','PORT' => 1433,'DB' => 'SH_IAS','USER' => 'qq', 'PASSWD' => '1qazXSW@');
$_MSDB_CFG['ERP_5001']   = array( 'IP' => '10.24.177.135','PORT' => 1433,'DB' => 'SH_IAS','USER' => 'qq', 'PASSWD' => '1qazXSW@' );
$_MSDB_CFG['ERP_BAK_1']         = array( 'IP' => '10.24.177.134','PORT' => 1433,'DB' => 'SH_IAS','USER' => 'qq', 'PASSWD' => 'QQ123456!!');
$_MSDB_CFG['ERP_BAK_1001']         = array( 'IP' => '10.24.177.134','PORT' => 1433,'DB' => 'SZ_IAS','USER' => 'qq', 'PASSWD' => 'QQ123456!!');
$_MSDB_CFG['ERP_BAK_2001']         = array( 'IP' => '10.24.177.134','PORT' => 1433,'DB' => 'BJ_IAS','USER' => 'qq', 'PASSWD' => 'QQ123456!!');
$_MSDB_CFG['ERP_BAK_3001']   = array( 'IP' => '10.24.177.134','PORT' => 1433,'DB' => 'WH_IAS','USER' => 'qq', 'PASSWD' => 'QQ123456!!');
$_MSDB_CFG['ERP_BAK_4001']         = array( 'IP' => '10.24.177.134','PORT' => 1433,'DB' => 'CQ_IAS','USER' => 'qq', 'PASSWD' => 'QQ123456!!');
$_MSDB_CFG['ERP_BAK_5001'] = $_MSDB_CFG['ERP_5001'];
$_MSDB_CFG['SO']   = array( 'IP' => '10.24.177.135','PORT' => 1433,'DB' => 'Icson_IAS_CS','USER' => 'qq', 'PASSWD' => '1qazXSW@' );

$_MSDB_CFG['Inventory_Manager']         = array( 'IP' => '10.24.177.135','PORT' => 1433,'DB' => 'Inventory_Manager','USER' => 'qq', 'PASSWD' => '1qazXSW@');

//ͳ�Ʊ������ݿ�
$_MSDB_CFG['ICSON_STATISTIC']         = array( 'IP' => '10.96.78.171','PORT' => 1433,'DB' => 'ICSON_STATISTICS_SALES','USER' => 'sa', 'PASSWD' => 'qwer');
$_MSDB_CFG['ICSON_STATISTIC_REAL']         = array( 'IP' => '10.96.78.171','PORT' => 1433,'DB' => 'ICSON_STATISTICS_SALES','USER' => 'sa', 'PASSWD' => 'qwer');
$_MSDB_CFG['ICSON_STATISTICS_CLICKFLOW'] = array( 'IP' => '10.96.78.170','PORT' => 1433,'DB' => 'ICSON_STATISTICS_CLICKFLOW','USER' => 'sa', 'PASSWD' => '1');
$_MSDB_TABLE_CFG['ICSON_STATISTICS_CLICKFLOW'] = array('DB' => 'ICSON_STATISTICS_CLICKFLOW', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>6);
$_MSDB_TABLE_CFG['DMSDB']   = array('DB' => 'DMSDB', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>1);
$_MSDB_TABLE_CFG['Inventory_Manager']   = array('DB' => 'Inventory_Manager', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>1);
$_MSDB_TABLE_CFG['Icson_Finance']   = array('DB' => 'Icson_Finance', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>9);
$_MSDB_CFG['ICSON_STATISTIC_DISTRIBUTOR']         = array( 'IP' => '10.96.78.171','PORT' => 1433,'DB' => 'ICSON_STATISTICS_SALES','USER' => 'sa', 'PASSWD' => 'qwer');

$_MSDB_CFG['Customer']         = array( 'IP' => '10.24.177.135','PORT' => 1433,'DB' => 'Customer','USER' => 'qq', 'PASSWD' => '1qazXSW@');
//80���ã������������ã����ã������ɾ
$_MSDB_CFG['real_statistic'] = array( 'IP' => '192.168.2.80','PORT' => 1433,'DB' => 'ICSON_STATISTICS_REAL','USER' => 'sh_ics', 'PASSWD' => 'icson@20061102');

$_MSDB_CFG['Product'] =  array('IP' => '10.24.177.135', 'PORT' => 1433, 'DB' => 'Icson_product', 'USER' => 'qq', 'PASSWD' => '1qazXSW@');
$_MSDB_TABLE_CFG['Customer']      = array('DB' => 'Customer', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>1);

//���������µ�
$_MSDB_TABLE_CFG['QQSHOP_ORDER_CORE'] = array('DB' => 'QQSHOP_ORDER_CORE', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>0);
$_MSDB_TABLE_CFG['HQ_QQShop']         = array('DB' => 'HQ_QQShop', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>3 );

//��Լ��
$_MSDB_CFG['ICSON_Product2'] = array('IP' => '10.24.177.135', 'PORT' => 1433, 'DB' => 'Icson_product', 'USER' => 'qq', 'PASSWD' => '1qazXSW@');

//�µ����Ŀ�����
// ��Ʒ�ṹ���������������
$_MSDB_TABLE_CFG['Stock'] = array('DB' => 'Icson_product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['Product'] = array('DB' => 'Icson_product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['Category'] = array('DB' => 'Icson_product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['Product_Gift'] = array('DB' => 'Icson_product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=> 1);
$_MSDB_TABLE_CFG['CustomPhone'] = array('DB' => 'Icson_product', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>1);//��Լ��


$_MSDB_TABLE_CFG['ICSON_ORDER_CORE']      = array('DB' => 'ICSON_ORDER_CORE', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=>0);
$_MSDB_TABLE_CFG['ICSON_CORE']      = array('DB' => 'ICSON_CORE', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>0);
$_MSDB_TABLE_CFG['ORDER_PROCESS_FLOW']      = array('DB' => 'HQ_SO', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>1);
$_MSDB_TABLE_CFG['ERP_1']      = array('DB' => 'SH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>1);
$_MSDB_TABLE_CFG['ERP_1001']      = array('DB' => 'SH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>1);
$_MSDB_TABLE_CFG['ERP_2001']      = array('DB' => 'SH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1, 'IP'=>1);
$_MSDB_TABLE_CFG['ERP_3001']      = array('DB' => 'SH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>1);
$_MSDB_TABLE_CFG['ERP_4001']      = array('DB' => 'SH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>1);
$_MSDB_TABLE_CFG['ERP_5001']      = array('DB' => 'SH_IAS', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>1);
$_MSDB_TABLE_CFG['ICSON_WORKFLOW']      = array('DB' => 'ICSON_WORKFLOW', 'DB_NUM' => 1,  'IP'=>0);
$_MSDB_TABLE_CFG['ICSON_USERS']   = array('DB' => 'ICSON_USERS', 'DB_NUM' => 10, 'TABLE_NUM' => 100, 'IP'=>0);
$_MSDB_TABLE_CFG['SO']            = array('DB' => 'Icson_IAS_CS', 'DB_NUM' => 1, 'TABLE_NUM' => 1,  'IP'=>8);


$_MSDB_SERVER_CFG['online'][0] = array( 'IP' => '10.24.177.54','PORT' => 1433,'USER' => 'sa', 'PASSWD' => '1' );  //����SQL-server��ַ
//$_MSDB_SERVER_CFG['online'][1] = array( 'IP' => '10.96.78.171','PORT' => 1433,'USER' => 'sa', 'PASSWD' => '1' );
//$_MSDB_SERVER_CFG['online'][2] = array( 'IP' => '192.168.17.54','PORT' => 1433,'USER' => 'sa', 'PASSWD' => 'Icson2012' );
$_MSDB_SERVER_CFG['online'][1] = array('IP' => '10.24.177.135', 'PORT' => 1433, 'USER' => 'qq', 'PASSWD' => '1qazXSW@');
$_MSDB_SERVER_CFG['online'][2] = array( 'IP' => '10.96.78.175','PORT' => 1433,'USER' => 'qq', 'PASSWD' => 'qqbuy' );
$_MSDB_SERVER_CFG['online'][3] = array( 'IP' => '10.96.78.171','PORT' => 1433,'USER' => 'sa', 'PASSWD' => 'qwer' );
$_MSDB_SERVER_CFG['online'][4] = array( 'IP' => '10.96.78.171','PORT' => 1433,'USER' => 'sa', 'PASSWD' => 'qwer' );
$_MSDB_SERVER_CFG['online'][5] = array( 'IP' => '10.96.78.171','PORT' => 1433,'USER' => 'sa', 'PASSWD' => 'qwer' );
$_MSDB_SERVER_CFG['online'][6] = array( 'IP' => '10.96.78.170','PORT' => 1433,'USER' => 'sa', 'PASSWD' => '1' );
$_MSDB_SERVER_CFG['online'][7] = array( 'IP' => '10.24.177.135','PORT' => 1433,'USER' => 'sa', 'PASSWD' => '1qaz' );
$_MSDB_SERVER_CFG['online'][8] = array( 'IP' => '10.24.177.135', 'PORT' => 1433, 'USER' => 'qq', 'PASSWD' => '1qazXSW@');
$_MSDB_SERVER_CFG['online'][9] = array( 'IP' => '10.24.177.134','PORT' => 1433,'USER' => 'qq', 'PASSWD' => 'QQ123456!!' );
$_MSDB_SERVER_CFG['bakup'][0] = array( 'IP' => '10.24.177.54','PORT' => 1433,'USER' => 'sa', 'PASSWD' => '1' );
$_MSDB_SERVER_CFG['bakup'][1] = array( 'IP' => '10.96.78.171','PORT' => 1433,'USER' => 'sa', 'PASSWD' => 'qwer' );
$_MSDB_SERVER_CFG['bakup'][2] = array( 'IP' => '10.96.78.171','PORT' => 1433,'USER' => 'sa', 'PASSWD' => 'qwer' );
$_MSDB_SERVER_CFG['bakup'][3] = array( 'IP' => '10.96.78.171','PORT' => 1433,'USER' => 'sa', 'PASSWD' => 'qwer' );

######################## Cache ���� ############################
$_CACHE_CFG = array();








######################## ��Ϣ�������� ############################
//define('ASYNC_PROF_KEY', 0x100001); // �첽�����û�������Ϣ����

######################## �˺Ű�ȫ������ ############################
$_IP_CFG['safeService'] = array('ip' => '172.25.36.46', 'port' => 25500);

######################## CMEM ���� ############################
$_CMEM_CFG	=	array();
$_CMEM_CFG['smsCode']	=	array(
	'bid'			=>	20120409,
	'show_error'	=>	false,	//�Ƿ���ʾ����
	'timeout'		=>	1000,	//��ʱ����
	'freetime'		=>	10,		//����ʱ��
	'servers'		=>	array('10.136.9.77:9101')
);

$_CMEM_CFG['cate_hot_top5']	=	array(
	'bid'			=>	20120409,
	'show_error'	=>	false,	//�Ƿ���ʾ����
	'timeout'		=>	1000,	//��ʱ����
	'freetime'		=>	10,		//����ʱ��
	'servers'		=>	array('10.136.9.77:9101')
);

/* CMEM Session */
$_CMEM_CFG['ClientSession']	=	array(
		'bid'			=>	20120409,
		'show_error'	=>	false,	//�Ƿ���ʾ����
		'timeout'		=>	1000,	//��ʱ����
		'freetime'		=>	10,		//����ʱ��
		'servers'		=>	array('10.136.9.77:9101')
);

######################## ������������ ############################
$_CPS_SERVER_CONFIG['PSFOrderPusher'] = array( 'IP' => '10.96.78.101', 'PORT' => 10003);
$_CPS_SERVER_CONFIG['PSFOrderComputing'] = array( 'IP' => '10.96.78.101', 'PORT' => 10002);
$_CPS_SERVER_CONFIG['PSFService'] = array( 'IP' => '10.96.78.101', 'PORT' => 10004);
$_CPS_SERVER_CONFIG['PSFOrderReceiver'] = array( 'IP' => '10.96.78.101', 'PORT' => 10001);
$_CPS_SERVER_CONFIG['PSFOrderToERP'] = array( 'IP' => '10.96.78.101', 'PORT' => 10005);


$_CPS_L5_MOD_CONFIG = array(
		'PSFOrderReceiver'  =>  array( 'modid' => 7701, 'cmdid' => 101),
		'PSFOrderComputing' =>  array( 'modid' => 7702, 'cmdid' => 102),
		'PSFOrderPusher'    =>  array( 'modid' => 7703, 'cmdid' => 103),
		'PSFService'        =>  array( 'modid' => 7704, 'cmdid' => 104),
		'PSFOrderToERP'     =>  array( 'modid' => 7705, 'cmdid' => 105),
		'PSFOrderOwnerComputing' =>  array( 'modid' => 7706, 'cmdid' => 106),
);
// End of script
