<?php
/**
 * ģ����������
 * @author bennylin
 */

$EE_MODULE_STATE = array();

//master module
$_MODULE_WEB = 232000506; //DEFAULT
$_MODULE_SCRIPT = 233000098;
$_MODULE_ANDROID = 233000099;
$_MODULE_IPHONE = 233000100;
$_MODULE_WAP = 232000502;

//default is web
$_AUTO_MASTER = $_MODULE_WEB;

//set auto master module id
if (!empty($argv) ) {
	$_AUTO_MASTER = $_MODULE_SCRIPT;
}
elseif (!empty($_GET['appSource']) ) {
	$_from = strtolower(trim($_GET['appSource']) );
	if ($_from == 'android') {
		$_AUTO_MASTER = $_MODULE_ANDROID;
	}
	elseif ($_from == 'iphone') {
		$_AUTO_MASTER = $_MODULE_IPHONE;
	}
}
elseif (defined('IN_MOBILE') && IN_MOBILE == 1) {
	$_AUTO_MASTER = $_MODULE_WAP;
}

/**
 * modules id map
 */
$EE_MODULE_STATE['MODULE_MAP'] = array(
	//master
	'AUTO_MASTER' => $_AUTO_MASTER,

	//ttc to call
	'ttc.IDelayOrderTTC' => 233000135,
	'ttc.IGuiJiuPeiTTC' => 233000129,
	'ttc.IUserProductsTTC' => 233000128,
	'ttc.IScoreFlowTTC' => 233000127,
	'ttc.IInventoryStockTTC' => 233000126,
	'ttc.IProductStockTTC' => 233000125,
	'ttc.IPromotionSendCouponTTC' => 233000124,
	'ttc.IPromotionUserRuleMapTTC' => 233000123,
	'ttc.IPromotionProductRuleMapTTC' => 233000122,
	'ttc.IPromotionRuleValidTTC' => 233000121,
	'ttc.IMultiPriceTTC' => 233000120,
	'ttc.IOrderItemsTTC' => 233000119,
	'ttc.IOrdersTTC' => 233000118,
	'ttc.IOrderInvoiceTTC' => 233000117,
	'ttc.IShippingRegionTTC' => 233000116,
	'ttc.IShippingPriceTTC' => 233000115,
	'ttc.IProductRelativityTTC' => 233000114,
	'ttc.IProductIDMapTTC' => 233000113,
	'ttc.IProductInfoTTC' => 233000112,
	'ttc.IProductCommonInfoTTC' => 233000111,
	'ttc.IShoppingCartTTCNew' => 233000110,
	'ttc.ICouponTTC' => 233000109,
	'ttc.IUserInvoiceBookTTC' => 233000108,
	'ttc.IUserAddressBookTTC' => 233000107,
	'ttc.IUsersTTC' => 233000106,
	//'ttc.IQQLoginTTC' => 233000105,
	'ttc.ITelLoginTTC' => 233000104,
	'ttc.IIcsonLoginTTC' => 233000103,
	'ttc.IEmailLoginTTC' => 233000102,
	//'ttc.IUserPassTTC' => 233000101,

	//db to call
	'db.Icson_Finance' => 233000097,
	'db.ICSON_CORE' => 233000096,
	'db.ICSON_ORDER_CORE' => 233000095,
	'db.DMSDB' => 233000094,
	'db.Inventory_Manager' => 233000093,
	'db.ERP_5001' => 233000092,
	'db.ERP_4001' => 233000091,
	'db.ERP_3001' => 233000090,
	'db.ERP_2001' => 233000089,
	'db.ERP_1001' => 233000088,
	'db.Customer' => 233000087,
	'db.ERP_1' => 233000086,
	'db.Stock' => 233000140,
	'db.Product' => 233000141,
	'db.Categroy' => 233000142,
	'db.Product_Gift' => 233000143,

	//'db.icson_cps' => 233000085,
	'db.product_info' => 233000084,
	'db.guijiupei' => 233000083,
	'db.product_list' => 233000082,
	'db.icson_core' => 233000081,
	'db.promotion_user_rule_map' => 233000080,
	'db.promotion' => 233000079,
	'db.icson_rma' => 233000078,
	'db.user_coupon_index' => 233000077,
	'db.coupon' => 233000076,
	'db.icson_login' => 233000075,
	'db.tel_login' => 233000074,
	'db.email_login' => 233000073,
	//'db.user_pass' => 233000072,
	'db.users' => 233000071,
	'db.order_process_flow' => 233000070,
	'db.order_virtual_stock' => 233000069,
	'db.order_match' => 233000068,
	'db.order_items' => 233000067,
	'db.order_invoice' => 232000508,
	'db.orders' => 232000507,

	//cgi.coupon_get
	//'cgi.coupon_get' => 233000130,
);

/**
 * interfaces id map
 */
$EE_MODULE_STATE['INTERFACE_MAP'] = array(
	//db
	'db.select' => 132000540,
	'db.insert' => 132000541,
	'db.update' => 132000542,
	'db.delete' => 132000543,
	'db.commit' => 132000544,
	'db.rollback' => 132000545,
	'db.start' => 132000553,
	'db.select_db' => 132000554,
	'db.connect' => 132000555,
	'db.init' => 132000557,

	//ttc
	'ttc.select' => 132000546,
	'ttc.insert' => 132000547,
	'ttc.update' => 132000548,
	'ttc.delete' => 132000549,
	'ttc.replace' => 132000550,
	'ttc.purge' => 132000551,
	'ttc.flush' => 132000552,
	'ttc.init' => 132000556,
	'ttc.increment' => 132000558,
	'ttc.increment' => 132000559,

	//cgi
	'cgi.get' => 133000563,
);

/**
 * ����������
 * ����δ���õĽ�ȫ���ϱ�
 * ͬʱ������module��interfaceʱ����moduleΪ׼
 */
$EE_MODULE_STATE['RATES'] = array(
	//module rates
	//...
	'cgi.coupon_get' => 0.1,

	//interface rates
	//db
	'db.select' => 0.1,
	//'db.insert' => 0.1,
	//'db.update' => 0.1,
	// 'db.delete' => 0.1,
	// 'db.commit' => 0.1,
	// 'db.rollback' => 0.1,
	// 'db.start' => 0.1,
	'db.select_db' => 0.01,
	'db.connect' => 0.01,
	'db.init' => 0.1,

	//ttc
	'ttc.select' => 0.1,
	//'ttc.insert' => 0.1,
	//'ttc.update' => 0.1,
	// 'ttc.delete' => 0.1,
	// 'ttc.replace' => 0.1,
	// 'ttc.purge' => 0.1,
	// 'ttc.flush' => 0.1,
	'ttc.init' => 0.01,
	//'ttc.increment' => 0.1,
	//'ttc.increment' => 0.1,
);

//put at end
return $EE_MODULE_STATE;
