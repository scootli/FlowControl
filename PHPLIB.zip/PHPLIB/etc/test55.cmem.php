<?php
/**
 * CMEM配置
 * @author bennylin
 * 2011/10/11
 */

$EC_CONF_CMEM = array();

//接入机组0
$EC_CONF_CMEM['ACCESS_0'] = array(
	'192.168.2.225:53024',
);


//下面是SimpleCmem的配置

//配置示例
$EC_CONF_CMEM['example'] = array(
	'access_id' => 0,
	'bid' => 20120381,
    'prefix' => 'example',
	'pack' => 'serialize', //打包函数
	'unpack' => 'unserialize', //解包函数
	//'include' => '', //打、解包需要依赖的PHP文件路径
);
$EC_CONF_CMEM['autopayback'] = array(
	'access_id' => 0,
	'bid' => 20120381,
	'prefix' => 'autopayback',
	'pack' => 'serialize', //打包函数
	'unpack' => 'unserialize', //解包函数
	//'include' => '', //打、解包需要依赖的PHP文件路径
);
//礼品卡PN码
$EC_CONF_CMEM['giftcard_pncode'] = array( //also define in IGiftCard
	'access_id' => 0,
	'bid' => 20120381,
	'prefix' => 'pncode_',
	'pack' => 'serialize', //打包函数
	'unpack' => 'unserialize', //解包函数
	//'include' => '', //打、解包需要依赖的PHP文件路径
);

//这里返回，要放在最后
return $EC_CONF_CMEM;
//end of script
