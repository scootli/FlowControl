<?php
/**
 * ECC Lib
 *
 * @category	EL
 * @author		bennylin <linqiang.gx@gmail.com>
 * @udpated		2012/2/27
 */

/*
eg.

$_GET['string'] = "abc\r123\n";
$_GET['int'] = "123";
$_GET['bool'] = "1";
$_GET['float'] = "1.238";
$_GET['map'] = array(
	'k1' => "abc\r<br>\n",
	'k2' => 'ddfdfdf',
);

$ret = EL_Request::get(array(
	'string' => EL_Request::T_STRIP_NL,
	'int' => EL_Request::T_INT,
	'bool' => EL_Request::T_BOOL,
	'float' => EL_Request::T_FLOAT,
	'map' => EL_Request::T_MAP | EL_Request::T_ESCAPE_HTML | EL_Request::T_STRIP_NL,
));

var_dump($ret);
*/

/**
 * �������������
 *
 * @category	EF
 * @package		EL_Request
 * @version 1.0
 * @updated 2012/2/20
 * @author bennylin <linqiang.gx@gmail.com>
 */
class EL_Request
{
	//type list
	const T_RAW = 0x0;
	const T_STRING = 0x1; //strip \r
	const T_INT = 0x2;
	const T_FLOAT = 0x4;
	const T_BOOL = 0x8;
	const T_MAP = 0x10; //һά���������

	//string ext type list
	const T_STRIP_ER = 0x1; //strip \r, same to T_STRING
	const T_STRIP_NL = 0x1001; //strip \n and \r
	const T_STRIP_TAGS = 0x2001; //strip html tags and \r
	const T_ESCAPE_HTML = 0x4001; //call htmlspecialchars with ENT_QUOTES

	//business type list
	const T_UIN = 0x100000; //qq

	/**
	 * filter from $_GET
	 *
	 * @param $type_map ����������
	 * @param $prefix ���˺�������±�ǰ׺
	 *
	 * @return array
	 */
	public static function get($type_map, $prefix = '')
	{
		return self::filterArray($_GET, $type_map, $prefix);
	}

	/**
	 * filter from $_POST
	 *
	 * @param $type_map ����������
	 * @param $prefix ���˺�������±�ǰ׺
	 *
	 * @return array
	 */
	public static function post($type_map, $prefix = '')
	{
		return self::filterArray($_POST, $type_map, $prefix);
	}

	/**
	 * filter from $_COOKIE
	 *
	 * @param $type_map ����������
	 * @param $prefix ���˺�������±�ǰ׺
	 *
	 * @return array
	 */
	public static function cookie($type_map, $prefix = '')
	{
		return self::filterArray($_COOKIE, $type_map, $prefix);
	}

	/**
	 * filter from $_REQUEST
	 *
	 * @param $type_map ����������
	 * @param $prefix ���˺�������±�ǰ׺
	 *
	 * @return array
	 */
	public static function all($type_map, $prefix = '')
	{
		return self::filterArray($_REQUEST, $type_map, $prefix);
	}

	/**
	 * filter from souce data by types
	 *
	 * @param $source source data map
	 * @param $type_map filter type map
	 * @param $prefix ����������±�ǰ׺
	 *
	 * @return array
	 */
	public static function filterArray(array $source, array $type_map, $prefix = '')
	{
		$output = array();
		foreach ($type_map as $_k => $type)
		{
			if (!isset($source[$_k]) )
			{
				$output[$prefix . $_k] = null;
				continue;
			}
			$output[$prefix . $_k] = self::filter($source[$_k], $type);
		}

		return $output;
	}

	/**
	 * filter from souce data by type
	 *
	 * @param $source source data
	 * @param $type filter type
	 *
	 * @return array
	 */
	public static function filter($var, $type)
	{
		if ($type == self::T_RAW) {
			return $var;
		}

		//map
		if ($type & self::T_MAP)
		{
			if (is_array($var) )
			{
				$tmp_type = $type ^ self::T_MAP;
				if ($tmp_type)
				{
					//��ÿһ����й���
					$map_items = array();
					foreach ($var as $tmp_key => $tmp_value)
					{
						$map_items[$tmp_key] = self::filter($tmp_value, $tmp_type);
					}

					$var = $map_items;
				}
			}
			else
			{
				$var = array();
			}

			return $var;
		}

		//uin
		if ($type & self::T_UIN)
		{
			$var = intval($var);
			if ($var < 10000)
			{
				$var = 0;
			}

			return $var;
		}

		//int
		if ($type & self::T_INT)
		{
			$var = intval($var);
			return $var;
		}

		//float
		if ($type & self::T_FLOAT)
		{
			$var = doubleval($var);
			return $var;
		}

		//boolean
		if ($type & self::T_BOOL)
		{
			$var = empty($var) ? false : true;
			return $var;
		}

		//string above

		//strip \r
		if ($type & self::T_STRIP_ER)
		{
			$var = str_replace("\r", '', $var);
			$type ^= self::T_STRIP_ER; //ȥ��������Ա�֤�·��߼�ִ�е���ȷ��
		}

		//strip \n
		if ($type & self::T_STRIP_NL)
		{
			$var = str_replace("\n", '', $var);
		}

		//strip html tags
		if ($type & self::T_STRIP_TAGS)
		{
			$var = strip_tags($var);
		}

		//convert html chars
		if ($type & self::T_ESCAPE_HTML)
		{
			$var = htmlspecialchars($var, ENT_QUOTES);
		}

		return $var;
	}
}



