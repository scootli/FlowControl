<?php
/**
 * CMEM.php 
 *
 * @copyright	(c) 1998-2011 All Rights Reserved
 * @author		benxi <benxi@tencent.com>
 * @created		2013-1-5
 * @version		$Id$
 */

class CMEM
{
	static $defAccess; //Ĭ�Ͻӿڻ�

	public $errCode = 0;
	public $errMsg;

	private $_tmem = null;
	private $conf = array(
			'bid' => 0,
			'show_error' => false, //�Ƿ���ʾ����
			'timeout'    => 1, //��ʱ����
			'freetime'   => 10, //����ʱ��
	);

	const ERR_KEY_NOEXISTS   = -13105;
	const ERR_DATA_NOEXISTS  = -13200;

	function __construct($conf)
	{
		if(empty($conf['bid']))
		{
			throw new \Exception(__CLASS__." require bid.");
		}
		$this->_tmem = new \tmem((int)$this->conf['timeout']/1000, $this->conf['show_error']);
		if(empty($conf['servers']))
		{
			if(!empty(self::$defAccess))
			{
				$conf['servers'] = self::$defAccess;
			}
			else
			{
				throw new \Exception('CMEM require conf[\'servers\']');
			}
		}
		$this->conf = array_merge($this->conf, $conf);
		$this->_tmem->set_servers($conf['servers'], $this->conf['timeout'], $this->conf['freetime']);
	}

	private function getError()
	{
		$this->errCode = $this->_tmem->errno();
		$this->errMsg  = $this->_tmem->error();
	}
	/**
	 * ��ȡ��ֵ
	 * @param $key
	 */
	function get($key, $offset = 0, $length = 0)
	{
		$isa = is_array($key);
		if(($isa && empty($key)) or (!$isa && strlen($key)===0) )
		{
			trigger_error('call tmem->get but No keys');
			return false;
		}

		$ret = $this->_tmem->get($this->conf['bid'], $key, $offset, $length);
		//����
		if ($ret === false)
		{
			$this->getError();
			if($this->errCode == -11907 or $this->errCode == -11906)
			{
				$ret = $this->_tmem->get($key, $offset, $length);
			}
		}
		if ($ret === false)
		{
			$this->getError();
			//key������
			if($this->errCode==self::ERR_DATA_NOEXISTS or $this->errCode==self::ERR_KEY_NOEXISTS )
			{
				return array();
			}
			return false;
		}
		
		if ( $isa ) {
			return	$ret;
		} else {
			return	array($ret);
		}
	}
	/**
	 * ���ü�ֵ
	 * @param $key
	 * @param $value
	 * @param $expire
	 */
	function set($key_or_kvmap, $value, $expire = 0, $offset = 0, $length = 0)
	{
		$isa = is_array($key_or_kvmap);
		if ( ($isa && empty($key_or_kvmap)) || (!$isa && strlen($key_or_kvmap)===0) )
		{
			trigger_error('call tmem->get but No keys');
			return false;
		}

		$ret = $this->_tmem->set($this->conf['bid'], $key_or_kvmap, $value, $offset, $length);
		if ($ret === false)
		{
			$this->getError();
			if($this->errCode == -11907 or $this->errCode == -11906)
			{
				$ret = $this->_tmem->set($this->conf['bid'], $key_or_kvmap, $value, $offset, $length);
				if ($ret === false)
				{
					$this->getError();
					return false;
				}
			}
		}

		//�����п��ܷ�������
		$no_errors = true;
		if (is_array($ret) && is_array($key_or_kvmap))
		{
			foreach ($ret as $one_key => $key_return)
			{
				if ($key_return === false)
				{
					//����Ϊ��ʱ�϶�ʧ�� ����Ҫ���˵�
					if ($key_or_kvmap[$one_key] !== '')
					{
						$no_errors = false;
					}

					unset($key_or_kvmap[$one_key]);
				}
			}

			//Ϊ�ձ�ʾȫ��ʧ����
			if (empty($key_or_kvmap))
			{
				$ret = false;
			}
		}

		if ($ret === false)
		{
			return false;
		}

		return $ret;
	}
	/**
	 * ɾ����
	 * @param $key
	 */
	function del($key)
	{
		$isa = is_array($key);
		if ( ($isa && empty($key)) or (!$isa && strlen($key)===0) )
		{
			trigger_error('call tmem->get but No keys');
			return false;
		}

		$ret = $this->_tmem->del($this->conf['bid'], $key);
		if ($ret === false)
		{
			$this->getError();
			if($this->errCode == -11907 or $this->errCode == -11906)
			{
				$ret = $this->_tmem->del($this->conf['bid'], $key);
				if ($ret === false)
				{
					$this->getError();
					return false;
				}
			}
		}

		//�����п��ܷ�������
		if (is_array($ret) && is_array($key))
		{
			foreach ($ret as $one_key => $key_return)
			{
				if ($key_return === false)
				{
					$idx = array_search($one_key, $key);
					unset($key[$idx]);
				}
			}

			//Ϊ�ձ�ʾȫ��ʧ����
			if (empty($key))
			{
				$ret =  false;
			}
		}

		if ($ret === false)
		{
			return false;
		}

		return $ret;
	}
	/**
	 * ���л�ȡkeyֵ
	 *
	 * @param string/array $key
	 * @param string/array $cols
	 *
	 * @return string/array/false
	 */
	public function getcol($key, $cols)
	{
		$ret = $this->_tmem->getcol($this->conf['bid'], $key, $cols);
		$this->getError();
		if ($ret === false && ($this->errCode == -11907 or $this->errCode == -11906))
		{
			$ret = $this->_tmem->getcol($this->conf['bid'], $key, $cols);
			if ($ret === false)
			{
				$this->getError();
				return false;
			}
		}
		return $ret;
	}
	/**
	 * ��������keyֵ
	 *
	 * @param string/array $key
	 * @param array/int $record_or_col ����ֵ��Ӧ������б�ʶ
	 * @param string $value_of_col ���$record_or_col������д���б�ʶ������������е�ֵ
	 *
	 * @return boolean
	 */
	public function setcol($key, $record_or_col, $value_of_col = null)
	{
		$ret = $this->_tmem->setcol($this->conf['bid'], $key, $record_or_col, $value_of_col);
		if ($ret === false && ($this->_tmem->errno() == -11907 || $this->_tmem->errno() == -11906))
		{
			$ret = $this->_tmem->setcol($this->conf['bid'], $key, $record_or_col, $value_of_col);
		}

		//�����п��ܷ�������
		$no_errors = true;
		if (is_array($ret))
		{
			foreach ($ret as $col => $col_return)
			{
				if ($col_return === false)
				{
					//����Ϊ��ʱ�϶�ʧ�� ����Ҫ���˵�
					if ($record_or_col[$col] !== '')
					{
						$no_errors = false;
					}

					unset($record_or_col[$col]);
				}
			}

			//Ϊ�ձ�ʾȫ��ʧ����
			if (empty($record_or_col))
			{
				$ret = false;
			}
		}

		//check result
		if ($ret === false)
		{
			return false;
		}

		return $ret;
	}
	/**
	 * ����ɾ��keyֵ
	 *
	 * @param int $bid
	 * @param string/array $key
	 * @param array $cols
	 *
	 * @return boolean
	 */
	public function delcol($key, $cols)
	{
		$ret = $this->_tmem->delcol($this->conf['bid'], $key, $cols);

		if ($ret === false)
		{
			$this->getError();
			if(($this->errCode == -11907 || $this->errCode == -11906))
			{
				$ret = $this->_tmem->delcol($this->conf['bid'], $key, $cols);
				if ($ret === false)
				{
					$this->getError();
					return false;
				}
			}
		}

		//�����п��ܷ�������
		if (is_array($ret))
		{
			foreach ($ret as $col => $col_return)
			{
				if ($col_return === false)
				{
					$idx = array_search($col, $cols);
					unset($cols[$idx]);
				}
			}

			//Ϊ�ձ�ʾȫ��ʧ����
			if (empty($cols))
			{
				$ret = false;
			}
		}

		//check result
		if ($ret === false)
		{
			return false;
		}

		return $ret;
	}
	/**
	 * �趨��ʱʱ��
	 * @param $timeout
	 */
	function setTimeout($timeout)
	{
		return $this->_tmem->set_connect_timeout((int)$timeout/1000);
	}

}

//end of script
