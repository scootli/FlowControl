<?php

class ArrayUtil {
	
	public static $errCode = 0;
	public static $errMsg = '';
	
	private static function clearErr() {
		self::$errCode = 0;
		self::$errMsg = '';
	}
	
	/**
	 * �������ò������Ŀ�������е�ֵ����������ά����
	 * @param array $obj Ŀ������
	 * @param array $mask �������
	 * @param bool $allowEmpty �Ƿ�����Ŀ��������δ���������е�ֵ
	 * @example
	 *  $obj = array(
			'k1' => 'v1',
			'k2' => array(
				'k2_1' => 'v2_1',
				'k2_2' => 'v2_2'
			),
			'k3' => array(
				'k3_1' => 'v3_1',
				'k3_2' => 'v3_2'
			),
			'k4' => array(
				'v4_1',
				'v4_2'
			),
			'k5' => array(
				array(
					'k5_1' => 'v5_1_1',
					'k5_2' => 'v5_1_2'
				),
				array(
					'k5_1' => 'v5_2_1',
					'k5_2' => 'v5_2_2'
				)
			)
			);
		
			$mask = array(
				'k1' => true,
				'k2' => true,
				'k3' => array(
					'k3_1' => true,
				),
				'k4' => true,
				'k5' => array(
					'k5_2' => true
				)
			);
		
			var_dump(ArrayUtil::array_mask($obj, $mask));
		
			�����
			array(5) {
			["k1"]=>
				string(2) "v1"
			["k2"]=>
				array(2) {
				["k2_1"]=>
					string(4) "v2_1"
				["k2_2"]=>
					string(4) "v2_2"
				}
			["k3"]=>
				array(1) {
				["k3_1"]=>
					string(4) "v3_1"
				}
			["k4"]=>
				array(2) {
				[0]=>
					string(4) "v4_1"
				[1]=>
					string(4) "v4_2"
				}
			["k5"]=>
				array(2) {
				[0]=>
					array(1) {
					["k5_2"]=>
						string(6) "v5_1_2"
					}
				[1]=>
					array(1) {
					["k5_2"]=>
						string(6) "v5_2_2"
					}
				}
			} 
	 */
	public static function array_mask($obj, $mask, $allowEmpty = true)
	{
		self::clearErr();
		if ($mask === true) {
			// ȫ�����
			return $obj;
		} else if (is_array($mask)) {
			// ��mask���
			if (is_array($obj)) {
				$new_obj = array();
				if (ArrayUtil::is_assoc_array($obj)) {
					// ��������
					foreach ($mask as $k => $v) {
						if (isset($obj[$k])) {
							$new_obj[$k] = ArrayUtil::array_mask($obj[$k], $v);
							if($new_obj[$k] === false) {
								return false;
							}
						} else {
							if (!$allowEmpty) {
								self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
								self::$errMsg = "Attribute $k not set.";
								return false;
							}
						}
					}
				} else {
					// ˳������
					foreach ($obj as $child) {
						$new_obj[] = ToolUtil::array_mask($child, $mask);
						if($new_obj[$k] === false) {
							return false;
						}
					}
				}
				return $new_obj;
			} else {
				// ������mask�޷�ƥ��
				self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
				self::$errMsg = 'Array can not match with mask.';
				return false;
			}
		} else {
			// ��Ч��mask
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Illegal mask.';
			return false;
		}
	}

	/**
	 * �ж��Ƿ��������
	 * @param array $obj Ŀ������
	 */
	public static function is_assoc_array($obj)
	{
		if (is_array($obj)) {
			return array_keys($obj) !== range(0, count($obj) - 1);
		} else {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 1 is not an array.';
			return false;
		}
	}

	/**
	 * ��Ŀ����������ȡָ��ֵ��ֻ����һά����
	 * @param array $obj Ŀ������
	 * @param array $filter ��������
	 * @example
	 * $params = ArrayUtil::array_fetch($_GET, array(
	 *         'id' => array(
	 *             'name' => 'product_id' // ����ָ��Ŀ�������е���������ʡ��������������ֵ��ͬ
	 *             'default' => '' // ����Ĭ��ֵ����ʡ�ԣ�Ĭ��Ϊ''
	 *             'allowEmpty' => false // ָ���������ܹ�Ϊ�գ���ʡ�ԣ�Ĭ��Ϊtrue����ʶ����Ϊ��
	 *             'secureType' => 'int' // ���ð�ȫ���ƣ�����Ϊ'int'��'string'����ʡ��������ȫ����
	 *         )
	 *         ...
	 * ));
	 */
	public static function array_fetch($obj, $filter)
	{
		if (!is_array($obj)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 1 is not an array.';
			return false;
		}
		if (!is_array($filter)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 2 is not an array.';
			return false;
		}
		$out = array();
		foreach ($filter as $name => $config) {
			$pname = (isset($config['name']) && !empty($config['name'])) ? $config['name'] : $name;
			if (isset($config['default']) && (!isset($obj[$pname]) || empty($obj[$pname])))
				$obj[$pname] = $config['default'];

			if (isset($config['allowEmpty']) && !$config['allowEmpty'] && (!isset($obj[$pname]) || empty($obj[$pname]))) {
				self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
				self::$errMsg = "Property $pname should not be empty.";
				return false;
			}

			if (isset($obj[$pname])) {
				if (isset($config['secureType'])) {
					if ($config['secureType'] == 'int') {
						$out[$name] = intval($obj[$pname]);
					} else if ($config['secureType'] == 'number') {
						$out[$name] = floatval($obj[$pname]);
					} else if ($config['secureType'] == 'string') {
						$out[$name] = ToolUtil::transXSSContent($obj[$pname]);
					} else if ($config['secureType'] == 'bool') {
						$out[$name] = ($obj[$pname] == true && $obj[$pname] !== 'false');
					} else {
						self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
						self::$errMsg = "Undefined secure type {$config['secureType']}.";
						return false;
					}
				} else
					$out[$name] = $obj[$pname];
			} else
				$out[$name] = '';
		}
		return $out;
	}
	
	/**
	 * ������תΪ����
	 * @param object $obj ��ת������
	 * @param array $config ���Լ�ֵӳ���
	 */
	public static function objToArray($obj, $config) {
		self::clearErr();
		
		if(!is_object($obj)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 1 should be object.';
			return false;
		}
		
		if(!is_array($config)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Parameter 2 should be array.';
			return false;
		}
		
		$arr = array();
		foreach ($config as $k => $v) {
			if(isset($obj->$v)) {
				$arr[$k] = $obj->$v;
			} else {
				$arr[$k] = null;
			}
		}
		
		return $arr;
	}
	
	/**
	 * �����ݸ�ʽ��utf-8ת��Ϊgbk����ת������
	 * @param mixed $data ��ת������
	 * @param bool $recursive �Ƿ�ݹ�ת��
	 */
	public static function utf8ToGbk($data, $recursive = false) {
		if(!is_array($data)) {
			return iconv('utf-8', 'gbk', $data);
		} else {
			$new_data = array();
			foreach ($data as $k => $v) {
				if(!is_array($v)) {
					$new_data[$k] = iconv('utf-8', 'gbk', $data[$k]);
				} else {
					if($recursive) {
						$new_data[$k] = self::utf8ToGbk($data[$k]);
					} else {
						$new_data[$k] = $data[$k];
					}
				}
			}
			return $new_data;
		}
	}

	public static function convertCharset(&$data, $keys, $in_charset, $out_charset) {
		if(!is_array($data) || !is_array($keys)) {
			return;
		}

		foreach ($keys as $k) {
			if(isset($data[$k]) && is_string($data[$k])) {
				$data[$k] = iconv($in_charset, $out_charset, $data[$k]);
			}
		}

		return;
	}
} 