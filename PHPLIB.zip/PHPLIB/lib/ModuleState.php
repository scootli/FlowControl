<?php

//init,load configure
EL_ModuleState::init();

/**
 * module state reporter
 *
 * @author		bennylin <bennylin@tencent.com>
 * @created		2012/11/20
 * @version		$Id$
 */
class EL_ModuleState
{
	public static $errCode;
	public static $errMsg;

	/**
	 * result states
	 * @const int
	 */
	const SUCCESS = 0;
	const FAILED = 1;
	const FAILED_LOGIC = 2;
	const FAILED_DB = 3;
	const FAILED_NETWORK = 4;
	const FAILED_IO = 5;
	const FAILED_OTHER = 6;

	/**
	 * time shots at call start
	 * @var int
	 */
	private static $_start_time_shot_map	=	array();

	/**
	 * configs
	 * @var array
	 */
	private static $_rates = array();
	private static $_module_map = array();
	private static $_interface_map = array();

	/**
	 * is clogger exist
	 * @var boolean
	 */
	private static $_clogger_exist = false;

	/**
	 * init
	 *
	 * @return boolean
	 */
	public static function init()
	{
		$config = Config::getAllByType('module_state');
		if (!$config) {
			self::$errCode = 101;
			self::$errMsg = 'load module state config failed';
			return false;
		}

		self::$_rates = $config['RATES'];
		self::$_module_map = $config['MODULE_MAP'];
		self::$_interface_map = $config['INTERFACE_MAP'];

		//check CLogger
		if (!class_exists('CLogger', false)) {
			self::$errCode = 103;
			self::$errMsg = 'CLogger not exists';
			trigger_error(self::$errMsg, E_USER_WARNING);

			return false;
		}

		self::$_clogger_exist = true;

		return true;
	}

	/**
	 * start call
	 *
	 * @param string $call_module
	 * @param string $call_interface
	 *
	 * @return void
	 */
	public static function start($call_module, $call_interface)
	{
		//check module
		if (empty(self::$_module_map[$call_module])) {
			return 0;
		}

		//check interface
		if (empty(self::$_interface_map[$call_interface])) {
			return 0;
		}

		//get rate
		$rate = 0;
		if (isset(self::$_rates[$call_module]) ) {
			$rate = self::$_rates[$call_module];
		}
		elseif (isset(self::$_rates[$call_interface]) ) {
			$rate = self::$_rates[$call_interface];
		}

		//rating
		if ($rate && mt_rand(1, 10000000) > $rate * 10000000) {
			return 0;
		}

		//shot
		self::$_start_time_shot_map[$call_module . '|' . $call_interface] = microtime(true);

		return 1;
	}

	/**
	 * report result
	 *
	 * @param int $master_module	master module config id
	 * @param int $call_module		to call module config id
	 * @param int $call_interface	to call interface config id
	 * @param int $result_state		result: self::SUCCESS,  self::FAILED, self::FAILED_LOGIC, self::FAILED_DB...
	 * @param int $code			response code
	 * @param string $call_module_ip
	 * @param string $master_module_ip  default to local ip
	 *
	 * return mix	0/1/false
	 */
	public static function report($master_module, $call_module, $call_interface, $result_state, $code = 0, $call_module_ip = '0.0.0.0', $master_module_ip = null)
	{
		self::$errCode = 0;
		self::$errMsg = '';

		$time_shot_key = $call_module . '|' . $call_interface;

		//get this time shot
		if (!isset(self::$_start_time_shot_map[$time_shot_key]) ) {
			return 0;
		}

		$start_time	= self::$_start_time_shot_map[$time_shot_key];

		//unset this time shot
		unset(self::$_start_time_shot_map[$time_shot_key]);

		//driver not exist
		if (!self::$_clogger_exist) {
			return false;
		}

		if (empty(self::$_module_map[$master_module])) {
			self::$errCode = 104;
			self::$errMsg = "$master_module not defined";
			trigger_error(self::$errMsg, E_USER_WARNING);
			return false;
		}

		if (empty(self::$_module_map[$call_module])) {
			self::$errCode = 105;
			self::$errMsg = "$call_module not defined";
			trigger_error(self::$errMsg, E_USER_WARNING);
			return false;
		}

		if (empty(self::$_interface_map[$call_interface])) {
			self::$errCode = 106;
			self::$errMsg = "$call_interface not defined";
			trigger_error(self::$errMsg, E_USER_WARNING);
			return false;
		}

		//get the number id
		$master_module_id = self::$_module_map[$master_module];
		$call_module_id = self::$_module_map[$call_module];
		$call_interface_id = self::$_interface_map[$call_interface];

		//get the local ip when default
		if ($master_module_ip === null) {
			$master_module_ip = ToolUtil::getLocalIp(0);
		}

		$uses = (microtime(true) - $start_time) * 1000;

		//init driver
		static $cloggers = array();
		if (empty($cloggers[$master_module_id])) {
			$cloggers[$master_module_id] = new CLogger();
			$cloggers[$master_module_id]->init_mod($master_module_id);
		}

		//call msglog
		self::$errCode = $cloggers[$master_module_id]->write_modulelog($call_module_id, $call_interface_id, $master_module_ip, $call_module_ip, $code, $result_state, $uses, 0, 0, '', '');
		if (self::$errCode !== 0) {
			self::$errMsg = $cloggers[$master_module_id]->get_errmsg();
			return false;
		}

		return 1;
	}
}

//end of script
