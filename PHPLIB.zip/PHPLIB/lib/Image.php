<?php
/**
 * ����ͼƬ
 * 
 * @author Jimhuang
 */

class Image
{
	/**
	 * �������
	 * @var int
	 */
	public static $errCode = 0;

	/**
	 * ������Ϣ
	 * @var string
	 */
	public static $errMsg = '';
	
	/**
	 * �ļ���������
	 */
	private static $typeArr = array( 
		1 => 'GIF',
		2 => 'JPG', 
		3 => 'PNG', 
		4 => 'SWF', 
		5 => 'PSD', 
		6 => 'BMP', 
		7 => 'TIFF', //intel byte order
		8 => 'TIFF', //motorola byte order
		9 => 'JPC',
		10 => 'JP2', 
		11 => 'JPX',
		12 => 'JB2',
		13 => 'SWC',
		14 => 'IFF',
		15 => 'WBMP',
		16 => 'XBM',
	);
	
	/**
	 * ������ͼƬ����
	 */
	private static $allowedImgType = array('gif', 'jpeg', 'jpg', 'png');
	/**
	 * ��������ʶ����ÿ����������ǰ����
	 */
	private static function clearERR()
	{
		self::$errCode = 0;
		self::$errMsg  = '';
	}
	
	/**
	 * ѹ��ͼƬ
	 *
	 * @param	array	$imageInfo
	 * @return	
	 */
	public static function generateThumbnail($imageInfo)
	{
		self::clearERR();
		
		$imageInfo	= self::initImageInfo($imageInfo);
		//��������ļ�ȫ·��
		$pathArr	= self::setOutFilePaths($imageInfo);
		
		$inputComplete	= $pathArr['inputComplete'];
		
		$imgWidth	= $imageInfo['width'];
		$imgHeight	= $imageInfo['height'];
		$imgType	= $imageInfo['inputType'];
		if ( empty($imgWidth) || empty($imgHeight) || empty($imgType)) {
			$imgSize	= @GetImageSize( $inputComplete );
			if ($imgSize === false) {
				self::$errMsg	= 'This file is not image';
				return false;
			}
			$imgWidth  = $imgSize[0];
			$imgHeight = $imgSize[1];
			
			$imgType = strtolower(self::$typeArr[$imgSize[2]]);
		}
		
		$imgType = strtolower($imgType);
		$desiredWidth	= $imageInfo['desiredWidth'];
		$desiredHeight	= $imageInfo['desiredHeight'];
		if ( empty($desiredWidth) ) {
			self::$errMsg	= 'This desired image width is null';
			return false;
		}
		if ( empty($desiredHeight) ) {
			self::$errMsg	= 'This desired image height is null';
			return false;
		}

		if ( $imgWidth<$desiredWidth && $imgHeight<$desiredHeight ) {
			$desiredWidth	= $imgWidth;
			$desiredHeight	= $imgHeight;
		}
			
		$imageSize	= self::scaleImage(array('maxWidth'=>$desiredWidth,'maxHeight'=>$desiredHeight,'curWidth'=>$imgWidth,'curHeight'=>$imgHeight));
									   
		$thumbWidth		= $imageSize['imgWidth'];
		$thumbHeight	= $imageSize['imgHeight'];	
		
		if (!in_array($imgType, self::$allowedImgType)) {
			self::$errMsg	= 'This type image could not create thumbnail';
			return false;
		}
		
		if ( $imgType == 'gif' ){
			if ( imagetypes() & IMG_GIF ){
				$image = @imagecreatefromgif( $inputComplete );
			}
		} else if ( $imgType == 'png' ) {
			if ( imagetypes() & IMG_PNG ) {
				$image = @imagecreatefrompng( $inputComplete );
			}
		} else if (  $imgType == 'jpg' ) {
			if ( imagetypes() & IMG_JPG ) { 
				$image = @imagecreatefromjpeg( $inputComplete );
			}
		} else if (  $imgType == 'wbmp' )	{
			if ( imagetypes() & IMG_WBMP ) { 
				$image = @imagecreatefromwbmp( $inputComplete );
			}
		} else {
			self::$errMsg = 'This type image could not create thumbnail';
			return false;
		}
								
		//---------------------------------------------
		// Did we get a return from imagecreatefrom?
		//---------------------------------------------

		if (empty($image)) {
			self::$errMsg	= 'PHP GD function not support';
			return false;
		} else if ($imageInfo['gdVersion'] == 1) {
			$thumb = @imagecreate( $imageSize['imgWidth'], $imageSize['imgHeight'] );
			@imagecopyresized( $thumb, $image, 0, 0, 0, 0, $imageSize['imgWidth'], $imageSize['imgHeight'], $imgWidth, $imgHeight );
		} else {
			if ($imgType == 'gif') {
				$thumb				= @imagecreate( $imageSize['imgWidth'], $imageSize['imgHeight'] );
				$backgroundColor	= imagecolorallocatealpha($thumb, 255, 255, 255, 127);
				@imagecolortransparent($thumb, $backgroundColor);
				@imagecopyresized( $thumb, $image, 0, 0, 0, 0, $imageSize['imgWidth'], $imageSize['imgHeight'], $imgWidth, $imgHeight );
			} else {
				$thumb = @imagecreatetruecolor( $imageSize['imgWidth'], $imageSize['imgHeight'] );
				@imagecopyresampled($thumb, $image, 0, 0, 0, 0, $imageSize['imgWidth'], $imageSize['imgHeight'], $imgWidth, $imgHeight );
			}
			
					
			//-----------------------------------------------
			// Saving?
			//-----------------------------------------------
			$inputFileName	= $imageInfo['inputName'];
			$outFileName	= $imageInfo['outputName'];
			if ( empty($imageInfo['outputName']) ) {
				$outFileName	= preg_replace( "/^(.*)\..+?$/", "\\1", $inputFileName ) . '_thumb';
			}
			
			$outputDir	= $imageInfo['outputDir'];
			if(!is_dir($outputDir)) {
				if (! @mkdir($outputDir, 0777, true) ) {
					self::$errMsg = 'Cannot create thumbnail dir';
					return false;
				}
			}

			if (! is_writeable($outputDir) ) {
				@chmod( $outputDir, 0777 );
			}
			
			// modified by Peter Du
			$outImageType	= $imageInfo['outputType'];
			if ( empty($outImageType) ) {
				$outImageType	= $imgType;
			}
			
			if (in_array($outImageType, self::$allowedImgType)) {
				$functionName	= ($outImageType == 'jpg') ? 'imagejpeg' : 'image'.$outImageType;
				
				if (function_exists($functionName)) {
					@$functionName( $thumb, $outputDir."/".$outFileName.'.'.$outImageType);
					@chmod( $outputDir."/".$outFileName.'.'.$outImageType, 0777 );
					@imagedestroy( $thumb );
					@imagedestroy( $image );
					$thumbLocation	= $outputDir."/".$outFileName.'.'.$outImageType;
				}
			}
		}
		
		$imageArr	= array(
			'thumbLocation'	=> $thumbLocation,
			'thumbWidth'	=> $thumbWidth,
			'thumbHeight'	=> $thumbHeight,	
		);
		
		return $imageArr;
	}
	
	/**
	 * ��ͼƬ�ϼ�ˮӡ
	 *
	 * @param	array	$imageInfo(
	 * 						'imgUrl'	:Ҫ��logo��ͼƬ��ַ
	 * 						'markUrl'	:logo��ַ
	 * 						'refPoint'	:��logo������ 0(����), 1(����), 2(����), 3(����)
	 * 						'xPos'		:logo�� x���� �յ�
	 * 						'yPos'		:logo�� y���� �յ�
	 * 						'squareLimit': Դͼ�����߲���ͬʱС�ڸ�ֵ
	 * 						'minLimit'	:Դͼ�����ߵ���Сֵ
	 * 						'scaleLimit':�Ƿ���Сlogo(��ͼƬ�Ķ̱�С�ڸ�ֵ�ǰ�������С)
	 * ) 					
	 * @return unknown
	 */
	public static function makeLogo($imageInfo)	
	{
		self::clearERR();
		
		//��ȡlogo��ַ
		if ( empty($imageInfo['markUrl']) ) {
			self::$errCode	= 1001;
			self::$errMsg	= 'Empty water_mark image url';
			return false;
		}
		$markUrl = $imageInfo['markUrl'];
		
		//��ȡԭͼ��ַ
		if ( empty($imageInfo['imgUrl']) ) {
			self::$errCode	= 1000;
			self::$errMsg	= 'Empty original image url';
			return false;
		}
		$srcImg		= $imageInfo['imgUrl'];
		//��ȡԭͼ��Ϣ
		$srcImgInfo	= @getimagesize($srcImg);
		if ($srcImgInfo === false) {
			self::$errCode	= 1002;
			self::$errMsg	= 'Can not get info of original image ' . $srcImg;
			return false;
		}
		$srcImgWidth	= $srcImgInfo[0];
		$srcImgHight	= $srcImgInfo[1];
		$srcImgType		= $srcImgInfo[2];
		
		//��ȡ��ԴͼƬ��С����
		$squareLimit	= empty($imageInfo['squareLimit']) ? '' : intval($imageInfo['squareLimit']);
		$sizeLimit		= empty($imageInfo['minLimit']) ? '' : intval($imageInfo['minLimit']);

		if ( $squareLimit || $sizeLimit ) {
			// original image is too small
			if ( ($srcImgWidth <= $squareLimit && $srcImgHight <= $squareLimit) || ($srcImgWidth <= $sizeLimit) || ($srcImgHight <= $sizeLimit) ) {
				self::$errCode	= 1003;
				self::$errMsg	= "srcImage is too small. width-{$srcImgWidth},hight-{$srcImgHight} squareLimit-{$squareLimit},sizeLimit-{$sizeLimit}";
			}
		}
		
		//��ȡlogoͼƬ��Ϣ
		$markImgInfo	= @getimagesize($markUrl);
		if ($markImgInfo === false) {
			self::$errCode	= 1004;
			self::$errMsg	= 'Can not get info of Logo image. logoUrl:' . $markUrl;
			return false;
		}

		$markWidth	= $markImgInfo[0];
		$markHight	= $markImgInfo[1];
		$markType	= $markImgInfo[2];

		if ( $markType != IMAGETYPE_PNG ) {
			self::$errCode	= 1005;
			self::$errMsg	= 'Type of water_mark image maybe PNG';
			return false;
		}

		//��ȡlogo����ص�
		$refPoint	= isset($imageInfo['refPoint']) ? abs((int)$imageInfo['refPoint']) : 2;
		$refPoint	= ($refPoint > 3) ? 3 : $refPoint;
			
		//logo�������յ�
		$xPos = (empty($imageInfo['xPos'])) ? $srcImgWidth : intval($imageInfo['xPos']);
		$yPos = (empty($imageInfo['yPos'])) ? $srcImgHight : intval($imageInfo['yPos']);
		
		//��ȡlogo��ͷ���ʶ��
		$markIMG = @imagecreatefrompng($markUrl);
		if ($markIMG === false) {
			self::$errCode	= 1006;
			self::$errMsg	= 'Can not create resource from water_mark image';
			return false;
		}

		$markImgRes		= $markIMG;
		$markXoffset	= $markWidth;
		$markYoffset	= $markHight;

		// ��ȡ�����ٽ糤��
		$scaleLimit	= empty($imageInfo['scaleLimit']) ? 0 : intval($imageInfo['scaleLimit']);
		//��ȡԴͼ�϶̱߳���
		$scrSmallSize	= ($srcImgWidth > $srcImgHight) ? $srcImgHight : $srcImgWidth;

		// ����ˮӡ
		if ( $scrSmallSize < $scaleLimit ) {
			
			//���ű���
			$rate = $scrSmallSize / $scaleLimit;
			
			$markDstWidth = ceil($markWidth * $rate);
			$markDstHight = ceil($markHight * $rate);
			
			$tmpMarkImg = @imagecreatetruecolor($markDstWidth, $markDstHight);
			@imagealphablending($tmpMarkImg, false);
			@imagesavealpha($tmpMarkImg, true);
			@imagecopyresampled($tmpMarkImg, $markIMG, 0, 0, 0, 0, $markDstWidth, $markDstHight, $markWidth, $markHight);
			
			if ($tmpMarkImg === false) {
				self::$errCode	= 1007;
				self::$errMsg	= 'Can not create resized image resource from water_mark image';
				return false;
			}

			$markImgRes		= $tmpMarkImg;
			$markXoffset	= $markDstWidth;
			$markYoffset	= $markDstHight;
		}

		// get original image resource
		switch ( $srcImgType )
		{
			case IMAGETYPE_GIF:
				$temSrcImg	= @imagecreatefromgif($srcImg);
				$desImg		= imagecreatetruecolor($srcImgWidth, $srcImgHight);
				@imagecopy($desImg, $temSrcImg, 0, 0, 0, 0, $srcImgWidth, $srcImgHight);
				@imagedestroy($temSrcImg);
				break;
			case IMAGETYPE_JPEG:
				$desImg	= @imagecreatefromjpeg($srcImg);
				break;
			case IMAGETYPE_PNG:
				$desImg	= @imagecreatefrompng($srcImg);
				break;
			case IMAGETYPE_WBMP:
				$desImg	= @imagecreatefromwbmp($srcImg);
				break;
			default:
				self::$errCode	= 1008;
				self::$errMsg	= 'Does not support this type of original image';
				return false;
		}

		if ($desImg === false) {
			self::$errCode	= 1009;
			self::$errMsg	= 'Can not get resource of original image';
			return false;
		}
		//��ȡ��logo�ľ�������
		switch ($refPoint)
		{
			case 0:
				$xpos = $xPos;
				$ypos = $yPos;
				break;
			case 1:
				$xpos = $srcImgWidth - $markXoffset - $xPos;
				$ypos = $yPos;
				break;
			case 2:
				$xpos = $srcImgWidth - $markXoffset - $xPos;
				$ypos = $srcImgHight - $markYoffset - $yPos;
				break;
			case 3:
			default :
				$xpos = $xPos;
				$ypos = $srcImgHight - $markYoffset - $yPos;
				break;
		}

		// ��logo
		@imagecopy($desImg, $markImgRes, $xpos, $ypos, 0, 0, $markXoffset, $markYoffset);
		umask(0);

		$imgUrl	= $imageInfo['imgUrl'];
		switch ( $srcImgType )
		{
			case IMAGETYPE_GIF:
				$succ	= @imagegif($desImg, $imgUrl);
				break;
			case IMAGETYPE_JPEG:
				$succ	= @imagejpeg($desImg, $imgUrl);
				break;
			case IMAGETYPE_PNG:
				$succ	= @imagepng($desImg, $imgUrl);
				break;
			case IMAGETYPE_WBMP:
				$succ	= @imagewbmp($desImg, $imgUrl);
				break;
		}
		
		if ($succ === false) {
			self::$errCode	= 1010;
			self::$errMsg	= "imagepng fail. param1-{$desImg}, param2-{$imgUrl}";
			return false;
		}

		@imagedestroy($markIMG);
		@imagedestroy($markImgRes);
		@imagedestroy($srcImg);
		@imagedestroy($desImg);
		
		return $imgUrl;
}
	
	
	/**
	 * �����ļ�����ȫ·��������ļ�Ŀ¼
	 *
	 * @param	array	$imageInfo
	 * @return	array('inputComplete', 'outputDir')
	 */
	private static function setOutFilePaths($imageInfo)
	{
		$inputDir  = preg_replace( "#/$#", "", $imageInfo['inputDir'] );
		$outputDir = preg_replace( "#/$#", "", $imageInfo['outputDir'] );
		
		if ( !empty($inputDir) && !empty($imageInfo['inputName']) ){
			$inputComplete	= $inputDir.'/'.$imageInfo['inputName'];
		} else {
			$inputComplete	= $imageInfo['inputName'];
		}
		
		if ( empty($outputDir) ) {
			$outputDir	= $inputDir . '_thumb';
		}
		
		return array('inputComplete'=>$inputComplete, 'outputDir'=>$outputDir);
	}
	
	/**
	 * ��ʼ��ͼƬ��Ϣ����
	 *
	 * @param	array	$imageInfo
	 * @return	array	
	 */
	private static function initImageInfo($imageInfo)
	{
		$imageInit	= array(
			'width'			=> 0,	// ͼƬ����
			'height'		=> 0,	// ͼƬ�߶�
			'inputType'		=> '',	// ����ͼƬ�ĸ�ʽ
			'outputType'	=> '', 					// ��� jpg ��ʽͼƬ
			'inputDir'		=> '.',// ��ѹ���ļ�·��
			'inputName'		=> '',	// ��ѹ���ļ���(����׺)
			'outputDir'		=> '',	// ���ѹ���ļ�·��
			'outputName'	=> '',	// ���ѹ���ļ���,(ѹ���ļ����Զ�׷�� .jpg)
			'gdVersion'		=> 2,
			'desiredWidth'	=> 0,
			'desiredHeight' => 0,
		);
		
		return array_merge($imageInit, $imageInfo);
	}
	
	/**
	 * ��ȡͼƬ��С
	 *
	 * @param	array	$arg
	 * @return	array	$imageSize
	 */
	private static function scaleImage($arg)
	{
		$imageSize	= array(
			'imgWidth'	=> $arg['curWidth'],
			'imgHeight'	=> $arg['curHeight']
		);
		
		if ( $arg['curWidth'] > $arg['maxWidth'] ) {
			$imageSize['imgWidth']	= $arg['maxWidth'];
			$imageSize['imgHeight']	= ceil( ( $arg['curHeight'] * ( ( $arg['maxWidth'] * 100 ) / $arg['curWidth'] ) ) / 100 );
			$imageSize['curHeight']	= $imageSize['imgHeight'];
			$imageSize['curWidth']	= $imageSize['imgWidth'];
		}
		
		if ( $arg['curHeight'] > $arg['maxHeight'] ) {
			$imageSize['imgHeight']	= $arg['maxHeight'];
			$imageSize['imgWidth']	= ceil( ( $arg['curWidth'] * ( ( $arg['maxHeight'] * 100 ) / $arg['curHeight'] ) ) / 100 );
		}
		
		return $imageSize;
	}
	
}
	
//End of script

	