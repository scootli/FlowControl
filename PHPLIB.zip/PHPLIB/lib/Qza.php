<?php
require_once '_init.php';

class Qza
{
	
}