<?php
/**
 * CDBFactory.php 
 *
 * @copyright	(c) 1998-2011 All Rights Reserved
 * @author		daopingsun <daopingsun@tencent.com>
 * @created		2013-3-7
 * @version		$Id$
 */
//init & setting
date_default_timezone_set('Asia/Shanghai');

if (!defined('PHPLIB_ROOT'))
{
	define('PHPLIB_ROOT', dirname(dirname(__FILE__)) . '/');
}

require_once PHPLIB_ROOT . 'etc/' . get_cfg_var('env.name') . '.inecfg.inc.php';
require_once PHPLIB_ROOT . 'inc/constant.inc.php';
require_once PHPLIB_ROOT . 'lib/CDB.php';


class CDBFactory {
	/**
	 * 错误编码
	 *
	 * @var int
	 */
	public static $errCode = 0;

	/**
	 * 错误信息
	 *
	 * @var string
	 */
	public static $errMsg = '';

	/**
	 * 保存项目中CDB的句柄
	 *
	 * @var array
	 */

	private static $CDBResMap = array();

	/**
	 * 保存项目中CDB的配置
	 *
	 * @var array
	 */
	private static $CDBConfig;
//	private static	$_instances	=	array();
	

	/**
	 * 清除错误标识，在每个函数调用前调用
	 */
	private static function clearERR()
	{
		self::$errCode = 0;
		self::$errMsg  = '';
	}


	private static function init(){
		global $_CDB_CFG;
		if(empty(self::$CDBConfig)){
			//self::$CDBConfig = Rest::getConf('CDBConfig');
			self::$CDBConfig =  $_CDB_CFG;
		}
	}

	/**
	 * 
	 * @param string $name
	 * 
	 * @return resource|object|false:
	 */
	public static function getCDB($key) {

		self::init();
		self::clearERR();

		// 判断参数
		if (!isset(self::$CDBConfig[$key]) || empty(self::$CDBConfig[$key]['IP'])){
			self::$errCode = 20000;
			self::$errMsg = "no CDB config info for key {$key}";
			return false;
		}

		$cfg = self::$CDBConfig[$key];
		$cfg['PORT'] = empty($cfg['PORT']) ? 3306 : $cfg['PORT'];

		// 如果在前面已创建该 CDB 资源，则直接返回
		if (isset(self::$CDBResMap[$key])){
			if (self::$CDBResMap[$key]->selectDB($cfg['DB'])) {
				return self::$CDBResMap[$key];
			}

			//retry
			if (self::$CDBResMap[$key]->selectDB($cfg['DB'])) {
				return self::$CDBResMap[$key];
			}

//			Logger::warn("change the mysql db fail : {$cfg['DB']} [" . self::$DBResMap[$cacheKey]->errCode . ' : ' . self::$DBResMap[$cacheKey]->errMsg . ']');
			self::$errCode = self::$CDBResMap[$key]->errCode;
			self::$errMsg = "change the mysql db fail : {$cfg['DB']} [".self::$CDBResMap[$key]->errMsg . ']';

			self::$CDBResMap[$key]->closeDB();
			unset(self::$CDBResMap[$key]);

			return false;
		}

		// 创建 DB 对象
		$CDB = new CDB($cfg['IP'], $cfg['PORT'], $cfg['DB'], $cfg['USER'], $cfg['PASSWD']);
		if ($CDB->errCode > 0) {
			self::$errCode = 20001;
			self::$errMsg = "create DB connnect failed for {$key}: " . $CDB->errCode . " " . $CDB->errMsg;
			return false;
		}

		//for module state report
		$CDB->configId = $key;

		// 保存到类属性中
		self::$CDBResMap[$key] = $CDB;
		return self::$CDBResMap[$key];
	}
	
	public static function remove($key) {
		if ( isset(self::$CDBResMap[$key]) ) {
			unset(self::$CDBResMap[$key]);
		}
	}
	
	public static function removeAll() {
		foreach (self::$CDBResMap as $obj) {
			unset($obj);
		}
	}
}

//end of script
