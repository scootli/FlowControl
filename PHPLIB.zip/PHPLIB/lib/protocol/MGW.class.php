<?php

class MGW {
	private $len;
	private $md5;
	private $cmd;
	private $seq;
	private $prot_ver;
	private $api_ver;
	private $reqtime;
	private $uin;
	private $ruleid;
	private $reserved;
	private $resultcode;
	private $resultinfo;
	
	private $body_len;
	private $body_content;
	
	private $key;
	
	public static $errCode = 0;
	public static $errMsg = '';
	
	private function __construct() {}
	
	public function encodePackage($pkg) {
		$data = ArrayUtil::array_fetch($pkg, array(
			'cmd' => array( 'allowEmpty' => false, 'secureType' => 'int' ),
			'seq' => array( 'secureType' => 'int', 'default' => 1 ),
			'uin' => array( 'allowEmpty' => false, 'secureType' => 'int'),
			'ruleid' => array( 'allowEmpty' => false ),
			'reserved' => array(),
			'params' => array( 'default' => array() )
		));
		if($data === false) {
			throw new BaseException(ArrayUtil::$errCode, ArrayUtil::$errMsg);
		}
		
		$this->cmd = $data['cmd'];
		$this->seq = $data['seq'];
		$this->prot_ver = 100;
		$this->api_ver = 100;
		$this->reqtime = time();
		$this->uin = $data['uin'];
		$this->ruleid = substr($data['ruleid'], 0, 64);
		$this->reserved = substr($data['reserved'], 0, 64);
		$this->resultcode = 0;
		$this->resultinfo = '';
		
		$this->body_content = $this->getBodyContent($data['params']);
		$this->body_len = strlen($this->body_content);
		
		$this->key = $this->getMd5Key();
		
		$md5Body = pack('nNnnNNa64a64Na128na' . $this->body_len . 'a*', 
			$this->cmd, 
			$this->seq, 
			$this->prot_ver, 
			$this->api_ver,
			$this->reqtime,
			$this->uin,
			$this->ruleid,
			$this->reserved,
			$this->resultcode,
			$this->resultinfo,
			$this->body_len,
			$this->body_content,
			$this->key
		);
		$this->md5 = md5($md5Body);
		$this->len = 300 + $this->body_len + strlen($this->key);
		
		return pack('Na16a*', $this->len, $this->md5, $md5Body);
	}
	
	public function decodeMessage($msg) {
		$this->len = array_shift(unpack('N', $msg));
		$this->md5 = array_shift(unpack('a16', substr($msg, 4)));
		$this->cmd = array_shift(unpack('n', substr($msg, 20)));
		$this->seq = array_shift(unpack('N', substr($msg, 22)));
		$this->prot_ver = array_shift(unpack('n', substr($msg, 26)));
		$this->api_ver = array_shift(unpack('n', substr($msg, 28)));
		$this->reqtime = array_shift(unpack('N', substr($msg, 30)));
		$this->uin = array_shift(unpack('N', substr($msg, 34)));
		$this->ruleid = array_shift(unpack('a64', substr($msg, 38)));
		$this->reserved = array_shift(unpack('a64', substr($msg, 102)));
		$this->resultcode = array_shift(unpack('N', substr($msg, 166)));
		$this->resultinfo = array_shift(unpack('a128', substr($msg, 170)));
		if($this->len > 298) {
			$this->body_len = array_shift(unpack('n', substr($msg, 298)));
			$key_len = $this->len - 300 - $this->body_len;
			$this->body_content = array_shift(unpack('a' . $this->body_len, substr($msg, 300)));
			$this->key = array_shift(unpack('a' . $key_len, 300 + $this->body_len));
		} else {
			$this->body_len = 0;
			$this->body_content = '';
			$this->key = '';
		}
	}
	
	private function getBodyContent($params) {
		$tks = array();
		foreach ($params as $k => $v) {
			$tks[] = $k . '=' . urlencode($v);
		}
		return implode('&', $tks);
	}
	
	private function getMd5Key() {
		$key = '';
		for($i = 0; $i < strlen($this->ruleid); $i += 2) {
			$key .= strrev(substr($this->ruleid, $i, 2));
		}
		return $key;
	}
	
	private static function clearErr() {
		self::$errCode = 0;
		self::$errMsg = '';
	}
	
	public static function encode($pkg) {
		self::clearErr();
		
		try {
			$mgw = new MGW();
			return $mgw->encodePackage($pkg);
		} catch(BaseException $e) {
			self::$errCode = $e->errCode;
			self::$errMsg = $e->errMsg;
			return false;
		}
	}
	
	public static function decode($msg) {
		self::clearErr();
		
		try {
			$mgw = new MGW();
			return $mgw->decodeMessage($msg);
		} catch(BaseException $e) {
			self::$errCode = $e->errCode;
			self::$errMsg = $e->errMsg;
			return false;
		}
	}
}