<?php
/**
 * ��Q��¼
 */
class SqLogin
{
	private $conf;

	const LOGIN_URL = 'http://waykyhe.adm0309.3g.qq.com/s?aid=bizp&pt=page&pc=sqqliveopen';
	const SECRET = 'S%q$Q,*l^J&h(';
	
	private $method = 'GET';

	function __construct($conf)
	{
		if(empty($conf['appid']))
		{
			throw new Exception("WapPtlogin require appid");
		}
		$this->conf = $conf;
	}

	function getLoginURL($callback)
	{
		return self::LOGIN_URL . '&gurl='.urlencode($callback);
	}
	
	static function getKey($params)
	{
		return strtoupper(md5($params['issqq'].$params['openid'].$params['time'].self::SECRET));
	}
}