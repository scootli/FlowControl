<?php
/**
 * abstract
 * ��֤��
 * */
class VerifyCode{
	const CODE_KEY = '$#fd3!';
	public static $errCode = 0;
	public static $errMsg = '';

	/**
	 * ���ó�������ͳ�����Ϣ
	 * @param int $code
	 * @param string $msg
	 */
	private static function setErrMsg($code, $msg='') {
		self::$errCode = $code;
		self::$errMsg = $msg;
	}

	/**
	 * ��֤
	 * */
	public static function verifycodeNum($codeNum){
		if (!isset($_COOKIE['vcode'])) {
			self::setErrMsg(404, 'vcode is null');
			return false;
		}

		$codeNum = strtolower(trim($codeNum));
		$vcode = strtolower($_COOKIE['vcode']);
		$vcode = pack("H*", $vcode);
		$vcode = mcrypt_ecb(MCRYPT_3DES, self::CODE_KEY, $vcode, MCRYPT_DECRYPT);

		$vcode = strtolower(trim($vcode));

		$vcode = explode(',', $vcode);

		if(count($vcode) != 2 || $vcode[0] != $codeNum || time() - $vcode[1] > 2 * 60){
			self::setErrMsg(500, 'vcode is invalid');
			return false;
		}
		else {
			unset($_COOKIE['vcode']);
			return true;
		}
	}

	/**
	 * ����
	 * */
	public static function generateCodeNum(){
		$vc = new PicCode();

		$vc->setWidth(100);
		$vc->setHeight(26);
		$vc->setFontSize(16);
		$vc->setTextNumber(4);
		$vc->setNoisePoint(80);
		$vc->setNoiseLine(4);
		$vc->setDistortion(TRUE);

		@ob_clean();
		@ob_start();
		$v = $vc->createImage();
		if(strlen($v) != 4) {
			return false;
		}

		$time = time();
		$vcode = mcrypt_ecb(MCRYPT_3DES, self::CODE_KEY, strtolower($v . ',' . $time), MCRYPT_ENCRYPT);
		$vcode = strtoupper(bin2hex($vcode));
		setcookie('vcode', $vcode);
		@ob_end_flush();
	}

	/**
	 * ����
	 * */
	public static function generateCodeNum2(){
		$vc = new PicCode();
		$vc->setTextNumber(4);
		$v = str_replace(',', '', $vc->randText('en'));

		$time = time();
		$vcode = mcrypt_ecb(MCRYPT_3DES, self::CODE_KEY, strtolower($v . ',' . $time), MCRYPT_ENCRYPT);
		$vcode = strtoupper(bin2hex($vcode));
		setcookie('vcode', $vcode);
		
		return $v;
	}
}