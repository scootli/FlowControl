<?php
/**
 * ��¼һЩphp��Ҫ��������ˮ����־��
 * @author ��ѧ��
 * @version 1.0
 * @updated 03-����-2008 23:45:23
 */
class BinLog
{
	// ��־�ļ�����
	private $curBinLogFileName;
	private $binLogDir;

	// ������ˮ
	private $records = array();

	// ��¼ cache �б������ˮ�Ĵ�С, ��ÿ 100��дһ���ļ�
	private $maxRecordCount;

	// ����log�ļ��ľ��
	private $logFile;
	private $intervalTime;

	function __construct($binlogDir, $intervalTime, $maxRecordCount=1)
	{
		$this->binLogDir = $binlogDir;
		$this->intervalTime = $intervalTime;
		$this->maxRecordCount = $maxRecordCount;
	}

	function __destruct()
	{
		$this->cacheToDisk();
		if ( !empty($this->logFile) ) {
			fclose($this->logFile);
		}
	}

	/**
	 * ��¼log
	 *
	 * @param		string		$str, log��Ϣ
	 */
	function log($str)
	{
		$this->records[]="{$str}\n";
		if ( count($this->records) >= $this->maxRecordCount ) {
			$this->cacheToDisk();
		}

		return true;
	}

	/**
	 * ��cache�еļ�¼��д�������
	 */
	private function cacheToDisk()
	{
		$len = count($this->records);
		if ( $len == 0 ) {
			return true;
		}
		$curTime = time();
		$curTime = floor($curTime / $this->intervalTime) * $this->intervalTime;
		$curTime = date('YmdHis',$curTime);
		$binFileName = $this->binLogDir .'/'. $curTime .'.bin';
		if ( empty($this->logFile) ){
			$this->curBinLogFileName = $binFileName;
			$this->logFile = fopen($this->curBinLogFileName, 'a');
		} elseif ( $this->curBinLogFileName != $binFileName ) {
			if ( !empty($this->logFile) ) {
				fclose($this->logFile);
			}
			$this->curBinLogFileName = $binFileName;
			$this->logFile = fopen($this->curBinLogFileName, 'a');
		}

		for ($i = 0; $i < $len; $i++) {
			fwrite($this->logFile, $this->records[$i]);
		}
		$this->records = array();
		return true;
	}
}

//End of script

