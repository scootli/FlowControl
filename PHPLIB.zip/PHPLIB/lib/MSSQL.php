<?php
if(!defined("PHPLIB_ROOT"))
{
	define('PHPLIB_ROOT', dirname(dirname(__FILE__)) . '/');
	require_once PHPLIB_ROOT . 'lib/Config.php';
}

class MSSQL
{
	/**
	 * ���ñ�ʶ
	 * �����ϱ��Ȳ���
	 * @var string
	 */
	public $configId;

	/**
	 * ���ݿ����ip
	 *
	 * @var string
	 */
	private $host;

	/**
	 * ���ݿ�˿�
	 *
	 * @var string
	 */
	private $port;

	/**
	 * �û���
	 *
	 * @var string
	 */
	private $user;

	/**
	 * ����
	 *
	 * @var string
	 */
	private $password;

	/**
	 * ���ݿ�����
	 */
	public $db_name;

	/**
	 * ���ݿ�����
	 *
	 * @var object
	 */
	private $con;

	/**
	 * db����
	 *
	 * @var string
	 */
	private $db;

	/**
	 * �������
	 *
	 * @var int
	 */
	public $errCode = 0;

	/**
	 * ������Ϣ
	 *
	 * @var string
	 */
	public $errMsg = '';

	/**
	 * ��������ʶ����ÿ����������ǰ����
	 */
	private function clearERR()
	{
		$this->errCode = 0;
		$this->errMsg  = '';
	}

	/**
	 *
	 * @param string host     ����ip
	 * @param int    port     �˿�
	 * @param string db_name  ���ݿ�����
	 * @param string user     �û�����
	 * @param string password ����
	 */
	public function __construct($host, $port, $db_name, $user, $password)
	{
		$this->host = $host;
		$this->port = $port;
		$this->db_name = $db_name;
		$this->user = $user;
		$this->password = $password;
	}

	public function __destruct()
	{
		$this->closeDB();
	}

	/**
	 * ��ʼ������
	 */
	public  function init()
	{
		//for report
		EL_ModuleState::start("db.{$this->configId}", 'db.connect');

		$this->con = mssql_connect($this->host . (empty($this->port) ? '' : (':' . $this->port)), $this->user, $this->password);
		if (!$this->con)
		{
			$last_message = mssql_get_last_message();

			$this->errCode = 10301;
			$this->errMsg="srv:{$this->host}:{$this->port}} error:". $last_message;

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.connect', EL_ModuleState::FAILED_DB, $this->errCode, $this->host);

			return false;
		}

		if (!mssql_select_db($this->db_name, $this->con)) {
			$last_message = mssql_get_last_message();

			$this->errCode = 10302;
			$this->errMsg="db:{$this->host}:{$this->port}:{$this->db_name} error:".$last_message;

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.connect', EL_ModuleState::FAILED_DB, $this->errCode, $this->host);
			return false;
		}

		//report
		EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.connect', EL_ModuleState::SUCCESS, 0, $this->host);

		return true;
	}


	/**
	 * ����Ĭ�����ݿ�����
	 */
	function selectDB($db_name) {
		$this->db_name = $db_name;

		//for report
		EL_ModuleState::start("db.{$this->configId}", 'db.select_db');

		$ret = mssql_select_db($this->db_name, $this->con);

		if (!$ret) {
			$last_message = mssql_get_last_message();

			$this->errCode = 10308;
			$this->errMsg="db:{$this->host}:{$this->port}:{$this->db_name} error:".$last_message;

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select_db', EL_ModuleState::FAILED_DB, $this->errCode, $this->host);
			return false;
		}

		//report
		EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select_db', EL_ModuleState::SUCCESS, 0, $this->host);

		return true;
	}

	/**
	 * �ر����ݿ�����
	 */
	function closeDB()
	{
		if ($this->con) {
			return @mssql_close($this->con);
		}
		return true;
	}

	/**
	 * ���ݲ�ѯsql�����ָ��������
	 *
	 * @param  string sql    sql���
	 * @return bool ��ȷ��������,���󷵻�false
	 */
	public function getRows($sql)
	{
		$this->clearERR();

		//for report
		EL_ModuleState::start("db.{$this->configId}", 'db.select');

		$result = mssql_query($sql, $this->con);
		if($result === false){
			$this->errCode = 10303;
			$this->errMsg  = 'host:'.$this->host.',port:'.$this->port.',db:'.$this->db_name.',sql:'.$sql.',error:'.mssql_get_last_message();

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select', EL_ModuleState::FAILED_DB, $this->errCode, $this->host);

			//error
			EL_Flow::getInstance('ms_sql_error')->append(mssql_get_last_message());

			return false;
		}

		//report
		EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select', EL_ModuleState::SUCCESS, 0, $this->host);

		$data = array();
		do
		{
			while (($row = mssql_fetch_array($result, MSSQL_ASSOC)))
			{
				$data[] = $row;
			}
		} while(mssql_next_result($result));

		mssql_free_result($result);
		return $data;
	}

	/**
	 * ������ݿ����ָ������
	 *
	 * @param   string table    ������
	 * @param   array fields    ��Ҫ��ȡ��������
	 * @param   string condition    ��ѯ����
	 * @param   int startIndex    ��ʼ��¼λ��
	 * @param   int length    ��Ҫȡ�õ�������
	 *
	 * @return  bool ��ȷ����true�����򷵻�false
	 */
	public function getRows2($table, $fields, $condition, $startIndex, $length)
	{
		$this->clearERR();

		//for report
		EL_ModuleState::start("db.{$this->configId}", 'db.select');

		$n_str = '';
		$table = $this->msEscapeStr($table);
		if (!empty($fields) && is_array($fields))
		{
			foreach ($fields as $v)
			{
				$n_str .= $this->msEscapeStr($v).',';
			}
			$n_str = preg_replace("/,$/", "", $n_str);
		}
		if (empty($n_str))
		{
			$n_str = '*';
		}

		$limit = is_int($startIndex) && is_int($length) && $startIndex >= 0 && $length > 0;
		$sql = 'SELECT '. ($limit ? (' TOP ' . ($startIndex + $length) . ' ') : '') . $n_str.' FROM '.$table;
		if (!empty($condition))
		{
			$sql .= ' WHERE '.$condition;
		}

		$result = @mssql_query($sql, $this->con);
		if($result === false){
			$last_message = mssql_get_last_message();

			$this->errCode = 10303;
			$this->errMsg  = 'host:'.$this->host.',port:'.$this->port.',db:'.$this->db_name.',sql:'.$sql.',error:'. $last_message;

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select', EL_ModuleState::FAILED_DB, $this->errCode, $this->host);

			//error
			EL_Flow::getInstance('ms_sql_error')->append($last_message);

			return false;
		}

		$rows = mssql_num_rows($result);
		if ($rows === false) {
			$last_message = mssql_get_last_message();

			$this->errCode = 10305;
			$this->errMsg  = 'host:'.$this->host.',port:'.$this->port.',db:'.$this->db_name.',sql:'.$sql.',error:' . $last_message;

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select', EL_ModuleState::FAILED_DB, $this->errCode, $this->host);

			//error
			EL_Flow::getInstance('ms_sql_error')->append($last_message);

			return false;
		}

		if($rows > $startIndex && !mssql_data_seek($result, $startIndex))
		{
			$last_message = mssql_get_last_message();

			$this->errCode = 10304;
			$this->errMsg  = 'host:'.$this->host.',port:'.$this->port.',db:'.$this->db_name.',sql:'.$sql.',error:' . $last_message;

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select', EL_ModuleState::FAILED_DB, $this->errCode, $this->host);

			//error
			EL_Flow::getInstance('ms_sql_error')->append($last_message);

			return false;
		}

		//report
		EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select', EL_ModuleState::SUCCESS, 0, $this->host);

		$data = array();
		do
		{
			while (($row =  mssql_fetch_array($result, MSSQL_ASSOC)))
			{
				$data[] = $row;
			}
		} while(mssql_next_result($result));

		mssql_free_result($result);
		return $data;
	}

	/**
	 * ������������ļ�¼����
	 *
	 * @param  string table     ������
	 * @param  string condition  ��ѯ����
	 *
	 * @return  bool ��ȷ����true,���򷵻�false
	 */
	public function getRowsCount($table, $condition)
	{
		$table = $this->msEscapeStr($table);
		$sql = 'SELECT count(*) as c FROM '.$table;
		if (!empty($condition))
		{
			$sql .= ' WHERE '.$condition;
		}
		$data = $this->getRows($sql);
		if ($data === false)
		{
			return false;
		}
		return ((count($data)<=0) ? 0 : $data[0]['c']);
	}

	/**
	 * ֱ�ӷ��ؽ����, �Ա�������Ӧ�ó�����, ҵ���߼������д������ؽ����
	 *
	 * @param		string		$sql, sql���
	 *
	 * @return		object/bool	��ȷ��������,���󷵻�false
	 */
	public function getRS($sql) {
		$this->clearERR();

		//for report
		EL_ModuleState::start("db.{$this->configId}", 'db.select');

		$result = @mssql_query($sql, $this->con);
		if ($result === false) {
			$last_message = mssql_get_last_message();

			$this->errCode = 10303;
			$this->errMsg  = 'host:'.$this->host.',port:'.$this->port.',db:'.$this->db_name.',sql:'.$sql.',error:'.$last_message;

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select', EL_ModuleState::FAILED_DB, $this->errCode, $this->host);

			//error
			EL_Flow::getInstance('ms_sql_error')->append($last_message);

			return false;
		}

		//report
		EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select', EL_ModuleState::SUCCESS, 0, $this->host);

		return $result;
	}

		/**
	 * ִ��ָ����sql���,,��������,��ʽ:
	 * code:0Ϊ�ɹ�������Ϊʧ��
	 * msg:������Ϣ
	 * data:�������
	 *
	 * @param  string sql    	sql���
	 * @return bool ��ȷ����true ���򷵻�false
	 */
	public function execSql($sql)
	{
		$this->clearERR();

		$sql = trim($sql);

		EL_ModuleState::start("db.{$this->configId}", 'db.select_db');

		if (!mssql_select_db($this->db_name, $this->con)) {
			$last_message = mssql_get_last_message();

			$this->errCode = 10302;
			$this->errMsg="db:{$this->host}:{$this->port}:{$this->db_name} error:".$last_message;

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select_db', EL_ModuleState::FAILED_DB, $this->errCode, $this->host);

			//error
			EL_Flow::getInstance('ms_sql_error')->append($last_message);

			return false;
		}

		EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", 'db.select_db', EL_ModuleState::SUCCESS, 0, $this->host);

		//for report
		$_operation = 'other';
		$_matched = array();
		if (preg_match('/^(select|insert|update|delete|start|commit|rollback)\s/i', $sql, $_matched)) {
			$_operation = strtolower($_matched[1]);
		}

		EL_ModuleState::start("db.{$this->configId}", 'db.' . $_operation);

		$result = @mssql_query($sql, $this->con);
		if ($result === false) {
			$last_message = mssql_get_last_message();

			$this->errCode = 10303;
			$this->errMsg  = 'host:'.$this->host.',port:'.$this->port.',db:'.$this->db_name.',sql:'.$sql.',error:'.$last_message;

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", "db.{$_operation}", EL_ModuleState::FAILED_DB, $this->errCode, $this->host);

			//error
			EL_Flow::getInstance('ms_sql_error')->append($last_message);

			//write flow
			if ($_operation != 'select')
			{
				EL_Flow::getInstance('sql_write_flow')->append("result:SQLServer_failed,sql:{$sql},errCode:{$this->errCode},errMsg:{$this->errMsg}",true);
			}

			return false;
		}

		//report
		EL_ModuleState::report('AUTO_MASTER', "db.{$this->configId}", "db.{$_operation}", EL_ModuleState::SUCCESS, 0, $this->host);

		//write flow
		if (strtolower(substr($sql, 0, 6)) != 'select')
		{
			EL_Flow::getInstance('sql_write_flow')->append("result:SQLServer_success,sql:$sql",true);
		}

		if ($result === true) {
			return true;
		}

		$this->errCode = 10304;
		$this->errMsg  = 'host:'.$this->host.',port:'.$this->port.',db:'.$this->db_name.',sql:'.$sql;//." affected_rows = {$n}";
		return false;
	}

	/**
	 * ƴװinsert��sql���
	 *
	 * @param string table    ������
	 * @param array data    ����
	 *
	 * @return string
	 */
	public function getInsertString($table, $data)
	{
		$n_str = '';
		$v_str = '';
		$table = $this->msEscapeStr($table);
		foreach ($data as $k => $v)
		{
			$n_str .= $this->msEscapeStr($k).',';
			$v_str .= "'".$this->msEscapeStr($v)."',";
		}
		$n_str = preg_replace( "/,$/", "", $n_str );
		$v_str = preg_replace( "/,$/", "", $v_str );
		$str = 'INSERT INTO '.$table.' ('.$n_str.') VALUES('.$v_str.')';
		return $str;
	}

	/**
	 * ��������,��������,��ʽ:
	 * code:0Ϊ�ɹ�������Ϊʧ��
	 * msg:������Ϣ
	 * @param string table   ������
	 * @param array  data    ����
	 * @return ��ȷ����true�����򷵻�false
	 */
	public function insert($table, $data)
	{
		$sql = $this->getInsertString($table, $data);
		return $this->execSql($sql);
	}

	/**
	 * һ����һ�ű������Ӷ�����¼
	 * code:0Ϊ�ɹ�������Ϊʧ�ܡ�msg:������Ϣ��
	 * @param string $table �����������
	 * @param array $rows ��������
	 * @return ��ȷ����true�����򷵻�false
	 */
	public function insertMultiple($table, $rows) {
		$table = $this->msEscapeStr($table);

		$n_str = '';
		$n_str_init = false;

		$v_str_ary = array();

		foreach($rows as $row) {
			$v_str = '';
			foreach ($row as $k => $v) {
				if (! $n_str_init) {
					$n_str .= $this->msEscapeStr($k).',';
				}
				$v_str .= "'" . $this->msEscapeStr($v) . "',";
			}

			if (! $n_str_init) {
				$n_str = preg_replace( "/,$/", "", $n_str );
				$n_str_init = true;
			}

			$v_str = preg_replace( "/,$/", "", $v_str );
			$v_str_ary[] = "({$v_str})";
		}

		$v_part = implode(',', $v_str_ary);
		$sql = "INSERT INTO {$table} ({$n_str}) VALUES {$v_part}";

		return $this->execSql($sql);
	}

	public function getAffectedRows()
	{
		return mssql_rows_affected($this->con);
	}

	/**
	 * ƴװupdate��sql���
	 *
	 * @param string  table    ������
	 * @param array data    ����
	 * @param string condition    ����
	 *
	 * @return string
	 */
	public function getUpdateString($table, $data, $condition)
	{
		$str = '';
		$table = $this->msEscapeStr($table);
		foreach ($data as $k => $v)
		{
			$str .= $this->msEscapeStr($k)."='".$this->msEscapeStr($v)."',";
		}
		$str = preg_replace("/,$/", "", $str);
    	$sql = 'UPDATE '.$table.' SET '.$str;
    	if (!empty($condition) && is_string($condition))
    	{
    		$sql .= ' WHERE '.$condition;
    	}
		return $sql;
	}

	/**
	 * ,��������,��������,��ʽ:
	 * code:0Ϊ�ɹ�������Ϊʧ��
	 * msg:������Ϣ
	 *
	 * @param string table    ������
	 * @param array data    ����
	 * @param string condition    ��ѯ����
	 * @return ��ȷ����true�����򷵻�false
	 */
	public function update($table, $data, $condition)
	{
		$sql = $this->getUpdateString($table, $data, $condition);
		return $this->execSql($sql);
	}

	/**
	 * ��UPDATE�����@@ROWCOUNTΪ�㣬��INSERT��
	 * @param string $table ����
	 * @param array $updateData ���µ�����
	 * @param string $condition ��ѯ����
	 * @param array $insertData ���������
	 * @return ��ȷ����true�����򷵻�false
	 */
	public function updateOrInsert($table, $updateData, $condition, $insertData) {
		$updateSql = $this->getUpdateString($table, $updateData, $condition);
		$insertSql = $this->getInsertString($table, $insertData);

		$sql = "$updateSql
			IF @@ROWCOUNT = 0
			$insertSql";
		return $this->execSql($sql);
	}

	/**
	 * ɾ��ָ������������,,��������,��ʽ:
	 * code:0Ϊ�ɹ�������Ϊʧ��
	 * msg:������Ϣ
	 *
	 * @param  string table     ������
	 * @param  string condition  ��ѯ����
	 * @return bool ��ȷ����true�����򷵻�false
	 *
	 */
	public function remove($table, $condition)
	{
		$table = $this->msEscapeStr($table);
		$sql = 'DELETE FROM '.$table.' WHERE '.$condition;
		return $this->execSql($sql);
	}

	/**
	 * ���������ֶ�ֵ
	 *
	 */
	public function getLastId()
	{
		$this->clearERR();
		$sql = 'SELECT SCOPE_IDENTITY() as i';
		$data = $this->getRows($sql);
		if ($data === false)
		{
			return false;
		}
		return ((count($data)<=0) ? 0 : $data[0]['i']);
	}

	/**
	 * ���������ַ�
	 *
	 * @param string str    �ַ���
	 * @return string
	 */
	public function msEscapeStr($str)
	{
		if ( is_numeric($str) ) {
			return $str;
		} else {
			return str_replace("'", "''", $str);
		}
	}
}
//End of script

