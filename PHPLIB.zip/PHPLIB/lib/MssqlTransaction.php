<?php
/**
 * MSSQL ���������
 *
 * @author bennylin
 * @created 2013/2/1
 */
class EL_MssqlTransaction
{
	public $code;
	public $msg;

	/**
	 * ���ݿ������б�
	 * @var array
	 */
	private $connections = array();

	/**
	 * �Ѿ���ʼ�����db�б�
	 * @var array
	 */
	private $transaction_db_list = array();

	/**
	 * ��ִ�е� db => sql�б� ӳ��
	 * @var array
	 */
	private $db2sql_map = array();

	/**
	 * ��ִ�е� db => sql�б� ӳ��
	 * @var array
	 */
	private $executed_db2sql_map = array();

	/**
	 * �������ݿ�ʱ�Ƿ񴴽�������
	 * @var boolean
	 */
	private $new_link = false;

	/**
	 * ���캯��
	 *
	 * @param boolean $new_link		create new link on connect?
	 *
	 * @return void
	 */
	public function __construct($new_link = false)
	{
		$this->new_link = $new_link;
	}

	/**
	 * �����¼
	 *
	 * @param string $db		�����¼���ڵ����ݿ�
	 * @param string $table		�����¼���ڵı�
	 * @param array $data		����ļ�¼
	 * @param boolean $real_time		�Ƿ�ʵʱִ��
	 * @param int $route_id ���ڷֿ������
	 *
	 * @return boolean
	 */
	public function insert($db, $table, $data, $real_time = false, $route_id = null)
	{
		if (strpos('\'', $table) !== false) {
			$this->code = 2011;
			$this->msg = "table ({$table}) is invalid";
			return false;
		}

		if (empty($data) ) {
			$this->code = 2012;
			$this->msg = "insert data is empty";
			return false;
		}

		if (is_array(current($data) ) ) {
			//multipie insert

			$fields = array_keys(current($data) );

			$values_list = array();
			foreach ($data as $item) {
				$tmp_fields = array_keys($item);
				if ($tmp_fields !== $fields) {
					$this->code = 2013;
					$this->msg = "insert records fields are different";
					return false;
				}

				$values = array_values($item);
				$values = array_map(array($this, 'escape'), $values);
				$values_list[] = '(\'' . implode('\',\'', $values) . '\')';
			}

			$fields = implode(',', $fields);
			$values_list = implode(',', $values_list);
			$sql = "INSERT INTO {$table} ({$fields}) VALUES {$values_list}";
		}
		else {
			//single insert

			$fields = array_keys($data);
			$values = array_values($data);
			$values = array_map(array($this, 'escape'), $values);

			$fields = implode(',', $fields);
			$values = '\'' . implode('\',\'', $values) . '\'';
			$sql = "INSERT INTO {$table} ({$fields}) VALUES ({$values})";
		}

		return $this->execute($db, $sql, $real_time, $route_id);
	}

	/**
	 * ���¼�¼
	 *
	 * @param string $db		�����¼���ڵ����ݿ�
	 * @param string $table		�����¼���ڵı�
	 * @param array $record		���µļ�¼
	 * @param string $condition		����
	 * @param boolean $real_time		�Ƿ�ʵʱִ��
	 * @param int $route_id ���ڷֿ������
	 *
	 * @return boolean
	 */
	public function update($db, $table, $record, $condition, $real_time = false, $route_id = null)
	{
		if (strpos('\'', $table) !== false) {
			$this->code = 2011;
			$this->msg = "table ({$table}) is invalid";
			return false;
		}

		if (empty($condition) || !is_string($condition) ) {
			throw new Exception('parameter $condition not a string');
		}

		if (empty($record) ) {
			return false;
		}

		$update_list = array();
		foreach ($record as $k => $v) {
			$update_list[] = "{$k}='" . $this->escape($v) . "'";
		}

		$update_list = implode(',', $update_list);
		$sql = "UPDATE {$table} SET {$update_list} WHERE {$condition}";

		return $this->execute($db, $sql, $real_time, $route_id);
	}

	/**
	 * ���¼�¼
	 *
	 * @param string $db		�����¼���ڵ����ݿ�
	 * @param string $table		�����¼���ڵı�
	 * @param string $condition		����
	 * @param boolean $real_time		�Ƿ�ʵʱִ��
	 * @param int $route_id ���ڷֿ������
	 *
	 * @return boolean
	 */
	public function delete($db, $table, $condition, $real_time = false, $route_id = null)
	{
		if (strpos('\'', $table) !== false) {
			$this->code = 2011;
			$this->msg = "table ({$table}) is invalid";
			return false;
		}

		if (empty($condition) || !is_string($condition) ) {
			throw new Exception('parameter $condition not a string');
		}

		$sql = "DELETE FROM {$table} WHERE {$condition}";

		return $this->execute($db, $sql, $real_time, $route_id);
	}

	/**
	 * ��ѯ
	 *
	 * @param string $db		�����¼���ڵ����ݿ�
	 * @param string $table		�����¼���ڵı�
	 * @param string $condition		����
	 * @param mixed $fields		��ѯ���ֶ��б�
	 * @param int $route_id ���ڷֿ������
	 *
	 * @return mixed	��ѯ���ļ�¼��
	 */
	public function select($db, $table, $condition = '', $fields = '*', $route_id = null)
	{
		if (strpos('\'', $table) !== false) {
			$this->code = 2011;
			$this->msg = "table ({$table}) is invalid";
			return false;
		}

		$conn = $this->getConnection($db);
		if (!$this->selectDb($db, $conn, $route_id) ) {
			return false;
		}

		if (is_array($fields)) {
			$fields = implode(',', $fields);
		}

		$condition = $condition ? 'WHERE ' . $condition : '';
		$sql = "SELECT {$fields} FROM {$table} {$condition}";
		$result = mssql_query($sql, $conn);
		if ($result === false) {
			return false;
		}

		$items = array();
		while (($row = mssql_fetch_array($result, MSSQL_ASSOC) ) ) {
			$items[] = $row;
		}

		return $items;
	}

	/**
	 * ͨ��sql����ѯ
	 *
	 * @param string $db		�����¼���ڵ����ݿ�
	 * @param string $table		�����¼���ڵı�
	 * @param string $condition		����
	 * @param mixed $fields		��ѯ���ֶ��б�
	 * @param int $route_id ���ڷֿ������
	 *
	 * @return mixed	��ѯ���ļ�¼��
	 */
	public function selectBySql($db, $sql = '*', $route_id = null)
	{
		$conn = $this->getConnection($db);
		if (!$this->selectDb($db, $conn, $route_id) ) {
			return false;
		}

		$result = mssql_query($sql, $conn);
		if ($result === false) {
			return false;
		}

		$items = array();
		while (($row = mssql_fetch_array($result, MSSQL_ASSOC) ) ) {
			$items[] = $row;
		}

		return $items;
	}

	/**
	 * ͳ�Ƽ�¼��
	 *
	 * @param string $db		�����¼���ڵ����ݿ�
	 * @param string $table		�����¼���ڵı�
	 * @param string $condition		����
	 * @param mixed $string		��ѯ���ֶ��б�
	 * @param int $route_id ���ڷֿ������
	 *
	 * @return mixed	��ѯ���ļ�¼��
	 */
	public function count($db, $table, $condition = '', $field = '*', $route_id = null)
	{
		if (strpos('\'', $table) !== false) {
			$this->code = 2011;
			$this->msg = "table ({$table}) is invalid";
			return false;
		}

		$conn = $this->getConnection($db);
		if (!$this->selectDb($db, $conn, $route_id) ) {
			return false;
		}

		$condition = $condition ? 'WHERE ' . $condition : '';
		$sql = "SELECT count({$field}) FROM {$table} {$condition}";
		$result = mssql_query($sql, $conn);
		if ($result === false) {
			return false;
		}

		$row = mssql_fetch_row($result);

		return $row[0];
	}

	/**
	 * ִ��ָ��SQL���
	 *
	 * @param string $db		�����¼���ڵ����ݿ�
	 * @param string $sql
	 * @param boolean $real_time		�Ƿ�ʵʱִ��
	 * @param int $route_id ���ڷֿ������
	 *
	 * @return mixed	result �� null
	 */
	public function execute($db, $sql, $real_time = false, $route_id = null)
	{
		//append to execute queue
		if (empty($this->db2sql_map[$db]) ) {
			$this->db2sql_map[$db] = array();
		}

		$this->db2sql_map[$db][] = array(
			'sql' => $sql,
			'route_id' => $route_id,
		);

		//execute in time
		if ($real_time) {
			//����ʵʱִ�е�sql������ִ�����dbǰ�������е����е�sql��������ʱ��������Ⱥ�˳��ʱ���ܳ�������
			foreach ($this->db2sql_map[$db] as $k => $item) {
				$exec_result = $this->realExecute($db, $item['sql'], $item['route_id']);
				if ($exec_result === false) {
					return false;
				}

				//��ִ�ж�����ȥ��
				unset($this->db2sql_map[$db][$k]);
			}
		}

		return true;
	}

	/**
	 * ����ִ��ָ��SQL���
	 *
	 * @param string $db		�����¼���ڵ����ݿ�
	 * @param string $sql
	 * @param boolean $real_time		�Ƿ�ʵʱִ��
	 * @param int $route_id ���ڷֿ������
	 *
	 * @return mixed	result / false
	 */
	public function realExecute($db, $sql, $route_id = null)
	{
		if (!in_array($db, $this->transaction_db_list) ) {
			if (!$this->startTransaction($db) ) {
				return false;
			}
		}

		$conn = $this->connections[$db];
		if (!$this->selectDb($db, $conn, $route_id) ) {
			return false;
		}

		//for report
		$_operation = '';
		$_matched = array();
		if (preg_match('/^(select|insert|update|delete|start|begin|commit|rollback)\s/i', $sql, $_matched)) {
			$_operation = strtolower($_matched[1]);
		}

		EL_ModuleState::start("db.{$db}", $_operation);

		//execute
		$result = mssql_query($sql, $conn);
		if ($result === false) {
			$last_message = mssql_get_last_message();
			EL_ModuleState::report('AUTO_MASTER', "db.{$db}", $_operation, EL_ModuleState::FAILED_DB, 10303, $this->host);
			EL_Flow::getInstance('ms_sql_error')->append($last_message);

			//write flow
			if ($_operation != 'select') {
				EL_Flow::getInstance('sql_write_flow')->append("result:SQLServer_failed,sql:{$sql},errCode:{$this->errCode},errMsg:{$this->errMsg}", true);
			}

			return false;
		}

		//success
		EL_ModuleState::report('AUTO_MASTER', "db.{$db}", $_operation, EL_ModuleState::SUCCESS, 0);

		//record to executed
		$this->executed_db2sql_map[$db][] = $sql;

		//write flow
		if ($_operation != 'select') {
			EL_Flow::getInstance('sql_write_flow')->append("result:SQLServer_success,sql:$sql", true);
		}

		//record executed sql
		if (!isset($this->executed_db2sql_map[$db]) ) {
			$this->executed_db2sql_map[$db] = array();
		}

		return $result;
	}

	/**
	 * ��ȡ��һSQL����Ӱ�쵽�ļ�¼��
	 *
	 * @param string $db
	 *
	 * @return int
	 */
	public function getAffectedRows($db)
	{
		if (!isset($this->connections[$db]) ) {
			return false;
		}

		return mssql_rows_affected($this->connections[$db]);
	}

	/**
	 * ��ȡ�����ֶ�ֵ
	 *
	 * @param string $db
	 *
	 * @return int
	 */
	public function getInsertId($db)
	{
		if (!isset($this->connections[$db]) ) {
			return false;
		}

		$sql = 'SELECT SCOPE_IDENTITY() AS id';

		$conn = $this->connections[$db];
		$result = mssql_query($sql, $conn);
		if ($result === false) {
			return false;
		}

		$row = mssql_fetch_array($result, MSSQL_ASSOC);
		if ($row === false) {
			return false;
		}

		return empty($row)? null : $row['id'];
	}

	/**
	 * �ύ��������
	 *
	 * @return boolean
	 */
	public function commit()
	{
		foreach ($this->db2sql_map as $db => $items) {
			foreach ($items as $item) {
				$executed = $this->realExecute($db, $item['sql'], $item['route_id']);
				if (!$executed) {
					$this->rollback();
					return false;
				}
			}
		}

		//commit all
		foreach ($this->transaction_db_list as $db) {
			$conn = $this->connections[$db];
			mssql_query('COMMIT', $conn);
		}

		return true;
	}

	/**
	 * �ع���������
	 *
	 * @return boolean
	 */
	public function rollback()
	{
		//rollback all executeds
		foreach ($this->transaction_db_list as $db) {
			$conn = $this->connections[$db];
			@mssql_query('ROLLBACK', $conn);
		}

		//clean
		$this->transaction_db_list = array();
		$this->db2sql_map = array();
	}

	/**
	 * ת��sql����ַ���
	 *
	 * @param string $str
	 *
	 * @return string
	 */
	public function escape($str)
	{
		if (is_numeric($str)) {
			return $str;
		}

		return str_replace("'", "''", $str);
	}

	/**
	 * ��ȡ���ݿ�����
	 *
	 * @param string $db
	 *
	 * @return mixed
	 */
	public function getConnection($db)
	{
		if (isset($this->connections[$db]) ) {
			return $this->connections[$db];
		}

		$conf = Config::get('db', $db);
		if (empty($conf)) {
			throw new Exception("db config '{$db}' not found");
		}

		if (empty($conf['port'])) {
			$server = $conf['host'];
		}
		else {
			$server = $conf['host'] . ':' . $conf['port'];
		}

		EL_ModuleState::start("db.{$db}", 'connect');

		$conn = mssql_connect($server, $conf['user'], $conf['password'], $this->new_link);
		if (!$conn) {
			$last_message = mssql_get_last_message();
			EL_Flow::getInstance('ms_sql_error')->append($last_message);

			//report
			EL_ModuleState::report('AUTO_MASTER', "db.{$db}", 'connect', EL_ModuleState::FAILED_DB, 10301, $conf['host']);

			return false;
		}

		EL_ModuleState::report('AUTO_MASTER', "db.{$db}", 'connect', EL_ModuleState::SUCCESS, 0);

		$this->connections[$db] = $conn;

		return $conn;
	}

	/**
	 *
	 * @param int $route_id ���ڷֿ������
	 *
	 */
	public function getRealDatabaseName($db, $route_id = null)
	{
		$options = Config::get('db', $db);
		if (empty($options)) {
			throw new Exception("db config '{$db}' not found");
		}

		if ($route_id !== null ) {
			if (empty($options['db_num']) || empty($options['table_num'])) {
				return false;
			}

			$idx = intval($route_id / $options['table_num']) % $options['db_num'];
			return $options['database'] . '_' . $idx;
		}

		return $options['database'];
	}

	public function getTableIndex($db, $id)
	{
		$options = Config::get('db', $db);
		if (empty($options)) {
			throw new Exception("db config '{$db}' not found");
		}

		if (empty($options['table_num'])) {
			return false;
		}

		return $id % $options['table_num'];
	}

	/**
	 * ��ʼ������
	 *
	 * @param string $db
	 *
	 * @return resource
	 */
	private function startTransaction($db)
	{
		$conn = $this->getConnection($db);

		EL_ModuleState::start("db.{$db}", 'start_transaction');

		$sql = 'BEGIN TRANSACTION';
		$result = mssql_query($sql, $conn);
		if (!$result) {
			$last_message = mssql_get_last_message();
			EL_Flow::getInstance('ms_sql_error')->append($last_message);
			EL_ModuleState::report('AUTO_MASTER', "db.{$db}", 'start_transaction', EL_ModuleState::FAILED_DB, 10301);

			return false;
		}

		EL_ModuleState::report('AUTO_MASTER', "db.{$db}", 'start_transaction', EL_ModuleState::SUCCESS, 0);

		$this->transaction_db_list[] = $db;

		//record to executed
		$this->executed_db2sql_map[$db][] = $sql;

		return true;
	}

	/**
	 * ѡ��������ݿ�
	 *
	 * @param string $db
	 * @param resource $conn
	 * @param int $route_id ���ڷֿ������
	 *
	 * @return boolean
	 */
	private function selectDb($db, $conn, $route_id = null)
	{
		$real_db_name = $this->getRealDatabaseName($db, $route_id);

		EL_ModuleState::start("db.{$db}", 'select_db');

		if (!mssql_select_db($real_db_name, $conn) ) {
			$last_message = mssql_get_last_message();
			EL_Flow::getInstance('ms_sql_error')->append($last_message);
			EL_ModuleState::report('AUTO_MASTER', "db.{$db}", 'select_db', EL_ModuleState::FAILED_DB, 10302);
			return false;
		}

		EL_ModuleState::report('AUTO_MASTER', "db.{$db}", 'select_db', EL_ModuleState::SUCCESS, 0);

		return true;
	}
}

