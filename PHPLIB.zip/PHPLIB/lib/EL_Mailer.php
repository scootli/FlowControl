<?php

define("ICSON_SMTP_HOSTNAME", "119.147.74.45");
define("ICSON_SMTP_SERVER", "119.147.74.45");
define("ICSON_SMTP_PORT", 25);
define("ICSON_SMTP_CHARSET", "GB2312");
define("ICSON_SMTP_TIMEOUT", 10);
define("ICSON_SMTP_USERNAME", 'data@51buy.com');
define("ICSON_SMTP_PASSWORD", '51buy&&icson!@');


class EL_Mailer
{
	/**
	 * �������
	 */
	public static $errCode = 0;

	/**
	 * ������Ϣ,�޴���Ϊ''
	 */
	public static $errMsg = '';

	/**
	 * ���������Ϣ,��ÿ�������Ŀ�ʼ����
	 */
	private static function clearError() {
		self::$errCode = 0;
		self::$errMsg  = '';
	}

	/*
	 * Old version.
	 * Don't use this method in a newly developed mail.
	 */ 
	public static function drawSingleTimeTable($name, $data)
	{
		if (empty($data))
		{
			return false;
		}
		$count = 1;
		$isInited = 0;
		$whIsInited = 0;
		$all_num = 0;
		$table = '<div><div style="margin:0 20px 10px 5px;text-align:left;"><span style="font-weight:bold;font-size:15px;">' . $name . '</span></div>' .
			'<div style="margin:0 20px 20px 5px;"><table class="table_basic" id="bodys"><thead id="table_header"><tr class="th"><th colspan="1" rowspan="1">����</th>';
		if (count($data) > 1)
		{
			$table .='<th colspan="1" rowspan="1">��վ</th>';
		}
		$table .= '<th colspan="1" rowspan="1">����ָ��</th>' .
			'<th colspan="1" rowspan="1">��ֵ</th>' . 
			'<th colspan="1" rowspan="1">�ջ���</th>' . 
			'<th colspan="1" rowspan="1">�ܻ���</th></tr></thead>' .
			'<tbody id="table_record">' . "\r\n";
		
		foreach ($data as $d)
		{
			$all_num += count($d['limit']);
		}
		
		foreach ($data as $d)
		{
			$header = $d['header'];
			$header_limit = $d['limit'];
			$yesterday = $d['yesterday'];
			$daily_in = $d['daily_in'];
			$week_in = $d['week_in'];
			$num = count($header_limit);
			foreach ($header as $h)
			{
				if ($h['id'] != 's_date')
				{
					if (!empty($header_limit) && !in_array($h['id'], $header_limit))
					{
						continue;
					}
					
					$odd = $count%2 == 1?'odd':'';
					$table .= '<tr class="' . $odd . '">';
					if (0 === $isInited)
					{
						$table .= '<td rowspan="' . $all_num . '" style="text-align:center;">' . $yesterday['s_date'] . '</td>';
						$isInited = 1;
					}
					if (0 === $whIsInited && count($data) > 1 && isset($d['title']))
					{
						$table .= '<td rowspan="' . $num . '" style="text-align:left;">' . $d['title'] . '</td>';
						$whIsInited = 1;
					}
					$render = self::guessRender($h['id']);
					$table .= '<td rowspan="1" style="text-align:left;">' . $h['name'] . '</td>';
					$table .= '<td rowspan="1" style="text-align:left;">' . $render($yesterday[$h['id']]) . '</td>';
					$table .= '<td rowspan="1" style="text-align:center;">' . formatRate(self::caculateRate($yesterday[$h['id']], $daily_in[$h['id']])) . '</td>';
					$table .= '<td rowspan="1" style="text-align:center;">' . formatRate(self::caculateRate($yesterday[$h['id']], $week_in[$h['id']])) . '</td>';
					$table .= '</tr>' . "\r\n";
					$count ++;
				}
			}
			$whIsInited = 0;
		}
		$table .= '</tbody></table></div></div>' . "\r\n";
		return $table;
	}


	/*
	 * ���ɵ�������
	 *
	 * @param	s_date	string	
	 * @param	title	string
	 * @param	columns	array	�и�ʽ	������s_date���� warehouse_id��վ	indexָ��ֵ
	 * @param	dataSet array
	 *				array(
	 *					array(
	 *						warehouse	=> XX,	��վ����
	 *						header	=> XX,	��ͷ��Ϣ 
	 *						limit	=> XX,	��չʾ�ı�ͷid
	 *						curr	=> XX,	��ͳ���յ�����
	 *						daily_in	=> XX,	�ջ�������
	 *						weekly_in	=> XX,	�ܻ�������
	 *					),
	 *					...
	 *				)
	 *
	 * @return	string	����֮HTML����
	 *
	 */
	public static function drawVerticalTable($s_date, $title, $columns, $dataSet)
	{
		global $_MAIL_SITES_LIST;
		if (empty($columns) || empty($dataSet))
		{
			return false;
		}

		$currpos = 0;
		$total_num = 0;
		$row_counter = 1;
		$first_row_of_table = true;
		$first_row_of_block = true;
		$column_num = count($columns);
		$warehouse_num = count($dataSet);
		foreach ($dataSet as $data)
		{
			$total_num += count($data['limit']);
		}

		$table = '<div><div style="margin:0 20px 10px 5px;text-align:left;"><span style="font-weight:bold;font-size:15px;">' . $title . '</span></div>' .
			'<div style="margin:0 20px 20px 5px;"><table class="table_basic" id="bodys"><thead id="table_header"><tr class="th">';
		
		// ������ͷ
		foreach ($columns as $column)
		{
			if ('s_date' == $column)
			{
				$table .= '<th colspan="1" rowspan="1">����</th>';
			}
			else if ('warehouse_id' == $column)
			{
				$table .= '<th colspan="1" rowspan="1">ϸ��</th>';
			}
			else if ('index' == $column)
			{
				$table .= '<th colspan="1" rowspan="1">����ָ��</th>';
			}
			else
			{
				self::$errMsg = 'Unsupported table column: ' . $column;
				return false;
			}
		}

		$table .= '<th colspan="1" rowspan="1">��ֵ</th>' . 
			'<th colspan="1" rowspan="1">�ջ���</th>' . 
			'<th colspan="1" rowspan="1">�ܻ���</th></tr></thead>' .
			'<tbody id="table_record">' . "\r\n";

		//�������Ϊ����
		if ($column_num > $currpos && 's_date' == $columns[$currpos])
		{
			$has_date_column = true;
			$currpos ++;
		}
		else
		{
			$has_date_column = false;
		}

		//�Է�վ���ֺ���ָ�껮��
		if ($column_num > $currpos && 'warehouse_id' == $columns[$currpos])
		{
			// �ڶ���Ϊ��վ ������Ϊ����վָ������
			foreach ($dataSet as $wid => $data)
			{
				$header = $data['header'];
				$header_limit = $data['limit'];
				$curr = $data['curr'];
				$daily_in = $data['daily_in'];
				$weekly_in = $data['weekly_in'];
			
				$index_num = count($data['limit']);
				foreach ($header as $h)
				{
					if (!in_array($h['id'], $header_limit) || 's_date' == $h['id'])
					{
						continue;
					}

					$odd = $row_counter % 2 == 1 ? 'odd' : '';
					$table .= '<tr class="' . $odd . '">';

					if (true === $first_row_of_table && true === $has_date_column)
					{
						$table .= '<td rowspan="' . $total_num . '" style="text-align:center;">' . $s_date . '</td>';
						$first_row_of_table = false;
					}
					if (true === $first_row_of_block)
					{
						$wh_name  = isset($data['warehouse'])?$data['warehouse']:$_MAIL_SITES_LIST[$wid];
						$table .= '<td rowspan="' . $index_num . '" style="text-align:left;">' . $wh_name . '</td>';
						$first_row_of_block = false;
					}
					$render = self::guessRender($h['id']);
					$table .= '<td rowspan="1" style="text-align:left;">' . $h['name'] . '</td>';
					$table .= '<td rowspan="1" style="text-align:right;">' . $render($curr[$h['id']]) . '</td>';
					$table .= '<td rowspan="1" style="text-align:center;">' . formatRate(self::caculateRate($curr[$h['id']], $daily_in[$h['id']])) . '</td>';
					$table .= '<td rowspan="1" style="text-align:center;">' . formatRate(self::caculateRate($curr[$h['id']], $weekly_in[$h['id']])) . '</td>';
					$table .= '</tr>' . "\r\n";
					$row_counter ++;
				}
				$first_row_of_block = true;
			}			
		}
		else if ($column_num > $currpos && 'index' == $columns[$currpos])
		{
			// �ڶ���Ϊָ�� ������Ϊָ���ڸ���վ��ֵ
			$currpos ++;

			$tmp_data = current($dataSet);
			$header = $tmp_data['header'];
			$header_limit = $tmp_data['limit'];

			$wids = array_keys($dataSet);
			foreach ($header as $h)
			{
				if (!in_array($h['id'], $header_limit) || 's_date' == $h['id'])
				{
					continue;	
				}

				foreach ($wids as $wid)
				{
					$odd = $row_counter % 2 == 1 ? 'odd' : '';
					$table .= '<tr class="' . $odd . '">';
				
					if (true === $first_row_of_table && true === $has_date_column)
					{
						$table .= '<td rowspan="' . $total_num . '" style="text-align:center;">' . $s_date . '</td>';
						$first_row_of_table = false;
					}
					if (true === $first_row_of_block)
					{
						$table .= '<td rowspan="' . $warehouse_num . '" style="text-align:left;">' . $h['name'] . '</td>';
						$first_row_of_block = false;
					}
				
					if (in_array('warehouse_id', $columns))
					{
						$wh_name  = isset($data['warehouse'])?$data['warehouse']:$_MAIL_SITES_LIST[$wid];	
						$table .= '<td rowspan="1" style="text-align:left;">' . $wh_name . '</td>';
					}
					$render = self::guessRender($h['id']);
					$curr = $dataSet[$wid]['curr'];
					$daily_in = $dataSet[$wid]['daily_in'];
					$weekly_in = $dataSet[$wid]['weekly_in'];
					$table .= '<td rowspan="1" style="text-align:right;">' . $render( isset($curr[$h['id']])?$curr[$h['id']]:0 ) . '</td>';
					$table .= '<td rowspan="1" style="text-align:center;">' . formatRate( isset($curr[$h['id']])?(self::caculateRate($curr[$h['id']], $daily_in[$h['id']])):0 ) . '</td>';
					$table .= '<td rowspan="1" style="text-align:center;">' . formatRate( isset($curr[$h['id']])?(self::caculateRate($curr[$h['id']], $weekly_in[$h['id']])):0 ) . '</td>';
					$table .= '</tr>' . "\r\n";
					$row_counter ++;
				}
				$first_row_of_block = true;
			}
		}

		$table .= '</tbody></table></div></div>' . "\r\n";
		return $table;		
	}

	public static function drawHorizontalTable($s_date, $title, $header, $limit, $data, $summary = array(), $average = array())
	{
		global $_MAIL_SITES_LIST;
		if (empty($data))
		{
			self::$errMsg = 'Invalid parameters.';
			return false;
		}
		
		$table = '<div><div style="margin:0 20px 10px 5px;text-align:left;"><span style="font-weight:bold;font-size:15px;">' . $title . '</span></div>' .
			'<div style="margin:0 20px 20px 5px;"><table class="table_basic" id="bodys"><thead id="table_header"><tr class="th">';
		foreach ($header as $v => $h)
		{
			if (in_array($h['id'], $limit))
			{
				$table .= '<th colspan="1" rowspan="1">' . $h['name'] . '</th>' . "\r\n";
			}
		}
		$table .= '</tr></thead>';
		
		$table .= '<tbody id="table_record">' . "\r\n";
		$row_counter = 1;
		foreach ($data as $row)
		{
			$odd = ($row_counter % 2 == 1)?'odd':'';
			$table .= '<tr class="' . $odd . '">';
			foreach ($header as $h)
			{
				if (!in_array($h['id'], $limit))
					continue;

				if (isset($row[$h['id']]))
				{
					if ('warehouse_id' == $h['id'])
					{
						$table .= '<td rowspan="1" style="text-align:center;">' . $_MAIL_SITES_LIST[$row['warehouse_id']] . '</td>' . "\r\n";
						continue;
					}
					else
					{
						$value = $row[$h['id']];
					}
				}
				else
				{
					$value = '-';
				}

				$render = self::guessRender($h['id']);
				$align = isset($h['align'])?$h['align']:($h['id'] == 's_date')?'center':'right';
				$table .= '<td rowspan="1" style="text-align:' . $align . ';">' . $render($value) . '</td>' . "\r\n";
			}
			$table .= '</tr>' . "\r\n";
			$row_counter ++;
		}	
		
		if (!empty($summary))
				$table .= self::drawBoldRow($summary, $header, $limit, 'summary');

		if (!empty($average))
				$table .= self::drawBoldRow($average, $header, $limit, 'average');

		$table .= '</tbody></table></div></div>' . "\r\n";
		return $table;
	}



	public static function drawTrends($title, $cids)
	{
		$html = '<div><div style="margin:0 20px 10px 5px;text-align:left;"><span style="font-weight:bold;font-size:15px;">' . $title. '</span></div>';
		foreach ($cids as $cid)
		{
			$html .= '<div class="display_chart" style="margin:0 20px 20px 5px;"><img src="cid:' . $cid . '"></div>' . "\r\n";
		}
		$html .= '</div>';
		return $html;
	}

	public static function wrapHtml($title, $html, $comment)
	{
		if (empty($comment))
		{
			$comment_html = '';
		}
		else
		{
			$comment_html = '<div id="mailInfo">����˵����<br><br>' . $comment . '<br><br></div>';
		}

		$html = <<<STRING
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312"><title>��Ѹ����վ�ձ�</title><style type="text/css">
html{color:#000;background:#FFF;}body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,code,form,fieldset,legend,input,textarea,p,blockquote,th,td,button{margin:0;padding:0;}img{border:0;}address,caption,cite,code,dfn,em,var{font-style:normal;font-weight:normal;}li{list-style:none;}h1,h2,h3,h4,h5,h6{font-size:100%;font-weight:normal;}q:before,q:after{content:'';}abbr,acronym {border:0;font-variant:normal;}sup {vertical-align:text-top;}sub {vertical-align:text-bottom;}input,textarea,select{font-family:inherit;font-size:inherit;font-weight:inherit;}input,textarea,select{*font-size:100%;}legend{color:#000;}body {font:13px/1.231 arial,helvetica,clean,sans-serif;*font-size:small;*font:x-small;}table {font-size:inherit;font:100%;}pre,code,kbd,samp,tt{font-family:monospace;*font-size:108%;line-height:100%;}
body{font-family:tahoma,SimSun;font-size:12px;text-align:left;color:#333;}
a:link,
a:visited{color:#5491c9;text-decoration:none;}
a:hover,
a:active{text-decoration:underline;}

div.display_chart {display:block;padding:5px;text-align:center;}

/*table s*/
table.table_basic {border-collapse:collapse;border-spacing:0;empty-cells:show;width:100%;}
table.table_basic caption {BORDER-BOTTOM: medium none; TEXT-ALIGN: center; BORDER-LEFT: #b5b5b5 1px solid; LINE-HEIGHT: 20px; MARGIN: 0px; BACKGROUND: #fff; FONT-SIZE: 14px; BORDER-TOP: #b5b5b5 1px solid; FONT-WEIGHT: bold; BORDER-RIGHT: #b5b5b5 1px solid}
table.table_basic th {background-color:#d5e7f3;text-align:center;padding:0 5px 0 5px;color:#444444;height:27px;}
table.table_basic td {padding:0 4px 0 4px;white-space: nowrap;height:24px;}
table.table_basic td.emphasize {background-color:#d9ecf6;font-weight:bold;color:#444444;}
table.table_basic th.default {background-color:#d5e7f3;}
table.table_basic th.onhover {background:#ADD8E6;}
table.table_basic tr{background-color:#FFF;}
table.table_basic tr.odd,table.table_basic tr.alt{background-color:#eaf2f5;}
table.table_basic tr.end{background:#eaf2f5;text-align:right;}
table.table_basic tr.hit{background-color:#fff8ec;color:#834e00;}
table.table_basic tr.hover{background-color:#d5e7f3;}
table.table_basic th,table.table_basic td{border:1px solid #b1cbe2;}
/*table e*/
</style></head><body><div id="allContent">
<style rel="stylesheet">
    #mailInfo{font-size:12px;width:70%;padding:5px;margin:5px;background-color:#D5E7F3}
</style>
<br>
	<div>{$html}</div>
	{$comment_html}
</body></html>	
STRING;
		return $html;
	}


	private static function drawBoldRow($row, $header, $limit, $type)
	{
		$isInited = 0;
		$html = '<tr class="odd">';
		foreach ($header as $h)
		{
			if (!in_array($h['id'], $limit))
				continue;

			$render = self::guessRender($h['id']);
			$align = isset($h['align'])?$h['align']:'right';
			if (0 === $isInited)
			{
				if ('summary' == $type)
					$value = '�ϼ�';
				else if ('average' == $type)
					$value = '��ֵ';
				else
					$value = '-';
				$align = 'center';
				$isInited = 1;
			}
			else
			{
				$value = isset($row[$h['id']])?$row[$h['id']]:'-';
			}
			$html .= '<td rowspan="1" style="text-align:' . $align . ';"><b>' . $render($value) . '</b></td>' . "\r\n";
		}
		$html .= '</tr>' . "\r\n";
		return $html;
	}

	private static function guessRender($name)
	{
		$rate_preg = "/(_rate|_in|_on)$/";
		$date_preg = "/(_date|_time)$/";
		$float_preg = "/(unit_product_price|unit_product_num|pv_u)$/";
		$string_preg = "/(_name|_title)$/";

		if (1 == preg_match($rate_preg, $name))
		{
			return 'formatRate';
		}
		if (1 == preg_match($float_preg, $name))
		{
			return 'formatFloat';
		}
		if (1 == preg_match($date_preg, $name))
		{
			return 'formatDate';
		}
		if (1 == preg_match($string_preg, $name))
		{
			return 'formatString';
		}
		return 'formatInt';
	}
	
	private static function caculateRate($curr, $before)
	{
		if (0 == $before)
		{
			return 0;
		}
		else
		{
			return 100 * ($curr - $before) / $before;
		}
	}
	
	/*-------------------------------------------------------------------------*/
	//  Qzone Portal Database Class
	//
	//  Description : send email by smtp
	/*-------------------------------------------------------------------------*/	
	public static function send($to, $from, $displayname, $subject, $content, $images)
	{
		$return_data['code'] = false;
			
		$displayname = str_replace("\"", "", $displayname);
		$content = trim($content);

		$to   = preg_replace( "/[ \t]+/" , ""  , $to   );
		$from = preg_replace( "/[ \t]+/" , ""  , $from );

		$to = preg_replace("/[^@._a-zA-Z0-9,]/", "", $to);
		$from = preg_replace("/[^@._a-zA-Z0-9]/", "", $from);
			
		$to   = preg_replace( "/,,/"     , ","  , $to );
		$from = preg_replace( "/,,/"     , ","  , $from );
			
		$to     = preg_replace( "#\#\[\]'\"\(\):;/\$!?\^&\*\{\}#" , "", $to  );
		$from   = preg_replace( "#\#\[\]'\"\(\):;/\$!?\^&\*\{\}#" , "", $from);
			
		$subject = str_replace("\n", "", trim($subject));
		$subject = self::cleanMessage($subject);
		
		$boundary = 'divided_by_ECC_ECP_icson_BA_';
		
		//----------------------------------
		// Build headers
		//----------------------------------
			
		$mail_headers = "";
		$mail_headers .= "From: \"" . $displayname . "\"<" . $from . ">\n";
		$mail_headers .= "To: ".$to."\n";
		$mail_headers .= "Subject: ".$subject."\n";
		$mail_headers .= "MIME-Version: 1.0\n";
			
		//$mail_headers .= "Return-Path: ".$from."\n";
		//$mail_headers .= "X-Priority: 3\n";
		//$mail_headers .= "X-Mailer: 51buy.com Mailer\n";
		if (!empty($images))
		{
			$level = 0;
			$mail_headers .= "Content-Type: multipart/mixed;\tboundary=\"" . $boundary . $level . "\"\n\n";
			$mail_headers .= "--" . $boundary . $level . "\n";

			$level ++;
			$mail_headers .= "Content-Type: multipart/related;\ttype=\"multipart/alternative\";\tboundary=\"" . $boundary . $level . "\"\n\n";
			
			$mail_headers .= "--" . $boundary . $level . "\n";
			$content = "Content-Type: text/html; charset=" . ICSON_SMTP_CHARSET . "\n\n" . $content . "\n\n";	
			$content .= "--" . $boundary . $level . "--\n";
			
			$level --;
			foreach($images as $image)
			{
				if (!file_exists($image['file']))
				{
					$return_data['msg'] = "Could not find a image file: " . $image['file'];
				}
				$image_data = addslashes(fread($fp=fopen($image['file'],"r"), filesize($image['file'])));
				$image_data = chunk_split(base64_encode(StripSlashes($image_data)));
				
				$content .= "--" . $boundary . $level . "\n";
				$content .= "Content-Type:" . $image['type'] . ";\tname=\"" . $image['name'] . "\"\n";
				$content .= "Content-Transfer-Encoding: base64\n";
				$content .= "Content-Disposition: attachment; filename=\"" . $image['name'] . "\"\n";
				$content .= "Content-ID: <" . $image['cid'] . ">\n\n";
				$content .= $image_data . "\n\n";
			}
		
			$content .= "--" . $boundary . $level . "--\n";		
		}
		else
		{
			$mail_headers .= "Content-Type: text/html; charset=" . ICSON_SMTP_CHARSET ."\n";
		}

		$smtp_fp = @fsockopen( ICSON_SMTP_SERVER, ICSON_SMTP_PORT, $errno, $errstr, ICSON_SMTP_TIMEOUT );
			
		if ( ! $smtp_fp )
		{
			$return_data['msg'] = "Could not open a socket to the SMTP server";
			return $return_data;
		}
			
		$smtpmsg = self::getLine($smtp_fp);		
		$smtpcode = substr( $smtpmsg, 0, 3 );
			
		if ( $smtpcode == 220 )
		{
			$data = self::crlfEncode( $mail_headers . "\n" . $content);
				
			//---------------------
			// HELO!, er... HELLO!
			//---------------------
			
			$smtp_msg = self::sendCmd($smtp_fp, "EHLO ".ICSON_SMTP_HOSTNAME);
			$smtp_code = substr( $smtp_msg, 0, 3 );
			
			if ( $smtp_code != 250 )
			{
				$return_data['msg'] = "EHLO";
				return $return_data;
			}
			
			$smtp_msg = self::sendCmd($smtp_fp, "AUTH LOGIN");
			$smtp_code = substr( $smtp_msg, 0, 3 );
				
			if ( $smtp_code == 334 )
			{
				$smtp_msg = self::sendCmd( $smtp_fp, base64_encode(ICSON_SMTP_USERNAME) );
				$smtp_code = substr( $smtp_msg, 0, 3 );
					
				if ( $smtp_code != 334  )
				{
					$return_data['msg'] = "Username not accepted from the server";
					return $return_data;
				}
			
				$smtp_msg = self::sendCmd( $smtp_fp, base64_encode(ICSON_SMTP_PASSWORD) );
				$smtp_code = substr( $smtp_msg, 0, 3 );
					
				if ( $smtp_code != 235 )
				{
					$return_data['msg'] = "Password not accepted from the server";
					return $return_data;
				}
			}

			$smtp_msg = self::sendCmd($smtp_fp, "MAIL FROM:".$from);
			$smtp_code = substr( $smtp_msg, 0, 3 );
				
			if ( $smtp_code != 250 )
			{
				$return_data['msg'] = $smtp_msg;
				return $return_data;
			}
				

			$tos = explode(',',$to);
			
			foreach ($tos as $to_mail){
				$smtp_msg = self::sendCmd($smtp_fp, "RCPT TO:<".$to_mail.">");
				$smtp_code = substr( $smtp_msg, 0, 3 );

				if ( $smtp_code != 250 )
				{
					$return_data['msg'] = "Incorrect email address: $to_mail".var_dump($tos);
					return $return_data;
				}
			}
				
			//---------------------
			// SEND MAIL!
			//---------------------
				
			$smtp_msg = self::sendCmd($smtp_fp,"DATA");
			$smtp_code = substr( $smtp_msg, 0, 3 );
				
			if ( $smtp_code == 354 )
			{
				//$this->smtp_send_cmd( $data );
				fputs( $smtp_fp, $data."\r\n" );
			}
			else
			{
				$return_data['msg'] = "Error on write to SMTP server";
				return $return_data;
			}
				
			//---------------------
			// GO ON, NAFF OFF!
			//---------------------
				
			$smtp_msg = self::sendCmd($smtp_fp,".");
			$smtp_code = substr( $smtp_msg, 0, 3 );
				
			if ( $smtp_code != 250 )
			{
				$return_data['msg'] = "Error on send '.'";
				return $return_data;
			}
				
			$smtp = self::sendCmd($smtp_fp,"quit");
			$smtp_code = substr( $smtp_msg, 0, 3 );
			
			if ( ($smtp_code != 250) and ($smtp_code != 221) )
			{
				$return_data['msg'] = "Error on send 'quit'";
				return $return_data;
			}
				
			@fclose( $smtp_fp );
		}
		else
		{
			$return_data['msg'] =  "Error on smtp code ne 220";
			return $return_data;
		}
		$return_data['code']=true;
		return $return_data;
	}	
	

	/*-------------------------------------------------------------------------*/
	// clean_message: (Mainly used internally)
	// Ensures that \n and <br> are converted into CRLF (\r\n)
	// Also unconverts some BBCode
	/*-------------------------------------------------------------------------*/
		
	public static function cleanMessage($message = "" ) 
	{
			$message = preg_replace( "/^(\r|\n)+?(.*)$/", "\\2", $message );
		
			//-----------------------------------------
			// Bear with me...
			//-----------------------------------------
			
			$message = str_replace( "\n"          , "<br />", $message );
			$message = str_replace( "\r"          , ""      , $message );		
			$message = str_replace( "<br>" , "\r\n", $message );
			$message = str_replace( "<br />"      , "\r\n", $message );

			$message = preg_replace( "#<.+?".">#" , "" , $message );
			
			$message = str_replace( "&quot;", "\"", $message );
			$message = str_replace( "&#092;", "\\", $message );
			$message = str_replace( "&#036;", "\$", $message );
			$message = str_replace( "&#33;" , "!", $message );
			$message = str_replace( "&#39;" , "'", $message );
			$message = str_replace( "&lt;"  , "<", $message );
			$message = str_replace( "&gt;"  , ">", $message );
			$message = str_replace( "&#124;", '|', $message );
			$message = str_replace( "&amp;" , "&", $message );
			$message = str_replace( "&#58;" , ":", $message );
			$message = str_replace( "&#91;" , "[", $message );
			$message = str_replace( "&#93;" , "]", $message );
			$message = str_replace( "&#064;", '@', $message );
			$message = str_replace( "&#60;", '<', $message );
			$message = str_replace( "&#62;", '>', $message );
			$message = str_replace( "&nbsp;" , ' ' , $message );
			
			return $message;
	}
		
	//+------------------------------------
	//| get_line()
	//|
	//| Reads a line from the socket and returns
	//| CODE and message from SMTP server
	//|
	//+------------------------------------
		
	public static function getLine($smtp_fp)
	{
		$smtp_msg = "";
			
		while ( $line = fgets( $smtp_fp, 515 ) )
		{
			$smtp_msg .= $line;
				
			if ( substr($line, 3, 1) == " " )
			{
				break;
			}
		}
			
		return $smtp_msg;
	}
		
	//+------------------------------------
	//| send_cmd()
	//|
	//| Sends a command to the SMTP server
	//| Returns TRUE if response, FALSE if not
	//|
	//+------------------------------------
		
	public static function sendCmd($smtp_fp,$cmd)
	{
		fputs( $smtp_fp, $cmd."\r\n" );

		$smtp = array();
			
		$smtp_msg = self::getLine($smtp_fp);
			
		return $smtp_msg;
	}
		
	//+------------------------------------
	//| crlf_encode()
	//|
	//| RFC 788 specifies line endings in
	//| \r\n format with no periods on a 
	//| new line
	//+------------------------------------
		
	public static function crlfEncode($data)
	{
		$data .= "\n";
		$data  = str_replace( "\n", "\r\n", str_replace( "\r", "", $data ) );
		$data  = str_replace( "\n.\r\n" , "\n. \r\n", $data );
			
		return $data;
	}
	
} // end of class


function formatDate($value)
{
	return $value;
}

function formatInt($value)
{
	$value = intval($value);
	return number_format($value);
}

function formatFloat($value)
{
	$value = floatval($value);
	return number_format($value, 2);
}

function formatRate($value)
{
	$value = floatval($value);

	if ($value >= 0)
	{
		return '<span style="color:green;">' . sprintf("%.2f",$value) . '%</span>';
	}
	else
	{
		return '<span style="color:red;">' . sprintf("%.2f",$value) . '%</span>';
	}
}

function formatString($value)
{
	return $value;
}
