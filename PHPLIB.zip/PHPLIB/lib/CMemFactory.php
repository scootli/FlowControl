<?php
/**
 * CMemFactory.php 
 *
 * @copyright	(c) 1998-2011 All Rights Reserved
 * @author		benxi <benxi@tencent.com>
 * @created		2012-12-27
 * @version		$Id$
 */

abstract class CMemFactory {
	private static	$_options	=	array();
	
	private static	$_instances	=	array();
	
	/**
	 * 
	 * @param array $cfg
	 * 
	 * @return boolean
	 */
	public static function factory($cfg) {
		//valiadate option
		try {
			$obj	=	new CMEM($cfg);
			
		} catch ( Exception $e ) {
			trigger_error($e->getMessage(), E_USER_ERROR);
			
			return	false;
		}
			
		if ( false === $obj ) {
			return	false;
		}

		return	$obj;
	}

	/**
	 * 
	 * @param string $name
	 * 
	 * @return resource|object|false:
	 */
	public static function singleton($name) {
		if ( empty(self::$_instances[$name]) ) {
			if ( isset($GLOBALS['_CMEM_CFG'][$name]) ) {
				$obj	=	self::factory($GLOBALS['_CMEM_CFG'][$name]);
				
				if ( false === $obj ) {
					return	false;
				}
				
				self::$_instances[$name]	=	$obj;
			} else {
				trigger_error("cmem cfg[{$name}] not set!", E_USER_ERROR);
				
				return	false;
			}
		}
		
		return self::$_instances[$name];
	}
	
	public static function remove($name) {
		if ( isset(self::$_instances[$name]) ) {
			unset(self::$_instances[$name]);
		}
	}
	
	public static function removeAll() {
		foreach (self::$_instances as $obj) {
			unset($obj);
		}
	}
	
	private static function _init() {
		if ( empty(self::$_options) ) {
			
		}
	}
}

//end of script
