<?php
/**
 * L5(Load Balancer Level 5)
 * Using get route & update invoke time for load balance
 * Error code: 1-cannot load L5 extension, 2-get route failed, 3-update route status failed.
 *
 * @copyright 1998-2013 (c) Tencent. All rights reserved.
 * @author    EdisonTsai
 * @date 	  16:15 2013/02/17
 */

class L5{
	
	private static $_req = array(
					'flow'		=>	0,
					'modid'		=>	'',
					'cmd'		=>	'',
					'host_ip'	=>	'',
					'host_port'	=>	0
		);

	private $_timeout = 0.2;
	private $_isL5Ext = true;

	public function __construct(){

		if(!$this->checkL5Ext()){
				Logger::err('load L5 ext failed');
			$this->_isL5Ext = false;
		}

	}

	/**
	 * Get route address from L5 agent
	 *
	 * @param integer $modid 	module ID
	 * @param integer $cmdid 	command ID
	 * @return array 
	 */
	public function getRoute($modid, $cmdid){

		if(empty($modid) || empty($cmdid) || !$this->_isL5Ext){
			return self::$_req;
		}

		//Modify request data
		self::$_req['modid']	=	trim($modid);
		self::$_req['cmd']		=	trim($cmdid);

		$errMsg = '';

		$res 	=	tphp_l5sys_getroute(self::$_req,$this->_timeout,$errMsg);

	       if($res < 0){ //Write error log
	       		Logger::err('modid:'.$modid.'--cmdid:'.$cmdid.'--res:'.$res.'--errMsg:'.$errMsg.'--req:'.json_encode(self::$_req));
	       }

	      return self::$_req;
	}

	/**
	 * Update route status
	 *
	 * @param integer $res 	the response status, equals '0' is OK, otherwise is failed.
	 * @param float $mtime 	the invoke time of API.
	 * @return boolean
	 */
	public function updateRouteStatus($res,$mtime){

		if(empty($mtime) || !$this->_isL5Ext){
				//CPSLogger::saveErr(0, 9, 'update route status failed, the mtime is '.$mtime. ' the isL5Ext is '.$this->_isL5Ext, 3);
			return false;
		}

		$errMsg = '';
		$res 	= tphp_l5sys_route_result_update(self::$_req, $res, $mtime, $errMsg);

		 if(0 == $res){
		 	return true;
		 }else{
		 	Logger::err('update route status failed, the res is ' . $res . ' the errMsg is ' . $errMsg . ' the req is '.json_encode(self::$_req));
		 	return false;
		 }

	}

	public function setTimeout($sec){
			if(!is_numeric($sec)){
				return false;
			}
		$this->_timeout = $sec;
		return true;
	}

	public function checkL5Ext(){
		return extension_loaded('tphp_l5sys');
	}

}
?>