<?php
/**
 * ��װһЩ���õĺ���1
 */
if (!defined("PHPLIB_ROOT")) {
	define('PHPLIB_ROOT', '/data/release/PHPLIB/');
}

abstract class ToolUtil
{
	/**
	 * �������
	 */
	public static $errCode = 0;
	/**
	 * ������Ϣ,�޴���Ϊ''
	 */
	public static $errMsg = '';

	/**
	 * �ͻ���IP��һ�������ڣ����ֵ�����
	 * @var string
	 */
	private static $clientIP = false;

	/**
	 * ����ͳ��ҳ��㼶
	 * @var int
	 */
	private static $yPageLevel = 0;
	/**
	 * ����ͳ��ҳ��ID
	 * @var int
	 */
	private static $yPageId = 0;

	/**
	 * ���������Ϣ,��ÿ�������Ŀ�ʼ����
	 */
	private static function clearError()
	{
		self::$errCode = 0;
		self::$errMsg = '';
	}

	private static function setERR($code, $msg = '')
	{
		self::$errCode = $code;
		self::$errMsg = $msg;
	}

	/**
	 * �ж��Ƿ���ڻ�����
	 * ������Ҳ�������ǻ����ĵ�һ���֣�����������飬��Ҫ�Լ��������������дһ������ĺ���
	 *
	 * @param string $str
	 * @return ���ڻ����ķ���true���������򷵻�false
	 */
	public static function hasMarsWord($str)
	{
		$b = 0;
		$count = strlen($str);
		for ($i = 0; $i < $count; $i++) {
			$cCode = ord($str[$i]);
			if (($cCode > 47 && $cCode < 58)) { // 0-9
				$b = 0;
			} else if (($cCode > 64 && $cCode < 91)) { // A-Z
				$b = 0;
			} else if (($cCode > 96 && $cCode < 123)) { // a-z
				$b = 0;
			} else if ($cCode == 32) { // �ո�
				$b = 0;
			} else {
				if ($b == 1) { // ��1��3...λ
					if ($cCode < 64 || $cCode > 254) return false;
				} else { // ��0��2��4...λ
					if ($cCode < 128 || $cCode > 254) return false;
				}

				$b = $b == 0 ? 1 : 0;
			}
		}

		return $b;
	}

	/**
	 * ��֤qq����ĺϷ���
	 * 32 bit systems have a maximum signed integer range of -2147483648 to 2147483647
	 * 64 bit systems have a maximum signed integer range of -9223372036854775808
	 * to 9223372036854775807
	 * So we can use intval() safely to convert qq number
	 *
	 * @author        ericfu
	 *
	 * @param        string    $uin, �û�qq����
	 *
	 * @return         bool ��ȷ����true, ���󷵻�false
	 */
	public static function checkUin($uin)
	{
		self::clearError();

		if (!self::checkInt($uin)) {
			self::$errCode = 10601;
			self::$errMsg = 'uin is not integer';

			return false;
		}

		if ($uin > 10000) {
			return true;
		}

		self::$errCode = 10601;
		self::$errMsg = 'uin is not integer';

		return false;
	}

	/**
	 * �ж���Ϊ����
	 * GBKһ�����ְ��������ֽڣ����У���һ���ֽ�                 �ڶ����ֽ�
	 *        GBK      |  x81-0xFE��129-254��    |   0x40-0xFE��64-254��
	 * @param string $str
	 * @return
	 */
	public static function IsChineseWord($str)
	{
		$str = trim($str);
		$count = strlen($str);
		for ($i = 0; $i < $count; $i++) {
			$cCode = ord($str[$i]);
			if ($i & 0x1) { // ��1��3...λ
				if ($cCode < 64 || $cCode > 254) return false;
			} else { // ��0��2��4...λ
				if ($cCode < 128 || $cCode > 254) return false;
			}
		}

		return true;
	}

	/**
	 * �жϵ�ַ�ĺϷ��ԣ���������У��
	 * �������������ģ����֣�Ӣ�ģ�һ���ַ���
	 * ���Ű�����. , () - _
	 * @param string $str
	 * @return
	 */
	public static function checkAddress($str)
	{
		$str = trim($str);
		$b = 0;
		$count = strlen($str);
		for ($i = 0; $i < $count; $i++) {
			$cCode = ord($str[$i]);
			if (($cCode > 47 && $cCode < 58)) { // 0-9
				$b = 0;
			} else if (($cCode > 64 && $cCode < 91)) { // A-Z
				$b = 0;
			} else if (($cCode > 96 && $cCode < 123)) { // a-z
				$b = 0;
			} else if ($cCode == 32 || $cCode == 46 || $cCode == 40 || $cCode == 41 || $cCode == 45) { // �ո�.()-
				$b = 0;
			} else {
				if ($b == 1) { // ��1��3...λ
					if ($cCode < 64 || $cCode > 254) return false;
				} else { // ��0��2��4...λ
					if ($cCode < 128 || $cCode > 254) return false;
				}

				$b = $b == 0 ? 1 : 0;
			}
		}

		return true;
	}

	public static function checkValidCharset($str)
	{
		$str = trim($str);
		$b = 0;

		$count = strlen($str);
		$pChar = 0;
		for ($i = 0; $i < $count; $i++) {
			$cCode = ord($str[$i]);
			if (($cCode >= 0 && $cCode < 8) || ($cCode >= 11 && $cCode <= 12) || ($cCode >= 14 && $cCode <= 31) || $cCode == 127) {
				return false;
			} else if ($cCode < 128) {
				$b = 0;
			} else {
				if ($b == 1) { // ��1��3...λ
					if ($pChar > 0xF7) {
						if ($cCode < 0x40 || $cCode > 0xA0 || $cCode == 0x7F) return false;
					} else {
						if ($cCode < 0x40 || $cCode > 0xFE || $cCode == 0x7F) return false;
					}
				} else { // ��0��2��4...λ
					if ($cCode < 0x81 || $cCode > 0xFE) return false;
					$pChar = $cCode;
				}

				$b = $b == 0 ? 1 : 0;
			}
		}

		return true;
	}

	/**
	 * �ж�n�Ƿ�������
	 *
	 * @author        ericfu
	 *
	 * @param        int        $n
	 *
	 * @return        bool    ��ȷ����true, ���󷵻�false
	 */
	public static function checkInt($n)
	{
		self::clearError();

		if (!is_numeric($n)) {
			self::$errCode = 10624;
			self::$errMsg = 'param $n must be a number str. $n=' . $n;
			return false;
		}
		$n = trim($n);

		if (preg_match('/^[1-9][0-9]*$/', $n) === 1) {
			return true;
		}

		self::$errCode = 10600;
		self::$errMsg = 'data is not int';

		return false;
	}

	/**
	 * �ж����ڵĸ�ʽ�Ƿ�����ȷ��
	 * ���ڵĸ�ʽΪ:YYYY-MM-DD
	 *          or:YYYYMMDD
	 * @author        ericfu
	 *
	 * @param        string    $d, ʱ���ַ���
	 *
	 * @return        bool    ��ȷ����true, ���󷵻�false
	 *
	 * @ preg_match modified by clydechang
	 */
	public static function checkDate($d)
	{
		self::clearError();

		$d = trim($d);
		$regs = array();

		//if ( preg_match('/^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})$/', $d, $regs) !== 1 )
		if (preg_match('/^([0-9]{4})[-]*([0-9]{1,2})[-]*([0-9]{1,2})$/', $d, $regs) !== 1) {
			self::$errCode = 10603;
			self::$errMsg = 'date is invalid';

			return false;
		}

		if (checkdate($regs[2], $regs[3], $regs[1])) {
			return true;
		}

		self::$errCode = 10603;
		self::$errMsg = 'date is invalid';

		return false;
	}

	/**
	 * �ж�����ʱ��ĸ�ʽ�Ƿ�����ȷ��
	 * ���ڵĸ�ʽΪ:YYYY-MM-DD HH:mm:ss
	 *
	 * @author        ericfu
	 *
	 * @param        string    $t, ʱ���ַ���
	 *
	 * @return        bool    ��ȷ����true, ���󷵻�false
	 */
	public static function checkDateTime($t)
	{
		self::clearError();

		$t = trim($t);
		$regs = array();

		if (preg_match('/^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})$/', $t, $regs) !== 1) {
			self::$errCode = 10604;
			self::$errMsg = 'date time is invalid';

			return false;
		}

		if (checkdate($regs[2], $regs[3], $regs[1]) === false) {
			self::$errCode = 10604;
			self::$errMsg = 'date time is invalid';

			return false;
		}

		if ($regs[4] < 0 || $regs[4] > 23 || $regs[5] < 0 || $regs[5] > 59 || $regs[6] < 0 || $regs[6] > 59) {
			self::$errCode = 10604;
			self::$errMsg = 'date time is invalid';

			return false;
		}

		return true;
	}


	/**
	 * ���ݳ������ռ�������
	 *
	 * @param        int        $birth_month, ������
	 * @param        int        $birth_day, ������
	 *
	 * @return        int        $astro, ������Ӧ������(1��12), ��������0
	 */
	public static function genAstro($birth_month, $birth_day)
	{
		$astro_start_array = array(
			1 => 19, 2 => 18, 3 => 20, 4 => 20, 5 => 20, 6 => 21,
			7 => 22, 8 => 22, 9 => 22, 10 => 22, 11 => 21, 12 => 21
		);

		$birth_month = intval($birth_month);
		if ($birth_month < 1 || $birth_month > 12) {
			return 0;
		}

		$birth_day = intval($birth_day);
		if ($birth_day < 1 || $birth_day > 31) {
			return 0;
		}

		if ($birth_day > $astro_start_array[$birth_month]) {
			$astro = $birth_month - 2;
		} else {
			$astro = $birth_month - 3;
		}

		$astro = $astro > 0 ? $astro : $astro + 12;

		return $astro;
	}

	/**
	 * ת��������ʽ
	 *
	 * @param int $date:    ��������������
	 * @return array($id=>$detail)
	 */

	public static function changeDate($date)
	{
		$date = intval($date);
		$j = 1;
		$weekArray = array('һ', '��', '��', '��', '��', '��', '��');
		$days = array();
		for ($i = 0; $i < 7; $i = $i + 1) {
			if ($date & $j) {
				$days[$i + 1] = '����' . $weekArray[$i];
			}
			$j = $j * 2;
		}
		return $days;
	}

	/**
	 * ��֤�û���email��Ϣ, ��ȷ����true, ���򷵻�false
	 *
	 * @author        ericfu
	 * @modifier    peterdu
	 *
	 * @param        string    $email, �û�email
	 *
	 * @return        bool    ��ȷ����true, ���󷵻�false
	 */
	public static function checkEmail($email)
	{
		self::clearError();

		$email = trim($email);
		$pt = '/^[a-z0-9_\-]+(\.[_a-z0-9\-]+)*@([_a-z0-9\-]+\.)+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel)$/i';

		if (preg_match($pt, $email) === 1) {
			return true;
		}

		self::$errCode = 10623;
		self::$errMsg = 'email is invalid';

		return false;
	}

	/**
	 * ��֤�ʱ�
	 *
	 * @author        ericfu
	 *
	 * @param        string    $zip, ��֤�ʱ�
	 *
	 * @return        bool    ��ȷ����true, ���󷵻�false
	 */
	public static function checkZip($zip)
	{
		self::clearError();

		if (preg_match('/^[1-9]\d{5}$/', trim($zip))) {
			return true;
		}

		self::$errCode = 10605;
		self::$errMsg = 'zip code is invalid';

		return false;
	}

	/**
	 * ��֤����֤����
	 *
	 * @author        ericfu
	 *
	 * @param        string    $id, ����֤����
	 *
	 * @return        bool    ��ȷ����true, ���󷵻�false
	 */
	public static function checkIDCard($id)
	{
		self::clearError();

		if (preg_match('/^([0-9]{15}|[0-9]{17}[0-9a-z])$/i', trim($id))) {
			return true;
		}

		self::$errCode = 10606;
		self::$errMsg = 'IDCard number is invalid';

		return false;
	}

	/**
	 * ��֤�ֻ�����
	 *
	 * @author        ericfu
	 *
	 * @param        phone    $phone, �绰����
	 * @param         string        $type, CHN�й���½�绰����, INT���ʵ绰����
	 *
	 * @return        bool    ��ȷ����true, ���󷵻�false
	 */
	public static function checkMobilePhone($phone, $type = 'CHN')
	{
		self::clearError();
		$ret = false;
		switch ($type) {
			case "CHN":
				$ret = (preg_match("/^((\(\d{3}\))|(\d{3}\-))?1\d{10}$/", trim($phone)) ? true : false);
				break;
			case "INT":
				$ret = (preg_match("/^((\(\d{3}\))|(\d{3}\-))?\d{6,20}$/", trim($phone)) ? true : false);
				break;
		}

		if ($ret === false) {
			self::$errCode = 10607;
			self::$errMsg = 'Mobile Phone is not illege.';
			return false;
		}

		return true;
	}

	/**
	 * ��֤�绰����
	 *
	 * @author        ericfu
	 *
	 * @param        string        $phone, �绰����
	 * @param         string        $type, CHN�й���½�绰����, INT���ʵ绰����
	 *
	 * @return        bool        ��ȷ����true, ���󷵻�false
	 */
	public static function checkPhone($phone, $type = 'CHN')
	{
		self::clearError();

		$ret = false;

		switch ($type) {
			case 'CHN':
				$ret = preg_match('/^([0-9]{3}|0[0-9]{3})-[1-9][0-9]{6,7}(-[0-9]{1,6})?$/', trim($phone)) ? true : false;
				break;
			case 'INT':
				$ret = preg_match('/^[0-9]{4}-([0-9]{3}|0[0-9]{3})-[0-9]{7,8}$/', trim($phone)) ? true : false;
		}

		if ($ret === false) {
			self::$errCode = 10608;
			self::$errMsg = 'Phone is invalid';

			return false;
		}

		return true;
	}

	/**
	 * ��֤ip��ַ
	 *
	 * @author        ericfu
	 * @modifier    peterdu
	 *
	 * @param        string    $ip, ip��ַ
	 *
	 * @return        bool    ��ȷ����true, ���򷵻�false
	 */
	public static function checkIP($ip)
	{
		self::clearError();

		$ip = trim($ip);
		$pt = '/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/';

		if (preg_match($pt, $ip) === 1) {
			return true;
		}

		self::$errCode = 10609;
		self::$errMsg = 'IP is invalid.';

		return false;
	}

	/**
	 * ��֤url��ַ
	 *
	 * @author        ericfu
	 * @modifier    peterdu
	 *
	 * @param        string    $url, url��ַ
	 * @return        bool    ��ȷ����true, ���򷵻�false
	 */
	public static function checkURL($url)
	{
		self::clearError();

		$pt = '/^(https?:\/\/)?([a-z]([a-z0-9\-]*\.)+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel)|(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]))(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&amp;\/]*)?)?(#[a-z][a-z0-9_]*)?$/';

		if (preg_match($pt, $url) === 1) {
			return true;
		}

		self::$errCode = 10610;
		self::$errMsg = 'url is invalid';

		return false;
	}

	public static function checkLoginOrRedirect()
	{
		$uid = IUser::getLoginUid();

		if ($uid === false || $uid == 0) {
			$currentUrl = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
			self::redirect('https://base.51buy.com/login.html?url=' . urlencode($currentUrl));
			return 0;
		}

		return $uid;
	}

	/**
	 * �ض���ҳ�棬��ֹ���⻺��
	 * @param string $url Ŀ��url
	 */
	public static function redirect($url)
	{
		self::noCacheHeader();
		header("location: " . $url);
		exit;
	}

	/**
	 * ǿ���޻���
	 * @param string $url Ŀ��url
	 */
	public static function noCacheHeader()
	{
		header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
		header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
		header('Cache-Control: max-age=0');
		header('Cache-Control: no-store, no-cache, must-revalidate');
		header('Cache-Control: post-check=0, pre-check=0', false);
		header('Pragma: no-cache');
	}

	/**
	 * �ж��ַ����Ƿ�ֻ����Ӣ���ַ�
	 *
	 * @author        ericfu
	 *
	 * @param        string    $s, �ַ���
	 *
	 * @return        bool
	 */
	public static function isAlpha($s)
	{
		self::clearError();

		if (preg_match('/^[A-Za-z]+$/', $s)) {
			return true;
		}

		self::$errCode = 10611;
		self::$errMsg = 'analphabetic character is detected';

		return false;
	}

	/**
	 * ��ȡ��������ָ������IP(���б�)
	 *
	 * @param int $index    ��Ҫ��ȡ��IP���� eth(index)
	 *
	 * @author    bennylin
	 * @return    mix    [ip1, ip2, ..]/ip
	 */
	public static function getLocalIp($index = -1)
	{
		static $local_ip_list;

		if (!$local_ip_list) {
			//read from file cache
			$local_ip_list = @file_get_contents('/tmp/local_ip_list.txt');
			if ($local_ip_list) {
				$local_ip_list = explode("\n", $local_ip_list);
			} else {
				//get by exec ip cmd
				$out = array();
				$stats = array();
				exec('ip addr', $out, $stats);
				//var_dump($out, $stats);

				$local_ip_list = array();
				foreach ($out as $info) {
					//inet 192.168.2.35/24 brd 192.168.2.255 scope global eth0
					$info = trim($info);
					$m = null;
					if (strpos($info, 'inet') === 0 && preg_match('/inet (\d+\.\d+\.\d+\.\d+).*eth(\d+)/i', $info, $m)) {
						$local_ip_list[] = trim($m[1]);
					}
				}

				//cache to file
				file_put_contents('/tmp/local_ip_list.txt', implode("\n", $local_ip_list));
			}
		}

		//get one ip
		if ($index >= 0) {
			return empty($local_ip_list[$index]) ? '0.0.0.0' : $local_ip_list[$index];
		}

		//return all
		return $local_ip_list;
	}


	/**
	 * ��ȡ�ͻ���IP
	 *
	 * @author        mangoguo
	 * @modifier    kulin
	 *
	 * @return        string    $ip, IP��ַ��
	 */
	public static function getClientIP($recalc = false)
	{
		self::clearError();

		if (!$recalc && self::$clientIP !== false) {
			return self::$clientIP;
		}

		if (isset($_SERVER['HTTP_QVIA'])) {
			$ip = self::qvia2ip($_SERVER['HTTP_QVIA']);

			if ($ip) {
				return self::$clientIP = $ip;
			}
		}

		if (isset($_SERVER['HTTP_CLIENT_IP']) && !empty($_SERVER['HTTP_CLIENT_IP'])) {
			return self::$clientIP = self::checkIP($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : '0.0.0.0';
		}

		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = strtok($_SERVER['HTTP_X_FORWARDED_FOR'], ',');
			do {
				$tmpIp = explode('.', $ip);
				//-------------------
				// skip private ip ranges
				//-------------------
				// 10.0.0.0 - 10.255.255.255
				// 172.16.0.0 - 172.31.255.255
				// 192.168.0.0 - 192.168.255.255
				// 127.0.0.1, 255.255.255.255, 0.0.0.0
				//-------------------
				if (is_array($tmpIp) && count($tmpIp) == 4) {
					if (($tmpIp[0] != 10) && ($tmpIp[0] != 172) && ($tmpIp[0] != 192) && ($tmpIp[0] != 127) && ($tmpIp[0] != 255) && ($tmpIp[0] != 0)) {
						return self::$clientIP = $ip;
					}
					if (($tmpIp[0] == 172) && ($tmpIp[1] < 16 || $tmpIp[1] > 31)) {
						return self::$clientIP = $ip;
					}
					if (($tmpIp[0] == 192) && ($tmpIp[1] != 168)) {
						return self::$clientIP = $ip;
					}
					if (($tmpIp[0] == 127) && ($ip != '127.0.0.1')) {
						return self::$clientIP = $ip;
					}
					if ($tmpIp[0] == 255 && ($ip != '255.255.255.255')) {
						return self::$clientIP = $ip;
					}
					if ($tmpIp[0] == 0 && ($ip != '0.0.0.0')) {
						return self::$clientIP = $ip;
					}
				}
			} while ($ip = strtok(','));
		}

		if (isset($_SERVER['HTTP_PROXY_USER']) && !empty($_SERVER['HTTP_PROXY_USER'])) {
			return self::$clientIP = self::checkIP($_SERVER['HTTP_PROXY_USER']) ? $_SERVER['HTTP_PROXY_USER'] : '0.0.0.0';
		}

		if (isset($_SERVER['REMOTE_ADDR']) && !empty($_SERVER['REMOTE_ADDR'])) {
			return self::$clientIP = self::checkIP($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
		} else {
			return self::$clientIP = '0.0.0.0';
		}
	}

	/**
	 * ��ȡ��ͨ����������������������Ŀͻ���IP
	 *
	 * @author        kulin
	 *
	 * @return        string/flase    IP����false
	 */
	public static function qvia2ip($qvia)
	{
		self::clearError();

		if (strlen($qvia) != 40) {
			return false;
		}

		$ips = array(hexdec(substr($qvia, 0, 2)), hexdec(substr($qvia, 2, 2)), hexdec(substr($qvia, 4, 2)), hexdec(substr($qvia, 6, 2)));
		$ipbin = pack('CCCC', $ips[0], $ips[1], $ips[2], $ips[3]);
		$m = md5('QV^10#Prefix' . $ipbin . 'QV10$Suffix%');

		if ($m == substr($qvia, 8)) {
			return implode('.', $ips);
		} else {
			return false;
		}
	}

	public static function gbJsonDecode($data)
	{
		$data = str_replace("\r\n", "", $data);
		$data = str_replace("\t", "", $data);
		$data = mb_convert_encoding($data, 'UTF-8', 'GBK');
		$data = json_decode($data, true);
		return empty($data) ? "" : self::_gbJsonDecode($data);
	}

	private static function _gbJsonDecode($data)
	{
		if (is_array($data)) {
			$res = array();

			foreach ($data as $key => $value)
				$res[$key] = self::_gbJsonDecode($value);
			return $res;
		} else
			return mb_convert_encoding($data, 'GBK', 'UTF-8');
	}

	/**
	 * �Զ������ php ���ݳ� json �ĺ���(֧�� gb2312, utf-8 ���� php ���� json_encode)
	 * ע��ԭ�еķ��������硰��?�������Ļ�������
	 * @author        ericfu
	 *
	 * @param        mix        $data        ��Ҫת��������
	 */
	public static function gbJsonEncode($data)
	{
		self::clearError();

		if (is_object($data)) {
			$data = get_object_vars($data);
		}

		if (is_array($data)) {
			$data = self::_gbkToUtf8($data);
			$data = json_encode($data);
		} else if (is_string($data)) {
			$data = json_encode(iconv("GBK", "UTF-8", $data));
		} else {
			return json_encode($data);
		}

		return preg_replace_callback('/\\\\u([0-9a-f]{4})/i',
			create_function(
				'$matches',
				'return iconv("UCS-2BE", "GBK//IGNORE", pack("H*", $matches[1]));'
			),
			$data);
	}

	private static function _gbkToUtf8($data)
	{
		if (is_object($data)) {
			$data = get_object_vars($data);
		}

		if (is_array($data)) {
			$res = array();

			foreach ($data as $key => $val) {
				$key = iconv('GBK', 'UTF-8', $key);
				$res[$key] = self::_gbkToUtf8($val);
			}

			return $res;
		} else if (is_string($data)) {
			return iconv('GBK', 'UTF-8', $data);
		} else {
			return $data;
		}
	}

	/**
	 * utf-8 ��ȡ����
	 *
	 * @author        peterdu
	 *
	 * @param        string        $str, Դ�ַ���
	 * @param        int            $len, ��ȡ���Ӿ�����: Ӣ������, ������һ��; ��ȡ���βΪ�������ʱֱ��ȥ��
	 *
	 * @return        string        $tmp_str, ��ȡ����ַ���
	 */
	public static function utfSubstr($str, $len)
	{
		self::clearError();

		$len = intval($len);

		if ($len < 1) {
			return $str;
		}

		$o_len = mb_strlen($str, 'utf8');

		if ($o_len <= $len) {
			return $str;
		}

		$temp_len = 0;
		$tmp_str = '';

		for ($i = 0; $i < $o_len && $temp_len < $len; $i++) {
			$char = mb_substr($str, $i, 1, 'utf8');
			$temp_len += (ord($char[0]) > 127) ? 1 : 0.5;
			$tmp_str .= $char;
		}

		if ($temp_len > $len) {
			$tmp_str = rtrim($tmp_str, $char);
		}

		return $tmp_str;
	}

	/**
	 * xml���� gb ����ת utf8
	 *
	 * @author        bennylin
	 *
	 * @param        string        $xmldata
	 * @return        string        $xmldata
	 */
	public static function xmlGB2UTF($xmldata)
	{
		self::clearError();

		if (substr($xmldata, 0, 6) == '<?xml ') {
			$p = strpos($xmldata, "\n");
			if ($p === FALSE) {
				return $xmldata;
			}
			$xml_header = substr($xmldata, 0, $p);
			if (stripos($xml_header, 'gbk')) {
				$s = str_ireplace('gbk', 'utf-8', $xml_header);
			} else {
				$s = str_ireplace('gb2312', 'utf-8', $xml_header);
			}
			return iconv('gb18030', 'utf-8//IGNORE', $s . substr($xmldata, $p));
		}

		return $xmldata;
	}

	/**
	 * �����û������ַ��еĲ��Ϸ��ַ�
	 *
	 * Ŀǰ��Ҫֱ�Ӱ�һЩ�����ַ��滻�ɿո񣬲�ȥ��ǰ��ո�
	 *
	 * @param    string        $str    �û�������ַ�
	 * @return    string        ���˺�������ַ�
	 */
	public static function filterInput($str)
	{
		if (empty($str)) return '';
		// ��Ҫ�滻�������ַ�
		$specialStr = array('\\', '\'', '"', '`', '&', '/', '<', '>');
		$str = str_replace($specialStr, '', $str);

		// ����һ���ַ�����Χ��Ҳ��Ҫ�滻�ɿո�
		$str = trim($str);
		$asciiCode = '/[\x00-\x1f\x7f]/is';
		$str = preg_replace($asciiCode, '', $str);

		return $str;
	}

	/**
	 * ���˲��ɼ��ַ�,��Ҫ��XML��Ϊ��Ч���ַ�
	 *
	 * @param    string        $str, Դ�ַ���
	 *
	 * @return    string        $str, ���˽��
	 */
	public static function filterUnvisibleChar($str)
	{
		if (!strlen($str)) {
			return '';
		}
		return preg_replace('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', '', $str);
	}

	/**
	 * �ж��ַ����Ƿ�Ϸ�
	 *
	 * @param string $str        :������ַ���
	 * @param int     $length     :�ַ����������������
	 * @param Boolean $filter    :�Ƿ���������ַ�
	 * @param Boolean $dirty    :�Ǽ����ַ����Ƿ�������ֻ��Ƕ����ֽ����滻(false:�滻��true:���)
	 * @return Boolean|String false:���Ϸ����������໰���˵Ľ��
	 */
	public static function checkInput($str, $length, $filter = true, $dirty = false)
	{
		self::clearError();
		if (!is_numeric($length)) {
			self::$errCode = 10616;
			self::$errMsg = 'the length err';
			return false;
		}

		if (empty ($str) || !is_string($str) || strlen($str) > $length) {
			self::$errCode = 10617;
			self::$errMsg = 'the input string is empty or too long';
			return false;
		}

		if ($filter) {
			$str = self::filterInput($str);
		}
		if (empty($str)) {
			self::$errCode = 10620;
			self::$errMsg = 'the string is empty after filterInput';
			return false;
		}

		require_once PHPLIB_ROOT . 'lib/Dirty.php';

		if ($dirty) {
			$isDirty = Dirty::hasDirty($str);
			if ($isDirty) {
				self::$errCode = 10619;
				self::$errMsg = 'the string has dirty. dirty word is ' . $isDirty;
				return false;
			}
			return $str;
		}
		$str = Dirty::replaceDirty($str);
		if (empty ($str)) {
			self::$errCode = 10618;
			self::$errMsg = 'the string is empty after dirtyreplace';
			return false;
		}
		return $str;
	}

	/**
	 * ���ݴ����ʱ����������ʱ������ڵ������յ���ϸ��Ϣ
	 * ��ʽ����:
	 * array( 'year'    => 2009,
	 *           'month'    => 1,
	 *           'day'        => 12,
	 *           'hour'    => 12,
	 *           'minute'    => 2,
	 *           'sec'     => 59,
	 *           'week'     => 1
	 * )
	 *
	 * @param int t ��Ҫ������ʱ��
	 *
	 * @return array
	 */
	public static function getDetailDateTime($t)
	{
		$data = array();

		$data['year'] = date('Y', $t);
		$data['month'] = date('m', $t);
		$data['day'] = date('d', $t);
		$data['hour'] = date('H', $t);
		$data['minute'] = date('i', $t);
		$data['sec'] = date('s', $t);
		$data['week'] = date('N', $t);
		return $data;
	}


	/**
	 * ����UBB���룬���UBB�е�һЩ��ǩȥ����Ҳ���һЩ���ı�������ȥ��
	 * ��:em|video|flash|audio|vphoto|quote|ffg|url|marque|email
	 * ʹ�ô˺�����ʱ��Ҫע�⣬�˺���ֻ���ڷ���UBB���ı����ݣ���������UBB��
	 * ת���뷴ת��
	 *
	 * @param string $content
	 * @return string
	 */
	public static function filterUBB($content)
	{
		$tmp = htmlspecialchars($content);
		$tmp = stripslashes($tmp);

		$tmp = ereg_replace("\r\n", "", $tmp);
		$tmp = ereg_replace("<br/>", "", $tmp);
		$tmp = ereg_replace("<br>", "", $tmp);
		$tmp = ereg_replace("\r", "", $tmp);
		$tmp = preg_replace("/\\t/is", "", $tmp);
		$tmp = preg_replace("/\[ft([^\[\]]*?)\]\[\/ft\]/is", " ", $tmp);
		while (preg_match("/\[ft([^\[\]]*?)\](.*?)\[\/ft\]/i", $tmp)) {
			$tmp = preg_replace("/\[ft([^\[\]]*?)\](.*?)\[\/ft\]/is", "\\2", $tmp);
		}
		$tmp = preg_replace("/\[ft([^\[\]]*?)\](.*?)\[\/ft\]/is", "\\2", $tmp);
		$tmp = preg_replace("/\[ffg([^\[\]]*?)\](.*?)\[\/ffg\]/is", "\\2", $tmp);
		$tmp = preg_replace("/\[U\](.*?)\[\/U\]/is", "\\1", $tmp);
		$tmp = preg_replace("/\[U\]\[\/U\]/is", "", $tmp);
		$tmp = preg_replace("/\[M\](.*?)\[\/M\]/is", "\\1", $tmp);
		$tmp = preg_replace("/\[M\]\[\/M\]/is", "", $tmp);
		$tmp = preg_replace("/\[R\](.*?)\[\/R\]/is", "\\1", $tmp);
		$tmp = preg_replace("/\[R\]\[\/R\]/is", "", $tmp);
		$tmp = preg_replace("/\[B\](.*?)\[\/B\]/is", "\\1", $tmp);
		$tmp = preg_replace("/\[B\]\[\/B\]/is", "", $tmp);
		$tmp = preg_replace("/\[I\](.*?)\[\/I\]/is", "\\1", $tmp);
		$tmp = preg_replace("/\[I\]\[\/I\]/is", "", $tmp);
		$tmp = preg_replace("/\[em\](.*?)\[\/em\]/is", "\\1", $tmp);
		$tmp = preg_replace("/\[em\]\[\/em\]/is", "", $tmp);
		$tmp = preg_replace("/\[img([^\[\]]*?)\](.*?)\[\/img\]/is", "", $tmp);
		$tmp = preg_replace("/\[card([^\[\]]+?)\](.*?)\[\/card\]/is", "", $tmp);
		$tmp = preg_replace("/\[qqshow([^\[\]]+?)\](.*?)\[\/qqshow\]/is", "", $tmp);
		$tmp = preg_replace("/\[quote([^\[\]]+?)\](.*?)\[\/quote\]/is", "", $tmp);
		$tmp = preg_replace("/\[qqVideo([^\[\]\/]+?)\](.*?)\[\/qqVideo\]/is", "", $tmp);
		$tmp = preg_replace("/\[video([^\[\]]+?)\](.*?)\[\/video\]/is", "", $tmp);
		$tmp = preg_replace("/\[flash([^\[\]]+?)\](.*?)\[\/flash\]/is", "", $tmp);
		$tmp = preg_replace("/\[audio([^\[\]]+?)\](.*?)\[\/audio\]/is", "", $tmp);
		$tmp = preg_replace("/\[vphoto([^\[\]]+?)\](.*?)\[\/vphoto\]/is", "", $tmp);
		$tmp = preg_replace("/\[marque([^\[\]]+?)\](.*?)\[\/marque\]/is", "", $tmp);
		$tmp = preg_replace("/\[ppk_url\](http:\/\/.+?)\[\/ppk_url\]/is", "", $tmp);
		$tmp = preg_replace("/\[url\](.*?)\[\/url\]/is", "", $tmp);
		$tmp = preg_replace("/\[url=([^\[\]]*?)\](.*?)\[\/url\]/is", "\\2", $tmp);
		$tmp = preg_replace("/\[email\](.*?)\[\/email\]/is", "\\1", $tmp);
		$tmp = preg_replace("/\[email\]\[\/email\]/is", "", $tmp);
		$tmp = ereg_replace("\[hr\]", "", $tmp);
		return $tmp;
	}

	/**
	 * ����У�鴮��ͨ��hash����
	 *
	 * @param    mix        $seed1, ����У�鴮�����ӱ���(֧������,���������), �ɽ��ܶ��seed, ���֧��10��
	 * @param    mix        $seed2, ����У�鴮�����ӱ���(��ѡ����)
	 *
	 * @return    string        $hash
	 */
	public static function commHash($seed)
	{
		$enckey = '!@#123QWe';
		$numargs = func_num_args();
		$arg_list = func_get_args();
		$numargs = $numargs > 10 ? 10 : $numargs;
		$ostr = $enckey;
		for ($i = 0; $i < $numargs; $i++) {
			$temp = print_r($arg_list[$i], true);
			$ostr .= $temp;
		}
		$encstr = md5($ostr);
		return $encstr;
	}


	/**
	 * ת���Ƚ����ײ�Ʒxss�ļ�������
	 * '&' (ampersand) becomes '&amp;'
	 * '"' (double quote) becomes '&quot;' when ENT_NOQUOTES is not set.
	 * ''' (single quote) becomes '&#039;' only when ENT_QUOTES is set.
	 * '<' (less than) becomes '&lt;'
	 * '>' (greater than) becomes '&gt;'
	 * @param string $str
	 * @return string
	 */
	public static function transXSSContent($str)
	{
		$str = htmlspecialchars($str, ENT_QUOTES);
		return $str;
	}


	/**
	 * ��ת���Ƚ����ײ�Ʒxss�ļ�������
	 * '&' (ampersand) becomes '&amp;'
	 * '"' (double quote) becomes '&quot;' when ENT_NOQUOTES is not set.
	 * ''' (single quote) becomes '&#039;' only when ENT_QUOTES is set.
	 * '<' (less than) becomes '&lt;'
	 * '>' (greater than) becomes '&gt;'
	 * @param string $str
	 * @return string
	 */
	public static function unTransXSSContent($str)
	{
		$str = htmlspecialchars_decode($str, ENT_QUOTES);
		return $str;
	}

	/**
	 * ��ά��������
	 * @param Array $multi_array ����������
	 * @param Array $sort_key  �����ֶ�
	 * @return string $sort �������ͣ�SORT_ASC / SORT_DESC
	 */
	public static function multi_array_sort($multi_array, $sort_key, $sort = SORT_ASC)
	{
		if (is_array($multi_array) and !empty($multi_array)) {
			foreach ($multi_array as $row_array) {
				if (is_array($row_array)) {
					$key_array[] = $row_array[$sort_key];
				} else {
					return -1;
				}
			}
			array_multisort($key_array, $sort, $multi_array);
		}

		return $multi_array;
	}

	/**
	 * ���ɷ�ҳhtml
	 *
	 * @param string $url urlģ��,  ����: page.html?page={page}
	 * @param Number ��ǰҳ��
	 * @param Number $pageCount ҳ��
	 * $param Number neighborLength ��ʾ����ҳ��ĸ���
	 */
	public static function getpageHTML($url, $currentPage, $pageCount, $neighborLength = 3)
	{

		if ($pageCount < 2)
			return "";

		$start = $currentPage - $neighborLength;
		$end = $currentPage + $neighborLength;

		if ($start <= 4) {
			$start = 2;
		}

		$start = $start > 1 ? $start : 2;

		$end = 2 * $neighborLength - ($start < $currentPage ? ($currentPage - $start) : 0) + $currentPage;
		$end = $end < $pageCount ? $end : ($pageCount - 1);

		$str = "";
		//��һҳ
		$str .= $currentPage == 1 ? '<span class="page-start"><b>&lt;</b>��һҳ</span>' : '<a href="' . str_replace("{page}", $currentPage - 1, $url) . '" class="page-prev"><b>&lt;</b>��һҳ</a>';

		//��һҳ
		$str .= $currentPage == 1 ? "" : '<a href="' . str_replace("{page}", 1, $url) . '">1</a>';

		//���ھ�
		if ($start != 2)
			$str .= '<span class="page-break">...</span>';
		for ($i = $start; $i < $currentPage; $i++) {
			$str .= '<a href="' . str_replace("{page}", $i, $url) . '">' . $i . '</a>';
		}

		//��ǰҳ
		$str .= '<span class="page-this">' . $currentPage . '</span>';

		//���ھ�
		for ($i = $currentPage + 1; $i < $end + 1; $i++) {
			$str .= '<a href="' . str_replace("{page}", $i, $url) . '">' . $i . '</a>';
		}

		if ($end != $pageCount - 1)
			$str .= '<span class="page-break">...</span>';

		//���һҳ
		$str .= $currentPage != $pageCount ? '<a href="' . str_replace("{page}", $pageCount, $url) . '">' . $pageCount . '</a>' : '';

		//��һҳ
		$str .= $currentPage != $pageCount ? '<a href="' . str_replace("{page}", $currentPage + 1, $url) . '" class="page-next">��һҳ<b>&gt;</b></a>' : '<span class="page-end">��һҳ<b>&gt;</b></span>';

		//�������ת
		$str .= '<span class="page-skip"> ����<input type="text" value="' . $currentPage . '" maxlength="3">ҳ<button value="go" onclick="var a=parseInt($(this).parent().find(\'input[type=text]\').val(),10);a=(!!a&&a>0&&a<=' . $pageCount . ')?a:1;window.location.href=\'' . str_replace("{page}", '\'+a+\'', $url) . '\'">ȷ��</button></span>';

		return $str;
	}

	public static function escapeTransStr($str_)
	{
		$search = array(":", "&", "\n", "\r");
		$replace = array("%8A", "%8B", "%8C", "%8D");

		return str_replace($search, $replace, $str_);
	}

	public static function writeSynExceptionLog($reSyn_items_, $file_path_, $file_name_)
	{
		//check the file
		if (!file_exists("$file_path_")) {
			self::$errMsg = "no path : $file_path_";
			return;
		} else {
			$cols = "";
			$fp = fopen("$file_path_/$file_name_", 'w');
			// serialize the exception log
			foreach ($reSyn_items_ AS $wh_id => $reSyn_items) {
				foreach ($reSyn_items AS $name => $value) {
					if (4000 < strlen($value)) {
						$splits = explode(',', $value);
						$value = "";
						foreach ($splits AS $split) {
							if (4000 < strlen($value)) {
								$cols .= $wh_id . " " . "$name" . " " . "$value" . "\n";
								$value = "";
							}

							if ("" != $split) {
								$value .= $split . ',';
							}
						}
					} else if (strlen($value) == 0) {
						continue;
					}

					$cols .= $wh_id . " " . "$name" . " " . "$value" . "\n";
				}
			}

			fwrite($fp, $cols, strlen($cols));
			fclose($fp);
		}

		return true;
	}

	public static function readSynExceptionLog($file_path_, $file_name_)
	{
		//check the file
		if (!file_exists("$file_path_/$file_name_")) {
			self::$errMsg = "not exist file : $file_path_/$file_name_";
			return false;
		}

		// open file
		if (!$fp = fopen("$file_path_/$file_name_", 'r')) {
			self::$errMsg = "can't open file : $file_path_/$file_name_";
			return false;
		}

		$reSyn_items = array();
		// get file content
		while (!feof($fp)) {
			$items[] = fgets($fp, 4096);
		}

		// file is null
		if (false === $items[0]) {
			return $reSyn_items;
		}

		foreach ($items AS $item) {
			if (false === $item) {
				continue;
			}

			$content = explode(' ', $item);
			// every item must be three parts, "no name value"
			if (count($content) != 3) {
				continue;
			}

			$wh_id = $content[0];
			$name = $content[1];
			$ids = str_replace(array("\n", "\r"), '', $content[2]);

			if (isset($reSyn_items[$wh_id][$name])) {
				$reSyn_items[$wh_id][$name] .= $ids;
			} else {
				$reSyn_items[$wh_id][$name] = $ids;
			}
		}
		fclose($fp);

		return $reSyn_items;
	}

	public static function getPayTypeInfo($payTypeId, $whId)
	{
		global $_PAY_MODE;
		if (!isset($_PAY_MODE[$whId])) return false;

		if (!isset($_PAY_MODE[$whId][$payTypeId])) return false;
		return $_PAY_MODE[$whId][$payTypeId];
	}


	public static function getShipTypeInfo($shipTypeId, $whId)
	{
		global $_LGT_MODE;
		if (!isset($_LGT_MODE)) return false;

		if (!isset($_LGT_MODE[$shipTypeId])) return false;
		return $_LGT_MODE[$shipTypeId];
	}

	public static function getSynTime($key)
	{
		$mysql = Config::getDB('icson_admin');
		if (!$mysql) {
			Logger::info(Config::$errMsg);
			return false;
		}

		$sql = "SELECT `key`, `value` FROM t_config WHERE `key` = '{$key}'";
		$result = $mysql->getRows($sql);
		if (false === $result) {
			Logger::err('get data from sql fails' . $mysql->errMsg);
			return false;
		} else if (empty($result) || '' === $result[0]['value']) {
			$sql = "insert into t_config (`key`, `value`) values ('{$key}', '0')";
			$result = $mysql->execSql($sql);
			$time = date("Y-m-d H:i:s", 0);
		} else {
			$time = $result[0]['value'];
		}

		return $time;
	}

	public static function updateSynTime($key, $timestamp)
	{
		$mysql = Config::getDB('icson_admin');
		if (!$mysql) {
			Logger::info(Config::$errMsg);
			return false;
		}

		$now = date("Y-m-d H:i:s", $timestamp);
		$sql = "UPDATE t_config SET `value` = '{$now}' WHERE `key` = '{$key}'";
		$result = $mysql->execSql($sql);
		if (false === $result) {
			return false;
		}

		return true;
	}

	public static function getDBTableIndex($uid)
	{
		$dbtab = self::getDBTables();
		$tabNum = $dbtab['tabnum'];
		$dbNum = $dbtab['dbnum'];
		return array('db' => intval($uid / $tabNum) % $dbNum, 'table' => $uid % $tabNum);
	}

	public static function TTCStr2Hash($str)
	{
		return TTCStringHash($str, 1, -1);
	}

	public static function getUserDBTableIndex($hash)
	{
		$dbtab = self::getDBTables();
		$tabNum = $dbtab['tabnum'];
		$dbNum = $dbtab['dbnum'];
		return array('table' => intval($hash / $tabNum) % $dbNum, 'db' => $hash % $tabNum);
	}

	/*
		��÷ֿ�ֱ���������Ĭ���ǰٿ�ٱ�
	*/
	public static function getDeployTableIndex($hash, $dbNum = 100, $tabNum = 100)
	{
		return array('table' => intval($hash / $tabNum) % $dbNum, 'db' => $hash % $tabNum);
	}

	public static function getCouponDBTableIndex($hash)
	{
		$dbtab = self::getDBTables();
		$tabNum = $dbtab['tabnum'];
		$dbNum = $dbtab['dbnum'];
		return array('table' => intval($hash / $tabNum) % $dbNum, 'db' => $hash % $tabNum);
	}

	public static function getDBTables()
	{
		return array('tabnum' => 100, 'dbnum' => 100);
	}

	public static function getDBNumAndTableNum($name)
	{
		global $_DB_TABLE_CFG;
		return array('tabnum' => $_DB_TABLE_CFG[$name]['TABLE_NUM'], 'dbnum' => $_DB_TABLE_CFG[$name]['DB_NUM']);
	}

	public static function getDBObj($name, $i = -1)
	{
		global $_DB_TABLE_CFG;
		global $_DB_SERVER_CFG;
		global $_DB_CFG;
		$ipKey = $_DB_TABLE_CFG[$name]['IP'];
		$db = $_DB_TABLE_CFG[$name]['DB'];
		$config = $_DB_SERVER_CFG['online'][$ipKey];

		if (-1 == $i) {
			$config['DB'] = $db;
			$cfgKey = $name;
		} else {
			$config['DB'] = $db . "_" . $i;
			$cfgKey = $name . '_' . $i;
		}

		$_DB_CFG[$cfgKey] = $config;
		$db = Config::getDB($cfgKey);
		if ($db === false) {
			return false;
		}

		//for module state report
		$db->configId = $name;

		return $db;
	}

	public static function getMSDBNum($name)
	{
		global $_MSDB_TABLE_CFG;
		if (isset($_MSDB_TABLE_CFG[$name])) {
			return $_MSDB_TABLE_CFG[$name]['DB_NUM'];
		}
		return false;
	}


	public static function getMSDBTableIndex($uid, $name = 'ICSON_ORDER_CORE')
	{
		$dbtab = self::getMSDBNumAndTableNum($name);
		$tabNum = $dbtab['tabnum'];
		$dbNum = $dbtab['dbnum'];
		return array('db' => intval($uid / $tabNum) % $dbNum, 'table' => $uid % $tabNum);
	}

	public static function getMSDBNumAndTableNum($name)
	{
		global $_MSDB_TABLE_CFG;
		return array('tabnum' => $_MSDB_TABLE_CFG[$name]['TABLE_NUM'], 'dbnum' => $_MSDB_TABLE_CFG[$name]['DB_NUM']);
	}

	public static function getMSDBObj($name, $i = -1)
	{
		self::clearError();
		global $_MSDB_TABLE_CFG;
		global $_MSDB_SERVER_CFG;
		global $_MSDB_CFG;
		$ipKey = $_MSDB_TABLE_CFG[$name]['IP'];
		$db = $_MSDB_TABLE_CFG[$name]['DB'];
		$config = $_MSDB_SERVER_CFG['online'][$ipKey];

		if (-1 == $i) {
			$config['DB'] = $db;
			$cfgKey = $name;
		} else {
			$config['DB'] = $db . "_" . $i;
			$cfgKey = $name . '_' . $i;
		}

		$_MSDB_CFG[$cfgKey] = $config;
		$db = Config::getMSDB($cfgKey);

		if ($db === false) {
			self::setERR(Config::$errCode, Config::$errMsg);
			return false;
		}

		//for module state report
		$db->configId = $name;

		return $db;
	}

	public static function getMSBakDBObj($name, $i = -1)
	{
		global $_MSDB_TABLE_CFG;
		global $_MSDB_SERVER_CFG;
		global $_MSDB_CFG;
		$ipKey = $_MSDB_TABLE_CFG[$name]['IP'];
		$db = $_MSDB_TABLE_CFG[$name]['DB'];
		$config = $_MSDB_SERVER_CFG['bakup'][$ipKey];

		if (-1 == $i) {
			$config['DB'] = $db;
			$cfgKey = $name;
		} else {
			$config['DB'] = $db . "_" . $i;
			$cfgKey = $name . '_' . $i;
		}

		$_MSDB_CFG[$cfgKey] = $config;
		$db = Config::getMSDB($cfgKey);
		if ($db === false) {
			return false;
		}

		//for module state report
		$db->configId = $name;

		return $db;
	}

	public static function getDBTableName($name, $i)
	{
		return 't_' . $name . "_" . $i;
	}

	/**
	 * ͨ����������ѯ������Ϣ
	 * @param string $cityName
	 * @return mixed array ��ѯ�ɹ�; false ʧ��
	 */
	public static function getLocInfoByCityName($cityName)
	{
		if (empty($cityName)) {
			return false;
		}
		global $_District, $_City, $_Province;

		$cityId = false;
		foreach ($_City as $idx => &$item) {
			if (false !== strpos($item['name'], $cityName)) {
				$cityId = $item['id'];
				break;
			}
		}

		return (false === $cityId) ? false : self::getLocInfo($cityId);
	}

	public static function getLocInfo($id)
	{
		global $_District, $_City, $_Province;

		if (!isset($_District[$id])) {
			if (!isset($_City[$id])) {
				if (!isset($_Province[$id])) {
					return false;
				}

				// ��һ��ʡ������
				return array(
					"province_id" => $id,
					"province_name" => $_Province[$id],
					"full_name" => $_Province[$id],
				);
			}

			$prov_id = $_City[$id]['province_id'];
			if (!isset($_Province[$prov_id])) {
				return false;
			}

			return array(
				"province_id" => $prov_id,
				"province_name" => $_Province[$prov_id],
				"city_id" => $id,
				"city_name" => $_City[$id]['name'],
				"full_name" => ($_Province[$prov_id] == $_City[$id]['name'] ? "" : $_Province[$prov_id]) . $_City[$id]['name'],
			);
		}

		$addr = $_District[$id];
		if (!isset($_City[$addr['city_id']])) { // �м���Ч
			return false;
		}

		$addr['city_name'] = $_City[$addr['city_id']]['name'];

		if (!isset($_Province[$addr['province_id']])) { // ʡ����Ч
			return false;
		}

		$addr['province_name'] = $_Province[$addr['province_id']];
		$addr['full_name'] = ($addr['province_name'] == $addr['city_name'] ? "" : $addr['province_name']) . $addr['city_name'] . $addr['name'];
		return $addr;
	}

	/**
	 * PHP �汾escape��CPS����ʱ����
	 * @param string $str
	 */
	public static function escape($str)
	{
		preg_match_all("/[\x80-\xff].|[\x01-\x7f]+/", $str, $r);
		$ar = $r[0];
		foreach ($ar as $k => $v) {
			if (ord($v[0]) < 128) {
				$ar[$k] = rawurlencode($v);
			} else {
				$ar[$k] = "%u" . bin2hex(mb_convert_encoding($v, 'UCS-2', 'GBK'));
			}
		}
		return join('', $ar);
	}

	/**
	 *
	 * @param $str
	 * @param $start
	 * @param $len
	 */
	public static function msubstr($str, $start, $len)
	{
		$tmpstr = "";
		$strlen = $start + $len;
		for ($i = 0; $i < $strlen; $i++) {
			if (ord(substr($str, $i, 1)) > 0xa0) {
				$tmpstr .= substr($str, $i, 2);
				$i++;
			} else
				$tmpstr .= substr($str, $i, 1);
		}
		return $tmpstr;
	}

	//����һ���ַ�����hash����ֵ��ȡֵ����Ϊ[0-5614657)
	public static function  string2IntHash($str)
	{
		$hash = 0;
		$n = strlen($str);
		for ($i = 0; $i < $n; $i++) {
			$hash ^= (ord($str[$i]) << ($i & 0x0f));
		}
		return $hash % 5614657;
	}


	/*
		��̬TTC get
	*/
	public static function _getTTCInfo($ttcname, $key, $line, $filter = array(), $need = array())
	{
		$ttc = new $ttcname;
		$item = $ttc->get($key, $filter, $need);
		if (false === $item) {
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . $line . "[{$ttcname} get failed:]";
			return false;
		}
		return $item;
	}

	/*
		��̬TTC gets
	*/
	public static function _getTTCInfos($ttcname, $keys, $line, $filter = array(), $need = array())
	{
		$ttc = new $ttcname;
		$items = $ttc->gets($keys, $filter, $need);
		if (false === $items) {
			self::$errMsg = basename(__FILE__, '.php') . " | Line:" . $line . "[{$ttcname} get failed:]";
			return false;
		}

		return $items;
	}

	/*
		��ȡ�ֿ�ֱ�DB,���ַ���Ϊ����
	*/
	public static function _getDBStr_m($str, $prefix, &$mysql, &$index, $line)
	{
		$hash = self::TTCStr2Hash($str);
		$index = self::getDeployTableIndex($hash);
		$mysql = self::getDBObj($prefix, $index['db']);
		//var_dump($index);
		if (false === $mysql) {
			self::$errCode = self::$errCode;
			self::$errMsg = basename(__FILE__, 'php') . " | Line: $line _getDBStr_m Error" . self::$errMsg;
			return false;
		}
		return true;
	}

	/*
		��ȡ�ֿ�ֱ�DB,��intΪ����
	*/
	public static function _getDBInt_m($num, $prefix, &$mysql, &$index, $line)
	{
		$index = self::getDeployTableIndex($num);
		$mysql = self::getDBObj($prefix, $index['db']);

		if (!$mysql) {
			self::$errCode = self::$errCode;
			self::$errMsg = basename(__FILE__, 'php') . " | Line: $line _getDB Error" . self::$errMsg;
			return false;
		}
		return true;
	}

	/*
		��ȡ������DB
	*/
	public static function _getDB_s($dbname, &$mysql, $line)
	{
		$mysql = self::getDBObj($dbname);
		if (!$mysql) {
			self::$errCode = self::$errCode;
			self::$errMsg = basename(__FILE__, 'php') . " | Line: $line _getDB Error" . self::$errMsg;
			return false;
		}
		return true;
	}

	public static function _update_m($prefix, &$mysql, &$index, &$data, $condition, $line)
	{
		$uRet = $mysql->update($prefix . "_" . $index['table'], $data, $condition);
		if (false === $uRet) {
			self::$errCode = $mysql->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " | Line: $line \n_update info to mysql faild:" . $mysql->errMsg;
			$mysql->execSql("rollback");
			return false;
		}
		return true;
	}


	public static function _remove_m($prefix, &$mysql, &$index, $condition, $line)
	{
		$uRet = $mysql->remove($prefix . "_" . $index['table'], $condition);
		if (false === $uRet) {
			self::$errCode = $mysql->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " | Line: $line _remove  info to mysql faild:" . $mysql->errMsg;
			$mysql->execSql("rollback");
			return false;
		}
		return true;
	}

	public static function _insert_m($prefix, &$mysql, &$index, &$data, $line)
	{
		$uRet = $mysql->insert($prefix . "_" . $index['table'], $data);
		if (false === $uRet) {
			self::$errCode = $mysql->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " | Line: $line _insert  info to mysql faild:" . $mysql->errMsg;
			$mysql->execSql("rollback");
			return false;
		}
		return true;
	}

	public static function _update_s($tbname, &$mysql, &$data, $condition, $line)
	{
		$uRet = $mysql->update($tbname, $data, $condition);
		if (false === $uRet) {
			self::$errCode = $mysql->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " | Line: $line \n_update info to mysql faild:" . $mysql->errMsg;
			$mysql->execSql("rollback");
			return false;

		}
		return true;
	}

	public static function _remove_s($uid, $tbname, &$mysql, $condition, $line)
	{
		$uRet = $mysql->remove($tbname, $condition);
		if (false === $uRet) {
			self::$errCode = $mysql->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " | Line: $line _remove ($uid) info to mysql faild:" . $mysql->errMsg;
			$mysql->execSql("rollback");
			return false;
		}
		return true;
	}

	public static function _insert_s($tbname, &$mysql, &$data, $line)
	{
		$uRet = $mysql->insert($tbname, $data);
		if (false === $uRet) {
			self::$errCode = $mysql->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " | Line: $line _insert  info to mysql faild:" . $mysql->errMsg;
			$mysql->execSql("rollback");
			return false;
		}
		return true;
	}

	public static function _select_s(&$mysql, $sql, $line)
	{
		$uRet = $mysql->getRows($sql);
		if (false === $uRet) {
			self::$errCode = $mysql->errCode;
			self::$errMsg = basename(__FILE__, '.php') . " | Line: $line _select info to mysql faild:" . $mysql->errMsg;
			return false;
		}

		return $uRet;
	}


	public static function _purgeData4Str($ttcname, $str)
	{
		if (!empty($str))
			IAsyTask::purgeTTCData($ttcname, $str);
	}

	public static function _purgeData4Int($ttcname, $num)
	{
		IAsyTask::purgeTTCData($ttcname, $num);
	}


	public static function _transaction($mysql, $cmd, $line)
	{
		if (false === $mysql->execSql($cmd)) {
			self::$errCode = $mysql->errMsg;
			self::$errMsg = basename(__FILE__, "php") . " | Line: $line $cmd Transaction Error" . $mysql->errMsg;
			return false;
		}
		return true;
	}

	public static function isRequestFromMobile()
	{
		if (!isset($_SERVER['HTTP_USER_AGENT'])) return false;

		$userAgent = $_SERVER['HTTP_USER_AGENT'];
		$AGENTSCONFIG = Array("240x320", "acer", "acoon", "acs-", "abacho", "ahong", "airness", "alcatel", "amoi", "android", "anywhereyougo.com", "applewebkit/525", "applewebkit/532", "asus", "audio", "au-mic", "avantogo", "becker", "benq", "bilbo", "bird", "blackberry", "blazer", "bleu", "cdm-", "compal", "coolpad", "danger", "dbtel", "dopod", "elaine", "eric", "etouch", "fly ", "fly_", "fly-", "go.web", "goodaccess", "gradiente", "grundig", "haier", "hedy", "hitachi", "htc", "huawei", "hutchison", "inno", "ipad", "ipaq", "ipod", "jbrowser", "kddi", "kgt", "kwc", "lenovo", "lg ", "lg2", "lg3", "lg4", "lg5", "lg7", "lg8", "lg9", "lg-", "lge-", "lge9", "longcos", "maemo", "mercator", "meridian", "micromax", "midp", "mini", "mitsu", "mmm", "mmp", "mobi", "mot-", "moto", "nec-", "netfront", "newgen", "nexian", "nf-browser", "nintendo", "nitro", "nokia", "nook", "novarra", "obigo", "palm", "panasonic", "pantech", "philips", "phone", "pg-", "playstation", "pocket", "pt-", "qc-", "qtek", "rover", "sagem", "sama", "samu", "sanyo", "samsung", "sch-", "scooter", "sec-", "sendo", "sgh-", "sharp", "siemens", "sie-", "softbank", "sony", "spice", "sprint", "spv", "symbian", "talkabout", "tcl-", "teleca", "telit", "tianyu", "tim-", "toshiba", "tsm", "up.browser", "utec", "utstar", "verykool", "virgin", "vk-", "voda", "voxtel", "vx", "wap", "wellco", "wig browser", "wii", "windows ce", "wireless", "xda", "xde", "zte");
		foreach ($AGENTSCONFIG as $device) {
			if (stristr($userAgent, $device)) {
				return true;
			}
		}

		return false;
	}

	//ȥ��ipad
	public static function isFromMobileExpIpad()
	{
		if (!isset($_SERVER['HTTP_USER_AGENT']) || stristr($_SERVER['HTTP_USER_AGENT'], 'ipad')) return false;

		$userAgent = $_SERVER['HTTP_USER_AGENT'];
		$AGENTSCONFIG = Array("240x320", "acer", "acoon", "acs-", "abacho", "ahong", "airness", "alcatel", "amoi", "android", "anywhereyougo.com", "applewebkit/525", "applewebkit/532", "asus", "audio", "au-mic", "avantogo", "becker", "benq", "bilbo", "bird", "blackberry", "blazer", "bleu", "cdm-", "compal", "coolpad", "danger", "dbtel", "dopod", "elaine", "eric", "etouch", "fly ", "fly_", "fly-", "go.web", "goodaccess", "gradiente", "grundig", "haier", "hedy", "hitachi", "htc", "huawei", "hutchison", "inno", "ipad", "ipaq", "ipod", "jbrowser", "kddi", "kgt", "kwc", "lenovo", "lg ", "lg2", "lg3", "lg4", "lg5", "lg7", "lg8", "lg9", "lg-", "lge-", "lge9", "longcos", "maemo", "mercator", "meridian", "micromax", "midp", "mini", "mitsu", "mmm", "mmp", "mobi", "mot-", "moto", "nec-", "netfront", "newgen", "nexian", "nf-browser", "nintendo", "nitro", "nokia", "nook", "novarra", "obigo", "palm", "panasonic", "pantech", "philips", "phone", "pg-", "playstation", "pocket", "pt-", "qc-", "qtek", "rover", "sagem", "sama", "samu", "sanyo", "samsung", "sch-", "scooter", "sec-", "sendo", "sgh-", "sharp", "siemens", "sie-", "softbank", "sony", "spice", "sprint", "spv", "symbian", "talkabout", "tcl-", "teleca", "telit", "tianyu", "tim-", "toshiba", "tsm", "up.browser", "utec", "utstar", "verykool", "virgin", "vk-", "voda", "voxtel", "vx", "wap", "wellco", "wig browser", "wii", "windows ce", "wireless", "xda", "xde", "zte");
		foreach ($AGENTSCONFIG as $device) {
			if (stristr($userAgent, $device)) {
				return true;
			}
		}

		return false;
	}

	public static function isRequestFromAndroid()
	{
		if (!isset($_SERVER['HTTP_USER_AGENT'])) return false;

		return stristr($_SERVER['HTTP_USER_AGENT'], "android") ? true : false;
	}

	public static function makePageIdFromURL($pageType = PAGE_TYPE_COMMON)
	{
		$urlWithoutQueryStr = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
		if(preg_match("/\%27|\'/",$urlWithoutQueryStr)){
			return 0;
		}		
		$qSplit = strpos($urlWithoutQueryStr, "?");
		if (false !== $qSplit) {
			$urlWithoutQueryStr = substr($urlWithoutQueryStr, 0, $qSplit);
		}
				
		return ITag::getPageId($urlWithoutQueryStr, $pageType);
	}

	/**
	 * ��������ͳ�Ƶ�pageid��pagelevel
	 * @param int $yPageId
	 * @param int $yPageLevel
	 */
	public static function setCurrentPageId($yPageLevel, $yPageId = false, $pageType = PAGE_TYPE_COMMON)
	{
		self::$yPageLevel = $yPageLevel;

		if ($yPageId === false) {
			$yPageId = self::makePageIdFromURL($pageType);
		}
		self::$yPageId = $yPageId;
	}

	/**
	 * ��ȡ����ͳ�Ƶ�pageid��pagelevel
	 * @return array
	 */
	public static function getCurrentPageId()
	{
		return array(
			'yPageId' => self::$yPageId,
			'yPageLevel' => self::$yPageLevel
		);
	}

	/*
	  * ��ȡ�ļ���׺
	  *
	  * @Param	string	$fileName	the current file name
	  * @Return string
	  * @Created 19:29 2012/07/06
	  * @Author EdisonTsai
	  */
	public static function fileExt($fileName)
	{
		if (empty($fileName)) {
			return '';
		}
		return trim(strtolower(substr(strrchr($fileName, '.'), 1)));
	}

	/*
	 * ��¼���ݸ��ºͲ������
	 * $prefix д��ʾ���֣�Ĭ��Ϊ�գ�$dataΪҪд�������
	 * update ��ʽ��data ��ʽΪ:
	    array(
	       key1 => array('old' => value1,'new' => value2),
	       key2 => array('old' => value1,'new' => value2),
	       key3 => array('old' => value1,'new' => value2),
	       key4 => array('old' => value1,'new' => value2),
		);

	 *	insert ��ʽ��data��ʽΪ:
		array(
			$key1 => val1,
			$key2 => val2,
			$key3 => val3,
			$key4 => val4,
		);
	*/
	public static function traceLog($data, $method, $prefix = '')
	{
		if (!is_array($data)) {
			self::$errMsg = basename(__FILE__) . ",line:" . __LINE__ . ",errMsg: para error";
			return false;
		}


		$logMsg = "";
		if ($method == "update") {
			$logMsg = "update values:\n";
			if ($prefix != "")
				$logMsg .= $prefix . ",";
			foreach ($data as $key => $val) {
				if (!isset($val['old']) || !isset($val['new'])) {
					self::$errMsg = basename(__FILE__) . ",line:" . __LINE__ . ",errMsg: para error";
					return false;
				}

				if ($val['new'] == $val['old'])
					$logMsg .= "({$key}, {$val['old']} == {$val['new']})";
				else
					$logMsg .= "({$key}, {$val['old']} <> {$val['new']})";
			}
		} else if ($method == "insert") {
			$logMsg = "insert values:\n";
			if ($prefix != "")
				$logMsg .= $prefix . ",";
			foreach ($data as $key => $val) {
				$logMsg .= "({$key},{$val})";
			}
		}
		Logger::info($logMsg);
		return true;
	}


	/*
	  * ͨ���ļ��ϴ���������
	  * ֧�ָ�ʽ���ã�Ĭ��֧�ָ�ʽ��ͼ���ļ�Ϊ����ex: jpg/jpeg/gif/png/bmp etc...
	  *
	  * @Param	object	$fileID			this file id/name in HTML
	  * @Param	string	$destFolder		save to destination folder
	  * @Param	boolean	$isCreateDateFolder	Create date folder on destination folder or not, default is not create,
	  *										format is 'Y_m_d'
	  * @Param	array	$tmpAllowExt	allow extensions for temp using,
	  *									such as txt/zip/rar/tar/gz/exe etc...
	  *	@Param	array	$tmpAllowMimeType	allow mime type for temp using
	  * @Return array(
					0=>boolean(true or false),
					1=>return message,
					2=>path($destFolder/$newFileName)
				)
	  * @Author	EdisonTsai
	  *	@Date	10:13 2012/07/06
	  */
	public static function uploadFile($fileID, $destFolder = '', $isCreateDateFolder = false, $tmpAllowExt = array(), $tmpAllowMimeType = array())
	{

		self::clearError();

		#If no $fileID
		if (!isset($fileID) || empty($fileID)) {

			self::$errCode = '40001';
			self::$errMsg = 'Invalid fileID';

			return array(
				false,
				self::$errMsg,
				''
			);
		}

		#Check is upload succeed
		if (!isset($_FILES[$fileID]) || !is_uploaded_file($_FILES[$fileID]['tmp_name']) || empty($_FILES[$fileID]['tmp_name']) || 'none' == $_FILES[$fileID]['tmp_name']) {

			self::$errCode = '40002';
			self::$errMsg = 'Invalid file';

			return array(
				false,
				self::$errMsg,
				''
			);
		} #end if


		#Command for get mime type of file
		#$cmd = 'file -i -b %s';

		#The allow extensions list, only for image file at present
		$allowExt = array(
			'jpg',
			'jpeg',
			'gif',
			'png',
			'bmp'
		);

		$allowMimeType = array(
			'image/jpg',
			'image/jpeg',
			'image/gif',
			'image/png',
			'image/bmp',
			//Added by EdisonTsai on 15:01 2012/07/30 for add supported mime type
			'application/msword',
			'application/msexcel'
		);

		$allowMimeType = is_array($tmpAllowMimeType) && count($tmpAllowMimeType) ? array_merge($allowMimeType, $tmpAllowMimeType) : $allowMimeType;
		$allowExt = is_array($tmpAllowExt) && count($tmpAllowExt) ? array_merge($allowExt, $tmpAllowExt) : $allowExt;

		$isPassed = false; // using for set the pass flag
		$mimeType = $mimeTypeCurr = $fileExt = ''; //for storing mime type content

		/*
					 * Trying to check the mime type of file
					 * for checking allowExt at first
					 */
		$mimeTypeCurr = @getimagesize($_FILES[$fileID]['tmp_name']);

		if (isset($mimeTypeCurr['mime']) && in_array($mimeTypeCurr, $allowMimeType)) {

			$mimeType = $mimeTypeCurr['mime'];
			$isPassed = true;

		} /*Modified by EdisonTsai on 14:41 2012/08/03 for skip mimetype checking
			elseif(function_exists('finfo_open')){

				$finfo = new finfo(FILEINFO_MIME);

				 if(!$finfo){

					self::$errCode	= '40003';
					self::$errMsg	= 'There is failed to invoke finfo';

					return array(
							false,
							self::$errMsg,
							''
					);
				} #end if

				$mimeTypeCurr	= $finfo->file($_FILES[$fileID]['tmp_name']);
				$mimeType		= substr($mimeTypeCurr, 0, strpos($mimeTypeCurr,';'));

					if(!in_array($mimeType, $allowMimeType)){

							self::$errCode	= '40004';
							self::$errMsg	= 'Not allow file type as '.$mimeType;

							return array(
									false,
									self::$errMsg,
									''
							);
					}

					$isPassed = true;

			}elseif(function_exists('mime_content_type')){

				$mimeType = @mime_content_type($_FILES[$fileID]['tmp_name']);


					if(!in_array($mimeType, $allowMimeType)){

							self::$errCode	= '40005';
							self::$errMsg	= 'Not allow file type as '.$mimeType;

							return array(
									false,
									self::$errMsg,
									''
							);
					}

					$isPassed = true;
			}*/
		/*elseif(function_exists('exec')){ #Ignore execute the high risk function

		   }*/
		else { #at last, no choice! only can checking via extension, that's not safety!

			$fileExt = self::fileExt($_FILES[$fileID]['name']);

			$isPassed = in_array($fileExt, $allowExt) ? true : false;

		} #end if

		if (true !== $isPassed) {

			self::$errCode = '40006';
			self::$errMsg = 'Not allow file type as ' . ('' != $mimeType ? $mimeType : $fileExt);

			return array(
				false,
				self::$errMsg,
				''
			);
		}

		$maxFileSize = (int)ini_get('upload_max_filesize');

		if ($_FILES[$fileID]['error'] > 0) {

			self::$errCode = '40007';
			self::$errMsg = 'Upload file failed, the error number is ' . $_FILES[$fileID]['error'];

			return array(
				false,
				self::$errMsg,
				''
			);

		} elseif ($_FILES[$fileID]['size'] > ($maxFileSize * 1024 * 1024)) {

			self::$errCode = '40008';
			self::$errMsg = 'Exceed the max file size, default is ' . $maxFileSize . 'M';

			return array(
				false,
				self::$errMsg,
				''
			);

		}

		$fileExt = empty($fileExt) ? (self::fileExt($_FILES[$fileID]['name'])) : $fileExt;

		$newFileName = md5(uniqid(rand(), true)) . '.' . $fileExt;
		$newFolder = $isCreateDateFolder ? $destFolder . '/' . date('Y_m_d') : $destFolder;

		//Try to create new folder(s)
		if (!Tools::mkdirs($newFolder)) {

			self::$errCode = '40009';
			self::$errMsg = 'Can not create folder as ' . $newFolder;

			return array(
				false,
				self::$errMsg,
				''
			);
		}

		#Trying to move or copy file to destination folder
		if (!@move_uploaded_file($_FILES[$fileID]['tmp_name'], $newFolder . '/' . $newFileName)) { #Trying normal mode
			if (!@copy($_FILES[$fileID]['tmp_name'], $newFolder . '/' . $newFileName)) { #Trying advance mode

				#Still failed?
				self::$errCode = '40010';
				self::$errMsg = 'Can not move uploaded file to ' . $newFolder;

				return array(
					false,
					self::$errMsg,
					''
				);
			} #end if
		} #end if


		unset($_FILES, $finfo);

		return array(
			true,
			'Upload file successfully',
			$newFolder . '/' . $newFileName
		);

	}

	/**
	 * �������ò������Ŀ�������е�ֵ����������ά����
	 * @param $obj Ŀ������
	 * @param $mask �������
	 * @param $allowEmpty �Ƿ�����Ŀ��������δ���������е�ֵ
	 * @example
	 * $obj = array(
	'k1' => 'v1',
	'k2' => array(
	'k2_1' => 'v2_1',
	'k2_2' => 'v2_2'
	),
	'k3' => array(
	'k3_1' => 'v3_1',
	'k3_2' => 'v3_2'
	),
	'k4' => array(
	'v4_1',
	'v4_2'
	),
	'k5' => array(
	array(
	'k5_1' => 'v5_1_1',
	'k5_2' => 'v5_1_2'
	),
	array(
	'k5_1' => 'v5_2_1',
	'k5_2' => 'v5_2_2'
	)
	)
	);

	$mask = array(
	'k1' => true,
	'k2' => true,
	'k3' => array(
	'k3_1' => true,
	),
	'k4' => true,
	'k5' => array(
	'k5_2' => true
	)
	);

	try {
	$res = ToolUtil::array_mask($obj, $mask);
	var_dump($res);
	} catch(BaseException $e) {
	echo $e->errCode . ' : ' . $e->errMsg . "\n";
	}

	�����
	array(5) {
	["k1"]=>
	string(2) "v1"
	["k2"]=>
	array(2) {
	["k2_1"]=>
	string(4) "v2_1"
	["k2_2"]=>
	string(4) "v2_2"
	}
	["k3"]=>
	array(1) {
	["k3_1"]=>
	string(4) "v3_1"
	}
	["k4"]=>
	array(2) {
	[0]=>
	string(4) "v4_1"
	[1]=>
	string(4) "v4_2"
	}
	["k5"]=>
	array(2) {
	[0]=>
	array(1) {
	["k5_2"]=>
	string(6) "v5_1_2"
	}
	[1]=>
	array(1) {
	["k5_2"]=>
	string(6) "v5_2_2"
	}
	}
	}
	 */
	public static function array_mask($obj, $mask, $allowEmpty = true)
	{
		if ($mask === true) {
			// ȫ�����
			return $obj;
		} else if (is_array($mask)) {
			// ��mask���
			if (is_array($obj)) {
				$new_obj = array();
				if (ToolUtil::is_assoc_array($obj)) {
					// ��������
					foreach ($mask as $k => $v) {
						if (isset($obj[$k])) {
							$new_obj[$k] = ToolUtil::array_mask($obj[$k], $v);
						} else {
							if (!$allowEmpty) {
								throw new BaseException(103, "Attribute $k not set.");
							}
						}
					}
				} else {
					// ˳������
					foreach ($obj as $child) {
						$new_obj[] = ToolUtil::array_mask($child, $mask);
					}
				}
				return $new_obj;
			} else {
				// ������mask�޷�ƥ��
				throw new BaseException(102, 'Array can not match with mask.');
			}
		} else {
			// ��Ч��mask
			throw new BaseException(101, 'Illegal mask.');
		}
	}

	/**
	 * �ж��Ƿ��������
	 * @param $obj Ŀ������
	 */
	public static function is_assoc_array($obj)
	{
		if (is_array($obj)) {
			return array_keys($obj) !== range(0, count($obj) - 1);
		} else {
			throw new BaseException(101, 'Parameter 1 is not an array.');
		}
	}

	/**
	 * ��Ŀ����������ȡָ��ֵ��ֻ����һά����
	 * @param $obj Ŀ������
	 * @param $filter ��������
	 * @example
	 * $params = ToolUtil::array_fetch($_GET, array(
	 *         'id' => array(
	 *             'name' => 'product_id' // ����ָ��Ŀ�������е���������ʡ��������������ֵ��ͬ
	 *             'default' => '' // ����Ĭ��ֵ����ʡ�ԣ�Ĭ��Ϊ''
	 *             'allowEmpty' => false // ָ���������ܹ�Ϊ�գ���ʡ�ԣ�Ĭ��Ϊtrue����ʶ����Ϊ��
	 *             'secureType' => 'int' // ���ð�ȫ���ƣ�����Ϊ'int'��'string'����ʡ��������ȫ����
	 *         )
	 *         ...
	 * ));
	 */
	public static function array_fetch($obj, $filter)
	{
		if (!is_array($obj)) {
			throw new BaseException(101, 'Parameter 1 is not an array.');
		}
		if (!is_array($filter)) {
			throw new BaseException(102, 'Parameter 2 is not an array.');
		}
		$out = array();
		foreach ($filter as $name => $config) {
			$pname = (isset($config['name']) && !empty($config['name'])) ? $config['name'] : $name;
			if (isset($config['default']) && (!isset($obj[$pname]) || empty($obj[$pname])))
				$obj[$pname] = $config['default'];

			if (isset($config['allowEmpty']) && !$config['allowEmpty'] && (!isset($obj[$pname]) || empty($obj[$pname])))
				throw new BaseException(103, "Property $pname should not be empty.");

			if (isset($obj[$pname])) {
				if (isset($config['secureType'])) {
					if ($config['secureType'] == 'int') {
						$out[$name] = intval($obj[$pname]);
					} else if ($config['secureType'] == 'string') {
						$out[$name] = ToolUtil::transXSSContent($obj[$pname]);
					} else
						throw new BaseException(104, "Undefined secure type {$config['secureType']}.");
				} else
					$out[$name] = $obj[$pname];
			} else
				$out[$name] = '';
		}
		return $out;
	}

	/**
	 * �ж������Ƿ������ƶ��豸
	 */
	public static function is_mobile()
	{
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		$mobile_agents = Array("240x320", "acer", "acoon", "acs-", "abacho", "ahong", "airness", "alcatel", "amoi", "android", "anywhereyougo.com", "applewebkit/525", "applewebkit/532", "asus", "audio", "au-mic", "avantogo", "becker", "benq", "bilbo", "bird", "blackberry", "blazer", "bleu", "cdm-", "compal", "coolpad", "danger", "dbtel", "dopod", "elaine", "eric", "etouch", "fly ", "fly_", "fly-", "go.web", "goodaccess", "gradiente", "grundig", "haier", "hedy", "hitachi", "htc", "huawei", "hutchison", "inno", "ipad", "ipaq", "ipod", "jbrowser", "kddi", "kgt", "kwc", "lenovo", "lg ", "lg2", "lg3", "lg4", "lg5", "lg7", "lg8", "lg9", "lg-", "lge-", "lge9", "longcos", "maemo", "mercator", "meridian", "micromax", "midp", "mini", "mitsu", "mmm", "mmp", "mobi", "mot-", "moto", "nec-", "netfront", "newgen", "nexian", "nf-browser", "nintendo", "nitro", "nokia", "nook", "novarra", "obigo", "palm", "panasonic", "pantech", "philips", "phone", "pg-", "playstation", "pocket", "pt-", "qc-", "qtek", "rover", "sagem", "sama", "samu", "sanyo", "samsung", "sch-", "scooter", "sec-", "sendo", "sgh-", "sharp", "siemens", "sie-", "softbank", "sony", "spice", "sprint", "spv", "symbian", "tablet", "talkabout", "tcl-", "teleca", "telit", "tianyu", "tim-", "toshiba", "tsm", "up.browser", "utec", "utstar", "verykool", "virgin", "vk-", "voda", "voxtel", "vx", "wap", "wellco", "wig browser", "wii", "windows ce", "wireless", "xda", "xde", "zte");
		$is_mobile = false;
		foreach ($mobile_agents as $device) {
			if (stristr($user_agent, $device)) {
				$is_mobile = true;
				break;
			}
		}
		return $is_mobile;
	}

	/**
	 * ���ٻ�ȡԶ��ͼƬ�Ŀ���
	 * @param string $url Զ��ͼƬ������
	 * @return false|array
	 */
	public static function getImageSize($url)
	{
		$ch = curl_init($url);
		// ��ʱ����
		curl_setopt($ch, CURLOPT_TIMEOUT, 5);
		// ����301��ת
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		// ���ؽ��
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$data_size = 128;
		for($i = 0; $i < 6; $i++) {
			// ��ȡ0��$data_size��Χ������
			curl_setopt($ch, CURLOPT_RANGE, "0-$data_size");
			$dataBlock = curl_exec($ch);
			if(!$dataBlock) {
				self::$errCode = 101;
				self::$errMsg = "��ȡͼƬ $url ʧ��";
				return false;
			}
	
			$size = getimagesize('data://image/jpeg;base64,'. base64_encode($dataBlock));
			
		    if (!empty($size)) {
		        break;
		    }
		    
		    // ������Ϊ$data_size̫Сû�л�ȡ��������Ϣ���Ӵ�$data_size����
			$data_size *= 4;
		}
	
		curl_close($ch);
	
		if (empty($size)) {
			self::$errCode = 102;
			self::$errMsg = "��ȡͼƬ $url ����ʧ��";
			return false;
		}

	    $result['width'] = $size[0];
	    $result['height'] = $size[1];

	    return $result;
	}

	/**
	 * ��ȡ��ID
	 * @param string $cookie COOKIE �еĵ�����Ϣ
	 * @return int
	 */
	public static function getCommonPrid($cookie) {
		$prid_provinceid = explode('_', $cookie); //��ַcookies: '$prid_$provinceid'
		$prid = $prid_provinceid[0]; //��id

		return $prid;
	}

    /**
     *  iphone �汾�űȽ�
     * @param $version1
     * @param $version2
     * @return int
     */
    public static function iphone_version_cmp($version1, $version2) {
        $version_fields1 = explode('.', $version1);
        $version_fields2 = explode('.', $version2);
        $len1 = count($version_fields1);
        $len2 = count($version_fields2);
        $index = 0;
        $len = min($len1 , $len2);
        for (; $index < $len; $index++ ) {
            $sub_ver1 =	$version_fields1[$index];
            $sub_ver2 = $version_fields2[$index];
            if ( $sub_ver1 < $sub_ver2 ) {
                return -1;
            } else if( $sub_ver1 > $sub_ver2 ) {
                return 1;
            } else {
                continue;
            }
        }

        if ($len1 < $len2 )return -1;
        else return 1;
    }

}

//End of script
