<?php
// vim: set expandtab tabstop=4 shiftwidth=4 fdm=marker:
// +----------------------------------------------------------------------+
// | Tencent PHP Library.                                                 |
// +----------------------------------------------------------------------+
// | Copyright (c) 2006-2008 Tencent Inc. All Rights Reserved.            |
// +----------------------------------------------------------------------+
// | Authors: The Club Dev Team, ISRD, Tencent Inc.                       |
// |          fishchen <fishchen@tencent.com>                             |
// +----------------------------------------------------------------------+
// $Id$

/**
 * @version $Revision$
 * @author  $Author$
 * @date    $Date$
 * @brief   TPHPLIB functions.
 */


define( "TPHP_TTC_OP_SVRADMIN",         3 );
define( "TPHP_TTC_OP_GET",              4 );
define( "TPHP_TTC_OP_SELECT",           4 );
define( "TPHP_TTC_OP_PURGE",            5 );
define( "TPHP_TTC_OP_INSERT",           6 );
define( "TPHP_TTC_OP_UPDATE",           7 );
define( "TPHP_TTC_OP_DELETE",           8 );
define( "TPHP_TTC_OP_REPLACE",          12 );
define( "TPHP_TTC_OP_FLUSH",            13 );
define( "TPHP_TTC_OP_INVALIDATE",       14 );

define( 'TPHP_TTC_KEYTYPE_NONE',        0 );	// undefined
define( 'TPHP_TTC_KEYTYPE_INT',         1 );	// Signed Integer
define( 'TPHP_TTC_KEYTYPE_STRING',      4 );	// String, case insensitive, null ended

define( 'TPHP_TTC_FIELDTYPE_NONE',      0 );    // undefined
define( 'TPHP_TTC_FIELDTYPE_SIGNED',    1 );	// Signed Integer
define( 'TPHP_TTC_FIELDTYPE_UNSIGNED',  2 );	// Unsigned Integer
define( 'TPHP_TTC_FIELDTYPE_FLOAT',     3 );	// float
define( 'TPHP_TTC_FIELDTYPE_STRING',    4 );	// String, case insensitive, null ended
define( 'TPHP_TTC_FIELDTYPE_BINARY',    5 );	// binary


if ( !extension_loaded('tphp_ttc') ) {
    if ( !ini_get("safe_mode") && ini_get("enable_dl") ) {
        if ( !@dl("tphp_ttc.so") ) {
            $suffix  = ".".TPHP_LIB_VERSTR;
            $suffix .= ".libc-".tphp_get_libcver();
            if ( !dl("tphp_ttc.so".$suffix) ) exit(0);
        } // if
    } else {
        exit(0);
    } // if
} // if


?>
