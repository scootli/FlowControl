<?php
//flush when process exit
register_shutdown_function(array('EL_Flow', 'flushAllInstances'));

/**
 * ��ˮ��¼��
 *
 * eg.
 * $flow = new EL_Flow('test');
 * $flow->append('this is flow string', true);
 *
 * @author bennylin@tencent.com
 */
class EL_Flow
{
	private $_flow_name;
	private $_date_format;
	private $_dir;
	private $_sess_uid; //session user id
	private $_records = array();

	/**
	 * @var EL_Flow
	 */
	private static $_instances = array();

	/**
	 * init flow class
	 * default save to LOG_DIR
	 *
	 * @param string $flow_name log file name
	 * @param string $date_format the log file's date string
	 * @param string $dir 		the log save to dir
	 *
	 * @return void
	 */
	public function __construct($flow_name, $date_format = 'Ymd', $dir = LOG_ROOT)
	{
		$this->_flow_name = $flow_name;
		$this->_date_format = $date_format;
		$this->_dir = $dir;

		//session user id
		//$this->_sess_uid = !empty($_COOKIE['skey']) && class_exists('IUser') ? IUser::getLoginUid() : 0;
		$this->_sess_uid = empty($_COOKIE['uid']) ? 0 : intval($_COOKIE['uid']);
		//for admin
		if (!$this->_sess_uid && !empty($_COOKIE['CurrentUserID']) )
		{
			$this->_sess_uid = intval($_COOKIE['CurrentUserID']) . '|' . trim($_COOKIE['username']);
		}
	}

	/**
	 * ��ȡ����ĵ���ʵ��
	 *
	 * @param string $flow_name log file name
	 * @param string $date_format the log file's date string	���Ե�һ�λ�ȡ��ʵ��Ϊ׼
	 * @param string $dir 		the log save to dir		���Ե�һ�λ�ȡ��ʵ��Ϊ׼
	 *
	 * @return EL_Flow
	 */
	public static function getInstance($flow_name, $date_format = 'Ymd', $dir = LOG_ROOT)
	{
		if (!isset(self::$_instances[$flow_name] ) )
		{
			self::$_instances[$flow_name] = new EL_Flow($flow_name, $date_format, $dir);
		}

		return self::$_instances[$flow_name];
	}

	/**
	 * ������ʵ������ˮˢ���ļ�
	 *
	 * @return void
	 */
	public static function flushAllInstances()
	{
		foreach (self::$_instances as $ins)
		{
			$ins->flush();
		}
	}

	/**
	 * append flow
	 *
	 * @param string $content  log content,"\r" will be remove,"\n" will be replace to space " "
	 * @param mix $backtrace    true/false/0,1,2... is backtrace? backtrace all on true,no on false,backstrace level n on 0/1/2/3...
	 *
	 * @return void
	 */
	public function append($content, $backtrace = true)
	{
		//get backtrace info
		$trace = '-';
		if ($backtrace !== false)
		{
			$trace_items = debug_backtrace();

			//trace all
			if ($backtrace === true)
			{
				$list = array();
				$count = count($trace_items);
				for ($i = $count - 1; $i >= 0; $i--)
				{
					$item = $trace_items[$i];
					if(!isset($item['file'])) {
						continue;
					}
					$list[] = str_replace('/data/release/', '', $item['file']) . ':' . $item['line'];
				}

				$trace = implode(';', $list);
			}
			elseif (isset($backtrace)) //trace by level
			{
				$trace = str_replace('/data/release/', '', $trace_items[$backtrace]['file']) . ':' . $trace_items[$backtrace]['line'];
			}
		}


		$content = str_replace("\r", '', $content);
		$content = str_replace("\n", ' ', $content);
		$referer = empty($_SERVER['HTTP_REFERER']) ? '-' : str_replace('http://', '', $_SERVER['HTTP_REFERER']);
		$this->_records[] = date('Y-m-d H:i:s') . "\t{$this->_sess_uid}\t{$content}\t{$referer}\t{$trace}";

		//flush to file when records over 30
		if (count($this->_records) > 30)
		{
			$this->flush();
		}
	}

	/**
	 * flush to file
	 *
	 * @return void
	 */
	public function flush()
	{
		if (empty($this->_records) )
		{
			return true;
		}

		$flow_dir = "{$this->_dir}/{$this->_flow_name}";

		umask(0);

		//check and create dir
		if (!is_dir($flow_dir) )
		{
			if (!is_writeable($this->_dir) )
			{
				trigger_error('log dir (' . $this->_dir . ') unwriteable');
				return ;
			}

			mkdir($flow_dir, 0777);
		}

		//records to string
		$contents = implode("\n", $this->_records);

		//clear
		$this->_records = array();

		//make date string
		$date = 'flow';
		if ($this->_date_format)
		{
			$date = date($this->_date_format);
		}

		$file_path = "{$flow_dir}/{$date}";

		//save to file
		$ret = file_put_contents($file_path, $contents . "\n", FILE_APPEND | LOCK_EX);

		//rename when size is too big
		if (filesize($file_path) > 1000000000) //less than 1G
		{
			rename($file_path, $file_path . '.' . date('mdHis'));
		}

		return $ret;
	}

	public function __destruct()
	{
		$this->flush();
	}
}

