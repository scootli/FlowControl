<?php
if ( !defined('TPHP_TTC_OP_GET') ) {
	define( "TPHP_TTC_OP_GET", 4 );
}

if ( !defined('TPHP_TTC_OP_SELECT') ) {
	define( "TPHP_TTC_OP_SELECT", 4 );
}

define( "TPHP_TTC_OP_PURGE",    5 );
define( "TPHP_TTC_OP_INSERT",   6 );
define( "TPHP_TTC_OP_UPDATE",   7 );
define( "TPHP_TTC_OP_DELETE",   8 );
define( "TPHP_TTC_OP_REPLACE",  9 );
define( "TPHP_TTC_OP_FLUSH",    13 );



/**
 * ��װTTC��һЩAPI
 * @author ericfu
 * @version 1.0
 * @updated 06-ʮһ��-2008 18:16:40
 */
class TTC
{
	const INT = 1;
	const STRING = 2;
	const BINARY = 3;
	const FLOAT = 4;

	/**
	 * ���ñ�ʶ
	 * �����ϱ��Ȳ���
	 * @var string
	 */
	public $configId;

	/**
	 * ������
	 * @var int
	 */
	public $errCode;
	/**
	 * ������Ϣ
	 * @var string
	 */
	public $errMsg;

	/**
	 * TTC������
	 * @var int
	 */
	public $ttcCode;

	/**
	 * ttc�����ã�����ͨ�����������֤�����ݵĺϷ��Եȵ�
	 * @var array
	 */
	private $config;

	private $key_type;

	/**
	 * ttc��������
	 * @var tphp_ttc_server
	 */
	private $server = false;
	private $ttcKey = false;
	private $result = null;

	/**
	 * ttc key ͨ�����key����ȡ��������Ϣ
	 *
	 * @param string ttcKey
	 */
	function __construct($config)
	{
		$this->ttcKey = $config['TTCKEY'];
		$this->config = $config;
	}

	function __destruct()
	{
		if ($this->server != false) {
			$this->server->close();
		}
	}

	/**
	 * ��ʼ��ttc������,���ֻ��������������ʱ��Ż�ȥ��
	 *
	 * @return boolean
	 */
	private function init()
	{
		$this->clearERR();

		//for report
		EL_ModuleState::start("ttc.{$this->configId}", 'ttc.init');

		if (!extension_loaded('tphp_ttc') ) {
			if (!ini_get("safe_mode") && ini_get("enable_dl") ) {
				if ( !dl("tphp_ttc.so") ) {
					$this->errCode = 20000;
					$this->errMsg  = 'can not load tphp_ttc extension module';

					//report
					$this->reportModuleState('init', EL_ModuleState::FAILED_OTHER);

					return false;
				}
			} else {
				$this->errCode = 20000;
				$this->errMsg  = 'can not load tphp_ttc extension module';

				//report
				$this->reportModuleState('init', EL_ModuleState::FAILED_OTHER);

				return false;
			}
		}

		if ($this->server == false) {
			$this->server = new tphp_ttc_server();
			$errCode = $this->server->set_timeout($this->config['TimeOut']);
			if ($errCode != 0) {
				$this->errCode = $errCode;
				$this->errMsg  = $this->server->error_message();
				$this->server->close();

				//report
				$this->reportModuleState('init', EL_ModuleState::FAILED_OTHER);

				return false;
			}

			$errCode = $this->server->set_tablename($this->config['TABLE']);
			if ($errCode != 0) {
				$this->errCode = $errCode;
				$this->errMsg  = $this->server->error_message();
				$this->server->close();

				//report
				$this->reportModuleState('init', EL_ModuleState::FAILED_OTHER);

				return false;
			}

			$errCode = $this->server->set_address($this->config['IP']);
			if ($errCode != 0) {
				$this->errCode = $errCode;
				$this->errMsg  = $this->server->error_message();
				$this->server->close();

				//report
				$this->reportModuleState('init', EL_ModuleState::FAILED_OTHER);

				return false;
			}

			// �˴�������ַ���key��֧��
			$this->key_type = $this->config['FIELDS'][$this->config['KEY']]['type'];
			if ( $this->key_type == 1 ) {
				$errCode = $this->server->int_key();
			}
			elseif ( $this->key_type == 2 ) {
				$errCode = $this->server->string_key();
			}
			else  {
				$this->errCode = 20005;
				$this->errMsg  = 'invalid key type';
				$this->server->close();

				//report
				$this->reportModuleState('init', EL_ModuleState::FAILED_OTHER);

				return false;
			}

			if ($errCode != 0) {
				$this->errCode = $errCode;
				$this->errMsg  = $this->server->error_message();
				$this->server->close();

				//report
				$this->reportModuleState('init', EL_ModuleState::FAILED_OTHER);

				return false;
			}
		}

		//report
		$this->reportModuleState('init', EL_ModuleState::SUCCESS);

		return true;
	}

	/**
	 * ��������
	 *
	 * @param mix $key ��һ��key
	 * @param array $multikey ������������
	 *
	 * @return boolean
	 */
	public function purge($key, array $multikey = array())
	{
		$this->clearERR();

		if (($this->server == false) && ($this->init() == false)) {
			return false;
		}

		//for report
		EL_ModuleState::start("ttc.{$this->configId}", 'ttc.purge');

		if ($this->checkKey($key) == false) {
			//report
			$this->reportModuleState('purge', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		$req = new tphp_ttc_request($this->server, TPHP_TTC_OP_PURGE);
		if ( $this->key_type == 1 ) {
			$errCode = $req->set_key($key);
		} elseif ( $this->key_type == 2 ) {
			$errCode = $req->set_key_str($key);
		} else {
			$this->errCode = 20018;
			$this->errMsg  = 'request failed';

			//report
			$this->reportModuleState('purge', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		if($errCode != 0){
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} purge:{$key}: set_key error";

			//report
			$this->reportModuleState('purge', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		if ( !empty($multikey) && is_array($multikey) ) {
			// �������ֶ�key���
			foreach ( $multikey as $mk => $mv ) {
				$chk = $this->checkMultikey($mk, $mv);
				if ( !$chk ) {
					//report
					$this->reportModuleState('purge', EL_ModuleState::FAILED_OTHER);

					return $chk;
				}
				$eq = $this->eqv($req, $mk, $mv);
				if ( $eq != 0 ) {
					$this->errCode = 20093;
					$this->errMsg  = "ttc config:{$this->ttcKey} purge:{$key}: set multikey error";

					//report
					$this->reportModuleState('purge', EL_ModuleState::FAILED_OTHER);

					return false;
				}
			}
		}

		$result = new tphp_ttc_result();
		$ret = $req->execute($result);
		$this->result = $result;

		//TODO ...
		$errCode = $result->result_code();
		if ($errCode != 0) {
			$this->ttcCode = $errCode;
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} purge:{$key} error,error code:{$errCode}";

			//report
			$this->reportModuleState('purge', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		//report
		$this->reportModuleState('purge', EL_ModuleState::SUCCESS);

		return true;
	}

	/**
	 * ɾ��һ�����ݿ��¼
	 *
	 * @param key    ���ݿ������
	 */
	public function delete($key, $multikey = array())
	{
		$this->clearERR();
		if (($this->server == false) && ($this->init() == false)) {
			return false;
		}

		//for report
		EL_ModuleState::start("ttc.{$this->configId}", 'ttc.delete');

		if ($this->checkKey($key) == false) {
			//report
			$this->reportModuleState('delete', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		$req = new tphp_ttc_request($this->server, TPHP_TTC_OP_DELETE);
		if ( $this->key_type == 1 ) {
			$errCode = $req->set_key($key);
		} elseif ( $this->key_type == 2 ) {
			$errCode = $req->set_key_str($key);
		} else {
			$this->errCode = 20019;
			$this->errMsg  = 'request failed';

			//report
			$this->reportModuleState('delete', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		if($errCode != 0){
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} delete:{$key}: set_key error";

			//report
			$this->reportModuleState('delete', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		if ( !empty($multikey) && is_array($multikey) ) {
			// �������ֶ�key���
			foreach ( $multikey as $mk => $mv ) {
				$chk = $this->checkMultikey($mk, $mv);
				if ( !$chk ) {
					//report
					$this->reportModuleState('delete', EL_ModuleState::FAILED_OTHER);

					return $chk;
				}
				$eq = $this->eqv($req, $mk, $mv);
				if ( $eq != 0 ) {
					$this->errCode = 20013;
					$this->errMsg  = "ttc config:{$this->ttcKey} delete:{$key}: set multikey error";

					//report
					$this->reportModuleState('delete', EL_ModuleState::FAILED_OTHER);

					return false;
				}
			}
		}

		$result = new tphp_ttc_result();
		$ret = $req->execute($result);
		$this->result = $result;

		//TODO ...
		$errCode = $result->result_code();
		if ($errCode != 0) {
			$this->ttcWriteLog("result:TTC_delete_failed,ttc:{$this->ttcKey},key:{$key}");
			$this->ttcCode = $errCode;
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} delete:{$key} error,error code:{$errCode}";

			//report
			$this->reportModuleState('delete', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		//report
		$this->reportModuleState('delete', EL_ModuleState::SUCCESS);

		$this->ttcWriteLog("result:TTC_delete_success,ttc:{$this->ttcKey},key:{$key},effect:" . $this->getAffectRows());
		return true;
	}

	public function getAffectRows()
	{
		if ( !empty( $this->result ) )
		{
			return $this->result->affected_rows();
		}
		else
		{
			return -1;
		}
	}

	public function ttcWriteLog($str)
	{
		$black_list = array(
			'IPageCacheTTC',
			'IDiyCacheTTC',
			//'IProductCommonInfoTTC',
			'IProductDetailTTC',
			'IProductInstallMentBookTTC',
			//'IProductRelativityTTC',
			'IProductReviewStatisticsTTC',
			'IProductServiceTTC',
		);


		// ����ں�������򷵻�
		if (in_array($this->ttcKey, $black_list)) {
			return;
		}


		EL_Flow::getInstance($this->ttcKey)->append($str);
	}

	/**
	 * ���TTC��¼
	 *
	 * @param   string  $key, ���ݿ������
	 * @param   array   $multikey, ��ѡ����, ���ֶ�keyʱ��ѡ, ����array('field2' => 1, 'field3' => 2)
	 * @param   array    $need, ��ѡ����, Ĭ�Ϸ��������У�Ҳ����ָ����Ҫ���ص���
	 * @param   int    $start, ��ѡ����, Ĭ�ϴӵ�һ�����������ļ�¼��ʼ���أ�Ҳ��ָ�����ؼ�¼����ʼƫ����
	 * * @param   int    $need, ��ѡ����, Ĭ�Ϸ������з��������ļ�¼��Ҳ��ָ����Ҫ������
	 */
	public function get($key, $multikey = array(), $need = array(), $itemLimit = 0, $start = 0)
	{
		$this->clearERR();
		if (($this->server == false) && ($this->init() == false)) {
			return false;
		}

		//for report
		EL_ModuleState::start("ttc.{$this->configId}", 'ttc.select');

		if ($this->checkKey($key) == false) {
			return false;
		}
		$req = new tphp_ttc_request($this->server, TPHP_TTC_OP_GET);
		if ( $this->key_type == 1 ) {
			$errCode = $req->set_key($key);
		} elseif ( $this->key_type == 2 ) {
			$errCode = $req->set_key_str($key);
		} else {
			$this->errCode = 20020;
			$this->errMsg  = 'request failed';

			//report
			$this->reportModuleState('select', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		if($errCode != 0){
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} get:{$key}: set_key error";

			//report
			$this->reportModuleState('select', EL_ModuleState::FAILED_OTHER);

			return false;
		}
		if ( !empty($multikey) && is_array($multikey) ) {
			// �������ֶ�key���
			foreach ( $multikey as $mk => $mv ) {
				$chk = $this->checkMultikey($mk, $mv);
				if ( !$chk ) {
					return $chk;
				}
				$eq = $this->eqv($req, $mk, $mv);
				if ( $eq != 0 ) {
					$this->errCode = 20028;
					$this->errMsg  = "ttc config:{$this->ttcKey} get:{$key}: set multikey error";

					//report
					$this->reportModuleState('select', EL_ModuleState::FAILED_OTHER);

					return false;
				}
			}
		}
		$fields = $this->config['FIELDS'];
		$keyfield   = $this->config['KEY'];

		if (empty($need)) {

			foreach ($fields as $k => $v){
				if ($keyfield == $k){
					continue;
				}
				$errCode = $req->need($k);
				if($errCode != 0){
					$this->errCode = $errCode;
					$this->errMsg  = "ttc config:{$this->ttcKey} need({$k}) error,error code:{$errCode}";

					//report
					$this->reportModuleState('select', EL_ModuleState::FAILED_OTHER);

					return false;
				}
			}
		}
		else
		{
			foreach ($need as $k) {
				if ($keyfield == $k){
					continue;
				}
				$errCode = $req->need($k);
				if($errCode != 0){
					$this->errCode = $errCode;
					$this->errMsg  = "ttc config:{$this->ttcKey} need({$k}) error,error code:{$errCode}";

					//report
					$this->reportModuleState('select', EL_ModuleState::FAILED_OTHER);

					return false;
				}
			}
		}
		if (0 != $itemLimit) {
			$errCode = $req->limit($start, $itemLimit);
			if ($errCode != 0) {
				$this->ttcCode = $errCode;
				$this->errCode = $errCode;
				$this->errMsg  = "ttc config:{$this->ttcKey} get:{$key} error,error code:{$errCode}";
				return false;
			}

		}
		$result = new tphp_ttc_result();
		$req->execute($result);
		$this->result = $result;
		$errCode = $result->result_code();
		if ($errCode != 0) {
			$this->ttcCode = $errCode;
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} get:{$key} error,error code:{$errCode}";

			//report
			$this->reportModuleState('select', EL_ModuleState::FAILED_OTHER);

			return false;
		}
		$rowCount = $result->num_rows();
		$multiRows = array();
		for ($i = 0 ; $i < $rowCount; ++$i)
		{
			$ret = $result->fetch_row();
			if ($ret < 0)
			{
				$this->errCode = 20026;
				$this->errMsg  = "ttc config:{$this->ttcKey} get:{$key} error,fetch_row error";
				return false;
			}
			$rData = array();
			if (empty($need)) {
				foreach ($fields as $k => $v){
					if ($k == $keyfield) {
						continue;
					}
					switch ($v['type']){
						case TTC::INT :
							$rData[$k] = $result->int_value($k);
							break;
						case TTC::STRING :
							$rData[$k] = $result->string_value($k);
							break;
						case TTC::BINARY :
							$rData[$k] = $result->binary_value($k);
							break;
						case TTC::FLOAT  :
							$rData[$k] = $result->float_value($k);
							break;
						default:
							$this->errCode = 20027;
							$this->errMsg  = "ttc config:{$this->ttcKey} field:{$k} data type:{$v['type']} error";

							//report
							$this->reportModuleState('select', EL_ModuleState::FAILED_OTHER);

							return false;
					}
				}
				$rData[$keyfield] = $key;
				$multiRows[] = $rData;
			}
			else
			{
				foreach ($need as $k){
					if ($k == $keyfield) {
						continue;
					}
					switch ($fields[$k]['type']){
						case TTC::INT :
							$rData[$k] = $result->int_value($k);
							break;
						case TTC::STRING :
							$rData[$k] = $result->string_value($k);
							break;
						case TTC::BINARY :
							$rData[$k] = $result->binary_value($k);
							break;
						case TTC::FLOAT  :
							$rData[$k] = $result->float_value($k);
							break;
						default:
							$this->errCode = 20027;
							$this->errMsg  = "ttc config:{$this->ttcKey} field:{$k} data type:{$v['type']} error";

							//report
							$this->reportModuleState('select', EL_ModuleState::FAILED_OTHER);

							return false;
					}
				}
				$rData[$keyfield] = $key;
				$multiRows[] = $rData;
			}
		}

		//report
		$this->reportModuleState('select', EL_ModuleState::SUCCESS);

		return $multiRows;
	}

	/**
	 * ����һ�����ݿ��¼
	 *
	 * @param $data    ����
	 */
	public function update($data, $multikey = array())
	{
		$this->clearERR();
		if (($this->server == false) && ($this->init() == false)) {
			return false;
		}

		//for report
		EL_ModuleState::start("ttc.{$this->configId}", 'ttc.update');

		$key = $this->config['KEY'];
		if (!isset($data[$key])) {
			$this->errCode = 20031;
			$this->errMsg  = "ttc config:{$this->ttcKey} update key not set";

			//report
			$this->reportModuleState('update', EL_ModuleState::FAILED_OTHER);

			return false;
		}
		if (($this->check($data) == false)) {
			//report
			$this->reportModuleState('update', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		$fields = $this->config['FIELDS'];
		$req = new tphp_ttc_request($this->server, TPHP_TTC_OP_UPDATE);
		if ( $this->key_type == 1 ) {
			$errCode = $req->set_key($data[$key]);
		} elseif ( $this->key_type == 2 ) {
			$errCode = $req->set_key_str($data[$key]);
		} else {
			$this->errCode = 20020;
			$this->errMsg  = 'request failed';

			//report
			$this->reportModuleState('update', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		if($errCode != 0){
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} update:{$key}: set_key error";

			//report
			$this->reportModuleState('update', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		if ( !empty($multikey) && is_array($multikey) ) {
			// �������ֶ�key���
			foreach ( $multikey as $mk => $mv ) {
				$chk = $this->checkMultikey($mk, $mv);
				if ( !$chk ) {
					return $chk;
				}
				$eq = $this->eqv($req, $mk, $mv);
				if ( $eq != 0 ) {
					$this->errCode = 20036;
					$this->errMsg  = "ttc config:{$this->ttcKey} update:{$key}: set multikey error";

					//report
					$this->reportModuleState('update', EL_ModuleState::FAILED_OTHER);

					return false;
				}
			}
		}
		foreach ($data as $k => $v){
			if ($k == $key or (is_array($multikey) and array_key_exists($k, $multikey))) {
				continue;
			}
			if ( !isset($fields[$k]) ) {
				continue;
			}
			$tmpConfig = $fields[$k];
			switch($tmpConfig['type']){
				case TTC::INT:
					$data[$k] = $data[$k] + 0; // ȷ��������ȷ,����ttc��չ��warnning
					$req->set($k, $data[$k]);
					break;
				case TTC::STRING:
					$data[$k] = $data[$k] . ''; // ȷ��������ȷ,����ttc��չ��warnning
					$req->set_str($k, $data[$k]);
					break;
				case TTC::BINARY:
					$data[$k] = $data[$k] . ''; // ȷ��������ȷ,����ttc��չ��warnning
					$req->set_bin($k, $data[$k]);
					break;
				case TTC::FLOAT :
					$data[$k] = $data[$k] . ''; // ȷ��������ȷ,����ttc��չ��warnning
					$req->set_flo($k, $data[$k]);
					break;
				default:
					$this->errCode = 20033;
					$this->errMsg  = "ttc config:{$this->ttcKey} field:{$k} data type:{$v['type']} error";

					//report
					$this->reportModuleState('update', EL_ModuleState::FAILED_OTHER);

					return false;
			}
		}

		$result = new tphp_ttc_result();
		$req->execute($result);
		$this->result = $result;
		$errCode = $result->result_code();
		if ($errCode != 0) {
			//write flow
			//EL_Flow::getInstance('sql_write_flow')->append("result:TTC_update_failed,ttc:{$this->ttcKey},data:".serialize($data));
			$this->ttcWriteLog("result:TTC_update_failed,ttc:{$this->ttcKey},data:".serialize($data));
			$this->ttcCode = $errCode;
			$this->errCode = 20034;
			$this->errMsg  = "ttc config:{$this->ttcKey} update:{$data[$key]} error,error code:{$errCode}";

			//report
			$this->reportModuleState('update', EL_ModuleState::FAILED_OTHER);


			return false;
		}

		//write flow
		//EL_Flow::getInstance('sql_write_flow')->append("result:TTC_update_success,ttc:{$this->ttcKey},data:" . serialize($data) . ',effect:' . $this->getAffectRows());
		$this->ttcWriteLog("result:TTC_update_success,ttc:{$this->ttcKey},data:" . serialize($data) . ',effect:' . $this->getAffectRows());

		//report
		$this->reportModuleState('update', EL_ModuleState::SUCCESS);

		return true;
	}

	/**
	 * ����һ�����ݿ��¼
	 *
	 * @param data    ��Ҫinsert ������
	 */
	public function insert($data)
	{
		$this->clearERR();
		if (($this->server == false) && ($this->init() == false)) {
			return false;
		}

		//for report
		EL_ModuleState::start("ttc.{$this->configId}", 'ttc.insert');

		if ($this->check($data) == false) {
			//report
			$this->reportModuleState('insert', EL_ModuleState::FAILED_OTHER);
			return false;
		}

		$key = $this->config['KEY'];
		$fields = $this->config['FIELDS'];
		$keyConfig = $fields[$key];
		if (!isset($data[$key]) && $keyConfig['auto'] == false) {
			$this->errCode = 20041;
			$this->errMsg  = "ttc config:{$this->ttcKey} insert key not set";

			//report
			$this->reportModuleState('insert', EL_ModuleState::FAILED_OTHER);
			return false;
		}

		$req = new tphp_ttc_request($this->server, TPHP_TTC_OP_INSERT);
		if (isset($data[$key])) {
			if ( $this->key_type == 1 ) {
				$errCode = $req->set_key($data[$key]);
			} elseif ( $this->key_type == 2 ) {
				$errCode = $req->set_key_str($data[$key]);
			} else {
				$this->errCode = 200106;
				$this->errMsg  = 'request failed';

				//report
				$this->reportModuleState('insert', EL_ModuleState::FAILED_OTHER);

				return false;
			}

			if($errCode != 0){
				$this->errCode = $errCode;
				$this->errMsg  = "ttc config:{$this->ttcKey} insert:{$key}: set_key error";

				//report
				$this->reportModuleState('insert', EL_ModuleState::FAILED_OTHER);
				return false;
			}
		}

		foreach ($data as $k => $v){
			if ($k == $key) {
				continue;
			}
			if ( !isset($fields[$k]) ) {
				continue;
			}
			$tmpConfig = $fields[$k];
			switch($tmpConfig['type']){
				case TTC::INT:
					$data[$k] = $data[$k] + 0; // ȷ��������ȷ,����ttc��չ��warnning
					$req->set($k, $data[$k]);
					break;
				case TTC::STRING:
					$data[$k] = $data[$k] . ''; // ȷ��������ȷ,����ttc��չ��warnning
					$req->set_str($k, $data[$k]);
					break;
				case TTC::BINARY:
					$data[$k] = $data[$k] . ''; // ȷ��������ȷ,����ttc��չ��warnning
					$req->set_bin($k, $data[$k]);
					break;
				case TTC::FLOAT :
					$data[$k] = $data[$k] . ''; // ȷ��������ȷ,����ttc��չ��warnning
					$req->set_flo($k, $data[$k]);
					break;
				default:
					$this->errCode = 20043;
					$this->errMsg  = "ttc config:{$this->ttcKey} field:{$k} data type:{$v['type']} error";

					//report
					$this->reportModuleState('insert', EL_ModuleState::FAILED_OTHER);

					return false;
			}
		}

		$result = new tphp_ttc_result();
		$req->execute($result);
		$this->result = $result;
		//TODO...
		$errCode = $result->result_code();
		if ($errCode != 0) {
			$this->ttcWriteLog("result:TTC_insert_failed,ttc:{$this->ttcKey},data:" . serialize($data));
			$this->ttcCode = $errCode;
			$this->errCode = $errCode;
			$k_val = isset($data[$key]) ? $data[$key] : '[auto_increment]';
			$this->errMsg  = "ttc config:{$this->ttcKey} insert:{$k_val} error,code:{$errCode}";

			//report
			$this->reportModuleState('insert', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		//report
		$this->reportModuleState('insert', EL_ModuleState::SUCCESS);

		// ��Ϊ������key������insert_id
		if ( !isset($data[$key]) && $keyConfig['auto'] ) {
			$autoinc_id = $result->int_key();
			$this->ttcWriteLog("result:TTC_insert_success,ttc:{$this->ttcKey},data:" . serialize($data) . ',autoIncId:' . $autoinc_id);

			return $autoinc_id;
		}

		$this->ttcWriteLog("result:TTC_insert_success,ttc:{$this->ttcKey},data:" . serialize($data));

		return true;
	}

	/**
	 * �����ֶ�����
	 *
	 * @param   array   $key_arr, key����
	 * @param   string  $fld, �ֶ���,����Ϊ�����ֶ�
	 * @param   int     $val, ����ֵ
	 * @return  boolean
	 */
	public function increment($key_arr, $fld, $val = 1)
	{
		$this->clearERR();
		if (($this->server == false) && ($this->init() == false)) {
			return false;
		}

		//for report
		EL_ModuleState::start("ttc.{$this->configId}", 'ttc.increment');

		$key = $this->config['KEY'];
		if (!isset($key_arr[$key])) {
			$this->errCode = 20071;
			$this->errMsg  = "ttc config:{$this->ttcKey} increment key not set";

			//report
			$this->reportModuleState('increment', EL_ModuleState::FAILED_OTHER);

			return false;
		}
		$fields = $this->config['FIELDS'];
		if ( !array_key_exists($fld, $fields) ) {
			$this->errCode = 20072;
			$this->errMsg  = "ttc config:{$this->ttcKey} increment no field name $fld";

			//report
			$this->reportModuleState('increment', EL_ModuleState::FAILED_OTHER);

			return false;
		}
		$val = intval($val);
		if ( $val < 1 ) {
			$this->errCode = 20073;
			$this->errMsg  = "ttc config:{$this->ttcKey} invalid increment value";

			//report
			$this->reportModuleState('increment', EL_ModuleState::FAILED_OTHER);

			return false;
		}
		$req = new tphp_ttc_request($this->server, TPHP_TTC_OP_UPDATE);
		if ( $this->key_type == 1 ) {
			$errCode = $req->set_key($key_arr[$key]);
		} elseif ( $this->key_type == 2 ) {
			$errCode = $req->set_key_str($key_arr[$key]);
		} else {
			$this->errCode = 200110;
			$this->errMsg  = 'request failed';

			//report
			$this->reportModuleState('increment', EL_ModuleState::FAILED_OTHER);

			return false;
		}
		if($errCode != 0){
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} increment:{$key}: set_key error";
			return false;
		}
		if ( count($key_arr) > 1 ) {
			// �������ֶ�key���
			foreach ( $key_arr as $mk => $mv ) {
				if ($mk == $key) {
					continue;
				}
				$chk = $this->checkMultikey($mk, $mv);
				if ( !$chk ) {
					return $chk;
				}
				$eq = $this->eqv($req, $mk, $mv);
				if ( $eq != 0 ) {
					$this->errCode = 20075;
					$this->errMsg  = "ttc config:{$this->ttcKey} increment:{$key}: set multikey error";

					//report
					$this->reportModuleState('increment', EL_ModuleState::FAILED_OTHER);

					return false;
				}
			}
		}

		$add = $req->add($fld, $val);
		if ( $add != 0 ) {
			$this->errCode = 20076;
			$this->errMsg  = "ttc config:{$this->ttcKey} increment:{$key}: add error";

			//report
			$this->reportModuleState('increment', EL_ModuleState::FAILED_OTHER, $add);

			return false;
		}

		$result = new tphp_ttc_result();
		$req->execute($result);
		$this->result = $result;
		$errCode = $result->result_code();
		if ($errCode != 0) {
			//EL_Flow::getInstance('sql_write_flow')->append("result:TTC_increment_failed,ttc:{$this->ttcKey},data:".serialize($key_arr));
			$this->ttcWriteLog("result:TTC_increment_failed,ttc:{$this->ttcKey},data:".serialize($key_arr));
			$this->ttcCode = $errCode;
			$this->errCode = 20077;
			$this->errMsg  = "ttc config:{$this->ttcKey} increment:{$key} error,error code:{$errCode}";

			//report
			$this->reportModuleState('increment', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		//report
		$this->reportModuleState('increment', EL_ModuleState::SUCCESS);

		//EL_Flow::getInstance('sql_write_flow')->append("result:TTC_increment_success,ttc:{$this->ttcKey},data:" . serialize($key_arr) . ',effect:' . $this->getAffectRows());
		$this->ttcWriteLog("result:TTC_increment_success,ttc:{$this->ttcKey},data:" . serialize($key_arr) . ',effect:' . $this->getAffectRows());

		return true;
	}

	/**
	 * �����ֶ��Լ�
	 *
	 * @param   array   $key_arr, key����
	 * @param   string  $fld, �ֶ���,����Ϊ�����ֶ�
	 * @param   int     $val, �Լ�ֵ
	 * @return  boolean
	 */
	public function decrement($key_arr, $fld, $val = 1)
	{
		$this->clearERR();
		if (($this->server == false) && ($this->init() == false)) {
			return false;
		}

		//for report
		EL_ModuleState::start("ttc.{$this->configId}", 'ttc.decrement');

		$key = $this->config['KEY'];
		if (!isset($key_arr[$key])) {
			$this->errCode = 20081;
			$this->errMsg  = "ttc config:{$this->ttcKey} decrement key not set";

			//report
			$this->reportModuleState('decrement', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		$fields = $this->config['FIELDS'];
		if ( !array_key_exists($fld, $fields) ) {
			$this->errCode = 20082;
			$this->errMsg  = "ttc config:{$this->ttcKey} decrement no field name $fld";

			//report
			$this->reportModuleState('decrement', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		$val = intval($val);
		if ( $val < 1 ) {
			$this->errCode = 20083;
			$this->errMsg  = "ttc config:{$this->ttcKey} invalid decrement value";

			//report
			$this->reportModuleState('decrement', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		$req = new tphp_ttc_request($this->server, TPHP_TTC_OP_UPDATE);
		if ( $this->key_type == 1 ) {
			$errCode = $req->set_key($key_arr[$key]);
		} elseif ( $this->key_type == 2 ) {
			$errCode = $req->set_key_str($key_arr[$key]);
		} else {
			$this->errCode = 200111;
			$this->errMsg  = 'request failed';

			//report
			$this->reportModuleState('decrement', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		if ($errCode != 0){
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} decrement:{$key}: set_key error";

			//report
			$this->reportModuleState('decrement', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		if ( count($key_arr) > 1 ) {
			// �������ֶ�key���
			foreach ( $key_arr as $mk => $mv ) {
				if ($mk == $key) {
					continue;
				}

				$chk = $this->checkMultikey($mk, $mv);
				if ( !$chk ) {
					//report
					$this->reportModuleState('decrement', EL_ModuleState::FAILED_OTHER);

					return $chk;
				}

				$eq = $this->eqv($req, $mk, $mv);
				if ( $eq != 0 ) {
					$this->errCode = 20085;
					$this->errMsg  = "ttc config:{$this->ttcKey} decrement:{$key}: set multikey error";

					//report
					$this->reportModuleState('decrement', EL_ModuleState::FAILED_OTHER);

					return false;
				}
			}
		}

		$add = $req->sub($fld, $val);
		if ( $add != 0 ) {
			$this->errCode = 20086;
			$this->errMsg  = "ttc config:{$this->ttcKey} decrement:{$key}: sub error";

			//report
			$this->reportModuleState('decrement', EL_ModuleState::FAILED_OTHER, $add);

			return false;
		}

		$result = new tphp_ttc_result();
		$req->execute($result);
		$this->result = $result;
		$errCode = $result->result_code();
		if ($errCode != 0) {
			$this->ttcWriteLog("result:TTC_decrement_failed,ttc:{$this->ttcKey},data:".serialize($key_arr));
			$this->ttcCode = $errCode;
			$this->errCode = $errCode;
			$this->errMsg  = "ttc config:{$this->ttcKey} decrement:{$key} error,error code:{$errCode}";

			//report
			$this->reportModuleState('decrement', EL_ModuleState::FAILED_OTHER);

			return false;
		}

		//report
		$this->reportModuleState('decrement', EL_ModuleState::SUCCESS);

		$this->ttcWriteLog("result:TTC_decrement_success,ttc:{$this->ttcKey},data:" . serialize($key_arr) . ',effect:' . $this->getAffectRows());

		return true;
	}

	/**
	 * ��������Ƿ�Ϸ�
	 *
	 * @param data    ����
	 * @param type    1:insert, 2:update 3:delete 4:get
	 */
	public function check(&$data)
	{
		$this->clearERR();
		$fields = $this->config['FIELDS'];
		foreach ($fields as $k => $v){
			if (!isset($data[$k])) {
				continue;
			}
			switch ($v['type']){
				case TTC::INT :
				case TTC::FLOAT :
					if ($v['min'] > $data[$k] || $data[$k] > $v['max']) {
						$this->errCode = 20051;
						$this->errMsg  = "ttc config:{$this->ttcKey} field:{$k} error";
						return false;
					} else {
						$data[$k] = 0 + $data[$k];
					}
					break;
				case TTC::STRING :
					$len = strlen($data[$k]);
					if ($v['min'] > $len || $len > $v['max']) {
						$this->errCode = 20052;
						$this->errMsg  = "ttc config:{$this->ttcKey} field:{$k} error";
						return false;
					} else {
						$data[$k] = '' . $data[$k];
					}
					break;
				case TTC::BINARY :
					$len = strlen($data[$k]);
					if ($v['min'] > $len || $len > $v['max']) {
						$this->errCode = 20053;
						$this->errMsg  = "ttc config:{$this->ttcKey} field:{$k} error";
						return false;
					} else {
						$data[$k] = '' . $data[$k];
					}
					break;
				default:
					$this->errCode = 20054;
					$this->errMsg  = "ttc config:{$this->ttcKey} field:{$k} data type:{$v['type']} error";
					return false;
			}
		}
		return true;
	}

	/**
	 * ��������Ƿ�Ϸ�
	 *
	 * @param key    ��������
	 */
	public function checkKey(&$key)
	{
		$this->clearERR();
		$v = $this->config['FIELDS'][$this->config['KEY']];
		switch($v['type']){
			case TTC::INT:
			case TTC::FLOAT :
				$ret = ($v['min'] <= $key && $key <= $v['max']);
				if($ret == false){
					$this->errCode = 20061;
					$this->errMsg  = "ttc config:{$this->ttcKey} field:{$key} error";
				} else {
					$key = 0 + $key;
				}
				return $ret;
			case TTC::STRING:
				$len = strlen($key);
				$ret = ($v['min'] <= $len && $len <= $v['max']);
				if ($ret === false) {
					$this->errCode = 20062;
					$this->errMsg  = "ttc config:{$this->ttcKey} field:{$key} error";
				} else {
					$key = '' . $key;
				}
				return $ret;
			case TTC::BINARY:
				//TODO...
				return true;
			default:
				$this->errCode = 20063;
				$this->errMsg  = "ttc config:{$this->ttcKey} field:{$key} data type:{$v['type']} error";
				return false;
		}
	}

	/**
	 * �����ֶ�key����£�����key�������key�ֶ�
	 *
	 * @param   string  $key, key�ֶ���
	 * @param   mix     $val, key�ֶ�ֵ(����), �����ͨ��, �����ֶ�����ͬʱ��������ת��, ����������ʹ���
	 * @return  boolean
	 */
	private function checkMultikey($key, &$val)
	{
		if ( !isset($this->config['FIELDS'][$key]) ) {
			$this->errCode = 20064;
			$this->errMsg  = "ttc config:{$this->ttcKey} field:{$key} not exists";
			return false;
		}
		$field = $this->config['FIELDS'][$key];
		switch($field['type']){
			case TTC::INT:
			case TTC::FLOAT :
				$ret = ($field['min'] <= $val && $val <= $field['max']);
				if($ret == false){
					$this->errCode = 20065;
					$this->errMsg  = "ttc config:{$this->ttcKey} field:{$key} error";
				} else {
					$val = 0 + $val;
				}
				return $ret;
			case TTC::STRING:
				$len = strlen($val);
				$ret = ($field['min'] <= $len && $len <= $field['max']);
				if ($ret === false) {
					$this->errCode = 20066;
					$this->errMsg  = "ttc config:{$this->ttcKey} field:{$key} error";
				} else {
					$val = '' . $val;
				}
				return $ret;
			case TTC::BINARY:
				//TODO...
				return true;
			default:
				$this->errCode = 20067;
				$this->errMsg  = "ttc config:{$this->ttcKey} field:{$key} data type:{$field['type']} error";
				return false;
		}
	}

	/**
	 * Ϊrequest����������������(ͨ��Ϊ���ֶ�key����£���������key)
	 *
	 * @param   tphp_ttc_request    $req, ttc�������
	 * @param   string              $key, �ֶ���
	 * @param   mix                 $val, �ֶ�ֵ
	 * @return  int                 $ret
	 */
	private function eqv(&$req, $key, $val) {
		if ( is_string($val) ) {
			$ret = $req->eq_str($key, $val);
		} elseif ( is_numeric($val) ) {
			$ret = $req->eq($key, $val);
		}

		return $ret;
	}

	/**
	 * module state report
	 *
	 * @param string $call_interface
	 * @param int $result
	 *
	 * @return mix 0/1/false
	 */
	private function reportModuleState($call_interface, $result)
	{
		$resp_code = EL_ModuleState::SUCCESS == $result ? 0 : $this->errCode;

		return EL_ModuleState::report('AUTO_MASTER', "ttc.{$this->configId}", 'ttc.' . $call_interface, $result, $resp_code, $this->config['IP']);
	}

	/**
	 * ��������ʶ����ÿ����������ǰ����
	 */
	private function clearERR()
	{
		$this->errCode = 0;
		$this->errMsg  = '';
		$this->ttcCode = 0;
	}
}

//End Of Script
