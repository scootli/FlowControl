<?php
define("ICSON_SMTP_HOSTNAME", "smtp.exmail.qq.com");
define("ICSON_SMTP_SERVER", "smtp.exmail.qq.com");
define("ICSON_SMTP_PORT", 25);
define("ICSON_SMTP_CHARSET", "GB2312");
define("ICSON_SMTP_TIMEOUT", 10);
define("ICSON_SMTP_USERNAME", 'data@51buy.com');
define("ICSON_SMTP_PASSWORD", '51buy&&icson!@');

class EL_Mailer
{
	/**
	 * �������
	 */
	public static $errCode = 0;

	/**
	 * ������Ϣ,�޴���Ϊ''
	 */
	public static $errMsg = '';

	/**
	 * ���������Ϣ,��ÿ�������Ŀ�ʼ����
	 */
	private static function clearError() {
		self::$errCode = 0;
		self::$errMsg  = '';
	}

	/*-------------------------------------------------------------------------*/
	//  Qzone Portal Database Class
	//
	//  Description : send email by smtp
	/*-------------------------------------------------------------------------*/
	public static function send($to, $from, $displayname, $subject, $content, $images)
	{
		$return_data['code'] = false;

		$displayname = str_replace("\"", "", $displayname);
		$content = trim($content);

		$to   = preg_replace( "/[ \t]+/" , ""  , $to   );
		$from = preg_replace( "/[ \t]+/" , ""  , $from );

		$to = preg_replace("/[^@._a-zA-Z0-9,]/", "", $to);
		$from = preg_replace("/[^@._a-zA-Z0-9]/", "", $from);

		$to   = preg_replace( "/,,/"     , ","  , $to );
		$from = preg_replace( "/,,/"     , ","  , $from );

		$to     = preg_replace( "#\#\[\]'\"\(\):;/\$!?\^&\*\{\}#" , "", $to  );
		$from   = preg_replace( "#\#\[\]'\"\(\):;/\$!?\^&\*\{\}#" , "", $from);

		$subject = str_replace("\n", "", trim($subject));
		$subject = self::cleanMessage($subject);

		$boundary = 'divided_by_ECC_ECP_icson_BA_';

		//----------------------------------
		// Build headers
		//----------------------------------

		$mail_headers = "";
		$mail_headers .= "From: \"" . $displayname . "\"<" . $from . ">\n";
		$mail_headers .= "To: ".$to."\n";
		$mail_headers .= "Subject: ".$subject."\n";
		$mail_headers .= "MIME-Version: 1.0\n";

		//$mail_headers .= "Return-Path: ".$from."\n";
		//$mail_headers .= "X-Priority: 3\n";
		//$mail_headers .= "X-Mailer: 51buy.com Mailer\n";
		if (!empty($images))
		{
			$level = 0;
			$mail_headers .= "Content-Type: multipart/mixed;\tboundary=\"" . $boundary . $level . "\"\n\n";
			$mail_headers .= "--" . $boundary . $level . "\n";

			$level ++;
			$mail_headers .= "Content-Type: multipart/related;\ttype=\"multipart/alternative\";\tboundary=\"" . $boundary . $level . "\"\n\n";

			$mail_headers .= "--" . $boundary . $level . "\n";
			$content = "Content-Type: text/html; charset=" . ICSON_SMTP_CHARSET . "\n\n" . $content . "\n\n";
			$content .= "--" . $boundary . $level . "--\n";

			$level --;
			foreach($images as $image)
			{
				if (!file_exists($image['file']))
				{
					$return_data['msg'] = "Could not find a image file: " . $image['file'];
				}
				$image_data = addslashes(fread($fp=fopen($image['file'],"r"), filesize($image['file'])));
				$image_data = chunk_split(base64_encode(StripSlashes($image_data)));

				$content .= "--" . $boundary . $level . "\n";
				$content .= "Content-Type:" . $image['type'] . ";\tname=\"" . $image['name'] . "\"\n";
				$content .= "Content-Transfer-Encoding: base64\n";
				$content .= "Content-Disposition: attachment; filename=\"" . $image['name'] . "\"\n";
				$content .= "Content-ID: <" . $image['cid'] . ">\n\n";
				$content .= $image_data . "\n\n";
			}

			$content .= "--" . $boundary . $level . "--\n";
		}
		else
		{
			$mail_headers .= "Content-Type: text/html; charset=" . ICSON_SMTP_CHARSET ."\n";
		}

		$smtp_fp = @fsockopen( ICSON_SMTP_SERVER, ICSON_SMTP_PORT, $errno, $errstr, ICSON_SMTP_TIMEOUT );
		if ( ! $smtp_fp )
		{
			$return_data['msg'] = "Could not open a socket to the SMTP server";
			return $return_data;
		}

		$smtpmsg = self::getLine($smtp_fp);
		$smtpcode = substr( $smtpmsg, 0, 3 );

		if ( $smtpcode == 220 )
		{
			$data = self::crlfEncode( $mail_headers . "\n" . $content);

			//---------------------
			// HELO!, er... HELLO!
			//---------------------

			$smtp_msg = self::sendCmd($smtp_fp, "EHLO ".ICSON_SMTP_HOSTNAME);
			$smtp_code = substr( $smtp_msg, 0, 3 );

			if ( $smtp_code != 250 )
			{
				$return_data['msg'] = "EHLO";
				return $return_data;
			}

			$smtp_msg = self::sendCmd($smtp_fp, "AUTH LOGIN");
			$smtp_code = substr( $smtp_msg, 0, 3 );

			if ( $smtp_code == 334 )
			{
				$smtp_msg = self::sendCmd( $smtp_fp, base64_encode(ICSON_SMTP_USERNAME) );
				$smtp_code = substr( $smtp_msg, 0, 3 );

				if ( $smtp_code != 334  )
				{
					$return_data['msg'] = "Username not accepted from the server";
					return $return_data;
				}

				$smtp_msg = self::sendCmd( $smtp_fp, base64_encode(ICSON_SMTP_PASSWORD) );
				$smtp_code = substr( $smtp_msg, 0, 3 );

				if ( $smtp_code != 235 )
				{
					$return_data['msg'] = "Password not accepted from the server";
					return $return_data;
				}
			}

			$smtp_msg = self::sendCmd($smtp_fp, "MAIL FROM:".$from);
			$smtp_code = substr( $smtp_msg, 0, 3 );

			if ( $smtp_code != 250 )
			{
				$return_data['msg'] = $smtp_msg;
				return $return_data;
			}


			$tos = explode(',',$to);

			foreach ($tos as $to_mail){
				$smtp_msg = self::sendCmd($smtp_fp, "RCPT TO:<".$to_mail.">");
				$smtp_code = substr( $smtp_msg, 0, 3 );

				if ( $smtp_code != 250 )
				{
					$return_data['msg'] = "Incorrect email address: $to_mail".var_dump($tos);
					return $return_data;
				}
			}

			//---------------------
			// SEND MAIL!
			//---------------------

			$smtp_msg = self::sendCmd($smtp_fp,"DATA");
			$smtp_code = substr( $smtp_msg, 0, 3 );

			if ( $smtp_code == 354 )
			{
				//$this->smtp_send_cmd( $data );
				fputs( $smtp_fp, $data."\r\n" );
			}
			else
			{
				$return_data['msg'] = "Error on write to SMTP server";
				return $return_data;
			}

			//---------------------
			// GO ON, NAFF OFF!
			//---------------------

			$smtp_msg = self::sendCmd($smtp_fp,".");
			$smtp_code = substr( $smtp_msg, 0, 3 );

			if ( $smtp_code != 250 )
			{
				$return_data['msg'] = "Error on send '.'";
				return $return_data;
			}

			$smtp = self::sendCmd($smtp_fp,"quit");
			$smtp_code = substr( $smtp_msg, 0, 3 );

			if ( ($smtp_code != 250) and ($smtp_code != 221) )
			{
				$return_data['msg'] = "Error on send 'quit'";
				return $return_data;
			}

			@fclose( $smtp_fp );
		}
		else
		{
			$return_data['msg'] =  "Error on smtp code ne 220";
			return $return_data;
		}
		$return_data['code']=true;
		return $return_data;
	}


	/*-------------------------------------------------------------------------*/
	// clean_message: (Mainly used internally)
	// Ensures that \n and <br> are converted into CRLF (\r\n)
	// Also unconverts some BBCode
	/*-------------------------------------------------------------------------*/

	public static function cleanMessage($message = "" )
	{
			$message = preg_replace( "/^(\r|\n)+?(.*)$/", "\\2", $message );

			//-----------------------------------------
			// Bear with me...
			//-----------------------------------------

			$message = str_replace( "\n"          , "<br />", $message );
			$message = str_replace( "\r"          , ""      , $message );
			$message = str_replace( "<br>" , "\r\n", $message );
			$message = str_replace( "<br />"      , "\r\n", $message );

			$message = preg_replace( "#<.+?".">#" , "" , $message );

			$message = str_replace( "&quot;", "\"", $message );
			$message = str_replace( "&#092;", "\\", $message );
			$message = str_replace( "&#036;", "\$", $message );
			$message = str_replace( "&#33;" , "!", $message );
			$message = str_replace( "&#39;" , "'", $message );
			$message = str_replace( "&lt;"  , "<", $message );
			$message = str_replace( "&gt;"  , ">", $message );
			$message = str_replace( "&#124;", '|', $message );
			$message = str_replace( "&amp;" , "&", $message );
			$message = str_replace( "&#58;" , ":", $message );
			$message = str_replace( "&#91;" , "[", $message );
			$message = str_replace( "&#93;" , "]", $message );
			$message = str_replace( "&#064;", '@', $message );
			$message = str_replace( "&#60;", '<', $message );
			$message = str_replace( "&#62;", '>', $message );
			$message = str_replace( "&nbsp;" , ' ' , $message );

			return $message;
	}

	//+------------------------------------
	//| get_line()
	//|
	//| Reads a line from the socket and returns
	//| CODE and message from SMTP server
	//|
	//+------------------------------------

	public static function getLine($smtp_fp)
	{
		$smtp_msg = "";

		while ( $line = fgets( $smtp_fp, 515 ) )
		{
			$smtp_msg .= $line;

			if ( substr($line, 3, 1) == " " )
			{
				break;
			}
		}

		return $smtp_msg;
	}

	//+------------------------------------
	//| send_cmd()
	//|
	//| Sends a command to the SMTP server
	//| Returns TRUE if response, FALSE if not
	//|
	//+------------------------------------

	public static function sendCmd($smtp_fp,$cmd)
	{
		fputs( $smtp_fp, $cmd."\r\n" );

		$smtp_msg = self::getLine($smtp_fp);

		return $smtp_msg;
	}

	//+------------------------------------
	//| crlf_encode()
	//|
	//| RFC 788 specifies line endings in
	//| \r\n format with no periods on a
	//| new line
	//+------------------------------------

	public static function crlfEncode($data)
	{
		$data .= "\n";
		$data  = str_replace( "\n", "\r\n", str_replace( "\r", "", $data ) );
		$data  = str_replace( "\n.\r\n" , "\n. \r\n", $data );

		return $data;
	}

} // end of class

