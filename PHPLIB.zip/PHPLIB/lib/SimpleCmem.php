<?php
/**
 * CMEM简单调用封装
 * 用本接口可以屏蔽bid和接入机，bid和接入机分组在xxx.cmem.php配置文件中指定
 *
 * @author bennylin
 */

/*
//example

require 'Config.php';

$value = array(
	'test_data' => 'example data',
	'date' => date('Y-m-d'),
);

$set_resp = EL_SimpleCmem::set('example', 'testkey_123', $value);
if ($set_resp) {
	echo "set success\n";
}
else {
	echo "set failed,code:" . EL_Errors::$code . ",msg:" . EL_Errors::$msg . "\n";
}

$get_resp = EL_SimpleCmem::get('example', 'testkey_123');
echo "\nget response:\n";
var_dump($get_resp, EL_Errors::$code, EL_Errors::$msg);

echo "\ntest end\n";
*/


/**
 * simple tmem access class
 *
 * @author bennylin
 */
class EL_SimpleCmem
{
	private static $_tmem_instances = array();
	private static $_last_instance;

	/**
	 * 获取key值
	 *
	 * @param string $biz_name
	 * @param mixed $key 字符串或字符串数组，不能为空，不能为0
	 * @param int $offset 偏移
	 * @param int $length 长度
	 *
	 * @return mix string/array/null/false
	 */
	public static function get($biz_name, $key, $offset = 0, $length = 0)
	{
		$conf = Config::get('cmem', $biz_name);
		if (empty($conf))
		{
			EL_Errors::err(1, "cmem '{$biz_name}' not defined");
			return false;
		}

		$cmem = self::getRawApiInstance($conf['access_id']);

		if (!empty($conf['prefix'])) {
			$key = self::_withPrefix($key, $conf['prefix']);
		}

		$result = $cmem->get($conf['bid'], $key, $offset, $length);
		if ($result === false)
		{
			//just no key
			if ($cmem->errno() == -13200 || $cmem->errno() == 0)
			{
				return null;
			}

			return false;
		}

		//if no data,unset
		if (is_array($key) ) {
			foreach ($result as $k => $v) {
				if ($v === false) {
					unset($result[$k]);
				}
			}
		}

		//need unpack ?
		if ($result !== '' && !empty($conf['unpack']) )
		{
			if (!empty($conf['include']))
			{
				$inc = include_once $conf['include'];
				if ($inc === false)
				{
					EL_Errors::err(1, $conf['include'] . ' not found');
					return false;
				}
			}
			$result = is_array($key) ? array_map($conf['unpack'], $result) : call_user_func($conf['unpack'], $result);
		}

		return $result;
	}

	/**
	 * 设置key值
	 *
	 * @param string $biz_name
	 * @param string/array $key_or_kvmap 单key或 k => v 数组，字符串或字符串数组，不能为空，不能为0
	 * @param string $value 单key时的值
	 * @param int $offset 偏移
	 * @param int $length 长度
	 *
	 * @return boolean
	 */
	public static function set($biz_name, $key_or_kvmap, $value = null, $offset = 0, $length = 0)
	{
		if (empty($key_or_kvmap) ) {
			return false;
		}

		$conf = Config::get('cmem', $biz_name);
		if (empty($conf))
		{
			EL_Errors::err(1, "cmem '{$biz_name}' not defined");
			return false;
		}

		$cmem = self::getRawApiInstance($conf['access_id']);

		//need pack ?
		if (!empty($conf['pack']) )
		{
			if (!empty($conf['include']))
			{
				$inc = include_once $conf['include'];
				if ($inc === false)
				{
					EL_Errors::err(1, $conf['include'] . ' not found');
					return false;
				}
			}

			//区分批量和单个
			if (is_array($key_or_kvmap))
			{
				$key_or_kvmap = array_map($conf['pack'], $key_or_kvmap);
			}
			else
			{
				$value = call_user_func($conf['pack'], $value);
			}
		}

		//auto add prefix
		if (!empty($conf['prefix'])) {
			if (is_array($key_or_kvmap)) {
				//kvmap mode
				$_tmp_kvmap = array();
				foreach ($key_or_kvmap as $k => $v) {
					$tmp_k = $conf['prefix'] . '_' . $k;
					$_tmp_kvmap[$tmp_k] = $v;
				}

				$key_or_kvmap = $_tmp_kvmap;
			}
			else {
				//single key mode
				$key_or_kvmap = $conf['prefix'] . '_' . $key_or_kvmap;
			}
		}

		$result = $cmem->set($conf['bid'], $key_or_kvmap, $value, $offset, $length);
		if ($result === false)
		{
			return false;
		}

		return $result;
	}

	/**
	 * 删除key
	 *
	 * @param string $biz_name
	 * @param mixed $key 字符串或字符串数组，不能为空，不能为0
	 *
	 * @return boolean
	 */
	public static function del($biz_name, $key)
	{
		$conf = Config::get('cmem', $biz_name);
		if (empty($conf))
		{
			EL_Errors::err(1, "cmem '{$biz_name}' not defined");
			return false;
		}

		$cmem = self::getRawApiInstance($conf['access_id']);

		if (!empty($conf['prefix'])) {
			$key = self::_withPrefix($key, $conf['prefix']);
		}

		$result = $cmem->del($conf['bid'], $key);
		if ($result === false)
		{
			return false;
		}

		//这里有可能返回数组
		if (is_array($result) && is_array($key))
		{
			foreach ($result as $one_key => $key_resp)
			{
				if ($key_resp === false)
				{
					$idx = array_search($one_key, $key);
					unset($key[$idx]);
				}
			}

			//为空表示全部失败了
			if (empty($key))
			{
				return false;
			}
		}

		return $result;
	}

	/**
	 * 按列获取key值
	 *
	 * @param string $biz_name
	 * @param mixed $key 字符串或字符串数组，不能为空，不能为0
	 * @param string/array $cols
	 *
	 * @return string/array/false
	 */
	public static function getcol($biz_name, $key, $cols)
	{
		$conf = Config::get('cmem', $biz_name);
		if (empty($conf))
		{
			EL_Errors::err(1, "cmem '{$biz_name}' not defined");
			return false;
		}

		$cmem = self::getRawApiInstance($conf['access_id']);

		if (!empty($conf['prefix'])) {
			$key = self::_withPrefix($key, $conf['prefix']);
		}

		return $cmem->getcol($conf['bid'], $key, $cols);
	}

	/**
	 * 按列设置key值
	 *
	 * @param string $biz_name
	 * @param mixed $key 字符串或字符串数组，不能为空，不能为0
	 * @param array/int $record_or_col 列与值对应数组或列标识
	 * @param string $value_of_col 如果$record_or_col参数填写是列标识，那这里填该列的值
	 *
	 * @return mix 批量时返回array(col1 => return1, col2 => return2, ...)
	 */
	public static function setcol($biz_name, $key, $record_or_col, $value_of_col = null)
	{
		$conf = Config::get('cmem', $biz_name);
		if (empty($conf))
		{
			EL_Errors::err(1, "cmem '{$biz_name}' not defined");
			return false;
		}

		$cmem = self::getRawApiInstance($conf['access_id']);

		if (!empty($conf['prefix'])) {
			$key = self::_withPrefix($key, $conf['prefix']);
		}

		$result = $cmem->setcol($conf['bid'], $key, $record_or_col, $value_of_col);
		if ($result === false)
		{
			return false;
		}

		//这里有可能返回数组
		if (is_array($result))
		{
			foreach ($result as $col => $col_resp)
			{
				if ($col_resp === false)
				{
					unset($record_or_col[$col]);
				}
			}

			//为空表示全部失败了
			if (empty($record_or_col))
			{
				return false;
			}
		}

		return $result;
	}

	/**
	 * 按列删除key值
	 *
	 * @param string $biz_name
	 * @param mixed $key 字符串或字符串数组，不能为空，不能为0
	 * @param array $cols
	 *
	 * @return boolean
	 */
	public static function delcol($biz_name, $key, $cols)
	{
		$conf = Config::get('cmem', $biz_name);
		if (empty($conf))
		{
			EL_Errors::err(1, "cmem '{$biz_name}' not defined");
			return false;
		}

		$cmem = self::getRawApiInstance($conf['access_id']);

		if (!empty($conf['prefix'])) {
			$key = self::_withPrefix($key, $conf['prefix']);
		}

		$result = $cmem->delcol($conf['bid'], $key, $cols);
		if ($result === false)
		{
			return false;
		}

		//这里有可能返回数组
		if (is_array($result))
		{
			foreach ($result as $col => $col_resp)
			{
				if ($col_resp === false)
				{
					$idx = array_search($col, $cols);
					unset($cols[$idx]);
				}
			}

			//为空表示全部失败了
			if (empty($cols))
			{
				return false;
			}
		}

		return $result;
	}

	/**
	 * 获取最后的错误码
	 *
	 * @return int
	 */
	public static function errno()
	{
		if (self::$_last_instance) {
			return self::$_last_instance->errno();
		}

		return 0;
	}

	/**
	 * 设置是否显示错误，调试模式时使用
	 *
	 * @param boolean $show_error
	 *
	 * @return void
	 */
	public static function show_error($show_error = true)
	{
		return Tmem::show_error($show_error);
	}

	/**
	 * 取得原生的TMEM客户端实例
	 *
	 * @param int $id cmem access set id
	 *
	 * @return Tmem
	 */
	public static function getRawApiInstance($id)
	{
		if (empty(self::$_tmem_instances[$id] ) ) {
			$servers = Config::get('cmem', 'ACCESS_' . $id);
			if (empty($servers)) {
				throw new Exception("cmem access servers group {$id} not defined.");
			}

			$connect_time_ms = 500;
			$debug_error = 0;
			$tmem = new tmem($connect_time_ms, $debug_error); //tmem.so

			$timeout = 500;
			$freetime = 0;
			$tmem->set_servers($servers, $timeout, $freetime);

			$tmem->instanceId = $id;
			self::$_tmem_instances[$id] = $tmem;
		}

		return self::$_tmem_instances[$id];
	}

	/**
	 * 加上指定前缀
	 *
	 * @param mixed $key
	 * @param string $prefix
	 *
	 * @return array
	 */
	private static function _withPrefix($key, $prefix)
	{
		if (is_array($key)) {
			foreach ($key as $k => $v) {
				$key[$k] = $prefix . '_' . $v;
			}
		}
		else {
			$key = $prefix . '_' . $key;
		}

		return $key;
	}
}

