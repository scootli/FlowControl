<?php

require_once PHPLIB_ROOT . 'inc/TMemDBConfig.inc.php';

class TMemHelper {
	
	// tmem����������
	/** ��ȡkey��Ӧ�������Ҳ��� */
	const ERROR_NO_DATA = -13200; 
	/** ��ȡʱkey��Ӧ�������ѹ��� */
	const ERROR_KEY_EXPIRED = -13106; 
	/** ɾ��ʱkey������ */
	const ERROR_KEY_NO_EXIST = -13105; 
	/** ƫ�Ʋ����������Ϸ� */
	const ERROR_LOCAL_PARSE_ARGS = -13002;
	/** �в����������Ϸ� */
	const ERROR_SO_PARSE_ARGS = -13004;
	
	// ɢ������
	const HASH_TYPE_INT = 1;
	const HASH_TYPE_STRING = 2;
	
	private $dbName;
	private $tableName;
	private $tmemBizId;
	private $dataKeyPrefix;
	private $lockKeyPrefix;
	private $dbCount;
	private $tableCount;
	private $columns;
	private $keyColumn;
	private $hashType;
	private $tm;
	private $isMultiTable = false;
	
	private $_errCode = 0;
	private $_errMsg = '';
	
	private static $instances = array();
	
	public static $errCode = 0;
	public static $errMsg = '';
	
	private function __construct() {}
	
	public static function getInstance($config_key) {
		if(isset(self::$instances[$config_key])) {
			return self::$instances[$config_key];
		}
		
		global $_TMEM_DB_CONFIG;
		if(!isset($_TMEM_DB_CONFIG[$config_key])) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = "Failed to load configuration with key $config_key.";
			return false;
		}
		
		$config = $_TMEM_DB_CONFIG[$config_key];
		if(!is_array($config)) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Invalid configuration.';
			return false;
		}
		
		$obj = new TMemHelper();
		
		if(empty($config['dbName'])) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Failed to find db name.';
			return false;
		} else {
			$obj->dbName = $config['dbName'];
		}
		
		if(empty($config['tableName'])) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Failed to find table name.';
			return false;
		} else {
			$obj->tableName = $config['tableName'];
		}
		
		if(empty($config['tmemConfigKey'])) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Failed to find tmem configuration key.';
			return false;
		} else {
			$tmemConfigKey = $config['tmemConfigKey'];
		}
		$obj->tm = Config::getTMem($tmemConfigKey);
		if($obj->tm === false) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = "Failed to initialize tmem with key $tmemConfigKey.";
			Logger::err(Config::$errCode . ' : ' . Config::$errMsg);
			return false;
		}
		
		if(empty($config['tmemBizId'])) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Failed to find tmem biz id.';
			return false;
		} else {
			$obj->tmemBizId = $config['tmemBizId'];
		}
		
		if(empty($config['dataKeyPrefix'])) {
			$obj->dataKeyPrefix = $obj->dbName . '_';
			$obj->lockKeyPrefix = $obj->dataKeyPrefix . 'lock_';
		} else {
			$obj->dataKeyPrefix = $config['dataKeyPrefix'];
			$obj->lockKeyPrefix = $obj->dataKeyPrefix . 'lock_';
		}
		
		if(empty($config['dbCount']) || !is_int($config['dbCount']) || $config['dbCount'] <= 0) {
			$obj->dbCount = 1;
		} else {
			$obj->dbCount = $config['dbCount'];
		}
		if($obj->dbCount > 1) {
			$obj->isMultiTable = true;
		}
		
		if(empty($config['tableCount']) || !is_int($config['tableCount']) || $config['tableCount'] <= 0) {
			$obj->tableCount = 1;
		} else {
			$obj->tableCount = $config['tableCount'];
		}
		if($obj->tableCount > 1) {
			$obj->isMultiTable = true;
		}
		
		if(empty($config['columns']) || !is_array($config['columns'])) {
			self::$errCode = ErrorConfig::getErrorCode('unexpected_input');
			self::$errMsg = 'Failed to find column definition.';
			return false;
		} else {
			$obj->columns = $config['columns'];
		}
		
		if(empty($config['keyColumn']) || !isset($obj->columns[$config['keyColumn']])) {
			$keys = array_keys($obj->columns);
			$obj->keyColumn = $keys[0];
		} else {
			$obj->keyColumn = $config['keyColumn'];
		}
		
		if(!isset($config['hashType']) || empty($config['hashType'])) {
			$obj->hashType = self::HASH_TYPE_INT;
		} else {
			if($config['hashType'] == self::HASH_TYPE_STRING) {
				$obj->hashType = self::HASH_TYPE_STRING;
			} else {
				$obj->hashType = self::HASH_TYPE_INT;
			}
		}
		
		self::$instances[$config_key] = $obj;
		
		return $obj;
	}
	
	private function clearErr() {
		$this->_errCode = 0;
		$this->_errMsg = '';
	}
	
	public function lock($key) {
		$cas = -1;
		$expire_timestamp = 0;
		
		$ret = $this->tm->casget($this->tmemBizId, $this->lockKeyPrefix . $key, &$cas, &$expire_timestamp);
		if($ret !== false) {
			return false;
		} else {
			$errno = $this->tm->errno();
			if($errno != self::ERROR_KEY_EXPIRED && $errno != self::ERROR_NO_DATA) {
				$this->_errCode = $errno;
				$this->_errMsg = 'Failed to get lock status.[' . $this->lockKeyPrefix . $key . ']';
				Logger::err($this->_errCode . ' : ' . $this->_errMsg);
				return false;
			}
		}
		
		$ret = $this->tm->casset($this->tmemBizId, $this->lockKeyPrefix . $key, 'LOCKED', &$cas, 2);
		if($ret === false) {
			$this->_errCode = $this->tm->errno();
			$this->_errMsg = 'Failed to get lock.[' . $this->lockKeyPrefix . $key . ']';
			Logger::err($this->_errCode . ' : ' . $this->_errMsg);
			return false;
		} else if($ret === null) {
			return false;
		}
		
		return true;
	}
	
	public function unlock($key) {
		$ret = $this->tm->del($this->tmemBizId, $this->lockKeyPrefix . $key);
		if($ret === false) {
			$errno = $this->tm->errno();
			if($errno != self::ERROR_KEY_NO_EXIST) {
				$this->_errCode = $errno;
				$this->_errMsg = 'Failed to release lock.[' . $this->lockKeyPrefix . $key . ']';
				Logger::err($this->_errCode . ' : ' . $this->_errMsg);
				return false;
			}
		}
		
		return true;
	}
	
	private function cleanCache($key) {
		$ret = $this->tm->del($this->tmemBizId, $this->dataKeyPrefix . $key);
		if($ret === false) {
			$errno = $this->tm->errno();
			if($errno != self::ERROR_KEY_NO_EXIST) {
				$this->_errCode = $errno;
				$this->_errMsg = 'Failed to clean cache.[' . $this->dataKeyPrefix . $key . ']';
				Logger::err($this->_errCode . ' : ' . $this->_errMsg);
				return false;
			}
		}
		
		return true;
	}
	
	private function getDBIndex($key) {
		if(!$this->isMultiTable) {
			return 1;
		}
		
		if($this->hashType == self::HASH_TYPE_INT) {
			return $key % $this->dbCount;
		} else {
			return ToolUtil::string2IntHash($key) % $this->dbCount;
		}
	}
	
	private function getTableIndex($key) {
		if(!$this->isMultiTable) {
			return 1;
		}
		
		if($this->hashType == self::HASH_TYPE_INT) {
			return $key / $this->dbCount % $this->tableCount;
		} else {
			return ToolUtil::string2IntHash($key) / $this->dbCount % $this->tableCount;
		}
	}
	
	private function getTableName($key) {
		if(!$this->isMultiTable) {
			return $this->tableName;
		}
		
		return $this->tableName . '_' . $this->getTableIndex($key);
	}
	
	private function getDB($key) {
		if($this->isMultiTable) {
			global $_DB_CFG;
			$config = $_DB_CFG[$this->dbName];
			$db_index = $this->getDBIndex($key);
			$db_key = $this->dbName . '_' . $db_index;
			$config['DB'] = $config['DB'] . '_' . $db_index;
			$_DB_CFG[$db_key] = $config;
			$db = Config::getDB($db_key);
			if($db === false) {
				$this->_errCode = Config::$errCode;
				$this->_errMsg = Config::$errMsg;
				Logger::err($this->_errCode . ' : ' . $this->_errMsg);
				return false;
			}
			return $db;
		} else {
			$db = Config::getDB($this->dbName);
			if($db === false) {
				$this->_errCode = Config::$errCode;
				$this->_errMsg = Config::$errMsg;
				Logger::err($this->_errCode . ' : ' . $this->_errMsg);
				return false;
			}
			return $db;
		}
	}
	
	private function updateCache($key) {
		$db = $this->getDB($key);
		if($db === false) {
			return false;
		}
		
		$table_name = $this->getTableName($key);
		$res = $db->getRows2($table_name, '', $this->getCondition(array( $this->keyColumn => $key )), null, null);
		if($res === false) {
			$this->_errCode = $db->errCode;
			$this->_errMsg = $db->errMsg;
			Logger::err($this->_errCode . ' : ' . $this->_errMsg);
			return false;
		}
		
		$ret = $this->tm->set($this->tmemBizId, $this->dataKeyPrefix . $key, serialize($res));
		if($ret === false) {
			$this->_errCode = $this->tm->errno();
			$this->_errMsg = 'Failed to update cache with key ' . $this->dataKeyPrefix . $key;
			Logger::err($this->_errCode . ' : ' . $this->_errMsg);
			return false;
		}
		
		return $res;
	}
	
	private function getCondition($filter) {
		$conds = array();
		foreach ($filter as $k => $v) {
			if(isset($this->columns[$k])) {
				if($this->columns[$k]['type'] == 'number') {
					$conds[] = "$k = $v";
				} else {
					$conds[] = "$k = '$v'";
				}
			}
		}
		return implode(' AND ', $conds);
	}
	
	public function getErrCode() {
		return $this->_errCode;
	}
	
	public function getErrMsg() {
		return $this->_errMsg;
	}
	
	public function insert($params) {
		$this->clearErr();
		
		$data = array();
		foreach ($this->columns as $name => $config) {
			if((!isset($config['readonly']) || !$config['readonly']) && (!isset($config['auto']) || !$config['auto'])) {
				if(isset($params[$name])) {
					$data[$name] = $params[$name];
				} else if(isset($config['default'])) {
					$data[$name] = $config['default'];
				} else {
					if($config['type'] == 'number') {
						$data[$name] = 0;
					} else {
						$data[$name] = '';
					}
				}
			}
		}
		
		if(empty($data[$this->keyColumn])) {
			$this->_errCode = ErrorConfig::getErrorCode('key_not_found');
			$this->_errMsg = 'Key not found.';
			return false;
		}
		$key = $data[$this->keyColumn];
		
		if($this->lock($key) === false) {
			return false;
		}
		
		if($this->cleanCache($key) === false) {
			return false;
		}
		
		$db = $this->getDB($key);
		if($db === false) {
			return false;
		}
		
		$table_name = $this->getTableName($key);
		$ret = $db->insert($table_name, $data);
		if($ret === false) {
			$this->_errCode = $db->errCode;
			$this->_errMsg = $db->errMsg;
			Logger::err($this->_errCode . ' : ' . $this->_errMsg);
			return false;
		}
		
		$this->updateCache($key);
		$this->unlock($key);
		
		return true;
	}
	
	public function update($params, $filter = array()) {
		$this->clearErr();
		
		$data = array();
		foreach ($this->columns as $name => $config) {
			if((!isset($config['readonly']) || !$config['readonly']) && (!isset($config['auto']) || !$config['auto'])) {
				if(isset($params[$name])) {
					$data[$name] = $params[$name];
				}
			}
		}
		
		if(empty($data[$this->keyColumn])) {
			$this->_errCode = ErrorConfig::getErrorCode('key_not_found');
			$this->_errMsg = 'Key not found.';
			return false;
		}
		$key = $data[$this->keyColumn];
		unset($data[$this->keyColumn]);
		
		$filter = $filter ?: array();
		if(!is_array($filter)) {
			$this->_errCode = ErrorConfig::getErrorCode('unexpected_input');
			$this->_errMsg = 'Parameter 2 should be array.';
			return false;
		}
		$filter[$this->keyColumn] = $key;
		
		if($this->lock($key) === false) {
			return false;
		}
		
		if($this->cleanCache($key) === false) {
			return false;
		}
		
		$db = $this->getDB($key);
		if($db === false) {
			return false;
		}
		
		$table_name = $this->getTableName($key);
		$ret = $db->update($table_name, $data, $this->getCondition($filter));
		if($ret === false) {
			$this->_errCode = $db->errCode;
			$this->_errMsg = $db->errMsg;
			Logger::err($this->_errCode . ' : ' . $this->_errMsg);
			return false;
		}
		
		$this->updateCache($key);
		$this->unlock($key);
		
		return true;
	}
	
	public function get($key, $filter = array(), $need = array(), $start = 0, $len = 0) {
		$this->clearErr();
		
		if(empty($key)) {
			$this->_errCode = ErrorConfig::getErrorCode('unexpected_input');
			$this->_errMsg = 'Parameter 1 should not be empty.';
			return false;
		}
		
		$filter = $filter ?: array();
		if(!is_array($filter)) {
			$this->_errCode = ErrorConfig::getErrorCode('unexpected_input');
			$this->_errMsg = 'Parameter 2 should be array.';
			return false;
		}
		
		$need = $need ?: array();
		if(!is_array($need)) {
			$this->_errCode = ErrorConfig::getErrorCode('unexpected_input');
			$this->_errMsg = 'Parameter 3 should be array.';
			return false;
		}
		
		$start = $start ?: 0;
		if(!is_int($start)) {
			$this->_errCode = ErrorConfig::getErrorCode('unexpected_input');
			$this->_errMsg = 'Parameter 4 should be int.';
			return false;
		}
		
		$len = $len ?: 0;
		if(!is_int($len)) {
			$this->_errCode = ErrorConfig::getErrorCode('unexpected_input');
			$this->_errMsg = 'Parameter 5 should be int.';
			return false;
		}
		
		$res = $this->tm->get($this->tmemBizId, $this->dataKeyPrefix . $key);
		if($res !== false) {
			$data = unserialize($res);
		} else {
			$errno = $this->tm->errno();
			if($errno == self::ERROR_NO_DATA || $errno == self::ERROR_KEY_EXPIRED) {
				$data = $this->updateCache($key);
				if($data === false) {
					return false;
				}
			} else {
				$this->_errCode = $this->tm->errno();
				$this->_errMsg = 'Failed to get cache data with key ' . $this->dataKeyPrefix . $key;
				Logger::err($this->_errCode . ' : ' . $this->_errMsg);
				return false;
			}
		}
		
		if(!empty($filter)) {
			for($i = 0; $i < count($data); $i++) {
				$d = $data[$i];
				foreach ($filter as $k => $v) {
					if(isset($this->columns[$k]) && $d[$k] != $v) {
						array_splice($data, $i, 1);
						$i--;
						break;
					}
				}
			}
		}
		
		if(!empty($start) || !empty($len)) {
			if(!empty($len)) {
				$data = array_slice($data, $start, $len);
			} else {
				$data = array_slice($data, $start);
			}
		}
		
		if(!empty($need)) {
			foreach ($data as &$d) {
				foreach ($d as $k => $v) {
					if(!in_array($k, $need)) {
						unset($d[$k]);
					}
				}
			}
		}
		
		return $data;
	}
	
	public function remove($key, $filter = array()) {
		$this->clearErr();
		
		if(empty($key)) {
			$this->_errCode = ErrorConfig::getErrorCode('unexpected_input');
			$this->_errMsg = 'Parameter 1 should not be empty.';
			return false;
		}
		
		$filter = $filter ?: array();
		if(!is_array($filter)) {
			$this->_errCode = ErrorConfig::getErrorCode('unexpected_input');
			$this->_errMsg = 'Parameter 2 should be array.';
			return false;
		}
		$filter[$this->keyColumn] = $key;
		
		if($this->lock($key) === false) {
			return false;
		}
		
		if($this->cleanCache($key) === false) {
			return false;
		}
		
		$db = $this->getDB($key);
		if($db === false) {
			return false;
		}
		
		$table_name = $this->getTableName($key);
		$ret = $db->remove($table_name, $this->getCondition($filter));
		if($ret === false) {
			$this->_errCode = $db->errCode;
			$this->_errMsg = $db->errMsg;
			Logger::err($this->_errCode . ' : ' . $this->_errMsg);
			return false;
		}
		
		$this->updateCache($key);
		$this->unlock($key);
		
		return true;
	}
}