<?php
require_once "_init.php";
/**
 *
 * wap�Ĺ��߼�
 * @author myforchen@tencent.com
 *
 */
class WapUtil {
	const VISITED_LENGTH = 10;
	public static $errCode = 0;
	public static $errMsg = '';

	public static $DOMAIN = false;

	private static $currentUser = null;
	private static $wapCategory = array();

	private static function setERR($code, $msg){
		self::$errCode = $code;
		self::$errMsg = $msg;
	}

	private static function clearERR(){
		self::setERR(0, '');
	}

	public static function sessionCMEMStart(){
		@ini_set("session.use_only_cookies", 0);
		@ini_set("session.use_cookies", 0);
		@ini_set('session.use_trans_sid', 1);
		@ini_set('session.name', "sid");

		$session = new Com\Base\Session();
		register_shutdown_function('session_write_close');
		session_set_save_handler(
		array($session, "open"),
		array($session, "close"),
		array($session, "read"),
		array($session, "write"),
		array($session, "destroy"),
		array($session, "gc")
		);

		$sid = "";

		if(isset($_COOKIE['rsess']))
		{
			$sid = @base64_decode($_COOKIE['rsess']);
		}
		else if(isset($_GET['_sid']))
		{
			$sid = ToolUtil::transXSSContent(trim($_GET['_sid']));
		}

		if(empty($sid))
		{
			@session_start();
			$sid = session_id();
		}
		else
		{
			session_id($sid);
			@session_start();
		}

		$_SESSION['sid'] = $sid;
		$_SESSION['uid'] = empty($_SESSION['uid']) ? 0 : $_SESSION['uid'];

		return $sid;
	}

	public static function sessionStart(){
		@ini_set("session.use_only_cookies", 0);
		@ini_set("session.use_cookies", 0);
		@ini_set('session.use_trans_sid', 1);
		@ini_set('session.name', "sid");

		/*
		 $session = new ISession();
		register_shutdown_function('session_write_close');
		session_set_save_handler(
				array($session, "open"),
				array($session, "close"),
				array($session, "read"),
				array($session, "write"),
				array($session, "destroy"),
				array($session, "gc")
		);
		*/

		$sid = "";
		if(isset($_COOKIE['rsess'])){
			$sid = @base64_decode($_COOKIE['rsess']);
		}

		if(empty($sid)){
			@session_start();
			$sid = session_id();
		} else {
			session_id($sid);
			@session_start();
		}

		$_SESSION['sid'] = $sid;
		$_SESSION['uid'] = empty($_SESSION['uid']) ? 0 : $_SESSION['uid'];

		return $sid;
	}

	public static function setLoginUid($uid){
		$_SESSION['uid'] = $uid;
	}

	public static function getLoginUid(){
		return empty($_SESSION['uid']) ? 0 : $_SESSION['uid'];
	}

	public static function getLoginUser($flush = false){
		if(self::$currentUser == null || $flush === true){
			$uid = self::getLoginUid();
			if(empty($uid)){
				return null;
			}

			$user = IUser::getUserInfo($uid);
			if($user === false){
				self::setERR(9101, "IUser::getUserInfo failed, code:" . IUser::$errCode . ', msg: ' . IUser::$errMsg);
				return false;
			}

			self::$currentUser = $user;
		}

		return self::$currentUser;
	}

	// ��¼���ʹ�����Ʒ
	public static function visited($pid){
		$vistied = self::getVisited();

		if(isset($vistied[$pid])) return;
		$vistied[$pid] = array(
				time()
		);

		$_SESSION['visited'] = array_slice($vistied, -self::VISITED_LENGTH, self::VISITED_LENGTH, true);
	}

	// ��ȡ���ʹ�����Ʒ
	public static function getVisited(){
		$vistied = array();
		if(isset($_SESSION['visited']) && is_array($_SESSION['visited'])){
			$vistied = $_SESSION['visited'];
		}
		return $vistied;
	}

	public static function strCollapse($str, $len, $encoding  = 'GBK'){
		return self::cutStr($str, $len, $encoding, '...');
	}
	public static function cutStr($str, $len, $encoding  = 'GBK', $collapse = ''){
		$str = trim($str);
		$strLen = strlen($str);

		if ($len && $strLen > $len) {
			$wordscut = '';
			if (strtolower ($encoding) == 'utf-8') {
				$n = 0;
				$tn = 0;
				$noc = 0;
				while ($n < $strLen) {
					$t = ord($str[$n]);
					if ($t == 9 || $t == 10 || (32 <= $t && $t <= 126)) {
						$tn = 1;
						$n ++;
						$noc ++;
					} elseif (194 <= $t && $t <= 223) {
						$tn = 2;
						$n += 2;
						$noc += 2;
					} elseif (224 <= $t && $t < 239) {
						$tn = 3;
						$n += 3;
						$noc += 2;
					} elseif (240 <= $t && $t <= 247) {
						$tn = 4;
						$n += 4;
						$noc += 2;
					} elseif (248 <= $t && $t <= 251) {
						$tn = 5;
						$n += 5;
						$noc += 2;
					} elseif ($t == 252 || $t == 253) {
						$tn = 6;
						$n += 6;
						$noc += 2;
					} else {
						$n ++;
					}
					if ($noc >= $len) {
						break;
					}
				}

				if ($noc > $len) {
					$n -= $tn;
				}
				$wordscut = substr($str, 0, $n);
			} else {
				$cLen = 0;
				for($i = 0; $i < $len - 1 && $cLen <= $len; $i ++) {
					$ord = ord ( $str [$i] );
					if($ord > 64 && $ord < 91){ // ��д��ĸ����+1
						$wordscut .= $str [$i];
						$cLen ++;
					} else if ($ord > 127) {
						$wordscut .= $str [$i] . $str [$i + 1];
						$cLen ++;
						$i ++;
					} else {
						$wordscut .= $str [$i];
					}
				}
			}

			$str = $wordscut . $collapse;
		}

		return trim($str);
	}

	public static function redirect($url){
		$url = self::urlAppendSid($url);
		ToolUtil::redirect($url);
	}

	public static function urlAppendSid($url){
		if(stripos($url, "http://") === false // �����ڣ���Ե�ַ
				|| preg_match("/^http:\/\/([^\/]+\.|)(51buy|icson)\.com/i", $url)){
			if(!preg_match("/(\?|&)sid=(.*?)(&|$)/", $url)){
				$url .= (strpos($url, "?") !== false ? '&' : '?') . 'sid=' . session_id();
			} else {
				$url = preg_replace("/(\?|&)sid=(.*?)(&|$)/", "$1sid=" . session_id() . "$3", $url);
			}

			if(strpos($url, "/") === 0){
				$url = 'http://' . self::getMDomain() . $url;
			}
		}
		return $url;
	}

	public static function checkUrlValid($url){
		if ( isset($url) && preg_match("/^http:\/\/([^\/]+\.|)(51buy)\.com/i", $url) ) {
			$url = preg_replace("/(\?|&(amp;)?)sid=.*?(&(amp;)?|$)/", "", $url);
			return $url;
		}
		return '/';
	}

	public static function checkLoginOrRedirect($url = null){
		if(empty($_SESSION['uid'])){
			if($url === null){
				$url = preg_replace("/(?!\?|&(amp;)?)sid=(.*?)(&(amp;)?|$)/", "", $_SERVER['REQUEST_URI']);
				$url = preg_replace("/(&(amp;)?|\?)$/", "", $url);
			} else {
				$url = trim($url);
				$url = stripos($url, "http://") === 0 ? self::checkUrlValid($url) : $url;
			}
			self::redirect("http://" . self::getMDomain() . "/wlogin.html?url=" . urlencode($url));
			return false;
		}

		return true;
	}

	//�ж��Ƿ��¼����û�е�¼��ֱ��ȥQQ��¼
	public static function checkLoginOrRedirectQQ($url = null){
		if(empty($_SESSION['uid'])){
			if($url === null){
				$url = preg_replace("/(?!\?|&(amp;)?)sid=(.*?)(&(amp;)?|$)/", "", $_SERVER['REQUEST_URI']);
				$url = preg_replace("/(&(amp;)?|\?)$/", "", $url);
			} else {
				$url = trim($url);
				$url = stripos($url, "http://") === 0 ? self::checkUrlValid($url) : $url;
			}
			self::redirect("http://" . self::getMDomain() . "/wlogin-qq.html?url=" . urlencode($url));
			return false;
		}

		return true;
	}

	public static function getWapCategory($whId){
		if(!isset(self::$wapCategory[$whId])){
			$wapCategory = IPageCacheTTC::get("WAP_CATEGORY_" . $whId);
			if($wapCategory === false){
				self::setERR(9001, "IPageCacheTTC::get error: " . IPageCacheTTC::$errCode . "; " . IPageCacheTTC::$errMsg);
				return false;
			} else {
				if(count($wapCategory) > 0){
					self::$wapCategory[$whId] = @unserialize($wapCategory[0]['content']);
				} else {
					self::$wapCategory[$whId] = array();
				}
			}
		}

		return self::$wapCategory[$whId];
	}

	public static function inputConvertEncoding(&$str){
		$str = iconv("UTF-8", 'GBK//IGNORE', $str);
	}

	public static function ouputConvertEncoding(&$str){
		$domain = self::getMDomain();
		if($domain != 'm.51buy.com'){
			$str = str_replace("http://m.51buy.com", "http://" . $domain, $str);
		}
		$str = iconv("GBK", 'UTF-8//IGNORE', $str);

		$str = preg_replace_callback("/<(a|area)([^>]+?)(href)=\"http:\/\/([^\">]*?)\"/", 'WapUtil::_urlRewriter', $str);
		$str = preg_replace_callback("/<(frame|input)([^>]+?)(src)=\"http:\/\/([^\">]*?)\"/", 'WapUtil::_urlRewriter', $str);
		$str = preg_replace_callback("/<(form)([^>]+?)(action)=\"http:\/\/([^\">]*?)\"/", 'WapUtil::_urlRewriter', $str);
	}

	public static function _urlRewriter($matches){
		if(preg_match("/(&|\?)sid=/", $matches[4]) || (stripos($matches[4], self::getMDomain()) !== 0 && stripos($matches[4], "pay.51buy.com") !== 0)) return $matches[0];
		$url = explode("#", $matches[4]);
		if($matches[3] == 'href' || $matches[3] == 'src'){
			if(strpos($url[0], "?") !== false) $url[0] .= "&sid=" . $_SESSION['sid'];
			else $url[0] .= "?sid=" . $_SESSION['sid'];
			return "<" . $matches[1] . $matches[2] . $matches[3] . '="http://' . implode("#", $url) . '"';
		} else if($matches[3] == 'form'){
			return $matches[0] . '<input type="hidden" name="sid" value="' . $_SESSION['sid'] . '" />';
		}
		return $matches[0];
	}

	public static function getMDomain(){
		if(self::$DOMAIN !== false){
			return self::$DOMAIN;
		}

		if(defined("WAP_M_DOMAIN")){
			$domain = WAP_M_DOMAIN;
		} else if(isset($_SERVER['SERVER_ADDR']) && $_SERVER['SERVER_ADDR'] == '10.96.78.101'){
			$domain = 'test.m.51buy.com';
		} else if(isset($_SERVER['DOCUMENT_ROOT']) && strpos($_SERVER['DOCUMENT_ROOT'], "test")){
			$domain = 'w3sg.m.51buy.com';
		} else {
			$domain = 'm.51buy.com';
		}

		self::$DOMAIN = $domain;
		return $domain;
	}

	public static function googleAnalyticsGetImageUrl(){
		$url = "http://" . self::getMDomain() . "/track.php?";
		$url .= "utmn=" . rand ( 0, 0x7fffffff );
		$referer = empty($_SERVER ["HTTP_REFERER"]) ? "" :$_SERVER ["HTTP_REFERER"];
		$query = empty($_SERVER ["QUERY_STRING"]) ? "" :$_SERVER ["QUERY_STRING"];
		$path = empty($_SERVER ["REQUEST_URI"]) ? "" :$_SERVER ["REQUEST_URI"];
		if (empty ( $referer )) {
			$referer = "-";
		}

		$referer = preg_replace("/(?!\?|&(amp;)?)sid=(.*?)(&(amp;)?|$)/", "", $referer);
		$referer = preg_replace("/(&(amp;)?|\?)$/", "", $referer);
		$path = preg_replace("/(?!\?|&(amp;)?)sid=(.*?)(&(amp;)?|$)/", "", $path);
		$path = preg_replace("/(&(amp;)?|\?)$/", "", $path);
		$url .= "&refer=" . urlencode ( $referer );
		if (! empty ( $path )) {
			$url .= "&path=" . urlencode ( $path );
		}
		$url .= "&guid=ON";
		return str_replace ( "&", "&amp;", $url );
	}
}
// End Of Script