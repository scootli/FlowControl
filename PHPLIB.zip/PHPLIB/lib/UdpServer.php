<?php
/**
 * UdpServer
 * @author ��ѧ��
 * @version 1.0
 * @updated 08-����-2008 21:51:15
 */

set_time_limit(0);
declare(ticks = 1);

abstract class UdpServer
{
	const STOP	  = 'STOP';
	const RUNNING = 'RUNNING';

	// IP ��ַ
	protected $ip = false;

	// �˿�
	protected $port = false;

	// �ӽ��� id
	private $child = false;

	// �Ƿ���Ҫ���ͻظ�
	protected $isResponse = false;

	// ����ʱ��
	private $startTime = false;

	// ������
	protected $blacklist = false;

	// ������
	protected $whitelist = false;

	// �������� server �ľ��
	private $serverHandle = false;

	// ��ǰ�������������
	protected $curRequestNum = 0;

	// ��ȷ�����������
	protected $succRequestNum = 0;

	// ��ȷ��Ӧ��������
	protected $succResponseNum = 0;

	// ��������������
	protected $errRequestNum = 0;

	// �������Ӧ������
	protected $errResponseNum = 0;

	// �����������Ĵ�������������
	protected $maxRequestNum = 100000;

	// ������Ϣ����󳤶�
	protected $maxLength = 1024000;

	// ����״̬
	private $status = self::RUNNING;

	// ������̵��ļ�
	private $pidFile = false;

	// �Ƿ�Ӱ��ĳ���У��
	private $wrap = true;

	function __construct($isResponse=true, $maxLength=10240, $blacklist=false, $whitelist=false, $wrap = true)
	{
		$this->maxLength	= $maxLength;
		$this->blacklist	= $blacklist;
		$this->whitelist	= $whitelist;
		$this->isResponse	= $isResponse;
		$this->wrap			= $wrap;
	}

	function __destruct(){}

	/**
	 * �����������Ҫ��������, �ڲ�����
	 */
	private function _monitor()
	{
		while (true) {
			$pid = pcntl_wait($status, WNOHANG);
			if ( $this->status === self::STOP ) {
				if ( $pid > 0 && $pid == $this->child ) {
					$this->child = false;
					break;
				} else {
					$this->ping();
				}
			} else {
				if ( $pid > 0 && $pid == $this->child ) {
					$this->child = false;
					$this->createProcess();
				} else {
					sleep(2);
					$this->monitor();
				}
			}
		}
		socket_close($this->serverHandle);
	}

	/**
	 * ���� Server �ⲿ��һЩ����
	 */
	public function run()
	{
		// ��Ҫ��֤ ip �Ͷ˿ڵĺϷ���
		$param = $this->analyseParam();
		$this->ip   = $param['h'];
		$this->port = $param['p'];
		$this->pidFile = '/tmp/PHP_UDP_SERVER_'.$this->ip.'.'.$this->port;
		switch ($param['cmd']) {
			case 'start' :
				$this->start($param);
				break;
			case 'stop'  :
				$this->stop($param);
				break;
			default:
				Logger::err('unrecognized parameter');
				exit("unrecognized parameter.\n");
		}
	}

	/**
	 * ����
	 *
	 * @param param
	 */
	private function start()
	{
		if ( file_exists($this->pidFile) ) {
			$pid = file_get_contents($this->pidFile);
			if ( file_exists("/proc/{$pid}") ) {
				Logger::err('server is runing');
				exit("server is runing.\n");
			}
			unlink($this->pidFile);
		}
		$this->init();
		$this->_monitor();
	}

	/**
	 * ֹͣ server ������
	 *
	 * @param param
	 */
	private function stop($param)
	{
		$pid = file_get_contents($this->pidFile);
		if ( $pid === false ) {
			Logger::err("stop fail. can not find pid file {$this->pidFile}");
    		exit("error: stop fail. can not find pid file {$this->pidFile}\n");
    	}

    	if ( !empty($param['method']) && $param['method'] == '-f' ) {
    		$ret = posix_kill($pid, SIGUSR2);
    	} else {
    		$ret = posix_kill($pid, SIGUSR1);
    	}

		if ($ret) {
			Logger::info("stop server succ");
			exit("succ: stop server succ.\n");
		}

		Logger::err("stop server fail");
		exit("error: stop server fail.\n");
	}

	/**
	 * ��ʼ��������
	 */
	private function init()
	{
		$pid = pcntl_fork();
		// �����ӽ���ʧ��
		if ( $pid == -1 ) {
			Logger::err("start server fail. can not create process");
			exit("error: start server fail. can not create process.\n");
		} elseif ( $pid > 0 ) {
			exit(0);
		}

		posix_setsid();
		$pid = pcntl_fork();
		// �����ӽ���ʧ��
		if ( $pid == -1 ) {
			Logger::err("start server fail. can not create process", self::FATAL);
			exit("error: start server fail. can not create process.\n");
		} elseif ( $pid > 0 ) {
			exit(0);
		}

		pcntl_signal(SIGHUP,  SIG_IGN);
		pcntl_signal(SIGINT,  SIG_IGN);
		pcntl_signal(SIGTTIN, SIG_IGN);
		pcntl_signal(SIGTTOU, SIG_IGN);
		pcntl_signal(SIGQUIT, SIG_IGN);

		$r = pcntl_signal(SIGUSR1, array($this, "signalHandle"));
		if ( $r == false ) {
			Logger::err("install SIGUSR1 fail");
			exit("error: install SIGUSR1 fail.\n");
		}

		$r = pcntl_signal(SIGUSR2, array($this, "signalHandle"));
		if ( $r == false ) {
			Logger::err("install SIGUSR2 fail");
			exit("error: install SIGUSR2 fail.\n");
		}

		$this->serverHandle = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
		if ( $this->serverHandle === false ) {
			$err = socket_strerror(socket_last_error());
			Logger::err("socket create fail.{$err}");
			exit("error: socket create fail.{$err}\n");
		}

		if ( !socket_set_option($this->serverHandle, SOL_SOCKET, SO_REUSEADDR, 1) ) {
			$err = socket_strerror(socket_last_error($this->serverHandle));
			socket_close($this->serverHandle);
			Logger::err($err);
			exit("error: {$err}.\n");
		}

		$bind = socket_bind($this->serverHandle, $this->ip, $this->port);
		if ( $bind == false ) {
			$err = socket_strerror(socket_last_error($this->serverHandle));
			socket_close($this->serverHandle);
			Logger::err($err);
			exit("error: socket bind fail.{$err}\n");
		}

		$pid = posix_getpid();
		$r = file_put_contents($this->pidFile, $pid);
		if ( $r <= 0 ) {
			Logger::err("can not write pid file($this->pidFile)");
			exit("error: can not write pid file($this->pidFile).\n");
		}

		$pid = pcntl_fork();
		if ( $pid == -1 ) {
			Logger::err("can not create fork", self::ERROR);
			exit('error: can not create fork!');
		} elseif ( $pid == 0) {
			pcntl_signal(SIGUSR1, SIG_IGN);
			$this->child	= false;
			$this->pidFile	= false;
			$this->startTime= time();
			$this->service();
			exit(0);
		}

		$this->child = $pid;
		$this->startTime = time();
	}

	/**
	 * ��������
	 */
	private function service()
	{
		$this->taskBefore();
		while ( $this->status == self::RUNNING ) {
			if ( $this->curRequestNum > $this->maxRequestNum ) {
				break;
			}

			$this->curRequestNum++;
			$ip = '';
			$port = 0;
			$hasErr = false;
			$errMsg = '';

			if ( $this->wrap ) {
				$message = NetUtil::udpSocketRecvFrom($this->serverHandle, $this->maxLength, $ip, $port);
				if ( $message === false ) {
					$hasErr = true;
					$errMsg = NetUtil::$errMsg;
				}
			} else {
				$ret = socket_recvfrom($this->serverHandle, $message, $this->maxLength, 0, $ip, $port);
				if ( $ret === -1 ) {
					$message = false;
					$hasErr = true;
					$errMsg = socket_strerror(socket_last_error());
				}
			}

			// �жϰ�����
			if ( $hasErr === false && !empty($this->whitelist) && !in_array($ip, $this->whitelist) ) {
				$hasErr = true;
				$errMsg = "{$ip} is not allowed";
				Logger::err("{$ip} is not allowed");
			}

			// �жϺ�����
			if ( $hasErr === false && !empty($this->blacklist) && in_array($ip, $this->blacklist) ) {
				$hasErr = true;
				Logger::err("{$ip} is not allowed");
			}

			if ( $hasErr === true) {
				$this->errRequestNum++;
			} else {
				$this->succRequestNum++;
			}

			$response = '';
			try {
				$response = $this->task($message, !$hasErr, $errMsg);
			} catch (Exception $e) {
				Logger::err($e->getMessage());
			}

			// ������Ϣ
			if ($this->isResponse === false) {
				continue;
			}

			if ( $this->wrap ) {
				$ret = NetUtil::udpSocketSendTo($this->serverHandle, $response, $ip, $port);
				if ( $ret === false ) {
					Logger::err(NetUtil::$errMsg);
					$this->errResponseNum++;
				} else {
					$this->succResponseNum++;
				}
			} else {
				$len = strlen($response);
				$ret = socket_sendto($this->serverHandle, $response, $len, 0, $ip, $port);
				if ( $ret != $len ) {
					$errMsg = socket_strerror(socket_last_error());
					Logger::err($errMsg, self::ERROR);
					$this->errResponseNum++;
				} else {
					$this->succResponseNum++;
				}
			}
		}
		$this->taskAfter();
	}

	/**
	 * �����������Ҫ��������
	 */
	abstract public function monitor();

	/**
	 * ��ÿ����������ǰ��ʼ��һЩ����
	 */
	public function taskBefore(){}

	/**
	 * ��ÿ����������ǰִ��һЩ����
	 */
	public function taskAfter(){}

	/**
	 *
	 * @param message    ���յ�����
	 * @param goodBag    ��ʶ�����Ƿ���ȷ
	 * @param errMsg    ���goodBag=false,�˲�����ʾ������Ϣ
	 */
	abstract public function task($message, $goodBag = true, $errMsg = '');

	/**
	 * ����һ������
	 */
	private function createProcess()
	{
		$pid = pcntl_fork();
		if ( $pid == -1 ) {
			Logger::err("can not create process");
		} elseif ( $pid == 0 ) {
			pcntl_signal(SIGUSR1, SIG_IGN);
			$this->service();
			exit(0);
		}
		$this->child = $pid;
	}

	/**
	 * �����ź���
	 */
	public function signalHandle($signo)
	{
		switch ($signo) {
			case SIGUSR1:
				$this->status = self::STOP;
				if ( $this->child == false ) break;
				posix_kill($this->child, SIGUSR2);
				break;
			case SIGUSR2:
				$this->status = self::STOP;
				if ( $this->child == false ) break;
				posix_kill($this->child, SIGKILL);
				break;
		}
	}

	/**
	 * ��������
	 */
	private function analyseParam()
	{
		$tip = "usage: %server% [start | stop] -h ip -p port [-c cfg_id] [-f]\n";

		$param['cmd'] =	isset($_SERVER['argv'][1]) ? strtolower($_SERVER['argv'][1]) : 'start';

		if ( $param['cmd'] != 'stop' && $param['cmd'] != 'start' ) {
			exit($tip);
		}

		$opts = getopt('h:p:c:f');

		if ( !isset($opts['h']) || !isset($opts['p']) ) {
			exit($tip);
		}

		foreach ( $opts as $key => $val ) {
			$val = trim($val, '=');
			switch ( $key ) {
				case 'h' :
					if ( !ToolUtil::checkIP($val) ) {
						Logger::err("ip {$val} is invalid", self::ERROR);
						exit("ip[-h] is invalid\n");
					}
					$param['h'] = $val;
					break;
				case 'p' :
					$val = intval($val);
					if ( $val > 65535 || $val < 1025 ) {
						Logger::err("port[-p] {$val} must between 1025 and 65535");
						exit("port[-p] must be between 1025 and 65535\n");
					}
					$param['p'] = $val;
					break;
				case 'c' :
					$val = intval($val);
					if ( $val < 0 ) {
						Logger::err("config id[-c] {$val} can not be less than 0");
						exit("config id[-c] can not be less than 0\n");
					}
					$param['c'] = $val;
					break;
				case 'f' :
					if ( $val === false ) {
						$param['method'] = '-f';
					}
					break;
			}
		}

		return $param;
	}

	/**
	 * �����������һ���հ��Խ��������״̬
	 */
	private function ping()
	{
		NetUtil::udpCmd($this->ip, $this->port, '', false);
	}
}


//End of script
