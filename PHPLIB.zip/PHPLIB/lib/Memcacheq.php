<?php

/**
 * Memcacheq.php 
 *
 * @copyright	(c) 1998-2011 All Rights Reserved
 * @author		rongxu <rongxu@tencent.com>
 * @version		2013-4-24 by rongxu
 *
 */

class Memcacheq {

	private $mcq = null;

	public $errCode = 0;

	public $errMsg;

	public function __construct($conf) {
		if(ArrayUtil::is_assoc_array($conf)) {
			$conf = array( $conf );
		}
		$this->mcq = new Memcache();
		foreach ($conf as $c) {
			$this->mcq->addServer($c['ip'], $c['port']);
		}
	}

	/**
	 * push������
	 *
	 * @param $qname string ��������
	 * @param $qcontent string ��������
	 * @return boolean
	 *
	 */
	public function set($qname, $qcontent) {
		return $this->mcq->set($qname, $qcontent);
	}

	/**
	 * pop������
	 *
	 * @param $qname string ��������
	 * @return mutitype
	 *
	 */
	public function get($qname) {
		return $this->mcq->get($qname);
	}

	/**
	 * �ر�mcq����
	 *
	 */
	public function close() {
		$this->mcq->close();
	}
}
