<?php

class BaseException extends Exception {
	
	public $errCode;
	public $errMsg;
	
	public function __construct($errCode, $errMsg) {
		$this->errCode = $errCode;
		$this->errMsg = $errMsg;
	}
}