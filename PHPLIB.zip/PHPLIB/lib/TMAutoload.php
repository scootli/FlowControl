<?php
if (!class_exists('TMAutoload', false)):
/*
 *---------------------------------------------------------------------------
 *
 *				  T E N C E N T   P R O P R I E T A R Y
 *
 *	 COPYRIGHT (c)  2008 BY  TENCENT  CORPORATION.  ALL RIGHTS
 *	 RESERVED.   NO  PART  OF THIS PROGRAM  OR  PUBLICATION  MAY
 *	 BE  REPRODUCED,   TRANSMITTED,   TRANSCRIBED,   STORED  IN  A
 *	 RETRIEVAL SYSTEM, OR TRANSLATED INTO ANY LANGUAGE OR COMPUTER
 *	 LANGUAGE IN ANY FORM OR BY ANY MEANS, ELECTRONIC, MECHANICAL,
 *	 MAGNETIC,  OPTICAL,  CHEMICAL, MANUAL, OR OTHERWISE,  WITHOUT
 *	 THE PRIOR WRITTEN PERMISSION OF :
 *
 *						TENCENT  CORPORATION
 *
 *	   Advertising Platform R&D Team, Advertising Platform & Products
 *	   Tencent Ltd.
 *---------------------------------------------------------------------------
 */

/**
 * Used to load all the class automatically
 *
 * @package PHPLIB.lib
 * @author  Oscarzhu <oscarzhu@tencent.com>
 * @updated bennylin
 */
/**
 * Usage:
 *
 *   1. Scan class file and cache
 *   TMAutoload::getInstance()
 *	   ->setDirs(array(ROOT_PATH, LIB_PATH))		 // dirs needed to scan
 *	   ->setSavePath(CACHE_PATH.'autoload/')		 // cache file's full path
 *	   ->setSaveName('autoloader.cache.php')		 // cache file's name
 *	   ->execute();
 *
 *   2. Rescan dirs forcly
 *   TMAutoload::getInstance()->execute(true);
 **/
class TMAutoload
{
	private
		$includeFile,
		$cacheFile,
		$savePath,
		$saveName,
		$ignore = array('.', '..', '.svn', '_config', 'test', 'template'),
		$dirs;

	public $autoloadPaths;

	/**
	 * �������ļ��Բ��Ϻŵ�ӳ���
	 * @var array
	 * @access private
	 */
	private static $unusualClassMap = array(
		'FileStorage' => 'lib/DataReport.php',
		'NetworkStorage' => 'lib/DataReport.php',
		'DataReport' => 'lib/DataReport.php',
		'Report' => 'lib/OZReport.php',
		'TTC' => 'lib/TTC.php',
		'IProductRepairDetail' => 'api/inc/IProductRepairDetailTTC.php',
		'IProductRepair' => 'api/inc/IProductRepairTTC.php',
		'IAsking' => 'api/IReviewAsking.php',
		'IReply' => 'api/IReviewReply.php',
		'IShortMessage' => 'api/IReviewShortMessage.php',
		'IUserProducts_t' => 'api/IUserProducts.php',
		'Com\Base\Session' => 'common/Base/Session.php',
		'BuyerInfoPo' => 'api/appplatform/usericsonao_xxo.php',
		'CopartnerUserInfoPo' => 'api/appplatform/userapiao_xxo.php',
		'CopartnerRecvaddrPo' => 'api/appplatform/userapiao_xxo.php',
		'CopartnerInvoicePo' => 'api/appplatform/userapiao_xxo.php',
		'PointsAccessVerifyPo' => 'api/appplatform/pointsaccountao_xxo.php',
		'PointsAccountDetailFilterPo' => 'api/appplatform/pointsaccountao_xxo.php',
		'PointsAccountDetailPo' => 'api/appplatform/pointsaccountao_xxo.php',
		'PointsAccountDetailPoList' => 'api/appplatform/pointsaccountao_xxo.php',
		'PointsAccountPo' => 'api/appplatform/pointsaccountao_xxo.php',
		'PointsInPo' => 'api/appplatform/pointsaccountao_xxo.php',
		'PointsOutPo' => 'api/appplatform/pointsaccountao_xxo.php'
	);

	/**
	 * @var TMAutoload
	 * @access private
	 */
	private static $instance;

	/**
	 * ���캯��
	 *
	 * @param string $scanDirs
	 * @param string $savePath
	 * @param string $saveName
	 */
	protected function __construct()
	{
		spl_autoload_register(array('TMAutoload', '__autoload'));
        $this->initialize();
	}

	/**
	 * Get a instance of TMAutoload
	 * @access public
	 * @param bool $newInstance   create a new instance or not
	 * @return TMAutoload
	 */
	public static function getInstance($newInstance = false)
	{
		if($newInstance || self::$instance == null)
		{
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * ���г�ʼ��
	 *
	 * @param string $scanDirs
	 * @param string $savePath
	 * @param string $saveName
	 */
	public function initialize($scanDirs = null, $savePath = null, $saveName = null, $ignore = null)
	{
		$this->autoloadPaths = array();
		$this->includeFile = array();

		$this->dirs = $scanDirs && is_array($scanDirs) ? $scanDirs : (empty($this->dirs) ? array() : $this->dirs);
		$this->savePath = $savePath ? $savePath : (empty($this->savePath) ? '/tmp/' : $this->savePath);
		$this->saveName = $saveName ? $saveName : (empty($this->saveName) ? 'autoloader.php' : $this->saveName);

		if ($ignore)
		{
			$this->ignore = array_merge($this->ignore, $ignore);
		}

		return self::$instance;
	}

	/**
	 * Customized __autoload function:Autoload the class which registered in autoload.php
	 * @access public
	 * @param string $className	the class name
	 * @return void|string	the error information
	 */
	public static function __autoload($className)
	{
		//get class file path
		switch (substr($className, 0, 3) )
		{
			case 'EA_':
				$path = PHPLIB_ROOT . 'api/' . str_replace('_', '/', substr($className, 3)) . '.php';
				break;

			case 'EL_':
				$path = PHPLIB_ROOT . 'lib/' . str_replace('_', '/', substr($className, 3)) . '.php';
				break;

			default:
				if (isset(self::$unusualClassMap[$className]))
				{
					//�������ļ�����ͬ��
					$path = PHPLIB_ROOT . self::$unusualClassMap[$className];
				}
				else
				{
					//class => file map
					$path = self::getInstance()->getClassPath($className);
					if (!$path) {
						$path = self::getInstance()->initialize()->execute(true)->getClassPath($className);
						if (!$path)
						{
							return false;
						}
					}
				}
		}

		return include_once $path;
	}

	/**
	 * add dir to scan dirs dynamically
	 * @access public
	 * @param string $dir	the dir needs scan
	 * @return void
	 */
	public function addDir($dir) {
		array_push($this->dirs, $dir);
		return self::$instance;
	}

	/**
	 * ���Ӷ��ɨ��Ŀ¼
	 *
	 * @param array $scanDirs
	 * @return TMAutoload
	 */
	public function addDirs($scanDirs) {
		$scanDirs = is_array($scanDirs) ? $scanDirs : array($scanDirs);
		$this->dirs = array_merge($this->dirs,$scanDirs);
		return self::$instance;
	}

	/**
	 * create autoload.php and add customized __autoload function to spl__autoload stack
	 * @access public
	 * @param bool $reload Reload the autoload file if this parameter is true
	 * @return void
	 */
	public function execute($reload = false)
	{
//		if ($reload)
//		{
//			if (is_file($this->savePath.$this->saveName))
//			{
//				unlink($this->savePath.$this->saveName);
//			}
//		}

		if ($reload || !is_file($this->savePath.$this->saveName))
		{
			foreach ($this->dirs as $dir) {
				$this->opendir($dir);
			}

			$this->commit();
			$this->autoloadPaths = include($this->savePath . $this->saveName);
		}
		return self::$instance;
	}

	/**
	 * Used to get the path for a unknow class
	 * @access public
	 * @param string $className the class name
	 * @return string|false
	 */
	public function getClassPath($className)
	{
		if (!$this->autoloadPaths)
		{
			if (!is_file($this->savePath . $this->saveName))
			{
				$this->execute();
			}
		}

		$this->autoloadPaths = include($this->savePath . $this->saveName);

		if (isset($this->autoloadPaths[$className]))
		{
			return $this->autoloadPaths[$className];
		}
		else
		{
			return false;
		}
	}

	/**
	 * Used to save the autoload file:autoload.php
	 * @access private
	 * @return void
	 */
	private function commit()
	{
		$files = array();
		foreach ($this->includeFile as $key => $file)
		{
			if (preg_match('/(\.class){0,1}\.php$/', $key))
			{
				$className = preg_replace('/(\.class){0,1}\.php/', '', $key);

				$files[$className] = is_array($file) ? $file[0] : $file;
			}
		}

		$path = $this->savePath;
		$name = $this->saveName;
		$content = "<?php\nreturn ".var_export($files, true).';';

		//include_once LIB_PATH.'cache/TMFileCache.class.php';
		//TMFileCache::getInstance()->execute($path, $name, $content);
		$this->saveCacheFile($path, $name, $content);
	}

	/**
	 * Open dir and save to property
	 * @access private
	 * @param string $dir the dir needs scan
	 * @return void
	 */
	private function opendir($dir)
	{
		$dir = rtrim($dir,'/ ').'/';
		$handle = opendir($dir);
		while (false !== ($file = readdir($handle)))
		{
			if (!in_array($file, $this->ignore))
			{
				if (is_file($dir.$file))
				{
					if (isset($this->includeFile[$file])) {//������ͬ�ļ����¾�����ͬ�ļ��������ļ� �������
						// the third one
						// do nothing here
					}
					else
					{
						$this->includeFile[$file] = $dir.$file;
					}
				}
				else
				{
					$this->opendir($dir.$file.'/');
				}
			}
		}
	}

	/**
	 * save "class_name => file_path" array into cache file
	 * @param string $path the path of cache file
	 * @param string $file the name of cache file
	 * @param string $content content needed to be cached
	 * @return void
	 **/
	private function saveCacheFile($path, $name, $content) {
		if (!is_dir($path)) {
			$oldumask = umask(0);
			mkdir($path, 0777, true);
			umask($oldumask);
		}
		file_put_contents($path.$name, $content);
		chmod($path.$name, 0777);
	}

	/**
	 * ����ɨ��Ŀ¼
	 *
	 * @param array $scanDirs
	 * @return TMAutoload
	 */
	public function setDirs($scanDirs) {
		$this->dirs = is_array($scanDirs) ? $scanDirs : array($scanDirs);
		return self::$instance;
	}

	/**
	 * �����ļ�����·��
	 *
	 * @param string $savePath
	 * @return TMAutoload
	 */
	public function setSavePath($savePath) {
		$this->savePath = rtrim($savePath,'/ ').'/';
		return self::$instance;
	}

	/**
	 * ���ñ��滺���ļ���
	 *
	 * @param string $saveName
	 * @return TMAutoload
	 */
	public function setSaveName($saveName) {
		$this->saveName = $saveName;
		return self::$instance;
	}
}
endif;