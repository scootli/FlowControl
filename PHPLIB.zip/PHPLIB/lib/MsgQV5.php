<?php

/**
 * MsgQ V5 发送消息&接受消息接口
 * @author zyzheng
 */

class MsgQV5 {
	
	/**
	 * 发送消息到 MsgQ V5 消息队列
	 * @param $topicId int 主题ID
	 * @param $producerName string 生产者名称
	 * @param $msg string 消息内容
	 * @return array(
	 *				'errno'		=> xx,		// 错误码: 0 发送成功, 其它 发送失败
	 *				'errmsg'	=> 'xxx',	// 错误消息
	 *				'retcode'	=> xx,		// MultiSendMsg的返回码
	 *				'retseq'	=> xx,		// MultiSendMsg的返回序列号
	 *			)
	 *			
	 */
	public static function send($topicId, $producerName, $msg) {
		if (function_exists('msgq5_send')) {
			return msgq5_send($topicId, $producerName, $msg);
		}else{
			return false;
		}
	}

	/**
	 * 从 MsgQ V5 消息队列接受消息
	 * @param $consumerId int 消费者ID
	 * @param $consumerName string 消费者名称
	 * @param $msg string 消息内容
	 * @return array(
	 *				'errno'		=> xx,		// 错误码: 0 发送成功, 其它 发送失败
	 *				'errmsg'	=> 'xxx',	// 错误消息
	 *				'msg'		=> 'xxx',	// 接收到的消息
	 *				'retcode'	=> xx,		// SingleRecvMsg
	 *				'retseq'	=> xx,		// SingleRecvMsg的返回序列号
	 *				'origtopicid' => xx,	// 接收到消息的主题，业务据此用相应的通信协议解析
	 *				'origcliid'	  => xx,	// 消息的producer pid
	 *				'origseq'	  => xx,	// 消息发送出来时的内部序列号，调试使用
	 *			)
	 *			
	 */
	public static function recv($consumerId, $consumerName) {
		if (function_exists('msgq5_recv')) {
			return msgq5_recv($consumerId, $consumerName);
		}else{
			return false;
		}
	}
	
}